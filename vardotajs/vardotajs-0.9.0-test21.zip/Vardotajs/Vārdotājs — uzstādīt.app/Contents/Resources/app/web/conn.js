"use strict";
/* Vārdotājs 0.9.0-test3 — iestatījumi kā Analītiķim (core settingsFrame, noteikumi §5): sadaļa "Pieslēgumi"
   (core/ai.py API: ai_status, ai_check, ai_connect, ai_switch, ai_logout, ai_key, open_url, pick_folder),
   "Kurš AI ko dara" (ai_roles), Izskats, sakļaujamas sadaļas. Teksti "Pieslēgumiem" — no core/web/core.js.
   Lieto app.js / frame.js palīgus ($, $$, api, t, esc, toast, uiConfirm, S, applyTheme). */

const CONN_I18N = {
  lv: {
    sec_expand: "Izvērst sadaļu", sec_collapse: "Sakļaut sadaļu",
    s_conn: "Pieslēgumi",
    s_conn_d: "Programma paroli neprasa: abonementiem pieslēdzies pakalpojuma oficiālajā lapā (atveras pārlūkā), API atslēgas glabājas tikai šī datora drošajā glabātuvē. Limitu programma neuzstāda — tā rāda, cik iztērēts, un atlikumu, ja to zina.",
    cn_onedrive: "OneDrive", cn_onedrive_d: "Datorā sinhronizētā mape — piem., rezerves kopijām.",
    cn_claude_sub: "Claude abonements", cn_claude_sub_d: "Claude Pro/Max caur Claude Code — bez papildu maksas, tērē abonementa limitus.",
    cn_chatgpt_sub: "ChatGPT abonements", cn_chatgpt_sub_d: "ChatGPT Plus/Pro caur Codex — bez papildu maksas, tērē abonementa limitus.",
    cn_claude_api: "Claude API", cn_claude_api_d: "Anthropic atslēga — maksā par katru pieprasījumu.",
    cn_openai_api: "OpenAI API", cn_openai_api_d: "OpenAI atslēga — maksā par katru pieprasījumu.",
    cn_gemini_api: "Gemini API", cn_gemini_api_d: "Google AI Studio atslēga — ir bezmaksas līmenis ar dienas limitu (Google var izmantot datus apmācībai — tikai nekonfidenciāliem darbiem).",
    cn_ollama: "Ollama (datorā)", cn_ollama_d: "Bez maksas un bez interneta, dati paliek datorā. Der: vienkārši jautājumi, jaudīgs dators (Mac M sērija). Neder: vājš dators, maz vietas (modeļi vairāki GB), sarežģīti jautājumi, latviešu valoda.",
    cn_on: "pieslēgts", cn_off: "nav pieslēgts", cn_checking: "pārbaudu…", cn_not_installed: "nav uzstādīts", cn_no_key: "nav atslēgas", cn_not_logged_in: "nav pieslēdzies",
    cn_not_running: "nedarbojas", cn_no_models: "nav neviena modeļa", cn_err: "kļūda: {e}", cn_found: "atrasta: {p}", cn_nf: "nav atrasta",
    cn_install: "Uzstādīt", cn_login: "Pieslēgties", cn_connect: "Pieslēgt", cn_switch: "Mainīt kontu", cn_wait: "gaidu pieslēgšanos…", cn_ok: "{a}: pieslēgts", cn_switch_q: "Mainīt kontu? Vispirms pārlūkā atver claude.ai / chatgpt.com un pārliecinies, ka tur esi ielogojies ar vajadzīgo kontu — pieslēgšanās lapa ņems to.", cn_check: "Pārbaudīt", cn_logout: "Atslēgties", cn_getkey: "Iegūt atslēgu", cn_download: "Lejupielādēt Ollama",
    cn_key_ph: "ielīmē atslēgu", cn_key_saved_ph: "•••••• (saglabāta)", cn_save: "Saglabāt", cn_forget: "Aizmirst", cn_use_backup: "Izvēlēties mapi rezerves kopijām…", cn_bk_set: "Rezerves kopijas tagad: {p}",
    cn_term: "Atvērts Terminal logs — tur viss notiks pats; pārlūkā ielogojies un apstiprini. Rinda kļūs zaļa pati.",
    cn_spent: "Šomēnes: {n} piepras. · {tok} tokenu", cn_usd: " · ~${u}", cn_bal_ph: "atlikums $", cn_bal_left: "Atlikums: ~${l} (ievadīts {d})", cn_bal_save: "Saglabāt atlikumu",
    cn_limit: "Limits sasniegts {at}{r}", cn_models: "Modeļi: {m}",
    cn_roles: "Kurš AI ko dara", cn_roles_d: "Katram darbam — secība. Ja pirmajam beidzas limits vai ir kļūda, darbu turpina nākamais.", cn_none: "—", cn_first: "1.", cn_second: "2.", cn_third: "3.",
    s_theme: "Izskats", theme_light: "Gaišā", theme_dark: "Tumšā", theme_auto: "Kā sistēmā",
    s_shared: "Kopīgie dati", s_ai_work: "AI darbs (Vārdotājs)", s_ai_paths: "Programmu ceļi (ja neatrod pati)",
    cn_roles_d_v: "Katram Vārdotāja darbam — secība. Ja pirmajam beidzas limits vai ir kļūda, darbu turpina nākamais. Vārdotājs pagaidām lieto Claude un ChatGPT (abonementus un API).",
    job_describe: "Apraksti un atslēgvārdi", job_analyze: "Apskate: RF / ED, vietas, melnraksti", job_chat: "Saruna ar AI",
    job_texts: "Saīsināšana un tulkošana", cn_roles_reset: "Kā agrāk",
    open_data_dir: "Atvērt datu mapi (žurnāli, iestatījumi)", pick_open: "Atveru mapes izvēles logu…",
  },
  en: {
    sec_expand: "Expand section", sec_collapse: "Collapse section",
    s_conn: "Connections",
    s_conn_d: "The program never asks for passwords: subscriptions are connected on the provider's official page (opens in the browser), API keys are kept only in this computer's secure store. The program sets no limits — it shows what has been spent and the balance, if known.",
    cn_onedrive: "OneDrive", cn_onedrive_d: "The folder synced on this computer — e.g. for backups.",
    cn_claude_sub: "Claude subscription", cn_claude_sub_d: "Claude Pro/Max via Claude Code — no extra cost, uses the subscription limits.",
    cn_chatgpt_sub: "ChatGPT subscription", cn_chatgpt_sub_d: "ChatGPT Plus/Pro via Codex — no extra cost, uses the subscription limits.",
    cn_claude_api: "Claude API", cn_claude_api_d: "Anthropic key — paid per request.",
    cn_openai_api: "OpenAI API", cn_openai_api_d: "OpenAI key — paid per request.",
    cn_gemini_api: "Gemini API", cn_gemini_api_d: "Google AI Studio key — has a free tier with a daily limit (Google may use the data for training — non-confidential work only).",
    cn_ollama: "Ollama (on this computer)", cn_ollama_d: "Free and offline, data stays on the computer. Good for: simple questions, a powerful computer (Mac M series). Not for: a weak computer, little disk space (models are several GB), complex questions, Latvian.",
    cn_on: "connected", cn_off: "not connected", cn_checking: "checking…", cn_not_installed: "not installed", cn_no_key: "no key", cn_not_logged_in: "not signed in",
    cn_not_running: "not running", cn_no_models: "no models", cn_err: "error: {e}", cn_found: "found: {p}", cn_nf: "not found",
    cn_install: "Install", cn_login: "Sign in", cn_connect: "Connect", cn_switch: "Change account", cn_wait: "waiting for sign-in…", cn_ok: "{a}: connected", cn_switch_q: "Change account? First open claude.ai / chatgpt.com in the browser and make sure you are signed in with the account you want — the sign-in page will use it.", cn_check: "Check", cn_logout: "Disconnect", cn_getkey: "Get a key", cn_download: "Download Ollama",
    cn_key_ph: "paste the key", cn_key_saved_ph: "•••••• (saved)", cn_save: "Save", cn_forget: "Forget", cn_use_backup: "Choose a folder for backups…", cn_bk_set: "Backups now go to: {p}",
    cn_term: "A Terminal window opened — everything runs by itself there; sign in and confirm in the browser. The row will turn green by itself.",
    cn_spent: "This month: {n} requests · {tok} tokens", cn_usd: " · ~${u}", cn_bal_ph: "balance $", cn_bal_left: "Balance: ~${l} (entered {d})", cn_bal_save: "Save balance",
    cn_limit: "Limit reached {at}{r}", cn_models: "Models: {m}",
    cn_roles: "Which AI does what", cn_roles_d: "For each job — an order. If the first one hits its limit or fails, the next one continues.", cn_none: "—", cn_first: "1.", cn_second: "2.", cn_third: "3.",
    s_theme: "Appearance", theme_light: "Light", theme_dark: "Dark", theme_auto: "As system",
    s_shared: "Shared data", s_ai_work: "AI work (Vārdotājs)", s_ai_paths: "Program paths (if not found automatically)",
    cn_roles_d_v: "For each Vārdotājs job — an order. If the first one hits its limit or fails, the next one continues. For now Vārdotājs uses Claude and ChatGPT (subscriptions and API).",
    job_describe: "Titles, descriptions and keywords", job_analyze: "Analysis: RF / ED, places, drafts", job_chat: "Chat with AI",
    job_texts: "Shortening and translation", cn_roles_reset: "As before",
    open_data_dir: "Open data folder (logs, settings)", pick_open: "Opening the folder picker…",
  },
};
for (const l of Object.keys(CONN_I18N)) {
  window.I18N[l] = window.I18N[l] || {};
  for (const [k, v] of Object.entries(CONN_I18N[l])) if (!(k in window.I18N[l])) window.I18N[l][k] = v;
}

const CN = { list: ["onedrive", "claude_sub", "chatgpt_sub", "claude_api", "openai_api", "gemini_api", "ollama"],
  usable: ["claude_sub", "chatgpt_sub", "claude_api", "openai_api"], jobs: ["describe", "analyze", "chat", "texts"],
  st: null, pages: {}, polls: {}, rolesDirty: false, built: false };
const cnRow = (p) => $(`.conn[data-p="${p}"]`);
const fmtN = (n) => (n || 0).toLocaleString(window.LOCALE());

/* ---------- sakļaujamas sadaļas (kā core makeCollapsible) ---------- */
const CN_CHEV = `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path class="c1" d="M4 3h5l7 7-7 7H4l7-7z" transform="translate(0 -1) rotate(90 12 12)"/><path class="c2" d="M4 3h5l7 7-7 7H4l7-7z" transform="translate(0 5) rotate(90 12 12)"/></svg>`;
function cnCollapsible(root) {
  $$("section[data-collapse]", root).forEach((sec) => {
    const h = $("h2", sec);
    if (!h || sec.querySelector(":scope > .sec-body")) return;
    const body = document.createElement("div");
    body.className = "sec-body";
    while (h.nextSibling) body.appendChild(h.nextSibling);
    sec.appendChild(body);
    if (h.dataset.i18n) {
      const sp = document.createElement("span");
      sp.dataset.i18n = h.dataset.i18n; sp.textContent = h.textContent;
      h.removeAttribute("data-i18n"); h.textContent = ""; h.appendChild(sp);
    }
    const b = document.createElement("button");
    b.type = "button"; b.className = "sec-tog"; b.innerHTML = CN_CHEV;
    h.appendChild(b);
    h.classList.add("sec-h");
    const key = "sec:" + sec.dataset.collapse;
    const set = (open, save) => {
      sec.classList.toggle("collapsed", !open);
      b.title = t(open ? "sec_collapse" : "sec_expand");
      b.setAttribute("aria-expanded", String(open));
      if (save) try { localStorage.setItem(key, open ? "1" : "0"); } catch (_) {}
    };
    let open = false;
    try { open = localStorage.getItem(key) === "1"; } catch (_) {}
    set(open, false);
    h.addEventListener("click", () => set(sec.classList.contains("collapsed"), true));
  });
}

/* ---------- Pieslēgumi ---------- */
function cnRowHtml(p) {
  const keyed = /_api$/.test(p), sub = /_sub$/.test(p);
  return `<div class="conn" data-p="${p}"><span class="dot cn-dot"></span>
    <div class="cn-main"><b data-i18n="cn_${p}"></b> <span class="cn-st muted small"></span>
      <div class="muted small" data-i18n="cn_${p}_d"></div><div class="cn-info small"></div></div>
    <div class="cn-act">
      ${sub ? `<button class="small-btn primary cn-connect" data-i18n="cn_connect"></button><button class="small-btn cn-switch hidden" data-i18n="cn_switch"></button>` : ""}
      ${keyed ? `<input class="cn-key" type="password" autocomplete="new-password" data-i18n-ph="cn_key_ph"><button class="small-btn cn-ksave" data-i18n="cn_save"></button><button class="small-btn ghost cn-getkey" data-i18n="cn_getkey"></button>` : ""}
      ${p === "ollama" ? `<button class="small-btn ghost cn-getkey" data-i18n="cn_download"></button>` : ""}
      ${p === "onedrive" ? `<button class="small-btn cn-od hidden" data-i18n="cn_use_backup"></button>` : sub ? "" : `<button class="small-btn cn-check" data-i18n="cn_check"></button>`}
      ${sub ? `<button class="small-btn ghost cn-logout hidden" data-i18n="cn_logout"></button>` : keyed ? `<button class="small-btn ghost cn-logout hidden" data-i18n="cn_forget"></button>` : ""}
      ${keyed ? `<span class="cn-bal"><input class="cn-balv" type="number" step="0.01" min="0" data-i18n-ph="cn_bal_ph"><button class="small-btn ghost cn-bsave" data-i18n="cn_bal_save"></button></span>` : ""}
    </div></div>`;
}
function cnSet(p, ok, txt) {
  const row = cnRow(p); if (!row) return;
  $(".cn-dot", row).className = "dot cn-dot " + (ok === true ? "ok" : ok === false ? "off" : "");
  $(".cn-st", row).textContent = txt || "";
}
function cnWhy(r) { return r.why ? (t("cn_" + r.why) !== "cn_" + r.why ? t("cn_" + r.why) : t("cn_err", { e: r.detail || r.why })) : ""; }
function cnSubUi(p, on) {
  const row = cnRow(p); if (!row) return;
  $(".cn-connect", row).classList.toggle("hidden", on);
  $(".cn-switch", row).classList.toggle("hidden", !on);
  $(".cn-logout", row).classList.toggle("hidden", !on);
}
async function cnCheck(p) {
  if (!/_sub$/.test(p)) cnSet(p, null, t("cn_checking"));
  try {
    const r = (await api("ai_check", { p })).res || {};
    if (/_sub$/.test(p)) cnSubUi(p, !!r.ok);
    cnSet(p, !!r.ok, r.ok ? t("cn_on") + (r.who ? " · " + r.who : "") + (r.plan ? " · " + r.plan : "")
      : (r.why === "not_installed" || r.why === "not_logged_in" ? t("cn_off") : cnWhy(r)));
    if (r.ok && r.models && r.models.length) $(".cn-info", cnRow(p)).textContent = t("cn_models", { m: r.models.slice(0, 6).join(", ") });
    return r;
  } catch (e) { cnSet(p, false, e.message); return {}; }
}
function cnPoll(p) {          // pēc "Pieslēgt": ik 3 s (līdz 5 min) — rinda kļūst zaļa pati
  clearInterval(CN.polls[p]);
  const t0 = Date.now();
  CN.polls[p] = setInterval(async () => {
    if (Date.now() - t0 > 300e3) { clearInterval(CN.polls[p]); return; }
    try {
      const d = await api("ai_check", { p });
      if (d.res && d.res.ok) { clearInterval(CN.polls[p]); await cnCheck(p); toast(t("cn_ok", { a: t("cn_" + p) }), "ok", 4000); cnBadge(); }
    } catch (_) { /* */ }
  }, 3000);
}
function cnBadge() { try { if (typeof refreshAccBadge === "function") refreshAccBadge(); } catch (_) { /* */ } }
async function connLoad() {
  const box = $("#connList"); if (!box) return;
  if (!CN.built) { box.innerHTML = CN.list.map(cnRowHtml).join(""); applyI18n(box); CN.built = true; }
  try { const d = await api("ai_status"); CN.st = d.status; CN.pages = d.pages || {}; } catch (_) { return; }
  CN.list.forEach((p) => {
    const s = CN.st[p] || {}, row = cnRow(p), info = [];
    if (p === "onedrive") { cnSet(p, !!s.path, s.path ? t("cn_found", { p: s.path }) : t("cn_nf")); $(".cn-od", row).classList.toggle("hidden", !s.path); return; }
    if (/_sub$/.test(p)) { cnSubUi(p, false); cnSet(p, s.installed ? null : false, s.installed ? t("cn_checking") : t("cn_off")); if (s.installed) cnCheck(p); }
    if (/_api$/.test(p)) {
      cnSet(p, s.key ? null : false, s.key ? "" : t("cn_no_key"));
      $(".cn-key", row).placeholder = t(s.key ? "cn_key_saved_ph" : "cn_key_ph");
      $(".cn-logout", row).classList.toggle("hidden", !s.key);
      const b = (S.settings.ai_balance || {})[p]; $(".cn-balv", row).value = b ? b.amount : "";
      if (s.key && CN.usable.includes(p)) cnCheck(p);
    }
    if (p === "ollama") {
      cnSet(p, s.running ? (s.models.length ? true : null) : false, s.running ? (s.models.length ? t("cn_on") : t("cn_no_models")) : t("cn_not_running"));
      if (s.models.length) info.push(t("cn_models", { m: s.models.slice(0, 6).join(", ") }));
    }
    const sp = s.spent || {};
    if (sp.n) info.push(t("cn_spent", { n: fmtN(sp.n), tok: fmtN((sp.tin || 0) + (sp.tout || 0)) }) + (sp.usd ? t("cn_usd", { u: sp.usd.toFixed(2) }) : ""));
    if (s.balance) info.push(t("cn_bal_left", { l: Number(s.balance.left).toFixed(2), d: s.balance.at }));
    if (s.limit) info.push(t("cn_limit", { at: s.limit.at.replace("T", " "), r: s.limit.reset ? " · " + s.limit.reset : "" }));
    if (info.length) $(".cn-info", row).textContent = info.join(" · ");
  });
}
$("#connList").addEventListener("click", async (e) => {
  const b = e.target.closest("button"); if (!b) return;
  const row = b.closest(".conn"), p = row.dataset.p;
  try {
    if (b.classList.contains("cn-check")) return cnCheck(p);
    if (b.classList.contains("cn-connect")) { await api("ai_connect", { p }); cnSet(p, null, t("cn_wait")); toast(t("cn_term"), "ok", 9000); cnPoll(p); return; }
    if (b.classList.contains("cn-switch")) {
      if (!(await uiConfirm(t("cn_switch_q"), t("cn_switch")))) return;
      await api("ai_switch", { p }); cnSubUi(p, false); cnSet(p, null, t("cn_wait")); toast(t("cn_term"), "ok", 9000); cnPoll(p); return;
    }
    if (b.classList.contains("cn-getkey")) { await api("open_url", { url: CN.pages[p] }); return; }
    if (b.classList.contains("cn-logout")) {
      const sub = /_sub$/.test(p);
      if (!(await uiConfirm((sub ? t("cn_logout") : t("cn_forget")) + " — " + t("cn_" + p) + "?", sub ? t("cn_logout") : t("cn_forget")))) return;
      await api(sub ? "ai_logout" : "ai_key", { p, forget: true }); await connLoad(); cnBadge(); return;
    }
    if (b.classList.contains("cn-ksave")) {
      const k = $(".cn-key", row).value.trim(); if (!k) return;
      const d = await api("ai_key", { p, key: k }); $(".cn-key", row).value = "";
      await connLoad(); const r = d.res || {}; cnSet(p, !!r.ok, r.ok ? t("cn_on") : cnWhy(r)); cnBadge(); return;
    }
    if (b.classList.contains("cn-bsave")) {
      const v = $(".cn-balv", row).value; const bal = Object.assign({}, S.settings.ai_balance || {});
      if (v === "") delete bal[p]; else bal[p] = { amount: +v, at: new Date().toISOString().slice(0, 10) };
      S.settings = (await api("settings", { settings: { ai_balance: bal } })).settings; toast(t("saved"), "ok", 1500); return connLoad();
    }
    if (b.classList.contains("cn-od")) {      // rezerves kopiju mape, sākot OneDrive
      b.disabled = true; toast(t("pick_open"), "ok", 4000);
      let r; try { r = await api("pick_folder", { start: CN.st.onedrive.path }); } finally { b.disabled = false; }
      if (!r.path) return;
      S.settings = (await api("settings", { settings: { backup_dir: r.path } })).settings;
      if ($("#sBkDir")) $("#sBkDir").value = r.path;
      toast(t("cn_bk_set", { p: r.path }), "ok", 4000); return;
    }
  } catch (err) { toast(err.message, "err"); }
});

/* ---------- Kurš AI ko dara (ai_roles; darbi — vardotajs/ai.py JOBS) ---------- */
async function rolesLoad() {
  const box = $("#connRoles"); if (!box) return;
  let d;
  try { d = await api("ai_roles"); } catch (_) { return; }
  CN.jobs = d.jobs || CN.jobs; CN.usable = d.usable || CN.usable;
  const roles = d.roles || {};
  const opts = (sel) => `<option value="">${esc(t("cn_none"))}</option>` + CN.usable.map((p) => `<option value="${p}"${p === sel ? " selected" : ""}>${esc(t("cn_" + p))}</option>`).join("");
  box.innerHTML = `<table class="t roles"><tbody>` + CN.jobs.map((j) => `<tr data-job="${esc(j)}"><td>${esc(t("job_" + j))}</td>` +
    [0, 1, 2].map((i) => `<td>${esc(t(["cn_first", "cn_second", "cn_third"][i]))} <select class="cn-role">${opts((roles[j] || [])[i] || "")}</select></td>`).join("") + `</tr>`).join("") + `</tbody></table>`;
  CN.rolesDirty = false;
  $$(".cn-role", box).forEach((s) => s.addEventListener("change", () => (CN.rolesDirty = true)));
}
function rolesCollect() {
  const out = {};
  $$("#connRoles tr[data-job]").forEach((tr) => { const v = $$(".cn-role", tr).map((s) => s.value).filter(Boolean); if (v.length) out[tr.dataset.job] = [...new Set(v)]; });
  return out;
}

/* ---------- Izskats ---------- */
$$("input[name=sTheme]").forEach((r) => r.addEventListener("change", () => {
  applyTheme(r.value);
  api("settings", { settings: { theme: r.value } }).then((d) => { S.settings = d.settings; }).catch(() => {});
}));
$$(".theme-sw button").forEach((b) => b.addEventListener("click", () => $$("input[name=sTheme]").forEach((r) => (r.checked = r.value === b.dataset.th))));

/* ---------- app.js funkcijas papildinām ---------- */
const _cnLoadSettings = loadSettingsPage;
loadSettingsPage = async function () {          // eslint-disable-line no-func-assign
  await _cnLoadSettings();
  $$("input[name=sTheme]").forEach((r) => (r.checked = r.value === (S.settings.theme || "auto")));
  connLoad();
  rolesLoad();
};
const _cnCollect = collectSettings;
collectSettings = function () {                 // eslint-disable-line no-func-assign
  const v = _cnCollect();
  if (CN.rolesDirty) v.ai_roles = rolesCollect();
  return v;
};
const _cnSetLang = setLang;
setLang = function (l, persist = true) {        // eslint-disable-line no-func-assign
  _cnSetLang(l, persist);
  if (CN.built) { $("#connList").innerHTML = ""; CN.built = false; connLoad(); rolesLoad(); }
};
$("#openDataDir").addEventListener("click", () => api("open_data_dir").catch((e) => toast(e.message, "err")));
cnCollapsible($("#page-settings"));
