"use strict";
/* Vārdotājs 0.9.0 — atjauninājumi, "Kas jauns" un rezerves kopijas (kopīgais kods core/: updater.py, backup.py;
   noteikumi §5, §9a). Lieto app.js palīgus ($, api, t, esc, toast, uiDialog, uiConfirm). */

const UPD = { info: null };

async function updCheck(force = false) {
  let d;
  try { d = await api("update_check", { force }); } catch (_) { return null; }
  UPD.info = d;
  const bar = $("#updBar");
  if (d.available && d.latest) {
    let later = null;
    try { later = sessionStorage.getItem("updLater"); } catch (_) {}
    if (force || later !== d.latest.version) {
      $("#updMsg").textContent = t("upd_avail", { v: d.latest.version, cur: d.current });
      bar.classList.remove("hidden");
    }
  } else bar.classList.add("hidden");
  return d;
}

async function updInstall() {
  const u = UPD.info;
  if (!u || !u.latest) return;
  const v = u.latest.version;
  if (!u.can_install) { toast(t("upd_dev"), "err"); return; }
  if (!(await uiConfirm(t("upd_q", { v })))) return;
  try { await api("update_install", { latest: u.latest }); }
  catch (e) { toast(e.message === "busy" ? t("upd_busy") : t("upd_error", { e: e.message }), "err", 8000); return; }
  $("#updBtns").classList.add("hidden");
  const poll = async () => {
    let s;
    try { s = (await api("update_status")).state; } catch (_) { return setTimeout(() => location.reload(), 4000); }   // pārstartējas
    if (s.status === "download") $("#updMsg").textContent = t("upd_download", { v, p: s.pct || 0 });
    else if (s.status === "install") $("#updMsg").textContent = t("upd_installing", { v });
    else if (s.status === "restart") $("#updMsg").textContent = t("upd_restart", { v });
    else if (s.status === "error") { $("#updMsg").textContent = t("upd_error", { e: s.msg }); $("#updBtns").classList.remove("hidden"); return; }
    setTimeout(poll, 800);
  };
  poll();
}

function updNotes() {
  const L = (UPD.info && UPD.info.latest) || {};
  const n = L.notes || {};
  const list = n[window.LANG] || n.en || n.lv || [];
  $("#changelogBody").innerHTML = `<div class="cl-ver"><h4>${esc(L.version)} <span class="muted small">${esc(L.date || "")}</span></h4>` +
    (Array.isArray(list) ? `<ul>${list.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : `<p>${esc(list)}</p>`) + `</div>`;
  $("#changelogModal").classList.remove("hidden");
}

/* ---------- "Kas jauns" pēc atjaunināšanas ---------- */
function verKey(v) {
  const m = String(v || "").match(/^\s*v?(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z]+)(\d*))?/);
  if (!m) return [0, 0, 0, 0, 0];
  return [+m[1], +m[2], +m[3], m[4] == null ? 1 : 0, m[4] == null ? 0 : +(m[5] || 0)];
}
function verCmp(a, b) {
  const x = verKey(a), y = verKey(b);
  for (let i = 0; i < 5; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}
let wnTimer = null;
function wnHide() {
  clearTimeout(wnTimer);
  const c = $("#wnCloud");
  if (!c || c.classList.contains("hidden")) return;
  c.classList.add("fade");
  setTimeout(() => { c.classList.add("hidden"); c.classList.remove("fade"); }, 400);
}
async function whatsNew() {
  let d;
  try { d = await api("whatsnew"); } catch (_) { return; }
  if (!d || !d.show) return;
  const lang = window.LANG, ent = {};
  for (const e of d.entries || []) {
    const n = e.notes || {};
    ent[e.version] = { v: e.version, d: e.date || "", items: Array.isArray(n[lang]) ? n[lang] : Array.isArray(n.en) ? n.en : Array.isArray(n.lv) ? n.lv : [] };
  }
  for (const c of window.CHANGELOG || []) {
    if (verCmp(c.v, d.from) > 0 && verCmp(c.v, d.to) <= 0) ent[c.v] = { v: c.v, d: c.d || "", items: c[lang] || c.en || c.lv || [] };
  }
  const list = Object.values(ent).filter((e) => e.items.length).sort((a, b) => verCmp(b.v, a.v));
  $("#wnBody").innerHTML = `<h4>${esc(t("wn_title", { v: d.to }))}</h4>` +
    (list.length > 1 || (list[0] && list[0].v !== d.to) ? `<p class="small">${esc(t("wn_since", { v: d.from }))}</p>` : "") +
    (list.length ? list.map((e) => (list.length > 1 ? `<h5>${esc(e.v)} <span class="small">${esc(e.d)}</span></h5>` : "") +
      `<ul>${e.items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`).join("") : `<p>${esc(t("wn_none", { v: d.to }))}</p>`);
  $("#wnCloud").classList.remove("hidden");
  clearTimeout(wnTimer);
  wnTimer = setTimeout(wnHide, 20000);
  api("whatsnew_seen").catch(() => {});
}

/* ---------- iestatījumi: atjauninājumi + rezerves kopijas ---------- */
const fmtDT = (s) => { if (!s) return ""; const d = new Date(s); return isNaN(d) ? s : d.toLocaleString(window.LOCALE(), { dateStyle: "short", timeStyle: "short" }); };
const fmtSize = (n) => (n > 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB");

function updLoadSettings(s) {
  $("#sUpdCh").value = s.update_channel || "auto";
  $("#sBkEvery").value = s.backup_every || "week";
  $("#sBkKeep").value = s.backup_keep ?? 10;
  $("#sBkDir").value = s.backup_dir || "";
  loadBackups();
}
function updCollect() {
  return { update_channel: $("#sUpdCh").value, backup_every: $("#sBkEvery").value,
    backup_keep: +$("#sBkKeep").value || 10, backup_dir: $("#sBkDir").value.trim() };
}
async function loadBackups() {
  let d;
  try { d = await api("backup_list"); } catch (_) { return; }
  $("#sBkDir").placeholder = d.default_dir;
  $("#bkInfo").textContent = t("bk_info", { dir: d.dir, last: d.last ? fmtDT(d.last) : t("bk_never_made"), next: d.next ? fmtDT(d.next) : "–" });
  const tag = (n) => /pirms-atjaunin/.test(n) ? t("bk_tag_update") : /pirms-atjauno/.test(n) ? t("bk_tag_restore") : /-auto/.test(n) ? t("bk_tag_auto") : "";
  $("#bkList").innerHTML = d.items.length ? `<table class="bk-t"><tbody>` + d.items.slice(0, 12).map((x) =>
    `<tr><td>${esc(fmtDT(x.mtime))}${tag(x.name) ? ` <span class="muted">· ${esc(tag(x.name))}</span>` : ""}</td>
     <td class="muted">${fmtSize(x.size)}</td><td><button data-bk="${esc(x.name)}">${esc(t("bk_restore"))}</button></td></tr>`).join("") + `</tbody></table>`
    : `<span class="muted small">${esc(t("bk_none"))}</span>`;
  $$("#bkList [data-bk]").forEach((b) => b.addEventListener("click", () => restoreBackup({ name: b.dataset.bk })));
}
async function restoreBackup(src) {
  let p;
  try { p = await api("backup_preview", src); } catch (e) { return toast(e.message === "bk_other" ? t("bk_other") : e.message, "err", 8000); }
  const m = p.manifest || {};
  if (!(await uiConfirm(t("bk_restore_q", { d: fmtDT(m.created), v: m.version || "?", n: (m.files || []).length })))) return;
  $("#bkSt").textContent = t("bk_restoring");
  try {
    const r = await api("backup_restore", src);
    toast(t("bk_restored", { n: r.saved_before }), "ok", 8000);
    setTimeout(() => location.reload(), 1800);
  } catch (e) { $("#bkSt").textContent = ""; toast(e.message, "err", 9000); }
}
async function bkSaveDir(path) { $("#sBkDir").value = path; await saveSettings(true); loadBackups(); }

(function bindUpd() {
  $("#updInstall").addEventListener("click", updInstall);
  $("#updWhats").addEventListener("click", updNotes);
  $("#updLater").addEventListener("click", () => {
    try { sessionStorage.setItem("updLater", UPD.info.latest.version); } catch (_) {}
    $("#updBar").classList.add("hidden");
  });
  $("#wnCloud").addEventListener("click", wnHide);
  $("#wnCloud").addEventListener("mouseenter", () => clearTimeout(wnTimer));
  $("#wnCloud").addEventListener("mouseleave", () => { clearTimeout(wnTimer); wnTimer = setTimeout(wnHide, 6000); });
  $("#sUpdCh").addEventListener("change", () => api("settings", { settings: { update_channel: $("#sUpdCh").value } }).catch(() => {}));
  $("#sUpdCheck").addEventListener("click", async () => {
    $("#sUpdMsg").textContent = "…";
    const d = await updCheck(true);
    $("#sUpdMsg").textContent = !d ? "" : d.error ? t("upd_fail", { e: d.error }) : d.available ? t("upd_avail", { v: d.latest.version, cur: d.current }) : t("upd_none", { v: d.current });
  });
  $("#bkNow").addEventListener("click", async () => {
    await saveSettings(true);
    $("#bkNow").disabled = true; $("#bkSt").textContent = t("bk_making");
    try { const r = await api("backup_create"); toast(t("bk_made", { n: r.name }), "ok", 6000); loadBackups(); }
    catch (e) { toast(e.message, "err", 9000); }
    $("#bkNow").disabled = false; $("#bkSt").textContent = "";
  });
  $("#bkOpen").addEventListener("click", () => api("backup_open").catch((e) => toast(e.message, "err")));
  // 0.9.0-test4: kamēr mapes izvēles logs atvērts — abas pogas atspējotas (Windows: logs varēja palikt aizmugurē)
  const bkPickBtns = (on) => ["#bkDirPick", "#bkDirOd"].forEach((id) => ($(id).disabled = on));
  $("#bkDirPick").addEventListener("click", async () => {
    bkPickBtns(true); toast(t("pick_open"), "ok", 4000);
    try { const r = await api("pick_folder", { start: $("#sBkDir").value.trim() || $("#sBkDir").placeholder }); if (r.path) bkSaveDir(r.path); }
    catch (e) { toast(e.message === "pick_busy" ? t("pick_busy") : e.message, "err"); }
    finally { bkPickBtns(false); }
  });
  $("#bkDirOd").addEventListener("click", async () => {
    bkPickBtns(true);
    try { const od = await api("onedrive"); if (!od.path) throw new Error("");
      toast(t("pick_open"), "ok", 4000);
      const r = await api("pick_folder", { start: od.path }); if (r.path) bkSaveDir(r.path); }
    catch (e) { toast(e.message === "pick_busy" ? t("pick_busy") : t("bk_no_od"), "err"); }
    finally { bkPickBtns(false); }
  });
  $("#bkDirDef").addEventListener("click", () => bkSaveDir(""));
  api("onedrive").then((r) => $("#bkDirOd").classList.toggle("hidden", !(r && r.path))).catch(() => {});
  $("#bkPick").addEventListener("click", () => $("#bkFile").click());
  $("#bkFile").addEventListener("change", () => {
    const f = $("#bkFile").files[0];
    if (!f) return;
    const rd = new FileReader();
    rd.onload = () => { $("#bkFile").value = ""; restoreBackup({ data: rd.result }); };
    rd.readAsDataURL(f);
  });
})();
