"""Drošā vietējo kopiju dzēšana (lēmums 2026-11-13 14:17, dati §7a 17–19; Vārdotājs 0.9.0-test21).

Mac / mājas dators sūta uz NAS caur Synology Drive ("One-way upload" + "Keep locally deleted files on the server").
Tirgotājs (dežūras dators, redz NAS) pārbauda sūtījumus un raksta Google `Fotostokeris/Kopigi/nas_sanemts.json`.
Šeit: nolasām to, salīdzinām ar uzskaiti (prepared.json) — bilde + pavadoņi + oriģināls (nosaukums, izmērs, MD5).
Viss sakrīt → `verified`. Pēc 3 dienām kopš sūtīšanas piedāvājam dzēst — tikai šī datora sūtījumus un tikai failus,
kas tiešām ir uzskaitē norādītajā vietā; uz Atkritni, pēc lietotāja apstiprinājuma → `local_removed`.
"""
from __future__ import annotations

import json
import os
import shutil
import sys
import time

from . import config, submit

REPORT = "nas_sanemts.json"
KEEP_DAYS = 3
_cache: dict = {"t": 0.0, "data": None, "err": ""}


def _report(force: bool = False) -> dict | None:
    """nas_sanemts.json no Google Drive (kešs ~10 min). Bez Google — None."""
    if not force and time.time() - _cache["t"] < 600:
        return _cache["data"]
    data, err = None, ""
    try:
        from core import google
        if google.connected():
            fid = google.folder("Kopigi")
            f = next((x for x in google.list_files(fid) if x.get("name") == REPORT), None)
            if f:
                data = json.loads(google.download(f["id"]).decode("utf-8"))
    except Exception as e:
        err = str(e)
        print("NAS atskaite:", e)
    _cache.update(t=time.time(), data=data, err=err)
    return data


def _ts(s: str) -> float:
    try:
        return time.mktime(time.strptime((s or "")[:19], "%Y-%m-%dT%H:%M:%S"))
    except Exception:
        return 0.0


def _expected(it: dict) -> dict:
    """Relatīvais ceļš sūtījuma mapē → (bytes, md5) visiem bildes failiem."""
    out = {it.get("name") or os.path.basename(it.get("path", "")): (it.get("size"), it.get("md5"))}
    for c in it.get("companions") or []:
        out[c.get("name")] = (c.get("size"), c.get("md5"))
    o = it.get("original")
    if o and o.get("file"):
        out[o["file"]] = (o.get("bytes"), o.get("md5"))
    return out


def _local_files(it: dict) -> list[str]:
    base = os.path.dirname(it.get("path", ""))
    return [os.path.join(base, *rel.split("/")) for rel in _expected(it)]


def refresh(force: bool = False) -> dict:
    """Atzīmē `verified` pēc NAS atskaites; atdod kandidātus dzēšanai."""
    rep = _report(force) or {}
    ships = rep.get("shipments") or {}
    me = submit.computer_name()
    led = submit.ledger()
    changed, cands = False, []
    with led.lock:
        for it in led.data.get("items", []):
            if it.get("verify") != "sync" or it.get("computer") != me or it.get("status") == "local_removed":
                continue
            sh = ships.get(it.get("series_id") or "")
            if it.get("status") != "verified" and sh:
                if sh.get("sender") and sh["sender"] != me:
                    continue
                files = sh.get("files") or {}
                ok = all(rel in files and files[rel].get("bytes") == b and str(files[rel].get("md5", "")).lower() == str(m or "").lower()
                         for rel, (b, m) in _expected(it).items())
                if ok:
                    it["status"], it["verified_at"] = "verified", submit._now()
                    changed = True
            if it.get("status") == "verified":
                age = time.time() - _ts(it.get("at", ""))
                present = [f for f in _local_files(it) if os.path.isfile(f)]
                if age >= KEEP_DAYS * 86400 and present:
                    cands.append({"id": it.get("id"), "name": it.get("name"), "folder": os.path.dirname(it.get("path", "")),
                                  "bytes": sum(os.path.getsize(f) for f in present)})
        if changed:
            led.save()
    snooze = float(config.get("cleanup_snooze") or 0)
    return {"items": cands, "n": len(cands), "bytes": sum(c["bytes"] for c in cands), "report": bool(rep),
            "snoozed": snooze > time.time(), "err": _cache["err"]}


def _trash(path: str) -> None:
    """Uz Atkritni (nekad neatgriezeniski). Kļūda → izņēmums, fails paliek."""
    if sys.platform == "win32":
        import ctypes
        from ctypes import wintypes

        class SHFILEOPSTRUCTW(ctypes.Structure):
            _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                        ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                        ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]
        op = SHFILEOPSTRUCTW(None, 3, os.path.abspath(path) + "\0", None, 0x40 | 0x10 | 0x04 | 0x400, False, None, None)
        r = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        if r or op.fAnyOperationsAborted or os.path.exists(path):
            raise OSError(f"Recycle Bin: {r}")
        return
    if sys.platform == "darwin":
        tdir = os.path.expanduser("~/.Trash")
    else:
        tdir = os.path.expanduser("~/.local/share/Trash/files")
    os.makedirs(tdir, exist_ok=True)
    base = os.path.basename(path.rstrip("/"))
    dst, n = os.path.join(tdir, base), 1
    while os.path.exists(dst):
        stem, ext = os.path.splitext(base)
        dst, n = os.path.join(tdir, f"{stem} {n}{ext}"), n + 1
    shutil.move(path, dst)


def delete(ids: list[str]) -> dict:
    """Dzēš (uz Atkritni) tikai kandidātus no refresh() — pārbauda vēlreiz."""
    want = set(ids or [])
    ok = {c["id"] for c in refresh()["items"]} & want
    led = submit.ledger()
    done, errors, folders = 0, [], set()
    with led.lock:
        for it in led.data.get("items", []):
            if it.get("id") not in ok:
                continue
            failed = False
            for f in _local_files(it):
                if os.path.isfile(f):
                    try:
                        _trash(f)
                    except Exception as e:
                        errors.append(f"{os.path.basename(f)}: {e}")
                        failed = True
            if not failed:
                it["status"] = "local_removed"
                done += 1
                folders.add(os.path.dirname(it.get("path", "")))
        led.save()
    for d in folders:            # tukša sūtījuma mape (paliek tikai _fotostokeris / tukšs Original) → arī uz Atkritni
        try:
            left = [x for x in os.listdir(d) if x not in ("_fotostokeris", ".fotostokeris", ".DS_Store", "Thumbs.db")]
            orig = os.path.join(d, "Original")
            if left == ["Original"] and os.path.isdir(orig) and not os.listdir(orig):
                left = []
            if not left:
                _trash(d)
        except Exception as e:
            print("sūtījuma mape:", d, e)
    return {"deleted": done, "errors": errors}


def snooze(hours: float = 24) -> None:
    config.update({"cleanup_snooze": time.time() + hours * 3600})
