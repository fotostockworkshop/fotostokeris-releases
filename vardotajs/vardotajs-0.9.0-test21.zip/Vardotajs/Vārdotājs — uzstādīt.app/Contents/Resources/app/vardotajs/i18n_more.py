"""Servera ziņojumi vācu, spāņu, ukraiņu valodā (test21; noteikumi §6). Tulkots no angļu teksta; trūkstošs → angļu."""
MORE = {
    "et_missing": ("ExifTool nicht gefunden. Öffne die Einstellungen und klicke „ExifTool installieren“.", "No se encontró ExifTool. Abre Ajustes y pulsa “Instalar ExifTool”.", "ExifTool не знайдено. Відкрийте налаштування й натисніть «Встановити ExifTool»."),
    "et_write_failed": ("Schreiben fehlgeschlagen", "No se pudo escribir", "Не вдалося записати"),
    "et_bad_answer": ("Die Ausgabe von ExifTool konnte nicht gelesen werden", "No se pudo leer la salida de ExifTool", "Не вдалося прочитати вивід ExifTool"),
    "folder_missing": ("Ordner nicht gefunden: {path}", "Carpeta no encontrada: {path}", "Папку не знайдено: {path}"),
    "claude_missing": ("Claude Code wurde auf diesem Computer nicht gefunden. Siehe Einstellungen → Verbindungen.", "No se encontró Claude Code en este ordenador. Consulta Ajustes → Conexiones.", "Claude Code не знайдено на цьому комп'ютері. Див. Налаштування → Під'єднання."),
    "claude_timeout": ("Claude hat innerhalb von 5 Minuten nicht geantwortet.", "Claude no respondió en 5 minutos.", "Claude не відповів протягом 5 хвилин."),
    "not_logged_in": ("Claude Code ist nicht angemeldet. Klicke in den Einstellungen „Bei Claude anmelden“.", "Claude Code no tiene sesión iniciada. En Ajustes pulsa “Iniciar sesión en Claude”.", "У Claude Code не виконано вхід. У налаштуваннях натисніть «Увійти в Claude»."),
    "limit": ("Nutzungslimit des Abos erreicht.", "Se alcanzó el límite de uso de la suscripción.", "Досягнуто ліміту використання підписки."),
    "bad_json": ("Die KI-Antwort hatte nicht das erwartete Format: ", "La respuesta de la IA no tenía el formato esperado: ", "Відповідь ШІ мала неочікуваний формат: "),
    "empty": ("Die KI hat ein leeres Ergebnis geliefert.", "La IA devolvió un resultado vacío.", "ШІ повернув порожній результат."),
    "no_api_key": ("Kein API-Schlüssel eingegeben (Einstellungen → Verbindungen).", "No se ha introducido una clave API (Ajustes → Conexiones).", "Ключ API не введено (Налаштування → Під'єднання)."),
    "api_error": ("API-Fehler", "Error de API", "Помилка API"),
    "test_ok": ("Verbindung funktioniert", "La conexión funciona", "З'єднання працює"),
    "no_date": ("Das Foto hat kein Aufnahmedatum — füge das Datum selbst in die Beschreibung ein.", "La foto no tiene fecha de captura — añade tú la fecha a la descripción.", "Фото не має дати зйомки — додайте дату в опис самостійно."),
    "no_place": ("Die KI kannte den Ort nicht — füge Stadt und Land in die Beschreibung ein oder sag es der KI im Chat.", "La IA no conocía el lugar — añade la ciudad y el país a la descripción o díselo a la IA en el chat.", "ШІ не знав місця — додайте місто й країну в опис або скажіть ШІ в розмові."),
    "codex_missing": ("ChatGPT (Codex) wurde auf diesem Computer nicht gefunden. Siehe Einstellungen → Verbindungen.", "No se encontró ChatGPT (Codex) en este ordenador. Consulta Ajustes → Conexiones.", "ChatGPT (Codex) не знайдено на цьому комп'ютері. Див. Налаштування → Під'єднання."),
    "codex_not_logged_in": ("ChatGPT ist nicht angemeldet. Klicke in den Einstellungen „Bei ChatGPT anmelden“.", "ChatGPT no tiene sesión iniciada. En Ajustes pulsa “Iniciar sesión en ChatGPT”.", "У ChatGPT не виконано вхід. У налаштуваннях натисніть «Увійти в ChatGPT»."),
    "codex_timeout": ("ChatGPT hat innerhalb von 5 Minuten nicht geantwortet.", "ChatGPT no respondió en 5 minutos.", "ChatGPT не відповів протягом 5 хвилин."),
    "no_openai_key": ("Kein OpenAI-API-Schlüssel eingegeben (Einstellungen → Verbindungen).", "No se ha introducido una clave API de OpenAI (Ajustes → Conexiones).", "Ключ API OpenAI не введено (Налаштування → Під'єднання)."),
    "switched_ai": ("Limit von {a} erreicht — weiter mit {b}.", "Límite de {a} alcanzado — se sigue con {b}.", "Ліміт {a} досягнуто — продовжую з {b}."),
    "shortened": ("Der Text war zu lang und wurde gekürzt — prüfe, ob er vollständig wirkt.", "El texto era demasiado largo y se acortó — comprueba que se lee completo.", "Текст був задовгий і його скорочено — перевірте, чи він звучить завершено."),
    "interrupted": ("Unterbrochen (Vārdotājs wurde geschlossen)", "Interrumpido (Vārdotājs se cerró)", "Перервано (Vārdotājs закрито)"),
    "web_needs_sub": ("Die Websuche ist nur mit dem Claude- oder ChatGPT-Abo verfügbar.", "La búsqueda web solo está disponible con la suscripción de Claude o ChatGPT.", "Пошук в інтернеті доступний лише з підпискою Claude або ChatGPT."),
    "et_installed": ("ExifTool installiert", "ExifTool instalado", "ExifTool встановлено"),
    "et_install_failed": ("ExifTool konnte nicht heruntergeladen werden.", "No se pudo descargar ExifTool.", "Не вдалося завантажити ExifTool."),
    "downloading": ("Lade ExifTool herunter…", "Descargando ExifTool…", "Завантажую ExifTool…"),
    "error": ("Fehler", "Error", "Помилка"),
    "home_folder": ("Benutzerordner", "Carpeta personal", "Домашня папка"),
    "nothing_to_undo": ("Nichts rückgängig zu machen.", "No hay nada que deshacer.", "Нічого скасовувати."),
    "ready_dir_none": ("Der Ordner für einreichfertige Fotos ist in den Einstellungen nicht festgelegt.", "La carpeta de fotos listas para enviar no está indicada en Ajustes.", "Папку фото, готових до подання, не вказано в налаштуваннях."),
    "spec_fmt": ("Format {f} — die Zielagenturen akzeptieren nur {ok}", "formato {f} — las agencias de destino solo aceptan {ok}", "формат {f} — цільові агенції приймають лише {ok}"),
    "spec_min_mp": ("zu klein: {mp} MP ({ag} verlangt mindestens {min} MP)", "demasiado pequeña: {mp} MP ({ag} exige al menos {min} MP)", "замале: {mp} MP ({ag} вимагає щонайменше {min} MP)"),
    "spec_min_px": ("zu klein: {px} px ({ag} verlangt mindestens {min} px)", "demasiado pequeña: {px} px ({ag} exige al menos {min} px)", "замале: {px} px ({ag} вимагає щонайменше {min} px)"),
    "spec_min_mb": ("Datei zu klein: {mb} MB ({ag} verlangt mindestens {min} MB)", "archivo demasiado pequeño: {mb} MB ({ag} exige al menos {min} MB)", "файл замалий: {mb} MB ({ag} вимагає щонайменше {min} MB)"),
    "spec_big_nojpg": ("zu groß ({mb} MB) und kein JPG — kann nicht komprimiert werden", "demasiado grande ({mb} MB) y no es JPG — no se puede comprimir", "завеликий ({mb} MB) і не JPG — стиснути неможливо"),
    "spec_conflict": ("die Anforderungen der Zielagenturen widersprechen sich (min. und max. Größe)", "los requisitos de las agencias de destino se contradicen (tamaño mín. y máx.)", "вимоги цільових агенцій суперечать одна одній (мін. і макс. розмір)"),
    "spec_cant": ("{mb} MB konnten nicht auf {max} MB komprimiert werden, ohne unter das Geforderte zu gehen", "no se pudo comprimir de {mb} MB a {max} MB sin bajar del tamaño exigido", "не вдалося стиснути {mb} MB до {max} MB, не опустившись нижче вимог"),
    "copy_mismatch": ("die Kopie stimmt nicht mit dem Original überein (Größe oder Prüfsumme) — das Original blieb, wo es war", "la copia no coincide con el original (tamaño o suma de comprobación) — el original se dejó en su sitio", "копія не збігається з оригіналом (розмір або контрольна сума) — оригінал залишено на місці"),
    "dest_exists": ("am Ziel gibt es schon eine Datei mit diesem Namen", "ya existe un archivo con este nombre en el destino", "у місці призначення вже є файл із такою назвою"),
    "ready_dir_missing": ("Der Ordner für einreichfertige Fotos ist nicht erreichbar: {path}", "La carpeta de fotos listas para enviar no está disponible: {path}", "Папка фото, готових до подання, недоступна: {path}"),
    "no_ai_tr": ("Keine Übersetzung — keine KI verbunden.", "Sin traducción — no hay IA conectada.", "Немає перекладу — ШІ не під'єднано."),
}


def merge(msg: dict) -> None:
    for k, (de, es, uk) in MORE.items():
        if k in msg:
            msg[k].setdefault("de", de)
            msg[k].setdefault("es", es)
            msg[k].setdefault("uk", uk)
