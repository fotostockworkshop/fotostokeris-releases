"""Servera ziņojumu tulkojumi (saskarnes teksti ir web/i18n.js)."""
from __future__ import annotations

from . import config

MSG = {
    "et_missing": {
        "lv": "ExifTool nav atrasts. Atver Iestatījumus un nospied 'Uzstādīt ExifTool'.",
        "en": "ExifTool not found. Open Settings and click 'Install ExifTool'.",
    },
    "et_write_failed": {"lv": "Neizdevās ierakstīt", "en": "Could not write"},
    "et_bad_answer": {"lv": "Neizdevās nolasīt ExifTool atbildi", "en": "Could not read ExifTool output"},
    "folder_missing": {"lv": "Mape nav atrasta: {path}", "en": "Folder not found: {path}"},
    "claude_missing": {
        "lv": "Claude Code nav atrasts šajā datorā. Skat. Iestatījumi → AI.",
        "en": "Claude Code was not found on this computer. See Settings → AI.",
    },
    "claude_timeout": {"lv": "Claude neatbildēja 5 minūšu laikā.", "en": "Claude did not answer within 5 minutes."},
    "not_logged_in": {
        "lv": "Claude Code nav pieslēgts kontam. Iestatījumos spied 'Pieslēgties Claude kontam'.",
        "en": "Claude Code is not signed in. In Settings click 'Sign in to Claude'.",
    },
    "limit": {"lv": "Sasniegts abonementa lietošanas limits.", "en": "Subscription usage limit reached."},
    "bad_json": {"lv": "AI atbilde nebija saprotamā formātā: ", "en": "AI answer was not in the expected format: "},
    "empty": {"lv": "AI atgrieza tukšu rezultātu.", "en": "AI returned an empty result."},
    "no_api_key": {"lv": "Nav ievadīta API atslēga (Iestatījumi → AI).", "en": "No API key entered (Settings → AI)."},
    "api_error": {"lv": "API kļūda", "en": "API error"},
    "test_ok": {"lv": "Savienojums strādā", "en": "Connection works"},
    "no_date": {
        "lv": "Bildei nav uzņemšanas datuma — aprakstā ieraksti datumu pats.",
        "en": "The photo has no capture date — add the date to the description yourself.",
    },
    "no_place": {
        "lv": "AI nezināja vietu — ieraksti pilsētu un valsti aprakstā vai pastāsti AI sarunā.",
        "en": "AI did not know the place — add city and country to the description or tell the AI in the chat.",
    },
    "codex_missing": {
        "lv": "ChatGPT (Codex) nav atrasts šajā datorā. Skat. Iestatījumi → AI → ChatGPT.",
        "en": "ChatGPT (Codex) was not found on this computer. See Settings → AI → ChatGPT.",
    },
    "codex_not_logged_in": {
        "lv": "ChatGPT nav pieslēgts. Iestatījumos spied 'Pieslēgties ChatGPT kontam'.",
        "en": "ChatGPT is not signed in. In Settings click 'Sign in to ChatGPT'.",
    },
    "codex_timeout": {"lv": "ChatGPT neatbildēja 5 minūšu laikā.", "en": "ChatGPT did not answer within 5 minutes."},
    "no_openai_key": {"lv": "Nav ievadīta OpenAI API atslēga (Iestatījumi → AI).",
                      "en": "No OpenAI API key entered (Settings → AI)."},
    "switched_ai": {"lv": "{a} limits beidzies — turpina ar {b}.", "en": "{a} limit reached — continuing with {b}."},
    "shortened": {"lv": "Teksts bija par garu un tika saīsināts — pārbaudi, vai tas ir pabeigts.",
                  "en": "The text was too long and was shortened — check that it reads complete."},
    "interrupted": {"lv": "Pārtraukts (Vārdotājs tika aizvērts)", "en": "Interrupted (Vārdotājs was closed)"},
    "web_needs_sub": {"lv": "Meklēšana internetā pieejama tikai ar Claude vai ChatGPT abonementu.",
                      "en": "Web search is only available with the Claude or ChatGPT subscription."},
    "et_installed": {"lv": "ExifTool uzstādīts", "en": "ExifTool installed"},
    "et_install_failed": {"lv": "Neizdevās lejupielādēt ExifTool.", "en": "Could not download ExifTool."},
    "downloading": {"lv": "Lejupielādē ExifTool…", "en": "Downloading ExifTool…"},
    "error": {"lv": "Kļūda", "en": "Error"},
    "home_folder": {"lv": "Mājas mape", "en": "Home"},
    "nothing_to_undo": {"lv": "Nav ko atsaukt.", "en": "Nothing to undo."},
    "ready_dir_none": {"lv": "Iestatījumos nav norādīta iesniegšanai gatavo bilžu mape.",
                       "en": "The folder for photos ready to submit is not set in Settings."},
    "spec_fmt": {"lv": "formāts {f} — mērķa aģentūras pieņem tikai {ok}", "en": "format {f} — target agencies accept only {ok}"},
    "spec_min_mp": {"lv": "par mazu: {mp} MP ({ag} prasa vismaz {min} MP)", "en": "too small: {mp} MP ({ag} needs at least {min} MP)"},
    "spec_min_px": {"lv": "par mazu: {px} px ({ag} prasa vismaz {min} px)", "en": "too small: {px} px ({ag} needs at least {min} px)"},
    "spec_min_mb": {"lv": "fails par mazu: {mb} MB ({ag} prasa vismaz {min} MB)", "en": "file too small: {mb} MB ({ag} needs at least {min} MB)"},
    "spec_big_nojpg": {"lv": "par lielu ({mb} MB), un tas nav JPG — saspiest nevar", "en": "too large ({mb} MB) and not a JPG — cannot be compressed"},
    "spec_conflict": {"lv": "mērķa aģentūru prasības savstarpēji neder kopā (min. un maks. izmērs)", "en": "target agency requirements conflict (min. and max. size)"},
    "spec_cant": {"lv": "neizdevās saspiest {mb} MB līdz {max} MB, nesamazinot zem prasītā", "en": "could not compress {mb} MB to {max} MB without going below the required size"},
    "copy_mismatch": {"lv": "kopija nesakrīt ar oriģinālu (izmērs vai kontrolsumma) — oriģināls atstāts vietā",
                      "en": "the copy does not match the original (size or checksum) — the original was left in place"},
    "dest_exists": {"lv": "galamērķī jau ir fails ar šo nosaukumu", "en": "a file with this name already exists at the destination"},
    "ready_dir_missing": {"lv": "Iesniegšanai gatavo bilžu mape nav pieejama: {path}",
                          "en": "The folder for photos ready to submit is not available: {path}"},
    "no_ai_tr": {"lv": "Nav tulkojuma — nav pieslēgts AI.", "en": "No translation — no AI connected."},
}


from .i18n_more import merge as _merge_more   # de / es / uk (test21)
_merge_more(MSG)


def T(key: str, **kw) -> str:
    lang = config.get("lang") or "lv"
    d = MSG.get(key, {})
    s = d.get(lang) or d.get("en") or d.get("lv") or key   # trūkstošs → angļu (noteikumi §6)
    return s.format(**kw) if kw else s


def lang_name() -> str:
    return {"lv": "Latvian", "en": "English", "de": "German", "es": "Spanish", "uk": "Ukrainian"}.get(config.get("lang") or "lv", "Latvian")
