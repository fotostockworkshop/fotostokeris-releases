"""Manifesti un sīktēli (noteikumi: docs/fotostokeris-dati.md §7a "Manifesta formāts un darbība"; 0.9.0-test4).

Viena sērija (= mape ar bildēm) → 2 faili:
  <mape>/_fotostokeris/<sērija>.json         — versija, sērijas ID, katrai bildei teksti, kategorija, statuss, phash …
  <mape>/_fotostokeris/<sērija>-sikteli.zip  — sīktēli ~256 px (<stem>.jpg)
(līdz 2026-11-05 `.fotostokeris/` — to lasa; Synology Drive mapes ar punktu nesinhronizē). Ja pieslēgts Google konts —
arī Drive `Fotostokeris/Manifesti/` (core/manifests_drive.py; dati §7a (c), test11).
un to kopija kopīgajā manifestu mapē (iestatījums "manifest_dir"; tukšs = <iesniegšanai gatavo bilžu mape>/Manifesti,
bez tās — Vārdotāja datu mapē Manifesti/). Vārdotājs datu mapē pieraksta, kur katrs manifests atrodas (manifests.json).

"Dzīvs" manifests: pēc katras saglabāšanas / melnraksta / pārvietošanas mapes manifests atjaunojas fonā (ja tas jau ir
vai ja visas mapes bildes ir gatavas — "sērija pabeigta"). Galvenā atslēga — bilde (stem + phash), ne sērija.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import re
import shutil
import threading
import time
import uuid
import zipfile
from datetime import datetime, timezone

from PIL import Image

from core import manifests_drive

from . import VERSION, ai, config, exif, files, store

FORMAT = 1
SUB = "_fotostokeris"
SUBS = ("_fotostokeris", ".fotostokeris")      # lasa abas, raksta tikai pirmo (lēmums 2026-11-05)
GENERIC = {"jpg", "jpeg", "raw", "edited", "edit", "tif", "tiff", "export", "png", "dng", "heic"}
THUMB = 256

_lock = threading.RLock()
_pending: set[str] = set()
_timer: threading.Timer | None = None
_state: dict[str, dict] = {}            # mape -> {"building": bool, "done": n, "total": n, "error": str}
_index: config.JsonStore | None = None


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _norm(p: str) -> str:
    return os.path.normcase(os.path.abspath(p))


def index() -> config.JsonStore:
    global _index
    if _index is None:
        _index = config.JsonStore(config.app_dir() / "manifests.json", {})
    return _index


# --------------------------------------------------------------------------- vietas

def shared_dir() -> str:
    d = str(config.get("manifest_dir") or "").strip()
    if d:
        return d
    rd = str(config.get("ready_dir") or "").strip()
    if rd and os.path.isdir(rd):
        return os.path.join(rd, "Manifesti")
    return str(config.app_dir() / "Manifesti")


def _sub(folder: str) -> str:
    return os.path.join(folder, SUB)


def _hide(path: str) -> None:
    if config.IS_WIN:
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x2)      # HIDDEN
        except Exception:
            pass


def _safe(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "_", name).strip(" .") or "serija"


def series_name(folder: str) -> str:
    """Mapes nosaukums; RF/ED apakšmapei — "<vecākmape>-RF"."""
    base = os.path.basename(folder.rstrip("\\/"))
    names = {(config.get("sort_rf_name") or "RF").lower(), (config.get("sort_ed_name") or "ED").lower()}
    parent = os.path.basename(os.path.dirname(folder.rstrip("\\/")))
    if base.lower() in names and parent:
        return f"{parent}-{base}"
    if base.lower() in GENERIC and parent:      # "Bali/jpg" → "Bali" (test11; ne sērija "jpg")
        return parent
    return base


def _md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def find(folder: str) -> str | None:
    """Esošā manifesta .json ceļš mapē (vai None); vispirms `_fotostokeris`, tad vecā `.fotostokeris`."""
    for sub in SUBS:
        d = os.path.join(folder, sub)
        try:
            for n in sorted(os.listdir(d)):
                if n.endswith(".json"):
                    return os.path.join(d, n)
        except OSError:
            pass
    return None


def load(folder: str) -> dict | None:
    p = find(folder)
    if not p:
        return None
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, json.JSONDecodeError):
        return None


def _images(folder: str) -> list[str]:
    out = []
    try:
        for e in os.scandir(folder):
            if e.is_file() and not e.name.startswith(".") and os.path.splitext(e.name)[1].lower() in files.IMAGE_EXT:
                out.append(e.path)
    except OSError:
        pass
    return sorted(out, key=str.lower)


# --------------------------------------------------------------------------- bildes dati

def _dhash(im: Image.Image) -> str:
    """dHash 8×8 (16 hex) — tas pats algoritms, ko lieto Analītiķis (noteikumi §8 phash)."""
    g = im.convert("L").resize((9, 8), Image.LANCZOS)
    px = list(g.getdata())
    bits = 0
    for r in range(8):
        for c in range(8):
            bits = (bits << 1) | (1 if px[r * 9 + c] > px[r * 9 + c + 1] else 0)
    return f"{bits:016x}"


def _category(path: str, draft: dict | None, desc: str = "") -> str:
    parent = os.path.basename(os.path.dirname(path)).lower()
    if parent == (config.get("sort_ed_name") or "ED").lower():
        cat = "ED"
    elif parent == (config.get("sort_rf_name") or "RF").lower():
        cat = "RF"
    elif desc and ai.has_ed_prefix(desc):        # aprakstā ED piebilde → ED (test16)
        cat = "ED"
    elif draft and draft.get("cat") in ("RF", "ED"):
        cat = draft["cat"]
    else:
        try:
            cat = "ED" if ai.is_editorial(path) else "RF"
        except Exception:
            cat = "RF"
    if cat == "ED" and draft and draft.get("illustrative"):
        cat = "EDI"
    return cat


def _taken(info: dict) -> str:
    v = str(info.get("date") or "").strip()
    m = re.match(r"(\d{4})[:\-](\d\d)[:\-](\d\d)(?:[ T](\d\d):(\d\d)(?::(\d\d))?)?", v)
    if not m:
        return ""
    y, mo, d, hh, mm, ss = m.groups()
    return f"{y}-{mo}-{d}" + (f"T{hh}:{mm}:{ss or '00'}" if hh else "")


# --------------------------------------------------------------------------- būvēšana

def build(folder: str, moved: dict | None = None, series_id: str | None = None, progress=None,
          series_code: str | None = None, orig: dict | None = None, drive_now: bool = False,
          category: str | None = None, originals: dict | None = None, computer: str = "") -> dict | None:
    """Izveido / atjauno mapes manifestu un sīktēlus. moved: {stem: jaunā mape} — bildes, kas aizgāja no šīs mapes.
    series_code / orig {jaunais stem: oriģinālais faila nosaukums} — "Uz iesniegšanu" pārdēvēšana (test9, dati §7a)."""
    folder = os.path.abspath(folder)
    with _lock:
        imgs = _images(folder)
        old = load(folder) or {}
        old_path = find(folder)
        old_items = {it.get("stem"): it for it in old.get("images") or []}
        if not imgs and not old_items:
            return None
        sid = old.get("series_id") or series_id or uuid.uuid4().hex
        name = series_name(folder)
        sub = _sub(folder)
        os.makedirs(sub, exist_ok=True)
        _hide(sub)
        jpath = os.path.join(sub, _safe(name) + ".json")
        zpath = os.path.join(sub, _safe(name) + "-sikteli.zip")

        # sīktēli: neizmainītās bildes ņem no vecā zip
        old_zip = {}
        oz = old_path[:-5] + "-sikteli.zip" if old_path else None
        if oz and os.path.isfile(oz):
            try:
                with zipfile.ZipFile(oz) as z:
                    for n in z.namelist():
                        old_zip[n] = z.read(n)
            except (OSError, zipfile.BadZipFile):
                old_zip = {}

        meta = exif.read_meta(imgs, info=True) if imgs else {}
        status = exif.read_status(imgs) if imgs else {}
        notes = store.get_photos(imgs)
        items, thumbs = [], {}
        orig = orig or {}
        for i, p in enumerate(imgs):
            stem = os.path.splitext(os.path.basename(p))[0]
            st = os.stat(p)
            sig = f"{st.st_size}:{int(st.st_mtime)}"
            o = old_items.get(stem) or {}
            m = meta.get(p) or {}
            n = notes.get(p) or {}
            draft = n.get("draft")
            s = (status.get(p) or {}).get("status", "none")
            stt = "ready" if s == "full" and not (status.get(p) or {}).get("draft") else ("draft" if (s != "none" or draft) else "none")
            src_title, src_desc, src_kw = m.get("title", ""), m.get("description", ""), m.get("keywords") or []
            if stt == "draft" and draft and not (src_title or src_desc):
                src_title, src_desc, src_kw = draft.get("title", ""), draft.get("description", ""), draft.get("keywords") or []
            tkey = stem + ".jpg"
            ph, w, h = o.get("phash", ""), o.get("width", 0), o.get("height", 0)
            md5 = o.get("md5") if o.get("sig") == sig else ""
            if not md5:
                try:
                    md5 = _md5(p)
                except OSError:
                    md5 = ""
            if o.get("sig") == sig and tkey in old_zip and ph:
                thumbs[tkey] = old_zip[tkey]
            else:
                try:
                    im = files._load_scaled(p, THUMB)
                    buf = io.BytesIO()
                    im.save(buf, "JPEG", quality=80)
                    thumbs[tkey] = buf.getvalue()
                    ph = _dhash(im)
                    with Image.open(p) as full:
                        w, h = full.size
                except Exception:
                    pass
            edp, edl, edd = "", False, ""
            cat = category or _category(p, draft, src_desc)
            if category == "ED" and draft and draft.get("illustrative"):
                cat = "EDI"
            if cat == "RF":       # ED rezerve: tikai vietas un datuma piebilde (dati §7a, test13)
                place = n.get("place", "")
                if not place and n.get("hint"):
                    try:
                        place = ai.ed_place_from_hint(n["hint"])
                    except Exception as e:
                        print("ED vieta no pavediena:", e)
                if place:
                    edp = ai.ed_prefix(place, ai._fmt_date(_taken(m)))[0]
                    lim = int(config.get("ed_description_max") or 200)
                    edl = len(edp) + len(src_desc) > lim
                    if edl:                   # par garu — saīsināts variants ED kopijai (test14)
                        edd = ai.ed_short_description(src_desc, lim - len(edp))
            items.append({
                "stem": stem, "file": os.path.basename(p), "orig_file": orig.get(stem) or o.get("orig_file") or os.path.basename(p),
                "path": p, "status": stt,
                "category": cat, "title": src_title, "description": src_desc,
                "keywords": list(src_kw), "hint": n.get("hint", ""), "taken_at": _taken(m),
                "phash": ph, "width": w, "height": h, "bytes": st.st_size, "md5": md5, "sig": sig,
                **({"country": m["country"]} if m.get("country") else {}), **({"city": m["city"]} if m.get("city") else {}),
                **({"original": (originals or {}).get(stem) or o["original"]} if ((originals or {}).get(stem) or o.get("original")) else {}),
                **({"ed_prefix": edp, "ed_prefix_long": edl} if edp else {}), **({"ed_description": exif.to_english(edd)} if edd else {}), "updated": o.get("updated") if (
                    o.get("title") == src_title and o.get("description") == src_desc and o.get("keywords") == list(src_kw)
                    and o.get("status") == stt) else _now(),
            })
            if progress:
                progress(i + 1, len(imgs))
        # bildes, kas aizgājušas no mapes — paliek ieraksts "pārvietota uz …"
        have = {it["stem"] for it in items}
        moved = moved or {}
        for stem, o in old_items.items():
            if stem in have or not stem:
                continue
            if o.get("status") == "deleted":        # Tirgotājs izdzēsis no NAS — paliek, kā ir (dati §7a (c) 1)
                items.append(dict(o))
            elif stem in moved or o.get("moved_to"):
                rec = dict(o)
                rec["status"] = "moved"
                rec["moved_to"] = moved.get(stem) or o.get("moved_to")
                rec["updated"] = _now() if stem in moved else o.get("updated")
                items.append(rec)
        data = {"format": FORMAT, "kind": "series", "app": f"Vardotajs {VERSION}", "series_id": sid, "name": name, "folder": folder,
                **({"series_code": series_code or old.get("series_code")} if (series_code or old.get("series_code")) else {}),
                **({"computer": computer or old.get("computer")} if (computer or old.get("computer")) else {}),
                "created": old.get("created") or _now(), "updated": _now(),
                "count": sum(1 for it in items if it["status"] not in ("moved", "deleted")),
                "ready": sum(1 for it in items if it["status"] == "ready"),
                "thumbs": os.path.basename(zpath), "images": items}

        tmp = jpath + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, jpath)
        ztmp = zpath + ".tmp"
        with zipfile.ZipFile(ztmp, "w", zipfile.ZIP_STORED) as z:
            for k, v in thumbs.items():
                z.writestr(k, v)
        os.replace(ztmp, zpath)
        if old_path and _norm(old_path) != _norm(jpath):          # mape pārsaukta / vecā .fotostokeris — vecie faili prom
            for f in (old_path, oz):
                try:
                    if f and os.path.isfile(f):
                        os.remove(f)
                except OSError:
                    pass
            if _norm(os.path.dirname(old_path)) != _norm(sub):
                try:
                    os.rmdir(os.path.dirname(old_path))
                except OSError:
                    pass
        try:     # vienkāršotā kārtība (2026-11-11 22:33): tikai Google `Sutijumi`, bez apvienošanas; NAS `Manifesti/` vairs nav
            manifests_drive.queue(f"{_safe(name)}__{sid[:8]}", jpath, zpath, "plain", now=drive_now,
                                  folder=manifests_drive.SUTIJUMI)
        except Exception as e:
            print("manifests Drive rinda:", e)
        st = index()
        with st.lock:
            st.data[sid] = {"folder": folder, "name": name, "json": jpath, "updated": data["updated"],
                            "count": data["count"], "ready": data["ready"]}
            st.save()
        return {"json": jpath, "zip": zpath, "count": data["count"], "ready": data["ready"], "name": name,
                "series_id": sid}


def _copy_shared(data: dict, jpath: str, zpath: str) -> None:
    d = shared_dir()
    try:
        os.makedirs(d, exist_ok=True)
        base = f"{_safe(data['name'])}__{data['series_id'][:8]}"
        # ja sērija pārsaukta — vecā kopija ar to pašu ID prom
        for n in os.listdir(d):
            if f"__{data['series_id'][:8]}" in n and not n.startswith(base):
                try:
                    os.remove(os.path.join(d, n))
                except OSError:
                    pass
        for src, dst in ((jpath, base + ".json"), (zpath, base + "-sikteli.zip")):
            tmp = os.path.join(d, dst + ".tmp")
            shutil.copyfile(src, tmp)
            os.replace(tmp, os.path.join(d, dst))
    except OSError as e:
        print("manifesta kopija:", d, e)


def mark_moved_drive(folder: str, moved: dict, dest_sid: str = "") -> None:
    """"Uz iesniegšanu" iztukšoja darba mapi un bildes nonāca CITĀ sērijā (cits ID): darba mapes manifestu Google Drive
    atzīmē kā pārvietotu (status "moved" + moved_to), lai Analītiķis bildes neskaita divreiz (test15)."""
    m = load(folder)
    sid = (m or {}).get("series_id") or ""
    if not m or not sid or sid == dest_sid:
        return
    for it in m.get("images") or []:
        if it.get("status") not in ("moved", "deleted"):
            it["status"] = "moved"
            it["moved_to"] = moved.get(it.get("stem")) or it.get("moved_to") or ""
            it["updated"] = _now()
    m["count"], m["ready"], m["updated"] = 0, 0, _now()
    tmp = os.path.join(str(config.app_dir()), f"moved-{sid[:8]}.json")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=1)
    p = find(folder)
    z = p[:-5] + "-sikteli.zip" if p else ""
    manifests_drive.queue(f"{_safe(m.get('name') or series_name(folder))}__{sid[:8]}", tmp,
                          z if z and os.path.isfile(z) else None, "vardotajs", now=True)
    try:
        os.remove(tmp)                         # rindā jau ir kopija
    except OSError:
        pass


def remove(folder: str) -> None:
    """Mape kļuvusi tukša (visas bildes pārvietotas) — vietējie faili prom, ieraksts sarakstā paliek ar jauno vietu."""
    p = find(folder)
    if not p:
        return
    for f in (p, p[:-5] + "-sikteli.zip"):
        try:
            os.remove(f)
        except OSError:
            pass
    try:
        os.rmdir(os.path.dirname(p))
    except OSError:
        pass


# --------------------------------------------------------------------------- "dzīvs" manifests (fonā)

def _all_ready(folder: str) -> bool:
    imgs = _images(folder)
    if not imgs:
        return False
    st = exif.read_status(imgs)
    return all((st.get(p) or {}).get("status") == "full" and not (st.get(p) or {}).get("draft") for p in imgs)


def touch(paths) -> None:
    """Agrāk "dzīvais" manifests pēc katras izmaiņas — vienkāršotajā kārtībā (2026-11-11 22:33) vairs nav:
    manifestu raksta tikai "Uz iesniegšanu"."""
    return None


def _flush() -> None:
    with _lock:
        todo = list(_pending)
        _pending.clear()
    for folder in todo:
        try:
            if find(folder) or _all_ready(folder):
                build(folder)
        except Exception as e:
            print("manifests:", folder, e)


def folders_for(folder: str) -> list[str]:
    """Mape ar bildēm → tā pati; sērijas mape bez bildēm → apakšmapes (piem. RF un ED), kurās ir bildes."""
    if _images(folder):
        return [folder]
    out = []
    try:
        for e in sorted(os.scandir(folder), key=lambda e: e.name.lower()):
            if e.is_dir() and not e.name.startswith(".") and e.name not in SUBS and _images(e.path):
                out.append(e.path)
    except OSError:
        pass
    return out


def make_async(folder: str) -> dict:
    """Poga "Manifests": izveido / atjauno fonā (arī vecām, jau aprakstītām mapēm)."""
    targets = folders_for(folder)
    if not targets:
        return {"count": 0}
    key = _norm(folder)
    if (_state.get(key) or {}).get("building"):
        return {"count": len(targets), "busy": True}
    _state[key] = {"building": True, "done": 0, "total": 0, "error": "", "made": []}

    def run():
        s = _state[key]
        try:
            s["total"] = sum(len(_images(t)) for t in targets)
            base = 0
            for t in targets:
                n = len(_images(t))
                r = build(t, progress=lambda i, _n, b=base: s.update(done=b + i), drive_now=True)
                base += n
                if r:
                    s["made"].append({"name": r["name"], "count": r["count"], "ready": r["ready"], "folder": t})
        except Exception as e:
            s["error"] = str(e)
            print("manifests:", folder, e)
        finally:
            s["building"] = False

    threading.Thread(target=run, daemon=True).start()
    return {"count": len(targets)}


def info(folder: str) -> dict:
    s = _state.get(_norm(folder)) or {}
    out = []
    for t in folders_for(folder) or [folder]:
        d = load(t)
        if d:
            out.append({"folder": t, "name": d.get("name"), "updated": d.get("updated"), "count": d.get("count", 0),
                        "ready": d.get("ready", 0)})
    return {"manifests": out, "building": bool(s.get("building")), "done": s.get("done", 0), "total": s.get("total", 0),
            "error": s.get("error", ""), "made": s.get("made", []), "shared": shared_dir(),
            "drive": manifests_drive.status() if manifests_drive.enabled() else None}


# --------------------------------------------------------------------------- dati "Uz iesniegšanu" plānam (test18)

def scan(paths: list[str]) -> dict:
    """Bilžu dati bez manifesta rakstīšanas: {ceļš: {stem, status, category, description, phash, taken_at}}.
    status: ready (pilni metadati failā) | draft | none."""
    paths = [p for p in paths if os.path.isfile(p)]
    if not paths:
        return {}
    meta = exif.read_meta(paths, info=True)
    status = exif.read_status(paths)
    notes = store.get_photos(paths)
    out = {}
    for p in paths:
        m, n, sx = meta.get(p) or {}, notes.get(p) or {}, status.get(p) or {}
        draft = n.get("draft")
        s = sx.get("status", "none")
        stt = "ready" if s == "full" and not sx.get("draft") else ("draft" if (s != "none" or draft) else "none")
        desc = m.get("description", "")
        ph = ""
        try:
            ph = _dhash(files._load_scaled(p, THUMB))
        except Exception:
            pass
        out[p] = {"stem": os.path.splitext(os.path.basename(p))[0], "status": stt,
                  "category": _category(p, draft, desc) if stt == "ready" else "", "description": desc,
                  "phash": ph, "taken_at": _taken(m)}
    return out


# --------------------------------------------------------------------------- vienreizēja pāreja (test18)

def migrate() -> dict:
    """Vienreiz katrā datorā (lēmums 2026-11-11 22:33, pāreja p.16): (1) NAS sūtījumu manifesti (<ready_dir>/<GADS>/…,
    arī RF/ED apakšmapes) → Google `Sutijumi`; (2) darba mapju manifesti — prom (darba mapēs pēc saraksta, NAS
    `Manifesti/`, Google `Manifesti/` — tikai Vārdotāja sērijas bez `series_code`); (3) NAS `Manifesti/` mapi dzēš.
    Google `Manifesti/` mapi NEdzēš (to dara Analītiķis pēdējais). Atzīme `manifest_migrated`."""
    if config.get("manifest_migrated"):
        return {}
    res = {"sent": 0, "removed": 0, "drive_removed": 0, "errors": []}
    root = str(config.get("ready_dir") or "").strip()
    rootn = _norm(root) + os.sep if root else None
    # (1) NAS sūtījumi
    if root and os.path.isdir(root):
        for y in sorted(os.listdir(root)):
            yp = os.path.join(root, y)
            if not (re.match(r"^\d{4}$", y) and os.path.isdir(yp)):
                continue
            for sname in sorted(os.listdir(yp)):
                d = os.path.join(yp, sname)
                for f in [d] + [os.path.join(d, k) for k in (config.get("sort_rf_name") or "RF", config.get("sort_ed_name") or "ED")]:
                    j = find(f)
                    if not j:
                        continue
                    try:
                        m = json.load(open(j, encoding="utf-8"))
                        z = j[:-5] + "-sikteli.zip"
                        manifests_drive.queue(f"{_safe(m.get('name') or series_name(f))}__{str(m.get('series_id'))[:8]}",
                                              j, z if os.path.isfile(z) else None, "plain", now=True,
                                              folder=manifests_drive.SUTIJUMI)
                        res["sent"] += 1
                    except Exception as e:
                        res["errors"].append(f"{sname}: {e}")
    # (2) darba mapju manifesti šajā datorā
    for sid, e in list(index().data.items()):
        fo = (e or {}).get("folder") or ""
        if not fo or (rootn and (_norm(fo) + os.sep).startswith(rootn)):
            continue
        if find(fo):
            remove(fo)
            res["removed"] += 1
    # (3) NAS Manifesti/ (vecā kopīgā mape)
    sd = str(config.get("manifest_dir") or "").strip() or (os.path.join(root, "Manifesti") if root else "")
    if sd and os.path.isdir(sd):
        import shutil
        try:
            shutil.rmtree(sd)
        except OSError as e:
            res["errors"].append(f"Manifesti: {e}")
    # Google `Manifesti/`: Vārdotāja darba mapju manifesti (sērija bez series_code)
    if manifests_drive.enabled():
        try:
            res["drive_removed"] = manifests_drive.delete_where(
                manifests_drive.DIR, lambda d: (d.get("kind") or "series") == "series" and not d.get("series_code"))
        except Exception as e:
            res["errors"].append(f"Google Manifesti: {e}")
    if not res["errors"] or res["sent"] or res["removed"]:
        config.update({"manifest_migrated": _now()})
    print("Manifestu pāreja:", res)
    return res
