"""AI: metadatu ģenerēšana, saruna ar AI, RF/ED klasifikācija un Claude konta pieslēgšana.

Divi veidi:
  * claude_cli — izmanto lietotāja Claude abonementu caur Claude Code komandrindu (`claude -p`).
                 Papildu maksas nav, tiek tērēti abonementa lietošanas limiti.
  * api        — Anthropic API ar atslēgu (maksā par katru pieprasījumu).
"""
from __future__ import annotations

import base64
import datetime as dt
import glob
import json
import os
import re
import shlex
import shutil
import subprocess
import tempfile
import threading
import time
import urllib.request
from pathlib import Path

from . import config, exif, files, store
from .i18n import T, lang_name
from .store import clean_keywords

IS_WIN = config.IS_WIN
NO_WINDOW = 0x08000000 if IS_WIN else 0
NEW_CONSOLE = 0x00000010 if IS_WIN else 0

API_MODELS = {"sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5", "haiku": "claude-haiku-5-5"}

BANNED_KW = {"editorial", "illustrative", "photo", "image", "picture", "stock", "photography"}

GEN_SCHEMA = {
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "description": {"type": "string"},
        "keywords": {"type": "array", "items": {"type": "string"}},
        "place": {"type": "string"},
        "date": {"type": "string"},
        "risk": {"type": "string"},
    },
    "required": ["title", "description", "keywords", "place", "date", "risk"],
}

def gen_schema() -> dict:
    sc = json.loads(json.dumps(GEN_SCHEMA))
    sc["properties"]["title_lv"] = {"type": "string"}
    sc["properties"]["description_lv"] = {"type": "string"}
    sc["required"] += ["title_lv", "description_lv"]
    return sc


CHAT_SCHEMA = {
    "type": "object",
    "properties": {
        "reply": {"type": "string"},
        "remember": {"type": "string"},
        "remember_scope": {"type": "string", "enum": ["photos", "folder"]},
        "update": {"type": "boolean"},
        "title": {"type": "string"},
        "description": {"type": "string"},
        "keywords": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["reply", "remember", "remember_scope", "update", "title", "description", "keywords"],
}

CLASSIFY_SCHEMA = {
    "type": "object",
    "properties": {
        "category": {"type": "string", "enum": ["RF", "ED", "UNSURE"]},
        "reason": {"type": "string"},
        "hint": {"type": "string"},
        "hint_confidence": {"type": "string", "enum": ["sure", "maybe", "none"]},
        "flags": {"type": "array", "items": {"type": "string", "enum": [
            "people", "brand", "zoo", "museum", "paid_venue", "event", "restricted_place", "artwork"]}},
        "advice": {"type": "string"},
    },
    "required": ["category", "reason", "hint", "hint_confidence", "flags", "advice"],
}


class AIError(Exception):
    pass


# --------------------------------------------------------------------------- Claude Code atrašana

def _claude_candidates() -> list[str]:
    home = Path.home()
    c = []
    custom = (config.get("claude_path") or "").strip().strip('"')
    if custom:
        c.append(custom)
    w = shutil.which("claude")
    if w:
        c.append(w)
    if IS_WIN:
        appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
        local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        c += [str(home / ".local" / "bin" / "claude.exe"),
              str(home / ".claude" / "local" / "claude.exe"),
              os.path.join(local, "Programs", "claude", "claude.exe"),
              os.path.join(local, "Microsoft", "WinGet", "Links", "claude.exe"),
              os.path.join(appdata, "npm", "claude.cmd")]
    else:
        c += [str(home / ".local" / "bin" / "claude"),
              str(home / ".claude" / "local" / "claude"),
              "/opt/homebrew/bin/claude", "/usr/local/bin/claude",
              str(home / ".npm-global" / "bin" / "claude")]
        c += sorted(glob.glob(str(home / ".nvm" / "versions" / "node" / "*" / "bin" / "claude")), reverse=True)
    return c


def find_claude() -> list[str] | None:
    """Komanda Claude Code palaišanai (saraksts) vai None."""
    for p in _claude_candidates():
        if p and os.path.isfile(p):
            if IS_WIN and p.lower().endswith((".cmd", ".bat")):
                # npm instalācija: palaižam node + cli.js tieši, lai izvairītos no cmd.exe pēdiņu problēmām
                base = os.path.dirname(p)
                cli = os.path.join(base, "node_modules", "@anthropic-ai", "claude-code", "cli.js")
                node = os.path.join(base, "node.exe")
                node = node if os.path.isfile(node) else shutil.which("node")
                if os.path.isfile(cli) and node:
                    return [node, cli]
                continue
            return [p]
    return None


_help_cache: dict[str, str] = {}
_help_lock = threading.Lock()


def _env() -> dict:
    env = dict(os.environ)
    # Ja datorā ir iestatīta API atslēga, Claude Code to izmantotu abonementa vietā — noņemam.
    for k in ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN"):
        env.pop(k, None)
    env.setdefault("CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC", "1")
    # GUI lietotnēm (īpaši macOS) PATH bieži ir īss — pievienojam tipiskās vietas
    extra = [str(Path.home() / ".local" / "bin"), "/opt/homebrew/bin", "/usr/local/bin"]
    env["PATH"] = os.pathsep.join([env.get("PATH", "")] + extra)
    return env


def _help_text(cmd: list[str]) -> str:
    key = "|".join(cmd)
    with _help_lock:
        if key not in _help_cache:
            try:
                r = subprocess.run(cmd + ["--help"], capture_output=True, timeout=60, env=_env(),
                                   creationflags=NO_WINDOW)
                _help_cache[key] = (r.stdout + r.stderr).decode("utf-8", "replace")
            except Exception:
                _help_cache[key] = ""
        return _help_cache[key]


def claude_info() -> dict:
    cmd = find_claude()
    if not cmd:
        return {"found": False}
    try:
        r = subprocess.run(cmd + ["--version"], capture_output=True, timeout=60, env=_env(),
                           creationflags=NO_WINDOW)
        ver = r.stdout.decode("utf-8", "replace").strip()
    except Exception as e:
        ver = f"{T('error')}: {e}"
    return {"found": True, "path": cmd[-1], "version": ver}


# --------------------------------------------------------------------------- konta pieslēgšana

def auth_status() -> dict:
    """{'found': bool, 'loggedIn': bool, 'email': ..., ...} no `claude auth status --json`."""
    cmd = find_claude()
    if not cmd:
        return {"found": False, "loggedIn": False}
    try:
        r = subprocess.run(cmd + ["auth", "status", "--json"], capture_output=True, timeout=60,
                           env=_env(), creationflags=NO_WINDOW)
        out = r.stdout.decode("utf-8", "replace").strip()
        m = re.search(r"\{.*\}", out, re.S)
        d = json.loads(m.group(0)) if m else {}
    except Exception as e:
        return {"found": True, "loggedIn": False, "error": str(e)}
    d["found"] = True
    d["loggedIn"] = bool(d.get("loggedIn"))
    # dažādās versijās lauki var saukties citādi — paņemam, kas ir
    acc = d.get("account") if isinstance(d.get("account"), dict) else {}
    d["email"] = d.get("email") or d.get("emailAddress") or acc.get("email") or acc.get("emailAddress") or ""
    d["plan"] = d.get("subscriptionType") or d.get("plan") or acc.get("subscriptionType") or ""
    d["org"] = d.get("orgName") or d.get("organizationName") or acc.get("organizationName") or ""
    return d


def login() -> dict:
    """Pieslēgšanās Claude abonementam — kopīgais core.ai.connect (Mac: .command + open, bez AppleScript, tāpēc
    macOS neprasa "control Terminal" atļauju; teksti programmas valodā). Ja Claude Code nav — to arī uzstāda."""
    from core import ai as cai
    try:
        return cai.connect("claude_sub")
    except cai.AIError as e:
        raise AIError(str(e))


def install_claude() -> dict:
    return login()


def logout() -> None:
    cmd = find_claude()
    if not cmd:
        raise AIError(T("claude_missing"))
    subprocess.run(cmd + ["auth", "logout"], capture_output=True, timeout=60, env=_env(), creationflags=NO_WINDOW)


# --------------------------------------------------------------------------- palīgi

def _fmt_date(raw: str) -> str:
    if not raw:
        return ""
    m = re.match(r"(\d{4})[:\-](\d{2})[:\-](\d{2})", raw)
    if not m:
        return ""
    try:
        d = dt.date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        months = ["January", "February", "March", "April", "May", "June", "July", "August",
                  "September", "October", "November", "December"]
        return f"{months[d.month - 1]} {d.day} {d.year}"     # bez komata (Depositphotos; lietotājs 2026-11-12)
    except ValueError:
        return ""


def _folder_parts(path: str) -> list[str]:
    return [p.lower() for p in re.split(r"[\\/]", os.path.dirname(path)) if p]


def is_editorial(path: str) -> bool:
    parts = _folder_parts(path)
    word = (config.get("editorial_word") or "").strip().lower()
    ed_name = (config.get("sort_ed_name") or "").strip().lower()
    if word and any(word in p for p in parts):
        return True
    return bool(ed_name) and ed_name in parts


STOP_END = {"a", "an", "the", "of", "and", "or", "with", "without", "under", "over", "in", "on", "at", "to", "for",
            "from", "by", "near", "between", "behind", "beside", "into", "onto", "its", "their", "his", "her", "while",
            "as", "that", "which", "who", "whose", "is", "are", "was", "were", "being", "has", "have", "some", "one",
            "two", "several", "many", "very", "more", "most", "against", "along", "across", "through", "toward",
            "towards", "around", "amid", "among", "during", "after", "before", "where", "when", "than", "both", "each",
            "this", "these", "those", "next", "past", "up", "down", "off", "out", "&"}


def _strip_tail(s: str) -> str:
    s = s.rstrip(" ,;:-–—(")
    while True:
        words = s.split(" ")
        if len(words) > 3 and words[-1].lower().strip(",;:") in STOP_END:
            s = " ".join(words[:-1]).rstrip(" ,;:-–—(")
        else:
            return s


def _trim(s: str, maxlen: int) -> str:
    """Rezerves saīsināšana (ja AI pats nav ievērojis garumu): griež pie teikuma vai teikuma daļas robežas,
    nekad nebeidz ar palīgvārdu (a, the, under…)."""
    s = " ".join((s or "").split())
    if len(s) <= maxlen:
        return s
    end_dot = s.endswith(".")
    room = maxlen - (1 if end_dot else 0)
    cut = s[:room + 1]
    cut = cut[:cut.rfind(" ")] if " " in cut else cut[:room]
    best = ""
    for m in re.finditer(r"[.;!?](?=\s)|,(?=\s)|\s(?=(?:and|with|while|as|where|near|under|beside|behind|against|"
                         r"along|during|in front of|surrounded by)\s)", cut):
        if m.start() >= room * 0.55:
            best = cut[:m.start()]
    out = _strip_tail(best or cut)
    if end_dot and not out.endswith((".", "!", "?")):
        out += "."
    return out


# vārdi, ar kuriem pabeigts teikums praktiski nevar beigties (bez punkta beigās)
CUT_END = {"a", "an", "the", "of", "and", "or", "with", "without", "under", "in", "on", "at", "to", "for", "from",
           "by", "near", "between", "into", "onto", "its", "their", "his", "her", "while", "as", "that", "which",
           "who", "whose", "is", "are", "was", "were", "has", "have", "very", "against", "along", "across",
           "through", "toward", "towards", "amid", "among", "during", "than", "&"}


def looks_cut(s: str, limit: int | None = None) -> bool:
    """Vai teksts izskatās nogriezts pusteikumā. Teksts ar punktu (. ! ?) beigās skaitās pabeigts.
    Bez punkta: aizdomīgs, ja beidzas ar palīgvārdu vai ja tas ir gandrīz limita garumā (vecās versijas
    griezta tieši pie limita, piem. '…at a pond with a tiered')."""
    s = (s or "").strip()
    if not s or s[-1] in ".!?\"'”)":
        return False
    if s[-1] in ",;:-–(":
        return True
    if s.split(" ")[-1].lower() in CUT_END:
        return True
    return bool(limit) and len(s) >= limit - 12


def finish_keywords(kws) -> list[str]:
    if isinstance(kws, str):
        kws = kws.split(",")
    out = []
    for k in kws or []:
        k = str(k).strip().lower()
        parts = re.split(r"\s+", k) if config.get("single_word_keywords") else [k]
        for p in parts:
            p = p.strip(" .,;:!?\"'()[]")
            if p and p not in BANNED_KW:
                out.append(p)
    n = int(config.get("keywords_count") or 45)
    return clean_keywords(out)[:max(n, 1)]


def _facts(path: str | None, meta: dict | None, extra_note: str = "") -> list[str]:
    """Zināmie fakti prioritātes secībā: vispirms par šo bildi, tad mapes piezīmes, tad mapes nosaukums utt."""
    facts = []
    if path:
        ins = store.instructions_for(path)
        if ins["generic"]:
            facts.append(GENERIC_RULE)
        if ins["texts"]:
            facts.append("PHOTOGRAPHER'S INSTRUCTIONS for this photo (highest priority — follow them exactly, they "
                         "override everything else): " + " | ".join(ins["texts"]))
    ph = store.get_photo(path) if path else {"text": "", "hint": "", "ok": False}
    if ph["hint"] and ph["ok"]:
        facts.append("PLACE/SUBJECT CONFIRMED BY THE PHOTOGRAPHER FOR THIS PHOTO (highest priority — it overrides folder "
                     f"names, folder notes, GPS, existing metadata and other photos): {ph['hint']}. Use this landmark's "
                     "real location for 'place' and in the text (its town/regency/region and country), even if the "
                     "location is not written here.")
    if extra_note.strip():
        facts.append(f"Photographer's note for this photo (trust it): {extra_note.strip()}")
    if ph["text"]:
        facts.append("What the photographer told us about THIS photo (trust it): " + ph["text"].replace("\n", "; "))
    if ph["hint"] and not ph["ok"]:
        facts.append(f"Earlier AI guess about the place/subject (verify visually, use only if it fits): {ph['hint']}")
    pr = store.get_place_rules(ph["hint"]) if ph["hint"] else None
    if pr and pr.get("source") == "web":
        facts.append(f"VERIFIED photography rules at this place (checked on the web): {pr['rules']}")
    notes = store.notes_text_for(path) if path else ""
    if notes:
        facts.append("What the photographer told us about this shoot/folder (trust it, unless a fact about THIS photo "
                     "above says otherwise):\n  " + notes.replace("\n", "\n  "))
    if path:
        folders = [p for p in re.split(r"[\\/]", os.path.dirname(path)) if p and not p.endswith(":")][-4:]
        facts.append(f"File name: {os.path.basename(path)}")
        facts.append(f"Folder path (may hint at place or topic; lower priority than the facts above): {' / '.join(folders)}")
    if meta:
        date = _fmt_date(meta.get("date", ""))
        if date:
            facts.append(f"Date taken (from camera): {date}")
        if meta.get("gps") and config.get("send_gps"):
            try:
                facts.append(f"GPS: {float(meta['gps'][0]):.5f}, {float(meta['gps'][1]):.5f}")
            except (TypeError, ValueError):
                pass
    return facts


GENERIC_RULE = ("PHOTOGRAPHER'S INSTRUCTION (highest priority): describe this photo GENERICALLY. Do NOT identify or "
                "name any brand, make, model, manufacturer or company (of a car, vehicle, device, product or shop) even "
                "if you recognize it — not in the hint, title, description or keywords. Describe only what is "
                "visible in generic words (e.g. 'car interior with leather seats and steering wheel'). Use the "
                "'brand' risk flag only if a logo or brand name is actually clearly readable in the photo.")


PRIORITY_RULE = ("- Priority of facts when they disagree: place confirmed by the photographer > photographer's notes about "
                 "this photo > folder notes > folder names > GPS > existing metadata > other photos of the series > your "
                 "own guess. Existing metadata and other photos may be wrong or about a different place.")


def _norm(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (s or "").lower()).strip()


def sibling_texts(path: str, limit: int = 25) -> list[dict]:
    """Citu bilžu (tajā pašā mapē, tuvākās pēc nosaukuma) esošie virsraksti un apraksti."""
    folder = os.path.dirname(path)
    try:
        names = sorted(n for n in os.listdir(folder)
                       if os.path.splitext(n)[1].lower() in files.IMAGE_EXT)
    except OSError:
        return []
    me = os.path.basename(path)
    idx = names.index(me) if me in names else 0
    near = sorted((n for n in names if n != me), key=lambda n: abs(names.index(n) - idx))[:limit]
    if not near:
        return []
    try:
        meta = exif.read_meta([os.path.join(folder, n) for n in near])
    except Exception:
        return []
    return [{"title": m["title"], "description": m["description"]} for m in meta.values() if m.get("title")]


AGENCY_NOTES = {
    "adobe": ("Adobe Stock: commercial (RF) needs model/property releases for recognizable people, ticketed sites "
              "(museums, amusement parks, palaces), venues with photo policies (stadiums, concert halls), zoo and famous "
              "animals, buildings < ~120 years old, modern murals/sculptures/artworks, distinctive vehicles; never brand "
              "names, event names, people names or dates in RF titles/keywords. Adobe does NOT accept documentary "
              "editorial from individual contributors — only 'illustrative editorial' (brands/products/storefronts in "
              "real settings) and it must have NO recognizable people and NOT come from restricted events "
              "(conventions/expos/trade shows, sports games, fashion shows, premieres, political events)."),
    "shutterstock": ("Shutterstock: RF must have no visible trademarks and no brand/business names in title or "
                     "keywords. Documentary editorial is accepted with caption 'CITY, COUNTRY – MONTH DAY YEAR: ...' "
                     "and the event name; press credentials needed for concerts, theatre, private/ticketed sports "
                     "(motocross, horse races), red carpets, runway shows; NOT needed for auto shows, trade shows, "
                     "conventions, ticketed festivals, public sports. Not accepted at all: Oscars, Grammys, Golden "
                     "Globes, Emmys, Tonys, SAG, Cannes/Venice/Toronto/Sundance film festivals, NY/London/Milan/Paris "
                     "fashion weeks, Met Gala, US Open tennis, Wimbledon, FIFA World Cup. Restricted places include "
                     "Atomium, Uluru, British royal residences, Burning Man, Casa Mila and Sagrada Familia interiors, "
                     "Top of the Rock, World Trade Center/9-11 Memorial."),
    "istock": ("iStock/Getty: editorial is mainly for photojournalists; captions must state who/what/where/when; "
               "creative (RF) must have no logos/brands and needs releases; trade/auto show editorial is often "
               "rejected."),
}


def agency_text() -> str:
    targets = config.get("target_agencies") or ["adobe", "shutterstock", "istock"]
    parts = [AGENCY_NOTES[a] for a in targets if a in AGENCY_NOTES]
    mine = (config.get("my_rules") or "").strip()
    if mine:
        parts.append("Photographer's own experience (trust it): " + mine)
    return "\n".join("- " + p for p in parts)


def _rules(editorial: bool, illustrative: bool = False) -> str:
    n = int(config.get("keywords_count") or 45)
    tmax = int(config.get("title_max") or 150)
    dmax = int(config.get("description_max") or 140)
    style = (config.get("style") or "").strip()
    single = ("Each keyword must be ONE single word (no phrases)."
              if config.get("single_word_keywords") else "Keywords may be short phrases.")
    ed = ""
    if editorial and config.get("editorial_format"):
        edmax = int(config.get("ed_description_max") or 200)
        ed = (f"\nThis is an EDITORIAL photo. The final DESCRIPTION will be built by the app as "
              f"'CITY, COUNTRY – MONTH DAY YEAR: <your description sentence>' and must fit in {edmax} characters "
              f"in total, so your description sentence must be at most {edmax - 45} characters (this overrides the "
              f"description limit above). The TITLE is a plain factual sentence WITHOUT the place-date prefix. "
              f"Be strictly factual and neutral: who/what is in the image and what is happening, no promotional "
              f"words. Return 'place' as 'City, Country' (the most specific known town/village/city and the "
              f"country), and 'date' as 'Month Day Year' only if the photographer told it and the camera "
              f"date is missing (otherwise ''). Neither title nor description may contain the place-date prefix.")
    elif editorial:
        ed = "\nThis is an EDITORIAL photo: be strictly factual and neutral."
    if editorial and illustrative:
        ed += ("\nThis is ILLUSTRATIVE EDITORIAL (Adobe Stock style): the subject is a brand, product, vehicle or business "
               "in a real setting. Start the TITLE with the exact brand and model / company name and what it is "
               "(e.g. 'Toyota Land Cruiser 300 SUV parked on a city street', 'Shell gas station with fuel pumps'). "
               "The FIRST keywords must be the brand, model, company name and product type, then other words that "
               "increase recognition (logo, car, dealership, fuel station...). Brand and model names are allowed and "
               "wanted here. Recognizable people are not allowed in illustrative editorial — if any are visible, "
               "say so in 'risk'.")
        comm = ""
    elif editorial:
        comm = ("\n- Editorial: write the full truth — place, event name (if known), brands that are relevant to the "
                "story are allowed.")
    else:
        comm = ("\n- This is COMMERCIAL (royalty-free): never write brand, company, product-model, event or venue "
                "names, people's names or dates. Describe the subject generically.")
    return f"""Limits (count the characters yourself before answering; texts are NEVER cut by the app, so every text must
be complete, natural and fit the limit — aim for about 85% of the limit):
- "title": at most {tmax} characters.
- "description": at most {dmax} characters, worded differently from the title.
- "keywords": exactly {n} keywords if the image allows (never fewer than {max(10, n - 15)}). {single}
  The first 10 are the most important for search and sales.

Style guide from the photographer:
{style}

Rules:
- Use place names only when supported by the photographer's notes, folder names, GPS or a clearly recognizable landmark. Otherwise stay generic.
{PRIORITY_RULE}
- No people's names, no camera/technical words, no words like "photo", "image", "stock", "picture", "editorial", "illustrative".
- Title, description and keywords use ONLY plain English letters (A–Z) — no diacritics or local letters, even if the
  notes or hints write them so: "Rīga" → "Riga", "Kraków" → "Krakow", "Malmö" → "Malmo".
- Describe only what is actually visible or known. Do not add context that is not in the frame (for example, do not
  call an animal 'captive' or add 'zoo' unless a zoo/enclosure is visible or the photographer said so), and never
  invent or hide facts.{comm}{ed}

Stock agency rules to respect (target agencies):
{agency_text()}
If something in the photo is likely to cause rejection under these rules (visible logo in a commercial photo,
recognizable people without release, zoo enclosure, museum interior, ticketed venue, restricted event or place,
artwork), explain it briefly in "risk" in {lang_name()} (else "")."""


# --------------------------------------------------------------------------- izsaukumi

def _parse_json_text(text: str) -> dict:
    text = text.strip()
    try:
        d = json.loads(text)
        if isinstance(d, dict):
            return d
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    raise AIError(T("bad_json") + text[:300])


def _run_cli(prompt: str, workdir: str, schema: dict, has_image: bool, model: str,
             extra_tools: list[str] | None = None) -> dict:
    cmd = find_claude()
    if not cmd:
        raise AIError(T("claude_missing"))
    helptext = _help_text(cmd)
    args = cmd + ["-p", "--output-format", "json", "--model", model]
    if "--system-prompt" in helptext:
        args += ["--system-prompt",
                 "You are an expert assistant for stock photographers. You look at the photo file "
                 "you are given (if any) and answer with JSON only."]
    if "--json-schema" in helptext:
        args += ["--json-schema", json.dumps(schema)]
    if "--no-session-persistence" in helptext:
        args += ["--no-session-persistence"]
    tools = (["Read"] if has_image else []) + list(extra_tools or [])
    if re.search(r"--tools\b", helptext):
        args += ["--tools", ",".join(tools)]
    if tools:
        args += ["--allowedTools", ",".join(tools)]
    try:
        r = subprocess.run(args, input=prompt.encode("utf-8"), capture_output=True, cwd=workdir,
                           timeout=300, env=_env(), creationflags=NO_WINDOW)
    except subprocess.TimeoutExpired:
        raise AIError(T("claude_timeout"))
    out = r.stdout.decode("utf-8", "replace").strip()
    err = r.stderr.decode("utf-8", "replace").strip()
    data = None
    for chunk in [out] + out.splitlines()[::-1]:
        chunk = chunk.strip()
        if chunk.startswith("{"):
            try:
                data = json.loads(chunk)
                break
            except json.JSONDecodeError:
                continue
    if data is None:
        msg = (out or err or f"exit {r.returncode}")[:500]
        if "login" in msg.lower() or "authenticat" in msg.lower():
            msg = T("not_logged_in") + " (" + msg + ")"
        raise AIError(msg)
    if data.get("is_error"):
        msg = str(data.get("result") or data.get("subtype") or T("error"))
        low = msg.lower()
        if "limit" in low:
            msg = T("limit") + " " + msg
        elif "login" in low or "authenticat" in low:
            msg = T("not_logged_in") + " (" + msg + ")"
        raise AIError(msg[:500])
    u = data.get("usage") or {}
    _record("claude_cli", model, int(u.get("input_tokens") or 0) + int(u.get("cache_read_input_tokens") or 0)
            + int(u.get("cache_creation_input_tokens") or 0), int(u.get("output_tokens") or 0))
    so = data.get("structured_output")
    if isinstance(so, dict):
        return so
    return _parse_json_text(str(data.get("result", "")))


def _run_api(prompt: str, image_path, model: str) -> dict:
    key = _key("claude_api") or os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise AIError(T("no_api_key"))
    model = API_MODELS.get(model, model)
    content = []
    for ip in ([image_path] if isinstance(image_path, str) else (image_path or [])):
        img = base64.b64encode(Path(ip).read_bytes()).decode()
        content.append({"type": "text", "text": os.path.basename(ip) + ":"})
        content.append({"type": "image", "source": {"type": "base64", "media_type": "image/jpeg", "data": img}})
    content.append({"type": "text", "text": prompt})
    body = {"model": model, "max_tokens": 8000, "messages": [{"role": "user", "content": content}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages",
                                 data=json.dumps(body).encode(), method="POST",
                                 headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                          "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise AIError(f"{T('api_error')} {e.code}: {e.read().decode('utf-8', 'replace')[:300]}")
    u = data.get("usage") or {}
    _record("api", model, int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0))
    text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
    return _parse_json_text(text)


def _run_openai_api(prompt: str, image_path, schema: dict) -> dict:
    key = _key("openai_api")
    if not key:
        raise AIError(T("no_openai_key"))
    from .codex import strict_schema
    content = [{"type": "text", "text": prompt}]
    for ip in ([image_path] if isinstance(image_path, str) else (image_path or [])):
        img = base64.b64encode(Path(ip).read_bytes()).decode()
        content.append({"type": "text", "text": os.path.basename(ip) + ":"})
        content.append({"type": "image_url", "image_url": {"url": "data:image/jpeg;base64," + img}})
    body = {"model": (config.get("openai_model") or "gpt-5-mini").strip(),
            "messages": [{"role": "user", "content": content}],
            "response_format": {"type": "json_schema",
                                "json_schema": {"name": "answer", "strict": True, "schema": strict_schema(schema)}}}
    req = urllib.request.Request("https://api.openai.com/v1/chat/completions", data=json.dumps(body).encode(),
                                 method="POST", headers={"Authorization": "Bearer " + key,
                                                         "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=180) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        msg = e.read().decode("utf-8", "replace")[:300]
        if e.code == 429:
            raise AIError(T("limit") + " (OpenAI) " + msg)
        raise AIError(f"OpenAI {T('api_error')} {e.code}: {msg}")
    u = data.get("usage") or {}
    _record("openai_api", body["model"], int(u.get("prompt_tokens") or 0), int(u.get("completion_tokens") or 0))
    text = ((data.get("choices") or [{}])[0].get("message") or {}).get("content") or ""
    return _parse_json_text(text)


PROVIDER_NAMES = {"claude_cli": "Claude", "codex_cli": "ChatGPT", "api": "Claude API", "openai_api": "OpenAI API"}
# Vārdotāja nosaukumi ↔ kopīgie "Pieslēgumu" nosaukumi (core/ai.py, noteikumi §5 p.2)
CORE_NAME = {"claude_cli": "claude_sub", "codex_cli": "chatgpt_sub", "api": "claude_api", "openai_api": "openai_api"}
FROM_CORE = {v: k for k, v in CORE_NAME.items()}
# Vārdotāja darbi "Kurš AI ko dara" tabulai (ai_roles): apraksti+atslēgvārdi rodas vienā pieprasījumā
JOBS = ("describe", "analyze", "chat", "texts")
_limited: dict[str, float] = {}          # pieslēgums -> laiks, kad sasniegts limits
_status_cache: dict[str, tuple[float, bool]] = {}
_notice_lock = threading.Lock()
_notices: list[str] = []
LIMIT_PAUSE = 1800                       # pēc limita pieslēgumu 30 min neizmanto, ja ir cits


def _key(p: str) -> str:
    """API atslēga no drošās glabātuves (core.ai.key; rezervei — vecā atslēga settings.json)."""
    try:
        from core import ai as cai
        return (cai.key(p) or "").strip()
    except Exception:
        return (config.get({"claude_api": "api_key", "openai_api": "openai_key"}.get(p, "")) or "").strip()


def migrate_keys() -> None:
    """Vecās versijas API atslēgas no settings.json → drošajā glabātuvē (noteikumi §3, §5 p.2). Vienreiz, klusi."""
    try:
        from core import ai as cai, credentials
        if not credentials.available():
            return
        for p, k in (("claude_api", "api_key"), ("openai_api", "openai_key")):
            v = (config.get(k) or "").strip()
            if not v:
                continue
            if not credentials.get(cai.KEYED[p]):
                cai.key_save(p, v)
            config.update({k: ""})
            print(f"API atslēga ({p}) pārcelta uz drošo glabātuvi")
    except Exception as e:
        print("atslēgu pārcelšana neizdevās:", str(e)[:120])


def _record(provider: str, model: str = "", tin: int = 0, tout: int = 0) -> None:
    """Patēriņa uzskaite "Pieslēgumos" (core.ai.record) — aptuveni, žurnālā nekas."""
    try:
        from core import ai as cai
        cai.record(CORE_NAME.get(provider, provider), model, tin, tout)
    except Exception:
        pass


def _other(provider: str) -> str | None:
    return {"claude_cli": "codex_cli", "codex_cli": "claude_cli"}.get(provider)


def _ready(provider: str) -> bool:
    """Vai pieslēgums lietojams: abonements uzstādīts un pieslēgts (kešots 10 min); API — ir atslēga."""
    if provider == "api":
        return bool(_key("claude_api"))
    if provider == "openai_api":
        return bool(_key("openai_api"))
    now = time.time()
    c = _status_cache.get(provider)
    if c and now - c[0] < 600:
        return c[1]
    from . import codex
    try:
        ok = bool(auth_status().get("loggedIn")) if provider == "claude_cli" else bool(codex.auth_status().get("loggedIn"))
    except Exception:
        ok = False
    _status_cache[provider] = (now, ok)
    return ok


def roles_set() -> bool:
    """Vai lietotājs iestatījis "Kurš AI ko dara" (ai_roles) kādam Vārdotāja darbam."""
    r = config.get("ai_roles") or {}
    return any(FROM_CORE.get(p) for j in JOBS for p in (r.get(j) or []))


def providers(job: str = "describe") -> list[str]:
    """Pieslēgumi šim darbam secībā. ai_roles (Iestatījumi → Pieslēgumi → Kurš AI ko dara); ja nav —
    kā agrāk: izvēlētais abonements + otrs abonements pēc limita (fallback_ai)."""
    r = config.get("ai_roles") or {}
    lst = [FROM_CORE[p] for p in (r.get(job) or []) if p in FROM_CORE]
    if not lst and roles_set():
        lst = [FROM_CORE[p] for p in (r.get("describe") or []) if p in FROM_CORE]
    if not lst:
        p = config.get("ai_provider") or "claude_cli"
        lst = [p if p in CORE_NAME else "claude_cli"]
        o = _other(lst[0])
        if o and config.get("fallback_ai"):
            lst.append(o)
    return list(dict.fromkeys(lst))


def default_roles() -> dict:
    """Ko saskarne rāda "Kurš AI ko dara", ja lietotājs vēl nav iestatījis (= kā Vārdotājs strādā tagad)."""
    return {j: [CORE_NAME[p] for p in providers(j)] for j in JOBS}


def _limited_now(p: str) -> bool:
    return time.time() - _limited.get(p, 0) < LIMIT_PAUSE


def active_provider(job: str = "describe") -> str:
    """Pieslēgums, ko pašlaik lieto šim darbam (ņemot vērā pārslēgšanos pēc limita)."""
    lst = providers(job)
    if _limited_now(lst[0]):
        for p in lst[1:]:
            if not _limited_now(p) and _ready(p):
                return p
    return lst[0]


def take_notices() -> list[str]:
    with _notice_lock:
        out = list(_notices)
        _notices.clear()
    return out


def _is_limit(e: Exception) -> bool:
    return str(e).startswith(T("limit")) or "usage limit" in str(e).lower()


def _call_with(provider: str, prompt: str, schema: dict, workdir: str, imgs: list[str], light: bool) -> dict:
    from . import codex
    if provider == "claude_cli":
        model = "haiku" if light else (config.get("model") or "sonnet").strip()
        if len(imgs) == 1:
            where = ("The photo is the file photo.jpg in the current working directory. "
                     "Open it with the Read tool and look at it carefully before answering.\n\n")
        elif imgs:
            where = (f"The photos are the files {', '.join(os.path.basename(i) for i in imgs)} in the current working "
                     "directory. Open EACH of them with the Read tool and look at them carefully before answering.\n\n")
        else:
            where = ""
        return _run_cli(where + prompt, workdir, schema, bool(imgs), model)
    if provider == "codex_cli":
        try:
            r = codex.run(prompt, workdir, schema, imgs, config.get("codex_model") or "")
        except codex.CodexError as e:
            raise AIError(str(e))
        _record("codex_cli", config.get("codex_model") or "")
        return r
    fmt = "\n\nAnswer with JSON only, matching this JSON schema:\n" + json.dumps(schema)
    if provider == "openai_api":
        return _run_openai_api(prompt, imgs, schema)
    model = "haiku" if light else (config.get("model") or "sonnet").strip()
    return _run_api(prompt + fmt, imgs, model)


def img_size(default: int = 1568) -> int:
    """Ekonomiskais režīms — mazāks attēls AI (1024 px)."""
    return 1024 if config.get("eco_images") else default


def call(prompt: str, schema: dict, image: str | None = None, size: int | None = None, light: bool = False,
         images: list[str] | None = None, job: str = "describe") -> dict:
    """Viens AI izsaukums. image = oriģinālās bildes ceļš (tiek samazināts) vai None;
    images = vairākas bildes vienā izsaukumā (photo1.jpg, photo2.jpg …).
    light=True — vienkāršs teksta uzdevums (tulkošana), var izmantot ātrāku modeli.
    job — darbs "Kurš AI ko dara" secībai (describe | analyze | chat | texts). Ja pieslēgumam limits — nākamais;
    ja secību iestatījis lietotājs (ai_roles) — nākamais arī pēc citas kļūdas."""
    lst = providers(job)
    first = active_provider(job)
    order = [first] + [p for p in lst if p != first]
    any_error = roles_set()
    size = size or img_size()
    workdir = tempfile.mkdtemp(prefix="vardotajs_")
    try:
        imgs = []
        if image:
            imgs.append(os.path.join(workdir, "photo.jpg"))
            files.ai_image(image, imgs[0], size)
        for i, src in enumerate(images or []):
            dst = os.path.join(workdir, f"photo{i + 1}.jpg")
            files.ai_image(src, dst, size)
            imgs.append(dst)
        last: AIError | None = None
        prev = ""
        for p in order:
            if prev:
                if _limited_now(p) or not _ready(p):
                    continue
                with _notice_lock:
                    _notices.append(T("switched_ai", a=PROVIDER_NAMES.get(prev, prev), b=PROVIDER_NAMES.get(p, p)))
                print(f"AI: {prev} → {p} ({str(last)[:120]})")
            try:
                return _call_with(p, prompt, schema, workdir, imgs, light)
            except AIError as e:
                last, prev = e, p
                if _is_limit(e):
                    _limited[p] = time.time()
                    try:
                        from core import ai as cai
                        cai.note_limit(CORE_NAME.get(p, p))
                    except Exception:
                        pass
                elif not any_error:
                    raise
        raise last or AIError(T("error"))
    finally:
        shutil.rmtree(workdir, ignore_errors=True)


# --------------------------------------------------------------------------- garuma kontrole un tulkošana

REWRITE_SCHEMA = {"type": "object", "properties": {"title": {"type": "string"}, "description": {"type": "string"},
                                                  "title_lv": {"type": "string"}, "description_lv": {"type": "string"}},
                  "required": ["title", "description", "title_lv", "description_lv"]}


def rewrite(fields: dict[str, tuple[str, int]], mode: str = "shorten", context: str = "",
            image: str | None = None) -> dict[str, str]:
    """AI pārraksta tekstus, lai tie būtu PABEIGTI teikumi un ietilptu limitā. fields: {'title': (teksts, limits)}."""
    lines = []
    for k, (txt, lim) in fields.items():
        lines.append(f'- "{k}" (now {len(txt)} characters, must be at most {lim}; aim for about {int(lim * 0.9)}): {txt}')
    if mode == "complete":
        task = ("These stock photo texts were cut off in the middle of a sentence (the end is missing). Rewrite each "
                "one into a COMPLETE, natural English sentence with the same meaning that fits the limit — usually "
                "by shortening the middle and finishing the last phrase properly (e.g. '…with a tiered' -> '…with a "
                "tiered fountain'). Use the facts in the texts" + (" and what you see in the photo." if image else "."))
    else:
        task = ("These stock photo texts are too long. Rewrite each one SHORTER so it fits the limit, as a COMPLETE, "
                "natural English sentence: drop less important details, keep the main subject, place and facts.")
    prompt = (f"{task}\nNever end with a dangling word (a, an, the, of, under, with…), never cut words. Count the "
              f"characters carefully. Keep factual, neutral stock style.\n{context}\n\nTexts:\n" + "\n".join(lines)
              + '\n\nAnswer with JSON {"title": "...", "description": "...", "title_lv": "Latvian translation of '
                'your new title", "description_lv": "Latvian translation of your new description"} — return "" for a '
                'field not listed.')
    raw = call(prompt, REWRITE_SCHEMA, image=image, size=1024, job="texts")
    out = {k: " ".join(str(raw.get(k) or "").split()) for k in fields}
    # tulkojums nāk tajā pašā atbildē — saglabājam, lai vēlāk nevajadzētu vēlreiz jautāt AI
    store.tr_put({out[k]: str(raw.get(k + "_lv") or "").strip() for k in out if out[k] and raw.get(k + "_lv")})
    return out


def fit_texts(fields: dict[str, tuple[str, int]], context: str = "") -> tuple[dict[str, str], bool]:
    """Nodrošina, ka visi teksti ietilpst limitā un ir pabeigti: vispirms AI pats pārraksta (līdz 2 reizēm),
    tikai pēc tam — rezerves saīsināšana pa teikuma robežu. Atgriež (teksti, vai_bija_jāgriež)."""
    out = {k: " ".join((v[0] or "").split()) for k, v in fields.items()}
    for _ in range(2):
        bad = {k: (out[k], fields[k][1]) for k in out if len(out[k]) > fields[k][1]}
        if not bad:
            return out, False
        try:
            new = rewrite(bad, "shorten", context)
        except AIError:
            break
        for k, v in new.items():
            if v:
                out[k] = v
    cut = False
    for k in out:
        if len(out[k]) > fields[k][1]:
            out[k] = _trim(out[k], fields[k][1])
            cut = True
    # nekad neatstājam teikumu, kas beidzas ar komatu vai palīgvārdu (a, the, with, under…)
    half = {k: (out[k], fields[k][1]) for k in out if out[k] and looks_cut(out[k])}
    if half:
        try:
            new = rewrite(half, "complete", context)
            for k, v in new.items():
                if v and len(v) <= fields[k][1] and not looks_cut(v):
                    out[k] = v
        except AIError:
            pass
        for k in half:
            if looks_cut(out[k]):
                out[k] = _strip_tail(out[k])
                cut = True
    return out, cut


TR_SCHEMA = {"type": "object", "properties": {"translations": {"type": "array", "items": {"type": "string"}}},
             "required": ["translations"]}


def translate(texts: list[str]) -> list[str]:
    """Tulkojums latviski (kešots). Tukšie un jau tulkotie teksti AI netiek sūtīti."""
    texts = [" ".join((t or "").split()) for t in texts]
    cached = store.tr_get(texts)
    todo = [t for t in dict.fromkeys(texts) if t and t not in cached]
    if todo:
        prompt = ("Translate each of these English stock photo texts into natural Latvian (keep proper names, place "
                  "names in their usual Latvian or original form; keep a leading 'CITY, COUNTRY – DATE:' part but "
                  "translate it too). Return the translations in the same order.\n\n"
                  + "\n".join(f"{i + 1}. {t}" for i, t in enumerate(todo)))
        raw = call(prompt, TR_SCHEMA, light=True, job="texts")
        tr = [str(x) for x in (raw.get("translations") or [])]
        pairs = {t: tr[i].strip() for i, t in enumerate(todo) if i < len(tr) and tr[i].strip()}
        store.tr_put(pairs)
        cached.update(pairs)
    return [cached.get(t, "") for t in texts]


LANG_NAMES = {"lv": "Latvian", "de": "German", "es": "Spanish", "uk": "Ukrainian"}


def translate_rules(text: str, lang: str = "lv") -> str:
    """Iestatījumu "Rakstības noteikumi AI" / "RF/ED kritēriji" tulkojums mākonim (0.9.0-test4). AI norādes paliek
    angliski; tulkojums tikai parādīšanai. Noklusējuma tekstiem — iebūvēts (rules_tr, test9); citiem — AI, kešots pēc
    teksta un valodas (mainot tekstu — tulko no jauna)."""
    from . import rules_tr
    text = (text or "").strip()
    if not text or lang not in LANG_NAMES:
        return ""
    got = rules_tr.builtin(text, lang)
    if got:
        return got
    key = ("R|" if lang == "lv" else f"R{lang}|") + text
    got = store.tr_get([key]).get(key)
    if got:
        return got
    prompt = ("Translate these instructions for an AI (about writing stock photo titles/keywords or sorting photos into "
              f"royalty-free and editorial) into natural, simple {LANG_NAMES[lang]} for the user to read. Keep the line "
              "breaks, keep abbreviations RF, ED, UNSURE and quoted words as they are. Return one translation.\n\n" + text)
    raw = call(prompt, TR_SCHEMA, light=True, job="texts")
    tr = "\n".join(str(x) for x in (raw.get("translations") or [])).strip()
    if tr:
        store.tr_put({key: tr})
    return tr


# --------------------------------------------------------------------------- ģenerēšana

ED_PREFIX_RE = re.compile(r"^[^:\n]{2,90}? [–-] (?:CIRCA )?[A-Z]+(?: \d{1,2})?,? \d{4}:\s*")   # arī vecais ar komatu


def strip_ed_prefix(s: str) -> str:
    s = ED_PREFIX_RE.sub("", (s or "").strip())
    return ED_PLACE_ONLY_RE.sub("", s)


ED_PLACE_ONLY_RE = re.compile(r"^[A-Z][A-Z ,.'’\-]{2,80}:\s+")


def has_ed_prefix(s: str) -> bool:
    s = (s or "").strip()
    return bool(ED_PREFIX_RE.match(s) or ED_PLACE_ONLY_RE.match(s))


def ed_prefix(place: str, date: str) -> tuple[str, list[str]]:
    """'CITY, COUNTRY – MONTH DAY YEAR: ' (bez komata pirms gada) un brīdinājumi par trūkstošo."""
    from . import exif
    warnings = []
    place = exif.to_english(" ".join((place or "").split())).strip(" ,.-–:")
    date = " ".join((date or "").split()).strip(" ,.-–:")
    date = re.sub(r"(\d{1,2}|[A-Za-z]),\s*(\d{4})$", r"\1 \2", date)
    if not place:
        warnings.append(T("no_place"))
    if not date:
        warnings.append(T("no_date"))
    if place and date:
        return f"{place.upper()} – {date.upper()}: ", warnings
    if place or date:
        return f"{(place or date).upper()}: ", warnings
    return "", warnings


_edp: "config.JsonStore | None" = None
ED_PLACE_SCHEMA = {"type": "object", "properties": {"place": {"type": "string"}}, "required": ["place"],
                   "additionalProperties": False}


def ed_place_from_hint(hint: str) -> str:
    """Pavediens ('Tirta Gangga water palace, Karangasem, Bali, Indonesia') → 'City, Country' ED piebildei.
    Viens īss teksta AI izsaukums katram pavedienam, kešots ed_places.json (test13)."""
    global _edp
    hint = " ".join((hint or "").split())
    if not hint:
        return ""
    if _edp is None:
        _edp = config.JsonStore(config.app_dir() / "ed_places.json", {})
    k = hint.lower()
    if k in _edp.data:
        return _edp.data[k]
    raw = call("An editorial stock photo caption starts with its location as 'CITY, COUNTRY' (use the most specific "
               "well-known town or city; if there is none, the island or region; then the country). From this place "
               f"description return only that location as 'City, Country' in English, or '' if the country is unknown:\n{hint}",
               ED_PLACE_SCHEMA, light=True, job="texts")
    place = " ".join(str(raw.get("place") or "").split()).strip(" ,.-–:")
    with _edp.lock:
        _edp.data[k] = place
        _edp.save()
    return place


_ED_HEAD = re.compile(r"^\s*([A-Z][A-Z .'’-]+(?:,\s*[A-Z][A-Z .'’-]+)+)\s*[–—-]\s*[A-Z]+\s+\d")


def place_from_texts(title: str, description: str) -> str:
    """Esošie virsraksts/apraksts → 'City, Country' (test21, lietotājs 2026-11-13 13:48). ED piebilde aprakstā —
    bez AI; citādi viens īss teksta AI jautājums, kešots ed_places.json (atslēga 'txt:…')."""
    global _edp
    title, description = " ".join((title or "").split()), " ".join((description or "").split())
    m = _ED_HEAD.match(description)
    if m:
        return ", ".join(x.strip().title() for x in m.group(1).split(",") if x.strip())
    text = (title + " " + description).strip()
    if not text:
        return ""
    if _edp is None:
        _edp = config.JsonStore(config.app_dir() / "ed_places.json", {})
    k = "txt:" + text.lower()
    if k in _edp.data:
        return _edp.data[k]
    raw = call("Below is the title and description of a stock photo. If they name where the photo was taken, return only "
               "that location as 'City, Country' in English (the most specific well-known town or city; if there is none, "
               "the island or region; then the country). If the country is not stated or clearly implied, return ''.\n"
               f"{text}", ED_PLACE_SCHEMA, light=True, job="texts")
    place = " ".join(str(raw.get("place") or "").split()).strip(" ,.-–:")
    with _edp.lock:
        _edp.data[k] = place
        _edp.save()
    return place


_edd: "config.JsonStore | None" = None


def ed_short_description(desc: str, maxlen: int) -> str:
    """Īsāks apraksts ED kopijai, ja ar ED piebildi par garu (test14, dati §7a): fit_texts (AI pārraksta pabeigtā
    teikumā, rezervē — griež pie teikuma robežas). Kešots ed_descriptions.json, lai nepārrakstītu katrā manifesta pārbūvē."""
    global _edd
    desc = " ".join((desc or "").split())
    if len(desc) <= maxlen:
        return desc
    if _edd is None:
        _edd = config.JsonStore(config.app_dir() / "ed_descriptions.json", {})
    import hashlib
    k = hashlib.md5(f"{maxlen}|{desc}".encode("utf-8")).hexdigest()
    if k in _edd.data:
        return _edd.data[k]
    try:
        out, _cut = fit_texts({"description": (desc, maxlen)})
        short = out.get("description") or _trim(desc, maxlen)
    except Exception as e:
        print("ED apraksta saīsināšana:", e)
        return _trim(desc, maxlen)          # rezerve; nekešo — nākamreiz mēģinās ar AI
    with _edd.lock:
        _edd.data[k] = short
        _edd.save()
    return short


def build_ed_title(sentence: str, place: str, date: str, maxlen: int | None = None) -> tuple[str, list[str]]:
    """Editorial teksts formātā 'CITY, COUNTRY – MONTH DAY YEAR: teikums' (lieto Aprakstam)."""
    tmax = int(maxlen or config.get("ed_description_max") or 200)
    prefix, warnings = ed_prefix(place, date)
    sentence = strip_ed_prefix(sentence)
    sentence = sentence[:1].upper() + sentence[1:]
    return prefix + _trim(sentence, tmax - len(prefix)), warnings


def finalize(title: str, desc: str, editorial: bool, place: str = "", date: str = "",
             lv: dict | None = None, keep_prefix: str | None = None) -> tuple[str, str, list[str]]:
    """Gala virsraksts un apraksts: ED prefikss, garuma kontrole (AI pats saīsina pabeigtā teikumā),
    tulkojumu saglabāšana. keep_prefix — esošais ED prefikss (sarunā)."""
    tmax = int(config.get("title_max") or 150)
    warnings: list[str] = []
    prefix = ""
    ed_fmt = editorial and config.get("editorial_format")
    if ed_fmt:
        if keep_prefix is not None:
            prefix = keep_prefix
        else:
            prefix, warnings = ed_prefix(place, date)
        desc = strip_ed_prefix(desc)
        title = strip_ed_prefix(title)
        dlim = int(config.get("ed_description_max") or 200) - len(prefix)
    else:
        dlim = int(config.get("description_max") or 140)
    title = " ".join((title or "").split())
    desc = " ".join((desc or "").split())
    orig = (title, desc)
    fitted, cut = fit_texts({"title": (title, tmax), "description": (desc, dlim)})
    title, desc = fitted["title"], fitted["description"]
    title = title[:1].upper() + title[1:]
    desc = desc[:1].upper() + desc[1:]
    if cut:
        warnings.append(T("shortened"))
    final_desc = prefix + desc
    pairs = {}
    if lv and title == orig[0] and lv.get("title_lv"):
        pairs[title] = str(lv["title_lv"]).strip()
    if lv and desc == orig[1] and lv.get("description_lv"):
        pairs[final_desc] = prefix + str(lv["description_lv"]).strip()
    if prefix and desc != orig[1]:
        # saīsinātā teikuma tulkojums (no rewrite) — pieliekam ED prefiksu
        got = store.tr_get([desc]).get(desc)
        if got:
            pairs[final_desc] = prefix + got
    store.tr_put(pairs)
    return title, final_desc, warnings


def generate(path: str, context: str = "", editorial: bool | None = None, avoid: list[dict] | None = None,
             illustrative: bool = False) -> dict:
    """Ģenerē virsrakstu, aprakstu un atslēgvārdus vienai bildei (failu nemaina).
    avoid — citu tās pašas sērijas bilžu teksti, no kuriem jāatšķiras."""
    meta = exif.read_meta([path], info=True)[path]
    if editorial is None:
        editorial = is_editorial(path)
    facts = _facts(path, meta, context)
    if meta.get("title") or meta.get("keywords"):
        facts.append("Existing metadata of this photo (may be outdated or wrong — keep only facts that do not "
                     "contradict the facts above): "
                     f"title='{meta.get('title', '')}', keywords={', '.join(meta.get('keywords', [])[:50])}")
    others = list(avoid or []) + sibling_texts(path)
    seen, uniq_others = set(), []
    for o in others:
        k = _norm(o.get("title", ""))
        if k and k not in seen and _norm(meta.get("title", "")) != k:
            seen.add(k)
            uniq_others.append(o)
    uniq_others = uniq_others[:30]
    diff = ""
    if uniq_others:
        diff = ("\n\nOther photos from the SAME series already have these titles/descriptions:\n"
                + "\n".join(f"- {o['title']}" + (f" | {o['description']}" if o.get("description") else "")
                             for o in uniq_others)
                + "\nUse them ONLY to make your wording different — do NOT take place names or other facts from them."
                + "\nYour title and description MUST be clearly different from all of them: describe what is specific "
                  "to THIS frame (composition, viewpoint, close-up vs wide, people and what they do, light, time of day, "
                  "particular objects or details). Do not reuse their sentence structure. Also adapt the keywords and "
                  "their order to this particular frame.")

    def ask(extra: str = "") -> dict:
        prompt = ("You are an expert stock photography keyworder. Create metadata for selling this photo "
                  "on stock agencies (Adobe Stock, Shutterstock, iStock).\n\n" + _rules(editorial, illustrative)
                  + "\n\nKnown facts:\n- " + "\n- ".join(facts) + diff + extra
                  + '\n\nAnswer with JSON: {"title": "...", "description": "...", "keywords": [...], '
                    '"place": "City, Country or empty", "date": "Month Day, Year or empty"'
                  + ', "title_lv": "Latvian translation of the title", "description_lv": "Latvian translation of the '
                    'description sentence"}')
        return call(prompt, gen_schema(), image=path)

    raw = ask()
    taken = {_norm(o.get("title", "")) for o in uniq_others} | {_norm(o.get("description", "")) for o in uniq_others}
    if _norm(str(raw.get("title", ""))) in taken or _norm(str(raw.get("description", ""))) in taken:
        raw = ask(f"\n\nIMPORTANT: your previous answer duplicated another photo ('{raw.get('title', '')}'). "
                  "Write a completely different title and description for this frame.")
    if path:
        store.set_photo_place(path, str(raw.get("place") or ""))
    date = (_fmt_date(meta.get("date", "")) or str(raw.get("date") or "")) if editorial else ""
    # ED: datums, vieta un valsts ir APRAKSTĀ (description), virsraksts — tīrs teikums
    title, desc, warnings = finalize(str(raw.get("title", "")), str(raw.get("description", "")), bool(editorial),
                                     str(raw.get("place", "")), date, raw)
    risk = str(raw.get("risk") or "").strip()
    if risk:
        warnings = warnings + [risk]
    res = {"title": title, "description": desc, "keywords": finish_keywords(raw.get("keywords")),
           "editorial": editorial, "illustrative": bool(editorial and illustrative), "warnings": warnings}
    if not res["title"] and not res["keywords"]:
        raise AIError(T("empty"))
    return res


def _why(text: str, lim: int) -> str:
    """'' ja teksts kārtībā; citādi iemesls: long | end | limit."""
    if len(text) > lim:
        return "long"
    if looks_cut(text):
        return "end"
    if looks_cut(text, lim):
        return "limit"
    return ""


def text_problems(title: str, description: str) -> dict:
    """Kuri jau saglabātie teksti izskatās nogriezti vai par gariem (un kāpēc)."""
    tmax = int(config.get("title_max") or 150)
    d = (description or "").strip()
    m = ED_PREFIX_RE.match(d) or ED_PLACE_ONLY_RE.match(d)
    prefix = m.group(0) if m else ""
    sentence = d[len(prefix):]
    dlim = (int(config.get("ed_description_max") or 200) if prefix else int(config.get("description_max") or 140)) \
        - len(prefix)
    out, why = {}, {}
    t = (title or "").strip()
    if t and _why(t, tmax):
        out["title"] = (t, tmax)
        why["title"] = _why(t, tmax)
    sn = sentence.strip()
    if sn and _why(sn, dlim):
        out["description"] = (sn, dlim)
        why["description"] = _why(sn, dlim)
    return {"fields": out, "prefix": prefix, "why": why}


def cut_check(path: str, m: dict):
    """None — viss kārtībā; citādi {'title': 'end', ...}. Teksti, ko uzrakstījis/saglabājis Vārdotājs 0.6+
    (vai ko lietotājs atzīmēja 'Teksts ir kārtībā'), netiek apšaubīti, ja vien nav tiešām par gariem."""
    pr = text_problems(m.get("title", ""), m.get("description", ""))
    if not pr["fields"]:
        return None
    if store.get_cut_ok(path) == store.text_sig(m.get("title", ""), m.get("description", "")):
        keep = ("long",) if store.get_cut_lvl(path) == "user" else ("long", "end")
        why = {k: v for k, v in pr["why"].items() if v in keep}
        return why or None
    return pr["why"]


exif.CUT_CHECK = cut_check


def fix_cut(path: str) -> dict:
    """Pārraksta nogrieztu/par garu virsrakstu vai aprakstu par pabeigtu teikumu un ieraksta failā."""
    meta = exif.read_meta([path])[path]
    pr = text_problems(meta.get("title", ""), meta.get("description", ""))
    if not pr["fields"]:
        return {"changed": False, "title": meta.get("title", ""), "description": meta.get("description", "")}
    ctx = ("Other text of the same photo (for context): title: " + (meta.get("title") or "") + " | description: "
           + (meta.get("description") or ""))
    new = rewrite(pr["fields"], "complete", ctx)          # vispirms tikai teksts (lētāk)
    if any(not new.get(k) or looks_cut(new[k]) or len(new[k]) > v[1] for k, v in pr["fields"].items()):
        new2 = rewrite(pr["fields"], "complete", ctx, image=path)   # ja nepietiek — ar bildi
        new = {k: (new2.get(k) or new.get(k)) for k in pr["fields"]}
    fixed = {k: (new.get(k) or v[0], v[1]) for k, v in pr["fields"].items()}
    fitted, _ = fit_texts(fixed, ctx)
    # ja AI tomēr atstāja nepabeigtu teikumu — rezerves variants: nogriežam līdz pēdējai pabeigtai daļai
    for k, (_, lim) in fixed.items():
        if looks_cut(fitted[k]):
            fitted[k] = _trim(fitted[k] + " …", len(fitted[k])) if len(fitted[k]) > 20 else fitted[k]
    title = fitted.get("title", meta.get("title", ""))
    desc = pr["prefix"] + fitted["description"] if "description" in fitted else meta.get("description", "")
    if pr["prefix"] and "description" in fitted:
        got = store.tr_get([fitted["description"]]).get(fitted["description"])
        if got:
            store.tr_put({desc: pr["prefix"] + got})
    changed = title != (meta.get("title") or "") or desc != (meta.get("description") or "")
    if changed:
        exif.write_meta(path, title, desc, None, None)
    store.set_cut_ok(path, store.text_sig(title, desc))   # AI pārbaudīja — ✂ vairs nerādām
    return {"changed": changed, "title": title, "description": desc}


# --------------------------------------------------------------------------- saruna

def chat(folder: str, message: str, path: str | None = None, form: dict | None = None,
         editorial: bool | None = None, multi: int = 0, paths: list[str] | None = None,
         illustrative: bool = False) -> dict:
    """Atbilde uz lietotāja ziņu. Var arī atjaunināt laukus un atcerēties faktus mapei."""
    history = [m for m in store.get_chat(folder) if not m.get("forgotten")][-12:]
    meta = exif.read_meta([path], info=True)[path] if path else None
    if path and editorial is None:
        editorial = is_editorial(path)
    facts = _facts(path, meta) if path else []
    if not path:
        notes = store.notes_text_for(folder, is_file=False)
        if notes:
            facts.append("What the photographer already told us about this folder:\n  " + notes.replace("\n", "\n  "))
        facts.append(f"Current folder: {folder}")
    conv = "\n".join(f"{'Photographer' if m['role'] == 'user' else 'Assistant'}: {m['text']}" for m in history)
    cur = ""
    if form:
        cur = (f"Current metadata in the editor:\n  title: {form.get('title', '')}\n"
               f"  description: {form.get('description', '')}\n"
               f"  keywords: {', '.join(form.get('keywords') or [])}\n")
    if path and multi > 1:
        subject = (f"The photographer has selected {multi} photos; you see the first one. If they ask to (re)write metadata, "
                   "set update=true — the app will then write UNIQUE metadata for each selected photo separately using the "
                   "facts they gave, so you may return empty title/description/keywords.")
    elif path:
        subject = "The photo shown is the currently selected photo."
    else:
        subject = "No photo is selected right now, so set update=false."
    prompt = f"""You are the AI assistant inside "Vārdotājs", an app a stock photographer uses to write titles, descriptions and keywords.
Reply to the photographer in {lang_name()}, briefly and helpfully (1-3 sentences).

{subject}

What you can do:
1. If the photographer tells facts useful for describing photos (place, event, date, people types, objects, names of buildings…), put a short factual English summary of the NEW facts in "remember" (otherwise "").
   "remember_scope": "photos" if photos are selected and the facts are about them (DEFAULT when photos are selected);
   "folder" only if no photo is selected or the photographer clearly says it applies to the whole folder/shoot.
2. If they ask to write/change the metadata of the selected photo, or their new facts clearly change it, set "update": true and return the COMPLETE new "title", "description" and "keywords" that follow the rules below. Otherwise "update": false and return "", "" and [].
3. Otherwise just answer their question.

{_rules(bool(editorial), illustrative)}
{"For editorial photos the DESCRIPTION must have the format 'CITY, COUNTRY – MONTH DAY YEAR: sentence' (keep the existing place-date prefix), and the title is a plain sentence without it." if editorial and config.get("editorial_format") else ""}

Known facts:
- """ + "\n- ".join(facts or ["(none)"]) + f"""

{cur}
Conversation so far:
{conv or "(none)"}

New message from the photographer:
{message}"""
    raw = call(prompt, CHAT_SCHEMA, image=path, job="chat")
    scope = str(raw.get("remember_scope") or "photos")
    sel = [p for p in (paths or ([path] if path else [])) if p]
    if not sel:
        scope = "folder"
    res = {"reply": str(raw.get("reply", "")).strip(), "remember": str(raw.get("remember", "")).strip(),
           "update": bool(raw.get("update")), "scope": scope, "count": len(sel)}
    if res["update"] and len(sel) > 1:
        res["update"] = False
        res["batch"] = True          # serveris palaidīs atsevišķu ģenerēšanu katrai bildei
    elif res["update"]:
        rd = str(raw.get("description", ""))
        m = ED_PREFIX_RE.match(rd.strip()) or ED_PLACE_ONLY_RE.match(rd.strip())
        keep = m.group(0) if m else None
        if keep is None and form and editorial:
            m2 = ED_PREFIX_RE.match((form.get("description") or "").strip()) or \
                ED_PLACE_ONLY_RE.match((form.get("description") or "").strip())
            keep = m2.group(0) if m2 else None
        if keep is not None and not keep.endswith(" "):
            keep = keep.rstrip() + " "
        res["title"], res["description"], res["warnings"] = finalize(
            str(raw.get("title", "")), rd, bool(editorial), keep_prefix=keep if keep is not None else "")
        res["keywords"] = finish_keywords(raw.get("keywords"))
    store.add_chat(folder, "user", message)
    extra = {"remember": res["remember"], "scope": scope, "count": len(sel),
             "paths": sel if scope != "folder" else []} if res["remember"] else None
    store.add_chat(folder, "assistant", res["reply"] or "…", extra)
    if res["remember"]:
        if scope == "folder":
            store.add_folder_note(folder, res["remember"])
        else:
            for p in sel:
                store.add_photo_note(p, res["remember"])
    return res


# --------------------------------------------------------------------------- RF / ED klasifikācija

def classify(path: str) -> dict:
    meta = exif.read_meta([path], info=True)[path]
    facts = _facts(path, meta)
    prompt = f"""Decide whether this stock photo can be sold as Royalty-Free (RF) or must be Editorial (ED).

Criteria:
{config.get("rfed_criteria")}

Known facts:
- """ + "\n- ".join(facts) + f"""

Also, if you recognize the specific place, landmark, building, event or notable object in the photo, give a short
English "hint" with the most specific name and location (e.g. "Tirta Gangga water palace, Karangasem, Bali, Indonesia").
"hint_confidence": "sure" if you clearly recognize it, "maybe" if it is a plausible guess, "none" with hint "" if nothing specific.

Stock agency rules (the photographer's target agencies):
""" + agency_text() + f"""

Risk "flags" — list every one that applies (else []):
  people (recognizable people), brand (visible logo/trademark/brand product), zoo (zoo/enclosure visible),
  museum (museum/gallery interior or exhibits), paid_venue (ticketed attraction, theme park, stadium, concert hall),
  event (event that needs press credentials or is not accepted), restricted_place (known restricted landmark/place),
  artwork (modern mural, sculpture, artwork as main subject).
"advice": one short sentence in {lang_name()} saying how to submit it given the rules above and which agency fits,
  e.g. "RF der visām aģentūrām" or "ED tikai Shutterstock; Adobe nepieņems atpazīstamu cilvēku dēļ".

Answer with JSON: {{"category": "RF" | "ED" | "UNSURE", "reason": "short reason in {lang_name()}, max 12 words",
"hint": "...", "hint_confidence": "sure" | "maybe" | "none", "flags": [...], "advice": "..."}}"""
    raw = call(prompt, CLASSIFY_SCHEMA, image=path, job="analyze")
    cat = str(raw.get("category", "UNSURE")).upper()
    if cat not in ("RF", "ED", "UNSURE"):
        cat = "UNSURE"
    hint = str(raw.get("hint", "")).strip()[:200]
    conf = str(raw.get("hint_confidence", "none"))
    if conf == "none":
        hint = ""
    if hint:
        cur = store.get_photo(path)
        if not cur["ok"]:          # apstiprinātu pavedienu nepārrakstām
            store.set_hint(path, hint, conf, False)
    flags = [f for f in (raw.get("flags") or []) if isinstance(f, str)][:8]
    advice = str(raw.get("advice", "")).strip()[:300]
    store.set_risk(path, flags, advice)
    return {"category": cat, "reason": str(raw.get("reason", ""))[:200], "hint": hint, "conf": conf,
            "flags": flags, "advice": advice}


# --------------------------------------------------------------------------- viena apskate = viss

PHOTO_ITEM = {
    "type": "object",
    "properties": {
        "file": {"type": "string"},
        "category": {"type": "string", "enum": ["RF", "ED", "UNSURE"]},
        "reason": {"type": "string"},
        "hint": {"type": "string"},
        "hint_confidence": {"type": "string", "enum": ["sure", "maybe", "none"]},
        "flags": {"type": "array", "items": {"type": "string", "enum": [
            "people", "brand", "zoo", "museum", "paid_venue", "event", "restricted_place", "artwork"]}},
        "advice": {"type": "string"},
        "title": {"type": "string"},
        "description": {"type": "string"},
        "keywords": {"type": "array", "items": {"type": "string"}},
        "place": {"type": "string"},
        "date": {"type": "string"},
        "risk": {"type": "string"},
        "title_lv": {"type": "string"},
        "description_lv": {"type": "string"},
        "place_rules": {"type": "string"},
    },
    "required": ["file", "category", "reason", "hint", "hint_confidence", "flags", "advice", "title", "description",
                 "keywords", "place", "date", "risk", "title_lv", "description_lv", "place_rules"],
}
ANALYZE_SCHEMA = {"type": "object", "properties": {"photos": {"type": "array", "items": PHOTO_ITEM}},
                  "required": ["photos"]}


def folder_mode(path: str) -> str:
    """'ED' ja bilde ED/editorial mapē, 'RF' ja RF mapē, citādi 'auto' (AI izlemj)."""
    if is_editorial(path):
        return "ED"
    rf = (config.get("sort_rf_name") or "").strip().lower()
    if rf and rf in _folder_parts(path)[-1:]:
        return "RF"
    return "auto"


def analyze(paths: list[str], mode: str = "auto", illustrative: bool = False,
            avoid: list[str] | None = None) -> dict[str, dict]:
    """VIENS AI pieprasījums vairākām bildēm: RF/ED, pavediens, riski un virsraksta/apraksta/atslēgvārdu MELNRAKSTS.
    mode: auto | ED | RF. Atgriež {ceļš: rezultāts}; melnraksti un pavedieni tiek saglabāti programmā (ne failā)."""
    metas = exif.read_meta(paths, info=True)
    names = [f"photo{i + 1}.jpg" for i in range(len(paths))]
    per = [_facts(p, metas[p]) for p in paths]
    for i, p in enumerate(paths):
        m = metas[p]
        if m.get("title") or m.get("keywords"):
            per[i].append("Existing metadata (may be outdated or wrong — keep only facts that do not contradict the "
                          f"facts above): title='{m.get('title', '')}'")
    common = [f for f in per[0] if all(f in x for x in per[1:])] if len(per) > 1 else []
    common = [f for f in common if not f.startswith(("File name:", "Existing metadata", "Date taken"))]
    blocks = []
    for i, p in enumerate(paths):
        own = [f for f in per[i] if f not in common]
        blocks.append(f"{names[i]}:\n- " + "\n- ".join(own or ["(no extra facts)"]))
    if mode == "ED":
        rules = "ALL these photos are EDITORIAL (the photographer already decided). Metadata rules:\n" + \
                _rules(True, illustrative)
    elif mode == "RF":
        rules = "ALL these photos are ROYALTY-FREE / commercial (the photographer already decided). Metadata rules:\n" + \
                _rules(False)
    else:
        rules = ("Write the metadata according to the category you choose for each photo.\n\n"
                 "=== RULES FOR RF (commercial) PHOTOS ===\n" + _rules(False)
                 + "\n\n=== RULES FOR ED and UNSURE PHOTOS ===\n" + _rules(True, illustrative))
    diff = ""
    if avoid:
        diff = ("\n\nOther photos of the same series already have these titles — make yours clearly different:\n- "
                + "\n- ".join(avoid[-20:]))
    prompt = f"""You are an expert stock photography editor and keyworder. Look at EACH of the {len(paths)} photos and,
for each one, do everything in ONE go:
1. "category": RF, ED or UNSURE by these criteria:
{config.get("rfed_criteria")}
   "reason": short reason in {lang_name()}, max 12 words.
2. "hint": if you recognize the specific place, landmark, building, event or notable object, the most specific name and
   location in English (e.g. "Tirta Gangga water palace, Karangasem, Bali, Indonesia"); "hint_confidence": "sure",
   "maybe" or "none" (then hint ""). A place confirmed by the photographer is always right — use it.
3. "place_rules": if you recognized a specific place (temple, palace, museum, park, landmark…), state briefly in
   {lang_name()} what you KNOW about photography rules there that matter for stock: commercial photography or tripods
   banned or needing a permit, property release needed, paid entry, dress/ceremony rules, drones. Max 2 sentences.
   If you don't know, return "". Never invent rules. Use these rules (and any VERIFIED rules given in the facts) when
   choosing the category, flags and advice.
   "flags" (every one that applies, else []): people, brand, zoo, museum, paid_venue, event, restricted_place, artwork;
   "advice": one short sentence in {lang_name()} on how/where to submit it given the agency and place rules.
4. Stock metadata for selling the photo: "title", "description", "keywords", "place" ('City, Country' or ''),
   "date" ('Month Day, Year' only if the photographer told it and the camera date is missing, else ''), "risk"
   (in {lang_name()}, else ''), and Latvian translations "title_lv" and "description_lv".
Every photo must get its OWN, clearly different title and description (describe what is specific to that frame), even
when the photos are similar. Return one entry per photo in "photos", with "file" = its file name.

Stock agency rules (target agencies):
{agency_text()}

{rules}

Facts known about all these photos:
- """ + "\n- ".join(common or ["(none)"]) + "\n\nFacts per photo:\n" + "\n\n".join(blocks) + diff
    raw = call(prompt, ANALYZE_SCHEMA, images=paths, job="analyze")
    items = [x for x in (raw.get("photos") or []) if isinstance(x, dict)]
    by = {}
    for i, x in enumerate(items):
        f = str(x.get("file", "")).strip().lower()
        idx = names.index(f) if f in names else (i if i < len(paths) else None)
        if idx is not None and paths[idx] not in by:
            by[paths[idx]] = x
    out = {}
    for p in paths:
        x = by.get(p)
        if not x:
            continue
        out[p] = _store_analysis(p, x, metas[p], mode, illustrative)
    return out


def _store_analysis(path: str, x: dict, meta: dict, mode: str, illustrative: bool) -> dict:
    cat = str(x.get("category", "UNSURE")).upper()
    if cat not in ("RF", "ED", "UNSURE"):
        cat = "UNSURE"
    hint = str(x.get("hint", "")).strip()[:200]
    conf = str(x.get("hint_confidence", "none"))
    if conf == "none":
        hint = ""
    if hint and not store.get_photo(path)["ok"]:
        store.set_hint(path, hint, conf, False)
    flags = [f for f in (x.get("flags") or []) if isinstance(f, str)][:8]
    advice = str(x.get("advice", "")).strip()[:300]
    store.set_risk(path, flags, advice)
    rules = str(x.get("place_rules") or "").strip()[:500]
    place_key = store.get_photo(path)["hint"] or hint
    if rules:
        store.set_photo_rules(path, rules)
        store.set_place_rules(place_key, rules, "ai")
    store.set_photo_place(path, str(x.get("place") or ""))
    dcat = mode if mode in ("ED", "RF") else ("RF" if cat == "RF" else "ED")
    editorial = dcat == "ED"
    date = (_fmt_date(meta.get("date", "")) or str(x.get("date") or "")) if editorial else ""
    title, desc, warnings = finalize(str(x.get("title", "")), str(x.get("description", "")), editorial,
                                     str(x.get("place", "")), date, x)
    risk = str(x.get("risk") or "").strip()
    if risk:
        warnings.append(risk)
    draft = {"title": title, "description": desc, "keywords": finish_keywords(x.get("keywords")), "cat": dcat,
             "illustrative": bool(editorial and illustrative), "warnings": warnings}
    if draft["title"] or draft["keywords"]:
        store.set_draft(path, draft)
    return {"category": cat, "reason": str(x.get("reason", ""))[:200], "hint": hint, "conf": conf,
            "flags": flags, "advice": advice, "draft": draft}


def draft_generate(path: str, illustrative: bool = False) -> dict:
    """Melnraksta pārģenerēšana vienai bildei (piem., pēc RF↔ED maiņas) — failā netiek rakstīts."""
    res = generate(path, "", None, None, illustrative)
    ed = bool(res.get("editorial"))
    draft = {"title": res["title"], "description": res["description"], "keywords": res["keywords"],
             "cat": "ED" if ed else "RF", "illustrative": bool(res.get("illustrative")), "warnings": res["warnings"]}
    store.set_draft(path, draft)
    return {"draft": draft}


RULES_SCHEMA = {"type": "object", "properties": {"rules": {"type": "string"},
                                                "sources": {"type": "array", "items": {"type": "string"}}},
                "required": ["rules", "sources"]}


def check_place_rules(place: str) -> dict:
    """Fotografēšanas noteikumi vietai ar meklēšanu internetā (tikai pēc pieprasījuma; kešots vietai)."""
    provider = active_provider("analyze")
    if provider not in ("claude_cli", "codex_cli"):          # internetā meklē tikai abonements
        provider = next((p for p in providers("analyze") if p in ("claude_cli", "codex_cli") and _ready(p)), provider)
    prompt = (f"Search the web for the current photography rules for visitors at: {place}.\n"
              "Focus on what matters for a stock photographer: is commercial photography allowed or does it need a "
              "permit/fee, are tripods or drones banned, is a property release needed, dress or ceremony rules, any "
              "places inside where photos are forbidden. Summarize in at most 3 short sentences (max ~350 characters) in "
              f"{lang_name()}. If nothing reliable is found, say so. Return the URLs you used in 'sources'.")
    workdir = tempfile.mkdtemp(prefix="vardotajs_")
    try:
        if provider == "claude_cli":
            raw = _run_cli(prompt, workdir, RULES_SCHEMA, False, (config.get("model") or "sonnet").strip(),
                           ["WebSearch", "WebFetch"])
        elif provider == "codex_cli":
            from . import codex
            try:
                raw = codex.run(prompt, workdir, RULES_SCHEMA, None, config.get("codex_model") or "", web=True)
            except codex.CodexError as e:
                raise AIError(str(e))
        else:
            raise AIError(T("web_needs_sub"))
    finally:
        shutil.rmtree(workdir, ignore_errors=True)
    rules = str(raw.get("rules") or "").strip()
    srcs = [str(u) for u in (raw.get("sources") or []) if str(u).startswith("http")][:5]
    if rules:
        store.set_place_rules(place, rules, "web", srcs)
    return {"rules": rules, "sources": srcs}


exif.DRAFT_CHECK = store.has_draft


# --------------------------------------------------------------------------- savienojuma pārbaude

def test_connection() -> str:
    provider = active_provider()
    if provider == "codex_cli":
        from . import codex
        try:
            return codex.test()
        except codex.CodexError as e:
            raise AIError(str(e))
    if provider == "openai_api":
        r = _run_openai_api('Answer with JSON {"reply": "OK"}.', None,
                            {"type": "object", "properties": {"reply": {"type": "string"}}, "required": ["reply"]})
        return T("test_ok") + " (" + (config.get("openai_model") or "") + "): " + str(r.get("reply", ""))[:30]
    if provider == "claude_cli":
        cmd = find_claude()
        if not cmd:
            raise AIError(T("claude_missing"))
        args = cmd + ["-p", "--output-format", "json", "--model", (config.get("model") or "sonnet")]
        if "--no-session-persistence" in _help_text(cmd):
            args.append("--no-session-persistence")
        r = subprocess.run(args, input=b"Reply with exactly: OK", capture_output=True, timeout=180,
                           cwd=tempfile.gettempdir(), env=_env(), creationflags=NO_WINDOW)
        out = r.stdout.decode("utf-8", "replace").strip()
        try:
            d = json.loads(out.splitlines()[-1] if out else "{}")
        except json.JSONDecodeError:
            d = {}
        if d.get("is_error") or r.returncode != 0 or not d:
            msg = (d.get("result") or out or r.stderr.decode("utf-8", "replace"))[:400]
            if "login" in msg.lower() or "authenticat" in msg.lower():
                msg = T("not_logged_in")
            raise AIError(msg)
        return T("test_ok") + ": " + str(d.get("result", "")).strip()[:60]
    key = _key("claude_api")
    if not key:
        raise AIError(T("no_api_key"))
    model = API_MODELS.get(config.get("model"), config.get("model"))
    body = {"model": model, "max_tokens": 10, "messages": [{"role": "user", "content": "Reply OK"}]}
    req = urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(),
                                 headers={"x-api-key": key, "anthropic-version": "2023-06-01",
                                          "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise AIError(f"{T('api_error')} {e.code}: {e.read().decode('utf-8', 'replace')[:300]}")
    return T("test_ok") + " (" + model + ")"
