"""Aģentūru failu prasības pie "Uz iesniegšanu" (lēmums 2026-11-04 21:07, dati §8a; Vārdotājs 0.9.0-test20).

Uz NAS drīkst tikai bildes, kas der VISĀM mērķa aģentūrām (`target_agencies`, prasības `core/agency_specs.json`).
- Par lielu (MB, MP, garā mala) → Vārdotājs saglabā mazāku JPG: vispirms tikai JPEG kvalitāte (≥ 90), tikai tad neliela
  izmēra samazināšana, nekad zem lielākās prasītās MP / malas; metadati un krāsu profils saglabājas.
  Oriģināls ceļo līdzi sūtījuma apakšmapē "Original" (lietotājs 2026-11-13 10:39).
- Par mazu / nepareizs formāts → bilde nenonāk uz NAS, iemesls lietotājam.
"""
from __future__ import annotations

import io
import json
import math
import os
from pathlib import Path

from PIL import Image

from . import config
from .i18n import T

ORIGINAL_DIR = "Original"
DEFAULT_TARGETS = ["adobe", "shutterstock", "istock"]
MIN_Q = 90
MARGIN = 0.98                    # drošības rezerve zem MB limita
_specs: dict | None = None


def specs() -> dict:
    global _specs
    if _specs is None:
        here = Path(__file__).resolve()
        for p in (here.parent.parent / "core" / "agency_specs.json", here.parent.parent.parent / "core" / "agency_specs.json"):
            if p.is_file():
                try:
                    _specs = json.loads(p.read_text(encoding="utf-8")).get("agencies") or {}
                except Exception:
                    _specs = {}
                break
        else:
            _specs = {}
    return _specs


def targets() -> list[str]:
    t = config.get("target_agencies") or []
    return [a for a in (t if isinstance(t, list) and t else DEFAULT_TARGETS)]


def limits() -> dict:
    """Stingrākās vērtības no visām mērķa aģentūrām: {lauks: (vērtība, aģentūra)}; formats: (kopa, aģentūras)."""
    sp = specs()
    out: dict = {}
    for ag in targets():
        s = sp.get(ag) or {}
        for k in ("max_mb", "max_mp", "max_long_px"):
            v = s.get(k)
            if isinstance(v, (int, float)) and v > 0 and (k not in out or v < out[k][0]):
                out[k] = (v, ag)
        for k in ("min_mb", "min_mp", "min_side_px", "min_long_px"):
            v = s.get(k)
            if isinstance(v, (int, float)) and v > 0 and (k not in out or v > out[k][0]):
                out[k] = (v, ag)
        fm = s.get("formats")
        if fm:
            cur = out.get("formats")
            out["formats"] = (set(fm) & cur[0] if cur else set(fm), (cur[1] if cur else []) + [ag])
    return out


def _name(ag: str) -> str:
    return {"adobe": "Adobe Stock", "shutterstock": "Shutterstock", "istock": "iStock", "123rf": "123RF",
            "magnific": "Magnific"}.get(ag, ag.capitalize())


def _ext(path: str) -> str:
    e = os.path.splitext(path)[1].lower().lstrip(".")
    return {"jpeg": "jpg", "tiff": "tif"}.get(e, e)


def check(path: str) -> dict:
    """{'ok': True} | {'fix': {...}} (jāsaspiež / jāsamazina) | {'bad': [iemesli]}."""
    lim = limits()
    if not lim:
        return {"ok": True}
    size = os.path.getsize(path)
    try:
        with Image.open(path) as im:
            w, h = im.size
    except Exception:
        return {"ok": True}                      # nevar nolasīt — lai lemj aģentūra / Tirgotājs
    mp = w * h / 1e6
    bad = []
    ext = _ext(path)
    if "formats" in lim and ext not in lim["formats"][0]:
        ok = ", ".join(sorted(x.upper() for x in lim["formats"][0])) or "—"
        bad.append(T("spec_fmt", f=ext.upper(), ok=ok))
    if "min_mp" in lim and mp < lim["min_mp"][0]:
        bad.append(T("spec_min_mp", mp=round(mp, 1), min=lim["min_mp"][0], ag=_name(lim["min_mp"][1])))
    if "min_side_px" in lim and min(w, h) < lim["min_side_px"][0]:
        bad.append(T("spec_min_px", px=min(w, h), min=lim["min_side_px"][0], ag=_name(lim["min_side_px"][1])))
    if "min_long_px" in lim and max(w, h) < lim["min_long_px"][0]:
        bad.append(T("spec_min_px", px=max(w, h), min=lim["min_long_px"][0], ag=_name(lim["min_long_px"][1])))
    if "min_mb" in lim and size / 1e6 < lim["min_mb"][0]:
        bad.append(T("spec_min_mb", mb=round(size / 1e6, 1), min=lim["min_mb"][0], ag=_name(lim["min_mb"][1])))
    big = ("max_mb" in lim and size > lim["max_mb"][0] * 1e6) or ("max_mp" in lim and mp > lim["max_mp"][0]) \
        or ("max_long_px" in lim and max(w, h) > lim["max_long_px"][0])
    if bad:
        return {"bad": bad}
    if big:
        if ext != "jpg":
            return {"bad": [T("spec_big_nojpg", mb=round(size / 1e6, 1))]}
        return {"fix": {"mb": round(size / 1e6, 1), "w": w, "h": h}}
    return {"ok": True}


def _min_scale(w: int, h: int, lim: dict) -> float:
    """Mazākais pieļaujamais mērogs (nekad zem lielākās prasītās MP / malas)."""
    s = 0.0
    if "min_mp" in lim:
        s = max(s, math.sqrt(lim["min_mp"][0] * 1e6 / (w * h)))
    if "min_side_px" in lim:
        s = max(s, lim["min_side_px"][0] / min(w, h))
    if "min_long_px" in lim:
        s = max(s, lim["min_long_px"][0] / max(w, h))
    return s


def _max_scale(w: int, h: int, lim: dict) -> float:
    s = 1.0
    if "max_mp" in lim:
        s = min(s, math.sqrt(lim["max_mp"][0] * 1e6 / (w * h)))
    if "max_long_px" in lim:
        s = min(s, lim["max_long_px"][0] / max(w, h))
    return s


def compress(src: str, dst: str) -> dict:
    """Saglabā mazāku JPG uz dst (metadatus kopē exif.copy_meta). Kļūda → ValueError ar iemeslu (dst nav)."""
    from PIL import JpegImagePlugin
    lim = limits()
    max_b = lim["max_mb"][0] * 1e6 * MARGIN if "max_mb" in lim else None
    src_b = os.path.getsize(src)
    with Image.open(src) as im0:
        im0.load()
        icc = im0.info.get("icc_profile")
        exif_b = im0.info.get("exif")
        dpi = im0.info.get("dpi")
        try:
            sub = JpegImagePlugin.get_sampling(im0)
        except Exception:
            sub = -1
        im = im0.convert("RGB") if im0.mode not in ("RGB", "L", "CMYK") else im0.copy()
    w, h = im.size
    lo, hi = _min_scale(w, h, lim), _max_scale(w, h, lim)
    if hi < lo or hi <= 0:
        raise ValueError(T("spec_conflict"))

    from PIL import ImageFile
    ImageFile.MAXBLOCK = max(ImageFile.MAXBLOCK, w * h * 4)      # optimize lieliem attēliem (citādi "Suspension not allowed")

    def save(img, q) -> bytes:
        buf = io.BytesIO()
        kw = {"quality": q, "optimize": True}
        if sub is not None and sub >= 0:
            kw["subsampling"] = sub
        if icc:
            kw["icc_profile"] = icc
        if exif_b:
            kw["exif"] = exif_b
        if dpi:
            kw["dpi"] = dpi
        img.save(buf, "JPEG", **kw)
        return buf.getvalue()

    scale = hi
    cur = im if scale >= 0.9999 else im.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
    data, q = None, None
    for qq in (97, 95, 93, 91, MIN_Q):           # 1) tikai kvalitāte
        data = save(cur, qq)
        q = qq
        if max_b is None or len(data) <= max_b:
            break
    tries = 0
    while max_b is not None and len(data) > max_b:  # 2) neliela samazināšana, ne zem prasītā
        tries += 1
        if tries > 6 or scale <= lo + 1e-6:
            raise ValueError(T("spec_cant", mb=round(src_b / 1e6, 1), max=lim["max_mb"][0]))
        scale = max(lo, scale * math.sqrt(max_b / len(data)) * 0.98)
        cur = im.resize((max(1, round(w * scale)), max(1, round(h * scale))), Image.LANCZOS)
        q = 92
        data = save(cur, q)
    with open(dst, "wb") as f:
        f.write(data)
    return {"from_mb": round(src_b / 1e6, 1), "to_mb": round(len(data) / 1e6, 1), "q": q,
            "w": cur.size[0], "h": cur.size[1], "scaled": cur.size != (w, h)}
