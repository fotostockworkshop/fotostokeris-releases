"""Darbs ar ExifTool: atrašana, automātiska uzstādīšana, metadatu lasīšana un rakstīšana.

Rakstām tos laukus, kurus lasa fotostoki (Adobe Stock, Shutterstock, iStock u.c.):
  Virsraksts -> XMP-dc:Title, IPTC:ObjectName, XMP-photoshop:Headline, IPTC:Headline
  Apraksts   -> XMP-dc:Description, IPTC:Caption-Abstract, EXIF:ImageDescription
  Atslēgv.   -> XMP-dc:Subject, IPTC:Keywords
  Autors     -> XMP-dc:Creator, IPTC:By-line, EXIF:Artist
"""
from __future__ import annotations

import io
import json
import os
import queue
import shutil
import ssl
import subprocess
import tempfile
import threading
import urllib.request
import zipfile
import tarfile
from pathlib import Path

from . import config
from .i18n import T

IS_WIN = config.IS_WIN
NO_WINDOW = 0x08000000 if IS_WIN else 0

ROOT = Path(__file__).resolve().parent.parent


# --------------------------------------------------------------------------- atrašana

def _install_dir() -> Path:
    return config.app_dir() / "exiftool"


def find_exiftool() -> list[str] | None:
    """Atgriež komandu ExifTool palaišanai (sarakstu) vai None."""
    candidates: list[Path] = []
    for base in (_install_dir(), ROOT / "tools" / "exiftool"):
        if IS_WIN:
            candidates.append(base / "exiftool.exe")
        else:
            candidates.append(base / "exiftool")
    for c in candidates:
        if c.is_file():
            if IS_WIN:
                return [str(c)]
            perl = shutil.which("perl") or "/usr/bin/perl"
            return [perl, str(c)]
    w = shutil.which("exiftool")
    if w:
        return [w]
    for p in ("/opt/homebrew/bin/exiftool", "/usr/local/bin/exiftool", "/usr/bin/exiftool"):
        if os.path.isfile(p):
            return [p]
    return None


# --------------------------------------------------------------------------- uzstādīšana

def _download(url: str, timeout: int = 120) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Vardotajs/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except (ssl.SSLError, urllib.error.URLError) as e:  # macOS python.org bez sertifikātiem
        if isinstance(e, urllib.error.HTTPError):
            raise
        curl = shutil.which("curl")
        if not curl:
            raise
        fd, tmp = tempfile.mkstemp()
        os.close(fd)
        try:
            subprocess.run([curl, "-fsSL", "-o", tmp, url], check=True, timeout=timeout,
                           creationflags=NO_WINDOW)
            return Path(tmp).read_bytes()
        finally:
            os.unlink(tmp)


def _install_from_zip_windows(data: bytes) -> None:
    target = _install_dir()
    tmp = config.app_dir() / "exiftool_tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        z.extractall(tmp)
    exe = None
    for p in tmp.rglob("*.exe"):
        if p.name.lower() in ("exiftool(-k).exe", "exiftool.exe") and (p.parent / "exiftool_files").is_dir():
            exe = p
            break
    if not exe:
        raise RuntimeError("Arhīvā neatradu exiftool.exe")
    shutil.rmtree(target, ignore_errors=True)
    target.mkdir()
    shutil.move(str(exe), str(target / "exiftool.exe"))
    shutil.move(str(exe.parent / "exiftool_files"), str(target / "exiftool_files"))
    shutil.rmtree(tmp, ignore_errors=True)


def _install_perl_dist(data: bytes, is_zip: bool) -> None:
    target = _install_dir()
    tmp = config.app_dir() / "exiftool_tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    if is_zip:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            z.extractall(tmp)
    else:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
            t.extractall(tmp)
    src = None
    for p in tmp.rglob("exiftool"):
        if p.is_file() and (p.parent / "lib" / "Image" / "ExifTool.pm").is_file():
            src = p.parent
            break
    if not src:
        raise RuntimeError("Arhīvā neatradu exiftool")
    shutil.rmtree(target, ignore_errors=True)
    target.mkdir()
    shutil.copy2(src / "exiftool", target / "exiftool")
    shutil.copytree(src / "lib", target / "lib")
    os.chmod(target / "exiftool", 0o755)
    shutil.rmtree(tmp, ignore_errors=True)


def install_exiftool() -> str:
    """Lejupielādē ExifTool lietotnes datu mapē. Atgriež aprakstu par paveikto."""
    errors = []
    if IS_WIN:
        try:
            ver = _download("https://exiftool.org/ver.txt", 30).decode().strip()
            data = _download(f"https://exiftool.org/exiftool-{ver}_64.zip")
            _install_from_zip_windows(data)
            return f"{T('et_installed')}: {ver} (exiftool.org)"
        except Exception as e:
            errors.append(f"exiftool.org: {e}")
        try:
            data = _download("https://codeload.github.com/photostructure/exiftool-vendored.exe/zip/refs/heads/main")
            _install_from_zip_windows(data)
            return T("et_installed") + " (GitHub)"
        except Exception as e:
            errors.append(f"GitHub: {e}")
    else:
        try:
            data = _download("https://codeload.github.com/exiftool/exiftool/zip/refs/heads/master")
            _install_perl_dist(data, is_zip=True)
            return T("et_installed") + " (GitHub)"
        except Exception as e:
            errors.append(f"GitHub: {e}")
        try:
            ver = _download("https://exiftool.org/ver.txt", 30).decode().strip()
            data = _download(f"https://exiftool.org/Image-ExifTool-{ver}.tar.gz")
            _install_perl_dist(data, is_zip=False)
            return f"{T('et_installed')}: {ver} (exiftool.org)"
        except Exception as e:
            errors.append(f"exiftool.org: {e}")
    raise RuntimeError(T("et_install_failed") + " " + " | ".join(errors))


# --------------------------------------------------------------------------- stay_open process

class ExifToolError(Exception):
    pass


class ExifTool:
    """Viens pastāvīgi atvērts ExifTool process (-stay_open), lai nebūtu jāgaida starts katrai bildei."""

    def __init__(self):
        self.lock = threading.Lock()
        self.proc: subprocess.Popen | None = None
        self.errq: queue.Queue = queue.Queue()
        self.counter = 0
        self.cmd: list[str] | None = None

    def available(self) -> bool:
        return find_exiftool() is not None

    def version(self) -> str | None:
        cmd = find_exiftool()
        if not cmd:
            return None
        try:
            out = subprocess.run(cmd + ["-ver"], capture_output=True, timeout=30,
                                 creationflags=NO_WINDOW)
            return out.stdout.decode("utf-8", "replace").strip() or None
        except Exception:
            return None

    def _start(self):
        cmd = find_exiftool()
        if not cmd:
            raise ExifToolError(T("et_missing"))
        self.cmd = cmd
        self.proc = subprocess.Popen(
            cmd + ["-stay_open", "True", "-@", "-"],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=NO_WINDOW,
        )
        self.errq = queue.Queue()
        proc = self.proc

        def pump():
            for line in iter(proc.stderr.readline, b""):
                self.errq.put(line.decode("utf-8", "replace").rstrip("\r\n"))

        threading.Thread(target=pump, daemon=True).start()

    def stop(self):
        with self.lock:
            if self.proc and self.proc.poll() is None:
                try:
                    self.proc.stdin.write(b"-stay_open\nFalse\n")
                    self.proc.stdin.flush()
                    self.proc.wait(5)
                except Exception:
                    self.proc.kill()
            self.proc = None

    def execute(self, args: list[str]) -> tuple[str, list[str]]:
        """Izpilda vienu komandu. Atgriež (stdout, stderr rindiņas)."""
        with self.lock:
            for attempt in range(2):
                if not self.proc or self.proc.poll() is not None:
                    self._start()
                self.counter += 1
                n = self.counter
                lines = ["-charset", "filename=utf8"] + args + ["-echo4", f"{{errdone{n}}}", f"-execute{n}"]
                payload = "\n".join(a.replace("\r", " ").replace("\n", " ") for a in lines) + "\n"
                try:
                    self.proc.stdin.write(payload.encode("utf-8"))
                    self.proc.stdin.flush()
                    out = bytearray()
                    marker = f"{{ready{n}}}".encode()
                    while True:
                        chunk = self.proc.stdout.readline()
                        if not chunk:
                            raise ExifToolError("ExifTool process negaidīti beidzās")
                        if chunk.strip() == marker:
                            break
                        out += chunk
                    errs = []
                    while True:
                        line = self.errq.get(timeout=60)
                        if line.strip() == f"{{errdone{n}}}":
                            break
                        if line.strip():
                            errs.append(line)
                    return out.decode("utf-8", "replace"), errs
                except (BrokenPipeError, OSError, ExifToolError, queue.Empty):
                    try:
                        self.proc.kill()
                    except Exception:
                        pass
                    self.proc = None
                    if attempt == 1:
                        raise
        raise ExifToolError("ExifTool kļūda")


ET = ExifTool()


# --------------------------------------------------------------------------- lasīšana

READ_TAGS = [
    "-XMP-dc:Title", "-IPTC:ObjectName", "-XMP-photoshop:Headline", "-IPTC:Headline",
    "-XMP-dc:Description", "-IPTC:Caption-Abstract", "-EXIF:ImageDescription",
    "-XMP-dc:Subject", "-IPTC:Keywords",
    "-XMP-dc:Creator", "-IPTC:By-line", "-EXIF:Artist",
    "-XMP-photoshop:Country", "-IPTC:Country-PrimaryLocationName", "-XMP-iptcExt:LocationCreatedCountryName",
    "-XMP-photoshop:City", "-IPTC:City", "-XMP-iptcExt:LocationCreatedCity",
]
INFO_TAGS = ["-EXIF:DateTimeOriginal", "-XMP-exif:DateTimeOriginal", "-EXIF:CreateDate",
             "-XMP-photoshop:DateCreated", "-IPTC:DateCreated", "-Composite:GPSLatitude",
             "-Composite:GPSLongitude", "-EXIF:Model", "-File:ImageWidth", "-File:ImageHeight",
             "-Composite:ImageSize"]


def _as_list(v) -> list[str]:
    if v is None:
        return []
    if isinstance(v, list):
        return [str(x).strip() for x in v if str(x).strip()]
    s = str(v).strip()
    return [s] if s else []


def _first(d: dict, *keys) -> str:
    for k in keys:
        v = d.get(k)
        if isinstance(v, list):
            v = ", ".join(str(x) for x in v)
        if v not in (None, ""):
            return str(v).strip()
    return ""


def _normalize(d: dict) -> dict:
    kws = _as_list(d.get("XMP-dc:Subject")) or _as_list(d.get("IPTC:Keywords"))
    seen = set()
    uniq = []
    for k in kws:
        if k.lower() not in seen:
            seen.add(k.lower())
            uniq.append(k)
    return {
        "path": d.get("SourceFile", ""),
        "title": _first(d, "XMP-dc:Title", "IPTC:ObjectName", "XMP-photoshop:Headline", "IPTC:Headline"),
        "description": _first(d, "XMP-dc:Description", "IPTC:Caption-Abstract", "IFD0:ImageDescription"),
        "keywords": uniq,
        "author": _first(d, "XMP-dc:Creator", "IPTC:By-line", "IFD0:Artist"),
        "country": _first(d, "XMP-photoshop:Country", "IPTC:Country-PrimaryLocationName", "XMP-iptcExt:LocationCreatedCountryName"),
        "city": _first(d, "XMP-photoshop:City", "IPTC:City", "XMP-iptcExt:LocationCreatedCity"),
        "date": _first(d, "ExifIFD:DateTimeOriginal", "XMP-exif:DateTimeOriginal", "ExifIFD:CreateDate",
                       "XMP-photoshop:DateCreated", "IPTC:DateCreated"),
        "gps": [d.get("Composite:GPSLatitude"), d.get("Composite:GPSLongitude")]
        if d.get("Composite:GPSLatitude") not in (None, "") else None,
        "camera": _first(d, "IFD0:Model"),
        "size": _first(d, "Composite:ImageSize"),
    }


def _run_json(args: list[str], paths: list[str]) -> list[dict]:
    if not paths:
        return []
    out, errs = ET.execute(["-json", "-G1", "-n"] + args + list(paths))
    out = out.strip()
    if not out:
        return []
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        raise ExifToolError(T("et_bad_answer") + ": " + "; ".join(errs[:3]))


def _key(p: str) -> str:
    return os.path.normcase(os.path.abspath(p))


def read_meta(paths: list[str], info: bool = False) -> dict[str, dict]:
    """Nolasa metadatus. Atslēga = ceļš tieši tā, kā tika padots."""
    lookup = {_key(p): p for p in paths}
    res = {}
    for i in range(0, len(paths), 200):
        chunk = paths[i:i + 200]
        for d in _run_json(READ_TAGS + (INFO_TAGS if info else []), chunk):
            m = _normalize(d)
            orig = lookup.get(_key(m["path"]), m["path"])
            m["path"] = orig
            res[orig] = m
    for p in paths:
        res.setdefault(p, {"path": p, "title": "", "description": "", "keywords": [], "author": ""})
    return res


def status_for(meta: dict) -> str:
    """full | partial | none — krāsu kvadrātiņam pie sīktēla."""
    minkw = int(config.get("complete_min_keywords") or 5)
    has_t = bool(meta.get("title"))
    has_d = bool(meta.get("description"))
    nkw = len(meta.get("keywords") or [])
    if (has_t or has_d) and nkw >= minkw:
        return "full"
    if has_t or has_d or nkw:
        return "partial"
    return "none"


CUT_CHECK = None          # ai.py iestata: vai teksts izskatās nogriezts / par garu
DRAFT_CHECK = None        # ai.py iestata: vai bildei ir neapstiprināts AI melnraksts


def read_status(paths: list[str]) -> dict[str, dict]:
    meta = read_meta(paths)
    out = {}
    for p, m in meta.items():
        why = None
        if CUT_CHECK and (m.get("title") or m.get("description")):
            try:
                why = CUT_CHECK(p, m)
            except Exception:
                why = None
        draft = bool(DRAFT_CHECK and DRAFT_CHECK(p))
        out[p] = {"status": status_for(m), "kw": len(m["keywords"]), "title": m["title"][:120], "cut": bool(why),
                  "cut_why": why or {}, "draft": draft}
    return out


# --------------------------------------------------------------------------- rakstīšana

def _clean(s: str) -> str:
    return " ".join((s or "").replace("\r", " ").replace("\n", " ").split())


_FOLD = {"ł": "l", "Ł": "L", "ø": "o", "Ø": "O", "đ": "d", "Đ": "D", "ß": "ss", "æ": "ae", "Æ": "AE",
         "œ": "oe", "Œ": "OE", "þ": "th", "Þ": "TH", "ð": "d", "Ð": "D", "ı": "i", "ħ": "h", "Ħ": "H",
         "‘": "'", "’": "'", "‚": "'", "“": '"', "”": '"', "„": '"', "«": '"', "»": '"', "…": "...",
         "—": "-", "‐": "-", "‑": "-", "\u00a0": " "}


def to_english(s: str) -> str:
    """Tikai angļu burti (lietotājs 2026-11-12: "Rīga" → "Riga", "Kraków" → "Krakow"). ED formāta domuzīme "–" paliek."""
    import unicodedata
    s = "".join(_FOLD.get(c, c) for c in (s or ""))
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c) and (ord(c) < 128 or c == "–"))


COUNTRY_TAGS = ("XMP-photoshop:Country", "IPTC:Country-PrimaryLocationName", "XMP-iptcExt:LocationCreatedCountryName")
CITY_TAGS = ("XMP-photoshop:City", "IPTC:City", "XMP-iptcExt:LocationCreatedCity")
REGION_TAGS = ("XMP-photoshop:State", "IPTC:Province-State", "XMP-iptcExt:LocationCreatedProvinceState")


def write_meta(path: str, title=None, description=None, keywords=None, author=None, location=None) -> None:
    """Ieraksta metadatus. None = lauku neaiztikt, "" / [] = izdzēst.
    location = (pilsēta, valsts) — valsts/pilsēta failā (iStock u.c. nolasa; test20); None = neaiztikt."""
    args = ["-overwrite_original", "-m", "-codedcharacterset=utf8", "-charset", "iptc=utf8"]
    if title is not None:
        t = to_english(_clean(title))
        for tag in ("XMP-dc:Title", "IPTC:ObjectName", "XMP-photoshop:Headline", "IPTC:Headline"):
            args.append(f"-{tag}={t}")
    if description is not None:
        d = to_english(_clean(description))
        for tag in ("XMP-dc:Description", "IPTC:Caption-Abstract", "EXIF:ImageDescription"):
            args.append(f"-{tag}={d}")
    if keywords is not None:
        kws = []
        seen = set()
        for k in keywords:
            k = to_english(_clean(str(k))).strip(" ,;")
            if k and k.lower() not in seen:
                seen.add(k.lower())
                kws.append(k)
        for tag in ("XMP-dc:Subject", "IPTC:Keywords"):
            args.append(f"-{tag}=")
            for k in kws:
                args.append(f"-{tag}={k}")
    if author is not None:
        a = _clean(author)
        args.append(f"-XMP-dc:Creator={a}")
        args.append(f"-IPTC:By-line={a}")
        args.append(f"-EXIF:Artist={a}")
    if location is not None:
        city, country, region = (to_english(_clean(x or "")) for x in (tuple(location) + ("",))[:3])
        if country:
            for tag in COUNTRY_TAGS:
                args.append(f"-{tag}={country}")
            for tag in CITY_TAGS:
                args.append(f"-{tag}={city}")
            for tag in REGION_TAGS:
                args.append(f"-{tag}={region}")
    out, errs = ET.execute(args + [path])
    if "1 image files updated" not in out and "1 image files unchanged" not in out:
        real = [e for e in errs if not e.startswith("Warning")]
        raise ExifToolError("; ".join(real or errs) or out.strip() or T("et_write_failed"))


def copy_meta(src: str, dst: str, width: int = 0, height: int = 0) -> None:
    """Saspiestajai kopijai (test20): visi metadati no oriģināla (IPTC/XMP/EXIF), izmēri — jaunie."""
    args = ["-overwrite_original", "-m", "-tagsFromFile", src, "-all:all", "-unsafe",
            "--IFD1:all", "--ExifIFD:ExifImageWidth", "--ExifIFD:ExifImageHeight"]
    if width and height:
        args += [f"-ExifIFD:ExifImageWidth={width}", f"-ExifIFD:ExifImageHeight={height}"]
    out, errs = ET.execute(args + [dst])
    if "1 image files updated" not in out and "1 image files unchanged" not in out:
        real = [e for e in errs if not e.startswith("Warning")]
        raise ExifToolError("; ".join(real or errs) or out.strip() or T("et_write_failed"))
