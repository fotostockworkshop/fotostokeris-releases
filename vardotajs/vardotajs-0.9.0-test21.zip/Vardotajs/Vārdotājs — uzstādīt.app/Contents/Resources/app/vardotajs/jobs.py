"""Fona darbi: AI ģenerēšana, RF/ED klasifikācija, vietu atpazīšana, nogriezto tekstu labošana.

Darbu vēsture (pēdējie JOBS_KEEP) glabājas failā jobs.json, tāpēc ir redzama arī pēc restarta;
nepabeigtos darbus var turpināt (resume)."""
from __future__ import annotations

import copy
import json
import os
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor

from . import ai, config, exif, store, manifest
from .i18n import T

JOBS_KEEP = 20
_jobs: dict[str, dict] = {}
_lock = threading.RLock()
_loaded = False
_last_save = 0.0


def _file():
    return config.app_dir() / "jobs.json"


def _load():
    global _loaded
    if _loaded:
        return
    _loaded = True
    try:
        with open(_file(), encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = []
    for j in data if isinstance(data, list) else []:
        if not isinstance(j, dict) or "id" not in j:
            continue
        if not j.get("finished"):
            # Vārdotājs tika aizvērts darba laikā
            j["finished"] = True
            j["interrupted"] = True
            j["ended"] = j.get("ended") or time.time()
            j.setdefault("stop_reason", T("interrupted"))
        for it in j.get("items", []):
            if it.get("state") in ("queued", "running"):
                it["state"] = "interrupted"
        j["seen_restart"] = True
        _jobs[j["id"]] = j
        # 0.6.x ģenerētie teksti ir pārbaudīti (garuma kontrole) — atzīmējam, lai ✂ tos neapšauba
        if j.get("kind") == "generate":
            for it in j.get("items", []):
                r = it.get("result") or {}
                if it.get("state") == "done" and r.get("title") is not None and not store.get_cut_ok(it["path"]):
                    try:
                        store.set_cut_ok(it["path"], store.text_sig(r.get("title", ""), r.get("description", "")))
                    except Exception:
                        pass


def _save(force: bool = False):
    global _last_save
    now = time.time()
    if not force and now - _last_save < 2:
        return
    _last_save = now
    with _lock:
        jobs = sorted(_jobs.values(), key=lambda j: j.get("created", 0))[-JOBS_KEEP:]
        keep = {j["id"] for j in jobs}
        for k in [k for k in _jobs if k not in keep]:
            _jobs.pop(k, None)
        try:
            data = copy.deepcopy(jobs)
        except RuntimeError:          # kāds pavediens tieši maina ierakstu — saglabāsim nākamreiz
            _last_save = 0
            return
    try:
        tmp = _file().with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        os.replace(tmp, _file())
    except OSError:
        pass


def start(paths: list[str], kind: str = "generate", context: str = "", autosave: bool = True,
          template_kw: list[str] | None = None, editorial: bool | None = None, root: str = "",
          illustrative: bool = False, resumed_from: str = "") -> str:
    _load()
    jid = uuid.uuid4().hex[:8]
    job = {
        "id": jid, "kind": kind, "root": root, "illustrative": illustrative, "created": time.time(),
        "total": len(paths), "done": 0, "failed": 0, "cancelled": False, "finished": False, "autosave": autosave,
        "params": {"context": context, "template_kw": template_kw or [], "editorial": editorial},
        "resumed_from": resumed_from, "notices": [],
        "items": [{"path": p, "state": "queued", "error": "", "result": None} for p in paths],
    }
    with _lock:
        _jobs[jid] = job
    _save(True)
    threading.Thread(target=_run, args=(job,), daemon=True).start()
    return jid


def _rest(j: dict) -> list[str]:
    return [it["path"] for it in j["items"]
            if it["state"] in ("queued", "running", "interrupted", "cancelled", "error") and os.path.exists(it["path"])]


def resume(jid: str, auto: bool = False) -> str:
    """Jauns darbs ar bildēm, kas palika neapstrādātas. Pārtrauktiem tā paša veida darbiem tajā pašā mapē
    atlikušās bildes apvieno, lai neviena netiktu apstrādāta divreiz."""
    _load()
    j = _jobs.get(jid)
    if not j:
        raise RuntimeError("job not found")
    group = [j] + [o for o in _jobs.values() if o is not j and (o.get("interrupted") or o.get("retry_at"))
                   and not o.get("resumed") and o.get("finished")
                   and o["kind"] == j["kind"] and o.get("root", "") == j.get("root", "")]
    rest = list(dict.fromkeys(p for g in group for p in _rest(g)))
    if not rest:
        raise RuntimeError("nothing to resume")
    pr = j.get("params") or {}
    for g in group:
        g["resumed"] = True
    _save(True)
    for g in group:
        g.pop("retry_at", None)
    nid = start(rest, j["kind"], pr.get("context", ""), j.get("autosave", True), pr.get("template_kw"),
                pr.get("editorial"), j.get("root", ""), j.get("illustrative", False), resumed_from=jid)
    if auto:
        _jobs[nid]["auto_resumed"] = True
    return nid


def _process(job, item):
    if job["cancelled"]:
        item["state"] = "cancelled"
        return
    item["state"] = "running"
    pr = job.get("params") or {}
    try:
        if job["kind"] in ("classify", "recognize"):
            item["result"] = ai.classify(item["path"])
        elif job["kind"] == "draft":
            item["result"] = ai.draft_generate(item["path"], job.get("illustrative", False))
            item["status"] = exif.read_status([item["path"]])[item["path"]]
        elif job["kind"] == "fix":
            r = ai.fix_cut(item["path"])
            item["result"] = r
            item["status"] = exif.read_status([item["path"]])[item["path"]]
        else:
            avoid = [{"title": i["result"]["title"], "description": i["result"]["description"]}
                     for i in job["items"] if i is not item and i.get("result") and i["result"].get("title")]
            res = ai.generate(item["path"], pr.get("context", ""), pr.get("editorial"), avoid,
                              job.get("illustrative", False))
            if pr.get("template_kw"):
                res["keywords"] = store.clean_keywords(res["keywords"] + pr["template_kw"])[:50]
            if job.get("autosave"):
                author = None
                default_author = (config.get("author") or "").strip()
                cur = exif.read_meta([item["path"]])[item["path"]]
                if default_author and not cur.get("author"):
                    author = default_author
                exif.write_meta(item["path"], res["title"], res["description"], res["keywords"], author,
                                location=store.location(item["path"], cur))
                store.set_cut_ok(item["path"], store.text_sig(res["title"], res["description"]))
                if store.has_draft(item["path"]):
                    store.set_draft(item["path"], None)     # jaunais teksts jau failā — vecais melnraksts nederīgs
                item["status"] = exif.read_status([item["path"]])[item["path"]]
            item["result"] = res
        item["state"] = "done"
        with _lock:
            job["done"] += 1
    except Exception as e:
        item["state"] = "error"
        item["error"] = str(e)
        with _lock:
            job["failed"] += 1
            job["done"] += 1
        _stop_check(job, e)
    finally:
        notes = ai.take_notices()
        if notes:
            with _lock:
                for n in notes:
                    if n not in job["notices"]:
                        job["notices"].append(n)
        _save()
        if item.get("state") == "done" and job["kind"] != "classify":
            manifest.touch([item["path"]])           # "dzīvs" manifests (0.9.0-test4)


def _stop_check(job, e: Exception) -> None:
    low = str(e).lower()
    if "limit" in low or "claude code" in low or "codex" in low or ("api" in low and "key" in low):
        job["cancelled"] = True
        job["stop_reason"] = str(e)
        if "limit" in low and config.get("auto_retry"):
            job["retry_at"] = time.time() + RETRY_AFTER


def _notices(job):
    notes = ai.take_notices()
    if notes:
        with _lock:
            for n in notes:
                if n not in job["notices"]:
                    job["notices"].append(n)


def _process_group(job, group):
    """Viena AI apskate vairākām bildēm (RF/ED + pavediens + melnraksts)."""
    if job["cancelled"]:
        for it in group:
            it["state"] = "cancelled"
        return
    for it in group:
        it["state"] = "running"
    mode = "auto" if job["kind"] == "classify" else ai.folder_mode(group[0]["path"])
    avoid = [i["result"]["draft"]["title"] for i in job["items"]
             if i.get("result") and (i["result"].get("draft") or {}).get("title")]
    try:
        res = ai.analyze([it["path"] for it in group], mode, job.get("illustrative", False), avoid)
        missing = [it for it in group if it["path"] not in res]
        for it in missing:            # ja AI kādu bildi izlaida — vēlreiz atsevišķi
            res.update(ai.analyze([it["path"]], mode, job.get("illustrative", False), avoid))
        st = exif.read_status([it["path"] for it in group])
        for it in group:
            r = res.get(it["path"])
            if r:
                it["result"], it["state"], it["status"] = r, "done", st.get(it["path"])
            else:
                it["state"], it["error"] = "error", "AI neatgrieza rezultātu / no result"
            with _lock:
                job["done"] += 1
                if not r:
                    job["failed"] += 1
    except Exception as e:
        for it in group:
            it["state"], it["error"] = "error", str(e)
            with _lock:
                job["failed"] += 1
                job["done"] += 1
        _stop_check(job, e)
    finally:
        _notices(job)
        _save()
        if job["kind"] != "classify":
            manifest.touch([it["path"] for it in group if it.get("state") == "done"])


def _groups(items, n):
    """Pēc kārtas sekojošas bildes no vienas mapes — kopā (sērijas kadri)."""
    out, cur = [], []
    for it in items:
        if cur and (len(cur) >= n or os.path.dirname(cur[0]["path"]) != os.path.dirname(it["path"])):
            out.append(cur)
            cur = []
        cur.append(it)
    if cur:
        out.append(cur)
    return out


def _run(job):
    workers = max(1, min(4, int(config.get("parallel") or 1)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        if job["kind"] in ("classify", "recognize"):
            n = max(1, min(8, int(config.get("batch_photos") or 4)))
            items = sorted(job["items"], key=lambda it: it["path"].lower())
            for g in _groups(items, n):
                ex.submit(_process_group, job, g)
        else:
            for item in job["items"]:
                ex.submit(_process, job, item)
    for it in job["items"]:
        if it["state"] == "queued":
            it["state"] = "cancelled"
    job["finished"] = True
    job["ended"] = time.time()
    _save(True)


def cancel(jid: str) -> None:
    j = _jobs.get(jid)
    if j:
        j["cancelled"] = True


def snapshot(jid: str | None = None) -> list[dict]:
    _load()
    with _lock:
        jobs = [_jobs[jid]] if jid and jid in _jobs else sorted(_jobs.values(), key=lambda j: j.get("created", 0))
        for _ in range(5):
            try:
                out = copy.deepcopy(jobs)
                break
            except RuntimeError:
                time.sleep(0.01)
        else:
            out = []
    for j in out:
        j["remaining"] = sum(1 for it in j["items"]
                             if it["state"] in ("interrupted", "cancelled", "error")) if j.get("finished") else 0
    # cik dažādu bilžu kopā gaida turpināšanu (pārtrauktie darbi var pārklāties)
    pend = {it["path"] for j in out if j.get("interrupted") and not j.get("resumed")
            for it in j["items"] if it["state"] in ("interrupted", "cancelled", "error")}
    for j in out:
        j["pending_total"] = len(pend)
    return out


RETRY_AFTER = 30 * 60


def busy() -> bool:
    """Darbs notiek vai gaida automātisku atsākšanu pēc limita."""
    return any(not j.get("finished") or (j.get("retry_at") and not j.get("resumed")) for j in _jobs.values())


def _retry_loop():
    while True:
        time.sleep(30)
        try:
            for j in list(_jobs.values()):
                if j.get("finished") and j.get("retry_at") and not j.get("resumed") and time.time() >= j["retry_at"]:
                    if not config.get("auto_retry"):
                        j.pop("retry_at", None)
                        continue
                    try:
                        resume(j["id"], auto=True)
                    except Exception:
                        j.pop("retry_at", None)
        except Exception:
            pass


threading.Thread(target=_retry_loop, daemon=True).start()


def mark_applied(jid: str | None) -> None:
    j = _jobs.get(jid or "")
    if j:
        j["applied"] = True
        _save(True)


def clear_finished() -> None:
    _load()
    with _lock:
        for k in [k for k, v in _jobs.items() if v.get("finished")]:
            _jobs.pop(k, None)
    _save(True)
