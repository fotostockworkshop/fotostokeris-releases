"""ChatGPT caur OpenAI Codex CLI (`codex exec`) — izmanto lietotāja ChatGPT abonementu bez papildu maksas."""
from __future__ import annotations

import glob
import json
import os
import re
import shlex
import shutil
import subprocess
import threading
from pathlib import Path

from . import config
from .i18n import T

IS_WIN = config.IS_WIN
NO_WINDOW = 0x08000000 if IS_WIN else 0
NEW_CONSOLE = 0x00000010 if IS_WIN else 0


class CodexError(Exception):
    pass


def _candidates() -> list[str]:
    home = Path.home()
    c = []
    custom = (config.get("codex_path") or "").strip().strip('"')
    if custom:
        c.append(custom)
    w = shutil.which("codex")
    if w:
        c.append(w)
    if IS_WIN:
        local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
        appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
        c += [os.path.join(local, "Programs", "OpenAI", "Codex", "bin", "codex.exe"),
              str(home / ".local" / "bin" / "codex.exe"),
              os.path.join(local, "Microsoft", "WinGet", "Links", "codex.exe"),
              os.path.join(appdata, "npm", "codex.cmd")]
    else:
        c += [str(home / ".local" / "bin" / "codex"), "/opt/homebrew/bin/codex", "/usr/local/bin/codex",
              str(home / ".npm-global" / "bin" / "codex")]
        c += sorted(glob.glob(str(home / ".nvm" / "versions" / "node" / "*" / "bin" / "codex")), reverse=True)
    return c


def find() -> list[str] | None:
    for p in _candidates():
        if p and os.path.isfile(p):
            if IS_WIN and p.lower().endswith((".cmd", ".bat")):
                base = os.path.dirname(p)
                js = os.path.join(base, "node_modules", "@openai", "codex", "bin", "codex.js")
                node = os.path.join(base, "node.exe")
                node = node if os.path.isfile(node) else shutil.which("node")
                if os.path.isfile(js) and node:
                    return [node, js]
                continue
            return [p]
    return None


def _env() -> dict:
    env = dict(os.environ)
    # API atslēga vides mainīgajos liktu Codex maksāt no API konta abonementa vietā
    env.pop("OPENAI_API_KEY", None)
    env.pop("CODEX_API_KEY", None)
    extra = [str(Path.home() / ".local" / "bin"), "/opt/homebrew/bin", "/usr/local/bin"]
    if IS_WIN:
        local = os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))
        extra.append(os.path.join(local, "Programs", "OpenAI", "Codex", "bin"))
    env["PATH"] = os.pathsep.join([env.get("PATH", "")] + extra)
    env.setdefault("NO_COLOR", "1")
    return env


_help: dict[str, str] = {}
_help_lock = threading.Lock()


def _help_text(cmd: list[str]) -> str:
    key = "|".join(cmd)
    with _help_lock:
        if key not in _help:
            try:
                r = subprocess.run(cmd + ["exec", "--help"], capture_output=True, timeout=60, env=_env(),
                                   creationflags=NO_WINDOW)
                _help[key] = (r.stdout + r.stderr).decode("utf-8", "replace")
            except Exception:
                _help[key] = ""
        return _help[key]


def info() -> dict:
    cmd = find()
    if not cmd:
        return {"found": False}
    try:
        r = subprocess.run(cmd + ["--version"], capture_output=True, timeout=60, env=_env(), creationflags=NO_WINDOW)
        ver = r.stdout.decode("utf-8", "replace").strip()
    except Exception as e:
        ver = f"{T('error')}: {e}"
    return {"found": True, "path": cmd[-1], "version": ver}


def auth_status() -> dict:
    cmd = find()
    if not cmd:
        return {"found": False, "loggedIn": False}
    try:
        r = subprocess.run(cmd + ["login", "status"], capture_output=True, timeout=60, env=_env(),
                           creationflags=NO_WINDOW)
        out = (r.stdout + r.stderr).decode("utf-8", "replace").strip()
    except Exception as e:
        return {"found": True, "loggedIn": False, "error": str(e)}
    logged = r.returncode == 0 and "not logged in" not in out.lower()
    method = "chatgpt" if "chatgpt" in out.lower() else ("api_key" if "api key" in out.lower() else "")
    return {"found": True, "loggedIn": logged, "method": method, "text": out.splitlines()[0] if out else ""}


def _open_terminal(args: list[str]) -> dict:
    env = _env()
    if IS_WIN:
        subprocess.Popen(["cmd.exe", "/k"] + args, creationflags=NEW_CONSOLE, env=env)
        return {"mode": "terminal"}
    if config.IS_MAC:
        line = " ".join(shlex.quote(a) for a in args)
        script = f'tell application "Terminal"\nactivate\ndo script "{line}"\nend tell'
        subprocess.Popen(["osascript", "-e", script])
        return {"mode": "terminal"}
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xterm", "-e"]):
        if shutil.which(term[0]):
            subprocess.Popen(term + args, env=env)
            return {"mode": "terminal"}
    raise CodexError(" ".join(args))


def login() -> dict:
    """Atver termināli ar `codex login` — pārlūkā lietotājs pieslēdzas ar savu ChatGPT kontu."""
    cmd = find()
    if not cmd:
        raise CodexError(T("codex_missing"))
    return _open_terminal(cmd + ["login"])


def logout() -> None:
    cmd = find()
    if not cmd:
        raise CodexError(T("codex_missing"))
    subprocess.run(cmd + ["logout"], capture_output=True, timeout=60, env=_env(), creationflags=NO_WINDOW)


WIN_INSTALL = (
    "Write-Host 'Uzstada ChatGPT Codex / Installing ChatGPT Codex...';"
    # Windows PowerShell 5.1 pēc noklusējuma neielādē RuntimeInformation — bez tā instalētājs krīt ar
    # "The property 'OSArchitecture' cannot be found"
    "try { Add-Type -AssemblyName System.Runtime.InteropServices.RuntimeInformation } catch {};"
    "irm https://chatgpt.com/codex/install.ps1 | iex;"
    "Write-Host ''; Write-Host 'Gatavs! Atgriezies Vardotaja un spied Pieslegties ChatGPT. / Done! Go back to Vardotajs and click Sign in to ChatGPT.'"
)
MAC_INSTALL = (
    "curl -fsSL https://chatgpt.com/codex/install.sh | sh; "
    "echo; echo 'Gatavs! Atgriezies Vārdotājā un spied Pieslēgties ChatGPT. / Done! Go back to Vārdotājs and click Sign in to ChatGPT.'"
)


def install() -> dict:
    if IS_WIN:
        # ja ir PowerShell 7 (pwsh), lietojam to — tajā instalētājs strādā bez apiešanas
        ps = shutil.which("pwsh") or "powershell.exe"
        subprocess.Popen([ps, "-NoExit", "-ExecutionPolicy", "Bypass", "-Command", WIN_INSTALL],
                         creationflags=NEW_CONSOLE)
        return {"mode": "terminal"}
    if config.IS_MAC:
        script = ('tell application "Terminal"\nactivate\ndo script "'
                  + MAC_INSTALL.replace("\\", "\\\\").replace('"', '\\"') + '"\nend tell')
        subprocess.Popen(["osascript", "-e", script])
        return {"mode": "terminal"}
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["xterm", "-e"]):
        if shutil.which(term[0]):
            subprocess.Popen(term + ["bash", "-c", MAC_INSTALL + "; exec bash"])
            return {"mode": "terminal"}
    raise CodexError("curl -fsSL https://chatgpt.com/codex/install.sh | sh")


def strict_schema(schema: dict) -> dict:
    """OpenAI strukturētajai atbildei vajag additionalProperties=false un visus laukus 'required'."""
    s = json.loads(json.dumps(schema))

    def fix(node):
        if isinstance(node, dict):
            if node.get("type") == "object":
                node["additionalProperties"] = False
                props = node.get("properties") or {}
                node["required"] = list(props.keys())
            for v in node.values():
                fix(v)
        elif isinstance(node, list):
            for v in node:
                fix(v)
    fix(s)
    return s


def _err_text(out: str) -> str:
    """No Codex izvades izvelk saprotamu kļūdas tekstu."""
    lines = [ln.strip() for ln in out.splitlines() if ln.strip()]
    for ln in reversed(lines):
        if ln.startswith("{"):
            try:
                d = json.loads(ln)
                err = d.get("error")
                msg = d.get("message") or (err.get("message") if isinstance(err, dict) else err)
                if msg:
                    return str(msg)
            except json.JSONDecodeError:
                pass
        if re.search(r"error|limit|login|unauthori|401|403|429", ln, re.I):
            return ln
    return lines[-1] if lines else ""


def run(prompt: str, workdir: str, schema: dict, image, model: str = "", web: bool = False) -> dict:
    cmd = find()
    if not cmd:
        raise CodexError(T("codex_missing"))
    helptext = _help_text(cmd)
    schema_file = os.path.join(workdir, "schema.json")
    out_file = os.path.join(workdir, "answer.json")
    with open(schema_file, "w", encoding="utf-8") as f:
        json.dump(strict_schema(schema), f)
    args = cmd + ["exec"]
    if "--skip-git-repo-check" in helptext or not helptext:
        args.append("--skip-git-repo-check")
    if "--ephemeral" in helptext:
        args.append("--ephemeral")
    if "--sandbox" in helptext or not helptext:
        args += ["--sandbox", "read-only"]
    if "--color" in helptext:
        args += ["--color", "never"]
    if "--cd" in helptext or not helptext:
        args += ["--cd", workdir]
    args += ["--output-schema", schema_file, "--output-last-message", out_file]
    if web:
        args += ["-c", 'web_search="live"']
    model = (model or "").strip()
    if model:
        args += ["--model", model]
    for im in ([image] if isinstance(image, str) else (image or [])):
        args += ["--image", im]
    args.append("-")                     # uzdevums no stdin
    full = ("You are an expert assistant for stock photographers. Do not run any commands and do not edit files: "
            "just look at the attached photo(s) (if any; they are attached in the order photo1, photo2 …) and answer with JSON only.\n\n" + prompt)
    try:
        r = subprocess.run(args, input=full.encode("utf-8"), capture_output=True, cwd=workdir, timeout=300,
                           env=_env(), creationflags=NO_WINDOW)
    except subprocess.TimeoutExpired:
        raise CodexError(T("codex_timeout"))
    text = ""
    if os.path.isfile(out_file):
        with open(out_file, encoding="utf-8", errors="replace") as f:
            text = f.read().strip()
    if r.returncode != 0 or not text:
        out = (r.stdout + b"\n" + r.stderr).decode("utf-8", "replace")
        msg = _err_text(out) or f"exit {r.returncode}"
        low = msg.lower()
        if "usage limit" in low or "rate limit" in low or "429" in low or "limit" in low:
            msg = T("limit") + " (ChatGPT) " + msg
        elif "login" in low or "unauthori" in low or "401" in low or "auth" in low:
            msg = T("codex_not_logged_in") + " (" + msg + ")"
        raise CodexError(msg[:500])
    try:
        d = json.loads(text)
        if isinstance(d, dict):
            return d
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        try:
            return json.loads(m.group(0))
        except json.JSONDecodeError:
            pass
    raise CodexError(T("bad_json") + text[:300])


def test() -> str:
    import tempfile
    d = tempfile.mkdtemp(prefix="vardotajs_")
    try:
        res = run('Answer with JSON {"reply": "OK"}.', d,
                  {"type": "object", "properties": {"reply": {"type": "string"}}, "required": ["reply"]}, None,
                  config.get("codex_model") or "")
        return T("test_ok") + " (ChatGPT): " + str(res.get("reply", ""))[:40]
    finally:
        shutil.rmtree(d, ignore_errors=True)
