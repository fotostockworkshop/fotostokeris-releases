"""Poga "Uz iesniegšanu" (noteikumi docs/fotostokeris-dati.md §7a "MANIFESTI — VIENKĀRŠOTĀ KĀRTĪBA", test18).

Katrs klikšķis = jauni, neatkarīgi sūtījumi — viens katram veidam (RF / ED / EDI):
  <ready_dir>/<GADS>/<YYYY-MM-DD>-<VEIDS>-<kods>/   (sūtīšanas datums; bez RF/ED apakšmapēm, nekāda papildināšana)
Faili:  <kods>_<oriģinālais>  (atstarpes → _, arī RAW / .xmp); manifestā orig_file un series_code.
Neaprakstītas / bez zināma veida bildes nesūta. Tukšu darba mapi dzēš (tikai tehniski faili) vai jautā.
(Vecās mapes <YYYY-MM>_<Sērija>_<kods>/RF|ED/ paliek, kā ir.)
Drošā pārvietošana: kopē uz .part → salīdzina izmēru un MD5 → pārdēvē → tikai tad dzēš oriģinālu.
Uzskaite: prepared.json datu mapē (rezerves kopijās). Dublikāti — lēmums cilvēkam (plan atdod "dups").
Atsaukšana — submit_undo.json (tādā pašā drošā veidā atpakaļ).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import time
import uuid
from datetime import datetime, timezone

from . import ai, config, exif, manifest, sorter, specs, store
from .i18n import T

SIMILAR_BITS = 6
SYNC_MARKS = ("synologydrive", "onedrive", "cloudstorage", "google drive", "my drive", "dropbox")


def _undo_file():
    return config.app_dir() / "submit_undo.json"


def ready_dir() -> str:
    return str(config.get("ready_dir") or "").strip()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --------------------------------------------------------------------------- uzskaite (prepared.json)

_ledger: config.JsonStore | None = None


def ledger() -> config.JsonStore:
    global _ledger
    if _ledger is None:
        _ledger = config.JsonStore(config.app_dir() / "prepared.json", {"format": 1, "codes": {}, "items": []})
    return _ledger


def stats() -> dict:
    items = ledger().data.get("items") or []
    by_cat: dict[str, int] = {}
    for it in items:
        c = it.get("category") or "?"
        by_cat[c] = by_cat.get(c, 0) + 1
    return {"total": len(items), "by_cat": by_cat,
            "waiting": sum(1 for it in items if it.get("status") == "copied"),
            "series": len(ledger().data.get("codes") or {})}


# --------------------------------------------------------------------------- palīgi

def verify_mode(root: str | None = None) -> str:
    m = str(config.get("ready_verify") or "auto")
    if m in ("direct", "sync"):
        return m
    low = (root or ready_dir()).lower().replace("\\", "/")
    return "sync" if any(s in low for s in SYNC_MARKS) else "direct"


def _md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_copy(src: str, dst: str, remove_src: bool = True) -> tuple[int, str]:
    """Kopē → pārbauda (izmērs + MD5) → pārdēvē → dzēš oriģinālu. Nesakritība → oriģināls paliek, kļūda."""
    import shutil
    part = dst + ".part"
    try:
        shutil.copy2(src, part)
        s1, s2 = os.path.getsize(src), os.path.getsize(part)
        m1, m2 = _md5(src), _md5(part)
        if s1 != s2 or m1 != m2:
            raise OSError(T("copy_mismatch"))
        if os.path.exists(dst):
            raise OSError(T("dest_exists"))
        os.replace(part, dst)
    except Exception:
        try:
            if os.path.exists(part):
                os.remove(part)
        except OSError:
            pass
        raise
    if remove_src:
        os.remove(src)
    return s1, m1


def _rfed_names() -> dict:
    return {(config.get("sort_rf_name") or "RF").lower(): config.get("sort_rf_name") or "RF",
            (config.get("sort_ed_name") or "ED").lower(): config.get("sort_ed_name") or "ED"}


def _series_parts(src: str) -> tuple[str, str | None]:
    """(sērijas mape, RF/ED apakšmape vai None)."""
    src = src.rstrip("\\/")
    base = os.path.basename(src)
    names = _rfed_names()
    if base.lower() in names and os.path.basename(os.path.dirname(src)):
        return os.path.dirname(src), names[base.lower()]
    return src, None


DATE_HEAD = re.compile(r"^\d{4}[.\-_ ]\d{1,2}(?:[.\-_ ]\d{1,2})?[.\-_ ]*")


def _clean_name(series_dir: str) -> str:
    n = os.path.basename(series_dir.rstrip("\\/"))
    if n.lower() in manifest.GENERIC and os.path.basename(os.path.dirname(series_dir.rstrip("\\/"))):
        n = os.path.basename(os.path.dirname(series_dir.rstrip("\\/")))      # "Bali/jpg" → "Bali" (test11)
    n = DATE_HEAD.sub("", n).strip(" ._-") or n
    return manifest._safe(n)[:60]


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _code_for(sids: list[str], used_plan: dict) -> str:
    codes = ledger().data.get("codes") or {}
    for c, v in codes.items():
        if any(s in (v.get("series_ids") or []) for s in sids):
            return c
    for c, v in used_plan.items():
        if any(s in v for s in sids):
            return c
    sid = sids[0]
    for n in (4, 6, 8, 32):
        c = sid[:n]
        if c not in codes and c not in used_plan:
            return c
    return sid


# --------------------------------------------------------------------------- plāns

TYPES = ("RF", "ED", "EDI")
_LAST: dict = {}          # pēdējā plāna kodi (lai logā rādītais kods = īstais; {atslēga: {veids: kods}})
TECH = {"_fotostokeris", ".fotostokeris", "thumbs.db", ".ds_store", "desktop.ini"}


def _new_code(root: str, day: str, used: set) -> str:
    codes = ledger().data.get("codes") or {}
    names = set()
    yp = os.path.join(root, day[:4])
    try:
        names = {n.lower() for n in os.listdir(yp)}
    except OSError:
        pass
    while True:
        c = uuid.uuid4().hex[:4]
        if c in codes or c in used or any(n.endswith("-" + c) for n in names):
            continue
        return c


def _type_of(it: dict) -> str:
    c = it.get("category") or ""
    if c == "RF" and ai.has_ed_prefix(it.get("description") or ""):
        c = "ED"
    return c if c in TYPES else ""


def plan(paths: list[str]) -> dict:
    root = ready_dir()
    if not root:
        raise RuntimeError(T("ready_dir_none"))
    if not os.path.isdir(root):
        raise RuntimeError(T("ready_dir_missing", path=root))
    rootn = os.path.normcase(os.path.abspath(root)) + os.sep
    ps = []
    for p in paths:
        p = os.path.abspath(p)
        if not os.path.normcase(os.path.dirname(p) + os.sep).startswith(rootn) and p not in ps:
            ps.append(p)                               # jau iesniegšanai gatavo mapē — nesūta
    info = manifest.scan(ps)
    by_type: dict[str, list[str]] = {}
    skipped = {"undescribed": 0, "unknown": 0}
    bad, fix = [], {}
    for p in ps:
        it = info.get(p)
        if not it:
            continue
        if it["status"] != "ready":
            skipped["undescribed"] += 1
            continue
        t = _type_of(it)
        if not t:
            skipped["unknown"] += 1
            continue
        try:                                            # aģentūru prasības (test20, lēmums 2026-11-04 21:07)
            ck = specs.check(p)
        except Exception as e:
            print("prasību pārbaude:", p, e)
            ck = {"ok": True}
        if ck.get("bad"):
            bad.append({"path": p, "file": os.path.basename(p), "why": ck["bad"]})
            continue
        if ck.get("fix"):
            fix[p] = ck["fix"]
        by_type.setdefault(t, []).append(p)

    day = time.strftime("%Y-%m-%d")
    used: set = set()
    key = (day, tuple(sorted(ps)))
    prev = _LAST.get(key) or {}
    codes_now = ledger().data.get("codes") or {}
    out_groups, dups = [], []
    led = [it for it in ledger().data.get("items") or [] if it.get("phash") or it.get("size")]
    for t in TYPES:
        gp = by_type.get(t)
        if not gp:
            continue
        code = prev.get(t)
        if not code or code in codes_now or code in used or os.path.exists(os.path.join(root, day[:4], f"{day}-{t}-{code}")):
            code = _new_code(root, day, used)
        used.add(code)
        prev[t] = code
        name = f"{day}-{t}-{code}"
        dest = os.path.join(root, day[:4], name)
        renames = []
        for p in gp:
            base = os.path.basename(p)
            renames.append({"path": p, "name": f"{code}_{base}".replace(" ", "_")})
            it = info.get(p) or {}
            size = os.path.getsize(p) if os.path.exists(p) else 0
            ph = it.get("phash") or ""
            best = None
            for e in led:
                same = (e.get("size") == size and ph and e.get("phash") == ph)
                hd = _ham(ph, e.get("phash")) if ph and e.get("phash") else 99
                if same or hd <= SIMILAR_BITS:
                    k = 0 if same else hd + 1
                    if best is None or k < best[0]:
                        best = (k, e)
            if best:
                e = best[1]
                dups.append({"path": p, "file": base, "other": {
                    "kind": "same" if best[0] == 0 else "similar", "path": e.get("path"),
                    "name": e.get("name"), "orig": e.get("orig"), "series": e.get("series"),
                    "at": e.get("at"), "computer": e.get("computer"), "status": e.get("status"),
                    "exists": bool(e.get("path") and os.path.exists(e["path"]))}})
        srcs = sorted({os.path.dirname(p) for p in gp}, key=str.lower)
        out_groups.append({"type": t, "src": ", ".join(os.path.basename(x) for x in srcs), "srcs": srcs,
                           "dest": dest, "name": name, "paths": gp, "renames": renames, "code": code,
                           "items": {p: info.get(p) or {} for p in gp}})
    _LAST.clear()
    _LAST[key] = prev
    lim = specs.limits()
    return {"root": root, "groups": out_groups, "dups": dups, "verify": verify_mode(root), "skipped": skipped,
            "count": sum(len(g["paths"]) for g in out_groups), "bad": bad, "fix": fix,
            "max_mb": lim["max_mb"][0] if "max_mb" in lim else None, "agencies": specs.targets()}


# --------------------------------------------------------------------------- pārvietošana

def _leftovers(folder: str) -> list[str] | None:
    """None — mapes nav; [] — tikai tehniski faili; citādi — atlikušie faili / mapes."""
    try:
        names = os.listdir(folder)
    except OSError:
        return None
    return [n for n in names if n.lower() not in TECH and not n.startswith("._")]


def _rmtree(folder: str) -> None:
    import shutil
    shutil.rmtree(folder)


def move(paths: list[str], skip: list[str] | None = None) -> dict:
    skipn = {os.path.normcase(os.path.abspath(p)) for p in skip or []}
    pl = plan(paths)
    mode = pl["verify"]
    batch = uuid.uuid4().hex[:12]
    computer = platform.node() or "?"
    if computer.lower().endswith(".local"):   # Mac tehniskā aste (lietotājs 2026-11-04)
        computer = computer[:-6]
    done, errors, dests, made_dirs, new_items, sids = [], [], [], [], [], []
    made_files, compressed = [], []
    srcs: set = set()
    led = ledger()
    for g in pl["groups"]:
        dest, code = g["dest"], g["code"]
        todo = [r for r in g["renames"] if os.path.normcase(r["path"]) not in skipn]
        if not todo:
            continue
        for d in (os.path.dirname(dest), dest):
            if not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
                made_dirs.append(d)
        sid = uuid.uuid4().hex
        orig_names, originals = {}, {}
        for r in todo:
            p = r["path"]
            srcs.add(os.path.dirname(p))
            stem_old = os.path.splitext(os.path.basename(p))[0]
            stem_new = os.path.splitext(r["name"])[0]
            main_rec, comps = None, []
            small = None                 # par liela — saspiestā kopija; oriģināls → <sūtījums>/Original/ (test20)
            if p in pl["fix"]:
                odir = os.path.join(dest, specs.ORIGINAL_DIR)
                tmp = os.path.join(dest, "." + r["name"] + ".tmp.jpg")
                try:
                    info = specs.compress(p, tmp)
                    exif.copy_meta(p, tmp, info["w"], info["h"])
                    if not os.path.isdir(odir):
                        os.makedirs(odir, exist_ok=True)
                        made_dirs.append(odir)
                    small = (tmp, info, odir)
                except Exception as e:
                    try:
                        if os.path.exists(tmp):
                            os.remove(tmp)
                    except OSError:
                        pass
                    errors.append(f"{os.path.basename(p)}: {e}")
                    continue
            for c in sorter._companions(p):
                cb = os.path.basename(c)
                cnew = (stem_new + cb[len(stem_old):] if cb.lower().startswith(stem_old.lower())
                        else f"{code}_{cb}").replace(" ", "_")
                try:
                    if c == p and small:
                        tmp, info, odir = small
                        dst = sorter._unique(os.path.join(dest, cnew))
                        odst = os.path.join(odir, os.path.basename(dst))
                        osize, omd5 = _safe_copy(c, odst)          # oriģināls → Original/ (tas pats nosaukums)
                        os.replace(tmp, dst)
                        made_files.append(dst)
                        store.move_photo(c, dst)
                        done.append({"src": c, "dst": odst, "main": True, "notes": dst})
                        size, md5 = os.path.getsize(dst), _md5(dst)
                        rec = {"orig": cb, "name": os.path.basename(dst), "size": size, "md5": md5,
                               "original": {"file": f"{specs.ORIGINAL_DIR}/{os.path.basename(odst)}", "bytes": osize, "md5": omd5}}
                        originals[os.path.splitext(rec["name"])[0]] = rec["original"]
                        compressed.append({"file": cb, "from_mb": info["from_mb"], "to_mb": info["to_mb"], "scaled": info["scaled"]})
                        small = None
                    else:
                        dst = sorter._unique(os.path.join(dest, cnew))
                        size, md5 = _safe_copy(c, dst)
                        store.move_photo(c, dst)
                        done.append({"src": c, "dst": dst, "main": c == p})
                        rec = {"orig": cb, "name": os.path.basename(dst), "size": size, "md5": md5}
                    if c == p:
                        main_rec = (rec, dst)
                    else:
                        comps.append(rec)
                except OSError as e:
                    errors.append(f"{cb}: {e}")
            if small:                                     # oriģinālu neizdevās pārvietot — saspiesto prom
                try:
                    os.remove(small[0])
                except OSError:
                    pass
            if not main_rec:
                continue
            rec, dst = main_rec
            orig_names[os.path.splitext(rec["name"])[0]] = rec["orig"]
            it = g["items"].get(p) or {}
            new_items.append({
                "id": uuid.uuid4().hex[:12], "batch": batch, "code": code, "series": g["name"], "series_id": sid,
                "category": g["type"], "phash": it.get("phash", ""), "size": rec["size"], "md5": rec["md5"],
                "orig": rec["orig"], "name": rec["name"], "companions": comps, "at": _now(), "computer": computer,
                "src": p, "path": dst, "verify": mode, "status": "verified" if mode == "direct" else "copied",
                "verified_at": _now() if mode == "direct" else "", **({"original": rec["original"]} if rec.get("original") else {})})
        if not orig_names:
            continue
        try:
            manifest.build(dest, series_id=sid, series_code=code, orig=orig_names, drive_now=True, category=g["type"],
                           originals=originals)
            sids.append(sid)
        except Exception as e:
            errors.append(f"manifests: {e}")
        with led.lock:
            led.data.setdefault("codes", {})[code] = {"series_ids": [sid], "name": g["name"], "folder": dest,
                                                      "type": g["type"]}
        dests.append(dest)
    with led.lock:
        led.data.setdefault("items", []).extend(new_items)
        led.save()
    # darba mapes: vecais manifests prom (vienkāršotā kārtība); tukšās — dzēš vai jautā
    removed, ask = [], []
    for src in sorted(srcs, key=str.lower):
        try:
            if manifest.find(src):
                manifest.remove(src)
        except Exception:
            pass
        if manifest._images(src):
            continue
        left = _leftovers(src)
        if left is None:
            continue
        if not left:
            try:
                _rmtree(src)
                removed.append(src)
            except OSError as e:
                errors.append(f"{os.path.basename(src)}: {e}")
        else:
            ask.append({"folder": src, "name": os.path.basename(src), "files": left[:8], "n": len(left)})
    with open(_undo_file(), "w", encoding="utf-8") as f:
        json.dump({"time": time.time(), "batch": batch, "moves": done, "dirs": made_dirs, "sids": sids, "made": made_files},
                  f, ensure_ascii=False)
    return {"count": sum(1 for d in done if d["main"]), "errors": errors, "dests": dests, "root": pl["root"],
            "verify": mode, "skipped": len(skipn), "removed_dirs": removed, "ask_dirs": ask,
            "compressed": compressed, "bad": pl["bad"]}


def rmdirs(folders: list[str]) -> dict:
    """Lietotājs apstiprināja — dzēš tukšās darba mapes (bez bildēm) ar visu atlikušo saturu."""
    root = os.path.normcase(os.path.abspath(ready_dir() or "\0")) + os.sep
    done, errors = [], []
    for f in folders:
        f = os.path.abspath(f)
        if os.path.normcase(f + os.sep).startswith(root) or manifest._images(f) or not os.path.isdir(f):
            continue
        try:
            _rmtree(f)
            done.append(f)
        except OSError as e:
            errors.append(f"{os.path.basename(f)}: {e}")
    return {"removed": done, "errors": errors}


def undo() -> dict:
    try:
        with open(_undo_file(), encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError):
        raise RuntimeError(T("nothing_to_undo"))
    back, errors, folders = 0, [], set()
    for m in reversed(d.get("moves") or []):
        try:
            if os.path.exists(m["dst"]) and not os.path.exists(m["src"]):
                os.makedirs(os.path.dirname(m["src"]), exist_ok=True)
                _safe_copy(m["dst"], m["src"])
                store.move_photo(m.get("notes") or m["dst"], m["src"])
                back += 1 if m.get("main") else 0
                folders.add(os.path.dirname(m["dst"]))
        except OSError as e:
            errors.append(f"{os.path.basename(m['dst'])}: {e}")
    for f in d.get("made") or []:                            # saspiestās kopijas (oriģināls jau atpakaļ)
        try:
            if os.path.exists(f):
                os.remove(f)
            folders.add(os.path.dirname(f))
        except OSError as e:
            errors.append(f"{os.path.basename(f)}: {e}")
    for f in folders:                                        # sūtījuma mapes: manifests prom, tukšu mapi dzēš
        try:
            if not manifest._images(f):
                manifest.remove(f)
                if os.path.isdir(f) and not os.listdir(f):
                    os.rmdir(f)
        except Exception as e:
            print("manifests (atsaukšana):", f, e)
    for dd in reversed(d.get("dirs") or []):                 # tukšās jaunās mapes (sūtījums, gads)
        try:
            if os.path.isdir(dd) and not os.listdir(dd):
                os.rmdir(dd)
        except OSError:
            pass
    sids = d.get("sids") or []
    if sids:                                                 # Google `Sutijumi` — rindā un jau augšupielādētie
        from core import manifests_drive
        for s in sids:
            manifests_drive.unqueue(s)
        if manifests_drive.enabled():
            def _del():
                try:
                    manifests_drive.delete_where(manifests_drive.SUTIJUMI, lambda x: x.get("series_id") in sids)
                except Exception as e:
                    print("Google (atsaukšana):", e)
            import threading
            threading.Thread(target=_del, daemon=True).start()
    if d.get("batch"):
        led = ledger()
        with led.lock:
            led.data["items"] = [it for it in led.data.get("items") or [] if it.get("batch") != d["batch"]]
            used = {it.get("code") for it in led.data["items"]}
            led.data["codes"] = {c: v for c, v in (led.data.get("codes") or {}).items() if c in used}
            led.save()
    if not errors:
        os.remove(_undo_file())
    return {"count": back, "errors": errors}


def places() -> list[dict]:
    """Ātrās izvēles iestatījumos: OneDrive, Google Drive, NAS (ja atrasti)."""
    from pathlib import Path
    out = []
    try:
        from core.server import _onedrive
        od = str(config.get("onedrive_dir") or "") or _onedrive()
        if od and os.path.isdir(od):
            out.append({"kind": "onedrive", "path": od})
    except Exception:
        pass
    home = Path.home()
    gd = []
    if config.IS_MAC:
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/My Drive"))
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/Mans disks"))
    gd += [str(home / "Google Drive" / "My Drive"), str(home / "Google Drive"), str(home / "My Drive")]
    if config.IS_WIN:
        import string
        for L in string.ascii_uppercase:
            for n in ("My Drive", "Mans disks", "Мой диск"):
                gd.append(f"{L}:\\{n}")
    for p in gd:
        if os.path.isdir(p):
            out.append({"kind": "gdrive", "path": p})
            break
    if config.IS_MAC and os.path.isdir("/Volumes"):
        for n in sorted(os.listdir("/Volumes")):
            p = os.path.join("/Volumes", n)
            if not n.startswith(".") and os.path.isdir(p) and not os.path.islink(p) and n not in ("Macintosh HD", "Recovery"):
                out.append({"kind": "nas", "path": p})
    sd = home / "SynologyDrive"
    if sd.is_dir():
        out.append({"kind": "nas", "path": str(sd)})
    return out


# --------------------------------------------------------------------------- vienreizējs labojums (test16)

def fix_ed_placement() -> dict:
    """Vienreiz: līdz test16 nešķirotas ED bildes "Uz iesniegšanu" nonāca sērijas galvenajā mapē ar RF. Datorā, kur
    iesniegšanai gatavā mape pieejama (darba datorā — NAS), pārskata PAŠU MAPI `<ready_dir>/<GADS>/<sērija>/` (ne uzskaiti —
    no Mac nosūtītajām tajā ir Mac ceļi; test17) un ED bildes droši pārvieto uz `<sērija>/ED/`; uzskaite (pēc koda un
    faila nosaukuma), manifesti (+ Drive). Atzīme `ed_fix_done` = "v2:…"."""
    if str(config.get("ed_fix_done") or "").startswith("v2:"):
        return {}
    root = ready_dir()
    if not root or not os.path.isdir(root):
        return {}
    ed_name = config.get("sort_ed_name") or "ED"
    names = set(_rfed_names())
    led = ledger()
    by_name = {}
    for rec in led.data.get("items") or []:
        if rec.get("name"):
            by_name.setdefault(rec["name"].lower(), []).append(rec)
    dirs = []
    for y in sorted(os.listdir(root)):
        yp = os.path.join(root, y)
        if re.match(r"^\d{4}$", y) and os.path.isdir(yp):
            for sname in sorted(os.listdir(yp)):
                d = os.path.join(yp, sname)
                if os.path.isdir(d) and sname.lower() not in names and manifest._images(d):
                    dirs.append(d)
    moved_n, errors = 0, []
    shared = []
    try:
        sd = manifest.shared_dir()
        for f in os.listdir(sd):
            if f.endswith(".json") and "__" in f:
                try:
                    shared.append(json.load(open(os.path.join(sd, f), encoding="utf-8")))
                except (OSError, ValueError):
                    pass
    except OSError:
        pass
    for d in dirs:
        if not manifest.find(d):
            # sērijas mapē manifesta nav (agrāk `.fotostokeris` Synology nesinhronizēja) — tas pats ID no kopīgās mapes
            sname = os.path.basename(d)
            code = sname.rsplit("_", 1)[-1]
            sid = next((x.get("series_id") for x in shared if x.get("series_id") and
                        os.path.basename((x.get("folder") or "").replace("\\", "/").rstrip("/")) == sname), None)
            try:
                manifest.build(d, series_id=sid, series_code=code)
            except Exception as e:
                errors.append(f"manifests {sname}: {e}")
                continue
        m = manifest.load(d) or {}
        todo = []
        for it in m.get("images") or []:
            if it.get("status") == "moved":
                continue
            p = os.path.join(d, it.get("file") or "")
            if it.get("file") and os.path.isfile(p) and (it.get("category") in ("ED", "EDI")
                                                          or ai.has_ed_prefix(it.get("description") or "")):
                todo.append(p)
        if not todo:
            continue
        dest = os.path.join(d, ed_name)
        os.makedirs(dest, exist_ok=True)
        moved = {}
        for p in todo:
            stem = os.path.splitext(os.path.basename(p))[0]
            try:
                for c in sorter._companions(p):
                    dst = sorter._unique(os.path.join(dest, os.path.basename(c)))
                    _safe_copy(c, dst)
                    store.move_photo(c, dst)
                    if c == p:
                        with led.lock:
                            for rec in by_name.get(os.path.basename(p).lower(), []):
                                rec["path"], rec["category"] = dst, "ED"
                moved[stem] = dest
                moved_n += 1
            except OSError as e:
                errors.append(f"{os.path.basename(p)}: {e}")
        led.save()
        try:
            manifest.build(dest, series_code=m.get("series_code"), drive_now=True)
            if manifest._images(d):
                manifest.build(d, moved=moved, drive_now=True)
            else:
                ds = (manifest.load(dest) or {}).get("series_id") or ""
                manifest.mark_moved_drive(d, moved, ds)
                manifest.remove(d)
        except Exception as e:
            errors.append(f"manifests {os.path.basename(d)}: {e}")
        print(f"ED labojums: {os.path.basename(d)} → {ed_name}: {len(moved)} bildes")
    config.update({"ed_fix_done": "v2:" + _now()})
    print(f"ED labojums: pārbaudītas {len(dirs)} sērijas, pārvietotas {moved_n} bildes",
          "; kļūdas: " + "; ".join(errors) if errors else "")
    return {"moved": moved_n, "series": len(dirs), "errors": errors}
