"""Vārdotāja iestatījumi un datu mape — no kopīgā koda core/ (noteikumi §5, §10).

Vārdotāja atslēgām vēsturiski nav prefiksa (noteikumi §5). Kopīgās (lang, author, target_agencies, my_rules,
show_splash, update_channel, backup_* …) ir core.config.CORE_DEFAULTS."""
from __future__ import annotations

DEFAULT_STYLE = (
    "Write in natural, fluent English for international stock buyers.\n"
    "Title: one factual sentence describing who/what is in the image and what is happening — "
    "main subject first, then the setting and the most important details.\n"
    "Description: similar meaning to the title and also explanatory, but worded DIFFERENTLY "
    "(different words and sentence structure, not a copy), because variety helps the photo appear "
    "in more search results. When the place is known, it may end with the location "
    "(for example: '..., Kintamani, Bali, Indonesia').\n"
    "Keywords: single words only, lowercase, no duplicates. The first 10 must be the most "
    "searched-for words that will help buyers find and buy this photo. Every keyword must match "
    "something actually visible or true in the image: objects, places, events, people types, "
    "actions, colors, mood. Never use the words 'editorial' or 'illustrative'."
)

DEFAULT_RFED = (
    "EDITORIAL (ED) if the photo contains any of: recognizable faces or people who are the subject "
    "or clearly identifiable (no model release); visible logos, brand names, trademarks or "
    "readable commercial signage; identifiable artworks, murals or copyrighted designs; "
    "newsworthy or public events, festivals, ceremonies, protests, sports events; private "
    "property interiors or recognizable vehicles with plates.\n"
    "ROYALTY-FREE (RF) if: landscapes, nature, animals, plants, food, textures, architecture "
    "without logos, people only as tiny unrecognizable silhouettes or from behind, and no brands.\n"
    "UNSURE if it is a borderline case (e.g. small but possibly recognizable faces, partly visible logos)."
)

DEFAULT_SETTINGS = {
    "ai_provider": "claude_cli",        # claude_cli | codex_cli | api | openai_api
    "claude_path": "",                  # tukšs = atrast automātiski
    "api_key": "",
    "model": "sonnet",                  # sonnet | opus | haiku | pilns modeļa ID
    "codex_path": "",                   # ChatGPT (Codex CLI); tukšs = atrast automātiski
    "codex_model": "",                  # tukšs = ChatGPT plāna noklusējuma modelis
    "openai_key": "",
    "openai_model": "gpt-5-mini",
    "fallback_ai": True,                # kad limits beidzies — pārslēgties uz otru abonementu (Claude <-> ChatGPT)
    "show_translation": True,           # turot peli virs virsraksta/apraksta, rādīt latvisko tulkojumu
    "eco_images": False,                # ekonomiskais režīms: AI sūta 1024 px (nevis 1568 px)
    "batch_photos": 4,                  # cik bildes sūtīt AI vienā pieprasījumā (apskate/šķirošana)
    "auto_retry": True,
    "auto_move_cat": False,             # mainot RF<->ED redaktorā RF/ED mapē — pārvietot bez jautāšanas                 # pēc limita mēģināt atsākt automātiski ik pēc ~30 min
    "parallel": 2,
    "keywords_count": 45,
    "title_max": 150,
    "description_max": 140,
    "default_country": "Latvia",       # valsts failā, ja vieta nav zināma (lietotājs 2026-11-13; test20)
    "ed_description_max": 200,          # ED aprakstam ar "CITY, COUNTRY – DATE:" priekšā
    "style": DEFAULT_STYLE,
    "single_word_keywords": True,       # sadalīt "lake batur" -> "lake", "batur"
    "editorial_word": "editorial",      # ja mapes ceļā ir šis vārds -> editorial režīms
    "editorial_format": True,           # ED virsraksts: "CITY, COUNTRY – MONTH DAY, YEAR: ..."
    "send_gps": True,
    "complete_min_keywords": 5,         # cik atslēgvārdu vajag, lai bilde skaitītos "aprakstīta"
    "rfed_criteria": DEFAULT_RFED,
    "sort_rf_name": "RF",
    "sort_ed_name": "ED",               # nedrošās bildes paliek pamatmapē
    "ready_dir": "",                    # iesniegšanai gatavo bilžu mape (tukša = poga "Uz iesniegšanu" neaktīva); datora iestatījums
    "ready_verify": "auto",             # auto | direct | sync — kā pārbaudīt kopiju iesniegšanai gatavo mapē (dati §7a; datora)
    "manifest_dir": "",                 # kopīgā manifestu mape (tukša = <ready_dir>/Manifesti vai datu mapē Manifesti/)
    "drive_backfill": "",
    "ed_prefix_backfill": "",
    "ed_fix_done": "",                  # kad šajā datorā vienreiz salabotas ED bildes sēriju galvenajās mapēs (test16)           # kad šajā datorā vienreiz pārbūvēti visi manifesti ar ED piebildi (test13)               # kad šajā datorā vienreiz augšupielādēti esošie manifesti uz Google Drive (test12)
    "manifest_migrated": "",            # kad šajā datorā vienreiz pārcelti manifesti uz vienkāršoto kārtību (test18)
    "sort_manifest": True,              # šķirošanas pārskatā ķeksis "Izveidot manifestu un sīktēlus" (atceras)
    "notify_system": False,             # sistēmas paziņojumi, kad AI darbs beidzies (tikai pēc ķekša — Edge jautā atļauju)
    "last_folder": "",
    "thumb_size": 150,
}



# DEFAULT_SETTINGS — Vārdotāja noklusējumi (core.config.defaults() tos apvieno ar kopīgajiem)

from . import appdef  # noqa: E402,F401  — reģistrē Vārdotāju core/ pirms core.config lietošanas
from core.config import (IS_MAC, IS_WIN, JsonStore, app_dir, defaults, get, settings,  # noqa: E402,F401
                         setup_log, update)
