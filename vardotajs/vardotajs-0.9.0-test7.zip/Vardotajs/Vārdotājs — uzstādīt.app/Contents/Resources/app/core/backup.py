"""Rezerves kopijas (kopīgas visiem moduļiem; noteikumi §5, §9a). Analītiķis 0.3.0-test43.

Kopija = zip <Slug>-backup-YYYY-MM-DD_HHMM.zip:
  manifest.json — {app, slug, version, created, files, info}
  catalog.db    — datubāzes konsekventa kopija (sqlite backup API)
  settings.json — iestatījumi (bez datora piesaistītām vērtībām, sk. LOCAL_KEYS)
Iekšā NAV paroļu (tās ir drošajā glabātuvē), sesiju (sessions.bin), žurnālu un atjauninājumu kopiju — kopiju var
atjaunot jebkurā datorā.

Iestatījumi (kopīgās atslēgas, §5): backup_dir (tukšs = Dokumenti/Fotostokeris rezerves kopijas/<Slug>),
backup_every (never | day | week | month), backup_keep (cik pēdējās paturēt), backup_last (ISO).
Automātiski: pēc termiņa (pārbaude palaižot un ik stundu) un vienmēr pirms programmas atjaunināšanas (updater).
"""
from __future__ import annotations

import datetime as dt
import json
import os
import shutil
import sqlite3
import tempfile
import threading
import time
import zipfile
from pathlib import Path

from . import app as _app
from . import config

EVERY_DAYS = {"never": 0, "day": 1, "week": 7, "month": 30}
# datora piesaistītās vērtības — atjaunojot tās paliek šī datora (nevis kopijas) vērtības
LOCAL_KEYS = {"backup_dir", "backup_every", "backup_keep", "backup_last", "seen_version", "update_channel",
              "api_key", "openai_key", "claude_path", "codex_path", "onedrive_dir",
              "backup_google", "backup_google_last", "backup_google_err"}   # atslēgas un datora ceļi — ne kopijā
_lock = threading.Lock()
_hooks = {"before_restore": None, "after_restore": None, "info": None}


def set_hooks(before_restore=None, after_restore=None, info=None) -> None:
    """Modulis: before_restore() — aizvērt datubāzi; after_restore() — atvērt no jauna; info(db_path) → dict pārskatam."""
    _hooks.update(before_restore=before_restore, after_restore=after_restore, info=info)


def _slug() -> str:
    return _app.current().slug


def default_dir() -> Path:
    home = Path.home()
    docs = home / "Documents"
    base = docs if docs.is_dir() else home
    return base / "Fotostokeris rezerves kopijas" / _slug()


def backup_dir() -> Path:
    d = str(config.get("backup_dir") or "").strip()
    p = Path(os.path.expanduser(d)) if d else default_dir()
    return p


def _db_path() -> Path:
    return config.app_dir() / "catalog.db"


def _name(tag: str = "") -> str:
    return f"{_slug()}-backup-{dt.datetime.now():%Y-%m-%d_%H%M%S}{('-' + tag) if tag else ''}.zip"


def create(tag: str = "", dest: Path | None = None) -> dict:
    """Izveido kopiju. tag: '' | 'auto' | 'pirms-atjauninasanas' | 'pirms-atjaunosanas'."""
    with _lock:
        dest = Path(dest) if dest else backup_dir()
        dest.mkdir(parents=True, exist_ok=True)
        tmp = Path(tempfile.mkdtemp(prefix="bk-"))
        try:
            files = []
            src = _db_path()
            if src.exists():
                c = sqlite3.connect(str(src), timeout=30)
                out = sqlite3.connect(str(tmp / "catalog.db"))
                c.backup(out)
                out.close()
                c.close()
                files.append("catalog.db")
            for n in _app.current().backup_files:          # moduļa datu faili (Vārdotājs 0.9.0)
                f = config.app_dir() / n
                if f.is_file():
                    shutil.copy2(f, tmp / n)
                    files.append(n)
            st = config.settings().data
            json.dump({k: v for k, v in st.items() if k not in LOCAL_KEYS}, open(tmp / "settings.json", "w", encoding="utf-8"),
                      ensure_ascii=False, indent=1)
            files.append("settings.json")
            info = {}
            if _hooks["info"] and (tmp / "catalog.db").exists():
                try:
                    info = _hooks["info"](tmp / "catalog.db") or {}
                except Exception as e:
                    print("rezerves kopija: pārskats:", e)
            a = _app.current()
            man = {"app": a.name, "slug": a.slug, "version": a.version, "created": dt.datetime.now().isoformat(timespec="seconds"),
                   "files": files, "info": info, "tag": tag}
            json.dump(man, open(tmp / "manifest.json", "w", encoding="utf-8"), ensure_ascii=False, indent=1)
            target = dest / _name(tag)
            part = target.with_suffix(".part")
            with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED) as z:
                for f in ["manifest.json"] + files:
                    z.write(tmp / f, f)
            part.replace(target)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        config.update({"backup_last": dt.datetime.now().isoformat(timespec="seconds")})
        _prune(dest)
        size = target.stat().st_size
        print(f"rezerves kopija: {target.name} ({size // 1024} KB){' — ' + tag if tag else ''}")
        gd = False
        if not tag.startswith("pirms-") and google_on():
            gd = True
            threading.Thread(target=_to_google, args=(target,), daemon=True).start()
        return {"path": str(target), "name": target.name, "size": size, "dir": str(dest), "google": gd}


# --------------------------------------------------------------------------- Google Drive (0.9.0-test6)

def google_on() -> bool:
    """Iestatījums "Kopēt arī uz Google Drive" (backup_google) un pieslēgts Google konts (core/google.py)."""
    if not config.get("backup_google"):
        return False
    try:
        from . import google
        return google.connected()
    except Exception:
        return False


def _to_google(path: Path) -> None:
    from . import google
    try:
        google.backup_upload(path, max(1, int(config.get("backup_keep") or 10)))
        config.update({"backup_google_last": dt.datetime.now().isoformat(timespec="seconds"), "backup_google_err": ""})
        print(f"rezerves kopija: {path.name} augšupielādēta Google Drive")
    except Exception as e:
        config.update({"backup_google_err": str(e)[:200]})
        print("rezerves kopija: Google Drive augšupielāde neizdevās:", e)


def google_upload_now(name: str) -> dict:
    p = _resolve(name, None)
    _to_google(p)
    err = config.get("backup_google_err") or ""
    if err:
        raise RuntimeError(err)
    return {"name": name}


def _prune(dest: Path) -> None:
    keep = max(1, int(config.get("backup_keep") or 10))
    zs = sorted(dest.glob(f"{_slug()}-backup-*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)
    for p in zs[keep:]:
        try:
            p.unlink()
        except OSError:
            pass


def listing() -> dict:
    d = backup_dir()
    out = []
    if d.is_dir():
        for p in sorted(d.glob(f"{_slug()}-backup-*.zip"), key=lambda p: p.stat().st_mtime, reverse=True)[:50]:
            out.append({"name": p.name, "size": p.stat().st_size, "mtime": dt.datetime.fromtimestamp(p.stat().st_mtime).isoformat(timespec="seconds")})
    return {"dir": str(d), "default_dir": str(default_dir()), "items": out, "last": config.get("backup_last"),
            "every": config.get("backup_every") or "week", "keep": int(config.get("backup_keep") or 10), "next": next_due()}


def _resolve(name: str | None, data: bytes | None) -> Path:
    if data:
        tmp = Path(tempfile.mkdtemp(prefix="bk-in-")) / "upload.zip"
        tmp.write_bytes(data)
        return tmp
    if not name or "/" in name or "\\" in name or ".." in name:
        raise ValueError("bk_bad")
    p = backup_dir() / name
    if not p.is_file():
        raise ValueError("bk_bad")
    return p


def _read(p: Path) -> tuple[dict, zipfile.ZipFile]:
    try:
        z = zipfile.ZipFile(p)
        man = json.loads(z.read("manifest.json").decode("utf-8"))
    except (zipfile.BadZipFile, KeyError, ValueError):
        raise ValueError("bk_bad")
    if man.get("slug") != _slug():
        raise ValueError("bk_other")
    for n in z.namelist():
        if n not in ("manifest.json", "catalog.db", "settings.json") and n not in _app.current().backup_files:
            raise ValueError("bk_bad")
    return man, z


def preview(name: str | None = None, data: bytes | None = None) -> dict:
    p = _resolve(name, data)
    man, z = _read(p)
    z.close()
    return {"manifest": man, "name": name or "", "size": p.stat().st_size}


def restore(name: str | None = None, data: bytes | None = None) -> dict:
    """Atjauno no kopijas. Pirms tam — pašreizējo datu kopija (pirms-atjaunosanas)."""
    p = _resolve(name, data)
    man, z = _read(p)
    before = create("pirms-atjaunosanas")
    tmp = Path(tempfile.mkdtemp(prefix="bk-rs-"))
    try:
        z.extractall(tmp)
        z.close()
        if _hooks["before_restore"]:
            _hooks["before_restore"]()
        try:
            dbp = _db_path()
            if (tmp / "catalog.db").exists():
                for suf in ("-wal", "-shm"):
                    try:
                        Path(str(dbp) + suf).unlink()
                    except OSError:
                        pass
                shutil.copy2(tmp / "catalog.db", dbp)
            for n in _app.current().backup_files:
                if (tmp / n).is_file():
                    shutil.copy2(tmp / n, config.app_dir() / n)
            if (tmp / "settings.json").exists():
                vals = json.load(open(tmp / "settings.json", encoding="utf-8"))
                config.update({k: v for k, v in vals.items() if k not in LOCAL_KEYS})
        finally:
            if _hooks["after_restore"]:
                _hooks["after_restore"]()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    print(f"rezerves kopija: atjaunots no {name or 'faila'} ({man.get('created')}, v{man.get('version')}); iepriekšējie dati — {before['name']}")
    return {"manifest": man, "saved_before": before["name"]}


# --------------------------------------------------------------------------- automātiski

def next_due() -> str | None:
    days = EVERY_DAYS.get(config.get("backup_every") or "week", 7)
    if not days:
        return None
    last = config.get("backup_last")
    try:
        t = dt.datetime.fromisoformat(last) + dt.timedelta(days=days) if last else dt.datetime.now()
    except ValueError:
        t = dt.datetime.now()
    return t.isoformat(timespec="seconds")


def auto_if_due(busy=None) -> dict | None:
    n = next_due()
    if not n or dt.datetime.fromisoformat(n) > dt.datetime.now():
        return None
    if busy and busy():
        return None
    try:
        return create("auto")
    except Exception as e:
        print("rezerves kopija: neizdevās:", e)
        return None


def before_update() -> None:
    """Vienmēr pirms programmas atjaunināšanas (lietotājs 2026-10-30)."""
    try:
        create("pirms-atjauninasanas")
    except Exception as e:
        print("rezerves kopija pirms atjaunināšanas neizdevās:", e)


def start_scheduler(busy=None) -> None:
    def loop():
        time.sleep(90)
        while True:
            auto_if_due(busy)
            time.sleep(3600)
    threading.Thread(target=loop, daemon=True).start()
