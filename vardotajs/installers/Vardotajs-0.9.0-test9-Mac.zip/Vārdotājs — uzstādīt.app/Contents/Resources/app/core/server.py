"""Lokālais HTTP serveris visiem produktiem (noteikumi §3).

  GET  /            → moduļa web/index.html ({{TOKEN}} aizstāts)
  GET  /static/…    → moduļa web/
  GET  /core/…      → core/web/ (kopīgais stils, dialogi, iestatījumu rāmis)
  POST /api/<prefikss><nosaukums>  ar galveni X-Token → JSON

Kopīgie API (ar moduļa prefiksu): ping, quit, reveal, settings. Pārējos reģistrē modulis: register({...}).
"""
from __future__ import annotations

import json
import mimetypes
import os
import secrets
import subprocess
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from . import app as _app
from . import config

CORE_WEB = Path(__file__).resolve().parent / "web"
TOKEN = secrets.token_urlsafe(16)
BOOT = secrets.token_hex(6)

state = {"last_ping": time.time(), "server": None, "window_proc": None}
API: dict = {}
GET: dict = {}          # moduļa GET adreses: {"/thumb": fn(query: dict) -> (kods, baiti, tips, galvenes)} (Vārdotājs 0.9.0)
ON_SHUTDOWN: list = []  # moduļa darbības pirms izslēgšanās (piem. Vārdotājs aptur ExifTool)


def ok(**kw):
    kw.setdefault("ok", True)
    return kw


def register(funcs: dict):
    """Moduļa API: {"overview": fn, …} → /api/<prefikss>overview."""
    p = _app.current().api_prefix
    for name, fn in funcs.items():
        API[p + name] = fn


def register_get(routes: dict):
    """Moduļa GET adreses (piem. sīktēli). fn saņem vaicājuma parametrus {k: v}; žetonu pārbauda pats modulis."""
    GET.update(routes)


def base_state() -> dict:
    """Kopīgā daļa moduļa "state" atbildei."""
    a = _app.current()
    return dict(version=a.version, boot=BOOT, settings=config.settings().data, platform=sys.platform,
                app_dir=str(config.app_dir()), app=a.name, slug=a.slug)


# --------------------------------------------------------------------------- kopīgie API

def _api_ping(_):
    state["last_ping"] = time.time()
    return ok()


def _api_quit(_):
    def bye():
        time.sleep(0.3)
        shutdown()
    threading.Thread(target=bye, daemon=True).start()
    return ok()


def _api_reveal(_):
    p = str(config.app_dir())
    try:
        _open_folder(p)
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return ok()


def _api_settings(b):
    vals = dict(b.get("settings") or {})
    if "theme" in vals and vals["theme"] not in ("auto", "light", "dark", "forest"):
        vals.pop("theme")
    if "lang" in vals and vals["lang"] not in ("lv", "en", "de", "es", "uk"):
        vals.pop("lang")
    if "update_channel" in vals and vals["update_channel"] not in ("auto", "stable", "test", "off"):
        vals.pop("update_channel")
    if "target_agencies" in vals and not isinstance(vals["target_agencies"], list):
        vals.pop("target_agencies")
    if "backup_every" in vals and vals["backup_every"] not in ("never", "day", "week", "month"):
        vals.pop("backup_every")
    if "backup_keep" in vals:
        try:
            vals["backup_keep"] = max(1, min(100, int(vals["backup_keep"])))
        except (TypeError, ValueError):
            vals.pop("backup_keep")
    if "backup_google" in vals:
        vals["backup_google"] = bool(vals["backup_google"])
    if "backup_dir" in vals:
        vals["backup_dir"] = str(vals["backup_dir"] or "").strip()[:500]
    vals.pop("backup_last", None)
    from . import ai as _ai
    if "ai_roles" in vals:
        v = vals["ai_roles"]
        vals["ai_roles"] = {str(j)[:40]: [p for p in (ps or []) if p in _ai.PROVIDERS][:6]
                            for j, ps in (v.items() if isinstance(v, dict) else [])}
    if "ai_balance" in vals:
        v, clean = vals["ai_balance"], {}
        for p, b in (v.items() if isinstance(v, dict) else []):
            try:
                if p in _ai.PROVIDERS and b and str(b.get("amount", "")).strip() != "":
                    clean[p] = {"amount": round(float(b["amount"]), 2), "currency": "USD",
                                "at": str(b.get("at") or "")[:10] or __import__("datetime").date.today().isoformat()}
            except (TypeError, ValueError, AttributeError):
                pass
        vals["ai_balance"] = clean
    for k in ("gemini_model", "ollama_model", "onedrive_dir"):
        if k in vals:
            vals[k] = str(vals[k] or "").strip()[:300]
    vals = _app.current().validate_settings(vals)
    config.update(vals)
    return ok(settings=config.settings().data)


def _api_creds(b):
    """Saglabātie pieslēgšanās dati (bez parolēm!): {name: {user, saved}}."""
    from . import credentials
    names = [str(n) for n in (b.get("names") or [])]
    return ok(available=credentials.available(), backend=credentials.backend_name(),
              creds=credentials.summary(names))


def _api_cred_save(b):
    from . import credentials
    if not credentials.available():
        return {"ok": False, "error": "keyring"}
    try:
        credentials.save(str(b.get("name") or ""), str(b.get("user") or ""), b.get("password") or None)
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return ok(creds=credentials.summary([str(b.get("name"))]))


def _api_cred_forget(b):
    from . import credentials
    credentials.forget(str(b.get("name") or ""))
    return ok()


def _api_update_check(b):
    from . import updater
    return ok(**updater.check(force=bool(b.get("force"))), state=updater.status())


def _api_update_install(b):
    from . import updater
    r = updater.install(b.get("latest") if isinstance(b.get("latest"), dict) else None)
    return r if not r.get("ok") else ok(state=updater.status())


def _api_update_status(_):
    from . import updater
    return ok(state=updater.status())


def _bk_err(e: Exception) -> dict:
    from .i18n import T
    k = str(e)
    return {"ok": False, "error": T(k) if k.startswith("bk_") else k}


def _bk_data(b):
    if b.get("gdrive_id"):                          # kopija no Google Drive (0.9.0-test6)
        from . import google
        return google.download(str(b["gdrive_id"]))
    d = b.get("data")
    if not d:
        return None
    import base64
    if "," in d[:100]:
        d = d.split(",", 1)[1]
    return base64.b64decode(d)


def _api_google(b):
    """Google konts (core/google.py): {do: status|connect|disconnect|backups|upload, …}."""
    from . import backup, google
    do = b.get("do") or "status"
    try:
        if do == "connect":
            return ok(**google.connect())
        if do == "disconnect":
            google.disconnect()
            return ok(**google.status())
        if do == "backups":
            return ok(items=google.backup_list(), last=config.get("backup_google_last"), err=config.get("backup_google_err") or "")
        if do == "upload":
            return ok(**backup.google_upload_now(str(b.get("name") or "")))
        return ok(**google.status(check=bool(b.get("check"))))
    except google.GoogleError as e:
        return {"ok": False, "error": e.code or str(e), "detail": str(e)}
    except Exception as e:
        return {"ok": False, "error": "offline" if isinstance(e, OSError) else str(e)[:200]}


def _api_backup_list(_):
    from . import backup
    return ok(**backup.listing())


def _api_backup_create(_):
    from . import backup
    try:
        return ok(**backup.create(), list=backup.listing())
    except Exception as e:
        return _bk_err(e)


def _api_backup_preview(b):
    from . import backup
    try:
        return ok(**backup.preview(b.get("name"), _bk_data(b)))
    except Exception as e:
        return _bk_err(e)


def _api_backup_restore(b):
    from . import backup
    if _app.current().busy():
        return {"ok": False, "error": "busy"}
    try:
        return ok(**backup.restore(b.get("name"), _bk_data(b)), list=backup.listing())
    except Exception as e:
        return _bk_err(e)


def _onedrive() -> str:
    """Datorā sinhronizētā OneDrive mape (Windows %OneDrive%, Mac ~/Library/CloudStorage/OneDrive-*), ja ir."""
    import glob
    from pathlib import Path
    for v in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        p = os.environ.get(v)
        if p and os.path.isdir(p):
            return p
    hits = sorted(glob.glob(str(Path.home() / "Library" / "CloudStorage" / "OneDrive*"))) + \
        [str(p) for p in (Path.home() / "OneDrive",) if p.is_dir()]
    return hits[0] if hits else ""


_pick_lock = threading.Lock()
_inflight_lock = threading.Lock()


def _api_pick_folder(b):
    """Sistēmas mapes izvēles logs (test44). {onedrive: true} — atgriež OneDrive mapi bez loga."""
    import subprocess
    from . import config
    if b.get("onedrive"):
        p = _onedrive()
        return ok(path=p) if p else {"ok": False, "error": "no_onedrive"}
    start = str(b.get("start") or "")
    if not _pick_lock.acquire(blocking=False):          # logs jau atvērts — otru neveram (2026-11-02, Windows)
        return {"ok": False, "error": "pick_busy"}
    try:
        if config.IS_MAC:
            # Mac logā ir poga "New Folder" — var izveidot jaunu mapi
            scr = 'POSIX path of (choose folder with prompt "Izvēlies mapi (vai izveido jaunu ar New Folder)")'
            if start and os.path.isdir(start):
                scr = f'POSIX path of (choose folder with prompt "Izvēlies mapi (vai izveido jaunu ar New Folder)" default location POSIX file "{start}")'
            r = subprocess.run(["osascript", "-e", scr], capture_output=True, text=True, timeout=600)
            p = r.stdout.strip()
        elif config.IS_WIN:
            # 2026-11-02: logs atvērās AIZ visiem logiem un bez pogas uzdevumjoslā → tagad īpašnieks "TopMost" forma;
            # sāk no `start` (piem. OneDrive); izvade UTF-8 (garumzīmes ceļā)
            ps = ("[Console]::OutputEncoding = [Text.Encoding]::UTF8; Add-Type -AssemblyName System.Windows.Forms; "
                  "$o = New-Object System.Windows.Forms.Form -Property @{TopMost = $true; ShowInTaskbar = $false}; "
                  "$d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.ShowNewFolderButton = $true; "
                  "if ($env:FS_START -and (Test-Path -LiteralPath $env:FS_START)) { $d.SelectedPath = $env:FS_START }; "
                  "if ($d.ShowDialog($o) -eq 'OK') { [Console]::Out.Write($d.SelectedPath) }; $o.Dispose()")
            exe = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
            r = subprocess.run([exe if os.path.isfile(exe) else "powershell", "-NoProfile", "-STA", "-Command", ps],
                               capture_output=True, timeout=600, creationflags=0x08000000,
                               env=dict(os.environ, FS_START=start))
            p = r.stdout.decode("utf-8", "replace").strip()
            if r.returncode and not p:
                print("mapes izvēle (PowerShell):", r.stderr.decode("utf-8", "replace")[:200])
        else:
            return {"ok": False, "error": "unsupported"}
    except Exception as e:
        print("mapes izvēle:", e)
        return {"ok": False, "error": str(e)[:120]}
    finally:
        _pick_lock.release()
    return ok(path=p.rstrip("/\\") if len(p) > 3 else p, cancelled=not p)


def _ai_call(fn):
    from . import ai
    try:
        return ok(**(fn(ai) or {}))
    except ai.AIError as e:
        return {"ok": False, "error": str(e)}
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}


def _api_ai_status(_):
    return _ai_call(lambda ai: {"status": ai.status(), "pages": ai.KEY_PAGES})


def _api_ai_check(b):
    return _ai_call(lambda ai: {"res": ai.check(str(b.get("p")))})


def _api_ai_login(b):
    return _ai_call(lambda ai: ai.login(str(b.get("p"))))


def _api_ai_connect(b):
    return _ai_call(lambda ai: ai.connect(str(b.get("p"))))


def _api_ai_switch(b):
    return _ai_call(lambda ai: ai.switch(str(b.get("p"))))


def _api_ai_install(b):
    return _ai_call(lambda ai: ai.install(str(b.get("p"))))


def _api_ai_logout(b):
    return _ai_call(lambda ai: ai.logout(str(b.get("p"))))


def _api_ai_key(b):
    def f(ai):
        if b.get("forget"):
            ai.key_forget(str(b.get("p")))
        else:
            ai.key_save(str(b.get("p")), str(b.get("key") or ""))
            return {"res": ai.check(str(b.get("p")))}
    return _ai_call(f)


def _api_open_url(b):
    """Atver oficiālo lapu (atslēgas izveide / uzstādīšana) parastajā pārlūkā — tikai zināmās adreses."""
    from . import ai, browser
    u = str(b.get("url") or "")
    if u not in ai.KEY_PAGES.values():
        return {"ok": False, "error": "url"}
    browser.open_url(u)
    return ok()


def _api_backup_open(_):
    from . import backup
    p = backup.backup_dir()
    try:
        p.mkdir(parents=True, exist_ok=True)
        _open_folder(str(p))
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return ok()


def _api_whatsnew(_):
    from . import updater
    return ok(**updater.whats_new())


def _api_whatsnew_seen(_):
    from . import updater
    updater.mark_seen()
    return ok()


def _register_core():
    register({"ping": _api_ping, "quit": _api_quit, "reveal": _api_reveal, "settings": _api_settings,
              "creds": _api_creds, "cred_save": _api_cred_save, "cred_forget": _api_cred_forget,
              "update_check": _api_update_check, "update_install": _api_update_install,
              "update_status": _api_update_status, "whatsnew": _api_whatsnew, "whatsnew_seen": _api_whatsnew_seen,
              "ai_status": _api_ai_status, "ai_check": _api_ai_check, "ai_login": _api_ai_login,
              "ai_install": _api_ai_install, "ai_connect": _api_ai_connect, "ai_switch": _api_ai_switch, "ai_logout": _api_ai_logout, "ai_key": _api_ai_key, "open_url": _api_open_url,
              "pick_folder": _api_pick_folder, "onedrive": lambda b: ok(path=_onedrive()),
              "backup_list": _api_backup_list, "backup_create": _api_backup_create, "backup_preview": _api_backup_preview,
              "backup_restore": _api_backup_restore, "backup_open": _api_backup_open, "google": _api_google})


# --------------------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", {"Cache-Control": "no-store"})

    def _file(self, root: Path, rel: str):
        f = (root / rel).resolve()
        if root.resolve() in f.parents and f.is_file():
            ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            return self._send(200, f.read_bytes(), ctype, {"Cache-Control": "no-cache"})
        return self._send(404, b"not found", "text/plain")

    def do_GET(self):
        u = urlparse(self.path)
        web = _app.current().web_dir
        # "/<slug>" — Edge/Chrome lietotnes logam (launcher): katram modulim savs adreses ceļš, lai Windows uzdevumjoslā
        # Vārdotājs un Analītiķis nebūtu sagrupēti vienā pogā (Chromium lietotnes ID = adrese bez porta + profils)
        if u.path in ("/", "/index.html", "/" + _app.current().slug.lower(), "/" + _app.current().slug.lower() + "/"):
            html = (web / "index.html").read_text(encoding="utf-8").replace("{{TOKEN}}", TOKEN) \
                .replace("{{V}}", f"{_app.current().version}-{BOOT}")   # pēc atjaunināšanas — svaigi faili
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8", {"Cache-Control": "no-store"})
        if u.path.startswith("/static/"):
            return self._file(web, u.path[len("/static/"):])
        if u.path.startswith("/core/"):
            return self._file(CORE_WEB, u.path[len("/core/"):])
        if u.path in GET:
            from urllib.parse import parse_qs
            try:
                code, body, ctype, extra = GET[u.path]({k: v[0] for k, v in parse_qs(u.query).items()})
            except Exception:
                traceback.print_exc()
                code, body, ctype, extra = 500, b"", "text/plain", None
            return self._send(code, body, ctype, extra)
        return self._send(404, b"not found", "text/plain")

    def do_POST(self):
        u = urlparse(self.path)
        if not u.path.startswith("/api/"):
            return self._send(404, b"not found", "text/plain")
        if self.headers.get("X-Token") != TOKEN:
            return self._json({"ok": False, "error": "forbidden"}, 403)
        fn = API.get(u.path[5:])
        if not fn:
            return self._json({"ok": False, "error": "unknown api " + u.path[5:]}, 404)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        except json.JSONDecodeError:
            return self._json({"ok": False, "error": "bad JSON"}, 400)
        state["last_ping"] = time.time()
        with _inflight_lock:
            state["inflight"] = state.get("inflight", 0) + 1
        try:
            return self._json(fn(body))
        except Exception as e:
            traceback.print_exc()
            return self._json({"ok": False, "error": str(e)}, 200)
        finally:
            with _inflight_lock:
                state["inflight"] = max(0, state.get("inflight", 1) - 1)
            state["last_ping"] = time.time()


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        """Logs aizvērts / lapa pārlādēta pieprasījuma laikā — tā nav kļūda (žurnālā nerakstām)."""
        if isinstance(sys.exc_info()[1], (ConnectionResetError, BrokenPipeError, ConnectionAbortedError)):
            return
        super().handle_error(request, client_address)


def stop_previous() -> int:
    """Aptur iepriekš palaistu šī produkta instanci (arī vecāku versiju)."""
    import re as _re
    import urllib.request as _ur
    a = _app.current()
    opener = _ur.build_opener(_ur.ProxyHandler({}))
    stopped = 0
    for port in a.ports:
        base = f"http://127.0.0.1:{port}/"
        try:
            html = opener.open(base, timeout=1.5).read().decode("utf-8", "replace")
        except Exception:
            continue
        if a.name not in html and a.slug not in html:
            continue
        m = _re.search(r'window\.TOKEN\s*=\s*"([^"]+)"', html)
        if not m:
            continue
        try:
            req = _ur.Request(base + "api/" + a.api_prefix + "quit", data=b"{}", method="POST",
                              headers={"X-Token": m.group(1), "Content-Type": "application/json"})
            opener.open(req, timeout=3).read()
            stopped += 1
        except Exception:
            pass
        for _ in range(30):
            try:
                opener.open(base, timeout=0.5)
                time.sleep(0.2)
            except Exception:
                break
    return stopped


def start(port: int = 0) -> tuple[ThreadingHTTPServer, str]:
    _register_core()
    try:
        stop_previous()
    except Exception as e:
        print("stop_previous:", e)
    srv = None
    for p in ([port] if port else list(_app.current().ports) + [0]):
        try:
            srv = Server(("127.0.0.1", p), Handler)
            break
        except OSError:
            continue
    if srv is None:
        srv = Server(("127.0.0.1", 0), Handler)
    srv.daemon_threads = True
    state["server"] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}/"


def shutdown():
    for fn in ON_SHUTDOWN:
        try:
            fn()
        except Exception as e:
            print("izslēgšanās:", e)
    srv = state.get("server")
    if srv:
        threading.Thread(target=srv.shutdown, daemon=True).start()
    os._exit(0)


def window_alive() -> bool:
    """Vai mūsu atvērtais Edge/Chrome lietotnes logs vēl ir atvērts (ja to izdevās izsekot)."""
    p = state.get("window_proc")
    try:
        if p is not None and p.poll() is None:
            return True
    except Exception:
        pass
    return _win_profile_alive()


_prof_cache = {"t": 0.0, "v": False}


def _win_profile_alive() -> bool:
    """2026-11-03 (Windows, log-1): pa nakti serveris izslēdzās "nav ziņu no lapas", lai gan logs bija atvērts —
    Edge miegā aptur lapas taimerus, un sākotnējais Edge process var būt beidzies (Edge pārstartējas pats).
    Tāpēc pirms izslēgšanās pārbaudām, vai vēl darbojas kāds Edge/Chrome process ar MŪSU profilu (--user-data-dir)."""
    from . import config
    prof = state.get("window_profile")
    if not (config.IS_WIN and prof):
        return False
    now = time.time()
    if now - _prof_cache["t"] < 60:
        return _prof_cache["v"]
    v = False
    try:
        exe = os.path.join(os.environ.get("SystemRoot", r"C:\Windows"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
        ps = ("Get-CimInstance Win32_Process -Filter \"Name='msedge.exe' OR Name='chrome.exe'\" | "
              "ForEach-Object { $_.CommandLine } | Out-String -Width 4096")
        r = subprocess.run([exe if os.path.isfile(exe) else "powershell", "-NoProfile", "-Command", ps],
                           capture_output=True, timeout=30, creationflags=0x08000000)
        out = r.stdout.decode("utf-8", "replace").lower().replace("/", "\\")
        v = os.path.normpath(prof).lower() in out
    except Exception as e:
        print("loga pārbaude:", e)
    _prof_cache.update(t=now, v=v)
    return v


def _win_front(path: str):
    """Windows: atvērtā Explorer mape bieži paliek AIZ mūsu loga (fona process nedrīkst nest logu priekšā).
    Atrodam jauno Explorer logu pēc mapes nosaukuma un uzliekam to priekšā (2026-11-03)."""
    import ctypes
    from ctypes import wintypes
    u = ctypes.windll.user32
    name = os.path.basename(os.path.normpath(path)).lower()
    found = []
    PROC = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)

    def cb(h, _):
        if not u.IsWindowVisible(h):
            return True
        cls = ctypes.create_unicode_buffer(64); u.GetClassNameW(h, cls, 64)
        if cls.value != "CabinetWClass":
            return True
        n = u.GetWindowTextLengthW(h); t = ctypes.create_unicode_buffer(n + 1); u.GetWindowTextW(h, t, n + 1)
        if name and (t.value.lower() == name or name in t.value.lower()):
            found.append(h)
        return True
    for _ in range(20):                        # līdz ~5 s, kamēr Explorer atver logu
        time.sleep(0.25)
        found.clear(); u.EnumWindows(PROC(cb), 0)
        if found:
            break
    if not found:
        return
    h = found[0]
    try:
        u.keybd_event(0x12, 0, 0, 0); u.keybd_event(0x12, 0, 2, 0)    # Alt — atļauj SetForegroundWindow
        u.ShowWindow(h, 9)                                            # SW_RESTORE
        u.SetWindowPos(h, -1, 0, 0, 0, 0, 0x0003)                     # TOPMOST (bez izmēra/vietas maiņas)
        u.SetWindowPos(h, -2, 0, 0, 0, 0, 0x0003)                     # atpakaļ parasts
        u.SetForegroundWindow(h)
    except Exception as e:
        print("mapes logs priekšā:", e)


def _open_folder(p: str):
    from . import config
    if config.IS_WIN:
        p = os.path.normpath(p)
        subprocess.Popen(["explorer", p])
        threading.Thread(target=_win_front, args=(p,), daemon=True).start()
    elif config.IS_MAC:
        subprocess.Popen(["open", p])
    else:
        subprocess.Popen(["xdg-open", p])


def idle_watch(minutes: int = 5):
    """Pārlūka režīmā: ja logs aizvērts (nav 'ping') un darbs nenotiek — beidzam darbu.

    Datora miegs: kamēr dators guļ, ne lapa, ne serveris nestrādā; pamostoties pulkstenis ir "pārlēcis"
    uz priekšu, un bez šīs pārbaudes serveris uzreiz izslēgtos (lapā "Failed to fetch"). Tāpēc, ja starp
    pārbaudēm pagājis daudz vairāk laika nekā gaidīts, uzskatām, ka dators gulēja, un sākam skaitīt no jauna.
    Kamēr mūsu logs (Edge/Chrome process) vēl ir atvērts, neizslēdzamies nekad."""
    step = 20

    def run():
        prev = time.time()
        while True:
            time.sleep(step)
            now = time.time()
            if now - prev > step * 3:                     # dators gulēja (vai pulkstenis pārlēca)
                print(f"pamodos pēc {int(now - prev)} s pārtraukuma — gaidu lapu no jauna")
                state["last_ping"] = now
            prev = now
            if window_alive() or _app.current().busy() or state.get("inflight", 0) > 0:
                continue          # 2026-11-02: kamēr pieprasījums vēl iet (piem. atvērts mapes logs) — neizslēdzamies
            if now - state["last_ping"] > minutes * 60:
                print("logs aizvērts (nav ziņu no lapas) — beidzu darbu")
                shutdown()
    threading.Thread(target=run, daemon=True).start()
