"""Fotostokera moduļu ikonas vienotā stilā (docs/ikonas.md).

Pamats (kopīgs visiem): base.svg.tmpl — tumša vinjete apkārt, zils noapaļots kvadrāts ar ciānu režģi, mirdzošiem punktiem
un ciānu malu. Modulis dod tikai simbolu: <modulis>.symbol.svg (+ <modulis>.defs.svg — savi gradienti).

Lietošana (no repozitorija saknes):  python3 core/icons/make_icons.py [modulis ...]
Rezultāts: <modulis>/dev/icon/ikona_<modulis>.svg, _1024.png, _512.png, <Slug>.icns, <Slug>.ico
Vajag: Pillow; PNG zīmēšanai — Playwright ar Chromium (Claude darba vidē ir).
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MODS = {"analitikis": ("Analitikis", "Analītiķa oficiālā ikona un logo"),
        "vardotajs": ("Vardotajs", "Vārdotāja oficiālā ikona un logo"),
        "tirgotajs": ("Tirgotajs", "Tirgotāja oficiālā ikona un logo"),
        # pilnā Fotostokera komplekts (docs/ikonas.md "Komplekts v2") — rezultāts core/icons/out/<nosaukums>/
        "fotostokeris": ("Fotostokeris", "Fotostokera (pilnās programmas) ikona un logo"),
        "fotostokeris_embl": (None, "Fotostokera emblēma (banneris, dokumentācija)"),
        "iestatijumi": (None, "Josla: Iestatījumi"), "pieslegumi": (None, "Josla: Pieslēgumi"),
        "ai_asistents": (None, "Josla: AI asistents"), "palidziba": (None, "Josla: Palīdzība"),
        "kas_jauns": (None, "Josla: Kas jauns"), "dati": (None, "Josla: Darbs ar datiem")}
MINI_BOX = "64 64 384 384"      # mini variants: tikai simbols (bez pamata), apgriezts līdz simbola laukumam
JS = r"""
const { chromium } = require('playwright'); const fs = require('fs');
(async () => { const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1024, height: 1024 } });
  const s = fs.readFileSync(process.argv[2], 'utf8').replace('<svg', '<svg width="1024" height="1024"');
  await p.setContent('<body style="margin:0;background:transparent">' + s + '</body>');
  await p.screenshot({ path: process.argv[3], omitBackground: true }); await b.close(); })();
"""


def _render(svg_path: Path, png: Path, size: int) -> None:
    js = Path("/tmp/_mkicon.js")
    js.write_text(JS.replace("1024", str(size)))
    subprocess.run(["node", str(js), str(svg_path), str(png)], check=True)


def build(mod: str) -> None:
    slug, comment = MODS[mod]
    base = (HERE / "base.svg.tmpl").read_text(encoding="utf-8")
    defs = (HERE / f"{mod}.defs.svg").read_text(encoding="utf-8") if (HERE / f"{mod}.defs.svg").exists() else ""
    sym = (HERE / f"{mod}.symbol.svg").read_text(encoding="utf-8")
    svg = base.replace("{COMMENT}", comment).replace("{DEFS}", defs) + sym + "</svg>\n"
    out = ROOT / mod / "dev" / "icon" if (ROOT / mod).is_dir() else HERE / "out" / mod
    out.mkdir(parents=True, exist_ok=True)
    f = out / f"ikona_{mod}.svg"
    f.write_text(svg, encoding="utf-8")
    png = out / f"ikona_{mod}_1024.png"
    _render(f, png, 1024)
    from PIL import Image
    im = Image.open(png).convert("RGBA")
    im.resize((512, 512), Image.LANCZOS).save(out / f"ikona_{mod}_512.png")
    if slug:
        im.save(out / f"{slug}.icns")
        im.save(out / f"{slug}.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
    # mini variants joslai: tikai simbols uz caurspīdīga fona (defs no pamata — gradienti, ēnas)
    head = base[:base.index("  </defs>") + len("  </defs>")].replace("{COMMENT}", comment + " — mini").replace("{DEFS}", defs)
    head = head.replace('viewBox="0 0 512 512"', f'viewBox="{MINI_BOX}"')
    mf = out / f"mini_{mod}.svg"
    mf.write_text(head + "\n" + sym + "</svg>\n", encoding="utf-8")
    _render(mf, out / f"mini_{mod}_128.png", 128)
    print("gatavs:", out)


if __name__ == "__main__":
    for m in sys.argv[1:] or list(MODS):
        build(m)
