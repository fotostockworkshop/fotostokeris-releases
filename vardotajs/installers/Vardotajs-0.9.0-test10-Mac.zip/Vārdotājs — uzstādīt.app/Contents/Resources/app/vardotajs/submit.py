"""Poga "Uz iesniegšanu" (0.9.0-test4; test9 — noteikumi docs/fotostokeris-dati.md §7a "Struktūra iesniegšanai gatavo mapē").

Mapes:  <ready_dir>/<GADS>/<YYYY-MM>_<Sērija>_<kods>/RF|ED/   (GADS — kad pārvietots, YYYY-MM — agrākā uzņemšana)
Faili:  <kods>_<oriģinālais>  (arī RAW / .xmp ar to pašu nosaukumu); manifestā orig_file un series_code.
Drošā pārvietošana: kopē uz .part → salīdzina izmēru un MD5 → pārdēvē → tikai tad dzēš oriģinālu.
Uzskaite: prepared.json datu mapē (rezerves kopijās). Dublikāti — lēmums cilvēkam (plan atdod "dups").
Atsaukšana — submit_undo.json (tādā pašā drošā veidā atpakaļ).
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import time
import uuid
from datetime import datetime, timezone

from . import config, manifest, sorter, store
from .i18n import T

SIMILAR_BITS = 6
SYNC_MARKS = ("synologydrive", "onedrive", "cloudstorage", "google drive", "my drive", "dropbox")


def _undo_file():
    return config.app_dir() / "submit_undo.json"


def ready_dir() -> str:
    return str(config.get("ready_dir") or "").strip()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# --------------------------------------------------------------------------- uzskaite (prepared.json)

_ledger: config.JsonStore | None = None


def ledger() -> config.JsonStore:
    global _ledger
    if _ledger is None:
        _ledger = config.JsonStore(config.app_dir() / "prepared.json", {"format": 1, "codes": {}, "items": []})
    return _ledger


def stats() -> dict:
    items = ledger().data.get("items") or []
    by_cat: dict[str, int] = {}
    for it in items:
        c = it.get("category") or "?"
        by_cat[c] = by_cat.get(c, 0) + 1
    return {"total": len(items), "by_cat": by_cat,
            "waiting": sum(1 for it in items if it.get("status") == "copied"),
            "series": len(ledger().data.get("codes") or {})}


# --------------------------------------------------------------------------- palīgi

def verify_mode(root: str | None = None) -> str:
    m = str(config.get("ready_verify") or "auto")
    if m in ("direct", "sync"):
        return m
    low = (root or ready_dir()).lower().replace("\\", "/")
    return "sync" if any(s in low for s in SYNC_MARKS) else "direct"


def _md5(path: str) -> str:
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_copy(src: str, dst: str, remove_src: bool = True) -> tuple[int, str]:
    """Kopē → pārbauda (izmērs + MD5) → pārdēvē → dzēš oriģinālu. Nesakritība → oriģināls paliek, kļūda."""
    import shutil
    part = dst + ".part"
    try:
        shutil.copy2(src, part)
        s1, s2 = os.path.getsize(src), os.path.getsize(part)
        m1, m2 = _md5(src), _md5(part)
        if s1 != s2 or m1 != m2:
            raise OSError(T("copy_mismatch"))
        if os.path.exists(dst):
            raise OSError(T("dest_exists"))
        os.replace(part, dst)
    except Exception:
        try:
            if os.path.exists(part):
                os.remove(part)
        except OSError:
            pass
        raise
    if remove_src:
        os.remove(src)
    return s1, m1


def _rfed_names() -> dict:
    return {(config.get("sort_rf_name") or "RF").lower(): config.get("sort_rf_name") or "RF",
            (config.get("sort_ed_name") or "ED").lower(): config.get("sort_ed_name") or "ED"}


def _series_parts(src: str) -> tuple[str, str | None]:
    """(sērijas mape, RF/ED apakšmape vai None)."""
    src = src.rstrip("\\/")
    base = os.path.basename(src)
    names = _rfed_names()
    if base.lower() in names and os.path.basename(os.path.dirname(src)):
        return os.path.dirname(src), names[base.lower()]
    return src, None


DATE_HEAD = re.compile(r"^\d{4}[.\-_ ]\d{1,2}(?:[.\-_ ]\d{1,2})?[.\-_ ]*")


def _clean_name(series_dir: str) -> str:
    n = os.path.basename(series_dir.rstrip("\\/"))
    n = DATE_HEAD.sub("", n).strip(" ._-") or n
    return manifest._safe(n)[:60]


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _code_for(sids: list[str], used_plan: dict) -> str:
    codes = ledger().data.get("codes") or {}
    for c, v in codes.items():
        if any(s in (v.get("series_ids") or []) for s in sids):
            return c
    for c, v in used_plan.items():
        if any(s in v for s in sids):
            return c
    sid = sids[0]
    for n in (4, 6, 8, 32):
        c = sid[:n]
        if c not in codes and c not in used_plan:
            return c
    return sid


# --------------------------------------------------------------------------- plāns

def plan(paths: list[str]) -> dict:
    root = ready_dir()
    if not root:
        raise RuntimeError(T("ready_dir_none"))
    if not os.path.isdir(root):
        raise RuntimeError(T("ready_dir_missing", path=root))
    rootn = os.path.normcase(os.path.abspath(root)) + os.sep
    by_src: dict[str, list[str]] = {}
    for p in paths:
        src = os.path.dirname(os.path.abspath(p))
        if os.path.normcase(src + os.sep).startswith(rootn):
            continue                                  # jau ir iesniegšanai gatavo mapē
        by_src.setdefault(src, []).append(os.path.abspath(p))

    # sērijas: RF un ED vienas sērijas apakšmapes → viena sērijas mape un kods
    series: dict[str, dict] = {}
    for src, ps in by_src.items():
        sdir, sub = _series_parts(src)
        m = manifest.load(src)
        if not m or any(os.path.splitext(os.path.basename(p))[0] not in
                        {it.get("stem") for it in m.get("images") or []} for p in ps):
            m = manifest.build(src) and manifest.load(src)
        m = m or {}
        s = series.setdefault(os.path.normcase(sdir), {"dir": sdir, "groups": [], "sids": [], "dates": [], "code": None})
        sids = [m.get("series_id")] if m.get("series_id") else []
        # brāļu RF/ED manifesti (arī nepārvietotie) — tas pats kods
        if sub:
            for k in _rfed_names().values():
                sm = manifest.load(os.path.join(sdir, k))
                if sm and sm.get("series_id") and sm["series_id"] not in sids:
                    sids.append(sm["series_id"])
                if sm and sm.get("series_code") and not s["code"]:
                    s["code"] = sm["series_code"]
        if m.get("series_code") and not s["code"]:
            s["code"] = m["series_code"]
        for x in sids:
            if x not in s["sids"]:
                s["sids"].append(x)
        items = {it.get("stem"): it for it in m.get("images") or []}
        for p in ps:
            it = items.get(os.path.splitext(os.path.basename(p))[0]) or {}
            d = (it.get("taken_at") or "")[:7]
            if not re.match(r"\d{4}-\d\d$", d):
                try:
                    d = datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m")
                except OSError:
                    d = ""
            if d:
                s["dates"].append(d)
        s["groups"].append({"src": src, "sub": sub, "paths": ps, "items": items})

    codes = ledger().data.get("codes") or {}
    used: dict[str, list[str]] = {}
    year = time.strftime("%Y")
    out_groups, dups = [], []
    led = [it for it in ledger().data.get("items") or [] if it.get("phash") or it.get("size")]
    for s in series.values():
        sids = s["sids"] or [uuid.uuid4().hex]
        code = s["code"] or _code_for(sids, used)
        used.setdefault(code, []).extend(sids)
        known = (codes.get(code) or {}).get("folder")
        if known and os.path.isdir(known):
            sdest = known
        else:
            ym = min(s["dates"]) if s["dates"] else time.strftime("%Y-%m")
            sdest = os.path.join(root, year, f"{ym}_{_clean_name(s['dir'])}_{code}")
        for g in s["groups"]:
            dest = os.path.join(sdest, g["sub"]) if g["sub"] else sdest
            renames = []
            for p in g["paths"]:
                base = os.path.basename(p)
                new = base if base.lower().startswith(code.lower() + "_") else f"{code}_{base}"
                renames.append({"path": p, "name": new})
                it = g["items"].get(os.path.splitext(base)[0]) or {}
                size = os.path.getsize(p) if os.path.exists(p) else 0
                ph = it.get("phash") or ""
                hit = None
                target = os.path.join(dest, new)
                if os.path.exists(target):
                    hit = {"kind": "same" if os.path.getsize(target) == size else "similar", "path": target,
                           "name": new, "where": dest}
                if not hit:
                    best = None
                    for e in led:
                        same = (e.get("size") == size and ph and e.get("phash") == ph)
                        hd = _ham(ph, e.get("phash")) if ph and e.get("phash") else 99
                        if same or hd <= SIMILAR_BITS:
                            k = 0 if same else hd + 1
                            if best is None or k < best[0]:
                                best = (k, e)
                    if best:
                        e = best[1]
                        hit = {"kind": "same" if best[0] == 0 else "similar", "path": e.get("path"),
                               "name": e.get("name"), "orig": e.get("orig"), "series": e.get("series"),
                               "at": e.get("at"), "computer": e.get("computer"), "status": e.get("status"),
                               "exists": bool(e.get("path") and os.path.exists(e["path"]))}
                if hit:
                    dups.append({"path": p, "file": base, **{"other": hit}})
            out_groups.append({"src": g["src"], "dest": dest, "paths": g["paths"], "renames": renames, "code": code,
                               "series_dir": sdest, "series": _clean_name(s["dir"]), "sids": sids,
                               "items": g["items"]})
    return {"root": root, "groups": out_groups, "dups": dups, "verify": verify_mode(root),
            "count": sum(len(g["paths"]) for g in out_groups)}


# --------------------------------------------------------------------------- pārvietošana

def move(paths: list[str], skip: list[str] | None = None) -> dict:
    skipn = {os.path.normcase(os.path.abspath(p)) for p in skip or []}
    pl = plan(paths)
    mode = pl["verify"]
    batch = uuid.uuid4().hex[:12]
    computer = platform.node() or "?"
    done, errors, dests, made_dirs, new_items = [], [], [], [], []
    led = ledger()
    for g in pl["groups"]:
        src, dest, code = g["src"], g["dest"], g["code"]
        todo = [r for r in g["renames"] if os.path.normcase(r["path"]) not in skipn]
        if not todo:
            continue
        for d in (os.path.dirname(os.path.dirname(dest)), os.path.dirname(dest), dest):
            if not os.path.isdir(d):
                os.makedirs(d, exist_ok=True)
                made_dirs.append(d)
        old = manifest.load(src) or {}
        had_dest = bool(manifest.find(dest))
        moved_stems, orig_names = {}, {}
        for r in todo:
            p = r["path"]
            stem_old = os.path.splitext(os.path.basename(p))[0]
            stem_new = os.path.splitext(r["name"])[0]
            main_rec, comps = None, []
            for c in sorter._companions(p):
                cb = os.path.basename(c)
                cnew = stem_new + cb[len(stem_old):] if cb.lower().startswith(stem_old.lower()) else cb
                try:
                    dst = sorter._unique(os.path.join(dest, cnew))
                    size, md5 = _safe_copy(c, dst)
                    store.move_photo(c, dst)
                    done.append({"src": c, "dst": dst, "main": c == p})
                    rec = {"orig": cb, "name": os.path.basename(dst), "size": size, "md5": md5}
                    if c == p:
                        main_rec = (rec, dst)
                    else:
                        comps.append(rec)
                except OSError as e:
                    errors.append(f"{cb}: {e}")
            if not main_rec:
                continue
            rec, dst = main_rec
            moved_stems[stem_old] = dest
            orig_names[os.path.splitext(rec["name"])[0]] = rec["orig"]
            it = g["items"].get(stem_old) or {}
            new_items.append({
                "id": uuid.uuid4().hex[:12], "batch": batch, "code": code, "series": g["series"],
                "series_id": old.get("series_id") or (g["sids"] or [""])[0], "category": it.get("category") or (
                    "ED" if os.path.basename(dest).lower() == (config.get("sort_ed_name") or "ED").lower() else "RF"),
                "phash": it.get("phash", ""), "sig": it.get("sig", ""), "size": rec["size"], "md5": rec["md5"],
                "orig": rec["orig"], "name": rec["name"], "companions": comps, "at": _now(), "computer": computer,
                "src": p, "path": dst, "verify": mode, "status": "verified" if mode == "direct" else "copied",
                "verified_at": _now() if mode == "direct" else ""})
        left = manifest._images(src)
        try:
            manifest.build(dest, series_id=old.get("series_id") if not left and not had_dest else None,
                           series_code=code, orig=orig_names)
        except Exception as e:
            errors.append(f"manifests: {e}")
        try:
            if left and old:
                manifest.build(src, moved=moved_stems)
            elif not left:
                manifest.remove(src)
        except Exception as e:
            errors.append(f"manifests: {e}")
        with led.lock:
            c = led.data.setdefault("codes", {}).setdefault(code, {"series_ids": [], "name": g["series"]})
            c["folder"] = g["series_dir"]
            for s in g["sids"]:
                if s not in c["series_ids"]:
                    c["series_ids"].append(s)
        if dest not in dests:
            dests.append(dest)
    with led.lock:
        led.data.setdefault("items", []).extend(new_items)
        led.save()
    with open(_undo_file(), "w", encoding="utf-8") as f:
        json.dump({"time": time.time(), "batch": batch, "moves": done, "dirs": made_dirs}, f, ensure_ascii=False)
    return {"count": sum(1 for d in done if d["main"]), "errors": errors, "dests": dests, "root": pl["root"],
            "verify": mode, "skipped": len(skipn)}


def undo() -> dict:
    try:
        with open(_undo_file(), encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError):
        raise RuntimeError(T("nothing_to_undo"))
    back, errors, folders = 0, [], set()
    for m in reversed(d.get("moves") or []):
        try:
            if os.path.exists(m["dst"]) and not os.path.exists(m["src"]):
                os.makedirs(os.path.dirname(m["src"]), exist_ok=True)
                _safe_copy(m["dst"], m["src"])
                store.move_photo(m["dst"], m["src"])
                back += 1 if m.get("main") else 0
                folders.add(os.path.dirname(m["src"]))
                folders.add(os.path.dirname(m["dst"]))
        except OSError as e:
            errors.append(f"{os.path.basename(m['dst'])}: {e}")
    for f in folders:
        try:
            if manifest._images(f):
                manifest.build(f)
            else:
                manifest.remove(f)
                if os.path.isdir(f) and not os.listdir(f):
                    os.rmdir(f)
        except Exception as e:
            print("manifests (atsaukšana):", f, e)
    for dd in reversed(d.get("dirs") or []):                 # tukšās jaunās mapes (sērija, gads)
        try:
            if os.path.isdir(dd) and not os.listdir(dd):
                os.rmdir(dd)
        except OSError:
            pass
    if d.get("batch"):
        led = ledger()
        with led.lock:
            led.data["items"] = [it for it in led.data.get("items") or [] if it.get("batch") != d["batch"]]
            used = {it.get("code") for it in led.data["items"]}
            led.data["codes"] = {c: v for c, v in (led.data.get("codes") or {}).items() if c in used}
            led.save()
    if not errors:
        os.remove(_undo_file())
    return {"count": back, "errors": errors}


def places() -> list[dict]:
    """Ātrās izvēles iestatījumos: OneDrive, Google Drive, NAS (ja atrasti)."""
    from pathlib import Path
    out = []
    try:
        from core.server import _onedrive
        od = str(config.get("onedrive_dir") or "") or _onedrive()
        if od and os.path.isdir(od):
            out.append({"kind": "onedrive", "path": od})
    except Exception:
        pass
    home = Path.home()
    gd = []
    if config.IS_MAC:
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/My Drive"))
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/Mans disks"))
    gd += [str(home / "Google Drive" / "My Drive"), str(home / "Google Drive"), str(home / "My Drive")]
    if config.IS_WIN:
        import string
        for L in string.ascii_uppercase:
            for n in ("My Drive", "Mans disks", "Мой диск"):
                gd.append(f"{L}:\\{n}")
    for p in gd:
        if os.path.isdir(p):
            out.append({"kind": "gdrive", "path": p})
            break
    if config.IS_MAC and os.path.isdir("/Volumes"):
        for n in sorted(os.listdir("/Volumes")):
            p = os.path.join("/Volumes", n)
            if not n.startswith(".") and os.path.isdir(p) and not os.path.islink(p) and n not in ("Macintosh HD", "Recovery"):
                out.append({"kind": "nas", "path": p})
    sd = home / "SynologyDrive"
    if sd.is_dir():
        out.append({"kind": "nas", "path": str(sd)})
    return out
