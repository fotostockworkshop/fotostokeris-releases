"""Noklusējuma "Rakstības noteikumi AI" un "RF/ED kritēriji" — iebūvēti tulkojumi mākonim (lietotājs 2026-11-03 10:24).

AI norādes paliek angliski (config.DEFAULT_STYLE / DEFAULT_RFED); šeit tikai parādīšanai. Ja noklusējuma teksts mainās —
atjauno arī šos tulkojumus (citādi mākonis tulko ar AI kā lietotāja tekstu)."""
from __future__ import annotations

STYLE = {
    "lv": (
        "Raksti dabiskā, plūstošā angļu valodā starptautiskiem stoka pircējiem.\n"
        "Virsraksts: viens faktisks teikums par to, kas/kurš ir bildē un kas notiek — vispirms galvenais objekts, "
        "tad vide un svarīgākās detaļas.\n"
        "Apraksts: līdzīga nozīme kā virsrakstam, arī paskaidrojošs, bet uzrakstīts CITIEM vārdiem (citi vārdi un "
        "teikuma uzbūve, ne kopija), jo dažādība palīdz bildei parādīties vairāk meklēšanas rezultātos. Ja vieta zināma, "
        "beigās var būt atrašanās vieta (piemēram: '..., Kintamani, Bali, Indonesia').\n"
        "Atslēgvārdi: tikai atsevišķi vārdi, mazajiem burtiem, bez atkārtojumiem. Pirmajiem 10 jābūt visvairāk "
        "meklētajiem vārdiem, kas palīdzēs pircējiem atrast un nopirkt šo bildi. Katram atslēgvārdam jāatbilst kaut kam, "
        "kas bildē tiešām redzams vai ir patiess: priekšmeti, vietas, notikumi, cilvēku veidi, darbības, krāsas, "
        "noskaņa. Nekad nelieto vārdus 'editorial' vai 'illustrative'."
    ),
    "de": (
        "Schreibe in natürlichem, flüssigem Englisch für internationale Stock-Käufer.\n"
        "Titel: ein sachlicher Satz darüber, wer/was im Bild ist und was passiert — zuerst das Hauptmotiv, dann die "
        "Umgebung und die wichtigsten Details.\n"
        "Beschreibung: ähnliche Bedeutung wie der Titel und ebenfalls erklärend, aber ANDERS formuliert (andere Wörter "
        "und Satzbau, keine Kopie), denn Vielfalt hilft, in mehr Suchergebnissen zu erscheinen. Wenn der Ort bekannt "
        "ist, darf sie mit dem Ort enden (z. B. '..., Kintamani, Bali, Indonesia').\n"
        "Keywords: nur einzelne Wörter, kleingeschrieben, ohne Wiederholungen. Die ersten 10 müssen die meistgesuchten "
        "Wörter sein, die Käufern helfen, dieses Foto zu finden und zu kaufen. Jedes Keyword muss etwas entsprechen, das "
        "im Bild wirklich sichtbar oder wahr ist: Objekte, Orte, Ereignisse, Personentypen, Handlungen, Farben, "
        "Stimmung. Niemals die Wörter 'editorial' oder 'illustrative' verwenden."
    ),
    "es": (
        "Escribe en un inglés natural y fluido para compradores internacionales de stock.\n"
        "Título: una frase objetiva sobre quién/qué aparece en la imagen y qué ocurre — primero el sujeto principal, "
        "luego el entorno y los detalles más importantes.\n"
        "Descripción: significado parecido al título y también explicativa, pero redactada de forma DIFERENTE (otras "
        "palabras y otra estructura, no una copia), porque la variedad ayuda a aparecer en más búsquedas. Si se conoce "
        "el lugar, puede terminar con la ubicación (por ejemplo: '..., Kintamani, Bali, Indonesia').\n"
        "Palabras clave: solo palabras sueltas, en minúsculas, sin repeticiones. Las 10 primeras deben ser las más "
        "buscadas, las que ayudarán a los compradores a encontrar y comprar esta foto. Cada palabra clave debe "
        "corresponder a algo realmente visible o cierto en la imagen: objetos, lugares, eventos, tipos de personas, "
        "acciones, colores, ambiente. Nunca uses las palabras 'editorial' o 'illustrative'."
    ),
    "uk": (
        "Пиши природною, плавною англійською для міжнародних покупців стоку.\n"
        "Заголовок: одне фактичне речення про те, хто/що на фото і що відбувається — спочатку головний об'єкт, потім "
        "обстановка та найважливіші деталі.\n"
        "Опис: схожий за змістом на заголовок і також пояснювальний, але сформульований ІНАКШЕ (інші слова та будова "
        "речення, не копія), бо різноманітність допомагає фото з'являтися в більшій кількості результатів пошуку. Якщо "
        "місце відоме, наприкінці можна вказати локацію (наприклад: '..., Kintamani, Bali, Indonesia').\n"
        "Ключові слова: лише окремі слова, малими літерами, без повторів. Перші 10 мають бути найпопулярнішими в "
        "пошуку словами, які допоможуть покупцям знайти й купити це фото. Кожне ключове слово має відповідати тому, що "
        "справді видно або є правдою на фото: предмети, місця, події, типи людей, дії, кольори, настрій. Ніколи не "
        "використовуй слова 'editorial' або 'illustrative'."
    ),
}

RFED = {
    "lv": (
        "EDITORIAL (ED), ja bildē ir kaut kas no šī: atpazīstamas sejas vai cilvēki, kas ir galvenais objekts vai skaidri "
        "identificējami (bez modeļa atļaujas); redzami logotipi, zīmolu nosaukumi, preču zīmes vai salasāmas reklāmas "
        "izkārtnes; atpazīstami mākslas darbi, sienu gleznojumi vai autortiesību aizsargāts dizains; ziņu vērti vai "
        "publiski notikumi, festivāli, ceremonijas, protesti, sporta pasākumi; privātīpašuma interjeri vai atpazīstami "
        "transportlīdzekļi ar numurzīmēm.\n"
        "ROYALTY-FREE (RF), ja: ainavas, daba, dzīvnieki, augi, ēdiens, faktūras, arhitektūra bez logotipiem, cilvēki "
        "tikai kā sīki neatpazīstami silueti vai no mugurpuses, un nav zīmolu.\n"
        "UNSURE, ja tas ir robežgadījums (piem., mazas, bet varbūt atpazīstamas sejas, daļēji redzami logotipi)."
    ),
    "de": (
        "EDITORIAL (ED), wenn das Foto etwas davon enthält: erkennbare Gesichter oder Personen, die Hauptmotiv oder "
        "klar identifizierbar sind (ohne Model-Release); sichtbare Logos, Markennamen, Warenzeichen oder lesbare "
        "Werbeschilder; erkennbare Kunstwerke, Wandbilder oder urheberrechtlich geschützte Designs; berichtenswerte "
        "oder öffentliche Ereignisse, Festivals, Zeremonien, Proteste, Sportveranstaltungen; Innenräume von "
        "Privateigentum oder erkennbare Fahrzeuge mit Kennzeichen.\n"
        "ROYALTY-FREE (RF), wenn: Landschaften, Natur, Tiere, Pflanzen, Essen, Texturen, Architektur ohne Logos, "
        "Menschen nur als winzige unerkennbare Silhouetten oder von hinten, und keine Marken.\n"
        "UNSURE bei Grenzfällen (z. B. kleine, aber möglicherweise erkennbare Gesichter, teilweise sichtbare Logos)."
    ),
    "es": (
        "EDITORIAL (ED) si la foto contiene algo de esto: caras reconocibles o personas que son el sujeto o claramente "
        "identificables (sin autorización de modelo); logotipos, nombres de marcas, marcas registradas o letreros "
        "comerciales legibles; obras de arte, murales o diseños con derechos de autor reconocibles; eventos "
        "noticiosos o públicos, festivales, ceremonias, protestas, eventos deportivos; interiores de propiedad privada "
        "o vehículos reconocibles con matrícula.\n"
        "ROYALTY-FREE (RF) si: paisajes, naturaleza, animales, plantas, comida, texturas, arquitectura sin logotipos, "
        "personas solo como siluetas diminutas irreconocibles o de espaldas, y sin marcas.\n"
        "UNSURE si es un caso límite (p. ej., caras pequeñas pero quizá reconocibles, logotipos parcialmente visibles)."
    ),
    "uk": (
        "EDITORIAL (ED), якщо на фото є щось із цього: впізнавані обличчя або люди, які є головним об'єктом чи чітко "
        "ідентифікуються (без релізу моделі); видимі логотипи, назви брендів, торговельні марки або читабельні рекламні "
        "вивіски; впізнавані твори мистецтва, муралі чи захищений авторським правом дизайн; новинні або публічні події, "
        "фестивалі, церемонії, протести, спортивні заходи; інтер'єри приватної власності або впізнавані транспортні "
        "засоби з номерами.\n"
        "ROYALTY-FREE (RF), якщо: краєвиди, природа, тварини, рослини, їжа, текстури, архітектура без логотипів, люди "
        "лише як крихітні невпізнавані силуети або зі спини, і немає брендів.\n"
        "UNSURE, якщо це межовий випадок (напр., маленькі, але, можливо, впізнавані обличчя, частково видимі логотипи)."
    ),
}


def builtin(text: str, lang: str) -> str:
    from . import config
    t = " ".join((text or "").split())
    if t == " ".join(config.DEFAULT_STYLE.split()):
        return STYLE.get(lang, "")
    if t == " ".join(config.DEFAULT_RFED.split()):
        return RFED.get(lang, "")
    return ""
