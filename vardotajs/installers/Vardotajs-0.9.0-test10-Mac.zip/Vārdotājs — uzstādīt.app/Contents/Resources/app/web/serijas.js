"use strict";
/* Vārdotājs 0.9.0-test4 (+ test9: iesniegšanas struktūra, dublikāti, "Par programmu") — manifesti un sīktēli, "Uz iesniegšanu", kategorijas maiņa ED ⇄ RF redaktorā, sistēmas paziņojumu
   ķeksis, "Meža zaļā" tēma, tulkojuma mākonis "Rakstības noteikumi AI" un "RF/ED kritēriji" laukiem.
   Noteikumi: docs/fotostokeris-dati.md §7a "Manifesta formāts un darbība". Lieto app.js palīgus ($, $$, api, t, esc, toast,
   uiDialog, uiConfirm, S, navigate, confirmLeave, trPlace, TR, trHide …). */

const SER_I18N = {
  lv: {
    conn_lost: "Savienojums ar programmu pārtrūka (piemēram, dators gulēja). Mēģinu atjaunot…",
    conn_dead: "Programma neatbild. Ja tā aizvērās — palaid to vēlreiz; šī lapa atjaunosies pati.",
    conn_retry: "Mēģināt vēlreiz", conn_ok: "Savienojums atjaunots",
    pick_busy: "Mapes izvēles logs jau ir atvērts — tas var būt aiz citiem logiem (uzdevumjoslā).",
    pick_folder: "Izvēlēties mapi…",
    theme_forest: "Meža zaļais", th_forest: "Meža zaļais", theme_forest_d: "Tumša tēma ar laima zaļu akcentu — dabiska, mierīga, ērta ilgākam darbam",
    mf_btn: "Manifests", mf_btn_title: "Izveidot vai atjaunot šīs mapes manifestu un sīktēlus (arī vecām, jau aprakstītām mapēm). Tos lieto Analītiķis un Tirgotājs.",
    mf_btn_title_has: "Manifests: {name} — {n} bildes, {r} gatavas (atjaunots {d}). Klikšķis — atjaunot tagad.",
    mf_started: "Veidoju manifestu un sīktēlus: {n} bildes…", mf_progress: "Manifests: {d} / {n}…",
    mf_done: "Manifests gatavs: {list}. Kopija: {dir}", mf_item: "{name} ({n} bildes, {r} gatavas)",
    mf_none: "Šajā mapē (un tās apakšmapēs) nav bilžu.", mf_err: "Manifestu neizdevās izveidot: {e}",
    review_mf: "Izveidot manifestu un sīktēlus", review_mf_title: "RF un ED mapēs pēc pārvietošanas — manifests (teksti, kategorija, statuss) un sīktēli Analītiķim un Tirgotājam. Izvēle tiek atcerēta.",
    sub_btn: "Uz iesniegšanu", sub_btn_title: "Pārvietot atlasītās bildes (vai visu mapi) uz iesniegšanai gatavo bilžu mapi — kopā ar RAW/.xmp, piezīmēm un manifestu.",
    sub_off_title: "Iestatījumos norādi iesniegšanai gatavo bilžu mapi — tad poga kļūs aktīva (klikšķis atver iestatījumus).",
    sub_off_q: "Iesniegšanai gatavo bilžu mape vēl nav norādīta. Atvērt iestatījumus, lai to izvēlētos?", sub_open_settings: "Atvērt iestatījumus",
    sub_none: "Nav ko pārvietot — šīs bildes jau ir iesniegšanai gatavo mapē.",
    sub_q: "Pārvietot {n} bildes {which} uz iesniegšanai gatavo mapi?\n\n{lines}\n\nFailiem priekšā sērijas kods (oriģinālais nosaukums paliek manifestā). Līdzi: RAW / .xmp, piezīmes un pavedieni; mapē tiks izveidots vai atjaunots manifests.",
    sub_q_sel: "(atlasītās bildes)", sub_q_all: "(visa mape)",
    sub_move: "Pārvietot", sub_done: "Pārvietotas {n} bildes uz:\n{dest}", sub_undo: "Atsaukt", sub_reveal: "Atvērt mapi", sub_ok: "Labi",
    sub_undone: "Atsaukts: {n} bildes atpakaļ vietā.",
    s_ready: "Gatavās sērijas un manifesti",
    s_ready_d: "Kad sērija aprakstīta, ar pogu \"Uz iesniegšanu\" to pārvieto uz šo mapi. Manifests (teksti, kategorija, statuss, sīktēli) ir sērijas mapē neuzkrītošā apakšmapē .fotostokeris un kopija kopīgajā manifestu mapē — no turienes tos lasīs Analītiķis un Tirgotājs.",
    ready_dir: "Iesniegšanai gatavo bilžu mape", ready_dir_ph: "nav norādīta — poga \"Uz iesniegšanu\" neaktīva",
    rp_onedrive: "OneDrive", rp_gdrive: "Google Drive", rp_nas: "Tīkla disks / NAS",
    mf_dir: "Manifestu mape", mf_dir_d: "Tukša = <iesniegšanai gatavo bilžu mape>/Manifesti; ja arī tās nav — programmas datu mapē. Var būt arī OneDrive, Google Drive vai NAS mape.",
    s_notify: "Sistēmas paziņojumi, kad AI darbs beidzies",
    s_notify_d: "Ieslēdzot, pārlūks (Edge) vienreiz jautās \"wants to show notifications\" — spied Allow: tad paziņojums parādīsies ekrāna stūrī, kad darbs beidzies un programmas logs nav priekšā. Izslēgts — paziņojumi tikai programmā.",
    notify_denied: "Pārlūks paziņojumus neatļāva — tos var atļaut pārlūka vietnes iestatījumos.",
    cat_to_rf: "Kategorija mainīta uz RF, bet tekstā ir vieta un datums (Editorial formāts \"CITY, COUNTRY – DATE:\").",
    cat_to_ed: "Kategorija mainīta uz Editorial. Teksts rakstīts pēc RF noteikumiem (bez vietas un datuma).",
    cat_strip: "Noņemt vietu un datumu", cat_ai: "Pārrakstīt ar AI", cat_ai_ed: "Pārrakstīt ar AI (ar vietu un datumu)", cat_keep: "Atstāt kā ir",
    cat_move: "Pēc saglabāšanas pārvietot uz mapi {dest}", cat_move_now: "Pārvietot uz mapi {dest}",
    cat_stripped: "Vieta un datums noņemti — pārbaudi un saglabā.", cat_stripped_n: "Vieta un datums noņemti {n} bildēm.",
    sub_name_ex: "faili: {name} …", sub_working: "Kopēju un pārbaudu katru failu…",
    sub_verify_direct: "Katru failu nokopēs, salīdzinās ar oriģinālu (izmērs + kontrolsumma) un tikai tad dzēsīs oriģinālu.",
    sub_verify_sync: "Mape ir sinhronizācijas mapē (Synology Drive / OneDrive / Google Drive): kopiju pārbaudīs šajā datorā, oriģinālu dzēsīs; bildes uzskaitē būs \"gaida pārbaudi\", līdz tiks pārbaudīts serveris (nākamajā versijā).",
    sub_done_direct: "Visas kopijas pārbaudītas — sakrīt ar oriģināliem.", sub_done_sync: "Kopijas pārbaudītas šajā datorā; uz servera vēl jāpārbauda (uzskaitē \"gaida pārbaudi\").",
    dup_title: "Iespējami dublikāti: {n}", dup_d: "Šīs bildes jau ir sagatavoto bilžu uzskaitē vai galamērķa mapē (tā pati vai ļoti līdzīga). Izlem katrai — programma pati neko neizlaiž un neaizstāj.",
    dup_this: "Šī", dup_same: "Tā pati", dup_similar: "Līdzīga", dup_noimg: "bilde šajā datorā nav redzama",
    dup_move: "Pārvietot tik un tā", dup_skip: "Atstāt vietā", dup_all_move: "Visas — pārvietot", dup_all_skip: "Visas — atstāt vietā", dup_go: "Turpināt",
    dup_st_copied: "gaida pārbaudi", dup_st_verified: "pārbaudīta", dup_st_local_removed: "vietējā kopija dzēsta",
    ready_verify: "Kā pārbaudīt kopijas", rv_auto: "Automātiski (pēc mapes)", rv_direct: "Tieši (lokāla mape, tīkla disks N:)", rv_sync: "Sinhronizācijas mape (Synology Drive, OneDrive, Google Drive)",
    s_about: "Par programmu", about_ver: "Vārdotājs {v}", about_total: "Sagatavotas iesniegšanai: {n} bildes ({s} sērijas)", about_waiting: "No tām gaida pārbaudi uz servera: {n}",
    tr_rules_wait: "Tulkoju…", tr_rules_lv: "Teksts jau ir latviski — nav ko tulkot.", tr_rules_none: "Nav tulkojuma — nav pieslēgts AI.",
  },
  en: {
    conn_lost: "Connection to the program was lost (e.g. the computer was asleep). Reconnecting…",
    conn_dead: "The program does not respond. If it closed — start it again; this page will reload by itself.",
    conn_retry: "Try again", conn_ok: "Connection restored",
    pick_busy: "The folder picker is already open — it may be behind other windows (taskbar).",
    pick_folder: "Choose folder…",
    theme_forest: "Forest green", th_forest: "Forest", theme_forest_d: "Dark theme with a lime green accent — natural, calm, comfortable for long sessions",
    mf_btn: "Manifest", mf_btn_title: "Create or update this folder's manifest and thumbnails (also for older, already described folders). Used by Analītiķis and Tirgotājs.",
    mf_btn_title_has: "Manifest: {name} — {n} photos, {r} ready (updated {d}). Click to update now.",
    mf_started: "Creating the manifest and thumbnails: {n} photos…", mf_progress: "Manifest: {d} / {n}…",
    mf_done: "Manifest ready: {list}. Copy: {dir}", mf_item: "{name} ({n} photos, {r} ready)",
    mf_none: "There are no photos in this folder (or its subfolders).", mf_err: "Could not create the manifest: {e}",
    review_mf: "Create manifest and thumbnails", review_mf_title: "In the RF and ED folders after moving — a manifest (texts, category, status) and thumbnails for Analītiķis and Tirgotājs. The choice is remembered.",
    sub_btn: "To submission", sub_btn_title: "Move the selected photos (or the whole folder) to the folder for photos ready to submit — with RAW/.xmp, notes and the manifest.",
    sub_off_title: "Set the folder for photos ready to submit in Settings — then the button becomes active (click opens Settings).",
    sub_off_q: "The folder for photos ready to submit is not set yet. Open Settings to choose it?", sub_open_settings: "Open Settings",
    sub_none: "Nothing to move — these photos are already in the ready-to-submit folder.",
    sub_q: "Move {n} photos {which} to the ready-to-submit folder?\n\n{lines}\n\nFile names get the series code in front (the original name stays in the manifest). Also moved: RAW / .xmp, notes and hints; a manifest will be created or updated in the folder.",
    sub_q_sel: "(selected photos)", sub_q_all: "(whole folder)",
    sub_move: "Move", sub_done: "Moved {n} photos to:\n{dest}", sub_undo: "Undo", sub_reveal: "Open folder", sub_ok: "OK",
    sub_undone: "Undone: {n} photos are back.",
    s_ready: "Finished series and manifests",
    s_ready_d: "When a series is described, the \"To submission\" button moves it to this folder. The manifest (texts, category, status, thumbnails) is kept in the series folder in an unobtrusive .fotostokeris subfolder, with a copy in the shared manifest folder — Analītiķis and Tirgotājs will read them from there.",
    ready_dir: "Folder for photos ready to submit", ready_dir_ph: "not set — the \"To submission\" button is inactive",
    rp_onedrive: "OneDrive", rp_gdrive: "Google Drive", rp_nas: "Network drive / NAS",
    mf_dir: "Manifest folder", mf_dir_d: "Empty = <ready-to-submit folder>/Manifesti; if that is not set either — the program's data folder. Can also be a OneDrive, Google Drive or NAS folder.",
    s_notify: "System notifications when AI work is finished",
    s_notify_d: "When turned on, the browser (Edge) asks once \"wants to show notifications\" — click Allow: a notification will then appear in the corner of the screen when work is done and the program window is not in front. Off — notifications only inside the program.",
    notify_denied: "The browser did not allow notifications — they can be allowed in the browser's site settings.",
    cat_to_rf: "Category changed to RF, but the text has a place and date (Editorial format \"CITY, COUNTRY – DATE:\").",
    cat_to_ed: "Category changed to Editorial. The text was written by the RF rules (no place and date).",
    cat_strip: "Remove place and date", cat_ai: "Rewrite with AI", cat_ai_ed: "Rewrite with AI (with place and date)", cat_keep: "Keep as is",
    cat_move: "After saving, move to the {dest} folder", cat_move_now: "Move to the {dest} folder",
    cat_stripped: "Place and date removed — check and save.", cat_stripped_n: "Place and date removed for {n} photos.",
    sub_name_ex: "files: {name} …", sub_working: "Copying and checking every file…",
    sub_verify_direct: "Every file will be copied, compared with the original (size + checksum) and only then the original is deleted.",
    sub_verify_sync: "The folder is a sync folder (Synology Drive / OneDrive / Google Drive): the copy is checked on this computer and the original deleted; in the register the photos stay \"waiting for check\" until the server is checked (next version).",
    sub_done_direct: "All copies checked — they match the originals.", sub_done_sync: "Copies checked on this computer; the server still has to be checked (\"waiting for check\" in the register).",
    dup_title: "Possible duplicates: {n}", dup_d: "These photos are already in the register of prepared photos or in the destination folder (the same or very similar). Decide for each — the program never skips or replaces anything by itself.",
    dup_this: "This", dup_same: "Same", dup_similar: "Similar", dup_noimg: "the photo is not visible on this computer",
    dup_move: "Move anyway", dup_skip: "Leave in place", dup_all_move: "All — move", dup_all_skip: "All — leave in place", dup_go: "Continue",
    dup_st_copied: "waiting for check", dup_st_verified: "checked", dup_st_local_removed: "local copy deleted",
    ready_verify: "How to check copies", rv_auto: "Automatically (by folder)", rv_direct: "Directly (local folder, network drive N:)", rv_sync: "Sync folder (Synology Drive, OneDrive, Google Drive)",
    s_about: "About", about_ver: "Vārdotājs {v}", about_total: "Prepared for submission: {n} photos ({s} series)", about_waiting: "Of them waiting for the server check: {n}",
    tr_rules_wait: "Translating…", tr_rules_lv: "", tr_rules_none: "No translation — no AI connected.",
  },
};
for (const l of Object.keys(SER_I18N)) {
  window.I18N[l] = window.I18N[l] || {};
  for (const [k, v] of Object.entries(SER_I18N[l])) if (!(k in window.I18N[l])) window.I18N[l][k] = v;
}
applyI18n(document);

const SER = { poll: null };
const fmtWhen = (iso) => { try { return new Date(iso).toLocaleString(window.LANG === "en" ? "en-GB" : "lv-LV", { dateStyle: "short", timeStyle: "short" }); } catch (_) { return iso || ""; } };

/* ---------- pogas "Manifests" un "Uz iesniegšanu" stāvoklis ---------- */
async function serRefresh() {
  const sb = $("#submitBtn"), mb = $("#manifestBtn");
  const has = !!(S.settings && String(S.settings.ready_dir || "").trim());
  sb.classList.toggle("off", !has);
  sb.title = has ? t("sub_btn_title") + "\n→ " + S.settings.ready_dir : t("sub_off_title");
  mb.title = t("mf_btn_title");
  if (!S.path) return;
  try {
    const d = await api("manifest_info", { folder: S.path });
    const m = d.manifests || [];
    if (m.length) mb.title = m.map((x) => t("mf_btn_title_has", { name: x.name, n: x.count, r: x.ready, d: fmtWhen(x.updated) })).join("\n");
    if (d.building) serPoll();
  } catch (_) {}
}
const _serNavigate = navigate;
navigate = async function (path, push = true) {      // eslint-disable-line no-func-assign
  const r = await _serNavigate(path, push);
  serRefresh();
  return r;
};

/* ---------- Manifests ---------- */
function serPoll() {
  clearTimeout(SER.poll);
  const folder = S.path;
  SER.poll = setTimeout(async function tick() {
    let d;
    try { d = await api("manifest_info", { folder }); } catch (_) { return; }
    const b = $("#manifestBtn");
    if (d.building) {
      b.disabled = true;
      $("span[data-i18n=mf_btn]", b).textContent = d.total ? `${d.done} / ${d.total}` : "…";
      SER.poll = setTimeout(tick, 1200);
      return;
    }
    b.disabled = false;
    $("span[data-i18n=mf_btn]", b).textContent = t("mf_btn");
    if (d.error) toast(t("mf_err", { e: d.error }), "err", 9000);
    else if (d.made && d.made.length) {
      toast(t("mf_done", { list: d.made.map((x) => t("mf_item", { name: x.name, n: x.count, r: x.ready })).join(", "), dir: d.shared }), "ok sticky", 12000);
    }
    if (normP(folder) === normP(S.path)) serRefresh();
  }, 800);
}
$("#manifestBtn").addEventListener("click", async () => {
  if (!S.path) return;
  if (!(await confirmLeave())) return;
  try {
    const d = await api("manifest_make", { folder: S.path });
    if (!d.count) { toast(t("mf_none")); return; }
    toast(t("mf_started", { n: S.images.length || "…" }), "ok", 3000);
    $("#manifestBtn").disabled = true;
    serPoll();
  } catch (e) { toast(e.message, "err"); }
});

/* ---------- Uz iesniegšanu (test9: struktūra <GADS>/<YYYY-MM>_<Sērija>_<kods>/RF|ED, pārdēvēšana, pārbaude, dublikāti) ---------- */
function dupDialog(dups) {
  /* Katram dublikātam abas bildes blakus; lēmumu pieņem cilvēks (noteikumi dati §7a). Atdod skip sarakstu vai null (atcelt). */
  return new Promise((resolve) => {
    const m = document.createElement("div");
    m.className = "modal"; m.id = "dupModal";
    const rows = dups.map((d, i) => {
      const o = d.other || {};
      const info = [o.series, o.computer, o.at ? fmtWhen(o.at) : "", o.status ? t("dup_st_" + o.status) : ""].filter(Boolean).join(" · ");
      const oth = o.path && (o.exists !== false) ? `<img src="${thumbUrl(o.path, 240)}" alt="">` : `<div class="dup-noimg muted small">${esc(t("dup_noimg"))}</div>`;
      return `<div class="dup-row" data-i="${i}">
        <div class="dup-pair"><figure><img src="${thumbUrl(d.path, 240)}" alt=""><figcaption>${esc(t("dup_this"))}: ${esc(d.file)}</figcaption></figure>
        <figure>${oth}<figcaption>${esc(t(o.kind === "same" ? "dup_same" : "dup_similar"))}: ${esc(o.name || "")}${o.orig && o.orig !== o.name ? " (" + esc(o.orig) + ")" : ""}<br><span class="muted small">${esc(info)}</span></figcaption></figure></div>
        <div class="dup-choice"><label class="chk"><input type="radio" name="dup${i}" value="move"> <span>${esc(t("dup_move"))}</span></label>
        <label class="chk"><input type="radio" name="dup${i}" value="skip"> <span>${esc(t("dup_skip"))}</span></label></div></div>`;
    }).join("");
    m.innerHTML = `<div class="modal-box dup-box"><h3>${esc(t("dup_title", { n: dups.length }))}</h3><p class="muted small">${esc(t("dup_d"))}</p>
      <div class="row"><button data-all="move">${esc(t("dup_all_move"))}</button><button data-all="skip">${esc(t("dup_all_skip"))}</button></div>
      <div class="dup-list">${rows}</div>
      <div class="row right"><button class="primary" id="dupGo" disabled>${esc(t("dup_go"))}</button><button id="dupCancel">${esc(t("cancel"))}</button></div></div>`;
    document.body.appendChild(m);
    const check = () => { $("#dupGo", m).disabled = dups.some((_, i) => !m.querySelector(`input[name=dup${i}]:checked`)); };
    m.addEventListener("change", check);
    $$("button[data-all]", m).forEach((b) => b.addEventListener("click", () => {
      dups.forEach((_, i) => { m.querySelector(`input[name=dup${i}][value=${b.dataset.all}]`).checked = true; }); check();
    }));
    const close = (v) => { m.remove(); resolve(v); };
    $("#dupCancel", m).addEventListener("click", () => close(null));
    $("#dupGo", m).addEventListener("click", () => close(dups.filter((_, i) => m.querySelector(`input[name=dup${i}]:checked`).value === "skip").map((d) => d.path)));
  });
}
$("#submitBtn").addEventListener("click", async () => {
  if (!S.settings || !String(S.settings.ready_dir || "").trim()) {
    const r = await uiDialog({ msg: t("sub_off_q"), buttons: [{ v: true, label: t("sub_open_settings"), cls: "primary" }, { v: false, label: t("cancel") }] });
    if (r === true) { showPage("settings"); setTimeout(() => { const s = $("section[data-collapse=ready]"); if (s) { s.classList.remove("collapsed"); s.scrollIntoView({ block: "start" }); $("#sReadyDir").focus(); } }, 300); }
    return;
  }
  if (!S.path || !S.images.length) { toast(t("sort_none")); return; }
  if (!(await confirmLeave())) return;
  const sel = S.selected.size > 0;
  const paths = sel ? [...S.selected] : S.images.map((i) => i.path);
  const btn = $("#submitBtn"); btn.disabled = true;
  let pl;
  try { pl = await api("submit_plan", { paths }); } catch (e) { toast(e.message, "err", 9000); btn.disabled = false; return; }
  finally { btn.disabled = false; }
  if (!pl.count) { toast(t("sub_none")); return; }
  let skip = [];
  if (pl.dups && pl.dups.length) {
    skip = await dupDialog(pl.dups);
    if (skip === null) return;
    if (skip.length >= pl.count) { toast(t("sub_none")); return; }
  }
  const lines = pl.groups.map((g) => `${g.n} × ${g.src}\n   → ${g.dest}\n   ${t("sub_name_ex", { name: g.example })}`).join("\n");
  const ok = await uiDialog({ msg: t("sub_q", { n: pl.count - skip.length, lines, which: t(sel ? "sub_q_sel" : "sub_q_all") }) + "\n\n" + t(pl.verify === "sync" ? "sub_verify_sync" : "sub_verify_direct"),
    buttons: [{ v: true, label: t("sub_move"), cls: "primary" }, { v: false, label: t("cancel") }] });
  if (ok !== true) return;
  btn.disabled = true;
  toast(t("sub_working"), "ok", 4000);
  try {
    const d = await api("submit_move", { paths, skip });
    S.selected = new Set();
    await navigate(S.path, false);
    const n = typeof treeNode === "function" ? treeNode(S.path.replace(/[\\/][^\\/]+$/, "")) : null;
    if (n) await toggleNode(n, true, true);
    if (d.errors && d.errors.length) toast(d.errors.slice(0, 3).join("\n"), "err", 12000);
    const r = await uiDialog({ msg: t("sub_done", { n: d.count, dest: (d.dests || []).join("\n") }) + "\n\n" + t(d.verify === "sync" ? "sub_done_sync" : "sub_done_direct"),
      buttons: [{ v: "ok", label: t("sub_ok"), cls: "primary" }, { v: "open", label: t("sub_reveal") }, { v: "undo", label: t("sub_undo") }] });
    if (r === "open" && d.dests && d.dests[0]) api("reveal", { path: d.dests[0] }).catch(() => {});
    if (r === "undo") {
      const u = await api("submit_undo");
      toast(t("sub_undone", { n: u.count }) + (u.errors.length ? " — " + u.errors[0] : ""), u.errors.length ? "err" : "ok", 6000);
      await navigate(S.path, false);
    }
  } catch (e) { toast(e.message, "err", 9000); }
  finally { btn.disabled = false; }
});

/* ---------- Iestatījumi → "Par programmu": versija + sagatavoto bilžu skaits ---------- */
async function aboutRefresh() {
  const box = $("#aboutInfo");
  if (!box) return;
  try {
    const d = await api("prepared_stats");
    const cats = Object.entries(d.by_cat || {}).sort((a, b) => b[1] - a[1]).map(([c, n]) => `<li><b>${esc(c)}</b> — ${n}</li>`).join("");
    box.innerHTML = `<p>${esc(t("about_ver", { v: d.version }))}</p><p>${esc(t("about_total", { n: d.total, s: d.series }))}</p>`
      + (cats ? `<ul class="about-cats">${cats}</ul>` : "") + (d.waiting ? `<p class="muted small">${esc(t("about_waiting", { n: d.waiting }))}</p>` : "");
  } catch (_) {}
}

/* ---------- šķirošanas pārskats: ķeksis "Izveidot manifestu un sīktēlus" (atceras) ---------- */
const _serOpenReview = openReview;
openReview = function (job) {                      // eslint-disable-line no-func-assign
  _serOpenReview(job);
  $("#rManifest").checked = !S.settings || S.settings.sort_manifest !== false;
};

/* ---------- kategorijas maiņa ED ⇄ RF redaktorā (arī pēc "Atpazīt vietas") ---------- */
const ED_RE = /^[^:\n]{2,90}? [–-] (?:CIRCA )?[A-Z]+(?: \d{1,2})?, \d{4}:\s*/;
const ED_PLACE_RE = /^[A-Z][A-Z ,.'’-]{2,80}:\s+/;
const hasEd = (s) => ED_RE.test((s || "").trim()) || ED_PLACE_RE.test((s || "").trim());
const stripEd = (s) => { s = (s || "").trim().replace(ED_RE, "").replace(ED_PLACE_RE, ""); return s.charAt(0).toUpperCase() + s.slice(1); };
$("#edChk").addEventListener("change", async () => {
  if (!S.form) return;
  const isEd = $("#edChk").checked;
  const paths = [...S.form.paths];
  const single = paths.length === 1;
  const texts = single ? [S.form.title, S.form.description] : paths.flatMap((p) => [S.meta[p]?.title, S.meta[p]?.description]);
  const anyText = texts.some((x) => (x || "").trim());
  const withEd = texts.some(hasEd);
  if (!anyText || (isEd && withEd) || (!isEd && !withEd)) return;
  // vai bilde ir otras kategorijas mapē (RF / ED)?
  const rf = lower(S.settings.sort_rf_name || "RF"), ed = lower(S.settings.sort_ed_name || "ED");
  const parentName = (p) => lower(basename(p.replace(/[\\/][^\\/]+$/, "")));
  const wrong = paths.filter((p) => parentName(p) === (isEd ? rf : ed));
  const dest = isEd ? (S.settings.sort_ed_name || "ED") : (S.settings.sort_rf_name || "RF");
  const buttons = isEd
    ? [{ v: "ai", label: t("cat_ai_ed"), cls: "magic" }, { v: "keep", label: t("cat_keep") }]
    : [{ v: "strip", label: t("cat_strip"), cls: "primary" }, { v: "ai", label: t("cat_ai"), cls: "magic" }, { v: "keep", label: t("cat_keep") }];
  const v = await uiDialog({ msg: t(isEd ? "cat_to_ed" : "cat_to_rf"), buttons,
    check: wrong.length ? { label: t("cat_move", { dest }), checked: true } : null });
  const move = wrong.length ? $("#dlgCheck input").checked : false;
  if (wrong.length) S.catMove = { paths: wrong, isEd, move };
  if (v === "strip") {
    if (single) {
      S.form.title = stripEd(S.form.title); S.form.description = stripEd(S.form.description);
      S.form.touched.title = S.form.touched.description = true;
      renderForm(); counters(); setDirty(true);
      toast(t("cat_stripped"), "ok", 4000);
    } else {
      try {
        const d = await api("ed_strip", { paths });
        Object.assign(S.meta, d.meta); Object.assign(S.photoNotes, d.notes || {});
        for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
        await onSelectionChanged();
        $("#edChk").checked = isEd; refreshIl(); counters();
        toast(t("cat_stripped_n", { n: d.count }), "ok", 5000);
        if (wrong.length) offerCatMove(paths, isEd);
      } catch (e) { toast(e.message, "err"); }
    }
  } else if (v === "ai") {
    generate();
  } else if (!single && wrong.length && move) {
    offerCatMove(paths, isEd);                     // vairākām bildēm teksts failā jau ir — pārvietojam uzreiz
  }
});

/* ---------- Iestatījumi: gatavās sērijas, manifestu mape, paziņojumi ---------- */
async function pickInto(input, start) {
  const btns = $$("#readyPick, #mfPick, #readyPlaces button");
  btns.forEach((b) => (b.disabled = true));
  toast(t("pick_open"), "ok", 4000);
  try {
    const r = await api("pick_folder", { start: start || input.value.trim() || input.placeholder });
    if (r.path) input.value = r.path;
  } catch (e) { toast(e.message === "pick_busy" ? t("pick_busy") : e.message, "err"); }
  finally { btns.forEach((b) => (b.disabled = false)); }
}
async function readyPlaces() {
  const box = $("#readyPlaces");
  $$(".rp", box).forEach((b) => b.remove());
  try {
    const d = await api("ready_places");
    $("#sMfDir").placeholder = d.manifest_default || "";
    for (const p of d.places || []) {
      const b = document.createElement("button");
      b.className = "rp"; b.title = p.path;
      b.innerHTML = `${esc(t("rp_" + p.kind))} <span class="muted small">${esc(basename(p.path))}</span>`;
      b.addEventListener("click", () => pickInto($("#sReadyDir"), p.path));
      box.appendChild(b);
    }
  } catch (_) {}
}
$("#readyPick").addEventListener("click", () => pickInto($("#sReadyDir")));
$("#mfPick").addEventListener("click", () => pickInto($("#sMfDir")));
$("#mfDef").addEventListener("click", () => { $("#sMfDir").value = ""; });
$("#sNotify").addEventListener("change", async (e) => {
  if (!e.target.checked) return;
  try {
    const r = await askNotifyPermission(true);
    if (r === "denied" || (("Notification" in window) && Notification.permission === "denied")) toast(t("notify_denied"), "err", 8000);
  } catch (_) {}
});
const _serLoadSettings = loadSettingsPage;
loadSettingsPage = async function () {             // eslint-disable-line no-func-assign
  await _serLoadSettings();
  $("#sReadyDir").value = S.settings.ready_dir || "";
  $("#sMfDir").value = S.settings.manifest_dir || "";
  $("#sNotify").checked = !!S.settings.notify_system;
  $("#sVerify").value = S.settings.ready_verify || "auto";
  readyPlaces();
  aboutRefresh();
};
const _serCollect = collectSettings;
collectSettings = function () {                    // eslint-disable-line no-func-assign
  const v = _serCollect();
  v.ready_dir = $("#sReadyDir").value.trim();
  v.manifest_dir = $("#sMfDir").value.trim();
  v.notify_system = $("#sNotify").checked;
  v.ready_verify = $("#sVerify").value;
  return v;
};
$("#settingsSave").addEventListener("click", () => setTimeout(serRefresh, 600));

/* ---------- mākonis ar tulkojumu: "Rakstības noteikumi AI" un "RF/ED kritēriji" ---------- */
const TRR = new Map();
async function trRulesShow(el) {
  const text = el.value.trim();
  if (!text || window.LANG === "en") return;
  const tip = $("#trTip");
  const seq = ++TR.seq;
  const paint = (body, wait) => {
    tip.classList.add("rules");
    tip.innerHTML = `<div class="tr-head"><span class="tr-lv">${esc((window.LANG || "lv").toUpperCase())}</span> ${esc(t("tr_title"))}</div><div class="tr-body${wait ? " wait" : ""}">${esc(body)}</div>`;
    tip.classList.remove("hidden");
    trPlace(el);
  };
  if (window.LANG === "lv" && /[āčēģīķļņšūž]/i.test(text)) { paint(t("tr_rules_lv")); return; }
  const tk = (window.LANG || "lv") + "|" + text;
  if (TRR.has(tk)) { paint(TRR.get(tk)); return; }
  paint(t("tr_rules_wait"), true);
  try {
    const d = await api("translate_rules", { text });
    if (d.text) TRR.set(tk, d.text);
    if (seq === TR.seq && TR.el === el) paint(d.text || "—");
  } catch (e) { if (seq === TR.seq) paint(t("tr_rules_none") + (e.message && e.message !== CONN_ERR ? "\n(" + e.message + ")" : "")); }
}
for (const id of ["#sStyle", "#sCriteria"]) {
  const el = $(id);
  el.addEventListener("mouseenter", () => {
    clearTimeout(TR.timer); TR.el = el;
    TR.timer = setTimeout(() => { if (TR.el === el && document.activeElement !== el) trRulesShow(el); }, 900);
  });
  el.addEventListener("mouseleave", trHide);
  el.addEventListener("input", trHide);
  el.addEventListener("focus", trHide);
}
for (const id of ["#fTitle", "#fDesc"]) $(id).addEventListener("mouseenter", () => $("#trTip").classList.remove("rules"));

(async function serInit() {
  for (let i = 0; i < 60 && !(S.settings && S.settings.lang); i++) await new Promise((r) => setTimeout(r, 150));
  applyI18n(document);
  serRefresh();
})();
