"""RF / ED šķirošana: bilžu pārvietošana apakšmapēs un atsaukšana."""
from __future__ import annotations

import json
import os
import shutil
import time

from . import config, store
from .i18n import T


def _undo_file():
    return config.app_dir() / "sort_undo.json"


def _unique(target: str) -> str:
    if not os.path.exists(target):
        return target
    base, ext = os.path.splitext(target)
    i = 1
    while os.path.exists(f"{base}_{i}{ext}"):
        i += 1
    return f"{base}_{i}{ext}"


def _companions(path: str) -> list[str]:
    """Bilde un tās 'pavadoņi' ar to pašu nosaukumu (RAW, .xmp sidecar u.c.)."""
    folder, name = os.path.split(path)
    stem = os.path.splitext(name)[0].lower()
    out = [path]
    try:
        for e in os.scandir(folder):
            if e.is_file() and e.path != path and os.path.splitext(e.name)[0].lower() == stem:
                out.append(e.path)
    except OSError:
        pass
    return out


def apply(root: str, moves: list[dict]) -> dict:
    """moves: [{path, category: RF|ED|UNSURE}]. UNSURE paliek pamatmapē."""
    names = {"RF": config.get("sort_rf_name") or "RF", "ED": config.get("sort_ed_name") or "ED"}
    done, errors = [], []
    for m in moves:
        cat = m.get("category")
        if cat not in names:
            continue
        dest_dir = os.path.join(root, names[cat])
        os.makedirs(dest_dir, exist_ok=True)
        for src in _companions(m["path"]):
            try:
                dst = _unique(os.path.join(dest_dir, os.path.basename(src)))
                shutil.move(src, dst)
                store.move_photo(src, dst)
                done.append({"src": src, "dst": dst, "main": src == m["path"], "category": cat})
            except OSError as e:
                errors.append(f"{os.path.basename(src)}: {e}")
    with open(_undo_file(), "w", encoding="utf-8") as f:
        json.dump({"time": time.time(), "root": root, "moves": done}, f, ensure_ascii=False)
    return {"moved": [d for d in done if d["main"]], "count": sum(1 for d in done if d["main"]),
            "errors": errors}


def last() -> dict | None:
    try:
        with open(_undo_file(), encoding="utf-8") as f:
            d = json.load(f)
        return d if d.get("moves") else None
    except (OSError, json.JSONDecodeError):
        return None


def undo() -> dict:
    d = last()
    if not d:
        raise RuntimeError(T("nothing_to_undo"))
    back, errors = 0, []
    for m in reversed(d["moves"]):
        try:
            if os.path.exists(m["dst"]) and not os.path.exists(m["src"]):
                shutil.move(m["dst"], m["src"])
                store.move_photo(m["dst"], m["src"])
                back += 1 if m.get("main") else 0
        except OSError as e:
            errors.append(f"{os.path.basename(m['dst'])}: {e}")
    # tukšās RF/ED mapes izdzēšam
    for name in (config.get("sort_rf_name"), config.get("sort_ed_name")):
        p = os.path.join(d["root"], name or "")
        try:
            if name and os.path.isdir(p) and not os.listdir(p):
                os.rmdir(p)
        except OSError:
            pass
    os.remove(_undo_file())
    return {"count": back, "errors": errors, "root": d["root"]}
