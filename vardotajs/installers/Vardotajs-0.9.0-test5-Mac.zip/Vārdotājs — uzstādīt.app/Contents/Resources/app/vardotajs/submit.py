"""Poga "Uz iesniegšanu": bilžu pārvietošana uz iesniegšanai gatavo bilžu mapi (iestatījums ready_dir; 0.9.0-test4).

Līdzi — RAW / .xmp ar to pašu nosaukumu, piezīmes un pavedieni (store.move_photo), manifests (sērijas ID paliek tas pats).
RF/ED apakšmape saglabā struktūru: …/2026.09-Bali/RF → <mape>/2026.09-Bali/RF. Atsaukšana — submit_undo.json.
"""
from __future__ import annotations

import json
import os
import shutil
import time

from . import config, manifest, sorter, store
from .i18n import T


def _undo_file():
    return config.app_dir() / "submit_undo.json"


def ready_dir() -> str:
    return str(config.get("ready_dir") or "").strip()


def _dest_for(src_folder: str, root: str) -> str:
    src_folder = src_folder.rstrip("\\/")
    base = os.path.basename(src_folder)
    names = {(config.get("sort_rf_name") or "RF").lower(), (config.get("sort_ed_name") or "ED").lower()}
    if base.lower() in names:
        parent = os.path.basename(os.path.dirname(src_folder))
        return os.path.join(root, parent, base) if parent else os.path.join(root, base)
    return os.path.join(root, base)


def plan(paths: list[str]) -> dict:
    root = ready_dir()
    if not root:
        raise RuntimeError(T("ready_dir_none"))
    if not os.path.isdir(root):
        raise RuntimeError(T("ready_dir_missing", path=root))
    groups: dict[str, dict] = {}
    for p in paths:
        src = os.path.dirname(os.path.abspath(p))
        if os.path.normcase(src).startswith(os.path.normcase(os.path.abspath(root)) + os.sep):
            continue                                  # jau ir iesniegšanai gatavo mapē
        g = groups.setdefault(src, {"src": src, "dest": _dest_for(src, root), "paths": []})
        g["paths"].append(p)
    return {"root": root, "groups": list(groups.values()), "count": sum(len(g["paths"]) for g in groups.values())}


def move(paths: list[str]) -> dict:
    pl = plan(paths)
    done, errors, dests = [], [], []
    for g in pl["groups"]:
        src, dest = g["src"], g["dest"]
        os.makedirs(dest, exist_ok=True)
        old = manifest.load(src) or {}
        had_dest = bool(manifest.find(dest))
        moved_stems = {}
        for p in g["paths"]:
            for c in sorter._companions(p):
                try:
                    dst = sorter._unique(os.path.join(dest, os.path.basename(c)))
                    shutil.move(c, dst)
                    store.move_photo(c, dst)
                    done.append({"src": c, "dst": dst, "main": c == p})
                except OSError as e:
                    errors.append(f"{os.path.basename(c)}: {e}")
            moved_stems[os.path.splitext(os.path.basename(p))[0]] = dest
        left = manifest._images(src)
        # galamērķī — manifests vienmēr (sērijas ID no vecās mapes, ja visa sērija pārvietota)
        try:
            manifest.build(dest, series_id=old.get("series_id") if not left and not had_dest else None)
        except Exception as e:
            errors.append(f"manifests: {e}")
        try:
            if left and old:
                manifest.build(src, moved=moved_stems)
            elif not left:
                manifest.remove(src)
        except Exception as e:
            errors.append(f"manifests: {e}")
        dests.append(dest)
    with open(_undo_file(), "w", encoding="utf-8") as f:
        json.dump({"time": time.time(), "moves": done}, f, ensure_ascii=False)
    return {"count": sum(1 for d in done if d["main"]), "errors": errors, "dests": dests, "root": pl["root"]}


def undo() -> dict:
    try:
        with open(_undo_file(), encoding="utf-8") as f:
            d = json.load(f)
    except (OSError, json.JSONDecodeError):
        raise RuntimeError(T("nothing_to_undo"))
    back, errors, folders = 0, [], set()
    for m in reversed(d.get("moves") or []):
        try:
            if os.path.exists(m["dst"]) and not os.path.exists(m["src"]):
                os.makedirs(os.path.dirname(m["src"]), exist_ok=True)
                shutil.move(m["dst"], m["src"])
                store.move_photo(m["dst"], m["src"])
                back += 1 if m.get("main") else 0
                folders.add(os.path.dirname(m["src"]))
                folders.add(os.path.dirname(m["dst"]))
        except OSError as e:
            errors.append(f"{os.path.basename(m['dst'])}: {e}")
    for f in folders:
        try:
            if manifest._images(f):
                manifest.build(f)
            else:
                manifest.remove(f)
                if os.path.isdir(f) and not os.listdir(f):
                    os.rmdir(f)
        except Exception as e:
            print("manifests (atsaukšana):", f, e)
    os.remove(_undo_file())
    return {"count": back, "errors": errors}


def places() -> list[dict]:
    """Ātrās izvēles iestatījumos: OneDrive, Google Drive, NAS (ja atrasti)."""
    from pathlib import Path
    out = []
    try:
        from core.server import _onedrive
        od = str(config.get("onedrive_dir") or "") or _onedrive()
        if od and os.path.isdir(od):
            out.append({"kind": "onedrive", "path": od})
    except Exception:
        pass
    home = Path.home()
    gd = []
    if config.IS_MAC:
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/My Drive"))
        gd += sorted(str(p) for p in (home / "Library" / "CloudStorage").glob("GoogleDrive-*/Mans disks"))
    gd += [str(home / "Google Drive" / "My Drive"), str(home / "Google Drive"), str(home / "My Drive")]
    if config.IS_WIN:
        import string
        for L in string.ascii_uppercase:
            for n in ("My Drive", "Mans disks", "Мой диск"):
                gd.append(f"{L}:\\{n}")
    for p in gd:
        if os.path.isdir(p):
            out.append({"kind": "gdrive", "path": p})
            break
    if config.IS_MAC and os.path.isdir("/Volumes"):
        for n in sorted(os.listdir("/Volumes")):
            p = os.path.join("/Volumes", n)
            if not n.startswith(".") and os.path.isdir(p) and not os.path.islink(p) and n not in ("Macintosh HD", "Recovery"):
                out.append({"kind": "nas", "path": p})
    sd = home / "SynologyDrive"
    if sd.is_dir():
        out.append({"kind": "nas", "path": str(sd)})
    return out
