"""Šabloni un vēsture."""
from __future__ import annotations

import json
import re
import time
import uuid

from . import config

_templates: config.JsonStore | None = None
_history: config.JsonStore | None = None

HISTORY_MAX = 40


def templates() -> config.JsonStore:
    global _templates
    if _templates is None:
        _templates = config.JsonStore(config.app_dir() / "templates.json", [])
    return _templates


def history() -> config.JsonStore:
    global _history
    if _history is None:
        _history = config.JsonStore(config.app_dir() / "history.json", [])
    return _history


def clean_keywords(kws) -> list[str]:
    if isinstance(kws, str):
        kws = re.split(r"[,;\n]", kws)
    out, seen = [], set()
    for k in kws or []:
        k = " ".join(str(k).split()).strip(" ,;")
        if k and k.lower() not in seen:
            seen.add(k.lower())
            out.append(k)
    return out


def list_templates() -> list[dict]:
    return sorted(templates().data, key=lambda t: t.get("name", "").lower())


def save_template(t: dict) -> dict:
    st = templates()
    with st.lock:
        tid = t.get("id") or uuid.uuid4().hex[:10]
        rec = {"id": tid, "name": (t.get("name") or "Jauns šablons").strip(),
               "keywords": clean_keywords(t.get("keywords"))}
        st.data = [x for x in st.data if x.get("id") != tid] + [rec]
        st.save()
        return rec


def delete_template(tid: str) -> None:
    st = templates()
    with st.lock:
        st.data = [x for x in st.data if x.get("id") != tid]
        st.save()


def import_templates(text: str) -> int:
    """Pieņem mūsu JSON eksportu, citu JSON (name/title + keywords) vai teksta rindas 'nosaukums: a, b, c'."""
    items = []
    text = text.strip().lstrip("﻿")
    try:
        data = json.loads(text)
        if isinstance(data, dict):
            data = data.get("templates") or data.get("items") or [
                {"name": k, "keywords": v} for k, v in data.items()]
        for d in data:
            if isinstance(d, dict):
                name = d.get("name") or d.get("title") or d.get("Name") or d.get("Title") or "Importēts"
                kws = d.get("keywords") or d.get("Keywords") or d.get("tags") or ""
                items.append((name, kws))
    except json.JSONDecodeError:
        for line in text.splitlines():
            if ":" in line:
                name, kws = line.split(":", 1)
                items.append((name.strip(), kws))
            elif "\t" in line:
                name, kws = line.split("\t", 1)
                items.append((name.strip(), kws))
    existing = {t["name"].lower(): t for t in templates().data}
    n = 0
    for name, kws in items:
        kws = clean_keywords(kws)
        if not kws:
            continue
        old = existing.get(str(name).lower())
        save_template({"id": old["id"] if old else None, "name": str(name), "keywords": kws})
        n += 1
    return n


def add_history(entry: dict) -> None:
    h = history()
    with h.lock:
        e = {k: entry.get(k) for k in ("path", "title", "description", "keywords", "author")}
        e["time"] = time.time()
        h.data = [x for x in h.data if x.get("path") != e["path"]]
        h.data.insert(0, e)
        del h.data[HISTORY_MAX:]
        h.save()


# --------------------------------------------------------------------------- mapes piezīmes AI un sarunas

import os  # noqa: E402

_notes: config.JsonStore | None = None
_chats: config.JsonStore | None = None
CHAT_MAX = 40


def notes() -> config.JsonStore:
    global _notes
    if _notes is None:
        _notes = config.JsonStore(config.app_dir() / "notes.json", {})
    return _notes


def chats() -> config.JsonStore:
    global _chats
    if _chats is None:
        _chats = config.JsonStore(config.app_dir() / "chats.json", {})
    return _chats


def _fkey(folder: str) -> str:
    return os.path.normcase(os.path.abspath(folder)).rstrip("\\/")


def folder_note(folder: str) -> str:  # noqa: E302
    return notes().data.get(_fkey(folder), {}).get("text", "") if folder else ""


def _set_folder(folder: str, **fields) -> None:
    st = notes()
    with st.lock:
        k = _fkey(folder)
        d = dict(st.data.get(k) or {})
        d["path"] = folder
        d.update(fields)
        if not d.get("text") and not d.get("instr") and not d.get("generic"):
            st.data.pop(k, None)
        else:
            st.data[k] = d
        st.save()


def set_folder_note(folder: str, text: str) -> None:
    _set_folder(folder, text=(text or "").strip())


# --- norādījumi AI (nevis fakti, bet kā rakstīt): mapei (mantojas) un bildēm
def folder_instr(folder: str) -> dict:
    d = notes().data.get(_fkey(folder), {}) if folder else {}
    return {"instr": d.get("instr", ""), "generic": bool(d.get("generic"))}


def set_folder_instr(folder: str, instr: str | None = None, generic: bool | None = None) -> None:
    f = {}
    if instr is not None:
        f["instr"] = instr.strip()
    if generic is not None:
        f["generic"] = bool(generic)
    _set_folder(folder, **f)


def instructions_for(path: str) -> dict:
    """Visi norādījumi bildei: vecākmapju + mapes + pašas bildes. generic=True, ja kaut kur ieslēgts."""
    texts, generic = [], False
    cur = os.path.abspath(os.path.dirname(path))
    chain = []
    seen = set()
    while cur and cur not in seen:
        seen.add(cur)
        chain.append(cur)
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    for f in reversed(chain):
        fi = folder_instr(f)
        if fi["instr"]:
            texts.append(fi["instr"])
        generic = generic or fi["generic"]
    d = photos().data.get(_fkey(path)) or {}
    if d.get("instr"):
        texts.append(d["instr"])
    generic = generic or bool(d.get("generic"))
    return {"texts": texts, "generic": generic}


def add_folder_note(folder: str, line: str) -> None:
    line = (line or "").strip()
    if not line:
        return
    cur = folder_note(folder)
    if line.lower() in cur.lower():
        return
    set_folder_note(folder, (cur + "\n" + line).strip())


def inherited_notes(folder: str) -> list[dict]:
    """Piezīmes no šīs mapes un visām vecākmapēm (sākot ar augstāko)."""
    out = []
    cur = os.path.abspath(folder)
    seen = set()
    while cur and cur not in seen:
        seen.add(cur)
        t = folder_note(cur)
        if t:
            out.append({"path": cur, "text": t})
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    return list(reversed(out))


def notes_text_for(path_or_folder: str, is_file: bool = True) -> str:
    folder = os.path.dirname(path_or_folder) if is_file else path_or_folder
    return "\n".join(n["text"] for n in inherited_notes(folder))


def get_chat(folder: str) -> list[dict]:
    return chats().data.get(_fkey(folder), [])


def add_chat(folder: str, role: str, text: str, extra: dict | None = None) -> None:
    st = chats()
    with st.lock:
        k = _fkey(folder)
        msgs = st.data.get(k, [])
        m = {"role": role, "text": text}
        if extra:
            m.update(extra)
        msgs.append(m)
        st.data[k] = msgs[-CHAT_MAX:]
        st.save()


def _drop_line(text: str, line: str) -> str:
    key = (line or "").strip().lower()
    return "\n".join(x for x in (text or "").split("\n") if x.strip().lower() != key).strip()


def forget_chat_fact(folder: str, idx: int) -> dict:
    """Noņem sarunā pierakstīto faktu (📌) no vietas, kur tas saglabāts, un atzīmē ziņu kā noņemtu."""
    st = chats()
    with st.lock:
        msgs = st.data.get(_fkey(folder), [])
        if not (0 <= idx < len(msgs)) or not msgs[idx].get("remember"):
            raise ValueError("no fact")
        m = msgs[idx]
        line = m["remember"]
        removed = 0
        # mapes piezīme
        cur = folder_note(folder)
        if line.strip().lower() in [x.strip().lower() for x in cur.split("\n")]:
            set_folder_note(folder, _drop_line(cur, line))
            removed += 1
        # bilžu piezīmes: zināmie ceļi; vecām ziņām — visas šīs mapes bildes
        paths = m.get("paths") or []
        if not paths:
            base = _fkey(folder)
            paths = [d.get("path") for k, d in photos().data.items()
                     if os.path.dirname(k) == base and d.get("path")]
        for p in paths:
            t = get_photo(p)["text"]
            if t and line.strip().lower() in [x.strip().lower() for x in t.split("\n")]:
                set_photo_note(p, _drop_line(t, line))
                removed += 1
        m["forgotten"] = True
        if idx > 0 and msgs[idx - 1].get("role") == "user":
            msgs[idx - 1]["forgotten"] = True
        st.save()
    return {"removed": removed}


def clear_chat(folder: str) -> None:
    st = chats()
    with st.lock:
        st.data.pop(_fkey(folder), None)
        st.save()


# --------------------------------------------------------------------------- bilžu piezīmes un AI pavedieni

_photos: config.JsonStore | None = None


def photos() -> config.JsonStore:
    global _photos
    if _photos is None:
        _photos = config.JsonStore(config.app_dir() / "photo_notes.json", {})
    return _photos


def text_sig(title: str, description: str) -> str:
    import hashlib
    return hashlib.sha1((" ".join((title or "").split()) + "|" + " ".join((description or "").split()))
                        .encode("utf-8")).hexdigest()[:16]


def get_cut_ok(path: str) -> str:
    return (photos().data.get(_fkey(path)) or {}).get("cut_ok", "")


def get_cut_lvl(path: str) -> str:
    return (photos().data.get(_fkey(path)) or {}).get("cut_lvl", "auto")


def set_cut_ok(path: str, sig: str, level: str = "auto") -> None:
    """level 'auto' — teksts nāk no Vārdotāja (paslēpj tikai 'gandrīz pie limita' aizdomas);
    'user' — lietotājs apstiprināja (paslēpj visu, izņemot 'par garu')."""
    _update_photo(path, cut_ok=sig, cut_lvl=level)


def _view(d: dict) -> dict:
    return {"text": d.get("text", ""), "hint": d.get("hint", ""), "conf": d.get("conf", ""), "ok": bool(d.get("ok")),
            "flags": d.get("flags") or [], "advice": d.get("advice", ""), "draft": d.get("draft") or None,
            "instr": d.get("instr", ""), "generic": bool(d.get("generic")), "rules": d.get("rules", "")}


# --- AI melnraksti (virsraksts/apraksts/atslēgvārdi, kas vēl NAV ierakstīti failā)
def get_draft(path: str) -> dict | None:
    return (photos().data.get(_fkey(path)) or {}).get("draft") or None


def set_draft(path: str, draft: dict | None) -> None:
    if draft:
        draft = dict(draft)
        draft["time"] = time.time()
    _update_photo(path, draft=draft or None)


def set_photo_instr(path: str, instr: str | None = None, generic: bool | None = None) -> None:
    f = {}
    if instr is not None:
        f["instr"] = instr.strip()
    if generic is not None:
        f["generic"] = bool(generic)
    _update_photo(path, **f)


def set_photo_rules(path: str, rules: str) -> None:
    _update_photo(path, rules=(rules or "").strip())


# --- fotografēšanas noteikumi pēc vietas (viens ieraksts vietai, ne katrai bildei)
_places: config.JsonStore | None = None


def places() -> config.JsonStore:
    global _places
    if _places is None:
        _places = config.JsonStore(config.app_dir() / "place_rules.json", {})
    return _places


def _pkey(place: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", (place or "").lower()).strip()


def get_place_rules(place: str) -> dict | None:
    return places().data.get(_pkey(place)) if place else None


def set_place_rules(place: str, rules: str, source: str = "ai", sources: list | None = None) -> None:
    if not place or not (rules or "").strip():
        return
    st = places()
    with st.lock:
        k = _pkey(place)
        cur = st.data.get(k)
        if cur and cur.get("source") == "web" and source != "web":
            return          # internetā pārbaudītu nepārrakstām ar AI minējumu
        st.data[k] = {"place": place, "rules": rules.strip(), "source": source, "sources": sources or [],
                      "time": time.time()}
        st.save()


def has_draft(path: str) -> bool:
    return bool(get_draft(path))


def get_photo(path: str) -> dict:
    return _view(photos().data.get(_fkey(path)) or {})


def get_photos(paths: list[str]) -> dict:
    data = photos().data
    out = {}
    for p in paths:
        d = data.get(_fkey(p))
        if d:
            out[p] = _view(d)
    return out


def _update_photo(path: str, **fields) -> None:
    st = photos()
    with st.lock:
        k = _fkey(path)
        d = dict(st.data.get(k) or {})
        d["path"] = path
        d.update(fields)
        if not d.get("text") and not d.get("hint") and not d.get("flags") and not d.get("advice") and not d.get("cut_ok") \
                and not d.get("draft") and not d.get("instr") and not d.get("generic") and not d.get("rules"):
            st.data.pop(k, None)
        else:
            st.data[k] = d
        st.save()


def set_photo_note(path: str, text: str) -> None:
    _update_photo(path, text=(text or "").strip())


def add_photo_note(path: str, line: str) -> None:
    line = (line or "").strip()
    if not line:
        return
    cur = get_photo(path)["text"]
    if line.lower() in cur.lower():
        return
    set_photo_note(path, (cur + "\n" + line).strip())


def set_hint(path: str, hint: str, conf: str = "", ok: bool = False) -> None:
    _update_photo(path, hint=(hint or "").strip(), conf=conf, ok=bool(ok))


def set_risk(path: str, flags: list[str], advice: str) -> None:
    _update_photo(path, flags=list(flags or []), advice=(advice or "").strip())


def move_photo(src: str, dst: str) -> None:
    st = photos()
    with st.lock:
        d = st.data.pop(_fkey(src), None)
        if d:
            d["path"] = dst
            st.data[_fkey(dst)] = d
            st.save()


# --------------------------------------------------------------------------- tulkojumu kešs (EN -> LV)

import hashlib  # noqa: E402

_tr: config.JsonStore | None = None
TR_MAX = 5000


def _tr_store() -> config.JsonStore:
    global _tr
    if _tr is None:
        _tr = config.JsonStore(config.app_dir() / "translations.json", {})
    return _tr


def _tkey(text: str) -> str:
    return hashlib.sha1(" ".join((text or "").split()).encode("utf-8")).hexdigest()[:20]


def tr_get(texts: list[str]) -> dict:
    data = _tr_store().data
    out = {}
    for t in texts:
        d = data.get(_tkey(t)) if t else None
        if d:
            out[t] = d.get("lv", "") if isinstance(d, dict) else str(d)
    return out


def tr_put(pairs: dict) -> None:
    if not pairs:
        return
    st = _tr_store()
    with st.lock:
        now = time.time()
        for en, lv in pairs.items():
            if en and lv:
                st.data[_tkey(en)] = {"lv": lv, "t": now}
        if len(st.data) > TR_MAX:
            for k, _ in sorted(st.data.items(), key=lambda kv: kv[1].get("t", 0) if isinstance(kv[1], dict) else 0)[
                    :len(st.data) - TR_MAX]:
                st.data.pop(k, None)
        st.save()
