"""Failu sistēma: diski, mapes, bilžu saraksti un sīktēli."""
from __future__ import annotations

import hashlib
import io
import os
import string
from pathlib import Path

from PIL import Image, ImageOps

from . import config
from .i18n import T

IMAGE_EXT = {".jpg", ".jpeg", ".tif", ".tiff", ".png", ".webp"}

Image.MAX_IMAGE_PIXELS = 400_000_000


def roots() -> list[dict]:
    out = []
    if config.IS_WIN:
        for letter in string.ascii_uppercase:
            p = f"{letter}:\\"
            if os.path.exists(p):
                out.append({"name": f"{letter}:", "path": p})
    else:
        home = str(Path.home())
        out.append({"name": T("home_folder"), "path": home})
        for sub in ("Pictures", "Desktop", "Downloads"):
            p = os.path.join(home, sub)
            if os.path.isdir(p):
                out.append({"name": sub, "path": p})
        if config.IS_MAC and os.path.isdir("/Volumes"):
            for n in sorted(os.listdir("/Volumes")):
                p = os.path.join("/Volumes", n)
                if os.path.isdir(p) and not n.startswith("."):
                    out.append({"name": n, "path": p})
        out.append({"name": "/", "path": "/"})
    return out


def _hidden(entry: os.DirEntry) -> bool:
    n = entry.name
    if n.startswith(".") or n.startswith("$") or n in ("System Volume Information", "__MACOSX"):
        return True
    if config.IS_WIN:
        try:
            attrs = entry.stat(follow_symlinks=False).st_file_attributes
            return bool(attrs & 0x2 or attrs & 0x4)  # HIDDEN | SYSTEM
        except Exception:
            return False
    return False


def subdirs(path: str) -> list[dict]:
    res = []
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_dir() and not _hidden(e):
                        res.append({"name": e.name, "path": e.path, "children": _has_subdir(e.path)})
                except OSError:
                    pass
    except OSError:
        return []
    res.sort(key=lambda d: d["name"].lower())
    return res


def _has_subdir(path: str) -> bool:
    try:
        with os.scandir(path) as it:
            for e in it:
                try:
                    if e.is_dir() and not e.name.startswith("."):
                        return True
                except OSError:
                    pass
    except OSError:
        pass
    return False


def listing(path: str, depth: int = 0, sort: str = "name") -> dict:
    """Bildes (un depth=0 gadījumā arī apakšmapes) dotajā mapē."""
    folders, images = [], []

    def walk(p: str, level: int):
        try:
            with os.scandir(p) as it:
                entries = list(it)
        except OSError:
            return
        for e in entries:
            try:
                if _hidden(e):
                    continue
                if e.is_dir():
                    if level == 0 and depth == 0:
                        folders.append({"name": e.name, "path": e.path})
                    if depth < 0 or level < depth:
                        walk(e.path, level + 1)
                elif os.path.splitext(e.name)[1].lower() in IMAGE_EXT:
                    st = e.stat()
                    images.append({"name": e.name, "path": e.path, "size": st.st_size,
                                   "mtime": st.st_mtime,
                                   "rel": os.path.relpath(e.path, path)})
            except OSError:
                pass

    walk(path, 0)
    folders.sort(key=lambda d: d["name"].lower())
    keyf = {
        "name": lambda d: d["rel"].lower(),
        "name_desc": lambda d: d["rel"].lower(),
        "date": lambda d: d["mtime"],
        "date_desc": lambda d: d["mtime"],
        "size": lambda d: d["size"],
    }.get(sort, lambda d: d["rel"].lower())
    images.sort(key=keyf, reverse=sort in ("name_desc", "date_desc"))
    parent = os.path.dirname(path.rstrip("\\/")) if path.rstrip("\\/") else None
    if parent == path or not parent:
        parent = None
    return {"path": path, "parent": parent, "folders": folders, "images": images}


# --------------------------------------------------------------------------- sīktēli

def _thumb_dir() -> Path:
    d = config.app_dir() / "thumbs"
    d.mkdir(exist_ok=True)
    return d


def _load_scaled(path: str, size: int) -> Image.Image:
    im = Image.open(path)
    if im.format == "JPEG":
        im.draft("RGB", (size * 2, size * 2))
    im = ImageOps.exif_transpose(im)
    if im.mode not in ("RGB", "L"):
        bg = Image.new("RGB", im.size, (255, 255, 255))
        im2 = im.convert("RGBA")
        bg.paste(im2, mask=im2.split()[-1])
        im = bg
    elif im.mode == "L":
        im = im.convert("RGB")
    im.thumbnail((size, size), Image.LANCZOS)
    return im


def thumbnail(path: str, size: int = 300) -> bytes:
    st = os.stat(path)
    h = hashlib.sha1(f"{path}|{st.st_mtime_ns}|{st.st_size}|{size}".encode("utf-8")).hexdigest()
    cache = _thumb_dir() / f"{h}.jpg"
    if cache.exists():
        return cache.read_bytes()
    im = _load_scaled(path, size)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=82)
    data = buf.getvalue()
    try:
        cache.write_bytes(data)
    except OSError:
        pass
    return data


def ai_image(path: str, out_path: str, size: int = 1568) -> None:
    """Samazināta kopija AI analīzei (ietaupa limitus un laiku)."""
    im = _load_scaled(path, size)
    im.save(out_path, "JPEG", quality=88)


def clear_thumb_cache() -> int:
    n = 0
    for f in _thumb_dir().glob("*.jpg"):
        try:
            f.unlink()
            n += 1
        except OSError:
            pass
    return n
