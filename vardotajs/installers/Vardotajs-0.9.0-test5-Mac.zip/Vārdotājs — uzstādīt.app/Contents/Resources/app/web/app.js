"use strict";
/* Vārdotājs — saskarne */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const lower = (s) => String(s).toLocaleLowerCase();

/* "Failed to fetch" (programma neatbild) — nevis sarkanu paziņojumu kaudze, bet viena josla augšā ar "Mēģināt vēlreiz"
   (0.9.0-test4, kā core.js Analītiķī) */
const CONN_ERR = "__conn_lost__";
const CONN = { since: 0, timer: null };
function connLost() {
  if (!CONN.since) CONN.since = Date.now();
  let box = $("#connLost");
  if (!box) {
    document.body.insertAdjacentHTML("beforeend", `<div id="connLost" class="conn-lost"><span id="connLostMsg"></span><button id="connRetry"></button></div>`);
    box = $("#connLost");
    $("#connRetry").addEventListener("click", () => connRetry(true));
  }
  box.classList.remove("hidden");
  $("#connLostMsg").textContent = t(Date.now() - CONN.since > 15000 ? "conn_dead" : "conn_lost");
  $("#connRetry").textContent = t("conn_retry");
  if (!CONN.timer) CONN.timer = setTimeout(connRetry, 3000);
}
async function connRetry(manual = false) {
  clearTimeout(CONN.timer); CONN.timer = null;
  try {
    const r = await fetch("/api/ping", { method: "POST", headers: { "Content-Type": "application/json", "X-Token": window.TOKEN }, body: "{}", cache: "no-store" });
    if (r.status === 403 || r.ok) {
      // serveris atbild: ja žetons mainījies (programma palaista no jauna) — pārlādējam lapu
      if (r.status === 403) { location.reload(); return; }
      CONN.since = 0; $("#connLost")?.classList.add("hidden"); if (manual) toast(t("conn_ok"), "ok", 2000); return;
    }
  } catch (_) { /* vēl neatbild */ }
  try { const r = await fetch("/", { cache: "no-store" }); if (r.ok) { location.reload(); return; } } catch (_) {}
  connLost();
}
async function api(name, body = {}) {
  let r;
  try {
    r = await fetch("/api/" + name, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Token": window.TOKEN },
      body: JSON.stringify(body),
    });
  } catch (e) { connLost(); throw new Error(CONN_ERR); }
  if (CONN.since) { CONN.since = 0; $("#connLost")?.classList.add("hidden"); }
  const d = await r.json();
  if (!d.ok) throw new Error(d.error || "Error");
  return d;
}
const thumbUrl = (p, s = 300) => `/thumb?t=${encodeURIComponent(window.TOKEN)}&s=${s}&path=${encodeURIComponent(p)}`;
const previewUrl = (p) => `/preview?t=${encodeURIComponent(window.TOKEN)}&path=${encodeURIComponent(p)}`;

function toast(msg, kind = "", ms = 3500) {
  if (String(msg).includes(CONN_ERR) || /^(Failed to fetch|Load failed|NetworkError)/.test(String(msg))) { connLost(); return; }
  const el = document.createElement("div");
  el.className = "toast " + kind;
  // kļūdas un "sticky" paziņojumi paliek, līdz tos aizver
  const sticky = kind.includes("err") || kind.includes("sticky");
  el.innerHTML = `<span>${esc(msg)}</span>` + (sticky ? `<button class="tclose" title="×">×</button>` : "");
  if (sticky) $(".tclose", el).addEventListener("click", () => el.remove());
  $("#toasts").appendChild(el);
  if (!sticky) setTimeout(() => el.remove(), ms);
  else setTimeout(() => el.remove(), Math.max(ms, 60000));
}
function notify(msg) {
  try {
    if (S.settings?.notify_system && document.hidden && "Notification" in window && Notification.permission === "granted") new Notification("Vārdotājs", { body: msg, icon: "/static/icon.svg" });
  } catch (_) {}
}
/* Sistēmas paziņojumi — tikai, ja ieslēgts Iestatījumi → Cits (0.9.0-test4: Edge vairs nejautā pēkšņi pie AI darba) */
function askNotifyPermission(force = false) {
  if (!force && !S.settings?.notify_system) return;
  try { if ("Notification" in window && Notification.permission === "default") return Notification.requestPermission(); } catch (_) {}
}
/* --- programmas dialogi (pārlūka confirm/prompt var tikt bloķēti) --- */
let dlgResolve = null;
function uiDialog({ msg, input = null, buttons, check = null }) {
  return new Promise((resolve) => {
    if (dlgResolve) dlgResolve(null);
    dlgResolve = resolve;
    $("#dlgMsg").textContent = msg;
    const ck = $("#dlgCheck");
    ck.classList.toggle("hidden", !check);
    if (check) { $("span", ck).textContent = check.label; $("input", ck).checked = !!check.checked; }
    const inp = $("#dlgInput");
    inp.classList.toggle("hidden", input === null);
    inp.value = input ?? "";
    const box = $("#dlgBtns");
    box.innerHTML = "";
    buttons.forEach((b, i) => {
      const el = document.createElement("button");
      el.textContent = b.label;
      if (b.cls) el.className = b.cls;
      el.addEventListener("click", () => closeDlg(b.v === "__input" ? inp.value : b.v));
      box.appendChild(el);
    });
    $("#dlg").classList.remove("hidden");
    setTimeout(() => (input !== null ? inp : box.querySelector("button"))?.focus(), 30);
  });
}
function closeDlg(v) {
  $("#dlg").classList.add("hidden");
  const r = dlgResolve; dlgResolve = null;
  if (r) r(v);
}
document.addEventListener("keydown", (e) => {
  if ($("#dlg").classList.contains("hidden")) return;
  if (e.key === "Escape") { e.preventDefault(); e.stopImmediatePropagation(); closeDlg(null); }
  else if (e.key === "Enter") {
    e.preventDefault(); e.stopImmediatePropagation();
    const first = $("#dlgBtns button");
    if (!$("#dlgInput").classList.contains("hidden")) closeDlg($("#dlgInput").value);
    else if (document.activeElement?.parentElement?.id === "dlgBtns") document.activeElement.click();
    else first?.click();
  }
}, true);
async function uiConfirm(msg) {
  return (await uiDialog({ msg, buttons: [{ v: true, label: "OK", cls: "primary" }, { v: false, label: t("cancel") }] })) === true;
}
// apstiprinājums ar ķeksi: atgriež null (atcelts) vai ķekša vērtību (true/false)
async function uiConfirmCheck(msg, label, checked = true) {
  const v = await uiDialog({ msg, check: { label, checked }, buttons: [{ v: true, label: "OK", cls: "primary" }, { v: false, label: t("cancel") }] });
  return v === true ? $("#dlgCheck input").checked : null;
}
async function uiPrompt(msg, def = "") {
  const v = await uiDialog({ msg, input: def, buttons: [{ v: "__input", label: "OK", cls: "primary" }, { v: null, label: t("cancel") }] });
  return v === null || v === undefined ? null : String(v);
}
function basename(p) { return p.split(/[\\/]/).filter(Boolean).pop() || p; }
function shortName(n, max = 22) {
  if (n.length <= max) return n;
  const dot = n.lastIndexOf(".");
  const ext = dot > 0 ? n.slice(dot) : "";
  const keep = max - ext.length - 1;
  return n.slice(0, Math.ceil(keep * 0.55)) + "…" + n.slice(dot > 0 ? dot - Math.floor(keep * 0.45) : -Math.floor(keep * 0.45));
}
function splitKw(text) {
  return String(text).split(/[,;\n]/).map((s) => s.trim().replace(/\s+/g, " ")).filter(Boolean);
}
function uniqKw(list) {
  const seen = new Set(), out = [];
  for (const k of list) { const l = lower(k); if (!seen.has(l)) { seen.add(l); out.push(k); } }
  return out;
}
const one = (n) => window.LANG === "lv" && n % 10 === 1 && n % 100 !== 11;
const tn = (key, n) => t(one(n) ? key + "1" : key, { n });

/* ============================================================ stāvoklis */
const S = {
  settings: {},
  path: "",
  back: [], fwd: [],
  folders: [], images: [],
  status: {},
  selected: new Set(),
  anchor: null,
  meta: {},
  form: null,
  dirty: false,
  templates: [],
  history: [],
  clip: null,
  jobs: [],
  working: new Set(),
  reviewed: new Set(),
  photoNotes: {},
  placeRules: {},
  chatBusy: false,
};

/* ============================================================ valoda */
function setLang(lang, persist = true) {
  window.LANG = lang === "en" ? "en" : "lv";
  applyI18n();
  $("#langQuick").value = window.LANG;
  if ($("#sLang")) $("#sLang").value = window.LANG;
  if (persist) api("settings", { settings: { lang: window.LANG } }).then((d) => (S.settings = d.settings)).catch(() => {});
  // dinamiskās daļas
  updateCount();
  if (S.form) { renderForm(); refreshEditorHead(); }
  else refreshGenLabel();
  renderHistory();
  renderChat();
  updateChatSel();
  renderHintBox();
  renderCutBox();
  renderPhotoNotes();
  paintAccBadge(S.auth);
  if (S.images.length) for (const [p, st] of Object.entries(S.status)) paintStatus(p, st);
  if (!$("#page-settings").classList.contains("hidden")) loadSettingsPage();
  if (!$("#page-templates").classList.contains("hidden")) renderTplList();
  pollJobs();
  initTree().then(() => S.path && revealInTree(S.path));
}
$("#langQuick").addEventListener("change", (e) => setLang(e.target.value));

/* ============================================================ lapas */
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));
function showPage(name) {
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "templates") renderTplList();
  if (name === "settings") loadSettingsPage();
}

/* ============================================================ koks */
async function initTree() {
  const { roots } = await api("roots");
  const tree = $("#tree");
  tree.innerHTML = "";
  for (const r of roots) tree.appendChild(makeNode(r.name, r.path, 0, true, true));
}
function makeNode(name, path, lvl, hasChildren, isRoot = false) {
  const n = document.createElement("div");
  n.className = "tnode";
  n.dataset.path = path;
  n.innerHTML = `<div class="trow" style="--lvl:${lvl}"><span class="tw">${hasChildren ? "▶" : ""}</span><span class="fi ${isRoot ? "drive" : ""}"></span><span class="tn">${esc(name)}</span></div><div class="tkids hidden"></div>`;
  $(".tw", n).addEventListener("click", (e) => { e.stopPropagation(); toggleNode(n); });
  $(".trow", n).addEventListener("click", () => navigate(path));
  $(".trow", n).addEventListener("dblclick", () => toggleNode(n));
  n._lvl = lvl;
  return n;
}
async function toggleNode(n, forceOpen = false, reload = false) {
  const kids = $(".tkids", n);
  const tw = $(".tw", n);
  if (!tw.textContent && !reload) return;
  const open = !kids.classList.contains("hidden");
  if (open && !forceOpen && !reload) { kids.classList.add("hidden"); tw.textContent = "▶"; return; }
  if (!n._loaded || reload) {
    const { dirs } = await api("dirs", { path: n.dataset.path });
    kids.innerHTML = "";
    for (const d of dirs) kids.appendChild(makeNode(d.name, d.path, n._lvl + 1, d.children));
    n._loaded = true;
    tw.textContent = dirs.length ? "▼" : "";
  }
  kids.classList.remove("hidden");
  if (tw.textContent) tw.textContent = "▼";
}
const normP = (p) => lower(p.replace(/[\\/]+$/, "")).replace(/\\/g, "/");
function treeNode(path) {
  const target = normP(path);
  return $$("#tree .tnode").find((n) => normP(n.dataset.path) === target);
}
async function revealInTree(path) {
  $$(".tnode.current").forEach((x) => x.classList.remove("current"));
  const target = normP(path);
  let best = null;
  for (const n of $$("#tree > .tnode")) {
    const np = normP(n.dataset.path);
    if (target === np || target.startsWith(np === "" ? "/" : np + "/") || np === "") {
      if (!best || np.length > normP(best.dataset.path).length) best = n;
    }
  }
  let node = best;
  while (node) {
    if (normP(node.dataset.path) === target) break;
    await toggleNode(node, true);
    let next = null;
    for (const k of $$(":scope > .tkids > .tnode", node)) {
      const kp = normP(k.dataset.path);
      if (target === kp || target.startsWith(kp + "/")) { next = k; break; }
    }
    node = next;
  }
  if (node) {
    node.classList.add("current");
    $(".trow", node).scrollIntoView({ block: "nearest" });
  }
}

/* ============================================================ režģis */
async function navigate(path, push = true) {
  if (!path) return;
  if (!(await confirmLeave())) return;
  let d;
  try {
    const so = $("#sortSel").value;
    d = await api("list", { path, depth: +$("#depthSel").value, sort: so.startsWith("st_") ? "name" : so });
  } catch (e) { toast(e.message, "err"); return; }
  if (push && S.path && S.path !== d.path) { S.back.push(S.path); S.fwd = []; }
  S.path = d.path;
  S.parent = d.parent;
  S.folders = d.folders;
  S.images = d.images;
  S.status = {};
  S.photoNotes = {};
  S.selected.clear();
  S.anchor = null;
  $("#pathInput").value = d.path;
  renderGrid();
  onSelectionChanged(true);
  revealInTree(d.path);
  loadNotes();
  refreshUndoSort();
  refreshEdSwap();
  refreshFixCut();
  loadPhotoNotes();
  loadStatuses();
}
async function loadPhotoNotes() {
  const path = S.path;
  try {
    const { notes } = await api("photo_notes", { paths: S.images.map((i) => i.path) });
    if (S.path !== path) return;
    S.photoNotes = notes;
  } catch (_) { return; }
  for (const im of S.images) paintFlags(im.path);
  renderHintBox();
  renderPhotoNotes();
}
function paintFlags(p) {
  const el = tileByPath(p);
  if (!el) return;
  const ph = S.photoNotes[p];
  const im = S.images.find((x) => x.path === p);
  let box = $(".flags", el);
  if (!box) { box = document.createElement("div"); box.className = "flags"; el.appendChild(box); }
  const marks = [];
  if (ph?.hint) marks.push(`<span title="${esc(ph.hint)}">🔎</span>`);
  if (ph?.flags?.length) marks.push(`<span>⚠</span>`);
  if (S.status[p]?.cut) marks.push(`<span class="cut" title="${esc(t("cut_mark"))}">✂</span>`);
  if (S.status[p]?.draft) marks.push(`<span class="dr">✎</span>`);
  box.innerHTML = marks.join("");
  const tip = [im ? im.rel : basename(p)];
  if (ph?.hint) tip.push("🔎 " + ph.hint);
  if (ph?.flags?.length) tip.push("⚠ " + ph.flags.map((f) => t("fl_" + f)).join(", ") + (ph.advice ? " — " + ph.advice : ""));
  if (S.status[p]?.cut) tip.push(t("cut_mark"));
  if (S.status[p]?.draft) tip.push("✎ " + t("st_draft"));
  $(".nm", el).title = tip.join("\n");
}
function cutPaths() {
  const base = S.selected.size ? S.images.filter((i) => S.selected.has(i.path)) : S.images;
  return base.filter((i) => S.status[i.path]?.cut).map((i) => i.path);
}
function renderDraftBox() {
  const sel = S.form ? S.form.paths : [];
  const n = sel.filter((p) => S.photoNotes[p]?.draft).length;
  const box = $("#draftBox");
  box.classList.toggle("hidden", !n);
  if (!n) return;
  const single = sel.length === 1;
  $("#draftMsg").textContent = single ? t("draft_one") : t("draft_many", { n, m: sel.length });
  $("#draftApply").classList.toggle("hidden", single);
  $("#draftApply").textContent = t("draft_apply", { n });
}
$("#draftDiscard").addEventListener("click", async () => {
  const paths = (S.form ? S.form.paths : []).filter((p) => S.photoNotes[p]?.draft);
  if (!paths.length || !await uiConfirm(t("draft_discard_q", { n: paths.length }))) return;
  try {
    const d = await api("draft_discard", { paths });
    Object.assign(S.photoNotes, d.notes); for (const p of paths) if (!d.notes[p]) delete S.photoNotes[p];
    for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
    setDirty(false); onSelectionChanged();
  } catch (e) { toast(e.message, "err"); }
});
$("#draftApply").addEventListener("click", async () => {
  const paths = (S.form ? S.form.paths : []).filter((p) => S.photoNotes[p]?.draft);
  if (!paths.length || !await uiConfirm(t("draft_apply_q", { n: paths.length }))) return;
  try {
    const d = await api("draft_apply", { paths });
    Object.assign(S.meta, d.meta);
    for (const p of paths) { if (d.notes[p]) S.photoNotes[p] = d.notes[p]; else delete S.photoNotes[p]; }
    for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
    toast(t("draft_applied", { n: d.count }), "ok");
    refreshFixCut(); applyFilter(); onSelectionChanged();
  } catch (e) { toast(e.message, "err"); }
});
function renderCutBox() {
  const sel = S.form ? S.form.paths : [];
  const bad = sel.filter((p) => S.status[p]?.cut);
  $("#cutBox").classList.toggle("hidden", !bad.length);
  if (!bad.length) return;
  const why = S.status[bad[0]].cut_why || {};
  const parts = Object.entries(why).map(([f, r]) => t("cut_f_" + f) + " — " + t("cut_r_" + r));
  $("#cutBox span").textContent = "✂ " + (parts.join("; ") || t("cut_box")) + (bad.length > 1 ? " (" + bad.length + ")" : "");
}
$("#cutOk").addEventListener("click", async () => {
  const paths = (S.form ? S.form.paths : []).filter((p) => S.status[p]?.cut);
  try {
    const d = await api("cut_ok", { paths });
    for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
    refreshFixCut();
  } catch (e) { toast(e.message, "err"); }
});
$("#cutFix").addEventListener("click", async () => {
  const paths = (S.form ? S.form.paths : []).filter((p) => S.status[p]?.cut);
  if (!paths.length || !(await confirmLeave())) return;
  try {
    const d = await api("fix_cut", { paths, root: S.path });
    if (!d.job) { toast(t("fixcut_none")); return; }
    paths.forEach((p) => markWorking(p, true));
    toast(t("fixcut_started", { n: d.count }), "ok");
    pollJobs();
  } catch (e) { toast(e.message, "err"); }
});
function refreshFixCut() {
  renderCutBox();
  const n = S.images.filter((i) => S.status[i.path]?.cut).length;
  $("#fixCutBtn").classList.toggle("hidden", !n);
  $("#fixCutN").textContent = n ? String(n) : "";
}
$("#fixCutBtn").addEventListener("click", async () => {
  const paths = cutPaths();
  if (!paths.length) { toast(t("fixcut_none")); return; }
  if (!await uiConfirm(t("fixcut_q", { n: paths.length }))) return;
  if (!(await confirmLeave())) return;
  try {
    const d = await api("fix_cut", { paths, root: S.path });
    if (!d.job) { toast(t("fixcut_none")); return; }
    paths.forEach((p) => markWorking(p, true));
    toast(t("fixcut_started", { n: d.count }), "ok");
    pollJobs();
  } catch (e) { toast(e.message, "err"); }
});
const ST_ORDER = { none: 0, partial: 1, full: 2 };
function applyStatusSort() {
  const so = $("#sortSel").value;
  if (!so.startsWith("st_")) return;
  const dir = so === "st_none" ? 1 : -1;
  const rank = (p) => ST_ORDER[S.status[p]?.status] ?? 1;
  S.images.sort((a, b) => (rank(a.path) - rank(b.path)) * dir || a.rel.toLowerCase().localeCompare(b.rel.toLowerCase()));
  const anchorPath = S.anchor != null ? S.images[S.anchor]?.path : null;
  renderGrid();
  for (const im of S.images) {
    const el = tileByPath(im.path);
    if (el) el.classList.toggle("selected", S.selected.has(im.path));
    if (S.status[im.path]) paintStatus(im.path, S.status[im.path]);
  }
  if (anchorPath) S.anchor = S.images.findIndex((x) => x.path === anchorPath);
  for (const im of S.images) paintFlags(im.path);
  applyFilter();
}
async function loadStatuses() {
  const path = S.path;
  const all = S.images.map((i) => i.path);
  for (let i = 0; i < all.length; i += 150) {
    try {
      const { status } = await api("status", { paths: all.slice(i, i + 150) });
      if (S.path !== path) return;
      Object.assign(S.status, status);
      for (const [p, st] of Object.entries(status)) paintStatus(p, st);
    } catch (e) { toast(e.message, "err", 8000); return; }
  }
  applyFilter();
  applyStatusSort();
  refreshFixCut();
}
function paintStatus(p, st) {
  const tile = tileByPath(p);
  if (!tile) return;
  const el = $(".st", tile);
  const draft = st?.draft && st.status !== "full";
  el.className = "st " + (draft ? "draft" : st?.status || "");
  el.title = st ? (draft ? t("st_draft") : t("st_" + st.status) + (st.kw ? ", " + t("st_kw", { n: st.kw }) : "")) + (st.draft && !draft ? " · " + t("st_draft") : "") : "";
  tile.classList.toggle("cut", !!st?.cut);
  paintFlags(p);
}
function tileByPath(p) { return S.tileIndex ? S.tileIndex.get(p) : null; }
function renderGrid() {
  const g = $("#grid");
  g.innerHTML = "";
  S.tileIndex = new Map();
  const frag = document.createDocumentFragment();
  const showFolders = +$("#depthSel").value === 0;
  if (showFolders) {
    for (const f of S.folders) {
      const el = document.createElement("div");
      el.className = "tile folder";
      el.innerHTML = `<div class="imgbox"><div class="bigfolder"></div></div><div class="nm" title="${esc(f.name)}">${esc(f.name)}</div>`;
      el.addEventListener("dblclick", () => navigate(f.path));
      frag.appendChild(el);
    }
  }
  S.images.forEach((im, idx) => {
    const el = document.createElement("div");
    el.className = "tile img";
    el.innerHTML = `<div class="imgbox"><img loading="lazy" decoding="async" src="${thumbUrl(im.path, 300)}" alt=""></div><span class="st"></span><div class="nm" title="${esc(im.rel)}">${esc(shortName(im.rel, 24))}</div>`;
    el.addEventListener("mousedown", (e) => onTileClick(e, idx));
    el.addEventListener("dblclick", () => openLightbox(im.path));
    S.tileIndex.set(im.path, el);
    frag.appendChild(el);
  });
  if (!S.images.length && !(showFolders && S.folders.length)) {
    const e = document.createElement("div");
    e.className = "grid-empty";
    e.textContent = t("no_images");
    frag.appendChild(e);
  }
  g.appendChild(frag);
  for (const p of S.working) { const el = tileByPath(p); if (el) el.classList.add("working"); }
  updateCount();
}
function passFilter(p) {
  const f = $("#filterSel").value, st = S.status[p];
  return f === "all" || (f === "draft" ? !!st?.draft : f === "cut" ? !!st?.cut : st?.status === f);
}
function visibleIdx() {
  return S.images.map((_, i) => i).filter((i) => passFilter(S.images[i].path));
}
function applyFilter() {
  const f = $("#filterSel").value;
  S.images.forEach((im) => {
    const el = tileByPath(im.path);
    if (el) el.classList.toggle("hidden", !passFilter(im.path));
  });
  updateCount();
}
function updateCount() {
  const n = S.images.length;
  const known = Object.values(S.status);
  const none = known.filter((s) => s.status === "none").length;
  const full = known.filter((s) => s.status === "full").length;
  let txt = tn("count_img", n);
  if (known.length) txt += ", " + tn("count_full", full) + ", " + t("count_none", { n: none });
  if (S.selected.size) txt += " — " + tn("count_sel", S.selected.size);
  $("#gridCount").textContent = txt;
}
async function onTileClick(e, idx) {
  if (e.button !== 0) return;
  const p = S.images[idx].path;
  const multi = e.ctrlKey || e.metaKey;
  let next = new Set(S.selected);
  if (e.shiftKey && S.anchor != null) {
    const vis = visibleIdx();
    const a = vis.indexOf(S.anchor), b = vis.indexOf(idx);
    if (!multi) next = new Set();
    const [lo, hi] = a < b ? [a, b] : [b, a];
    for (let i = lo; i <= hi; i++) if (i >= 0) next.add(S.images[vis[i]].path);
  } else if (multi) {
    next.has(p) ? next.delete(p) : next.add(p);
    S.anchor = idx;
  } else {
    if (next.size === 1 && next.has(p)) return;
    next = new Set([p]);
    S.anchor = idx;
  }
  await setSelection(next);
}
async function setSelection(next) {
  if (!(await confirmLeave())) return;
  S.selected = next;
  for (const im of S.images) {
    const el = tileByPath(im.path);
    if (el) el.classList.toggle("selected", next.has(im.path));
  }
  updateCount();
  onSelectionChanged();
}
async function confirmLeave() {
  if (!S.dirty) return true;
  const r = await uiDialog({ msg: t("unsaved_q2"), buttons: [
    { v: "save", label: t("save"), cls: "primary" }, { v: "discard", label: t("discard") }, { v: null, label: t("cancel") }] });
  if (r === "save") return await save_();
  if (r === "discard") { S.dirty = false; return true; }
  return false;
}

/* ============================================================ redaktors */
let selToken = 0;
function refreshGenLabel() {
  const n = S.selected.size;
  if ($("#genBtn").classList.contains("busy")) return;
  $("#genLabel").textContent = n > 1 ? t("gen_many", { n }) : t("gen_one");
}
function refreshEditorHead() {
  const paths = [...S.selected];
  if (!paths.length) return;
  $("#selName").textContent = paths.length === 1 ? basename(paths[0]) : t("selected_n", { n: paths.length });
  refreshGenLabel();
}
async function onSelectionChanged(clear = false) {
  const paths = [...S.selected];
  const tok = ++selToken;
  showWarnings([]);
  updateChatSel();
  $("#chatUpdated").classList.add("hidden");
  if (!paths.length || clear) {
    S.form = null; setDirty(false);
    $("#editor").classList.add("hidden");
    $("#editEmpty").classList.remove("hidden");
    return;
  }
  $("#editEmpty").classList.add("hidden");
  $("#editor").classList.remove("hidden");
  const first = paths[0];
  $("#selPreview").src = thumbUrl(first, 400);
  $("#selMeta").textContent = "";
  refreshEditorHead();
  $("#revealBtn").classList.toggle("hidden", paths.length !== 1);
  try {
    const { editorial } = await api("is_editorial", { path: first });
    if (tok === selToken) { $("#edChk").checked = editorial; refreshIl(); counters(); }
  } catch (_) {}
  let meta;
  try {
    meta = (await api("read", { paths, info: paths.length === 1 })).meta;
  } catch (e) { toast(e.message, "err", 8000); return; }
  if (tok !== selToken) return;
  Object.assign(S.meta, meta);
  if (paths.length === 1) {
    const m = meta[first];
    const im = S.images.find((x) => x.path === first);
    const bits = [];
    if (m.size) bits.push(m.size.replace(" ", " × ") + " px");
    if (im) bits.push((im.size / 1048576).toFixed(1) + " MB");
    if (m.date) bits.push(m.date.slice(0, 10).replace(/:/g, "."));
    if (m.camera) bits.push(m.camera);
    $("#selMeta").textContent = bits.join(", ");
  }
  // AI melnraksts (vēl nav failā): vienai bildei ieliekam to laukos — Saglabāt to apstiprina
  const dr = paths.length === 1 ? S.photoNotes[first]?.draft : null;
  if (dr) {
    fillForm([{ ...meta[first], title: dr.title || "", description: dr.description || "", keywords: dr.keywords || [] }]);
    S.form.touched.title = S.form.touched.description = true;
    S.form.fromDraft = true;
    if (dr.cat) { $("#edChk").checked = dr.cat === "ED"; refreshIl(); counters(); }
    showWarnings(dr.warnings || []);
  } else fillForm(paths.map((p) => meta[p]));
  renderHintBox();
  renderCutBox();
  renderDraftBox();
  renderPhotoNotes();
}
function fillForm(list) {
  const single = list.length === 1;
  const f = { mixed: {}, touched: {}, multi: !single, paths: list.map((m) => m.path) };
  for (const k of ["title", "description"]) {
    const vals = new Set(list.map((m) => m[k] || ""));
    if (vals.size === 1) f[k] = [...vals][0];
    else { f[k] = ""; f.mixed[k] = true; }
  }
  if (single) f.keywords = [...list[0].keywords];
  else {
    const sets = list.map((m) => new Set(m.keywords.map(lower)));
    f.keywords = list[0].keywords.filter((k) => sets.every((s) => s.has(lower(k))));
  }
  f.common = [...f.keywords];
  S.form = f;
  renderForm();
  setDirty(false);
}
function renderForm() {
  const f = S.form;
  for (const [id, k] of [["#fTitle", "title"], ["#fDesc", "description"]]) {
    const el = $(id);
    el.value = f[k];
    el.placeholder = f.mixed[k] ? t("mixed_ph") : "";
    el.classList.toggle("mixed", !!f.mixed[k]);
  }
  const note = $("#multiNote");
  if (f.multi) { note.classList.remove("hidden"); note.textContent = t("multi_note", { n: f.paths.length }); }
  else note.classList.add("hidden");
  renderChips();
  counters();
  requestAnimationFrame(autosizeAll);
}
function showWarnings(list) {
  const box = $("#warnBox");
  if (!list || !list.length) { box.classList.add("hidden"); box.textContent = ""; return; }
  box.innerHTML = list.map((w) => "⚠ " + esc(w)).join("<br>");
  box.classList.remove("hidden");
}
function counters() {
  const st = S.settings;
  const set = (id, len, max) => {
    const el = $(id);
    el.textContent = max ? `${len} / ${max}` : `${len}`;
    el.classList.toggle("over", !!max && len > max);
  };
  set("#cTitle", $("#fTitle").value.length, st.title_max);
  set("#cDesc", $("#fDesc").value.length, $("#edChk").checked && st.editorial_format ? (st.ed_description_max || 200) : st.description_max);
  const n = S.form ? S.form.keywords.length : 0;
  const el = $("#cKw");
  el.textContent = `(${n}${st.keywords_count ? " / " + st.keywords_count : ""})`;
  el.classList.toggle("over", n > 50);
  el.title = t("kw_limit");
}
function setDirty(v) {
  S.dirty = v;
  $("#dirtyMark").classList.toggle("hidden", !v);
}
function autosize(el) {
  if (!el || el.offsetParent === null) return;
  el.style.height = "auto";
  el.style.height = el.scrollHeight + 2 + "px";
}
function autosizeAll() { $$("textarea.autosize").forEach(autosize); }
window.addEventListener("resize", autosizeAll);
$("#kwText").addEventListener("input", (e) => autosize(e.target));
for (const [id, k] of [["#fTitle", "title"], ["#fDesc", "description"]]) {
  $(id).addEventListener("input", () => {
    autosize($(id));
    if (!S.form) return;
    S.form[k] = $(id).value;
    S.form.touched[k] = true;
    setDirty(true);
    counters();
  });
}

/* --- atslēgvārdu čipi --- */
let dragIdx = null;
function renderChips(newOnes = null) {
  const box = $("#chips");
  box.innerHTML = "";
  if (!S.form) return;
  S.form.keywords.forEach((k, i) => {
    const c = document.createElement("span");
    c.className = "chip" + (i < 10 ? " top10" : "") + (newOnes && newOnes.has(lower(k)) ? " ai-new" : "");
    if (newOnes) c.style.animationDelay = Math.min(i * 18, 700) + "ms";
    c.draggable = true;
    c.title = i < 10 ? t("kw_top10") : t("kw_drag");
    c.innerHTML = `<span class="t">${esc(k)}</span><button class="x" title="${esc(t("remove"))}" tabindex="-1">×</button>`;
    $(".x", c).addEventListener("click", () => { S.form.keywords.splice(i, 1); kwChanged(); });
    c.addEventListener("dblclick", async () => {
      const v = await uiPrompt(t("kw_edit_q"), k);
      if (v != null && v.trim()) { S.form.keywords[i] = v.trim(); S.form.keywords = uniqKw(S.form.keywords); kwChanged(); }
    });
    c.addEventListener("dragstart", (e) => { dragIdx = i; c.classList.add("dragging"); e.dataTransfer.effectAllowed = "move"; });
    c.addEventListener("dragend", () => { dragIdx = null; renderChips(); });
    c.addEventListener("dragover", (e) => { e.preventDefault(); $$(".chip.drop-before").forEach((x) => x.classList.remove("drop-before")); c.classList.add("drop-before"); });
    c.addEventListener("drop", (e) => {
      e.preventDefault();
      if (dragIdx == null || dragIdx === i) return;
      const [m] = S.form.keywords.splice(dragIdx, 1);
      S.form.keywords.splice(dragIdx < i ? i - 1 : i, 0, m);
      dragIdx = null;
      kwChanged();
    });
    box.appendChild(c);
  });
  $("#kwText").value = S.form.keywords.join(", ");
}
function kwChanged(newOnes = null) { setDirty(true); renderChips(newOnes); counters(); }
function addKeywords(list) {
  if (!S.form) return;
  const before = S.form.keywords.length;
  S.form.keywords = uniqKw([...S.form.keywords, ...list]);
  if (S.form.keywords.length !== before) kwChanged();
}
$("#kwAdd").addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === ",") {
    e.preventDefault();
    addKeywords(splitKw(e.target.value));
    e.target.value = "";
  } else if (e.key === "Backspace" && !e.target.value && S.form?.keywords.length) {
    S.form.keywords.pop(); kwChanged();
  }
});
$("#kwAdd").addEventListener("paste", (e) => {
  const txt = (e.clipboardData || window.clipboardData).getData("text");
  if (/[,;\n]/.test(txt)) { e.preventDefault(); addKeywords(splitKw(txt)); }
});
$("#kwAdd").addEventListener("blur", (e) => { if (e.target.value.trim()) { addKeywords(splitKw(e.target.value)); e.target.value = ""; } });
$("#asText").addEventListener("change", (e) => {
  const on = e.target.checked;
  $("#chips").classList.toggle("hidden", on);
  $("#kwAdd").classList.toggle("hidden", on);
  $("#kwText").classList.toggle("hidden", !on);
  localStorage.setItem("asText", on ? "1" : "");
});
$("#kwText").addEventListener("input", (e) => {
  if (!S.form) return;
  S.form.keywords = uniqKw(splitKw(e.target.value));
  setDirty(true);
  counters();
});
$("#kwText").addEventListener("blur", () => renderChips());
$("#kwClear").addEventListener("click", async () => { if (S.form && S.form.keywords.length && await uiConfirm(t("kw_clear_q"))) { S.form.keywords = []; kwChanged(); } });
$("#kwCopy").addEventListener("click", async () => {
  if (!S.form) return;
  try { await navigator.clipboard.writeText(S.form.keywords.join(", ")); toast(t("kw_copied")); }
  catch (_) { toast(t("clip_fail"), "err"); }
});

/* --- AI pavediens (atpazītā vieta / objekts) --- */
function renderHintBox() {
  const box = $("#hintBox");
  const paths = [...S.selected];
  if (!paths.length) { box.classList.add("hidden"); return; }
  box.classList.remove("hidden");
  const hints = paths.map((p) => S.photoNotes[p]?.hint || "");
  const first = S.photoNotes[paths[0]] || {};
  let html = "";
  if (paths.length === 1) {
    if (first.hint) {
      const badge = first.ok ? t("hint_ok") : first.conf === "sure" ? t("hint_sure") : t("hint_maybe");
      html = `<div class="hint-line">🔎 <span class="muted">${esc(t("hint_label"))}:</span> <b>${esc(first.hint)}</b> <span class="hint-badge ${first.ok ? "ok" : first.conf}">${esc(badge)}</span></div>
        <div class="hint-btns">
          <button data-a="copy">${esc(t("hint_copy"))}</button>
          <button data-a="edit">${esc(t("hint_edit"))}</button>
          ${first.ok ? "" : `<button data-a="confirm">${esc(t("hint_confirm"))}</button>`}
          <button data-a="group">${esc(t("hint_group"))}</button>
          <button data-a="remove" class="link">${esc(t("hint_remove"))}</button>
        </div>`;
    } else {
      html = `<div class="hint-line muted">🔎 ${esc(t("hint_none"))}</div><div class="hint-btns"><button data-a="edit">${esc(t("hint_add"))}</button></div>`;
    }
  } else {
    const uniq = [...new Set(hints.filter(Boolean))];
    const list = uniq.length === 0 ? t("hint_none") : uniq.length === 1 ? uniq[0] : t("hint_mixed") + " (" + uniq.length + ")";
    html = `<div class="hint-line">🔎 ${esc(t("hint_multi", { list }))}</div>
      <div class="hint-btns"><button data-a="all">${esc(t("hint_apply_all", { n: paths.length }))}</button>
      ${uniq.length === 1 ? `<button data-a="copy">${esc(t("hint_copy"))}</button>` : ""}</div>`;
  }
  const fl = [...new Set(paths.flatMap((p) => S.photoNotes[p]?.flags || []))];
  const adv = paths.length === 1 ? (first.advice || "") : "";
  if (fl.length || adv) {
    html += `<div class="risk-line">⚠ <b>${esc(t("risk_label"))}:</b> ${esc(fl.map((f) => t("fl_" + f)).join(", ") || "—")}${adv ? `<div class="risk-adv">${esc(adv)}</div>` : ""}</div>`;
  }
  // fotografēšanas noteikumi vietā (AI zināšanas vai pārbaudīti internetā)
  if (paths.length === 1 && first.hint) {
    const pr = S.placeRules[first.hint];
    const txt = pr?.rules || first.rules || "";
    const src = pr?.source === "web"
      ? t("rules_web", { d: new Date((pr.time || 0) * 1000).toLocaleDateString() })
      : t("rules_ai");
    html += `<div class="rules-line">📜 <b>${esc(t("rules_label"))}:</b> ${txt ? esc(txt) : `<span class="muted">${esc(t("rules_none"))}</span>`}
      ${txt ? `<span class="hint-badge ${pr?.source === "web" ? "ok" : "maybe"}">${esc(src)}</span>` : ""}
      ${(pr?.sources || []).map((u, i) => `<a href="${esc(u)}" target="_blank" rel="noopener">[${i + 1}]</a>`).join(" ")}
      <div class="hint-btns"><button data-a="rulesweb">${esc(t("rules_check"))}</button></div></div>`;
    if (!(first.hint in S.placeRules)) {
      S.placeRules[first.hint] = null;
      api("place_rules", { place: first.hint }).then((d) => { S.placeRules[first.hint] = d.rules; renderHintBox(); }).catch(() => {});
    }
  }
  box.innerHTML = html;
  $$("button", box).forEach((b) => b.addEventListener("click", () => hintAction(b.dataset.a)));
  renderInstrBox();
}
/* --- norādījumi AI (bildēm) --- */
function renderInstrBox() {
  const paths = [...S.selected];
  const box = $("#instrBox");
  box.classList.toggle("hidden", !paths.length);
  if (!paths.length) return;
  const g = paths.map((p) => !!S.photoNotes[p]?.generic);
  const chk = $("#genericChk");
  chk.checked = g.every(Boolean);
  chk.indeterminate = !chk.checked && g.some(Boolean);
  $("#genericFolder").classList.toggle("hidden", !S.notes?.generic_inherited);
  const texts = [...new Set(paths.map((p) => S.photoNotes[p]?.instr || ""))];
  const ta = $("#instrText");
  if (document.activeElement !== ta) {
    ta.value = texts.length === 1 ? texts[0] : "";
    ta.placeholder = texts.length === 1 ? t("instr_ph") : t("mixed_ph");
  }
  const has = texts.some(Boolean);
  $("#instrMark").textContent = has ? "●" : "";
  if (has && !$("#instrDet").open && texts.length === 1) $("#instrDet").open = true;
}
async function setPhotoInstr(body) {
  const paths = [...S.selected];
  if (!paths.length) return;
  const d = await api("photo_instr_set", { paths, ...body });
  for (const p of paths) { if (d.notes[p]) S.photoNotes[p] = d.notes[p]; else delete S.photoNotes[p]; }
  $("#instrSaved").textContent = t("notes_saved");
  setTimeout(() => ($("#instrSaved").textContent = ""), 1500);
}
$("#genericChk").addEventListener("change", (e) => setPhotoInstr({ generic: e.target.checked }).then(renderInstrBox).catch((x) => toast(x.message, "err")));
let instrTimer = null;
$("#instrText").addEventListener("input", () => {
  clearTimeout(instrTimer);
  const v = $("#instrText").value;
  instrTimer = setTimeout(() => setPhotoInstr({ instr: v }).catch((x) => toast(x.message, "err")), 700);
});
/* --- norādījumi AI (mapei) --- */
async function setFolderInstr(body) {
  if (!S.path) return;
  const d = await api("folder_instr_set", { folder: S.path, ...body });
  S.notes.instr = d.instr; S.notes.generic = d.generic; S.notes.generic_inherited = d.generic_inherited;
  $("#notesSaved").textContent = t("notes_saved");
  setTimeout(() => ($("#notesSaved").textContent = ""), 1500);
  renderInstrBox();
}
$("#fGeneric").addEventListener("change", (e) => setFolderInstr({ generic: e.target.checked }).catch((x) => toast(x.message, "err")));
let fInstrTimer = null;
$("#fInstr").addEventListener("input", () => {
  clearTimeout(fInstrTimer);
  const v = $("#fInstr").value;
  fInstrTimer = setTimeout(() => setFolderInstr({ instr: v }).catch((x) => toast(x.message, "err")), 700);
});
async function setHint(paths, hint, ok = true) {
  const d = await api("hint_set", { paths, hint, ok, conf: "sure" });
  for (const p of paths) {
    if (d.notes[p]) S.photoNotes[p] = d.notes[p]; else delete S.photoNotes[p];
    paintFlags(p);
  }
  renderHintBox();
}
async function checkRulesWeb(place) {
  toast(t("rules_checking", { p: place }), "ok", 4000);
  try {
    const d = await api("place_rules_check", { place });
    S.placeRules[place] = d.rules;
    showNotices(d);
    toast(d.result.rules ? t("rules_checked") : t("rules_notfound"), d.result.rules ? "ok" : "", 5000);
    renderHintBox();
  } catch (e) { toast(e.message, "err", 10000); }
}
async function hintAction(a) {
  if (a === "rulesweb") { const p = [...S.selected][0]; const h = S.photoNotes[p]?.hint; if (h) checkRulesWeb(h); return; }
  const paths = [...S.selected];
  const first = S.photoNotes[paths[0]] || {};
  const uniq = [...new Set(paths.map((p) => S.photoNotes[p]?.hint).filter(Boolean))];
  try {
    if (a === "copy") {
      await navigator.clipboard.writeText(first.hint || uniq[0] || "");
      toast(t("hint_copied"));
    } else if (a === "edit") {
      const v = await uiPrompt(t("hint_edit_q"), first.hint || "");
      if (v != null) await setHint(paths, v.trim(), true);
    } else if (a === "confirm") {
      await setHint(paths, first.hint, true);
    } else if (a === "remove") {
      await setHint(paths, "", false);
    } else if (a === "all") {
      const v = await uiPrompt(t("hint_edit_q"), uniq.length === 1 ? uniq[0] : "");
      if (v != null && v.trim()) { await setHint(paths, v.trim(), true); toast(t("hint_applied", { n: paths.length }), "ok"); }
    } else if (a === "group") {
      const h = lower(first.hint || "");
      const sel = S.images.filter((im) => lower(S.photoNotes[im.path]?.hint || "") === h).map((im) => im.path);
      await setSelection(new Set(sel));
      toast(t("hint_group_sel", { n: sel.length }));
    }
  } catch (e) { toast(e.message, "err"); }
}

/* --- šablonu izvēlne --- */
$("#tplBtn").addEventListener("click", (e) => {
  e.stopPropagation();
  const m = $("#tplMenu");
  if (!m.classList.contains("hidden")) { m.classList.add("hidden"); return; }
  m.innerHTML = "";
  for (const tp of S.templates) {
    const b = document.createElement("button");
    b.textContent = `${tp.name} (${tp.keywords.length})`;
    b.addEventListener("click", () => { addKeywords(tp.keywords); m.classList.add("hidden"); });
    m.appendChild(b);
  }
  if (S.templates.length) m.appendChild(document.createElement("hr"));
  const s = document.createElement("button");
  s.textContent = t("tpl_save_current");
  s.addEventListener("click", async () => {
    m.classList.add("hidden");
    if (!S.form?.keywords.length) { toast(t("no_kw_to_save")); return; }
    const name = await uiPrompt(t("tpl_name_q"));
    if (!name) return;
    const d = await api("template_save", { name, keywords: S.form.keywords });
    S.templates = d.templates;
    toast(t("tpl_saved_named", { name }), "ok");
  });
  m.appendChild(s);
  m.classList.remove("hidden");
});
document.addEventListener("click", (e) => { if (!e.target.closest(".dropdown")) $("#tplMenu").classList.add("hidden"); });

/* --- saglabāšana --- */
function buildSaveItems() {
  const f = S.form;
  if (!f) return [];
  const clean = (s) => s.replace(/\s+/g, " ").trim();
  if (!f.multi) {
    return [{ path: f.paths[0], title: clean(f.title), description: clean(f.description), keywords: f.keywords }];
  }
  const cur = new Set(f.keywords.map(lower));
  const orig = new Set(f.common.map(lower));
  const removed = new Set([...orig].filter((k) => !cur.has(k)));
  const added = f.keywords.filter((k) => !orig.has(lower(k)));
  return f.paths.map((p) => {
    const it = { path: p };
    for (const k of ["title", "description"]) {
      if (f.touched[k] && !(f.mixed[k] && !f[k].trim())) it[k] = clean(f[k]);
    }
    if (removed.size || added.length) {
      const base = (S.meta[p]?.keywords || []).filter((k) => !removed.has(lower(k)));
      it.keywords = uniqKw([...base, ...added]);
    }
    return it;
  });
}
async function save_() {
  if (!S.form) return true;
  if ($("#genBtn").classList.contains("busy")) { toast(t("wait_ai")); return false; }
  const items = buildSaveItems();
  const btn = $("#saveBtn");
  btn.disabled = true;
  try {
    const d = await api("save", { items, texts_touched: !!(S.form.touched.title || S.form.touched.description) });
    Object.assign(S.meta, d.meta);
    if (S.form.touched.title || S.form.touched.description) for (const p of Object.keys(d.status)) if (S.photoNotes[p]) S.photoNotes[p].draft = null;
    for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
    refreshFixCut(); renderDraftBox();
    S.history = d.history; renderHistory();
    const errs = Object.entries(d.errors);
    if (errs.length) toast(t("save_failed", { n: errs.length, e: errs[0][1] }), "err", 8000);
    else toast(items.length === 1 ? t("saved_one") : t("saved_many", { n: items.length }), "ok", 1800);
    setDirty(false);
    S.form.common = [...S.form.keywords];
    S.form.touched = {};
    updateCount();
    if (!errs.length) setTimeout(() => offerCatMove(items.map((i) => i.path), $("#edChk").checked), 50);
    return !errs.length;
  } catch (e) {
    toast(e.message, "err", 8000);
    return false;
  } finally { btn.disabled = false; }
}
$("#saveBtn").addEventListener("click", save_);
/* RF/ED mapē mainīts veids (Editorial ķeksis) — piedāvāt pārvietot uz otru mapi */
async function offerCatMove(paths, isEd) {
  const rf = lower(S.settings.sort_rf_name || "RF"), ed = lower(S.settings.sort_ed_name || "ED");
  const parentName = (p) => lower(basename(p.replace(/[\\/][^\\/]+$/, "")));
  const target = isEd ? "ED" : "RF";
  const wrong = paths.filter((p) => parentName(p) === (isEd ? rf : ed));
  if (!wrong.length) return;
  const dest = isEd ? (S.settings.sort_ed_name || "ED") : (S.settings.sort_rf_name || "RF");
  let always = !!S.settings.auto_move_cat;
  const pre = S.catMove && S.catMove.isEd === isEd && wrong.every((p) => S.catMove.paths.includes(p)) ? S.catMove : null;
  S.catMove = null;
  if (pre && !pre.move) return;                // jau atbildēts kategorijas maiņas dialogā (0.9.0-test4)
  if (!always && !pre) {
    const r = await uiConfirmCheck(t(wrong.length === 1 ? "move_cat_q1" : "move_cat_q", { n: wrong.length, cat: target, dest }), t("move_cat_always"), false);
    if (r === null) return;
    always = r;
  }
  try {
    const d = await api("move_cat", { moves: wrong.map((path) => ({ path, category: target })), always });
    if (always) S.settings.auto_move_cat = true;
    toast(t("move_cat_done", { n: d.count, dest }) + (d.errors.length ? " — " + d.errors[0] : ""), d.errors.length ? "err" : "ok", 6000);
    const n = treeNode(S.path.replace(/[\\/][^\\/]+$/, ""));
    if (n) await toggleNode(n, true, true);
    navigate(S.path, false);
    refreshUndoSort();
  } catch (e) { toast(e.message, "err"); }
}
$("#revertBtn").addEventListener("click", () => { if (S.form) { fillForm(S.form.paths.map((p) => S.meta[p])); showWarnings([]); } });
$("#copyMeta").addEventListener("click", () => {
  if (!S.form) return;
  S.clip = { title: S.form.title, description: S.form.description, keywords: [...S.form.keywords] };
  toast(t("copied_all"));
});
$("#pasteMeta").addEventListener("click", () => applyData(S.clip));
function applyData(d, replaceKw = false) {
  if (!d || !S.form) return;
  if (d.title) { S.form.title = d.title; S.form.touched.title = true; }
  if (d.description) { S.form.description = d.description; S.form.touched.description = true; }
  if (d.keywords?.length) {
    if (S.form.multi && !replaceKw) S.form.keywords = uniqKw([...S.form.keywords, ...d.keywords]);
    else S.form.keywords = [...d.keywords];
  }
  S.form.mixed = {};
  renderForm();
  setDirty(true);
}
$("#revealBtn").addEventListener("click", () => { const p = [...S.selected][0]; if (p) api("reveal", { path: p }).catch((e) => toast(e.message, "err")); });
$("#selPreview").addEventListener("click", () => { const p = [...S.selected][0]; if (p) openLightbox(p); });

/* --- AI ģenerēšana --- */
$("#genBtn").addEventListener("click", generate);
function showNotices(d) {
  (d.notices || []).forEach((n) => { toast(n, "ok sticky"); notify(n); });
  if (d.provider && d.provider !== S.provider) { S.provider = d.provider; refreshAccBadge(); }
}
async function generate() {
  if (!S.form) return;
  const paths = [...S.selected];
  if (paths.length > 1) { openBatch(paths); return; }
  const btn = $("#genBtn");
  btn.classList.add("busy");
  $("#saveBtn").disabled = true;
  $("#genLabel").textContent = t("gen_busy");
  const p = paths[0];
  markWorking(p, true);
  try {
    const d = await api("generate", { path: p, editorial: $("#edChk").checked, illustrative: ilOn() });
    showNotices(d);
    if (!S.form || S.form.paths[0] !== p) { toast(t("gen_moved")); return; }
    const r = d.result;
    const before = new Set(S.form.keywords.map(lower));
    S.form.title = r.title; S.form.description = r.description; S.form.keywords = r.keywords;
    S.form.touched.title = S.form.touched.description = true;
    S.form.mixed = {};
    renderForm();
    renderChips(new Set(r.keywords.map(lower).filter((k) => !before.has(k))));
    showWarnings(r.warnings);
    setDirty(true);
    toast(t("gen_done"), "ok");
  } catch (e) {
    toast(e.message, "err", 10000);
  } finally {
    markWorking(p, false);
    btn.classList.remove("busy");
    $("#saveBtn").disabled = false;
    refreshGenLabel();
  }
}
function markWorking(p, on) {
  on ? S.working.add(p) : S.working.delete(p);
  const el = tileByPath(p);
  if (el) el.classList.toggle("working", on);
}
function openBatch(paths) {
  S.batchPaths = paths;
  $("#batchTitle").textContent = t("batch_title", { n: paths.length });
  $("#bEd").checked = $("#edChk").checked;
  $("#bIl").checked = ilOn();
  $("#bTpl").innerHTML = `<option value="">${esc(t("batch_no_tpl"))}</option>` + S.templates.map((tp) => `<option value="${esc(tp.id)}">${esc(tp.name)} (${tp.keywords.length})</option>`).join("");
  $("#batchModal").classList.remove("hidden");
}
$("#bCancel").addEventListener("click", () => $("#batchModal").classList.add("hidden"));
$("#bStart").addEventListener("click", async () => {
  $("#batchModal").classList.add("hidden");
  const paths = S.batchPaths || [];
  try {
    const il = $("#bIl").checked;
    await api("batch", { paths, template_id: $("#bTpl").value, autosave: $("#bSave").checked, editorial: ($("#bEd").checked || il) ? true : null, illustrative: il });
    paths.forEach((p) => markWorking(p, true));
    toast(t("batch_started", { n: paths.length }), "ok");
    pollJobs();
  } catch (e) { toast(e.message, "err"); }
});

/* ============================================================ saruna ar AI */
S.chat = [];
S.notes = { own: "", inherited: [] };
async function loadNotes() {
  if (!S.path) return;
  try {
    const d = await api("notes", { folder: S.path });
    S.notes = { own: d.own, inherited: d.inherited, instr: d.instr, generic: d.generic, generic_inherited: d.generic_inherited };
    S.chat = d.chat;
  } catch (_) { S.notes = { own: "", inherited: [] }; S.chat = []; }
  renderNotes();
  renderChat();
}
function renderPhotoNotes() {
  const sec = $("#photoNotesSec");
  const paths = [...S.selected];
  if (!paths.length) { sec.classList.add("hidden"); return; }
  sec.classList.remove("hidden");
  $("#photoNotesLabel").textContent = paths.length === 1 ? t("photo_notes_one") + ": " + basename(paths[0]) : t("photo_notes_many", { n: paths.length });
  const texts = [...new Set(paths.map((p) => S.photoNotes[p]?.text || ""))];
  const ta = $("#photoNotesText");
  if (document.activeElement !== ta) {
    ta.value = texts.length === 1 ? texts[0] : "";
    ta.placeholder = texts.length === 1 ? t("photo_notes_ph") : t("mixed_ph");
  }
}
let photoNotesTimer = null;
$("#photoNotesText").addEventListener("input", () => {
  clearTimeout(photoNotesTimer);
  const paths = [...S.selected];
  photoNotesTimer = setTimeout(async () => {
    const d = await api("photo_note_set", { paths, text: $("#photoNotesText").value });
    for (const p of paths) { if (d.notes[p]) S.photoNotes[p] = d.notes[p]; else delete S.photoNotes[p]; }
    $("#notesSaved").textContent = t("notes_saved");
    setTimeout(() => ($("#notesSaved").textContent = ""), 1500);
  }, 700);
});
function renderNotes() {
  $("#chatFolder").textContent = S.path ? basename(S.path) : "";
  $("#notesText").value = S.notes.own || "";
  if (document.activeElement !== $("#fInstr")) $("#fInstr").value = S.notes.instr || "";
  $("#fGeneric").checked = !!S.notes.generic;
  const inh = S.notes.inherited || [];
  $("#notesInherited").innerHTML = inh.length
    ? `<div class="muted small">${esc(t("notes_inherited"))}</div>` + inh.map((n) => `<div class="inh"><b>${esc(basename(n.path))}:</b> ${esc(n.text)}</div>`).join("")
    : "";
  const total = (S.notes.own ? S.notes.own.split("\n").filter(Boolean).length : 0) + inh.length + (S.notes.instr || S.notes.generic ? 1 : 0);
  $("#notesCount").textContent = total ? `(${total})` : "";
}
function renderChat() {
  const log = $("#chatLog");
  if (!log) return;
  log.innerHTML = "";
  const msgs = S.chat.length ? S.chat : [{ role: "assistant", text: t("chat_hello"), hello: true }];
  msgs.forEach((m, idx) => {
    const div = document.createElement("div");
    div.className = "msg " + (m.role === "user" ? "me" : "ai") + (m.hello ? " hello" : "") + (m.forgotten ? " forgotten" : "");
    div.textContent = m.text;
    if (m.remember) {
      const r = document.createElement("div");
      r.className = "remember" + (m.forgotten ? " off" : "");
      const where = m.scope === "folder" ? t("remember_folder") : m.count > 1 ? t("remember_photos", { n: m.count }) : m.scope === "photos" ? t("remember_photo1") : t("chat_remembered");
      const txt = document.createElement("span");
      txt.textContent = (m.forgotten ? "🗑 " + t("remember_removed") + ": " : "📌 " + where + ": ") + m.remember;
      r.appendChild(txt);
      if (!m.forgotten && !m.hello) {
        const x = document.createElement("button");
        x.className = "rm-x"; x.textContent = "×"; x.title = t("remember_forget");
        x.addEventListener("click", () => forgetFact(idx, m.remember));
        r.appendChild(x);
      }
      div.appendChild(r);
    }
    log.appendChild(div);
  });
  if (S.chatBusy) {
    const div = document.createElement("div");
    div.className = "msg ai thinking";
    div.textContent = t("chat_thinking");
    log.appendChild(div);
  }
  log.scrollTop = log.scrollHeight;
}
async function forgetFact(idx, text) {
  if (!await uiConfirm(t("remember_forget_q", { f: text }))) return;
  try {
    const d = await api("chat_forget", { folder: S.path, index: idx });
    S.chat = d.chat; S.notes.own = d.own;
    renderNotes(); renderChat();
    await loadPhotoNotes();
    toast(t("remember_forgot_done"), "ok");
  } catch (e) { toast(e.message, "err"); }
}
async function sendChat() {
  const input = $("#chatInput");
  const text = input.value.trim();
  if (!text || S.chatBusy || !S.path) return;
  const paths = [...S.selected];
  S.chat.push({ role: "user", text });
  input.value = "";
  S.chatBusy = true;
  renderChat();
  try {
    const d = await api("chat", {
      folder: S.path, message: text, path: paths[0] || null, multi: paths.length, paths,
      form: S.form ? { title: S.form.title, description: S.form.description, keywords: S.form.keywords } : null,
      editorial: paths.length ? $("#edChk").checked : null, illustrative: ilOn(),
    });
    S.chat = d.chat;
    S.notes.own = d.own;
    renderNotes();
    showNotices(d);
    const r = d.result;
    if (r.remember && r.scope !== "folder") await loadPhotoNotes();
    if (r.job) {
      paths.forEach((p) => markWorking(p, true));
      toast(t("chat_batch", { n: paths.length }), "ok", 6000);
      pollJobs();
    }
    if (r.update && S.form) {
      const before = new Set(S.form.keywords.map(lower));
      applyData({ title: r.title, description: r.description, keywords: r.keywords }, true);
      renderChips(new Set(r.keywords.map(lower).filter((k) => !before.has(k))));
      if (r.warnings && r.warnings.length) showWarnings(r.warnings);
      $("#chatUpdated").classList.remove("hidden");
      $("#chatDot").classList.remove("hidden");
    }
  } catch (e) {
    S.chat.push({ role: "assistant", text: "⚠ " + e.message });
  } finally {
    S.chatBusy = false;
    renderChat();
  }
}
$("#chatSend").addEventListener("click", sendChat);
$("#chatInput").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendChat(); }
});
$("#chatClear").addEventListener("click", async () => {
  if (!S.path) return;
  await api("chat_clear", { folder: S.path });
  S.chat = []; renderChat();
});
let notesTimer = null;
$("#notesText").addEventListener("input", () => {
  clearTimeout(notesTimer);
  notesTimer = setTimeout(async () => {
    if (!S.path) return;
    const d = await api("notes_set", { folder: S.path, text: $("#notesText").value });
    S.notes = { own: d.own, inherited: d.inherited };
    $("#notesSaved").textContent = t("notes_saved");
    setTimeout(() => ($("#notesSaved").textContent = ""), 1500);
    const total = (d.own ? d.own.split("\n").filter(Boolean).length : 0) + d.inherited.length;
    $("#notesCount").textContent = total ? `(${total})` : "";
  }, 700);
});
function showPaneTab(name) {
  $$(".pane-tabs button").forEach((b) => b.classList.toggle("active", b.dataset.ptab === name));
  $("#paneEdit").classList.toggle("hidden", name !== "edit");
  $("#paneChat").classList.toggle("hidden", name !== "chat");
  localStorage.setItem("paneTab", name);
  if (name === "edit") { $("#chatDot").classList.add("hidden"); $("#chatUpdated").classList.add("hidden"); requestAnimationFrame(autosizeAll); }
  else { updateChatSel(); const log = $("#chatLog"); log.scrollTop = log.scrollHeight; $("#chatInput").focus(); }
}
$$(".pane-tabs button").forEach((b) => b.addEventListener("click", () => showPaneTab(b.dataset.ptab)));
$("#chatGoEdit").addEventListener("click", () => showPaneTab("edit"));
function updateChatSel() {
  const paths = [...S.selected];
  const img = $("#chatSelImg");
  if (!paths.length) {
    img.classList.add("hidden");
    $("#chatSelName").textContent = S.path ? basename(S.path) : "";
    $("#chatSelHint").textContent = t("chat_sel_none");
  } else {
    img.src = thumbUrl(paths[0], 300);
    img.classList.remove("hidden");
    $("#chatSelName").textContent = paths.length === 1 ? basename(paths[0]) : t("selected_n", { n: paths.length });
    $("#chatSelHint").textContent = paths.length === 1 ? t("chat_sel_one") : t("chat_sel_many", { n: paths.length });
  }
}

/* ============================================================ RF / ED šķirošana */
async function refreshUndoSort() {
  try {
    const { last } = await api("sort_last");
    const par = S.path.replace(/[\\/][^\\/]+$/, "");
    const show = last && (normP(last.root) === normP(S.path) || normP(last.root) === normP(par));
    $("#undoSortBtn").classList.toggle("hidden", !show);
    S.lastSort = last;
  } catch (_) {}
}
$("#sortBtn").addEventListener("click", () => {
  if (!S.path) return;
  let imgs = S.images.filter((im) => !im.rel.includes("/") && !im.rel.includes("\\"));
  const selOnly = S.selected.size > 0 && imgs.some((im) => S.selected.has(im.path));
  if (selOnly) imgs = imgs.filter((im) => S.selected.has(im.path));
  if (!imgs.length) { toast(t("sort_none")); return; }
  S.sortPaths = imgs.map((im) => im.path);
  $("#sortIntro").textContent = t("sort_intro", {
    n: imgs.length, folder: basename(S.path), rf: S.settings.sort_rf_name || "RF", ed: S.settings.sort_ed_name || "ED",
  }) + (selOnly ? " " + t("sort_sel_note", { n: imgs.length }) : "");
  $("#sortModal").classList.remove("hidden");
});
$("#sortCancel").addEventListener("click", () => $("#sortModal").classList.add("hidden"));
$("#sortStart").addEventListener("click", async () => {
  $("#sortModal").classList.add("hidden");
  try {
    await api("classify", { root: S.path, paths: S.sortPaths });
    S.sortPaths.forEach((p) => markWorking(p, true));
    toast(t("sort_started", { n: S.sortPaths.length }), "ok");
    pollJobs();
  } catch (e) { toast(e.message, "err"); }
});
function openReview(job) {
  S.review = { job, choice: {} };
  for (const it of job.items) S.review.choice[it.path] = it.result?.category || "UNSURE";
  const list = $("#reviewList");
  list.innerHTML = "";
  const allPaths = job.items.map((x) => x.path);
  job.items.forEach((it, idx) => {
    const row = document.createElement("div");
    row.className = "rv-row";
    row.dataset.path = it.path;
    const cat = S.review.choice[it.path];
    const reason = it.state === "error" ? "⚠ " + it.error : (it.result?.reason || "");
    const fl = it.result?.flags || [];
    const hint = (it.result?.hint ? `<div class="rv-hint">🔎 ${esc(it.result.hint)}</div>` : "")
      + (fl.length || it.result?.advice ? `<div class="rv-risk">⚠ ${esc(fl.map((f) => t("fl_" + f)).join(", "))}${it.result?.advice ? " — " + esc(it.result.advice) : ""}</div>` : "");
    row.innerHTML = `<img src="${thumbUrl(it.path, 300)}" alt=""><div class="rv-info"><div class="rv-name">${esc(basename(it.path))}</div><div class="muted small">${esc(reason)}</div>${hint}</div>
      <div class="seg">${["RF", "ED", "UNSURE"].map((c) => `<button data-c="${c}" class="${c === cat ? "on c-" + c : ""}">${esc(t("cat_" + c))}</button>`).join("")}</div>`;
    $$(".seg button", row).forEach((b) => b.addEventListener("click", () => setReviewCat(it.path, b.dataset.c)));
    $("img", row).addEventListener("click", () => openViewer(allPaths, idx, true));
    list.appendChild(row);
  });
  reviewSummary();
  $("#reviewModal").classList.remove("hidden");
}
function setReviewCat(path, c) {
  if (!S.review) return;
  S.review.choice[path] = c;
  const row = $$("#reviewList .rv-row").find((r) => r.dataset.path === path);
  if (row) $$(".seg button", row).forEach((x) => (x.className = x.dataset.c === c ? "on c-" + c : ""));
  reviewSummary();
}
function reviewSummary() {
  const v = Object.values(S.review.choice);
  $("#reviewSummary").textContent = t("review_sum", {
    rf: v.filter((x) => x === "RF").length, ed: v.filter((x) => x === "ED").length, un: v.filter((x) => x === "UNSURE").length,
  });
}
$("#reviewCancel").addEventListener("click", () => $("#reviewModal").classList.add("hidden"));
$("#reviewApply").addEventListener("click", async () => {
  const job = S.review.job;
  const moves = Object.entries(S.review.choice).map(([path, category]) => ({ path, category }));
  try {
    const mk = $("#rManifest") ? $("#rManifest").checked : false;
    const d = await api("sort_apply", { root: job.root, moves, generate_after: $("#rGen").checked, job_id: job.id, make_manifest: mk });
    S.settings.sort_manifest = mk;
    $("#reviewModal").classList.add("hidden");
    toast(t("sorted_done", { n: d.count }) + (d.regen ? " " + t("regen_started", { n: d.regen }) : "") + (d.errors.length ? " — " + d.errors[0] : ""), d.errors.length ? "err" : "ok", 6000);
    const n = treeNode(job.root);
    if (n) await toggleNode(n, true, true);
    if (normP(S.path) === normP(job.root)) navigate(S.path, false);
    if (d.job || d.regen_job) pollJobs();
  } catch (e) { toast(e.message, "err"); }
});
async function refreshEdSwap() {
  try {
    const sep = S.path.includes("\\") ? "\\" : "/";
    const { editorial } = await api("is_editorial", { path: S.path.replace(/[\\/]+$/, "") + sep + "x.jpg" });
    $("#edSwapBtn").classList.toggle("hidden", !editorial || !S.images.length);
  } catch (_) {}
}
function ilKey() { return "il:" + S.path; }
function refreshIl() {
  const ed = $("#edChk").checked;
  $("#ilWrap").classList.toggle("hidden", !ed);
  $("#ilChk").checked = ed && localStorage.getItem(ilKey()) === "1";
}
$("#edChk").addEventListener("change", () => { counters(); refreshIl(); });
$("#ilChk").addEventListener("change", (e) => localStorage.setItem(ilKey(), e.target.checked ? "1" : ""));
const ilOn = () => $("#edChk").checked && $("#ilChk").checked;
$("#edSwapBtn").addEventListener("click", async () => {
  const paths = S.selected.size ? [...S.selected] : S.images.map((i) => i.path);
  if (!await uiConfirm(t("ed_swap_q", { n: paths.length }))) return;
  if (!(await confirmLeave())) return;
  try {
    const d = await api("ed_swap", { paths });
    Object.assign(S.meta, d.meta);
    for (const [p, st] of Object.entries(d.status)) { S.status[p] = st; paintStatus(p, st); }
    toast(t("ed_swap_done", { n: d.count, k: d.skipped }), "ok", 6000);
    if (S.form) onSelectionChanged();
  } catch (e) { toast(e.message, "err", 8000); }
});
$("#recognizeBtn").addEventListener("click", async () => {
  if (!S.images.length) { toast(t("sort_none")); return; }
  // ja kaut kas atlasīts (arī viena bilde) — tikai atlasītās; citādi visa mape, izlaižot jau atpazītās
  const sel = S.selected.size > 0;
  const paths = sel ? [...S.selected] : S.images.map((i) => i.path);
  const isKnown = (p) => S.photoNotes[p]?.hint && (S.photoNotes[p]?.draft || S.status[p]?.status === "full");
  const known = paths.filter(isKnown).length;
  let skip = false;
  if (known) {
    const msg = sel ? t("recognize_sel_q", { n: paths.length }) : t("recognize_all_q", { n: paths.length }) + " " + t("recognize_q", { n: paths.length });
    const r = await uiConfirmCheck(msg, t("recognize_skip", { k: known, m: paths.length - known }), !sel || known < paths.length);
    if (r === null) return;
    skip = r;
  } else if (!await uiConfirm(sel ? t("recognize_sel_q", { n: paths.length }) : t("recognize_all_q", { n: paths.length }) + " " + t("recognize_q", { n: paths.length }))) return;
  try {
    const d = await api("recognize", { paths, root: S.path, skip_known: skip });
    if (!d.job) { toast(t("recognize_nothing")); return; }
    const todo = skip ? paths.filter((p) => !isKnown(p)) : paths;
    todo.forEach((p) => markWorking(p, true));
    toast(t("recognize_started", { n: d.count }), "ok");
    askNotifyPermission();
    pollJobs();
  } catch (e) { toast(e.message, "err"); }
});
$("#undoSortBtn").addEventListener("click", async () => {
  if (!S.lastSort || !await uiConfirm(t("undo_q", { n: S.lastSort.count }))) return;
  try {
    const d = await api("sort_undo");
    toast(t("undo_done", { n: d.count }), "ok");
    const n = treeNode(d.root);
    if (n) await toggleNode(n, true, true);
    navigate(S.path, false);
  } catch (e) { toast(e.message, "err"); }
});

/* ============================================================ darbu uzraudzība */
let pollTimer = null;
const seenDone = new Set();
let firstPoll = true;
async function pollJobs() {
  clearTimeout(pollTimer);
  let d;
  try { d = await api("jobs"); } catch (_) { pollTimer = setTimeout(pollJobs, 3000); return; }
  S.jobs = d.jobs;
  if (d.provider && d.provider !== S.provider) { S.provider = d.provider; paintAccBadge(); }
  if (firstPoll) {
    // darbi, kas beidzās pirms lapas ielādes (arī pirms restarta), vairs nav jāpaziņo
    firstPoll = false;
    for (const j of S.jobs) if (j.finished) { seenDone.add(j.id); j.items.forEach((it) => seenDone.add(j.id + it.path)); (j.notices || []).forEach((n) => seenDone.add(j.id + "#" + n)); }
    const intr = S.jobs.filter((j) => j.interrupted && !j.resumed && j.remaining);
    if (intr.length) S.badgeDone = "interrupted";
  }
  let active = false, total = 0, done = 0;
  for (const j of S.jobs) {
    if (!j.finished) active = true;
    for (const n of j.notices || []) if (!seenDone.has(j.id + "#" + n)) { seenDone.add(j.id + "#" + n); toast(n, "ok sticky"); notify(n); }
    if (!j.finished || !seenDone.has(j.id)) { total += j.total; done += j.done; }
    for (const it of j.items) {
      const key = j.id + it.path;
      if (["done", "error", "cancelled"].includes(it.state) && !seenDone.has(key)) {
        seenDone.add(key);
        markWorking(it.path, false);
        if (it.status) { S.status[it.path] = it.status; paintStatus(it.path, it.status); refreshFixCut(); }
        if (j.kind === "generate" && it.state === "done" && j.autosave && S.form && S.form.paths.includes(it.path) && !S.dirty) onSelectionChanged();
      }
    }
    if (j.finished && !seenDone.has(j.id)) {
      seenDone.add(j.id);
      if (["classify", "recognize", "draft"].includes(j.kind)) { loadPhotoNotes().then(() => { if (S.form && !S.dirty) onSelectionChanged(); }); loadStatuses(); }
      if (j.kind === "draft") {
        const m = t("draft_done", { n: j.done - j.failed }); toast(m, "ok sticky"); notify(m);
      } else if (j.kind === "classify") {
        if (!j.applied && (!j.cancelled || j.done)) { toast(t("job_class_done", { n: j.done }), "ok sticky"); notify(t("job_class_done", { n: j.done })); openReview(j); }
      } else if (j.kind === "fix") {
        const ch = j.items.filter((i) => i.result?.changed).length, ok = j.items.filter((i) => i.result && !i.result.changed).length;
        const m = t("fixcut_done", { n: ch }) + (ok ? " " + t("fixcut_ok", { n: ok }) : "") + (j.stop_reason ? " — " + j.stop_reason : "");
        toast(m, j.failed ? "err" : "ok sticky"); notify(m);
        if (S.form && !S.dirty) onSelectionChanged();
      } else if (j.kind === "recognize") {
        const m = t("recognize_done", { n: j.done - j.failed }) + (j.stop_reason ? " — " + j.stop_reason : "");
        toast(m, j.failed ? "err" : "ok sticky"); notify(m);
      } else {
        const ok = j.done - j.failed;
        const m = t("job_done", { ok }) + (j.failed ? t("job_errs", { n: j.failed }) : "") + (j.stop_reason ? " — " + j.stop_reason : "");
        toast(m, j.failed ? "err" : "ok sticky"); notify(m);
      }
      updateCount();
      applyFilter();
      if (j.kind === "generate") applyStatusSort();
    }
  }
  const badge = $("#jobBadge");
  const running = S.jobs.filter((j) => !j.finished);
  badge.classList.remove("done", "idle", "warn");
  $("#jobProv").textContent = "";
  if (active) {
    const kinds = [...new Set(running.map((j) => j.kind))];
    const label = kinds.length === 1 ? t("badge_" + kinds[0]) : "AI";
    $("#jobText").textContent = `${label} ${done} / ${total}`;
    $("#jobFill").style.width = (total ? (done / total) * 100 : 0) + "%";
    $("#jobProv").textContent = PROV_SHORT[S.provider] || "";
    S.badgeDone = null;
  } else if (S.jobs.some((j) => j.retry_at && !j.resumed)) {
    const j = S.jobs.find((x) => x.retry_at && !x.resumed);
    badge.classList.add("warn");
    $("#jobText").textContent = "⏳ " + t("retry_at", { t: new Date(j.retry_at * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) });
    $("#jobFill").style.width = "0%";
  } else if (S.badgeDone === "interrupted") {
    badge.classList.add("warn");
    const n = S.jobs[0]?.pending_total || 0;
    if (!n) S.badgeDone = "seen";
    $("#jobText").textContent = t("job_resume", { n });
    $("#jobFill").style.width = "0%";
  } else if (S.jobs.length && S.badgeDone !== "seen" && S.badgeDone !== undefined) {
    const last = [...S.jobs].sort((a, b) => (b.ended || 0) - (a.ended || 0))[0];
    badge.classList.add("done");
    $("#jobText").textContent = t("badge_done", { n: last.done });
    $("#jobFill").style.width = "100%";
  } else {
    badge.classList.add("idle");
    $("#jobText").textContent = t("jobs_idle");
    $("#jobFill").style.width = "0%";
  }
  if (!$("#jobsModal").classList.contains("hidden")) renderJobs();
  if (active) { askNotifyPermission(); pollTimer = setTimeout(pollJobs, 1500); }
  else if (S.jobs.some((j) => j.retry_at && !j.resumed)) pollTimer = setTimeout(pollJobs, 20000);
}
const PROV_SHORT = { claude_cli: "Claude", codex_cli: "ChatGPT", api: "Claude API", openai_api: "OpenAI API" };
$("#jobBadge").addEventListener("click", () => {
  if (S.jobs.some((j) => !j.finished) === false && S.badgeDone !== "interrupted") S.badgeDone = "seen";
  renderJobs(); $("#jobsModal").classList.remove("hidden");
});
$("#jobsClose").addEventListener("click", () => { if (S.badgeDone === "interrupted") S.badgeDone = "seen"; $("#jobsModal").classList.add("hidden"); pollJobs(); });
$("#jobsClear").addEventListener("click", async () => {
  try { const d = await api("jobs_clear"); S.jobs = d.jobs; S.badgeDone = "seen"; renderJobs(); pollJobs(); } catch (e) { toast(e.message, "err"); }
});
function renderJobs() {
  const body = $("#jobsBody");
  if (!S.jobs.length) { body.innerHTML = `<p class="muted">${esc(t("job_none"))}</p>`; return; }
  body.innerHTML = "";
  for (const j of [...S.jobs].reverse()) {
    const div = document.createElement("div");
    div.className = "job";
    const pct = j.total ? (j.done / j.total) * 100 : 0;
    const state = j.finished ? (j.interrupted ? t("job_interrupted") : j.cancelled ? t("job_stopped") : t("job_finished")) : t("job_running");
    const itemTxt = (i) => {
      if (i.state === "running") return t("job_working");
      if (i.state === "cancelled") return t("job_cancelled");
      if (i.state === "interrupted") return t("job_interrupted");
      if (j.kind === "fix") return i.result?.changed ? (i.result.description || i.result.title || "") : t("job_ready");
      if (i.state === "error") return i.error;
      if (j.kind === "classify") return (i.result?.category || "") + " — " + (i.result?.reason || "") + (i.result?.draft?.title ? " · ✎ " + i.result.draft.title : "");
      if (j.kind === "recognize") return (i.result?.hint ? "🔎 " + i.result.hint + " · " : "") + (i.result?.draft?.title ? "✎ " + i.result.draft.title : t("job_ready"));
      if (j.kind === "draft") return "✎ " + (i.result?.draft?.title || "");
      return i.result?.title || t("job_ready");
    };
    div.innerHTML = `<div class="job-head"><b>${esc(t("job_kind_" + j.kind))}: ${esc(state)}, ${esc(t("job_of", { done: j.done, total: j.total }))}${j.failed ? esc(t("job_errs", { n: j.failed })) : ""}</b>
      <span>${j.finished ? (j.kind === "classify" && !j.applied && !j.interrupted ? `<button data-review="1">${esc(t("review_open"))}</button>` : "")
        + (j.remaining && !j.resumed ? ` <button data-resume="1" class="magic">${esc(t("job_resume", { n: j.remaining }))}</button>` : "")
        : `<button data-cancel="1">${esc(t("job_stop"))}</button>`}</span></div>
      <div class="muted small">${esc(new Date((j.created || 0) * 1000).toLocaleString())}${j.root ? " · " + esc(basename(j.root)) : ""}</div>
      <div class="bar"><i style="width:${pct}%"></i></div>
      ${(j.notices || []).map((n) => `<p class="small" style="color:var(--accent2, #b07a1a)">⇄ ${esc(n)}</p>`).join("")}
      ${j.stop_reason ? `<p class="small" style="color:var(--bad)">${esc(j.stop_reason)}</p>` : ""}
      ${j.retry_at && !j.resumed ? `<p class="small retry-line">⏳ ${esc(t("retry_at", { t: new Date(j.retry_at * 1000).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) }))}</p>` : ""}
      ${j.auto_resumed ? `<p class="small muted">↻ ${esc(t("auto_resumed"))}</p>` : ""}
      <ul>${j.items.filter((i) => i.state !== "queued").slice(-60).map((i) => `<li class="${i.state === "error" ? "err" : ""}">${esc(basename(i.path))} — ${esc(itemTxt(i))}</li>`).join("")}</ul>`;
    const cb = $("[data-cancel]", div);
    if (cb) cb.addEventListener("click", async () => { await api("cancel", { id: j.id }); toast(t("job_stopping")); });
    const sb = $("[data-resume]", div);
    if (sb) sb.addEventListener("click", async () => {
      try {
        await api("job_resume", { id: j.id });
        toast(t("job_resumed", { n: j.remaining }), "ok");
        j.items.filter((i) => ["interrupted", "cancelled", "error"].includes(i.state)).forEach((i) => markWorking(i.path, true));
        S.badgeDone = null;
        pollJobs();
      } catch (e) { toast(e.message, "err"); }
    });
    const rb = $("[data-review]", div);
    if (rb) rb.addEventListener("click", () => { $("#jobsModal").classList.add("hidden"); openReview(j); });
    body.appendChild(div);
  }
}

/* --- vēsture --- */
function renderHistory() {
  const s = $("#historyStrip");
  s.innerHTML = "";
  for (const h of S.history) {
    const img = document.createElement("img");
    img.src = thumbUrl(h.path, 300);
    img.title = `${basename(h.path)}\n${h.title || ""}\n${t("st_kw", { n: (h.keywords || []).length })}`;
    img.addEventListener("click", () => {
      if (!S.form) { toast(t("hist_pick")); return; }
      applyData(h);
      toast(t("hist_applied"));
    });
    img.onerror = () => img.remove();
    s.appendChild(img);
  }
  if (!S.history.length) s.innerHTML = `<span class="muted small">${esc(t("history_empty"))}</span>`;
}

/* --- lielais skats (lightbox) ar pārslēgšanu --- */
const V = { list: [], idx: 0, review: false };
function openViewer(list, idx, review = false) {
  if (!list.length) return;
  V.list = list; V.idx = Math.max(0, Math.min(idx, list.length - 1)); V.review = review;
  $("#lightbox").classList.remove("hidden");
  showViewer();
}
function openLightbox(p) {
  const vis = visibleIdx().map((i) => S.images[i].path);
  const i = vis.indexOf(p);
  openViewer(i >= 0 ? vis : [p], Math.max(0, i));
}
function closeViewer() { $("#lightbox").classList.add("hidden"); }
function showViewer() {
  const p = V.list[V.idx];
  $("#lbImg").src = previewUrl(p);
  $("#lbName").textContent = basename(p);
  $("#lbPos").textContent = V.list.length > 1 ? `${V.idx + 1} / ${V.list.length}` : "";
  const ph = S.photoNotes[p];
  $("#lbHint").textContent = ph && ph.hint ? "🔎 " + ph.hint : "";
  $("#lbPrev").classList.toggle("hidden", V.idx === 0);
  $("#lbNext").classList.toggle("hidden", V.idx >= V.list.length - 1);
  const seg = $("#lbSeg");
  if (V.review && S.review) {
    const it = S.review.job.items.find((x) => x.path === p);
    $("#lbReason").textContent = it ? (it.state === "error" ? "⚠ " + it.error : it.result?.reason || "") : "";
    if (it?.result?.hint && !(ph && ph.hint)) $("#lbHint").textContent = "🔎 " + it.result.hint;
    if (it?.result?.flags?.length || it?.result?.advice) $("#lbReason").textContent += "  ⚠ " + (it.result.flags || []).map((f) => t("fl_" + f)).join(", ") + (it.result.advice ? " — " + it.result.advice : "");
    const cat = S.review.choice[p];
    seg.innerHTML = ["RF", "ED", "UNSURE"].map((c) => `<button data-c="${c}" class="${c === cat ? "on c-" + c : ""}">${esc(t("cat_" + c))}</button>`).join("");
    $$("button", seg).forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); setReviewCat(p, b.dataset.c); showViewer(); }));
    seg.classList.remove("hidden");
    $("#lbKeys").textContent = t("lb_keys_review");
  } else {
    $("#lbReason").textContent = "";
    seg.classList.add("hidden");
    $("#lbKeys").textContent = V.list.length > 1 ? t("lb_keys") : "";
  }
  // nākamo ielādējam iepriekš
  if (V.list[V.idx + 1]) { const im = new Image(); im.src = previewUrl(V.list[V.idx + 1]); }
}
function viewerStep(d) {
  const n = V.idx + d;
  if (n < 0 || n >= V.list.length) return;
  V.idx = n; showViewer();
}
$("#lbPrev").addEventListener("click", (e) => { e.stopPropagation(); viewerStep(-1); });
$("#lbNext").addEventListener("click", (e) => { e.stopPropagation(); viewerStep(1); });
$("#lbClose").addEventListener("click", (e) => { e.stopPropagation(); closeViewer(); });
$("#lightbox").addEventListener("click", (e) => { if (e.target.id === "lightbox" || e.target.id === "lbImg") closeViewer(); });

/* ============================================================ rīkjosla */
$("#navBack").addEventListener("click", () => { const p = S.back.pop(); if (p) { S.fwd.push(S.path); navigate(p, false); } });
$("#navFwd").addEventListener("click", () => { const p = S.fwd.pop(); if (p) { S.back.push(S.path); navigate(p, false); } });
$("#navUp").addEventListener("click", () => { if (S.parent) navigate(S.parent); });
$("#navRefresh").addEventListener("click", () => navigate(S.path, false));
$("#pathInput").addEventListener("keydown", (e) => { if (e.key === "Enter") navigate(e.target.value.trim()); });
$("#sortSel").addEventListener("change", () => {
  localStorage.setItem("sort", $("#sortSel").value);
  if ($("#sortSel").value.startsWith("st_") && Object.keys(S.status).length) applyStatusSort();
  else navigate(S.path, false);
});
$("#depthSel").addEventListener("change", () => navigate(S.path, false));
$("#filterSel").addEventListener("change", applyFilter);
$("#selAll").addEventListener("click", () => setSelection(new Set(visibleIdx().map((i) => S.images[i].path))));
$("#selUndone").addEventListener("click", () => {
  const sel = S.images.filter((im) => S.status[im.path]?.status === "none").map((im) => im.path);
  if (!sel.length) { toast(t("undone_all")); return; }
  setSelection(new Set(sel));
  toast(t("undone_sel", { n: sel.length }));
});
$("#sizeRange").addEventListener("input", (e) => {
  document.documentElement.style.setProperty("--tile", e.target.value + "px");
  localStorage.setItem("tile", e.target.value);
});

/* --- klaviatūra --- */
document.addEventListener("keydown", (e) => {
  if (!$("#lightbox").classList.contains("hidden")) {
    const k = e.key.toLowerCase();
    if (e.key === "ArrowRight") { e.preventDefault(); viewerStep(1); }
    else if (e.key === "ArrowLeft") { e.preventDefault(); viewerStep(-1); }
    else if (e.key === "Escape") closeViewer();
    else if (V.review && ["r", "e", "n"].includes(k)) {
      setReviewCat(V.list[V.idx], { r: "RF", e: "ED", n: "UNSURE" }[k]);
      showViewer();
    }
    return;
  }
  const mod = e.ctrlKey || e.metaKey;
  const inField = /INPUT|TEXTAREA|SELECT/.test(document.activeElement?.tagName);
  if (e.key === "Escape") {
    $$(".modal, .lightbox").forEach((m) => m.classList.add("hidden"));
    $("#tplMenu").classList.add("hidden");
  }
  if ($("#page-images").classList.contains("hidden")) {
    if (mod && e.key.toLowerCase() === "s" && !$("#page-templates").classList.contains("hidden")) { e.preventDefault(); saveTpl(); }
    return;
  }
  if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); save_(); return; }
  if (mod && e.key.toLowerCase() === "g") { e.preventDefault(); generate(); return; }
  if (e.key === "F5") { e.preventDefault(); navigate(S.path, false); return; }
  if (inField) return;
  if (mod && e.key.toLowerCase() === "a") { e.preventDefault(); $("#selAll").click(); return; }
  if (["ArrowRight", "ArrowLeft", "ArrowDown", "ArrowUp"].includes(e.key)) {
    e.preventDefault();
    const vis = visibleIdx();
    if (!vis.length) return;
    let pos = S.anchor == null ? -1 : vis.indexOf(S.anchor);
    const perRow = Math.max(1, Math.floor($("#grid").clientWidth / (($$(".tile.img")[0]?.offsetWidth || 150) + 10)));
    const step = { ArrowRight: 1, ArrowLeft: -1, ArrowDown: perRow, ArrowUp: -perRow }[e.key];
    pos = Math.min(vis.length - 1, Math.max(0, pos + step));
    const idx = vis[pos];
    S.anchor = idx;
    setSelection(new Set([S.images[idx].path]));
    tileByPath(S.images[idx].path)?.scrollIntoView({ block: "nearest" });
  }
  if (e.key === "Backspace" && S.parent) navigate(S.parent);
});

/* ============================================================ Šabloni */
let curTpl = null;
function renderTplList() {
  const q = lower($("#tplSearch").value || "");
  const list = $("#tplList");
  list.innerHTML = "";
  for (const tp of S.templates.filter((x) => !q || lower(x.name).includes(q) || x.keywords.some((k) => lower(k).includes(q)))) {
    const d = document.createElement("div");
    d.className = "tpl-item" + (curTpl && curTpl.id === tp.id ? " active" : "");
    d.innerHTML = `<span>${esc(tp.name)}</span><span class="muted">${tp.keywords.length}</span>`;
    d.addEventListener("click", () => openTpl(tp));
    list.appendChild(d);
  }
  if (!S.templates.length) list.innerHTML = `<div class="tpl-item muted">${esc(t("tpl_none"))}</div>`;
}
$("#tplSearch").addEventListener("input", renderTplList);
function openTpl(tp) {
  curTpl = { id: tp.id, name: tp.name, keywords: [...tp.keywords] };
  $("#tplEmpty").classList.add("hidden");
  $("#tplEditor").classList.remove("hidden");
  $("#tplName").value = curTpl.name;
  $("#tplDelete").classList.toggle("hidden", !tp.id);
  renderTplChips();
  renderTplList();
}
function renderTplChips() {
  const box = $("#tplChips");
  box.innerHTML = "";
  curTpl.keywords.forEach((k, i) => {
    const c = document.createElement("span");
    c.className = "chip";
    c.innerHTML = `<span>${esc(k)}</span><button class="x" tabindex="-1">×</button>`;
    $(".x", c).addEventListener("click", () => { curTpl.keywords.splice(i, 1); renderTplChips(); });
    box.appendChild(c);
  });
  $("#tplText").value = curTpl.keywords.join(", ");
  $("#tplCount").textContent = `(${curTpl.keywords.length})`;
}
$("#tplAdd").addEventListener("keydown", (e) => {
  if (e.key === "Enter" || e.key === ",") {
    e.preventDefault();
    curTpl.keywords = uniqKw([...curTpl.keywords, ...splitKw(e.target.value)]);
    e.target.value = "";
    renderTplChips();
  }
});
$("#tplAdd").addEventListener("paste", (e) => {
  const txt = e.clipboardData.getData("text");
  if (/[,;\n]/.test(txt)) { e.preventDefault(); curTpl.keywords = uniqKw([...curTpl.keywords, ...splitKw(txt)]); renderTplChips(); }
});
$("#tplText").addEventListener("change", (e) => { curTpl.keywords = uniqKw(splitKw(e.target.value)); renderTplChips(); });
$("#tplNew").addEventListener("click", () => { openTpl({ id: null, name: t("tpl_new_name"), keywords: [] }); $("#tplName").select(); });
async function saveTpl() {
  if (!curTpl) return;
  const pending = $("#tplAdd").value;
  if (pending.trim()) { curTpl.keywords = uniqKw([...curTpl.keywords, ...splitKw(pending)]); $("#tplAdd").value = ""; }
  curTpl.name = $("#tplName").value.trim() || t("tpl_noname");
  const d = await api("template_save", curTpl);
  S.templates = d.templates;
  curTpl.id = d.template.id;
  $("#tplDelete").classList.remove("hidden");
  renderTplList(); renderTplChips();
  toast(t("tpl_saved"), "ok", 1600);
}
$("#tplSave").addEventListener("click", saveTpl);
$("#tplDelete").addEventListener("click", async () => {
  if (!curTpl?.id || !await uiConfirm(t("tpl_delete_q", { name: curTpl.name }))) return;
  const d = await api("template_delete", { id: curTpl.id });
  S.templates = d.templates;
  curTpl = null;
  $("#tplEditor").classList.add("hidden");
  $("#tplEmpty").classList.remove("hidden");
  renderTplList();
});
$("#tplImport").addEventListener("click", () => $("#tplFile").click());
$("#tplFile").addEventListener("change", async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const text = await f.text();
  try {
    const d = await api("template_import", { text });
    S.templates = d.templates; renderTplList();
    toast(t("tpl_imported", { n: d.count }), "ok");
  } catch (err) { toast(err.message, "err"); }
  e.target.value = "";
});
$("#tplExport").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify(S.templates.map(({ name, keywords }) => ({ name, keywords })), null, 2)], { type: "application/json" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "vardotajs-templates.json";
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
});

/* ============================================================ tulkojums, turot peli virs teksta */
const TR = { cache: new Map(), timer: null, el: null, seq: 0 };
function trHide() { clearTimeout(TR.timer); TR.el = null; TR.seq++; $("#trTip").classList.add("hidden"); }
function trPlace(el) {
  const tip = $("#trTip"), r = el.getBoundingClientRect();
  const w = Math.min(Math.max(r.width, 260), window.innerWidth - 24);
  tip.style.width = w + "px";
  let left = Math.min(Math.max(12, r.left), window.innerWidth - w - 12);
  tip.style.left = left + "px";
  const below = r.bottom + 6, h = tip.offsetHeight || 60;
  tip.style.top = (below + h > window.innerHeight - 8 ? Math.max(8, r.top - h - 6) : below) + "px";
}
async function trShow(el) {
  const text = el.value.replace(/\s+/g, " ").trim();
  if (!text || !S.settings.show_translation) return;
  const tip = $("#trTip");
  const seq = ++TR.seq;
  const paint = (body, wait) => {
    tip.innerHTML = `<div class="tr-head"><span class="tr-lv">LV</span> ${esc(t("tr_title"))}</div><div class="tr-body${wait ? " wait" : ""}">${esc(body)}</div>`;
    tip.classList.remove("hidden");
    trPlace(el);
  };
  if (TR.cache.has(text)) { paint(TR.cache.get(text)); return; }
  paint(t("tr_wait"), true);
  try {
    const d = await api("translate", { texts: [text] });
    const tr = d.translations[0] || "";
    if (tr) TR.cache.set(text, tr);
    if (seq === TR.seq && TR.el === el) paint(tr || "—");
  } catch (e) { if (seq === TR.seq) paint(e.message); }
}
for (const id of ["#fTitle", "#fDesc"]) {
  const el = $(id);
  el.addEventListener("mouseenter", () => {
    clearTimeout(TR.timer); TR.el = el;
    TR.timer = setTimeout(() => { if (TR.el === el && document.activeElement !== el) trShow(el); }, 900);
  });
  el.addEventListener("mouseleave", trHide);
  el.addEventListener("input", trHide);
  el.addEventListener("focus", trHide);
}
window.addEventListener("scroll", trHide, true);

/* ============================================================ sākuma banneris */
const SPL = { parts: [], raf: 0, closing: false, t0: 0, last: 0, p: 0, steps: [] };
function splashStart(version) {
  const wrap = $("#splash"), card = $("#splashCard"), cv = $("#splashFx"), cx = cv.getContext("2d");
  $("#splashVer").textContent = "v" + version;
  card.title = t("splash_skip");
  const DUR = 6500;
  const labels = ["splash_s1", "splash_s2", "splash_s3", "splash_s4", "splash_s5", "splash_s6"].map((k) => t(k));
  const at = [0, 0.12, 0.34, 0.56, 0.76, 0.93];
  const SRC = [{ x: 0.545, y: 0.73, w: 3 }, { x: 0.455, y: 0.47, w: 1 }];
  let W = 0, H = 0;
  const size = () => { const r = card.getBoundingClientRect(), d = window.devicePixelRatio || 1; W = r.width; H = r.height; cv.width = W * d; cv.height = H * d; cx.setTransform(d, 0, 0, d, 0, 0); };
  const pick = () => { let r = Math.random() * 4; for (const q of SRC) if ((r -= q.w) <= 0) return q; return SRC[0]; };
  const spawn = (tw) => {
    if (tw) return { k: 1, x: Math.random() * W, y: Math.random() * H * 0.75, life: 0, max: 900 + Math.random() * 900, s: 1 + Math.random() * 2.2 };
    const q = pick(), a = -Math.PI / 2 + (Math.random() - 0.5) * 2.2, v = 0.04 + Math.random() * 0.09;
    return { k: 0, x: q.x * W + (Math.random() - 0.5) * 20, y: q.y * H + (Math.random() - 0.5) * 8, vx: Math.cos(a) * v + 0.02, vy: Math.sin(a) * v,
      life: 0, max: 1400 + Math.random() * 1800, s: 0.8 + Math.random() * 2.4, star: Math.random() < 0.35, rot: Math.random() * 6, wob: Math.random() * 6 };
  };
  const star = (x, y, r, rot) => { cx.beginPath(); for (let i = 0; i < 8; i++) { const rr = i % 2 ? r * 0.38 : r, a = rot + (i * Math.PI) / 4; cx.lineTo(x + Math.cos(a) * rr, y + Math.sin(a) * rr); } cx.closePath(); cx.fill(); };
  const frame = (now) => {
    const dt = Math.min(50, now - (SPL.last || now)); SPL.last = now;
    const p = Math.min(1, (now - SPL.t0) / DUR);
    const rate = SPL.closing ? 0 : (p < 0.15 ? 1.6 : 0.9) + (p > 0.85 ? 1.2 : 0);
    for (let i = 0; i < (rate * dt) / 16; i++) SPL.parts.push(spawn(false));
    if (Math.random() < (0.12 * dt) / 16) SPL.parts.push(spawn(true));
    cx.clearRect(0, 0, W, H); cx.globalCompositeOperation = "lighter";
    SPL.parts = SPL.parts.filter((q) => (q.life += dt) < q.max);
    for (const q of SPL.parts) {
      const f = q.life / q.max, al = Math.sin(Math.PI * f);
      if (q.k) { cx.fillStyle = `rgba(255,240,200,${al * 0.9})`; star(q.x, q.y, q.s * 2.2 * al + 0.3, 0); continue; }
      q.vy -= 0.00003 * dt; q.x += (q.vx + Math.sin(q.wob + q.life / 300) * 0.02) * dt; q.y += q.vy * dt; q.rot += 0.002 * dt;
      const r = q.s * (1 - f * 0.5), g = cx.createRadialGradient(q.x, q.y, 0, q.x, q.y, r * 5);
      g.addColorStop(0, `rgba(255,226,150,${al * 0.55})`); g.addColorStop(1, "rgba(255,180,80,0)");
      cx.fillStyle = g; cx.beginPath(); cx.arc(q.x, q.y, r * 5, 0, 7); cx.fill();
      cx.fillStyle = `rgba(255,250,230,${al})`;
      if (q.star) star(q.x, q.y, r * 2, q.rot); else { cx.beginPath(); cx.arc(q.x, q.y, r * 0.7, 0, 7); cx.fill(); }
    }
    cx.globalCompositeOperation = "source-over";
    if (!SPL.closing) {
      // josla nekad neapsteidz īsto ielādi: pēdējie soļi gaida, kamēr init ir gatavs
      const cap = SPL.ready ? 1 : 0.9;
      const pp = Math.min(p, cap);
      $("#splashBar").style.width = (pp * 100).toFixed(1) + "%";
      let txt = labels[0]; at.forEach((a, i) => { if (pp >= a) txt = labels[i]; });
      if ($("#splashStep").textContent !== txt) $("#splashStep").textContent = txt;
      if (p >= 1 && SPL.ready) splashClose();
    }
    SPL.raf = requestAnimationFrame(frame);
  };
  wrap.classList.remove("pending", "hidden");
  const img = $("#splashImg");
  const go = () => requestAnimationFrame(() => { size(); wrap.classList.add("show"); SPL.t0 = performance.now(); SPL.raf = requestAnimationFrame(frame); });
  img.onload = go; img.onerror = () => splashClose(true);
  img.src = "/static/splash.jpg";
  card.addEventListener("click", () => splashClose());
  window.addEventListener("resize", size);
  // drošībai — ja kaut kas aizķeras, banneris pazūd vēlākais pēc 15 s
  setTimeout(() => splashClose(), 15000);
}
function splashClose(now = false) {
  const wrap = $("#splash");
  if (SPL.closing || wrap.classList.contains("hidden")) return;
  SPL.closing = true;
  $("#splashBar").style.width = "100%";
  wrap.classList.add("hide");
  setTimeout(() => { cancelAnimationFrame(SPL.raf); wrap.classList.add("hidden"); wrap.classList.remove("show", "hide", "pending"); }, now ? 0 : 750);
}
function splashSkip() { const w = $("#splash"); w.classList.add("hidden"); w.classList.remove("pending"); }

/* ============================================================ Iestatījumi */
async function loadSettingsPage() {
  const d = await api("state");
  S.settings = d.settings;
  const s = d.settings;
  $("#sLang").value = window.LANG;
  $("#sClaudePath").value = s.claude_path || "";
  $("#sCodexPath").value = s.codex_path || "";
  $("#sCodexModel").value = s.codex_model || "";
  $("#sOpenaiModel").value = s.openai_model || "";
  $("#sTranslate").checked = !!s.show_translation;
  $("#sSplash").checked = s.show_splash !== false;
  updLoadSettings(s);                                  // upd.js: atjauninājumi, rezerves kopijas (0.9.0)
  $("#sEco").checked = !!s.eco_images;
  $("#sBatchN").value = String(s.batch_photos || 4);
  $("#sAutoRetry").checked = s.auto_retry !== false;
  $("#sAutoMove").checked = !!s.auto_move_cat;
  $("#sModel").value = ["sonnet", "opus", "haiku"].includes(s.model) ? s.model : "sonnet";
  $("#sParallel").value = String(s.parallel);
  $("#sAuthor").value = s.author || "";
  $("#sKwCount").value = s.keywords_count;
  $("#sTitleMax").value = s.title_max;
  $("#sDescMax").value = s.description_max;
  $("#sEdDescMax").value = s.ed_description_max || 200;
  $("#sMinKw").value = s.complete_min_keywords;
  $("#sEdWord").value = s.editorial_word;
  $("#sSingle").checked = !!s.single_word_keywords;
  $("#sEdFormat").checked = !!s.editorial_format;
  $("#sGps").checked = !!s.send_gps;
  $("#sStyle").value = s.style;
  $("#sRfName").value = s.sort_rf_name;
  $("#sEdName").value = s.sort_ed_name;
  $("#sCriteria").value = s.rfed_criteria;
  $$(".sAg").forEach((c) => (c.checked = (s.target_agencies || []).includes(c.value)));
  $("#sMyRules").value = s.my_rules || "";
  etStatus(d);
  $("#appInfo").innerHTML = esc(t("app_info", { v: d.version })) + `<code>${esc(d.app_dir)}</code>`;
}
$("#sLang").addEventListener("change", (e) => setLang(e.target.value));
function etStatus(d) {
  const el = $("#etStatus");
  if (d.installing) { el.className = "status-line"; el.textContent = d.install_msg || "…"; return; }
  if (d.exiftool) { el.className = "status-line good"; el.innerHTML = `<b>ExifTool</b> <span class="muted">${esc(d.exiftool)}${d.install_msg ? " · " + esc(d.install_msg) : ""}</span>`; }
  else { el.className = "status-line bad"; el.textContent = t("et_missing") + (d.install_msg ? " " + d.install_msg : ""); }
}
/* AI konta zīme statusa joslā: pieslēgums, ko Vārdotājs tagad lieto aprakstiem (Pieslēgumi → Kurš AI ko dara);
   ⇄ — pārslēgts uz nākamo pēc limita (0.9.0-test3) */
function paintAccBadge() {
  const b = $("#accBadge");
  b.classList.remove("in", "out", "gpt");
  const prov = S.provider || "claude_cli";
  const txt = $("#accBadgeText");
  const sw = S.primary && prov !== S.primary ? " ⇄" : "";
  if (prov === "api") { b.classList.add("in"); txt.textContent = t("acc_badge_api") + sw; return; }
  if (prov === "openai_api") { b.classList.add("in", "gpt"); txt.textContent = t("acc_badge_oapi") + sw; return; }
  if (prov === "codex_cli") {
    b.classList.add("gpt");
    const a = S.cx;
    if (!a) return;
    if (!a.found) { b.classList.add("out"); txt.textContent = t("acc_badge_cx_nocli"); }
    else if (a.loggedIn) { b.classList.add("in"); txt.textContent = "ChatGPT" + sw; }
    else { b.classList.add("out"); txt.textContent = t("acc_badge_cx_out"); }
    return;
  }
  const a = S.auth;
  if (!a) return;
  if (!a.found) { b.classList.add("out"); txt.textContent = t("acc_badge_nocli"); }
  else if (a.loggedIn) { b.classList.add("in"); txt.textContent = ([a.email, a.plan && a.plan.toUpperCase()].filter(Boolean).join(" — ") || t("acc_in")) + sw; }
  else { b.classList.add("out"); txt.textContent = t("acc_badge_out"); }
}
async function refreshAccBadge() {
  try {
    const d = await api("auth_status");
    S.auth = d.auth; S.provider = d.provider; S.primary = d.primary;
    if (S.provider === "codex_cli") S.cx = (await api("codex_status")).auth;
  } catch (_) {}
  paintAccBadge();
}
$("#accBadge").addEventListener("click", () => showPage("settings"));
function collectSettings() {
  return {
    lang: window.LANG,
    claude_path: $("#sClaudePath").value.trim(),
    codex_path: $("#sCodexPath").value.trim(),
    codex_model: $("#sCodexModel").value.trim(),
    openai_model: $("#sOpenaiModel").value.trim() || "gpt-5-mini",
    show_translation: $("#sTranslate").checked,
    show_splash: $("#sSplash").checked,
    eco_images: $("#sEco").checked,
    batch_photos: $("#sBatchN").value,
    auto_retry: $("#sAutoRetry").checked,
    auto_move_cat: $("#sAutoMove").checked,
    model: $("#sModel").value,
    parallel: $("#sParallel").value,
    author: $("#sAuthor").value.trim(),
    keywords_count: $("#sKwCount").value,
    title_max: $("#sTitleMax").value,
    description_max: $("#sDescMax").value,
    ed_description_max: $("#sEdDescMax").value,
    complete_min_keywords: $("#sMinKw").value,
    editorial_word: $("#sEdWord").value.trim(),
    single_word_keywords: $("#sSingle").checked,
    editorial_format: $("#sEdFormat").checked,
    send_gps: $("#sGps").checked,
    style: $("#sStyle").value,
    sort_rf_name: $("#sRfName").value.trim() || "RF",
    sort_ed_name: $("#sEdName").value.trim() || "ED",
    rfed_criteria: $("#sCriteria").value,
    target_agencies: $$(".sAg").filter((c) => c.checked).map((c) => c.value),
    my_rules: $("#sMyRules").value,
    ...updCollect(),                                   // upd.js (0.9.0)
  };
}
async function saveSettings(quiet = false) {
  const d = await api("settings", { settings: collectSettings() });
  S.settings = d.settings;
  if (!quiet) { $("#settingsMsg").textContent = t("saved"); setTimeout(() => ($("#settingsMsg").textContent = ""), 2000); }
  counters();
}
$("#settingsSave").addEventListener("click", () => saveSettings().then(() => { refreshAccBadge(); if (typeof rolesLoad === "function") rolesLoad(); }).catch((e) => toast(e.message, "err")));
$("#aiTest").addEventListener("click", async () => {
  await saveSettings(true);
  const m = $("#aiTestMsg");
  m.style.color = ""; m.textContent = t("ai_testing");
  try { const d = await api("ai_test"); m.textContent = d.message; m.style.color = "var(--ok)"; }
  catch (e) { m.textContent = e.message; m.style.color = "var(--bad)"; }
});
async function resetField(key, el) {
  if (!await uiConfirm(t("reset_q"))) return;
  const d = await api("settings", { settings: { [key]: "" } });
  S.settings = d.settings;
  $(el).value = d.settings[key] || "";
}
$("#styleReset").addEventListener("click", () => resetField("style", "#sStyle"));
$("#criteriaReset").addEventListener("click", () => resetField("rfed_criteria", "#sCriteria"));
$("#etInstall").addEventListener("click", async () => {
  await api("exiftool_install");
  const tick = async () => {
    const d = await api("state");
    etStatus(d);
    if (d.installing) setTimeout(tick, 1000);
    else if (d.exiftool) { toast(t("et_ready"), "ok"); if (S.path) loadStatuses(); }
  };
  tick();
});
$("#changelogBtn").addEventListener("click", () => {
  const L = window.CHANGELOG || [];
  $("#changelogBody").innerHTML = L.map((v) => `<div class="cl-ver"><h4>${esc(v.v)} <span class="muted small">${esc(v.d || "")}</span></h4><ul>${
    (v[window.LANG] || v.lv || []).map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div>`).join("");
  $("#changelogModal").classList.remove("hidden");
});
$("#changelogClose").addEventListener("click", () => $("#changelogModal").classList.add("hidden"));
$("#clearCache").addEventListener("click", async () => { const d = await api("clear_cache"); toast(t("cache_cleared", { n: d.count })); });

/* ============================================================ starts */
$("#quitBtn").addEventListener("click", async () => {
  if (S.dirty && !await uiConfirm(t("quit_q_dirty"))) return;
  if (S.jobs.some((j) => !j.finished) && !await uiConfirm(t("quit_q_job"))) return;
  try { await api("quit"); } catch (_) {}
  document.body.innerHTML = `<div style="padding:60px;text-align:center;font-size:16px">${esc(t("closed"))}</div>`;
  window.close();
});
window.addEventListener("beforeunload", (e) => { if (S.dirty) { e.preventDefault(); e.returnValue = ""; } });
setInterval(() => api("ping").catch(() => {}), 30000);
function checkVersion(serverVer) {
  const pv = window.PAGE_VERSION;
  if (pv && serverVer && pv !== serverVer) {
    const b = $("#verBanner");
    b.textContent = t("ver_mismatch", { page: pv, server: serverVer });
    b.classList.remove("hidden");
  }
}

(async function init() {
  const tile = localStorage.getItem("tile") || "150";
  $("#sizeRange").value = tile;
  document.documentElement.style.setProperty("--tile", tile + "px");
  $("#sortSel").value = localStorage.getItem("sort") || "name";
  let st;
  try { st = await api("state"); } catch (e) { splashSkip(); applyI18n(); toast(t("connect_fail") + e.message, "err", 20000); return; }
  S.settings = st.settings;
  S.provider = st.provider;
  $("#appVer").textContent = st.version;
  checkVersion(st.version);
  window.LANG = st.settings.lang === "en" ? "en" : "lv";
  applyI18n();
  // banneris — vienreiz katrā programmas palaišanā (ne pie lapas atsvaidzināšanas)
  let seenBoot = "";
  try { seenBoot = sessionStorage.getItem("splashBoot") || ""; sessionStorage.setItem("splashBoot", st.boot); } catch (_) {}
  if (st.settings.show_splash !== false && seenBoot !== st.boot) splashStart(st.version); else splashSkip();
  $("#langQuick").value = window.LANG;
  refreshGenLabel();
  if (localStorage.getItem("asText")) { $("#asText").checked = true; $("#asText").dispatchEvent(new Event("change")); }
  showPaneTab(localStorage.getItem("paneTab") === "chat" ? "chat" : "edit");
  const [tp, hi] = await Promise.all([api("templates"), api("history")]);
  S.templates = tp.templates;
  S.history = hi.history;
  renderHistory();
  renderChat();
  await initTree();
  if (!st.exiftool) { toast(t("et_open_settings"), "err", 6000); showPage("settings"); }
  if (st.settings.last_folder) navigate(st.settings.last_folder, false);
  pollJobs();
  await refreshAccBadge();
  SPL.ready = true;
  setInterval(refreshAccBadge, 5 * 60 * 1000);
  // 0.9.0: automātiskā atjaunināšana un "Kas jauns" (core/updater.py) — pēc bannera
  setTimeout(() => { whatsNew(); updCheck(); }, 7500);
  setInterval(() => updCheck(), 6 * 3600 * 1000);
})();
