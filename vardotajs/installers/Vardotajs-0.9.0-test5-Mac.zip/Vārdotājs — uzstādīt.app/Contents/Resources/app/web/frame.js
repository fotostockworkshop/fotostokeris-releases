"use strict";
/* Vārdotājs 0.9.0-test2 — kā Analītiķim (core): tēma (gaiša / tumša / kā sistēmā), valodu izvēlne ar karodziņiem,
   statusa josla apakšā (AI konts, ExifTool, AI darbs, mape). Lieto app.js palīgus ($, $$, api, t, esc, S, setLang). */

const FR = { theme: "auto", mq: window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null };

function applyTheme(th) {
  FR.theme = ["light", "dark", "auto", "forest"].includes(th) ? th : "auto";
  // "Meža zaļais" (0.9.0-test4) = tumšā tēma + sava krāsu palete (app.css [data-palette="forest"])
  const dark = FR.theme === "dark" || FR.theme === "forest" || (FR.theme === "auto" && FR.mq && FR.mq.matches);
  document.documentElement.dataset.theme = dark ? "dark" : "light";
  if (FR.theme === "forest") document.documentElement.dataset.palette = "forest"; else delete document.documentElement.dataset.palette;
  $$(".theme-sw button").forEach((b) => b.classList.toggle("on", b.dataset.th === FR.theme));
  try { localStorage.setItem("theme", FR.theme); } catch (_) {}
}
try { applyTheme(localStorage.getItem("theme") || "auto"); } catch (_) { applyTheme("auto"); }   // pirms ielādes — bez mirgošanas
if (FR.mq && FR.mq.addEventListener) FR.mq.addEventListener("change", () => FR.theme === "auto" && applyTheme("auto"));
$$(".theme-sw button").forEach((b) => b.addEventListener("click", () => {
  applyTheme(b.dataset.th);
  api("settings", { settings: { theme: FR.theme } }).then((d) => { S.settings = d.settings; }).catch(() => {});
}));

/* ---------- valodu izvēlne (karodziņi no /core/flags/) ---------- */
const FR_LANGS = [["lv", "Latviešu"], ["en", "English"]];      // DE, ES, UA — kad būs iztulkoti Vārdotāja teksti
function renderLangMenu() {
  const box = $("#langMenu");
  const code = (l) => (l === "uk" ? "UA" : l.toUpperCase());
  box.innerHTML = `<button type="button" class="lm-btn">${code(window.LANG)} <span class="lm-caret">▾</span></button>
    <div class="lm-list hidden">${FR_LANGS.map(([l, n]) => `<button type="button" data-l="${l}" class="${l === window.LANG ? "on" : ""}">
      <img src="/core/flags/${l}.svg" alt=""><b>${code(l)}</b><span>${esc(n)}</span></button>`).join("")}</div>`;
  const list = $(".lm-list", box);
  $(".lm-btn", box).addEventListener("click", (e) => { e.stopPropagation(); list.classList.toggle("hidden"); });
  $$(".lm-list button", box).forEach((b) => b.addEventListener("click", () => { list.classList.add("hidden"); setLang(b.dataset.l); }));
}
document.addEventListener("click", () => { const l = $("#langMenu .lm-list"); if (l) l.classList.add("hidden"); });

/* ---------- statusa josla ---------- */
function sbExif(st) {
  const el = $("#sbEt");
  el.className = "si " + (st.exiftool ? "ok" : "err");
  $("span", el).textContent = st.exiftool ? "ExifTool " + st.exiftool : t("sb_et_none");
  el.title = st.exiftool ? "" : t("et_open_settings");
}
function sbFolder() {
  const el = $("#sbFolder span");
  if (!el) return;
  const n = (S.images || []).length;
  if (!S.path || !n) { el.textContent = ""; return; }
  const st = Object.values(S.status || {});
  const full = st.filter((s) => s.status === "full").length;
  const dr = st.filter((s) => s.draft && s.status !== "full").length;
  el.textContent = t("sb_folder", { n, f: full }) + (dr ? " · ✎ " + dr : "");
}
$("#sbEt").addEventListener("click", () => showPage("settings"));

/* app.js funkcijas papildinām, nemainot tās */
const _updateCount = updateCount;
updateCount = function () { _updateCount(); sbFolder(); };            // eslint-disable-line no-func-assign
const _setLang = setLang;
setLang = function (l, persist = true) { _setLang(l, persist); renderLangMenu(); sbFolder(); api("state").then(sbExif).catch(() => {}); };   // eslint-disable-line no-func-assign

(async function frameInit() {
  for (let i = 0; i < 60 && !(S.settings && S.settings.lang); i++) await new Promise((r) => setTimeout(r, 150));   // gaida app.js init
  if (S.settings && S.settings.lang) applyTheme(S.settings.theme || "auto");
  renderLangMenu();
  applyI18n($("#statusBar"));
  try { sbExif(await api("state")); } catch (_) {}
  sbFolder();
  $("#etInstall").addEventListener("click", () => setTimeout(function w() { api("state").then((d) => { sbExif(d); if (d.installing) setTimeout(w, 1500); }); }, 1500));
})();
