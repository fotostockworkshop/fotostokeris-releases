"""Google konts (noteikumi §5 p.2, dati §7a; Vārdotājs 0.9.0-test6 — 1. daļa: pieslēgšana + rezerves kopijas Drive).

- Pieslēgšana: OAuth "Desktop app" ar atgriešanos uz 127.0.0.1 (lokāls ports) + PKCE; Google oficiālā lapa pārlūkā.
- Atļauja TIKAI `drive.file` (nesensitīva — bez "nepārbaudīta lietotne" brīdinājuma): programma redz tikai pašas
  izveidotos failus. Gmail (`gmail.send`, sensitīva) — atlikts līdz produktu piedāvāšanai citiem.
- Atslēga (refresh token) — tikai drošajā glabātuvē (`core/credentials.py`, ieraksts `google`), katrā datorā atsevišķi.
- Drive mapes: Fotostokeris/<Slug>/backups (vēlāk: settings.json, data/, Manifesti/ — 2. daļa, sinhronizācija).
- Programmas reģistrācija (client_id / client_secret) — fails core/google_client.json (repozitorijā NAV, .gitignore;
  izlaidumā iebūvēts — darbvirsmas lietotnēm Google to neuzskata par noslēpumu).
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

from . import app as _app
from . import config, credentials

SCOPE = "https://www.googleapis.com/auth/drive.file"
AUTH_URI = "https://accounts.google.com/o/oauth2/v2/auth"
TOKEN_URI = "https://oauth2.googleapis.com/token"
REVOKE_URI = "https://oauth2.googleapis.com/revoke"
DRIVE = "https://www.googleapis.com/drive/v3"
UPLOAD = "https://www.googleapis.com/upload/drive/v3"
CRED = "google"
ROOT = "Fotostokeris"
FOLDER_MIME = "application/vnd.google-apps.folder"

_state = {"flow": None, "error": "", "token": None, "token_exp": 0.0, "email": "", "folders": {}}
_lock = threading.Lock()


# --------------------------------------------------------------------------- programmas reģistrācija

def _client() -> dict | None:
    p = Path(__file__).resolve().parent / "google_client.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        d = d.get("installed") or d
        if d.get("client_id") and d.get("client_secret"):
            return d
    except (OSError, ValueError):
        pass
    return None


def configured() -> bool:
    return _client() is not None


# --------------------------------------------------------------------------- HTTP palīgi

def _http(method: str, url: str, data: bytes | None = None, headers: dict | None = None, timeout: int = 60):
    req = urllib.request.Request(url, data=data, method=method, headers=headers or {})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read(), dict(r.headers)
    except urllib.error.HTTPError as e:
        return e.code, e.read(), dict(e.headers or {})


def _form(url: str, fields: dict) -> dict:
    st, body, _ = _http("POST", url, urllib.parse.urlencode(fields).encode(),
                        {"Content-Type": "application/x-www-form-urlencoded"})
    try:
        d = json.loads(body.decode("utf-8") or "{}")
    except ValueError:
        d = {}
    if st >= 400:
        raise GoogleError(d.get("error_description") or d.get("error") or f"HTTP {st}", d.get("error"))
    return d


class GoogleError(Exception):
    def __init__(self, msg, code=None):
        super().__init__(msg)
        self.code = code


# --------------------------------------------------------------------------- pieslēgšana

def _page(ok: bool) -> bytes:
    lang = config.get("lang") or "lv"
    txt = {True: {"lv": "Google konts pieslēgts. Šo logu var aizvērt un atgriezties programmā.",
                  "en": "Google account connected. You can close this window and return to the program."},
           False: {"lv": "Google konta pieslēgšana neizdevās. Aizver šo logu un mēģini vēlreiz programmā.",
                   "en": "Connecting the Google account failed. Close this window and try again in the program."}}[ok]
    t = txt.get(lang) or txt["en"]
    return (f"<!doctype html><meta charset=utf-8><title>Fotostock Workshop</title>"
            f"<body style='font:18px system-ui;padding:48px;background:#121418;color:#fff'>"
            f"<h2 style='color:{'#9cff3c' if ok else '#ff7a6b'}'>{'✓' if ok else '✗'} Fotostock Workshop</h2><p>{t}</p>").encode()


def connect() -> dict:
    """Atver Google pieslēgšanās lapu pārlūkā; atbildi saņem lokāls ports (līdz 5 min)."""
    c = _client()
    if not c:
        raise GoogleError("not_configured", "not_configured")
    if not credentials.available():
        raise GoogleError("no_keyring", "no_keyring")
    with _lock:
        if _state["flow"] and _state["flow"].is_alive():
            webbrowser.open(_state["flow_url"])
            return {"started": True, "again": True}
        verifier = base64.urlsafe_b64encode(secrets.token_bytes(48)).rstrip(b"=").decode()
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        st = secrets.token_urlsafe(24)
        result = {}

        class H(BaseHTTPRequestHandler):
            def do_GET(self):
                q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
                if "code" not in q and "error" not in q:
                    self.send_response(404); self.end_headers(); return
                ok = q.get("state", [""])[0] == st and "code" in q
                result.update(code=q.get("code", [""])[0] if ok else "", error=q.get("error", [""])[0] or ("" if ok else "state"))
                ok2 = ok
                if ok:
                    try:
                        _finish(result["code"], verifier, redirect)
                    except Exception as e:
                        result["error"] = str(e)
                        ok2 = False
                body = _page(ok2)
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            def log_message(self, *a):
                pass

        srv = HTTPServer(("127.0.0.1", 0), H)
        redirect = f"http://127.0.0.1:{srv.server_address[1]}"
        url = AUTH_URI + "?" + urllib.parse.urlencode({
            "client_id": c["client_id"], "redirect_uri": redirect, "response_type": "code", "scope": SCOPE,
            "access_type": "offline", "prompt": "consent", "state": st,
            "code_challenge": challenge, "code_challenge_method": "S256"})

        def run():
            srv.timeout = 2
            end = time.time() + 300
            while time.time() < end and not result:
                srv.handle_request()
            srv.server_close()
            if not result:
                _state["error"] = "timeout"
            elif result.get("error"):
                _state["error"] = result["error"]
                print("Google pieslēgšana:", result["error"])

        _state["error"] = ""
        _state["flow_url"] = url
        _state["flow"] = threading.Thread(target=run, daemon=True)
        _state["flow"].start()
    webbrowser.open(url)
    return {"started": True}


def _finish(code: str, verifier: str, redirect: str) -> None:
    c = _client()
    d = _form(TOKEN_URI, {"code": code, "client_id": c["client_id"], "client_secret": c["client_secret"],
                          "redirect_uri": redirect, "grant_type": "authorization_code", "code_verifier": verifier})
    rt = d.get("refresh_token")
    if not rt:
        raise GoogleError("no refresh token")
    _state["token"], _state["token_exp"] = d.get("access_token"), time.time() + int(d.get("expires_in", 3600)) - 60
    email = ""
    try:
        email = _about().get("emailAddress", "")
    except Exception as e:
        print("Google: e-pasts nav nolasīts:", e)
    credentials.save(CRED, email, rt)
    _state["email"], _state["folders"] = email, {}
    print(f"Google konts pieslēgts: {email or '(e-pasts nav zināms)'}")


def _refresh_token() -> str | None:
    c = credentials.get(CRED)
    return c[1] if c and c[1] else None


def connected() -> bool:
    return bool(configured() and _refresh_token())


def access_token() -> str:
    if _state["token"] and time.time() < _state["token_exp"]:
        return _state["token"]
    rt = _refresh_token()
    c = _client()
    if not rt or not c:
        raise GoogleError("not_connected", "not_connected")
    try:
        d = _form(TOKEN_URI, {"refresh_token": rt, "client_id": c["client_id"], "client_secret": c["client_secret"],
                              "grant_type": "refresh_token"})
    except GoogleError as e:
        if e.code == "invalid_grant":                # atsaukts / beidzies — jāpieslēdz no jauna
            credentials.forget(CRED)
            _state["token"] = None
            raise GoogleError("expired", "expired")
        raise
    _state["token"], _state["token_exp"] = d["access_token"], time.time() + int(d.get("expires_in", 3600)) - 60
    return _state["token"]


def disconnect() -> None:
    rt = _refresh_token()
    if rt:
        try:
            _form(REVOKE_URI, {"token": rt})
        except Exception as e:
            print("Google atslēgšana (revoke):", e)
    credentials.forget(CRED)
    _state.update(token=None, token_exp=0, email="", folders={})
    print("Google konts atslēgts")


def status(check: bool = False) -> dict:
    out = {"configured": configured(), "connected": connected(), "email": "", "error": _state.get("error") or "",
           "waiting": bool(_state["flow"] and _state["flow"].is_alive()), "keyring": credentials.available()}
    c = credentials.get(CRED)
    if c:
        out["email"] = c[0] or _state["email"]
    if check and out["connected"]:
        try:
            out["email"] = _about().get("emailAddress", "") or out["email"]
        except GoogleError as e:
            out["error"] = e.code or str(e)
            out["connected"] = connected()
        except Exception as e:
            out["error"] = "offline" if isinstance(e, (urllib.error.URLError, OSError)) else str(e)[:200]
    return out


# --------------------------------------------------------------------------- Drive

def _api(method: str, url: str, params: dict | None = None, body=None, headers: dict | None = None, timeout: int = 120):
    h = {"Authorization": "Bearer " + access_token()}
    h.update(headers or {})
    if params:
        url += ("&" if "?" in url else "?") + urllib.parse.urlencode(params)
    data = body
    if isinstance(body, (dict, list)):
        data = json.dumps(body).encode()
        h.setdefault("Content-Type", "application/json; charset=UTF-8")
    st, raw, hd = _http(method, url, data, h, timeout)
    if st == 401:
        _state["token"] = None
        h["Authorization"] = "Bearer " + access_token()
        st, raw, hd = _http(method, url, data, h, timeout)
    if st >= 400:
        try:
            msg = json.loads(raw.decode("utf-8")).get("error", {}).get("message", "")
        except ValueError:
            msg = ""
        raise GoogleError(msg or f"HTTP {st}", f"http_{st}")
    return raw, hd


def _json(method, url, **kw) -> dict:
    raw, _ = _api(method, url, **kw)
    return json.loads(raw.decode("utf-8") or "{}")


def _about() -> dict:
    return _json("GET", DRIVE + "/about", params={"fields": "user(emailAddress,displayName),storageQuota(limit,usage)"}).get("user", {})


def _q(s: str) -> str:
    return s.replace("\\", "\\\\").replace("'", "\\'")


def _folder(name: str, parent: str | None) -> str:
    key = f"{parent}/{name}"
    if key in _state["folders"]:
        return _state["folders"][key]
    q = f"name = '{_q(name)}' and mimeType = '{FOLDER_MIME}' and trashed = false" + (f" and '{parent}' in parents" if parent else "")
    found = _json("GET", DRIVE + "/files", params={"q": q, "fields": "files(id,name)", "spaces": "drive"}).get("files", [])
    if found:
        fid = found[0]["id"]
    else:
        meta = {"name": name, "mimeType": FOLDER_MIME}
        if parent:
            meta["parents"] = [parent]
        fid = _json("POST", DRIVE + "/files", params={"fields": "id"}, body=meta)["id"]
    _state["folders"][key] = fid
    return fid


def folder(*parts: str) -> str:
    """Fotostokeris/<parts…> mapes ID (izveido, ja nav)."""
    fid = _folder(ROOT, None)
    for p in parts:
        fid = _folder(p, fid)
    return fid


def upload(path: str | Path, parent: str, name: str | None = None, mime: str = "application/zip") -> dict:
    """Augšupielāde (resumable — der arī lieliem failiem)."""
    path = Path(path)
    size = path.stat().st_size
    _, hd = _api("POST", UPLOAD + "/files", params={"uploadType": "resumable", "fields": "id,name,size"},
                 body={"name": name or path.name, "parents": [parent]},
                 headers={"X-Upload-Content-Type": mime, "X-Upload-Content-Length": str(size)})
    loc = hd.get("Location") or hd.get("location")
    if not loc:
        raise GoogleError("upload: no session")
    st, raw, _ = _http("PUT", loc, path.read_bytes(), {"Content-Type": mime, "Content-Length": str(size)}, timeout=600)
    if st >= 400:
        raise GoogleError(f"upload HTTP {st}", f"http_{st}")
    return json.loads(raw.decode("utf-8") or "{}")


def list_files(parent: str) -> list[dict]:
    out, token = [], None
    while True:
        p = {"q": f"'{parent}' in parents and trashed = false", "fields": "nextPageToken,files(id,name,size,createdTime,modifiedTime)",
             "orderBy": "createdTime desc", "pageSize": 100}
        if token:
            p["pageToken"] = token
        d = _json("GET", DRIVE + "/files", params=p)
        out += d.get("files", [])
        token = d.get("nextPageToken")
        if not token:
            return out


def download(file_id: str) -> bytes:
    raw, _ = _api("GET", f"{DRIVE}/files/{urllib.parse.quote(file_id)}", params={"alt": "media"}, timeout=600)
    return raw


def delete(file_id: str) -> None:
    _api("DELETE", f"{DRIVE}/files/{urllib.parse.quote(file_id)}")


# --------------------------------------------------------------------------- rezerves kopijas

def backups_folder() -> str:
    return folder(_app.current().slug, "backups")


def backup_upload(path: str | Path, keep: int) -> dict:
    """Rezerves kopiju augšupielādē Drive un paliek pēdējās `keep` kopijas (noteikumi dati §7a)."""
    fid = backups_folder()
    r = upload(path, fid)
    slug = _app.current().slug
    items = sorted((f for f in list_files(fid) if f["name"].startswith(f"{slug}-backup-") and f["name"].endswith(".zip")),
                   key=lambda f: f["name"], reverse=True)          # nosaukumā laiks — jaunākās pirmās
    for f in items[max(1, keep):]:
        try:
            delete(f["id"])
        except Exception as e:
            print("Google Drive: vecās kopijas dzēšana:", e)
    return r


def backup_list() -> list[dict]:
    slug = _app.current().slug
    return [{"id": f["id"], "name": f["name"], "size": int(f.get("size") or 0), "mtime": f.get("createdTime", "")}
            for f in sorted(list_files(backups_folder()), key=lambda f: f["name"], reverse=True)
            if f["name"].startswith(f"{slug}-backup-")]
