"use strict";
/* Vārdotājs 0.9.0-test6 (+ test10: sinhronizācija ar citiem datoriem) — Google konts (1. daļa): "Pieslēgumi" rinda "Google konts" un rezerves kopijas arī uz
   Google Drive (core/google.py, API "google"; noteikumi §5 p.2, dati §7a). Atļauja tikai drive.file — programma redz
   tikai pašas izveidotos failus. Lieto app.js / upd.js / conn.js palīgus ($, $$, api, t, esc, toast, uiConfirm, S,
   restoreBackup, fmtDT, fmtSize, connLoad, loadBackups, saveSettings). */

const G_I18N = {
  lv: {
    cn_google: "Google konts",
    cn_google_d: "Google Drive — rezerves kopijas ārpus datora, darbs no vairākiem datoriem un sēriju manifesti ar sīktēliem (mape Fotostokeris/Manifesti — tos lasa Analītiķis un Tirgotājs). Programma Drive redz tikai pašas izveidotos failus (mape Fotostokeris), ne tavas bildes un citus dokumentus.",
    g_connect: "Pieslēgt", g_disconnect: "Atslēgt", g_on: "pieslēgts", g_off: "nav pieslēgts",
    g_wait: "gaidu pieslēgšanos pārlūkā…", g_opened: "Pārlūkā atvērta Google lapa — izvēlies kontu un spied \"Atļaut\" (Allow). Rinda kļūs zaļa pati. Ja pārlūka logu neredzi — paskaties uzdevumjoslā.",
    g_ok: "Google konts pieslēgts: {e}", g_dis_q: "Atslēgt Google kontu? Rezerves kopijas Google Drive paliks, bet jaunas tur vairs netiks kopētas.",
    g_nocfg: "šajā versijā nav Google pieslēguma datu", g_expired: "pieslēgums beidzies — pieslēdz no jauna", g_offline: "nav interneta — pārbaudīšu vēlāk",
    g_timeout: "pieslēgšanās netika pabeigta — mēģini vēlreiz", g_denied: "pārlūkā netika atļauts", g_nokeyring: "datorā nav drošās glabātuves — Google kontu nevar saglabāt",
    bk_g: "Kopēt arī uz Google Drive", bk_g_need: "Vispirms pieslēdz Google kontu (Iestatījumi → Pieslēgumi).",
    bk_g_info: "Google Drive mapē Fotostokeris/Vardotajs/backups glabājas tikpat kopiju, cik iestatīts \"Cik kopijas paturēt\". Pēdējā augšupielāde: {d}.",
    bk_g_err: "Pēdējā augšupielāde neizdevās: {e}", bk_g_never: "vēl nav",
    sy_chk: "Sinhronizēt ar citiem datoriem", sy_d: "Iestatījumi (bez šī datora mapēm), šabloni, tulkojumi, vietu noteikumi un sagatavoto bilžu uzskaite — caur Google Drive. Ieslēdz katrā datorā, kurā lieto Vārdotāju. Bildes netiek sinhronizētas.",
    sy_now: "Sinhronizēt tagad", sy_last: "Sinhronizēts: {d}", sy_never: "vēl nav sinhronizēts", sy_err: "Sinhronizācijas kļūda: {e}",
    sy_busy: "Sinhronizēju…", sy_done: "Sinhronizēts.", sy_got: "Dati atjaunoti no datora {c}: {f}",
    sy_other: "Vārdotājs nesen ({d}) lietots arī datorā {c} — nestrādā abos datoros vienlaikus.",
    sy_f_settings: "iestatījumi", sy_f_templates: "šabloni", sy_f_translations: "tulkojumi", sy_f_place_rules: "vietu noteikumi", sy_f_prepared: "sagatavoto bilžu uzskaite",
    bk_g_list: "Google Drive kopijas", bk_g_none: "Google Drive vēl nav nevienas kopijas.", bk_g_loading: "Ielādēju sarakstu no Google Drive…",
    bk_g_up: "Arī uz Google Drive", bk_g_upd: "Kopija augšupielādēta Google Drive.",
  },
  en: {
    cn_google: "Google account",
    cn_google_d: "Google Drive — backups outside the computer, working from several computers and series manifests with thumbnails (folder Fotostokeris/Manifesti — read by Analītiķis and Tirgotājs). In Drive the program sees only the files it created itself (folder Fotostokeris), not your photos or other documents.",
    g_connect: "Connect", g_disconnect: "Disconnect", g_on: "connected", g_off: "not connected",
    g_wait: "waiting for sign-in in the browser…", g_opened: "A Google page opened in the browser — choose the account and click \"Allow\". The row will turn green by itself. If you do not see the browser window — look in the taskbar.",
    g_ok: "Google account connected: {e}", g_dis_q: "Disconnect the Google account? Backups in Google Drive stay, but new ones will no longer be copied there.",
    g_nocfg: "this version has no Google connection data", g_expired: "the connection expired — connect again", g_offline: "no internet — will check later",
    g_timeout: "sign-in was not finished — try again", g_denied: "not allowed in the browser", g_nokeyring: "no secure storage on this computer — the Google account cannot be saved",
    bk_g: "Also copy to Google Drive", bk_g_need: "Connect the Google account first (Settings → Connections).",
    bk_g_info: "The Google Drive folder Fotostokeris/Vardotajs/backups keeps as many copies as set in \"Copies to keep\". Last upload: {d}.",
    bk_g_err: "The last upload failed: {e}", bk_g_never: "none yet",
    sy_chk: "Sync with other computers", sy_d: "Settings (without this computer's folders), templates, translations, place rules and the register of prepared photos — via Google Drive. Turn it on on every computer where you use Vārdotājs. Photos are not synced.",
    sy_now: "Sync now", sy_last: "Synced: {d}", sy_never: "not synced yet", sy_err: "Sync error: {e}",
    sy_busy: "Syncing…", sy_done: "Synced.", sy_got: "Data updated from computer {c}: {f}",
    sy_other: "Vārdotājs was recently ({d}) used on computer {c} too — do not work on both computers at the same time.",
    sy_f_settings: "settings", sy_f_templates: "templates", sy_f_translations: "translations", sy_f_place_rules: "place rules", sy_f_prepared: "register of prepared photos",
    bk_g_list: "Google Drive backups", bk_g_none: "No backups in Google Drive yet.", bk_g_loading: "Loading the list from Google Drive…",
    bk_g_up: "Also to Google Drive", bk_g_upd: "The backup was uploaded to Google Drive.",
  },
};
for (const l of Object.keys(G_I18N)) {
  window.I18N[l] = window.I18N[l] || {};
  for (const [k, v] of Object.entries(G_I18N[l])) if (!(k in window.I18N[l])) window.I18N[l][k] = v;
}

const GG = { st: null, poll: null };
const gWhy = (e) => ({ not_configured: "g_nocfg", expired: "g_expired", offline: "g_offline", timeout: "g_timeout", access_denied: "g_denied", no_keyring: "g_nokeyring" }[e]);

/* ---------- Pieslēgumi: rinda "Google konts" (aiz OneDrive) ---------- */
function gRow() {
  let row = $('.conn[data-p="google"]');
  if (row) return row;
  const box = $("#connList"); if (!box) return null;
  box.insertAdjacentHTML("beforeend", `<div class="conn" data-p="google"><span class="dot cn-dot"></span>
    <div class="cn-main"><b data-i18n="cn_google"></b> <span class="cn-st muted small"></span>
      <div class="muted small" data-i18n="cn_google_d"></div><div class="cn-info small"></div>
      <div class="g-sync hidden"><label class="chk"><input type="checkbox" class="g-sync-chk"> <span data-i18n="sy_chk"></span></label>
        <div class="muted small" data-i18n="sy_d"></div><div class="row"><button class="small-btn g-sync-now" data-i18n="sy_now"></button>
        <span class="g-sync-st muted small"></span></div></div></div>
    <div class="cn-act"><button class="small-btn primary g-connect" data-i18n="g_connect"></button>
      <button class="small-btn ghost g-disconnect hidden" data-i18n="g_disconnect"></button></div></div>`);
  row = $('.conn[data-p="google"]');
  const od = $('.conn[data-p="onedrive"]');
  if (od) od.after(row);
  applyI18n(row);
  $(".g-connect", row).addEventListener("click", gConnect);
  $(".g-disconnect", row).addEventListener("click", gDisconnect);
  $(".g-sync-chk", row).addEventListener("change", async (e) => {
    try { syPaint(await api("google", { do: "sync_set", on: e.target.checked })); S.settings.google_sync = e.target.checked; setTimeout(syPoll, 6000); }
    catch (err) { toast(err.message, "err"); }
  });
  $(".g-sync-now", row).addEventListener("click", async (e) => {
    const b = e.target; b.disabled = true; $(".g-sync-st", row).textContent = t("sy_busy");
    try { const d = await api("google", { do: "sync_now" }); syPaint(d); syGot(d); toast(t("sy_done"), "ok", 3000); }
    catch (err) { toast(t("sy_err", { e: gWhy(err.message) ? t(gWhy(err.message)) : err.message }), "err", 9000); syLoad(); }
    finally { b.disabled = false; }
  });
  return row;
}
function gPaint(s) {
  const row = gRow(); if (!row) return;
  GG.st = s;
  const on = !!(s && s.connected);
  let ok = on ? true : false, txt = on ? t("g_on") + (s.email ? " · " + s.email : "") : t("g_off");
  if (s && !s.configured) txt = t("g_nocfg");
  else if (s && s.keyring === false) txt = t("g_nokeyring");
  else if (s && s.waiting && !on) { ok = null; txt = t("g_wait"); }
  else if (s && s.error) txt = (on ? txt + " · " : "") + (gWhy(s.error) ? t(gWhy(s.error)) : s.error);
  $(".cn-dot", row).className = "dot cn-dot " + (ok === true ? "ok" : ok === false ? "off" : "");
  $(".cn-st", row).textContent = txt;
  $(".g-connect", row).classList.toggle("hidden", on);
  $(".g-connect", row).disabled = !(s && s.configured && s.keyring !== false);
  $(".g-disconnect", row).classList.toggle("hidden", !on);
  $(".g-sync", row).classList.toggle("hidden", !on);
  bkGPaint();
  if (on) syLoad();
}
async function gLoad(check = true) {
  try { gPaint(await api("google", { do: "status", check })); } catch (_) { /* */ }
}
async function gConnect() {
  try {
    await api("google", { do: "connect" });
    toast(t("g_opened"), "ok", 9000);
    gPaint(Object.assign({}, GG.st || {}, { waiting: true, connected: false, error: "" }));
    clearInterval(GG.poll);
    const t0 = Date.now();
    GG.poll = setInterval(async () => {
      let s; try { s = await api("google", { do: "status" }); } catch (_) { return; }
      if (s.connected || !s.waiting || Date.now() - t0 > 310e3) {
        clearInterval(GG.poll); gPaint(s);
        if (s.connected) { toast(t("g_ok", { e: s.email || "" }), "ok", 6000); gLoad(true); }
      }
    }, 2500);
  } catch (e) { toast(gWhy(e.message) ? t(gWhy(e.message)) : e.message, "err", 8000); }
}
async function gDisconnect() {
  if (!(await uiConfirm(t("g_dis_q")))) return;
  try { gPaint(await api("google", { do: "disconnect" })); } catch (e) { toast(e.message, "err"); }
}

/* ---------- Rezerves kopijas: "Kopēt arī uz Google Drive" + saraksts ---------- */
function bkGBox() {
  let box = $("#bkGoogle");
  if (box) return box;
  const list = $("#bkList"); if (!list) return null;
  list.insertAdjacentHTML("afterend", `<div id="bkGoogle" class="bk-g">
    <label class="chk"><input type="checkbox" id="sBkGoogle"> <span data-i18n="bk_g"></span></label>
    <div id="bkGInfo" class="muted small"></div>
    <details id="bkGDet"><summary data-i18n="bk_g_list"></summary><div id="bkGList" class="muted small"></div></details></div>`);
  box = $("#bkGoogle");
  applyI18n(box);
  $("#sBkGoogle").addEventListener("change", async (e) => {
    try { S.settings = (await api("settings", { settings: { backup_google: e.target.checked } })).settings; } catch (err) { toast(err.message, "err"); }
    bkGPaint();
  });
  $("#bkGDet").addEventListener("toggle", () => { if ($("#bkGDet").open) bkGList(); });
  return box;
}
function bkGPaint() {
  const box = bkGBox(); if (!box) return;
  const on = !!(GG.st && GG.st.connected);
  const chk = $("#sBkGoogle");
  chk.disabled = !on;
  chk.checked = on && !!(S.settings && S.settings.backup_google);
  $("#bkGoogle label.chk").title = on ? "" : t("bk_g_need");
  const s = S.settings || {};
  $("#bkGInfo").textContent = !on ? t("bk_g_need")
    : s.backup_google ? (s.backup_google_err ? t("bk_g_err", { e: s.backup_google_err }) : t("bk_g_info", { d: s.backup_google_last ? fmtDT(s.backup_google_last) : t("bk_g_never") })) : "";
  $("#bkGDet").classList.toggle("hidden", !on);
}
async function bkGList() {
  const el = $("#bkGList");
  el.textContent = t("bk_g_loading");
  let d;
  try { d = await api("google", { do: "backups" }); } catch (e) { el.textContent = gWhy(e.message) ? t(gWhy(e.message)) : e.message; return; }
  el.innerHTML = d.items.length ? `<table class="bk-t"><tbody>` + d.items.slice(0, 12).map((x) =>
    `<tr><td>${esc(fmtDT(x.mtime))}</td><td class="muted">${fmtSize(x.size)}</td><td><button data-gid="${esc(x.id)}">${esc(t("bk_restore"))}</button></td></tr>`).join("") + `</tbody></table>`
    : esc(t("bk_g_none"));
  $$("#bkGList [data-gid]").forEach((b) => b.addEventListener("click", () => restoreBackup({ gdrive_id: b.dataset.gid })));
}

/* ---------- Sinhronizācija ar citiem datoriem (core/sync.py; dati §7a) ---------- */
const syFiles = (f) => (f || []).map((n) => t("sy_f_" + n.replace(".json", ""))).join(", ");
function syPaint(d) {
  const row = $('.conn[data-p="google"]'); if (!row || !d) return;
  $(".g-sync-chk", row).checked = !!d.enabled;
  $(".g-sync-now", row).disabled = !d.enabled;
  $(".g-sync-st", row).textContent = !d.enabled ? "" : d.err ? t("sy_err", { e: gWhy(d.err) ? t(gWhy(d.err)) : d.err })
    : t("sy_last", { d: d.last ? fmtDT(d.last) : t("sy_never") });
}
async function syLoad() { try { syPaint(await api("google", { do: "sync_status" })); } catch (_) { /* */ } }
async function syGot(d) {
  if (d.other && GG.other !== d.other.computer) { GG.other = d.other.computer; toast(t("sy_other", { c: d.other.computer, d: fmtDT(d.other.last) }), "err sticky", 15000); }
  if (!d.got_at || d.got_at === GG.gotAt) return;
  GG.gotAt = d.got_at;
  toast(t("sy_got", { c: d.got_from || "?", f: syFiles(d.got) }), "ok sticky", 10000);
  if ((d.got || []).includes("settings.json")) {        // iestatījumi mainījušies — lai saglabāšana nepārraksta ar vecajiem
    try { S.settings = (await api("state")).settings; } catch (_) { /* */ }
    const pg = $("#page-settings");
    if (pg && !pg.classList.contains("hidden") && typeof loadSettingsPage === "function") loadSettingsPage();
  }
}
async function syPoll() {
  try { const d = await api("google", { do: "sync_status" }); if (d.enabled) { syGot(d); syPaint(d); } } catch (_) { /* */ }
}
setInterval(syPoll, 60000);
setTimeout(syPoll, 15000);

/* ---------- app.js / conn.js / upd.js funkcijas papildinām ---------- */
const _gConnLoad = connLoad;
connLoad = async function () {                      // eslint-disable-line no-func-assign
  await _gConnLoad();
  gRow();
  gLoad(true);
};
const _gLoadBackups = loadBackups;
loadBackups = async function () {                   // eslint-disable-line no-func-assign
  await _gLoadBackups();
  bkGBox();
  if (!GG.st) await gLoad(false); else bkGPaint();
  if ($("#bkGDet") && $("#bkGDet").open) bkGList();
};
// pēc "Izveidot tagad" — Google Drive augšupielāde notiek fonā; pēc brīža atjaunojam informāciju
$("#bkNow").addEventListener("click", () => setTimeout(async () => {
  try { S.settings = (await api("state")).settings; } catch (_) { /* */ }
  bkGPaint();
}, 8000));
