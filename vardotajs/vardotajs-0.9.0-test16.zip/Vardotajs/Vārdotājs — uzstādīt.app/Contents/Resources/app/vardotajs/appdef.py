"""Vārdotāja apraksts kopīgajam kodam core/ (noteikumi §10, §12)."""
from __future__ import annotations

from pathlib import Path

from core import app as core_app

from . import APP_NAME, VERSION
from .config import DEFAULT_SETTINGS   # config.py importē šo failu tikai pēc DEFAULT_SETTINGS

ROOT = Path(__file__).resolve().parent.parent


def _validate(vals: dict) -> dict:
    from . import config
    if "rfed_criteria" in vals and not str(vals["rfed_criteria"]).strip():
        vals["rfed_criteria"] = config.DEFAULT_RFED
    for k in ("parallel", "batch_photos", "keywords_count", "title_max", "description_max", "ed_description_max",
              "complete_min_keywords", "thumb_size"):
        if k in vals:
            try:
                vals[k] = int(vals[k])
            except (TypeError, ValueError):
                vals.pop(k)
    if "style" in vals and not str(vals["style"]).strip():
        vals["style"] = config.DEFAULT_STYLE
    if isinstance(vals.get("ai_roles"), dict):               # saderībai: vecā atslēga = pirmais aprakstiem
        first = (vals["ai_roles"].get("describe") or [None])[0]
        old = {"claude_sub": "claude_cli", "chatgpt_sub": "codex_cli", "claude_api": "api", "openai_api": "openai_api"}
        if first in old:
            vals["ai_provider"] = old[first]
    if "lang" in vals and vals["lang"] not in ("lv", "en"):      # Vārdotāja saskarne pagaidām tikai LV/EN
        vals["lang"] = "en"
    return vals


def _busy() -> bool:
    from . import jobs
    return jobs.busy()


APP = core_app.init(core_app.App(
    name=APP_NAME, slug="Vardotajs", version=VERSION, ports=(47615, 47616, 47617), api_prefix="",
    web_dir=ROOT / "web", defaults=DEFAULT_SETTINGS, msgs={}, busy=_busy,
    validate_settings=_validate, icon=ROOT / "assets" / "icon.png",
    backup_files=("templates.json", "history.json", "notes.json", "chats.json", "photo_notes.json",
                  "translations.json", "place_rules.json", "jobs.json", "sort_undo.json", "prepared.json"),
    sync_files=("templates.json", "translations.json", "place_rules.json", "prepared.json"),
    local_keys=("ready_dir", "manifest_dir", "ready_verify", "notify_system", "thumb_size", "drive_backfill", "ed_prefix_backfill", "ed_fix_done")))


def after_restore() -> None:
    """Pēc rezerves kopijas atjaunošanas — JSON krātuves ielasa no jauna."""
    from . import store, submit
    submit._ledger = None
    for n in ("_templates", "_history", "_notes", "_chats", "_photos", "_places", "_tr"):
        setattr(store, n, None)
