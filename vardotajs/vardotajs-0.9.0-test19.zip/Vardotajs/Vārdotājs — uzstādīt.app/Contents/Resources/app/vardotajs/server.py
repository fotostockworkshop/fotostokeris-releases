"""Lokālais HTTP serveris, kas apkalpo saskarni (web/) un tās API."""
from __future__ import annotations

import os
import sys
import subprocess
import threading
import time

from core import server as core_server

from . import VERSION, ai, codex, config, exif, files, jobs, manifest, sorter, store, submit
from .i18n import T

# HTTP serveris, žetons, kopīgie API (ping, quit, settings, atjauninājumi, rezerves kopijas …) — core/server.py (0.9.0)
TOKEN = core_server.TOKEN
BOOT = core_server.BOOT              # mainās katrā palaišanā (sākuma bannerim)

state = {"installing": None, "install_msg": ""}


def _ok(**kw):
    kw.setdefault("ok", True)
    return kw


# --------------------------------------------------------------------------- API funkcijas

def api_state(_):
    return _ok(**core_server.base_state(),
               provider=ai.active_provider(),
               exiftool=exif.ET.version() if exif.find_exiftool() else None,
               installing=state["installing"], install_msg=state["install_msg"])


def api_roots(_):
    return _ok(roots=files.roots())


def api_dirs(b):
    return _ok(dirs=files.subdirs(b["path"]))


def api_list(b):
    path = b["path"]
    if not os.path.isdir(path):
        return {"ok": False, "error": T("folder_missing", path=path)}
    config.update({"last_folder": path})
    return _ok(**files.listing(path, int(b.get("depth", 0)), b.get("sort", "name")))


def api_status(b):
    return _ok(status=exif.read_status(b["paths"]))


def api_read(b):
    return _ok(meta=exif.read_meta(b["paths"], info=bool(b.get("info"))))


def api_save(b):
    items = b["items"]
    errors = {}
    # noklusējuma autors (Iestatījumos) tiek ierakstīts bildēm, kurām autora vēl nav
    default_author = (config.get("author") or "").strip()
    if default_author:
        try:
            cur = exif.read_meta([it["path"] for it in items])
            for it in items:
                if not it.get("author") and not cur.get(it["path"], {}).get("author"):
                    it["author"] = default_author
        except Exception:
            pass
    for it in items:
        try:
            kws = store.clean_keywords(it["keywords"]) if "keywords" in it and it["keywords"] is not None else None
            exif.write_meta(it["path"], it.get("title"), it.get("description"), kws, it.get("author"))
        except Exception as e:
            errors[it["path"]] = str(e)
    paths = [it["path"] for it in items]
    meta = exif.read_meta(paths)
    # lietotājs tekstu redzēja un saglabāja — ✂ to vairs neapšauba (ja vien nav par garu)
    for it in items:
        if it["path"] not in errors and b.get("texts_touched") and ("title" in it or "description" in it):
            m = meta.get(it["path"]) or {}
            store.set_cut_ok(it["path"], store.text_sig(m.get("title", ""), m.get("description", "")))
            if store.has_draft(it["path"]):
                store.set_draft(it["path"], None)        # melnraksts apstiprināts
    status = exif.read_status(paths)
    for p in paths[:3] if len(paths) <= 3 else paths[:1]:
        if p not in errors:
            store.add_history(meta[p])
    manifest.touch(paths)                        # "dzīvs" manifests (0.9.0-test4)
    return _ok(status=status, meta=meta, errors=errors, history=store.history().data)


def api_generate(b):
    try:
        res = ai.generate(b["path"], b.get("context", ""), b.get("editorial"), None, bool(b.get("illustrative")))
        return _ok(result=res, notices=ai.take_notices(), provider=ai.active_provider())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_batch(b):
    tpl = []
    if b.get("template_id"):
        for t in store.templates().data:
            if t["id"] == b["template_id"]:
                tpl = t["keywords"]
    jid = jobs.start(b["paths"], "generate", b.get("context", ""), bool(b.get("autosave", True)), tpl,
                     b.get("editorial"), illustrative=bool(b.get("illustrative")))
    return _ok(job=jid)


# --- mapes piezīmes un saruna ar AI
def api_notes(b):
    folder = b["folder"]
    own = store.folder_note(folder)
    inh = [n for n in store.inherited_notes(folder) if n["path"] != os.path.abspath(folder)]
    fi = store.folder_instr(folder)
    return _ok(own=own, inherited=inh, chat=store.get_chat(folder), instr=fi["instr"], generic=fi["generic"],
               generic_inherited=store.instructions_for(os.path.join(folder, "x.jpg"))["generic"])


def api_notes_set(b):
    store.set_folder_note(b["folder"], b.get("text", ""))
    return api_notes(b)


def api_chat(b):
    try:
        res = ai.chat(b["folder"], b["message"], b.get("path"), b.get("form"), b.get("editorial"),
                      int(b.get("multi") or 0), b.get("paths"), bool(b.get("illustrative")))
    except Exception as e:
        return {"ok": False, "error": str(e)}
    if res.get("batch") and b.get("paths"):
        res["job"] = jobs.start(b["paths"], "generate", b["message"], True, None, b.get("editorial"),
                                illustrative=bool(b.get("illustrative")))
    return _ok(result=res, own=store.folder_note(b["folder"]), chat=store.get_chat(b["folder"]),
               notices=ai.take_notices(), provider=ai.active_provider())


def api_folder_instr_set(b):
    store.set_folder_instr(b["folder"], b.get("instr"), b.get("generic"))
    return api_notes(b)


def api_photo_instr_set(b):
    for p in b["paths"]:
        store.set_photo_instr(p, b.get("instr"), b.get("generic"))
    return _ok(notes=store.get_photos(b["paths"]))


def api_place_rules(b):
    return _ok(rules=store.get_place_rules(b.get("place", "")))


def api_place_rules_check(b):
    try:
        r = ai.check_place_rules(b["place"])
        return _ok(result=r, rules=store.get_place_rules(b["place"]), notices=ai.take_notices())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_photo_notes(b):
    return _ok(notes=store.get_photos(b["paths"]))


def api_photo_note_set(b):
    for p in b["paths"]:
        store.set_photo_note(p, b.get("text", ""))
    return _ok(notes=store.get_photos(b["paths"]))


def api_hint_set(b):
    for p in b["paths"]:
        store.set_hint(p, b.get("hint", ""), b.get("conf", "sure"), bool(b.get("ok", True)))
    return _ok(notes=store.get_photos(b["paths"]))


def api_ed_swap(b):
    """Jau aprakstītām ED bildēm samaina virsrakstu un aprakstu, lai 'CITY, COUNTRY – DATE:' būtu aprakstā."""
    paths = b["paths"]
    meta = exif.read_meta(paths)
    swapped, skipped, errors = [], 0, {}
    for p in paths:
        m = meta.get(p) or {}
        t, d = m.get("title", ""), m.get("description", "")
        if ai.has_ed_prefix(t) and not ai.has_ed_prefix(d):
            new_desc = t
            new_title = d if d else ai.strip_ed_prefix(t)
            try:
                exif.write_meta(p, title=new_title, description=new_desc)
                swapped.append(p)
            except Exception as e:
                errors[p] = str(e)
        else:
            skipped += 1
    manifest.touch(swapped)
    return _ok(count=len(swapped), skipped=skipped, errors=errors,
               status=exif.read_status(swapped) if swapped else {}, meta=exif.read_meta(swapped) if swapped else {})


def api_recognize(b):
    paths = b["paths"]
    skipped = 0
    if b.get("skip_known"):
        # izlaižam bildes, kuras jau ir atpazītas UN aprakstītas (melnraksts vai pilni metadati)
        known = store.get_photos(paths)
        st = exif.read_status(paths)
        keep = [p for p in paths if not ((known.get(p) or {}).get("hint")
                                         and ((known.get(p) or {}).get("draft") or st.get(p, {}).get("status") == "full"))]
        skipped = len(paths) - len(keep)
        paths = keep
    if not paths:
        return _ok(job=None, count=0, skipped=skipped)
    return _ok(job=jobs.start(paths, "recognize", root=b.get("root", "")), count=len(paths), skipped=skipped)


def api_translate(b):
    try:
        return _ok(translations=ai.translate(b["texts"]))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_fix_cut(b):
    """Nogrieztu/par garu tekstu labošana ar AI (tikai tām bildēm, kurām tiešām ir problēma)."""
    meta = exif.read_meta(b["paths"])
    paths = [p for p, m in meta.items() if ai.text_problems(m.get("title", ""), m.get("description", ""))["fields"]]
    if not paths:
        return _ok(job=None, count=0)
    return _ok(job=jobs.start(paths, "fix", root=b.get("root", "")), count=len(paths))


def api_draft_apply(b):
    """Atlasīto bilžu AI melnrakstus ieraksta failos bez atsevišķas pārskatīšanas."""
    errors, done = {}, []
    default_author = (config.get("author") or "").strip()
    cur = exif.read_meta(b["paths"]) if default_author else {}
    for p in b["paths"]:
        d = store.get_draft(p)
        if not d:
            continue
        try:
            author = default_author if default_author and not (cur.get(p) or {}).get("author") else None
            exif.write_meta(p, d.get("title", ""), d.get("description", ""), store.clean_keywords(d.get("keywords") or []),
                            author)
            store.set_cut_ok(p, store.text_sig(d.get("title", ""), d.get("description", "")))
            store.set_draft(p, None)
            done.append(p)
        except Exception as e:
            errors[p] = str(e)
    manifest.touch(done)
    return _ok(count=len(done), errors=errors, status=exif.read_status(b["paths"]),
               meta=exif.read_meta(b["paths"]), notes=store.get_photos(b["paths"]))


def api_draft_discard(b):
    for p in b["paths"]:
        store.set_draft(p, None)
    manifest.touch(b["paths"])
    return _ok(status=exif.read_status(b["paths"]), notes=store.get_photos(b["paths"]))


def api_cut_ok(b):
    """'Teksts ir kārtībā' — paslēpt ✂ šīm bildēm (kamēr teksts netiek mainīts)."""
    meta = exif.read_meta(b["paths"])
    for p, m in meta.items():
        store.set_cut_ok(p, store.text_sig(m.get("title", ""), m.get("description", "")), "user")
    return _ok(status=exif.read_status(b["paths"]))


def api_job_resume(b):
    try:
        return _ok(job=jobs.resume(b["id"]))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_jobs_clear(_):
    jobs.clear_finished()
    return _ok(jobs=jobs.snapshot())


# --- ChatGPT (Codex) konts
def api_codex_status(_):
    st = codex.auth_status()
    ai._status_cache["codex_cli"] = (time.time(), bool(st.get("loggedIn")))
    st["info"] = codex.info() if st.get("found") else {"found": False}
    return _ok(auth=st)


def api_codex_login(_):
    try:
        return _ok(**codex.login())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_codex_install(_):
    try:
        return _ok(**codex.install())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_codex_logout(_):
    try:
        codex.logout()
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return _ok(auth=codex.auth_status())


def api_chat_forget(b):
    try:
        r = store.forget_chat_fact(b["folder"], int(b["index"]))
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return _ok(removed=r["removed"], chat=store.get_chat(b["folder"]), own=store.folder_note(b["folder"]))


def api_chat_clear(b):
    store.clear_chat(b["folder"])
    return _ok(chat=[])


# --- RF/ED šķirošana
def api_classify(b):
    jid = jobs.start(b["paths"], "classify", root=b["root"])
    return _ok(job=jid)


def api_sort_apply(b):
    res = sorter.apply(b["root"], b["moves"])
    jobs.mark_applied(b.get("job_id"))
    # ja pārskatā kategorija mainīta (RF<->ED), melnraksts rakstīts pēc nepareiziem noteikumiem — pārģenerējam
    regen = []
    for m in res["moved"]:
        d = store.get_draft(m["dst"])
        if d and d.get("cat") and d["cat"] != m.get("category"):
            regen.append(m["dst"])
    nodraft = [m["dst"] for m in res["moved"] if not store.get_draft(m["dst"])]
    if regen:
        res["regen_job"] = jobs.start(regen, "draft", root=b["root"], illustrative=bool(b.get("illustrative")))
        res["regen"] = len(regen)
    if b.get("generate_after") and nodraft:
        res["job"] = jobs.start(nodraft, "draft", root=b["root"])
    return _ok(**res)


def api_move_cat(b):
    """Pēc kategorijas maiņas redaktorā: pārvietot bildes no RF uz ED mapi (vai otrādi) tajā pašā vecākmapē."""
    groups: dict[str, list] = {}
    for m in b["moves"]:
        root = os.path.dirname(os.path.dirname(m["path"]))
        groups.setdefault(root, []).append({"path": m["path"], "category": m["category"]})
    moved, errors = [], []
    for root, mv in groups.items():
        r = sorter.apply(root, mv)
        moved += r["moved"]
        errors += r["errors"]
    if b.get("always"):
        config.update({"auto_move_cat": True})
    return _ok(moved=moved, count=len(moved), errors=errors)


# --- ED ⇄ RF maiņa redaktorā (0.9.0-test4): noņemt vietu un datumu bez AI
def api_ed_strip(b):
    out, errors = {}, {}
    meta = exif.read_meta(b["paths"])
    for p in b["paths"]:
        m = meta.get(p) or {}
        t, d = m.get("title", ""), m.get("description", "")
        nt, nd = ai.strip_ed_prefix(t), ai.strip_ed_prefix(d)
        if (nt, nd) == (t, d):
            continue
        nd = nd[:1].upper() + nd[1:]
        nt = nt[:1].upper() + nt[1:]
        try:
            exif.write_meta(p, title=nt, description=nd)
            store.set_cut_ok(p, store.text_sig(nt, nd))
            out[p] = True
        except Exception as e:
            errors[p] = str(e)
    for p in b["paths"]:                         # arī melnrakstā
        d = store.get_draft(p)
        if d and (ai.has_ed_prefix(d.get("description", "")) or ai.has_ed_prefix(d.get("title", ""))):
            d = dict(d, title=ai.strip_ed_prefix(d.get("title", "")), description=ai.strip_ed_prefix(d.get("description", "")),
                     cat="RF", illustrative=False)
            store.set_draft(p, d)
    manifest.touch(b["paths"])
    return _ok(count=len(out), errors=errors, meta=exif.read_meta(b["paths"]), status=exif.read_status(b["paths"]),
               notes=store.get_photos(b["paths"]))


# --- manifesti un "Uz iesniegšanu" (0.9.0-test4; noteikumi dati §7a)
def api_submit_plan(b):
    try:
        pl = submit.plan(b["paths"])
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return _ok(root=pl["root"], count=pl["count"], verify=pl["verify"], dups=pl["dups"], skipped=pl["skipped"],
               groups=[{"src": g["src"], "dest": g["dest"], "n": len(g["paths"]), "code": g["code"], "type": g["type"],
                        "example": (g["renames"][0]["name"] if g["renames"] else "")} for g in pl["groups"]])


def api_submit_move(b):
    try:
        return _ok(**submit.move(b["paths"], b.get("skip") or []))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_submit_rmdirs(b):
    try:
        return _ok(**submit.rmdirs(b.get("folders") or []))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_submit_undo(_):
    try:
        return _ok(**submit.undo())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_prepared_stats(_):
    return _ok(version=VERSION, **submit.stats())


def api_ready_places(_):
    return _ok(places=submit.places(), manifest_default=manifest.shared_dir())


def api_translate_rules(b):
    if (config.get("lang") or "lv") == "en":
        return _ok(text="")
    try:
        return _ok(text=ai.translate_rules(b.get("text", ""), config.get("lang") or "lv"))
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_sort_undo(_):
    try:
        return _ok(**sorter.undo())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_sort_last(_):
    d = sorter.last()
    return _ok(last={"root": d["root"], "time": d["time"],
                     "count": sum(1 for m in d["moves"] if m.get("main"))} if d else None)


# --- Claude konts
def api_auth_status(_):
    a = ai.auth_status()
    ai._status_cache["claude_cli"] = (time.time(), bool(a.get("loggedIn")))
    return _ok(auth=a, provider=ai.active_provider(), primary=ai.providers()[0])


def api_auth_login(_):
    try:
        return _ok(**ai.login())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_claude_install(_):
    try:
        return _ok(**ai.install_claude())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_auth_logout(_):
    try:
        ai.logout()
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return _ok(auth=ai.auth_status())


def api_jobs(b):
    return _ok(jobs=jobs.snapshot(b.get("id")), provider=ai.active_provider())


def api_cancel(b):
    jobs.cancel(b["id"])
    return _ok()


def api_is_editorial(b):
    return _ok(editorial=ai.is_editorial(b["path"]))


def api_templates(_):
    return _ok(templates=store.list_templates())


def api_template_save(b):
    return _ok(template=store.save_template(b), templates=store.list_templates())


def api_template_delete(b):
    store.delete_template(b["id"])
    return _ok(templates=store.list_templates())


def api_template_import(b):
    n = store.import_templates(b["text"])
    return _ok(count=n, templates=store.list_templates())


def api_history(_):
    return _ok(history=store.history().data)


def api_history_clear(_):
    h = store.history()
    with h.lock:
        h.data = []
        h.save()
    return _ok(history=[])


def api_exiftool_install(_):
    if state["installing"]:
        return _ok(installing=True)

    def run():
        state["installing"] = True
        state["install_msg"] = T("downloading")
        try:
            exif.ET.stop()
            state["install_msg"] = exif.install_exiftool()
        except Exception as e:
            state["install_msg"] = T("error") + ": " + str(e)
        finally:
            state["installing"] = False

    threading.Thread(target=run, daemon=True).start()
    return _ok(installing=True)


def api_claude_info(_):
    return _ok(info=ai.claude_info())


def api_ai_roles(_):
    """"Kurš AI ko dara": Vārdotāja darbi un pašreizējā secība (arī, ja lietotājs vēl nav iestatījis)."""
    return _ok(jobs=list(ai.JOBS), roles=ai.default_roles(), custom=ai.roles_set(),
               usable=list(ai.CORE_NAME.values()))


def api_ai_test(_):
    try:
        return _ok(message=ai.test_connection())
    except Exception as e:
        return {"ok": False, "error": str(e)}


def api_reveal(b):
    p = b["path"]
    try:
        if config.IS_WIN:
            subprocess.Popen(["explorer", "/select,", os.path.normpath(p)])
        elif config.IS_MAC:
            subprocess.Popen(["open", "-R", p])
        else:
            subprocess.Popen(["xdg-open", os.path.dirname(p)])
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return _ok()


def api_open_data_dir(_):
    """Iestatījumi → Cits → "Atvērt datu mapi" (žurnāli log*.txt, iestatījumi) — kā Analītiķī (core reveal)."""
    return core_server._api_reveal({})


def api_clear_cache(_):
    return _ok(count=files.clear_thumb_cache())


API = {k[4:]: v for k, v in globals().items() if k.startswith("api_")}


# --------------------------------------------------------------------------- serveris (core/)

def _get_thumb(q: dict, size_default: int | None):
    if q.get("t") != TOKEN:
        return 403, b"forbidden", "text/plain", None
    try:
        size = int(q.get("s", 300)) if size_default is None else size_default
        data = files.thumbnail(q["path"], min(max(size, 64), 2000))
        return 200, data, "image/jpeg", {"Cache-Control": "private, max-age=86400"}
    except Exception:
        return 404, b"", "image/jpeg", None


def start(port: int = 0):
    core_server.register_get({"/thumb": lambda q: _get_thumb(q, None), "/preview": lambda q: _get_thumb(q, 1600)})
    core_server.ON_SHUTDOWN.append(exif.ET.stop)
    ai.migrate_keys()                            # vecās API atslēgas → drošā glabātuve (0.9.0-test3)
    from core import backup
    from . import appdef
    backup.set_hooks(after_restore=appdef.after_restore)
    backup.start_scheduler(jobs.busy)            # automātiskā rezerves kopija pēc termiņa (noteikumi §5)
    from core import sync
    sync.start()                                 # sinhronizācija starp datoriem (ja ieslēgta; dati §7a)
    from core import manifests_drive
    manifests_drive.start()                      # neaugšupielādētie manifesti no iepriekšējās reizes (test11)
    threading.Thread(target=lambda: (time.sleep(20), submit.fix_ed_placement(), manifest.migrate()),
                     daemon=True).start()        # vienreizēji darbi (test17, test18)
    srv, url = core_server.start(port)
    core_server.register(API)                    # core.start() reģistrē kopīgos vēlreiz — Vārdotāja versijas virsū
    return srv, url


def shutdown():
    core_server.shutdown()


def idle_watch(minutes: int = 5):
    core_server.idle_watch(minutes)
