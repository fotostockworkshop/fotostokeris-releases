"""Vārdotājs — fotogrāfiju metadatu (virsraksts, apraksts, atslēgvārdi) rīks fotostokiem."""

APP_NAME = "Vārdotājs"
VERSION = "0.9.0-test15"
