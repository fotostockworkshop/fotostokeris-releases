/* Magnific (bij. Freepik): contributor.magnific.com/xhr — ienākumi (EUR) un lejupielādes pa dienām */
async function collect() {
  if (location.hostname !== "contributor.magnific.com") throw LOGIN;
  const XH = { "X-Requested-With": "XMLHttpRequest" };
  const user = await getj("/xhr/user", XH);
  if (!user || user.success === false) throw LOGIN;
  const S = (fmt, a, b) => getj(`/xhr/stats?format=${fmt}&license=all&typeFile=all&dateStart=${a}&dateEnd=${b}`, XH);
  const ser = (j, re) => ((((j || {}).data || {}).series || []).find((s) => re.test(s.name)) || {}).data || [];

  /* mēneši ar ienākumiem */
  say("mēneši", 3);
  const mon = await S("monthly", "2015-01-01", today);
  const cats = ((mon || {}).data || {}).categories || [];
  const rev = ser(mon, /revenue/i);
  const months = [];
  for (let i = 0; i < rev.length; i++) {
    let m = cats[i] ? (String(cats[i]).match(/(\d{4})-(\d{2})/) || [])[0] : "";
    if (!m) {                                       // bez etiķetēm: pēdējā vērtība = šis mēnesis
      const d = new Date(+today.slice(0, 4), +today.slice(5, 7) - 1 - (rev.length - 1 - i), 15);
      m = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    }
    if (+rev[i] > 0) months.push(m);
  }
  const cur = today.slice(0, 7);
  if (!months.includes(cur)) months.push(cur);
  let list = months.sort().reverse();
  if (OPTS.mode !== "full") list = list.filter((m) => m >= OPTS.since.slice(0, 7));

  for (let i = 0; i < list.length; i++) {
    const m = list[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(m, 5 + Math.round((i / list.length) * 90));
    const end = monthEnd(y, mo) < today ? monthEnd(y, mo) : today;
    const d = await S("daily", `${m}-01`, end);
    const dc = ((d || {}).data || {}).categories || [];
    const r = ser(d, /revenue/i), prem = ser(d, /premium/i), free = ser(d, /free/i);
    const days = dc.map((day, k) => ({ day: pdate(day), cat: "premium", e: +r[k] || 0, n: (+prem[k] || 0) + (+free[k] || 0) }))
      .filter((x) => x.day);
    await send("days", { start: `${m}-01`, end, currency: "EUR", days });
    await sleep(200);
  }
  await portfolioSafe([
    ["user", async () => { const n = countKey(user, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: user atslēgas: " + keysOf(user && (user.data || user))); return n; }],
    ["resources/data", () => portJson("/xhr/resources/data", XH)],
    ["resources", () => portJson("/xhr/resources?page=1&limit=1", XH)],
    ["stats/resources", () => portJson("/xhr/stats/resources", XH)],
  ]);
  return { months: list.length };
}
