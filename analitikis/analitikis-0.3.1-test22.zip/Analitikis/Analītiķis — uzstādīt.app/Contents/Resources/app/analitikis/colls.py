"""Kolekcijas un Microstockr imports (Analītiķis 0.3.0, 4. daļa; noteikumi §8).

Kolekcija = lietotāja bilžu grupa (sērija, tēma). Bilde kolekcijā = aģentūras vienums; kolekcijā skaitās arī tās
pašas bildes kopijas citās aģentūrās (assets.gid) — lietotājs 2026-10-30: "jā". Vienā kolekcijā var pievienot
vairākas bildes reizē; viena bilde var būt vairākās kolekcijās.

Microstockr imports (lietotāja .bak — zip ar SQLite microstockr.db): lasām TIKAI tabulas collection,
collection_media, media, multiple, sale. Paroles un žetonus (account, agency.username/password/…Token) — nekad.
Pārdošanas — tikai periodam, par kuru aģentūras pašas dati vēl nav (batch 'microstockr'; atkārtots imports
aizstāj iepriekšējo).
"""
from __future__ import annotations

import datetime as dt
import io
import sqlite3
import tempfile
import zipfile
from pathlib import Path

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS collections(id INTEGER PRIMARY KEY, name TEXT, created_at TEXT, source TEXT);
CREATE TABLE IF NOT EXISTS collection_items(collection_id INT, agency TEXT, agency_item_id TEXT, added_at TEXT,
  PRIMARY KEY(collection_id, agency, agency_item_id));
CREATE INDEX IF NOT EXISTS coll_items_item ON collection_items(agency, agency_item_id);
-- Microstockr "viena bilde vairākās aģentūrās" (multiple.tag) — papildu sasaiste bilžu grupām (db.regroup)
CREATE TABLE IF NOT EXISTS mr_link(agency TEXT, agency_item_id TEXT, tag TEXT, PRIMARY KEY(agency, agency_item_id));
-- Microstockr sīktēla nospiedums (media.thumbHash, 64 biti) — bilžu apvienošanai bez lejupielādes (lookalike.py)
CREATE TABLE IF NOT EXISTS mr_hash(agency TEXT, agency_item_id TEXT, h TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE INDEX IF NOT EXISTS mr_link_tag ON mr_link(tag);
"""

# Microstockr agency.id → mūsu aģentūra (PhotoDune = Envato Market; EyeEm, Mostphotos, Yayimages — arhīvs)
MR_AGENCY = {1: "shutterstock", 2: "istock", 3: "adobe", 4: "dreamstime", 5: "bigstock", 6: "123rf",
             7: "depositphotos", 8: "pond5", 10: "envato_market", 14: "alamy", 15: "pixta", 16: "yayimages",
             18: "mostphotos", 19: "eyeem", 25: "zoonar"}
BATCH = "microstockr"


def ensure(c=None) -> None:
    (c or db.conn()).executescript(SCHEMA)


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


# --------------------------------------------------------------------------- kolekcijas

def _groups_cte() -> str:
    """cg(cid, g): kolekcijas bilžu grupas (gid vai pats vienums)."""
    return """cg AS (SELECT DISTINCT ci.collection_id cid, COALESCE(a.gid, ci.agency||'|'||ci.agency_item_id) g
                    FROM collection_items ci LEFT JOIN assets a ON a.agency=ci.agency AND a.agency_item_id=ci.agency_item_id)"""


def listing() -> list[dict]:
    """Kolekcijas ar bilžu skaitu un ienākumiem visā vēsturē (visas aģentūras, visas kopijas)."""
    db.ensure_groups()
    with db._lock:
        ensure()
    cols = [dict(r) for r in db.q("SELECT * FROM collections ORDER BY name COLLATE NOCASE")]
    if not cols:
        return []
    src = f"""SELECT agency, agency_item_id, MAX(e) e, MAX(n) n FROM (
                {db.TOTALS_SQL.format(oth=" AND kind!='other'")}
                UNION ALL
                SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE kind!='other' GROUP BY agency, agency_item_id)
              GROUP BY agency, agency_item_id"""
    stats = {r["cid"]: r for r in db.q(f"""WITH {_groups_cte()}, t AS ({src})
        SELECT cg.cid, SUM(t.e) e, SUM(t.n) n FROM t JOIN assets a ON a.agency=t.agency AND a.agency_item_id=t.agency_item_id
        JOIN cg ON cg.g = COALESCE(a.gid, t.agency||'|'||t.agency_item_id) GROUP BY cg.cid""")}
    files = {r["cid"]: r["n"] for r in db.q(f"WITH {_groups_cte()} SELECT cid, COUNT(*) n FROM cg GROUP BY cid")}
    thumbs = {}
    for r in db.q("""SELECT ci.collection_id cid, a.thumb FROM collection_items ci JOIN assets a
                     ON a.agency=ci.agency AND a.agency_item_id=ci.agency_item_id WHERE a.thumb LIKE 'http%'"""):
        thumbs.setdefault(r["cid"], [])
        if len(thumbs[r["cid"]]) < 4:
            thumbs[r["cid"]].append(r["thumb"])
    for c in cols:
        s = stats.get(c["id"])
        c.update(e=round((s["e"] if s else 0) or 0, 2), n=int((s["n"] if s else 0) or 0), files=files.get(c["id"], 0),
                 thumbs=thumbs.get(c["id"], []))
    return cols


def _fill_cm(cn, cid: int) -> None:
    """Pagaidu tabula _cm: kolekcijas vienumi ar visām kopijām citās aģentūrās (ātrai apvienošanai)."""
    cn.execute("CREATE TEMP TABLE IF NOT EXISTS _cm(agency TEXT, agency_item_id TEXT, g TEXT, PRIMARY KEY(agency, agency_item_id))")
    cn.execute("DELETE FROM _cm")
    cn.execute(f"""INSERT OR IGNORE INTO _cm SELECT a.agency, a.agency_item_id, a.gid FROM assets a
                   WHERE a.gid IN (SELECT g FROM ({"WITH " + _groups_cte() + " SELECT g FROM cg WHERE cid=?"}))""", (cid,))
    cn.execute("""INSERT OR IGNORE INTO _cm SELECT ci.agency, ci.agency_item_id, COALESCE(a.gid, ci.agency||'|'||ci.agency_item_id)
                  FROM collection_items ci LEFT JOIN assets a ON a.agency=ci.agency AND a.agency_item_id=ci.agency_item_id
                  WHERE ci.collection_id=?""", (cid,))
    # KĻŪDA test38–43: bez commit galvenais savienojums palika atvērtā transakcijā → neredzēja sinhronizācijas procesa
    # jaunos datus ("Atjaunots pirms 34 min", lietotājs 2026-10-30). Pagaidu tabulas saturs pēc commit saglabājas.
    cn.commit()


def _src(period: str) -> tuple[str, list]:
    """Vienuma ienākumi un lejupielādes periodā (visa vēsture — ar kopsummām, kā Labākajās)."""
    rng = db._period(period or "all")
    if rng is None:
        return f"""SELECT agency, agency_item_id, MAX(e) e, MAX(n) n FROM (
                    {db.TOTALS_SQL.format(oth=" AND kind!='other'")}
                    UNION ALL
                    SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE kind!='other' GROUP BY agency, agency_item_id)
                  GROUP BY agency, agency_item_id""", []
    return ("SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE kind!='other' AND day BETWEEN ? AND ?"
            " GROUP BY agency, agency_item_id"), list(rng)


def view(cid: int, period: str = "all") -> dict:
    """Kolekcijas pārskats periodā (kā Microstockr kolekcijā, bez grafika): pa aģentūrām (arī ar 0), kopā, RPI, RPD."""
    c = next((x for x in listing() if x["id"] == cid), None)
    if not c:
        return {}
    src, args = _src(period)
    with db._lock:
        cn = db.conn()
        _fill_cm(cn, cid)
        rows = cn.execute(f"""SELECT m.agency, m.g, COALESCE(t.e, 0) e, COALESCE(t.n, 0) n FROM _cm m
                              LEFT JOIN ({src}) t ON t.agency=m.agency AND t.agency_item_id=m.agency_item_id""", args).fetchall()
        first = cn.execute("""SELECT MIN(s.day) d FROM _cm m JOIN sales s ON s.agency=m.agency
                              AND s.agency_item_id=m.agency_item_id WHERE s.kind!='other'""").fetchone()
    by, sold = {}, set()
    for r in rows:
        x = by.setdefault(r["agency"], {"agency": r["agency"], "e": 0.0, "n": 0, "items": 0})
        if r["e"] > 0 or r["n"] > 0:
            x["e"] += r["e"]
            x["n"] += r["n"]
            x["items"] += 1
            sold.add(r["g"])
    by_ag = sorted(({**v, "e": round(v["e"], 2)} for v in by.values()), key=lambda v: (-v["e"], -v["n"]))
    e = round(sum(v["e"] for v in by.values()), 2)
    n = sum(v["n"] for v in by.values())
    return {**c, "period": period, "by_agency": by_ag, "pe": e, "pn": n, "sold": len(sold),
            # RPI kā Microstockr: ienākumi uz pārdoto bildi periodā
            "rpi": round(e / len(sold), 2) if sold else 0, "rpd": round(e / n, 2) if n else 0,
            "first": first["d"] if first else None}


def items(cid: int, period: str = "all", sort: str = "e", offset: int = 0, limit: int = 60) -> dict:
    """Kolekcijas bildes (grupas) ar ienākumiem periodā — arī tās, kam periodā pārdošanu nav (kā Microstockr)."""
    src, args = _src(period)
    order = "n DESC, e DESC" if sort == "n" else "e DESC, n DESC"
    with db._lock:
        cn = db.conn()
        _fill_cm(cn, cid)
        sql = f"""SELECT m.g, SUM(COALESCE(t.e,0)) e, SUM(COALESCE(t.n,0)) n,
                         GROUP_CONCAT(m.agency||'|'||m.agency_item_id||'|'||ROUND(COALESCE(t.e,0),2)||'|'||COALESCE(t.n,0), ';') members,
                         MAX(a.title) title, MAX(a.thumb) thumb, MAX(a.filename) filename
                  FROM _cm m LEFT JOIN ({src}) t ON t.agency=m.agency AND t.agency_item_id=m.agency_item_id
                  LEFT JOIN assets a ON a.agency=m.agency AND a.agency_item_id=m.agency_item_id
                  GROUP BY m.g"""
        total = cn.execute(f"SELECT COUNT(*) FROM ({sql})", args).fetchone()[0]
        rows = cn.execute(f"{sql} ORDER BY {order}, title LIMIT ? OFFSET ?", args + [limit, offset]).fetchall()
    out = []
    for r in rows:
        mem = []
        for part in (r["members"] or "").split(";"):
            bits = part.rsplit("|", 2)
            if len(bits) == 3 and "|" in bits[0]:
                ag, iid = bits[0].split("|", 1)
                mem.append({"agency": ag, "agency_item_id": iid, "e": db.num(bits[1]), "n": int(db.num(bits[2]))})
        mem.sort(key=lambda m: (-m["e"], -m["n"]))
        thumb = r["thumb"] or db._thumb_for(r["g"])
        out.append({"key": r["g"], "e": round(r["e"] or 0, 2), "n": int(r["n"] or 0), "title": r["title"], "thumb": thumb,
                    "alt": db._thumb_for(r["g"], thumb) if thumb else None, "filename": r["filename"], "members": mem,
                    "counts": any(db.AGENCIES.get(m["agency"], {}).get("counts") for m in mem)})
    return {"rows": out, "count": total, "offset": offset}


def create(name: str, source: str = "user") -> int:
    name = (name or "").strip()[:80]
    if not name:
        raise ValueError("name")
    with db._lock:
        c = db.conn()
        ensure(c)
        old = c.execute("SELECT id FROM collections WHERE name=? COLLATE NOCASE", (name,)).fetchone()
        if old:
            return old["id"]
        cur = c.execute("INSERT INTO collections(name, created_at, source) VALUES(?,?,?)", (name, _now(), source))
        c.commit()
        return cur.lastrowid


def rename(cid: int, name: str) -> None:
    name = (name or "").strip()[:80]
    if not name:
        raise ValueError("name")
    with db._lock:
        c = db.conn()
        c.execute("UPDATE collections SET name=? WHERE id=?", (name, cid))
        c.commit()


def delete(cid: int) -> None:
    with db._lock:
        c = db.conn()
        c.execute("DELETE FROM collection_items WHERE collection_id=?", (cid,))
        c.execute("DELETE FROM collections WHERE id=?", (cid,))
        c.commit()


TWIN_DIST = 4      # dHash attālums: "precīzi tā pati bilde" (stingrāk nekā apvienošanā, lookalike.MAX_DIST)


def _twins(items: list[dict]) -> list[tuple[str, str]]:
    """0.3.1-test20 (lietotājs 2026-11-08): pievienojot bildi kolekcijai, tajā nonāk arī precīzi tāda pati bilde —
    arī tās pašas aģentūras otrs ieraksts (Envato dublikāti, sērijas ar vienādu virsrakstu, vēl neapvienotas kopijas).
    Kandidāti — tas pats virsraksta sākums (lookalike.bucket); salīdzina sīktēlu dHash (kešs thumb_hash; trūkstošos lejupielādē)."""
    from . import lookalike
    with db._lock:
        c = db.conn()
        lookalike.ensure(c)
        base, cand = {}, {}
        for it in items:
            ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
            a = c.execute("SELECT agency, agency_item_id, thumb, mkey, gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
            if not a:
                continue
            rows = [a] + (list(c.execute("SELECT agency, agency_item_id, thumb, mkey, gid FROM assets WHERE gid=?", (a["gid"],))) if a["gid"] else [])
            for r in rows:
                base[(r["agency"], r["agency_item_id"])] = r["thumb"]
            bk = lookalike.bucket(a["mkey"])
            if bk or a["mkey"]:                       # īsiem virsrakstiem (< 5 vārdi) — tieši tas pats virsraksts
                sql, arg = (("mkey LIKE ?", bk.replace("%", "").replace("_", "") + "%") if bk else ("mkey=?", a["mkey"]))
                for r in c.execute(f"SELECT agency, agency_item_id, thumb FROM assets WHERE {sql} AND thumb LIKE 'http%' LIMIT 120", (arg,)):
                    k = (r["agency"], r["agency_item_id"])
                    if k not in base:
                        cand[k] = r["thumb"]
        if not cand:
            return []
        known = {(r[0], r[1]): (r[2], r[3]) for r in c.execute("SELECT agency, agency_item_id, thumb, h FROM thumb_hash")
                 if (r[0], r[1]) in base or (r[0], r[1]) in cand}

    def h_of(k, url):
        if not url or not str(url).startswith("http"):
            return None
        th = known.get(k)
        if th and th[0] == url and th[1]:
            return th[1]
        data = lookalike._fetch(url)
        h = lookalike.dhash(data) if data else None
        with db._lock:
            c2 = db.conn()
            c2.execute("INSERT OR REPLACE INTO thumb_hash VALUES(?,?,?,?)", (k[0], k[1], url, h or ""))
            c2.commit()
        return h

    bh = [h for h in (h_of(k, u) for k, u in base.items()) if h]
    if not bh:
        return []
    out = []
    for k, u in cand.items():
        h = h_of(k, u)
        if h and min(lookalike.dist(h, x) for x in bh) <= TWIN_DIST:
            out.append(k)
    return out


def add(cid: int, items: list[dict]) -> int:
    """items = [{agency, agency_item_id}] — pievieno arī tās pašas bildes kopijas citās aģentūrās."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        n = 0
        for it in items:
            ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
            if not ag or not iid:
                continue
            a = c.execute("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
            mem = [(ag, iid)]
            if a and a["gid"]:
                mem = [(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM assets WHERE gid=?", (a["gid"],))] or mem
            for m in mem:
                n += c.execute("INSERT OR IGNORE INTO collection_items VALUES(?,?,?,?)", (cid, m[0], m[1], _now())).rowcount
        c.commit()
    try:                                              # precīzi tādas pašas bildes (arī citi ieraksti) — tajā pašā kolekcijā
        tw = _twins(items)
    except Exception as e:
        print("kolekcija: dvīņi —", str(e)[:120]); tw = []
    if tw:
        with db._lock:
            c = db.conn()
            for ag, iid in tw:
                n += c.execute("INSERT OR IGNORE INTO collection_items VALUES(?,?,?,?)", (cid, ag, iid, _now())).rowcount
            c.commit()
        print(f"kolekcija: pievienotas arī {len(tw)} tādas pašas bildes")
    return n


def remove(cid: int, items: list[dict]) -> int:
    """Noņem bildi (un visas tās kopijas) no kolekcijas."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        n = 0
        for it in items:
            ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
            a = c.execute("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
            mem = [(ag, iid)]
            if a and a["gid"]:
                mem += [(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM assets WHERE gid=?", (a["gid"],))]
            for m in set(mem):
                n += c.execute("DELETE FROM collection_items WHERE collection_id=? AND agency=? AND agency_item_id=?",
                               (cid, m[0], m[1])).rowcount
        c.commit()
    try:
        tw = _twins(items)
    except Exception:
        tw = []
    if tw:
        with db._lock:
            c = db.conn()
            for ag, iid in tw:
                n += c.execute("DELETE FROM collection_items WHERE collection_id=? AND agency=? AND agency_item_id=?", (cid, ag, iid)).rowcount
            c.commit()
    return n


def of_item(agency: str, agency_item_id: str) -> list[dict]:
    """Kurās kolekcijās ir šī bilde (vai tās kopija)."""
    db.ensure_groups()
    a = db.q1("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (agency, agency_item_id))
    g = (a["gid"] if a and a["gid"] else f"{agency}|{agency_item_id}")
    return [dict(r) for r in db.q(f"WITH {_groups_cte()} SELECT c.id, c.name FROM cg JOIN collections c ON c.id=cg.cid WHERE cg.g=? ORDER BY c.name", (g,))]


def names_map(keys: list[tuple]) -> dict:
    """{(aģentūra, id): [kolekciju nosaukumi]} daudzām bildēm vienā reizē (uznirstošajam tekstam, test52)."""
    keys = [(a, str(i)) for a, i in keys if a and i]
    if not keys:
        return {}
    db.ensure_groups()
    gid = {}
    for a, i in set(keys):
        r = db.q1("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (a, i))
        gid[(a, i)] = r["gid"] if r and r["gid"] else f"{a}|{i}"
    gs = sorted(set(gid.values()))
    by: dict = {}
    for k in range(0, len(gs), 400):
        part = gs[k:k + 400]
        for r in db.q(f"WITH {_groups_cte()} SELECT cg.g, c.name FROM cg JOIN collections c ON c.id=cg.cid "
                      f"WHERE cg.g IN ({','.join('?' * len(part))}) ORDER BY c.name", part):
            by.setdefault(r["g"], []).append(r["name"])
    return {k: by.get(g, []) for k, g in gid.items()}


def count_in(items: list[dict]) -> dict:
    """{kolekcijas id: cik no šīm bildēm tajā jau ir} — konteksta izvēlnei (zaļš = visas, gaišāk = daļa)."""
    db.ensure_groups()
    out: dict = {}
    for it in items or []:
        for c in of_item(str(it.get("agency") or ""), str(it.get("agency_item_id") or "")):
            out[c["id"]] = out.get(c["id"], 0) + 1
    return out


def filter_sql(gkey: str) -> str:
    """db.best(): nosacījums "grupa ir kolekcijā ?"."""
    return f"""{gkey} IN (SELECT COALESCE(a2.gid, ci.agency||'|'||ci.agency_item_id) FROM collection_items ci
               LEFT JOIN assets a2 ON a2.agency=ci.agency AND a2.agency_item_id=ci.agency_item_id WHERE ci.collection_id=?)"""


# --------------------------------------------------------------------------- Microstockr imports

def _open_bak(data: bytes) -> tuple[sqlite3.Connection, Path]:
    """.bak (zip ar microstockr.db) → pagaidu SQLite savienojums (tikai lasīšanai)."""
    tmp = Path(tempfile.mkdtemp(prefix="mr_"))
    p = tmp / "microstockr.db"
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            name = next((n for n in z.namelist() if n.lower().endswith("microstockr.db")), None)
            if not name:
                raise ValueError("bak_nodb")
            p.write_bytes(z.read(name))
    except zipfile.BadZipFile:
        if data[:16] != b"SQLite format 3\x00":
            raise ValueError("bak_bad")
        p.write_bytes(data)
    m = sqlite3.connect(f"file:{p}?mode=ro", uri=True)
    m.row_factory = sqlite3.Row
    need = {"collection", "collection_media", "media", "multiple", "sale"}
    have = {r[0] for r in m.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not need <= have:
        m.close()
        raise ValueError("bak_bad")
    return m, tmp


def _cleanup(m, tmp: Path) -> None:
    try:
        m.close()
    except Exception:
        pass
    for f in tmp.glob("*"):
        try:
            f.unlink()
        except OSError:
            pass
    try:
        tmp.rmdir()
    except OSError:
        pass


def _ymd(v) -> str:
    s = str(v or "")
    return f"{s[:4]}-{s[4:6]}-{s[6:8]}" if len(s) == 8 and s.isdigit() else ""


def _plan(m: sqlite3.Connection) -> dict:
    """Ko importēs: kolekcijas, bildes, pārdošanas pa aģentūrām (tikai pirms mūsu pašu datiem)."""
    first = {}
    for r in db.q("SELECT agency, MIN(day) d FROM sales WHERE COALESCE(batch,'')!=? GROUP BY agency", (BATCH,)):
        first[r["agency"]] = r["d"]
    per = {}
    rows = m.execute("""SELECT md.agencyId ag, s.date d, s.earnings e FROM sale s JOIN media md ON md.id=s.mediaId""").fetchall()
    for r in rows:
        ag = MR_AGENCY.get(r["ag"])
        if not ag:
            continue
        day = _ymd(r["d"])
        x = per.setdefault(ag, {"agency": ag, "all": 0, "take": 0, "e": 0.0, "from": None, "to": None, "ours_from": first.get(ag)})
        x["all"] += 1
        if not day or (first.get(ag) and day >= first[ag]):
            continue
        x["take"] += 1
        x["e"] += float(r["e"] or 0)
        x["from"] = min(x["from"] or day, day)
        x["to"] = max(x["to"] or day, day)
    cols = [{"name": r["name"], "files": r["files"]} for r in m.execute("SELECT name, files FROM collection ORDER BY name")]
    return {"collections": cols, "media": m.execute("SELECT COUNT(*) FROM media").fetchone()[0],
            "agencies": sorted((dict(v, e=round(v["e"], 2)) for v in per.values()), key=lambda v: -v["take"])}


def preview(data: bytes) -> dict:
    m, tmp = _open_bak(data)
    try:
        return _plan(m)
    finally:
        _cleanup(m, tmp)


def do_import(data: bytes) -> dict:
    m, tmp = _open_bak(data)
    try:
        plan = _plan(m)
        take_before = {a["agency"]: a["ours_from"] for a in plan["agencies"]}
        with db._lock:
            c = db.conn()
            ensure(c)
            # 1) bildes: nosaukums, sīktēls, saite — tikai trūkstošo papildina (aģentūras pašas dati svarīgāki)
            n_media = 0
            for r in m.execute("SELECT id, identifier, agencyId, name, url, thumb FROM media"):
                ag = MR_AGENCY.get(r["agencyId"])
                iid = str(r["identifier"] or "")
                if not ag or not iid or iid in ("0", "1"):
                    continue
                old = c.execute("SELECT title, thumb, url FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
                if old and old["title"] and old["thumb"] and old["url"]:
                    continue
                db._upsert_asset(c, ag, iid, r["name"] or None, r["thumb"] or None, None, r["url"] or None)
                n_media += 1
            # 2) "viena bilde vairākās aģentūrās" (tag = Microstockr grupa, var saturēt vairākus vienas sērijas kadrus)
            #    + sīktēla nospiedums (to salīdzina lookalike.py)
            c.execute("DELETE FROM mr_hash")
            for r in m.execute("SELECT identifier, agencyId, thumbHash FROM media WHERE thumbHash IS NOT NULL AND thumbHash != ''"):
                ag = MR_AGENCY.get(r["agencyId"])
                h = str(r["thumbHash"] or "").lower()
                if ag and len(h) == 16 and all(ch in "0123456789abcdef" for ch in h) and str(r["identifier"]) not in ("0", "1"):
                    c.execute("INSERT OR REPLACE INTO mr_hash VALUES(?,?,?)", (ag, str(r["identifier"]), h))
            c.execute("DELETE FROM mr_link")
            for r in m.execute("SELECT identifier, agencyId, tag FROM multiple WHERE tag IS NOT NULL"):
                ag = MR_AGENCY.get(r["agencyId"])
                if ag and r["identifier"] not in (None, "", 0, 1, "1"):
                    c.execute("INSERT OR REPLACE INTO mr_link VALUES(?,?,?)", (ag, str(r["identifier"]), str(r["tag"])))
            # 3) pārdošanas — tikai pirms mūsu pašu pirmās pārdošanas katrā aģentūrā
            c.execute("DELETE FROM sales WHERE batch=?", (BATCH,))
            n_sales, touched, seq = 0, set(), {}
            for r in m.execute("""SELECT md.agencyId ag, md.identifier iid, md.name nm, s.date d, s.earnings e, s.type ty
                                  FROM sale s JOIN media md ON md.id=s.mediaId"""):
                ag = MR_AGENCY.get(r["ag"])
                day = _ymd(r["d"])
                if not ag or not day or (take_before.get(ag) and day >= take_before[ag]):
                    continue
                iid = str(r["iid"] or "")
                other = iid in ("", "0", "1")          # "AI Generator", "Additional Revenue" u.c. — nav bilde
                if other:
                    iid = "other-mr"
                    db._upsert_asset(c, ag, iid, f"{db.AGENCIES[ag]['name']} — citi ienākumi (Microstockr)", None, None, None, "other")
                amt = float(r["e"] or 0)
                k = (ag, iid, day)                 # vairākas vienas bildes pārdošanas dienā (Adobe unikālā atslēga)
                seq[k] = seq.get(k, -1) + 1
                ts = f"{day}T00:{seq[k] // 60:02d}:{seq[k] % 60:02d}"
                c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,currency,cnt,kind,license,country,raw,batch)"
                          " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                          (ag, day, ts, iid, amt, amt, "USD", 0 if other else 1, "other" if other else "sale",
                           "", "", f'{{"mr_type": {int(r["ty"] or 0)}}}', BATCH))
                n_sales += 1
                touched.add((ag, day))
            # dienu kopsummas: tikai dienām, par kurām aģentūrai vēl nav nekā (Shutterstock u.c. — savas kopsummas paliek)
            months = {}
            for ag, day in touched:
                if c.execute("SELECT 1 FROM daily WHERE agency=? AND day=? AND cat!='microstockr' LIMIT 1", (ag, day)).fetchone():
                    continue
                c.execute("DELETE FROM daily WHERE agency=? AND day=? AND cat='microstockr'", (ag, day))
                c.execute("""INSERT INTO daily SELECT agency, day, 'microstockr', SUM(amount_usd), SUM(cnt) FROM sales
                             WHERE agency=? AND day=? AND batch=? GROUP BY agency, day""", (ag, day, BATCH))
                months.setdefault(ag, set()).add(day[:7])
            for ag, ms in months.items():
                db._rebuild_monthly(c, ag, ms)
            for ag in {a for a, _ in touched}:
                if ag != "shutterstock":           # Shutterstock kopsummas nāk no API (TOTALS_SQL)
                    db._derive_totals(c, ag)
            # 4) kolekcijas (pēc nosaukuma; esošās papildina)
            n_items = 0
            names = {r["id"]: r["name"] for r in m.execute("SELECT id, name FROM collection")}
            ids = {}
            for mid, name in names.items():
                old = c.execute("SELECT id FROM collections WHERE name=? COLLATE NOCASE", (name,)).fetchone()
                ids[mid] = old["id"] if old else c.execute("INSERT INTO collections(name, created_at, source) VALUES(?,?,?)",
                                                           (name, _now(), "microstockr")).lastrowid
            for r in m.execute("SELECT collectionId, identifier, agencyId FROM collection_media"):
                ag = MR_AGENCY.get(r["agencyId"])
                if not ag or r["collectionId"] not in ids:
                    continue
                n_items += c.execute("INSERT OR IGNORE INTO collection_items VALUES(?,?,?,?)",
                                     (ids[r["collectionId"]], ag, str(r["identifier"]), _now())).rowcount
            c.commit()
        from . import lookalike
        lookalike._link()                    # apvienošana pēc Microstockr sīktēlu nospiedumiem
        db.regroup()
        db.set_state("_import", "microstockr", {"at": _now(), "sales": n_sales, "media": n_media, "items": n_items})
        print(f"Microstockr imports: pārdošanas {n_sales}, bildes {n_media}, kolekciju piesaistes {n_items}")
        return {"sales": n_sales, "media": n_media, "collections": len(ids), "items": n_items, "plan": plan}
    finally:
        _cleanup(m, tmp)
