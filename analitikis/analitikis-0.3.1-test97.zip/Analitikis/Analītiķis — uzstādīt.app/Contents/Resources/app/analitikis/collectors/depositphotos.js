/* Depositphotos: depositphotos.com/sales.html — tabula ar katru pārdošanu un oriģinālo faila nosaukumu */
async function collect() {
  if (!/(^|\.)depositphotos\.com$/.test(location.hostname)) throw LOGIN;

  function parse(doc) {
    for (const t of doc.querySelectorAll("table")) {
      const head = [...t.querySelectorAll("tr")].find((tr) => /File ID/i.test(txt(tr)) && /Net/i.test(txt(tr)));
      if (!head) continue;
      const h = [...head.cells].map((c) => txt(c).toLowerCase());
      const ix = (re) => h.findIndex((x) => re.test(x));
      const c = { id: ix(/file id/), fn: ix(/filename/), date: ix(/^date/), size: ix(/size/), method: ix(/method/), net: ix(/net/) };
      const out = [];
      for (const tr of t.querySelectorAll("tr")) {
        if (tr === head) continue;
        const v = [...tr.cells];
        if (v.length < 5) continue;
        const day = pdate(txt(v[c.date]));
        if (!day) continue;
        const img = tr.querySelector("img");
        const id = txt(v[c.id]);
        const fn = txt(v[c.fn]);
        /* "RSM Subscription" — Revenue Share Program: abonementu ieņēmumu daļa (mēneša maksājums, nevis bilde) */
        if (/^RSM\b/i.test(fn) || (/subscription/i.test(fn) && !/\.\w{3,4}$/.test(fn))) {
          out.push({ day, id: "other-rsm", title: "Depositphotos — RSM (abonementu ieņēmumu daļa)", amount: money(txt(v[c.net])),
            cnt: 0, kind: "other", license: fn });
          continue;
        }
        out.push({ day, id, filename: fn, amount: money(txt(v[c.net])), cnt: 1, kind: "sale",
          license: [txt(v[c.method]), txt(v[c.size])].filter(Boolean).join(" · "),
          thumb: img ? (img.getAttribute("src") || img.getAttribute("data-src") || "").replace(/^\/\//, "https://").replace("/i/110/", "/i/450/") : "",
          url: id ? `https://depositphotos.com/${id}/stock-photo.html` : "" });
      }
      return out;
    }
    return null;
  }

  B.log(AG, "lapa atvērta: " + location.host + location.pathname + " — lasu /sales.html");   // test39: diagnostika (iestrēgst)
  const doc = await getdoc("/sales.html");
  let first = parse(doc);
  B.log(AG, `pārdošanu lapa: ${first ? first.length + " rindas" : "tabula nav"}`);
  if (!first) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Depositphotos: pārdošanu tabula nav atrasta");
  }
  const bm = txt(doc.body).match(/Balance:\s*\$\s*([\d.,]+)/i);
  if (bm) await send("balance", { amount: money(bm[1]), currency: "USD" });
  /* test81 (lietotājs 2026-11-18): "Balance" ($47.89) vēl ietver jau izmaksāto — neizmaksāts = pieejams = "Available to
     withdraw" ($3.44, /request-earnings.html). Lasām katrā atjaunošanā (agrāk — tikai izmaksu pārbaudē). */
  try {
    const rq0 = txt((await getdoc("/request-earnings.html")).body);
    const am = rq0.match(/Available to withdraw:?\s*\$\s*([\d,.]+)/i);
    if (am) {
      await sendPayInfo({ available: money(am[1]), unpaid: money(am[1]), currency: "USD" });
      B.log(AG, `izmaksas: neizmaksāts = pieejams $${money(am[1])}` + (bm ? ` (lapā "Balance" $${money(bm[1])} — neņemu)` : ""));
    }
  } catch (e) { if (e && e.login) throw e; }

  /* lapas: /sales/page2.html … /sales/pageN.html (pēdējā numurs — no lappušu saitēm) */
  const sig = (r) => r.slice(0, 3).map((x) => x.id + x.day).join(",");
  let pages = 1;
  for (const a of doc.querySelectorAll('a[href*="/sales/page"]')) {
    const m = (a.getAttribute("href") || "").match(/\/sales\/page(\d+)\.html/);
    if (m) pages = Math.max(pages, +m[1]);
  }
  const since = OPTS.mode === "full" ? "0000-00-00" : OPTS.since;
  let rows = first.filter((x) => x.day >= since);
  if (first.length && first[first.length - 1].day >= since) {
    let prev = sig(first);
    for (let pg = 2; pg <= pages; pg++) {
      say(`${pg}/${pages}`, Math.round((pg / pages) * 90));
      const r = parse(await getdoc(`/sales/page${pg}.html`)) || [];
      if (!r.length || sig(r) === prev) break;
      prev = sig(r);
      rows = rows.concat(r.filter((x) => x.day >= since));
      if (r[r.length - 1].day < since) break;
      await sleep(250);
    }
  }
  const start = OPTS.mode === "full" ? (rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today) : since;
  await sendRows(rows, { start, end: today });
  B.log(AG, `pārdošanas: ${rows.length} (lapas ${pages}) — tālāk izmaksas`);   // test40: diagnostika
  /* izmaksas: jāpieprasa (tikai LASĀM /request-earnings.html); vēsture /sales/payout.html (maksājuma datums) */
  await payoutsSafe(async () => {
    const rq = txt((await getdoc("/request-earnings.html")).body);
    /* 2026-11-06 (lietotājs): pēc pieprasījuma lapa rāda citu tekstu — vecā "pieejams" palika ($50.55, īstais $0.61).
       Meklējam vairākus formulējumus; ja neatrodam — žurnālā teksts, un pieejamo neatstājam veco. */
    const pick$ = (res) => { for (const re of res) { const m = rq.match(re); if (m) return money(m[1]); } return null; };
    const av = pick$([/Available (?:to withdraw|for withdrawal|balance|for payout)?:?\s*\$\s*([\d,.]+)/i, /(?:Your |Current |Account )?balance:?\s*\$\s*([\d,.]+)/i, /\$\s*([\d,.]+)\s*(?:is )?available/i]);
    const mn = pick$([/minimum (?:withdrawal|payout|request)?\s*amount (?:is|of)?\s*\$\s*([\d,.]+)/i, /minimum[^$]{0,40}\$\s*([\d,.]+)/i]);
    if (av == null) B.log(AG, "izmaksas: pieejamā summa nav atrasta; teksts: " + rq.replace(/\s+/g, " ").slice(0, 300));
    else B.log(AG, `izmaksas: pieejams $${av}` + (mn != null ? `, minimums $${mn}` : ""));
    /* minimumu no lapas neņemam (lietotājs 2026-11-06: īstais minimums $50, lapā nolasās $25) */
    await sendPayInfo({ available: av != null ? av : 0, ...(av != null ? { unpaid: av } : {}), currency: "USD" });
    const t = tableObjs(await getdoc("/sales/payout.html"), [/date/i, /amount/i]) || [];
    /* 2026-11-06: "Pending" (pieprasīts, vēl nav samaksāts; PAYMENT DATE "-") — rādām kā ceļā: pieprasījums + ~9 d.
       (vēsturē 8–16 d., PayPal saņem maksājuma dienā) */
    const plus = (d, n) => { const x = new Date(d + "T12:00:00Z"); x.setUTCDate(x.getUTCDate() + n); return x.toISOString().slice(0, 10); };
    await sendPayouts(t.map((o) => {
      const st = pick(o, /status/), rq = pdate(pick(o, /request/)), pd = pdate(pick(o, /payment date/));
      if (/pending|process(?!ed)/i.test(st) && !pd && rq) return { date: plus(rq, 9), amount: money(pick(o, /amount/)), currency: "USD", status: "aptuveni +9", ref: "req:" + rq };
      return { date: pd || pdate(pick(o, /date/)), amount: money(pick(o, /amount/)), currency: "USD", status: st, ref: pick(o, /^id$/) };
    }).filter((r) => r.date && (!r.status || /processed|paid|complet|aptuveni/i.test(r.status))));
  });
  B.log(AG, `izmaksas pārbaudītas — tālāk${OPTS.sub_due ? " statusi" : ""}${OPTS.port_due ? " portfelis" : ""}`);   // test97: diagnostika
  if (OPTS.sub_due) { try { await dpStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  const ONL = [/\bonline[:\s]{1,3}(\d[\d,]*)/i, /(\d[\d,]*)\s+online\b/i, ...PORT_RE];
  await portfolioSafe([
    ["sales", async () => countIn(txt(doc.body), ONL)],
    ["sākumlapa", () => portPage("/", ONL)],
    ["files", () => portPage("/files.html", ONL)],
  ]);
  return { rows: rows.length, pages };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06), Seller's Menu:
   /files/pending.html — FILE ID | FILENAME (te — virsraksts) | UPLOAD DATE;
   /files/rejected.html — FILE ID | ORIGINAL NAME | UPLOAD DATE | REJECT DATE | REJECT REASON;
   /files.html — Online: FILE ID | ONLINE DATE | VIEWS | DOWNLOADS | EARNED (jaunākās augšā, 160 lapā; 1. lapa pietiek).
   Faila nosaukums ir tikai noraidītajām; pārējās sasaista pēc FILE ID (gaida → online). */
async function dpStatus() {
  B.log(AG, "statusi: sāku");   // test97: diagnostika (2026-11-20 iestrēga pēc "tālāk izmaksas" bez ziņām)
  const D = "[A-Z][a-z]{2}\\.\\s?\\d{1,2},\\s?\\d{4}";
  const LISTS = [
    ["/files/pending.html", "Pending", [/file id/i, /upload/i], (o) => ({ id: pick(o, /file id/), title: pick(o, /filename|title/), submitted: pdate(pick(o, /upload/)) || "" }),
      new RegExp(`(\\d{8,10})\\s+(.+?)\\s+(${D})\\s+Edit`, "g"), (m) => ({ id: m[1], title: m[2], submitted: pdate(m[3]) || "" })],
    ["/files/rejected.html", "Rejected", [/file id/i, /reason/i], (o) => ({ id: pick(o, /file id/), file: pick(o, /original/), submitted: pdate(pick(o, /upload/)) || "", why: pick(o, /reason/) }),
      new RegExp(`(\\d{8,10})\\s+(\\S+\\.(?:jpe?g|tiff?|png|eps|mp4|mov))\\s+(${D})\\s+(${D})\\s+(.+?)(?=\\s+\\d{8,10}\\s|\\s*$)`, "g"), (m) => ({ id: m[1], file: m[2], submitted: pdate(m[3]) || "", why: m[5] })],
    ["/files.html", "Online", [/file id/i, /online date/i], (o) => ({ id: pick(o, /file id/), submitted: pdate(pick(o, /online date/)) || "" }),
      new RegExp(`(\\d{8,10})\\s+(${D})\\s+\\d+\\s+\\d+`, "g"), (m) => ({ id: m[1], submitted: pdate(m[2]) || "" })],
  ];
  for (const [path, raw, need, fromT, re, fromRe] of LISTS) {
    let rows = [], src = "";
    try {
      const d = await getdoc(path);
      const t = tableObjs(d, need);
      if (t && t.length) { rows = t.map(fromT); src = "tabula"; }
      else if (/No Files|no files/i.test(txt(d.body)) && !/\d{8,10}/.test(txt(d.body))) src = "tukšs";
      else {
        const tx = await framed(path, (x) => (/\d{8,10}|No Files/i.test(x) ? x : null), 25000);
        if (tx) { let m; re.lastIndex = 0; while ((m = re.exec(tx.replace(/[ \t]+/g, " ").replace(/\s*\n\s*/g, " ")))) rows.push(fromRe(m)); src = "lapas teksts"; }
      }
    } catch (e) { if (e && e.login) throw e; src = String((e && e.message) || e).slice(0, 60); }
    rows = rows.filter((r) => /^\d{6,}$/.test(String(r.id || "").trim())).map((r) => ({ id: String(r.id).trim(), file: r.file || "", title: (r.title || "").slice(0, 250),
      submitted: r.submitted || "", status: raw + (r.why ? ": " + r.why.trim().slice(0, 140) : "") }));
    /* test46: publicētajām virsraksta sarakstā nav — bildes lapā /<ID> virsraksts <h1> ("… — Photo"; Chrome 2026-11-11).
       Tikai pēdējo 30 dienu, kurām virsraksts vēl nav zināms (OPTS.sub_known), ≤25 bildes, ≤60 s. */
    if (raw === "Online") {
      const known = new Set((OPTS.sub_known || []).map(String)), t0 = Date.now(), lim = new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10);
      let n = 0, got = 0;
      /* test65: pēdējo 21 dienu bildēm lapu atveram arī zināmām — vajag sīktēlu (og:image) sasaistei pēc izskata; ≤45, ≤90 s */
      const lim2 = new Date(Date.now() - 21 * 864e5).toISOString().slice(0, 10);
      for (const r of rows) {
        const fresh = r.submitted && r.submitted >= lim2;
        if (!fresh && (r.title || known.has(r.id) || (r.submitted && r.submitted < lim))) continue;
        if (++n > 45 || Date.now() - t0 > 90000) break;
        if (n % 5 === 0) say(`Online: ${n}`, 95);
        try {
          const d = await getdoc("/" + r.id);
          const h = ((d.querySelector("h1") || {}).textContent || "").replace(/\s+[—–-]\s+(Photo|Image|Vector|Video|Illustration)\s*$/i, "").trim();
          if (h.length > 15) { r.title = h.slice(0, 250); got++; }
          const og = (d.querySelector('meta[property="og:image"]') || {}).content || "";   // test65: priekšskatījums sasaistei pēc izskata
          if (/^https?:/.test(og)) r.thumb = og;
        } catch (e) { if (e && e.login) throw e; }
      }
      if (n) B.log(AG, `statusi: Online — virsraksti no bildes lapas ${got}/${n}`);
    }
    /* gaidošajām faila nosaukums redzams, nospiežot "Edit" (lietotājs 2026-11-06): "Name: d738_….jpg" … "ID: 915982094" */
    if (raw === "Pending" && rows.some((r) => !r.file)) {
      const byId = new Map(rows.map((r) => [r.id, r]));
      let got = 0;
      await framed(path, (x) => (/Edit/.test(x) ? true : null), 25000, async ({ doc }) => {
        const edits = () => [...doc.querySelectorAll("a, button, span")].filter((e) => /^\s*Edit\s*$/.test(e.innerText || "") && ![...e.children].some((c) => /Edit/.test(c.innerText || "")));
        const n = Math.min(edits().length, 60);
        /* test41: ≤60 s, apstājas pēc 5 neveiksmēm pēc kārtas (test40: 0/26, 3,5 min velti) */
        const t0 = Date.now(); let miss = 0;
        for (let i = 0; i < n; i++) {
          if (miss >= 5 || Date.now() - t0 > 60000) break;
          if (i % 5 === 4) say(`Pending: ${i + 1}/${n}`, 95);
          const e = edits()[i]; if (!e) break;
          e.click();
          let m = null;
          for (let k = 0; k < 15 && !m; k++) {
            await sleep(300);
            const t = doc.body.innerText || "";
            const nm = t.match(/Name:\s*(\S+\.(?:jpe?g|tiff?|png|eps|mp4|mov))/i), id = t.match(/\bID:\s*(\d{6,})/);
            if (nm && id && byId.has(id[1]) && !byId.get(id[1]).file) m = [id[1], nm[1]];
          }
          if (m) { byId.get(m[0]).file = m[1]; got++; miss = 0; } else miss++;
          const x = [...doc.querySelectorAll("button, a, span, i, svg")].find((c) => /close|×|✕/i.test((c.getAttribute && (c.getAttribute("aria-label") || c.getAttribute("title") || c.className && String(c.className.baseVal || c.className))) || c.innerText || ""));
          if (x) { try { x.click(); } catch (_) { /* */ } }
          await sleep(300);
        }
        return true;
      }).catch(() => null);
      B.log(AG, `statusi: Pending — faila nosaukumi no "Edit": ${got}/${rows.length}`);
    }
    const f = rows[0];
    B.log(AG, `statusi: ${raw} — ${rows.length} bildes (${src})` + (f ? `; paraugs: ID ${f.id}, fails "${f.file}", ${f.status.slice(0, 60)}, ${f.submitted}` : ""));
    if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  }
  await send("sub_done", { full: false });
}
