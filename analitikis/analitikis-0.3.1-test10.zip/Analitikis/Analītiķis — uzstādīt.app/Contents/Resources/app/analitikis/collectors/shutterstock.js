/* Shutterstock Contributor: submit.shutterstock.com */
async function collect() {
  if (location.hostname !== "submit.shutterstock.com") throw LOGIN;
  const A = (u) => getj("/api/next/" + u);
  const head = await A("v2/earnings/header");
  if (!head || !head.unpaid) throw LOGIN;
  await send("balance", { amount: +head.unpaid.total || 0, currency: "USD" });

  const ty = +today.slice(0, 4), tm = +today.slice(5, 7);
  const full = OPTS.mode === "full";
  const since = OPTS.since;
  const months = full ? monthsBack(2004, 1, ty, tm) : monthsBack(+since.slice(0, 4), +since.slice(5, 7), ty, tm);
  const detailFrom = full ? OPTS.detail_from : (OPTS.detail_since || since);
  const cats = new Set(["25_a_day", "single_image_and_other", "on_demand"]);
  const detailDays = [];   // [date, [cat, ...]]
  let found = false, empty = 0;
  for (let i = 0; i < months.length; i++) {
    const [y, m] = months[i];
    say(`${y}-${String(m).padStart(2, "0")}`, full ? Math.min(40, Math.round(i / 3)) : 20);
    const j = await A(`v2/earnings/aggregate?aggregation_period=day&year=${y}&month=${m}`);
    const days = (j && j.days) || [];
    await send("daily", { year: y, month: m, days });
    for (const d of days) {
      const dc = Object.keys(d).filter((k) => d[k] && typeof d[k] === "object" && (d[k].downloads || d[k].earnings));
      dc.forEach((c) => cats.add(c));
      /* "earning_pools_*" (datu licencēšana u.c.) nav sadalījuma pa bildēm (HTTP 400) — tās ir tikai dienu summās */
      const per = dc.filter((c) => !/pool/i.test(c));
      if (d.date >= detailFrom && per.length) detailDays.push([d.date, per]);
    }
    if (full) {
      if (days.length) { found = true; empty = 0; } else empty++;
      if ((found && empty >= 24) || (!found && empty >= 48)) break;
    }
  }

  /* pārdošanas pa bildēm katrā dienā */
  for (let i = 0; i < detailDays.length; i++) {
    const [date, dc] = detailDays[i];
    say(date, 40 + Math.round((i / Math.max(1, detailDays.length)) * 40));
    let rows = [];
    for (const c of dc) {
      let page = 1, pages = 1;
      do {
        let j;
        /* dažām kategorijām (piem. jaunā "earning_pools_commission") sadalījuma pa bildēm nav — HTTP 400 */
        try { j = await A(`v2/earnings/media_stats/day?date=${date}&display_column=${c}&page=${page}&per_page=100`); }
        catch (e) { if (e && e.login) throw e; B.log(AG, `${date} ${c}: ${(e && e.message) || e}`); break; }
        rows = rows.concat(((j && j.media) || []).map((r) => Object.assign({ category: c }, r)));
        pages = Math.max(1, (j && j.pages) || 1);
        page++;
      } while (page <= pages && page < 30);
    }
    await send("day_media", { date, rows });
  }

  /* bilžu kopsummas visā vēsturē (≈2 min) — tikai pilnajā ielādē vai pirmo reizi; pēc tam tās papildina jaunās pārdošanas */
  if (OPTS.totals) {
  await send("totals", { begin: true });
  const mtypes = ["photo", "video"];
  let mi = 0;
  for (const mt of mtypes) {
    for (const c of cats) {
      let page = 1, pages = 1;
      say(`${mt} · ${c}`, 80 + Math.round((mi++ / (mtypes.length * cats.size)) * 15));
      do {
        let j;
        try { j = await A(`v2/earnings/media_summary?media_type=${mt}&display_column=${c}&page=${page}&per_page=500`); }
        catch (e) { if (e && e.login) throw e; break; }
        await send("totals", { category: c, media_type: mt, rows: (j && j.media) || [] });
        pages = Math.max(1, (j && j.pages) || 1);
        page++;
      } while (page <= pages && page < 100);
    }
  }

  }
  try { const r = await A("earnings/recent"); await send("recent", { rows: Array.isArray(r) ? r : [] }); } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: automātiskas (līdz 15. datumam), minimums — lietotāja iestatījums; vēsture /payments (10 lapas) */
  await payoutsSafe(async () => {
    const d = await getdoc("/payments");
    const mm = txt(d.body).match(/minimum payout amount is set to\s*\$\s*([\d.,]+)/i);
    await sendPayInfo({ unpaid: +head.unpaid.total || 0, currency: "USD", min: mm ? money(mm[1]) : null });
    const seen = new Set();
    let rows = [];
    const pfull = full || OPTS.payouts_full;
    for (let pg = 1; pg <= (pfull ? 30 : 1); pg++) {
      const dd = pg === 1 ? d : await getdoc(`/payments?pg=${pg}`)   /* ?pg= der (žurnāls 2026-10-30) */;
      const t = tableObjs(dd, [/date/i, /amount/i]);
      if (!t) { if (pg === 1) B.log(AG, "izmaksu tabula nav atrasta; virsraksti: " + [...dd.querySelectorAll("th, [role=columnheader]")].slice(0, 8).map(txt).join(" | ")); break; }
      const r = t.map((o) => ({ date: pdate(pick(o, /date/)), amount: money(pick(o, /amount/)), currency: "USD" })).filter((x) => x.date);
      const k = r.map((x) => x.date + x.amount).join();
      if (pg === 2 && seen.has(k)) {                  // ?page= nedarbojas — izpēte: citi lapošanas veidi (žurnālā)
        for (const u of ["/payments?pg=2", "/payments?p=2", "/payments/page/2", "/payments?page_number=2"]) {
          try {
            const tt = tableObjs(await getdoc(u), [/date/i, /amount/i]) || [];
            const kk = tt.map((o) => pdate(pick(o, /date/)) + money(pick(o, /amount/))).join();
            B.log(AG, `izmaksas: ${u} — ${tt.length} rindas${kk && !seen.has(kk) && tt.length ? " (citas — der!)" : " (tās pašas)"}`);
          } catch (e) { if (e && e.login) throw e; B.log(AG, `izmaksas: ${u} — ${((e && e.message) || e).toString().slice(0, 60)}`); }
        }
      }
      if (!r.length || seen.has(k)) break;
      seen.add(k);
      rows = rows.concat(r);
      await sleep(250);
    }
    /* test44: lapošana ir JS (?page= nemaina saturu) → vēsturi lasām atvērtā rāmī, spiežot "›" (lietotājs 2026-10-30) */
    if (pfull && rows.length <= 10) {
      const conv = (dd) => (tableObjs(dd, [/date/i, /amount/i]) || []).map((o) => ({ date: pdate(pick(o, /date/)), amount: money(pick(o, /amount/)), currency: "USD" })).filter((x) => x.date);
      const all = await framed("/payments", (t, dd) => conv(dd).length > 0, 25000, async ({ doc, win }) => {
        const out = [], keys = new Set();
        for (let pg = 1; pg <= 40; pg++) {
          const r = conv(doc), k = r.map((x) => x.date + x.amount).join();
          if (!r.length || keys.has(k)) break;
          keys.add(k); out.push(...r);
          const nx = [...doc.querySelectorAll("button, a, [role=button]")].find((e) => !e.disabled && e.getAttribute("aria-disabled") !== "true" &&
            (/next/i.test(e.getAttribute("aria-label") || "") || /^\s*(›|>|»|next)\s*$/i.test(e.innerText || "")));
          if (!nx) break;
          nx.click();
          for (let i = 0; i < 20; i++) { await sleep(400); if (conv(doc).map((x) => x.date + x.amount).join() !== k) break; }
        }
        B.log(AG, `izmaksas: rāmī nolasītas ${out.length} rindas`);
        if (out.length <= 10) apiSeen(win, /payment|payout/i);
        return out;
      });
      if (all && all.length > rows.length) rows = all;
    }
    await sendPayouts(rows, pfull ? {} : { full: false, start: rows.length ? rows.reduce((m, x) => (x.date < m ? x.date : m), today) : today });
  });
  if (OPTS.sub_due) { try { await ssStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["sākumlapa (Image portfolio)", () => framed("/dashboard", (t) => { const m = t.match(/Image portfolio\s*(\d[\d,]*)/i); return m ? numOf(m[1]) : null; })],
    ["earnings/header", async () => { B.log(AG, "portfelis: header atslēgas: " + keysOf(head)); return countKey(head, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); }],
    ["user", () => portJson("/api/next/v2/user")],
    ["user/stats", () => portJson("/api/next/v2/user/stats")],
    ["content_counts", () => portJson("/api/next/v2/user/content_counts")],
    ["dashboard", () => portPage("/dashboard")],
  ]);
  return { months: months.length, days: detailDays.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /portfolio/pending/photo ("Pending"),
   /portfolio/recently_reviewed/photo/reviewed (pēdējās 21 dienas: Approved / Rejected / Correction needed / Eligible for data licensing only),
   /portfolio/correction_needed/photo ("Correction needed" + iemesls, piem. "Eligible for Editorial Use", "Translation Required"),
   /portfolio/published/photo?sortOrder=newest (pieņemtās, jaunākās augšā). Kartītē: "<ID> - <faila nosaukums>" + statusa zīme. */
async function ssStatus() {
  const ID_RE = /^\s*(\d{6,12})\s*-\s*(.+?\.(?:jpe?g|tiff?|png|eps|mp4|mov))\s*$/i;
  const dom = async (doc, raw) => {
    const out = new Map();
    const hits = [...doc.querySelectorAll("body *")].filter((e) => ID_RE.test((e.innerText || "").replace(/\s+/g, " ")) && ![...e.children].some((c) => ID_RE.test((c.innerText || "").replace(/\s+/g, " "))));
    for (const e of hits) {
      const m = (e.innerText || "").replace(/\s+/g, " ").match(ID_RE); if (!m || out.has(m[1])) continue;
      let c = e; while (c.parentElement && ((c.parentElement.innerText || "").match(/\b\d{6,12}\s*-\s*\S/g) || []).length <= 1) c = c.parentElement;
      const t = (c.innerText || "").replace(/\s+/g, " ");
      const st = (t.match(/\b(Approved|Rejected|Correction needed|Eligible for data licensing only|Pending)\b/i) || [])[1] || raw;
      const reason = /reject|correction/i.test(st) ? ((t.match(/(?:Correction needed|Rejected)(?:\s*\(\d+\))?\s*(?:Make changes)?\s*([A-Z][^:]{3,80}):/i) || [])[1] || "") : "";
      out.set(m[1], { id: m[1], file: m[2].replace(/\s+/g, ""), title: "", submitted: (t.match(/Date (?:submitted|approved):\s*([\d/]+|\w+ \d{1,2}, \d{4})/i) || [])[1] || "",
        status: st + (reason ? ": " + reason.trim() : "") });
    }
    return [...out.values()];
  };
  await subLists([{ path: "/portfolio/pending/photo", raw: "Pending", max: 5 },
                  { path: "/portfolio/recently_reviewed/photo/reviewed", raw: "Checked", max: 5 },
                  { path: "/portfolio/correction_needed/photo", raw: "Correction needed", max: 3 },
                  { path: "/portfolio/published/photo?sortOrder=newest", raw: "Approved", max: 2 }], { dom, api: false });
}
