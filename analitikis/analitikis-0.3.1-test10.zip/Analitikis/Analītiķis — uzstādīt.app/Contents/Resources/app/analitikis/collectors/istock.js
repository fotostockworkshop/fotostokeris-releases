/* Getty Images / iStock: accountmanagement.gettyimages.com — mēneša atskaites (TSV ar katru pārdošanu).
   Atskaites ir tikai par noslēgtiem mēnešiem (piem. septembris parādās oktobrī). */
async function collect() {
  const host = location.hostname;
  if (/(^|\.)istockphoto\.com$/.test(host)) return { skipped: "istockphoto" };   // pircēju vietne — tur neielogojamies
  if (host === "esp.gettyimages.com") {
    /* ESP ir vienas lapas lietotne (uz Mac tā zīmējas lēni, un pāradresācija mēdz aizvest uz "Batches"):
       pagaidām, līdz redzams vai nu ielogošanās lauks, vai lietotnes saturs, un tad ejam uz atskaitēm. */
    const pw = () => document.querySelector('input[type="password"]');
    const app = () => document.querySelector('a[href*="account_manager"], nav a, header a, [class*="navbar" i]');
    for (let i = 0; i < 24 && !pw() && !app(); i++) await sleep(500);
    if (pw() || /sign-?in|log-?in/i.test(location.pathname)) throw LOGIN;
    /* sīktēli: ESP lejupielāžu statistika (MasterId → ThumbnailUrl, no 2023-07); tikai šeit — tas pats domēns */
    if (!sessionStorage.getItem("__an_th")) {
      sessionStorage.setItem("__an_th", "1");
      try { await espThumbs(); } catch (e) { if (e && e.login) throw e; B.log(AG, "ESP sīktēli: " + ((e && e.message) || e)); }
    }
    /* 2026-11-06 iesniegumu statusi: ESP "Batches" (/contribute/batches) — vispirms izpēte (API adreses un lauki žurnālā) */
    if (OPTS.sub_due) {          // 2026-11-06: sessionStorage atzīme traucēja otrajā atjaunošanā — pietiek ar sub_due (sub_done)
      try { await espSubProbe(); } catch (e) { if (e && e.login) throw e; B.log(AG, "ESP statusi: " + ((e && e.message) || e)); }
    }
    const st = JSON.parse(sessionStorage.getItem("__an_nav") || '{"n":0,"t":0}');
    if (st.n < 4 && Date.now() - st.t > 8000) {
      sessionStorage.setItem("__an_nav", JSON.stringify({ n: st.n + 1, t: Date.now() }));
      B.log(AG, "ESP → atskaites");
      location.href = "https://esp.gettyimages.com/ui/account_manager?path=Reports/Dashboard";
      return { navigated: true };
    }
    throw LOGIN;
  }
  if (host !== "accountmanagement.gettyimages.com") throw LOGIN;
  const XH = { "X-Requested-With": "XMLHttpRequest" };
  const per = await getj("/Reports/AvailableStatementPeriod", XH);
  const all = (((per || {}).Options || {}).AvailableStatementPeriods || []).map((p) => p.Value).filter(Boolean).sort().reverse();
  if (!all.length) throw new Error("Getty: nav pieejamu atskaišu");
  /* atskaites ir par noslēgtiem mēnešiem un vairs nemainās: pēc pirmās ielādes ņemam tikai mēnešus no pēdējās zināmās
     pārdošanas mēneša (tas pats mēnesis vēlreiz — ja atskaite tobrīd vēl nebija pilna); vismaz jaunāko */
  const since = OPTS.mode === "full" ? "0000" : (OPTS.last_sale_day || OPTS.since).slice(0, 7);
  let periods = all.filter((p) => p.slice(0, 7) >= since);
  if (OPTS.mode !== "full" && !periods.length) periods = all.slice(0, 1);
  B.log(AG, `atskaites: ${periods.length} (${periods.map((p) => p.slice(0, 7)).join(", ")})`);

  const exp = await getdoc("/Reports/Export");
  const tokEl = exp.querySelector('input[name="__RequestVerificationToken"]');
  if (!tokEl) throw LOGIN;
  const s3 = (exp.querySelector('[name="IsStatementReportFromS3FeatureActive"]') || {}).value || "False";
  const flag = (exp.querySelector("#StatementReportFeatureFlag") || {}).value || "False";

  let total = 0;
  for (let i = 0; i < periods.length; i++) {
    const p = periods[i], Y = p.slice(0, 4), M = p.slice(5, 7);
    say(`${Y}-${M}`, Math.round((i / periods.length) * 95));
    const body = new URLSearchParams({ exportIStockHistory: "false", reportTypes: "monthly", Years: Y, Months: M, contractId: "",
      exportFormat: "tsv", IsStatementReportFromS3FeatureActive: s3, __RequestVerificationToken: tokEl.value });
    let text = "";
    const hdr = { "Content-Type": "application/x-www-form-urlencoded" };
    if (flag === "True") {
      const u = await fetch("/Reports/GetExportUrl", { method: "POST", body, headers: Object.assign({}, hdr, XH), credentials: "include" }).then((r) => r.text());
      const url = u.trim().replace(/^"|"$/g, "");
      text = await fetch(url).then((r) => r.text());
    } else {
      text = await fetch("/Reports/Export", { method: "POST", body, headers: hdr, credentials: "include" }).then((r) => r.text());
    }
    if (/^\s*</.test(text)) {
      if (/password|sign in|log in/i.test(text.slice(0, 5000))) throw LOGIN;
      continue;                                        // mēnesim nav atskaites
    }
    const lines = text.split(/\r?\n/).filter((l) => l.trim());
    if (!lines.length) continue;
    const head = lines[0].split("\t");
    const ix = (n) => head.indexOf(n);
    const c = { date: ix("Sales Date"), id: ix("Asset Number"), fn: ix("Alternate Asset Number"), desc: ix("Asset Description"),
      prod: ix("Product Type"), terr: ix("Sales Territory"), roy: ix("Gross Royalty in USD"), coll: ix("Collection") };
    if (c.date < 0 || c.roy < 0) throw new Error("Getty: neparedzēts atskaites formāts");
    const rows = [];
    for (const l of lines.slice(1)) {
      const v = l.split("\t");
      const day = pdate(v[c.date]);
      const amount = parseFloat(v[c.roy]);
      if (!day || isNaN(amount)) continue;
      const id = (v[c.id] || "").trim();
      rows.push({ day, id, filename: (v[c.fn] || "").trim(), title: (v[c.desc] || "").replace(/^\d+-/, "").trim(),
        amount, cnt: 1, kind: "sale", license: (v[c.prod] || "").trim(), country: (v[c.terr] || "").trim(),
        url: id ? `https://www.istockphoto.com/search/2/image?phrase=${id}` : "", raw: c.coll >= 0 ? { coll: v[c.coll] } : null });
    }
    total += rows.length;
    await sendRows(rows, { batch: "getty-" + p.slice(0, 7) });
    await sleep(300);
  }
  /* izmaksas: automātiskas 25. datumā, minimums $100 (nesasniegts → pārnests). GetSummary katram periodam (JSON ar
     līguma numuru no atskaišu formas; bez tā — HTML kopsavilkums). */
  await payoutsSafe(async () => {
    /* līguma numurs (≠ Contributor ID): atskaišu lapās — izvēlne vai skriptā; meklējam vairākās lapās */
    const findContract = (d) => {
      const o = d.querySelector('select[name*="ontract" i] option[value]:not([value=""]), select[id*="ontract" i] option[value]:not([value=""])');
      if (o && /^\d{5,}$/.test(o.value)) return o.value;
      const m = d.documentElement.innerHTML.match(/contract(?:Id|Number)?["'\s:=]+["']?(\d{5,})/i);
      return m ? m[1] : "";
    };
    let contract = findContract(exp);
    for (const u of ["/Reports/Dashboard", "/Reports/Summary", "/Reports/Statement", "/Reports"]) {
      if (contract) break;
      try { contract = findContract(await getdoc(u)); } catch (e) { if (e && e.login) throw e; }
    }
    /* bez līguma GetSummary atbild {AllContracts, Status} (žurnāls 2026-10-30) — līgumu ņemam no turienes */
    if (!contract && all.length) {
      try {
        const r0 = await fetch("/Reports/GetSummary", { method: "POST", credentials: "include",
          headers: Object.assign({ "Content-Type": "application/x-www-form-urlencoded" }, XH),
          body: new URLSearchParams({ statementPeriod: all[0].slice(0, 10), contract: "" }) });
        const j0 = JSON.parse(await r0.text());
        const ac = j0 && j0.AllContracts;
        const ids = [];
        /* test44: AllContracts ir HTML gabals (contractGroupsPanel) — līguma numurs vērtībās/atribūtos/tekstā */
        if (typeof ac === "string" && /</.test(ac)) {
          const hd = new DOMParser().parseFromString(ac, "text/html");
          for (const el of hd.querySelectorAll("input, option, [data-contract], [data-contract-id], [data-id], [data-value], a[href]")) {
            for (const v of [el.value, el.getAttribute("data-contract"), el.getAttribute("data-contract-id"), el.getAttribute("data-id"), el.getAttribute("data-value"),
              ((el.getAttribute("href") || "").match(/contract\w*=(\d{4,})/i) || [])[1]]) if (v && /^\d{4,}$/.test(String(v).trim())) ids.push(String(v).trim());
          }
          /* teksts: "… $ 0.00 <līgums>;10iStock;<vārds> <līgums>/10iStock Minimum Payment Not Met. Amount Carried Forward $ 58.22" */
          if (!ids.length) { const m = txt(hd.body).match(/(\d{4,})\s*[;\/]\s*\d+\s*iStock/i); if (m) ids.push(m[1]); }
          const cf = txt(hd.body).match(/Carried Forward\s*\$\s*([\d,.]+)/i);
          if (cf) await sendPayInfo({ unpaid: money(cf[1]), currency: "USD" });
          if (!ids.length) { const m = txt(hd.body).match(/contract[^\d]{0,30}(\d{4,})/i) || hd.body.innerHTML.match(/(?:contract|value)\w*["'\s:=]+["']?(\d{5,})/i); if (m) ids.push(m[1]); }
          if (!ids.length) B.log(AG, "izmaksas: AllContracts HTML: " + txt(hd.body).replace(/\d{4,}/g, "N").slice(0, 300));
        }
        (function walk(o) {
          if (o == null) return;
          if (typeof o !== "object") { if (/^\d{3,}$/.test(String(o).trim())) ids.push(String(o).trim()); return; }
          for (const k in o) {
            const v = o[k];
            if (v != null && typeof v !== "object" && /id|number|value|contract/i.test(k) && /^\d{3,}$/.test(String(v).trim())) ids.push(String(v).trim());
            else if (typeof v === "object") walk(v);
          }
        })(ac);
        contract = ids[0] || "";
        B.log(AG, `izmaksas: AllContracts — ${ids.length ? `līgumi ${ids.length}` : "līgums nav atrasts; uzbūve: " + JSON.stringify(ac).replace(/\d{4,}/g, "N").slice(0, 160)}`);
      } catch (e) { if (e && e.login) throw e; B.log(AG, "izmaksas: AllContracts — " + ((e && e.message) || e)); }
    }
    B.log(AG, "izmaksas: līguma numurs " + (contract ? "atrasts" : "nav atrasts — lasu kopsavilkumu bez tā"));
    const list = OPTS.mode === "full" || OPTS.payouts_full ? all : all.slice(0, 2);
    const pays = new Map();
    let carried = null;
    for (let i = 0; i < list.length; i++) {
      const p = list[i];
      say(`izmaksas ${p.slice(0, 7)}`, 96);
      const r = await fetch("/Reports/GetSummary", { method: "POST", credentials: "include",
        headers: Object.assign({ "Content-Type": "application/x-www-form-urlencoded" }, XH),
        body: new URLSearchParams({ statementPeriod: p.slice(0, 10), contract }) });
      const tx = await r.text();
      let j = null;
      try { j = JSON.parse(tx); } catch (_) { /* HTML */ }
      if (!j) {
        /* bez līguma numura Getty atdod HTML kopsavilkumu: rindas "izmaksas datums … summa" */
        const d = new DOMParser().parseFromString(tx, "text/html");
        let n = 0;
        for (const tr of d.querySelectorAll("tr, li, .row, div")) {
          if (tr.children.length > 12) continue;
          const t = txt(tr);
          if (t.length > 200 || !/pay|paid/i.test(t)) continue;
          const dd = pdate(t), am = t.match(/\$\s*([\d,]+\.\d{2})/);
          if (dd && am && money(am[1]) > 0 && !/carried|not met/i.test(t)) { pays.set(dd, Math.max(pays.get(dd) || 0, money(am[1]))); n++; }
          const cf = t.match(/carried forward[^$]*\$\s*([\d,]+\.\d{2})/i);
          if (i === 0 && cf) carried = money(cf[1]);
        }
        if (i === 0 && !n) B.log(AG, "izmaksas: kopsavilkums HTML bez izmaksu rindām: " + txt(d.body).slice(0, 160));
        await sleep(250);
        continue;
      }
      if (i === 0 && !((j.Summary || {}).PaymentDates || []).length) B.log(AG, "izmaksas: kopsavilkumā nav izmaksu datumu; lauki: " + Object.keys(j).join(",") + " / " + Object.keys(j.Summary || {}).join(","));
      for (const pd of ((j.Summary || {}).PaymentDates || [])) for (const pc of (pd.PaymentCurrencies || [])) for (const s of (pc.Summaries || [])) {
        const T = s.Totals || {};
        const d = pdate(s.PaymentDate || pd.PaymentDate || "");
        if (d && +T.NetPayment > 0) pays.set(d, (pays.get(d) || 0) + +T.NetPayment);
        if (i === 0 && T.MinimumNotMetCarriedForward != null) carried = +T.MinimumNotMetCarriedForward || 0;
      }
      await sleep(250);
    }
    if (carried != null) await sendPayInfo({ unpaid: carried, currency: "USD" });
    const rows = [...pays].map(([date, amount]) => ({ date, amount: Math.round(amount * 100) / 100, currency: "USD" })).sort((a, b) => (a.date < b.date ? 1 : -1));
    await sendPayouts(rows, OPTS.mode === "full" ? {} : { full: false });
  });
  const pn = await portfolioSafe([
    ["dashboard", () => portPage("/Reports/Dashboard")],
  ]);
  /* publiskais portfelis istockphoto.com (vārds — iestatījumos); cits domēns → pāriet pašā logā */
  if (!pn && OPTS.port_name) {
    const r = await portNav(`https://www.istockphoto.com/portfolio/${encodeURIComponent(OPTS.port_name)}?mediatype=photography`, "([\\d,]+)\\s+Images and Stock Photos", "publiskais portfelis");
    if (r) return r;
  } else if (!pn) B.log(AG, "portfelis: publiskā portfeļa vārds iestatījumos nav ierakstīts");
  return { periods: periods.length, rows: total };
}

async function espThumbs() {
  const API = "https://esp.gettyimages.com/api/account/v1/statistics/";
  let months = [];
  try {
    const m = await getj(API + "months");
    const arr = Array.isArray(m) ? m : (m && (m.Months || m.months || m.Items || m.items)) || [];
    months = arr.map((x) => String(typeof x === "object" ? (x.Month || x.month || x.Value || x.value || x.Date || "") : x).slice(0, 7))
      .filter((x) => /^\d{4}-\d{2}$/.test(x)).sort().reverse();
  } catch (e) { if (e && e.login) throw e; }
  if (!months.length) months = [today.slice(0, 7)];
  if (!OPTS.full_thumbs) months = months.slice(0, 2);
  let n = 0;
  for (let i = 0; i < months.length; i++) {
    const m = months[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(`sīktēli ${m}`, Math.round((i / months.length) * 10));
    for (let page = 1; page < 60; page++) {
      const j = await getj(`https://esp.gettyimages.com/api/account/v1/statistics/downloads_for_search?orderResultsBy=LastDownloadDate&sortDirection=Descending&page=${page}&pageSize=50&assetTypes=Photo,Video,Illustration&fromDate=${m}-01&toDate=${monthEnd(y, mo)}`);
      const rows = ((j && j.AssetDownloadSummaries) || []).map((r) => ({ id: String(r.MasterId || ""), thumb: r.ThumbnailUrl || "" }))
        .filter((r) => r.id && r.thumb);
      if (rows.length) await send("thumbs", { rows, all: !!OPTS.full_thumbs && i === months.length - 1 });
      n += rows.length;
      const total = +(j && j.TotalAssetCount) || 0;
      if (!rows.length || page * 50 >= total) break;
      await sleep(150);
    }
  }
  if (OPTS.full_thumbs) await send("thumbs", { rows: [], all: true });     // pilnie sīktēli nolasīti — turpmāk tikai 2 jaunākie mēneši
  B.log(AG, `ESP sīktēli: ${n}`);
}

/* Iesniegumu statusi — ESP API (lietotāja saglabātā lapa 2026-11-06; rāmī lapa paliek tukša):
   GET /api/submission/v1/submission_batches?page&page_size → {items, meta.total_items}
   GET /api/submission/v1/submission_batches/<id>/contributions?with_asset_view_data=true&with_brief_notes=true → [bildes]
   GET /api/review/v1/submission_batches/<id>/reviews → noraidījuma iemesli. Galvene X-XSRF-TOKEN no sīkdatnes XSRF-TOKEN.
   Pirmajā reizē — visi iesniegumi (līdz 7 lapām pa 10), tālāk — 1. lapa (jaunākie). */
async function espSubProbe() {
  const xs = (document.cookie.match(/(?:^|;\s*)XSRF-TOKEN=([^;]+)/) || [])[1];
  const H = Object.assign({ Accept: "application/json" }, xs ? { "X-XSRF-TOKEN": decodeURIComponent(xs) } : {});
  const J = async (u) => { const r = await fetch(u, { credentials: "include", headers: H }); if (!r.ok) throw new Error(`${u.split("?")[0]}: HTTP ${r.status}`); return r.json(); };
  const all = new Map();
  const maxP = OPTS.sub_full ? 7 : 1;
  let batches = [], logged = { b: 0, c: 0, r: 0 };
  for (let p = 1; p <= maxP; p++) {
    const j = await J(`/api/submission/v1/submission_batches?page=${p}&page_size=10`);
    const items = (j && j.items) || [];
    if (!logged.b && items[0]) { logged.b = 1; B.log(AG, `statusi: iesniegumi ${j.meta && j.meta.total_items}; lauki: ${Object.keys(items[0]).slice(0, 30).join(", ")}`); }
    batches = batches.concat(items);
    if (items.length < 10) break;
    await sleep(300);
  }
  const val = (o, re) => { for (const [k, v] of Object.entries(o || {})) if (re.test(k) && v != null && v !== "" && typeof v !== "object") return String(v); return ""; };
  const deep = (o, re, d = 2) => { const v = val(o, re); if (v || !d) return v; for (const x of Object.values(o || {})) if (x && typeof x === "object" && !Array.isArray(x)) { const r = deep(x, re, d - 1); if (r) return r; } return ""; };
  for (const b of batches) {
    const bid = b.id || b.submission_batch_id; if (!bid) continue;
    let cs = [];
    try { cs = await J(`/api/submission/v1/submission_batches/${bid}/contributions?with_asset_view_data=true&with_brief_notes=true`); } catch (e) { B.log(AG, "statusi: " + e.message); continue; }
    if (!Array.isArray(cs)) cs = (cs && (cs.items || cs.contributions)) || [];
    if (!logged.c && cs[0]) { logged.c = 1; B.log(AG, `statusi: bildes lauki: ${Object.keys(cs[0]).slice(0, 40).join(", ")}; paraugs: ${JSON.stringify(cs[0]).replace(/https?:\/\/[^"]+/g, "…").slice(0, 500)}`); }
    let why = new Map();
    if (cs.some((c) => /reject|revis/i.test(JSON.stringify(c).slice(0, 2000)))) {
      try {
        const rv = await J(`/api/review/v1/submission_batches/${bid}/reviews`);
        const arr = Array.isArray(rv) ? rv : (rv && (rv.items || rv.reviews)) || [];
        if (!logged.r && arr[0]) { logged.r = 1; B.log(AG, `statusi: pārbaudes lauki: ${Object.keys(arr[0]).slice(0, 25).join(", ")}; paraugs: ${JSON.stringify(arr[0]).slice(0, 400)}`); }
        for (const x of arr) {
          const cid = deep(x, /^(contribution_id|contributionId|asset_id|master_id|media_id)$/i);
          const rs = JSON.stringify(x).match(/"(?:reason|rejection_reason|description|label|name|note|text)"\s*:\s*"([^"]{3,160})"/i);
          if (cid && rs) why.set(String(cid), rs[1]);
        }
      } catch (e) { B.log(AG, "statusi: iemesli — " + e.message); }
    }
    for (const c of cs) {
      const id = deep(c, /^(asset_id|master_id|media_id|getty_id|id)$/i);
      if (!id) continue;
      const st = deep(c, /^(status|review_status|state|contribution_status)$/i) || "";
      const r = why.get(String(c.id)) || why.get(String(id)) || "";
      all.set(String(id), { id: String(id), file: deep(c, /original_?file_?name|^file_?name$|upload_?file_?name|^filename$/i),
        title: deep(c, /^(title|headline)$/i).slice(0, 250), submitted: deep(c, /submitted_at|created_at|upload_date/i).slice(0, 10),
        status: (st.replace(/_/g, " ") + (r && /reject|revis/i.test(st) ? ": " + r : "")).slice(0, 160) });
    }
    await sleep(250);
  }
  const rows = [...all.values()], f = rows[0];
  B.log(AG, `statusi: ${batches.length} iesniegumi, ${rows.length} bildes` + (f ? `; paraugs: ${f.id}, "${f.file}", ${f.status}` : ""));
  const N = 500, parts = Math.max(1, Math.ceil(rows.length / N));
  if (rows.length) for (let i = 0; i < parts; i++) await send("sub_items", { rows: rows.slice(i * N, (i + 1) * N), part: i + 1, parts });
  await send("sub_done", { full: rows.length > 0 && !!OPTS.sub_full });
}
