/* Dreamstime: www.dreamstime.com/account/earnings-images — saraksts pa 20, ar pircēja meklēšanas vārdiem */
async function collect() {
  if (!/(^|\.)dreamstime\.com$/.test(location.hostname)) throw LOGIN;
  const U = (pg) => `/account/earnings-images?showlicense=all&pg=${pg}`;

  function parse(doc) {
    const out = [];
    let day = "";
    for (const list of doc.querySelectorAll(".account-list")) {
      for (const el of list.children) {
        if (el.classList.contains("account-list__date")) { day = pdate(txt(el)) || day; continue; }
        if (!el.classList.contains("account-list__item")) continue;
        const st = el.querySelector('a[href*="imageid="]');
        const id = st ? (st.getAttribute("href").match(/imageid=(\d+)/) || [])[1] : "";
        const tl = el.querySelector(".account-list__title");
        const img = el.querySelector("img");
        const p = el.querySelector(".account-list__text p") || el.querySelector("p");
        const ptxt = txt(p);
        const strong = p && p.querySelector("strong") ? txt(p.querySelector("strong")) : "";
        const amount = money(strong || ptxt);
        const lic = (strong ? ptxt.replace(strong, "") : ptxt.replace(/^\$?[\d.,]+/, ""))
          .replace(/^\s*\d+%\s*royalty/i, "").replace(/Buyer searched for:.*$/i, "").replace(/\s+/g, " ").trim();
        const qm = txt(el).match(/Buyer searched for:\s*(.+?)(?:\s+Share\b|\s+Stats\b|$)/i);
        if (!day || !amount) continue;
        out.push({ day, id: id || "", title: txt(tl), url: tl ? tl.href : "", thumb: img ? img.getAttribute("src") : "",
          amount, cnt: 1, kind: "sale", license: lic.slice(0, 60), raw: qm ? { q: qm[1].trim() } : null });
      }
    }
    return out;
  }

  let doc = await getdoc(U(1));
  const counter = doc.querySelector(".account-pagination__counter");
  if (!counter && !doc.querySelector(".account-list")) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Dreamstime: neparedzēta lapa");
  }
  const tm = txt(counter).match(/of\s+([\d,]+)/i);
  const pages = tm ? Math.ceil(parseInt(tm[1].replace(/[^\d]/g, ""), 10) / 20) : 1;
  const since = OPTS.mode === "full" ? "0000-00-00" : OPTS.since;
  let rows = [];
  for (let pg = 1; pg <= pages; pg++) {
    say(`${pg}/${pages}`, Math.round((pg / pages) * 90));
    if (pg > 1) { doc = await getdoc(U(pg)); await sleep(250); }
    const r = parse(doc);
    rows = rows.concat(r.filter((x) => x.day >= since));
    if (!r.length || r[r.length - 1].day < since) break;
  }
  await sendRows(rows, { start: OPTS.mode === "full" ? "2000-01-01" : since, end: today });
  try {
    const home = await getdoc("/");
    const b = txt(home.body).match(/\$\s*([\d,.]+)\s*Earnings balance/i);
    if (b) await send("balance", { amount: money(b[1]), currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: jāpieprasa (tikai LASĀM /account/request-payment — nekad nesūtām); vēsture /account/payment-requests */
  await payoutsSafe(async () => {
    const rp = txt((await getdoc("/account/request-payment")).body);
    const bal = rp.match(/current earnings balance:?\s*\$\s*([\d,.]+)/i);
    const mn = rp.match(/minimum payout balance is\s*\$\s*([\d,.]+)/i);
    await sendPayInfo({ unpaid: bal ? money(bal[1]) : null, available: bal ? money(bal[1]) : null, min: mn ? money(mn[1]) : null, currency: "USD" });
    const t = tableObjs(await getdoc("/account/payment-requests"), [/date/i, /value|amount/i]) || [];
    await sendPayouts(t.map((o) => ({ date: pdate(pick(o, /date/)), status: pick(o, /status/),
      amount: Math.round((money(pick(o, /value|amount/)) - Math.abs(money(pick(o, /withheld|tax/)))) * 100) / 100, currency: "USD" }))
      .filter((r) => !r.status || /paid|complet|sent|done/i.test(r.status)));
  });
  /* 2026-11-05 iesniegumu statusi (lietotājs: /upload/under-review, /upload/refused-files, /account/online-files):
     reizi dienā nolasām bilžu ID (+ nosaukums, faila vārds, noraidīšanas iemesls, ja redzams) → Analītiķis (sub_status).
     Pirmajā versijā — tikai pirmā lapa katrā sarakstā; žurnālā paraugs struktūras izpētei. */
  if (OPTS.sub_due || OPTS.port_due) { try { await dtStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["sākumlapa", () => portPage("/", [/online files[^\d]{0,20}(\d[\d,]*)/i, /(\d[\d,]*)\s+online files/i, ...PORT_RE])],
    ["account", () => portPage("/account", [/online files[^\d]{0,20}(\d[\d,]*)/i, /(\d[\d,]*)\s+online files/i, ...PORT_RE])],
  ]);
  return { pages, rows: rows.length };
}

async function dtStatus() {
  /* Lapu uzbūve (lietotāja ekrānuzņēmumi 2026-11-05):
     - /upload/uploads-history — rindas "<datums> · image · <faila nosaukums> · Processed with image ID N"
     - /upload/under-review — kartītes: virsraksts; "ETR: … • Status: Image under review"; "ID N • <fails> • image • …"; "Submitted on MM/DD/YYYY"
     - /upload/refused-files — tāpat (tikai pēdējās 14 dienas! tāpēc lasām katru dienu); tukšai — "No refused files"
     - /account/online-files — kartītes: virsraksts; "N downloads | Level"; "File ID N | Uploaded: 04 November 2026, online since: …";
       jaunākās augšā, 3000+ lapu → lasām, līdz augšupielādes datums vecāks par 60 dienām (maks. 8 lapas) */
  const T = (el) => { const w = []; const it = (el.ownerDocument || el).createTreeWalker(el, 4); let n; while ((n = it.nextNode())) { const v = n.nodeValue.trim(); if (v) w.push(v); } return w.join(" "); };
  const ID_RE = /\b(?:File\s+)?ID\s*:?\s*(\d{6,10})\b/i;
  const card = (el) => { let c = el; while (c.parentElement && ((T(c.parentElement).match(/\bID\s*:?\s*\d{6,10}/gi) || []).length <= 1)) c = c.parentElement; return c; };
  const parse = (d, raw) => {
    const out = new Map();
    const hits = [...d.querySelectorAll("body *")].filter((e) => ID_RE.test(e.textContent || "") && ![...e.children].some((ch) => ID_RE.test(ch.textContent || "")));
    for (const e of hits) {
      const id = (T(e).match(ID_RE) || [])[1];
      if (!id || out.has(id)) continue;
      const c = card(e), t = T(c);
      const h = [...c.querySelectorAll("h1,h2,h3,h4,h5,strong,b,a[href*='image'],a[href*='stock-photo']")]
        .find((x) => { const v = T(x); return v.length > 8 && !ID_RE.test(v) && !/^\d/.test(v); });
      const title = (h ? T(h) : "").slice(0, 250);
      const file = (t.match(/[\w .()\-]+\.(?:jpe?g|tiff?|png|mp4|mov|eps)\b/i) || [""])[0].replace(/^.*?\bID\s*\d+\s*•?\s*/i, "").trim();
      const st = (t.match(/Status:\s*([A-Za-z ]{3,40}?)(?:\s*(?:•|ID\b|$))/i) || [])[1];
      const reason = raw === "Refused" ? ((t.match(/(?:Reason|Refused(?: for| because)?|Refusal reason)\s*:?\s*(.{3,200}?)(?:\s*(?:ID\b|Submitted|$))/i) || [])[1] || "") : "";
      const sub = (t.match(/Submitted on\s*(\d{1,2}\/\d{1,2}\/\d{4})/i) || t.match(/Uploaded:\s*(\d{1,2} \w+ \d{4})/i) || [])[1] || "";
      out.set(id, { id, file, title, status: raw === "Refused" ? `Refused${reason ? ": " + reason.trim() : ""}` : (st && raw !== "Online" ? st.trim() : raw), submitted: sub });
    }
    return out;
  };
  const nextUrl = (d, base, page) => {
    const a = [...d.querySelectorAll("a[href]")].find((x) => /next|›|»|>/i.test((x.getAttribute("aria-label") || "") + (x.getAttribute("rel") || "") + (x.className || "") + T(x)) &&
      new RegExp("[?&/](?:pg|page|p)[=/]?" + (page + 1) + "\\b").test(x.getAttribute("href")));
    return a ? new URL(a.getAttribute("href"), base).href : null;
  };
  const load = async (path, wantRe) => {
    let d = await getdoc(path);
    if (!wantRe.test(T(d.body || d))) {                           // saturs, iespējams, tiek ielādēts ar JS — rāmī
      const f = await framed(path, (t, doc) => (wantRe.test(t) ? doc : null), 25000);
      if (f) d = f;
    }
    return d;
  };
  /* 1) augšupielādes vēsture: fails ↔ ID */
  const fileOf = new Map(), seenAny = new Set();
  try {
    const h = await load("/upload/uploads-history", /image ID\s*\d/i);
    const t = T(h.body || h);
    const re = /([^\s•|][^•|]*?\.(?:jpe?g|tiff?|png|mp4|mov|eps|zip))\s+Processed with image ID\s*(\d{6,10})/gi;
    let m; while ((m = re.exec(t))) fileOf.set(m[2], m[1].replace(/^.*?\b(?:image|video|vector|illustration)\s+/i, "").trim());
    B.log(AG, `statusi: augšupielādes vēsture — ${fileOf.size} faili ar ID`);
  } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: augšupielādes vēsture — " + String((e && e.message) || e).slice(0, 80)); }
  /* 2) saraksti */
  const LISTS = [["/upload/under-review", "In review", 5], ["/upload/refused-files", "Refused", 5], ["/account/online-files", "Online", 8]];
  const old = Date.now() - 60 * 864e5;
  for (const [path, raw, maxPages] of LISTS) {
    const all = new Map();
    let url = path, page = 1, note = "";
    try {
      while (url && page <= maxPages) {
        const d = await load(url, /\bID\s*:?\s*\d{6,}|No refused files|no files/i);
        const got = parse(d, raw);
        for (const [k, v] of got) all.set(k, Object.assign(v, { file: fileOf.get(k) || v.file }));
        if (!got.size) { note = /No refused files/i.test(T(d.body || d)) ? "nav noraidītu" : "teksts: " + T(d.body || d).slice(0, 160); break; }
        if (raw === "Online") {                                    // jaunākās augšā — tālāk tikai, kamēr nav vecākas par 60 d.
          const last = [...got.values()].pop(); const dt = Date.parse(last.submitted || "");
          if (dt && dt < old) break;
        }
        url = nextUrl(d, new URL(url, location.href).href, page);
        page++;
        if (url) await sleep(800);
      }
    } catch (e) { if (e && e.login) throw e; note = String((e && e.message) || e).slice(0, 80); }
    for (const k of all.keys()) seenAny.add(k);
    const f = [...all.values()][0];
    B.log(AG, `statusi: ${path} — ${all.size} bildes, ${page - (url ? 0 : 1) || 1} lapas` + (f ? `; paraugs: ID ${f.id}, "${f.title.slice(0, 40)}", fails "${f.file}", ${f.status}, ${f.submitted}` : "") + (note ? `; ${note}` : ""));
    if (all.size) await send("sub_items", { rows: [...all.values()], part: 1, parts: 1 });
  }
  /* augšupielādētas, bet vēl nevienā sarakstā nav redzētas */
  const rest = [...fileOf].filter(([id]) => !seenAny.has(id)).map(([id, file]) => ({ id, file, title: "", status: "Processed", submitted: "" }));
  if (rest.length) await send("sub_items", { rows: rest, part: 1, parts: 1 });
}
