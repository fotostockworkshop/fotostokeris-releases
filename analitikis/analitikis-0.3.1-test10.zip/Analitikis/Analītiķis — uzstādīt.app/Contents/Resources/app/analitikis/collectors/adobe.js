/* Adobe Stock Contributor: contributor.stock.adobe.com */
async function collect() {
  if (!/(^|\.)contributor\.stock\.adobe\.com$/.test(location.hostname)) throw LOGIN;
  const lang = (location.pathname.match(/^\/([a-z]{2}(?:[-_][A-Za-z]{2})?)\//) || [])[1] || "en";
  const H = { "X-Requested-With": "XMLHttpRequest" };
  const ov = await getj(`/${lang}/user/statistics/overview?time_range=year`, H);
  if (!ov || !ov.sales) throw LOGIN;

  const year = +today.slice(0, 4);
  let ranges = [];
  if (OPTS.mode === "full") {
    for (let y = year; y >= 2005; y--) ranges.push([`${y}-01-01`, y === year ? today : `${y}-12-31`, y]);
  } else {
    ranges.push([OPTS.since, today, null]);
  }
  let total = 0, empty = 0, found = false, balance = null;
  for (let i = 0; i < ranges.length; i++) {
    const [s, e, y] = ranges[i];
    let page = 1, pages = 1, n = 0;
    do {
      say(`${y || s} · ${page}/${pages}`, OPTS.mode === "full" ? Math.min(90, i * 8) : 30);
      const j = await getj(`/${lang}/insights/sales-earnings?start_date=${s}&end_date=${e}&page=${page}`, H);
      const pg = (j.view && j.view.pagination) || {};
      pages = Math.max(1, pg.pages || 1);
      const rows = (j.sales && j.sales.history) || [];
      if (j.sales && j.sales.earnings && j.sales.earnings.available) balance = j.sales.earnings.available;
      n += rows.length;
      await send("sales", { start: s, end: e, page, pages, rows, last: page >= pages });
      page++;
    } while (page <= pages);
    total += n;
    if (OPTS.mode === "full") {
      if (n) { found = true; empty = 0; } else empty++;
      if ((found && empty >= 2) || (!found && empty >= 4)) break;
    }
  }
  if (balance) await send("balance", { amount: balance.amount, currency: balance.currencyCode || "USD" });

  say("Other payments", 95);
  let rows = [], page = 1, pages = 1;
  do {
    const j = await getj(`/${lang}/insights/other-payments?start_date=2005-01-01&end_date=${today}&page=${page}`, H);
    rows = rows.concat((j.insights && j.insights.creditTransactions) || []);
    pages = Math.max(1, ((j.view && j.view.pagination) || {}).pages || 1);
    page++;
  } while (page <= pages && page < 50);
  await send("other", { rows });
  /* izmaksas: jāpieprasa (poga "Payout $X" = pieejams); vēsture — "Payout history" (līdz 2023-02 EUR, tad USD) */
  /* 0.3.1: atlikums ir jau rokā — izmaksu stāvokli atjaunojam katru reizi (ne tikai, kad lasām izmaksu vēsturi) */
  if (balance) await sendPayInfo({ unpaid: balance.amount, available: balance.amount, currency: balance.currencyCode || "USD" });
  /* 2026-11-06 (lietotāja ekrānuzņēmums): tabulā 92 izmaksas 2 lapās — 1. lapā jaunākās (2022-10 … šodien, augšā vecākā),
     2. lapā vecākās → lasām visas lapas. Statuss "Pending" = pieprasīta, vēl ceļā → arī to (saņemšana ≈ datums + 9 d). */
  await payoutsSafe(async () => {
    const all = new Map(); let url = `/${lang}/sales/conversions`, heads = "";
    for (let p = 1; url && p <= 12; p++) {
      const d = await getdoc(url);
      const t = tableObjs(d, [/date/i, /amount|total/i]);
      if (!t) { heads = [...d.querySelectorAll("th, [role=columnheader]")].slice(0, 10).map(txt).join(" | "); break; }
      const before = all.size;
      for (const o of t) { const a = pick(o, /amount|total/), r = { date: pdate(pick(o, /date/)), amount: money(a), currency: curOf(a), status: pick(o, /status/) }; if (r.date) all.set(r.date + "|" + r.amount, r); }
      if (all.size === before) break;                          // tā pati lapa — lappuses parametrs neder
      const nx = [...d.querySelectorAll("a[href]")].find((a) => /[?&]page=\d+/.test(a.getAttribute("href")) && +(a.getAttribute("href").match(/[?&]page=(\d+)/) || [])[1] === p + 1);
      url = nx ? nx.getAttribute("href") : `/${lang}/sales/conversions?page=${p + 1}`;
      await sleep(500);
    }
    if (!all.size) { B.log(AG, "izmaksu tabula nav atrasta; virsraksti: " + heads); return; }
    const rows = [...all.values()].filter((r) => !/fail|cancel|reject/i.test(r.status)).sort((a, b) => (a.date < b.date ? 1 : -1));
    const pend = rows.filter((r) => /pending|process/i.test(r.status));
    if (pend.length) B.log(AG, "izmaksas ceļā (Pending): " + pend.map((r) => `${r.date} ${r.amount}`).join(", "));
    await sendPayouts(rows);
  });
  const pn = await portfolioSafe([
    ["sākumlapa (All)", () => framed(`/${lang}/`, (t) => { const m = t.match(/\bAll\s*\(\s*([\d,.]+)\s*\)/); return m ? numOf(m[1]) : null; })],
    ["statistics/overview", async () => { const n = countKey(ov, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: overview atslēgas: " + keysOf(ov)); return n; }],
    ["portfolio/stats", () => portJson(`/${lang}/portfolio/stats`, H)],
    ["user/statistics/portfolio", () => portJson(`/${lang}/user/statistics/portfolio`, H)],
    ["dashboard", () => portPage(`/${lang}/dashboard`)],
  ]);
  if (OPTS.sub_due) { try { await adStatus(lang, H); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  if (!pn) { const r = await portNav(`/${lang}/`, "\\bAll\\s*\\(\\s*([\\d,.]+)\\s*\\)", "sākumlapa (All)"); if (r) return r; }
  return { sales: total, other: rows.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06):
   /<lang>/uploads/review — "In review" (labajā panelī: virsraksts, "Submitted N hours ago");
   /<lang>/uploads/rejected — "Not accepted" (3457 bildes, 35 lapas; panelī: iemesls, piem. "INTELLECTUAL PROPERTY REFUSAL",
     "File ID: N", "Original name: 1dbd_….jpg");
   /<lang>/portfolio?limit=100&page=N&sort_by=create_desc — pieņemtās, jaunākās augšā (27 377, 274 lapas).
   Avots pēc kārtas: (1) tā pati adrese kā JSON (X-Requested-With, kā pārdošanām); (2) JSON, ko lapa ielādē rāmī;
   (3) lapas teksts — katru sīktēlu uzklikšķinot un nolasot paneli. Pirmajā reizē noraidītās — visas lapas, tālāk 2 lapas. */
async function adStatus(lang, H) {
  /* lapas teksts: sīktēlus uzklikšķinot, labajā panelī "File ID", "Original name", iemesls (lielajiem burtiem) */
  const dom = async (doc, raw) => {
    const rows = new Map();
    const tiles = [...doc.querySelectorAll("img")].filter((i) => i.width > 80 && i.height > 60 && !i.closest("header, nav, footer"));
    for (const im of tiles.slice(0, 120)) {
      (im.closest("button, a, [role=button], [tabindex]") || im).click();
      await sleep(350);
      const t = doc.body.innerText || "";
      const id = (t.match(/File ID:\s*(\d{6,12})/i) || [])[1];
      if (!id || rows.has(id)) continue;
      const reason = (t.match(/\n\s*([A-Z][A-Z &/,'-]{6,80}(?:REFUSAL|REJECT\w*|ISSUES?|QUALITY|SIMILAR\w*|PROBLEM\w*|INFRINGEMENT|CONTENT))\s*\n/) || [])[1] || "";
      rows.set(id, { id, file: (t.match(/Original name:\s*(\S+)/i) || [])[1] || "", title: (t.match(/Title:\s*([^\n]{3,250})/i) || [])[1] || "",
        submitted: "", status: raw + (reason ? ": " + reason.trim() : "") });
    }
    return [...rows.values()];
  };
  await subLists([{ path: `/${lang}/uploads/review`, raw: "In review", max: 10 },
                  { path: `/${lang}/uploads/rejected`, raw: "Not accepted", max: OPTS.sub_full ? 40 : 2 },
                  { path: `/${lang}/portfolio?limit=100&sort_by=create_desc`, raw: "Approved", max: 2 }], { direct: true, H, dom, need: /thumb|content_?id|original|media_?(id|type)|preview/i });
}
