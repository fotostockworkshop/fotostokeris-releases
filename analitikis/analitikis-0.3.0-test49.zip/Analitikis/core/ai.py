"""Pieslēgumi (noteikumi §5 p.2): AI pakalpojumi un OneDrive — kopīgi visiem moduļiem.

Pieslēgumi (id):
  claude_sub  — Claude abonements caur Claude Code (`claude auth login` atver Anthropic oficiālo lapu)
  chatgpt_sub — ChatGPT abonements caur Codex (`codex login` atver OpenAI oficiālo lapu)
  claude_api  — Anthropic API atslēga        (drošajā glabātuvē: ai:claude)
  openai_api  — OpenAI API atslēga           (ai:openai)
  gemini_api  — Google Gemini API atslēga    (ai:gemini; bezmaksas līmenis Google AI Studio)
  ollama      — lokālie modeļi datorā (127.0.0.1:11434), neobligāti
Programma paroli nekad neprasa. Patēriņš: record() pēc katras AI atbildes (tokeni → aptuvenā cena pēc PRICES).
Limitu programma neuzstāda (lietotāja lēmums 2026-10-30) — rāda iztērēto un, ja zināms, atlikumu.
CLI daļa pārņemta no Vārdotāja (vardotajs/ai.py, codex.py) bez uzvedības izmaiņām.
"""
from __future__ import annotations

import datetime as dt
import glob
import json
import os
import re
import shlex
import shutil
import subprocess
import threading
import urllib.error
import urllib.request
from pathlib import Path

from . import config, credentials

IS_WIN = config.IS_WIN
NO_WINDOW = 0x08000000 if IS_WIN else 0
NEW_CONSOLE = 0x00000010 if IS_WIN else 0

PROVIDERS = ("claude_sub", "chatgpt_sub", "claude_api", "openai_api", "gemini_api", "ollama")
KEYED = {"claude_api": "ai:claude", "openai_api": "ai:openai", "gemini_api": "ai:gemini"}
KEY_PAGES = {"claude_api": "https://platform.claude.com/settings/keys",
             "openai_api": "https://platform.openai.com/api-keys",
             "gemini_api": "https://aistudio.google.com/apikey",
             "ollama": "https://ollama.com/download"}
# Aptuvenās cenas $ par 1 M tokenu (ievade, izvade) — pārbaudīts 2026-10-30 (publiskas cenu lapas); pēc modeļa nosaukuma daļas.
PRICES = [("opus", 4.0, 20.0), ("sonnet", 2.0, 10.0), ("haiku", 0.10, 0.50), ("fable", 10.0, 50.0),
          ("gpt-5-nano", 0.05, 0.40), ("gpt-5-mini", 0.25, 2.0), ("gpt-5.4-mini", 0.75, 4.50), ("gpt-5.5", 5.0, 30.0),
          ("flash-lite", 0.25, 1.50), ("flash", 1.50, 9.0), ("gemini", 2.0, 12.0)]


class AIError(Exception):
    pass


# --------------------------------------------------------------------------- palīgi

def _env(drop: tuple = ()) -> dict:
    env = dict(os.environ)
    for k in drop:                       # API atslēga vidē liktu CLI maksāt no API konta abonementa vietā
        env.pop(k, None)
    extra = [str(Path.home() / ".local" / "bin"), "/opt/homebrew/bin", "/usr/local/bin"]
    if IS_WIN:
        local = os.environ.get("LOCALAPPDATA", str(Path.home() / "AppData" / "Local"))
        extra.append(os.path.join(local, "Programs", "OpenAI", "Codex", "bin"))
    env["PATH"] = os.pathsep.join([env.get("PATH", "")] + extra)
    env.setdefault("NO_COLOR", "1")
    return env


CLAUDE_ENV = ("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN")
CODEX_ENV = ("OPENAI_API_KEY", "CODEX_API_KEY")


def _find(name: str, custom_key: str, extra_win: list[str], extra_nix: list[str], npm_js: str) -> list[str] | None:
    home = Path.home()
    c = []
    custom = str(config.get(custom_key) or "").strip().strip('"')
    if custom:
        c.append(custom)
    w = shutil.which(name)
    if w:
        c.append(w)
    if IS_WIN:
        c += extra_win
    else:
        c += extra_nix
        c += sorted(glob.glob(str(home / ".nvm" / "versions" / "node" / "*" / "bin" / name)), reverse=True)
    for p in c:
        if p and os.path.isfile(p):
            if IS_WIN and p.lower().endswith((".cmd", ".bat")):
                base = os.path.dirname(p)
                js = os.path.join(base, "node_modules", *npm_js.split("/"))
                node = os.path.join(base, "node.exe")
                node = node if os.path.isfile(node) else shutil.which("node")
                if os.path.isfile(js) and node:
                    return [node, js]
                continue
            return [p]
    return None


def find_claude() -> list[str] | None:
    home = Path.home()
    appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
    local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
    return _find("claude", "claude_path",
                 [str(home / ".local" / "bin" / "claude.exe"), str(home / ".claude" / "local" / "claude.exe"),
                  os.path.join(local, "Programs", "claude", "claude.exe"),
                  os.path.join(local, "Microsoft", "WinGet", "Links", "claude.exe"), os.path.join(appdata, "npm", "claude.cmd")],
                 [str(home / ".local" / "bin" / "claude"), str(home / ".claude" / "local" / "claude"),
                  "/opt/homebrew/bin/claude", "/usr/local/bin/claude", str(home / ".npm-global" / "bin" / "claude")],
                 "@anthropic-ai/claude-code/cli.js")


def find_codex() -> list[str] | None:
    home = Path.home()
    appdata = os.environ.get("APPDATA", str(home / "AppData" / "Roaming"))
    local = os.environ.get("LOCALAPPDATA", str(home / "AppData" / "Local"))
    return _find("codex", "codex_path",
                 [os.path.join(local, "Programs", "OpenAI", "Codex", "bin", "codex.exe"), str(home / ".local" / "bin" / "codex.exe"),
                  os.path.join(local, "Microsoft", "WinGet", "Links", "codex.exe"), os.path.join(appdata, "npm", "codex.cmd")],
                 [str(home / ".local" / "bin" / "codex"), "/opt/homebrew/bin/codex", "/usr/local/bin/codex",
                  str(home / ".npm-global" / "bin" / "codex")],
                 "@openai/codex/bin/codex.js")


def _run(cmd: list[str], env_drop: tuple, timeout=60) -> tuple[int, str]:
    r = subprocess.run(cmd, capture_output=True, timeout=timeout, env=_env(env_drop), creationflags=NO_WINDOW)
    return r.returncode, (r.stdout + r.stderr).decode("utf-8", "replace").strip()


def _terminal(args: list[str], env_drop: tuple = ()) -> dict:
    """Atver termināļa logu ar komandu (pieslēgšanās notiek pakalpojuma oficiālajā lapā pārlūkā)."""
    env = _env(env_drop)
    if IS_WIN:
        subprocess.Popen(["cmd.exe", "/k"] + args, creationflags=NEW_CONSOLE, env=env)
        return {"mode": "terminal"}
    if config.IS_MAC:
        line = " ".join(shlex.quote(a) for a in args)
        script = f'tell application "Terminal"\nactivate\ndo script "{line}"\nend tell'
        subprocess.Popen(["osascript", "-e", script])
        return {"mode": "terminal"}
    for term in (["x-terminal-emulator", "-e"], ["gnome-terminal", "--"], ["konsole", "-e"], ["xterm", "-e"]):
        if shutil.which(term[0]):
            subprocess.Popen(term + args, env=env)
            return {"mode": "terminal"}
    raise AIError(" ".join(args))


INSTALL = {
    "claude_sub": {"win": "irm https://claude.ai/install.ps1 | iex", "nix": "curl -fsSL https://claude.ai/install.sh | bash"},
    "chatgpt_sub": {"win": "try { Add-Type -AssemblyName System.Runtime.InteropServices.RuntimeInformation } catch {}; "
                           "irm https://chatgpt.com/codex/install.ps1 | iex",
                    "nix": "curl -fsSL https://chatgpt.com/codex/install.sh | sh"},
}


def install(p: str) -> dict:
    """Atver termināli ar oficiālo uzstādītāju (Claude Code / Codex)."""
    if p not in INSTALL:
        raise AIError("install")
    if IS_WIN:
        ps = shutil.which("pwsh") or "powershell.exe"
        subprocess.Popen([ps, "-NoExit", "-ExecutionPolicy", "Bypass", "-Command", INSTALL[p]["win"]], creationflags=NEW_CONSOLE)
        return {"mode": "terminal"}
    cmdline = INSTALL[p]["nix"] + "; echo; echo 'Gatavs — atgriezies programmā. / Done — go back to the app.'"
    if config.IS_MAC:
        script = 'tell application "Terminal"\nactivate\ndo script "' + cmdline.replace("\\", "\\\\").replace('"', '\\"') + '"\nend tell'
        subprocess.Popen(["osascript", "-e", script])
        return {"mode": "terminal"}
    return _terminal(["bash", "-c", cmdline + "; exec bash"])


# --------------------------------------------------------------------------- pieslēgšana ar vienu pogu (test48)
# Viens Terminal logs: (ja vajag) uzstādīšana → pieslēgšanās pakalpojuma oficiālajā lapā. Mūsu teksti logā — programmas
# valodā (noteikumi §6); Anthropic/OpenAI pašu teksti paliek angliski. Mac — .command fails + `open` (bez AppleScript,
# tāpēc macOS neprasa "control Terminal" atļauju).

MSG = {
    "lv": {"install": "Lejupielādē un uzstāda {n} (~100 MB). Pagaidi — tas var aizņemt dažas minūtes, logā tikmēr var nebūt jaunu rindu…",
           "path": "Ja augstāk redzi piezīmi par PATH — tā nav svarīga, programma {n} atrod pati.",
           "login": "Tagad atvērsies pārlūks ar oficiālo pieslēgšanās lapu — ielogojies ar vajadzīgo kontu un apstiprini.",
           "done": "Gatavs! Vari aizvērt šo logu — programmā rinda kļūs zaļa pati.",
           "fail": "Neizdevās. Aizver šo logu un mēģini vēlreiz (programmā — “Pieslēgt”)."},
    "en": {"install": "Downloading and installing {n} (~100 MB). Please wait — it can take a few minutes, and the window may show nothing new meanwhile…",
           "path": "If you see a note about PATH above — it does not matter, the program finds {n} by itself.",
           "login": "A browser with the official sign-in page will open now — sign in with the account you want and confirm.",
           "done": "Done! You can close this window — the row in the program will turn green by itself.",
           "fail": "It did not work. Close this window and try again (in the program — “Connect”)."},
}
SUBS = {"claude_sub": {"name": "Claude Code", "bin": "claude", "login": ["auth", "login", "--claudeai"], "env": CLAUDE_ENV,
                       "find": lambda: find_claude()},
        "chatgpt_sub": {"name": "Codex", "bin": "codex", "login": ["login"], "env": CODEX_ENV, "find": lambda: find_codex()}}


def _msg(k: str, n: str) -> str:
    lang = "en" if str(config.get("lang") or "lv") == "en" else "lv"
    return MSG[lang][k].format(n=n)


def connect(p: str) -> dict:
    """Viena poga "Pieslēgt": Terminal logā uzstāda (ja vajag) un atver oficiālo pieslēgšanos."""
    if p not in SUBS:
        raise AIError("connect")
    s = SUBS[p]
    have = s["find"]()
    d = config.app_dir()
    if IS_WIN:
        q = lambda t: "'" + t.replace("'", "''") + "'"
        lines = ["$ErrorActionPreference = 'Continue'"] + [f"Remove-Item Env:{k} -ErrorAction SilentlyContinue" for k in s["env"]]
        if not have:
            lines += [f"Write-Host {q(_msg('install', s['name']))} -ForegroundColor Cyan", INSTALL[p]["win"],
                      f"Write-Host ''; Write-Host {q(_msg('path', s['name']))} -ForegroundColor DarkGray"]
        lines += ["$env:Path += ';' + $env:USERPROFILE + '\\.local\\bin;' + $env:LOCALAPPDATA + '\\Programs\\OpenAI\\Codex\\bin'",
                  f"$b = {q(have[-1]) if have and len(have) == 1 else '$null'}",
                  f"if (-not $b) {{ $c = Get-Command {s['bin']} -ErrorAction SilentlyContinue; if ($c) {{ $b = $c.Source }} }}",
                  f"Write-Host ''; Write-Host {q(_msg('login', s['name']))} -ForegroundColor Cyan",
                  f"if ($b) {{ & $b {' '.join(s['login'])}; if ($LASTEXITCODE -eq 0) {{ Write-Host ''; Write-Host {q(_msg('done', s['name']))} -ForegroundColor Green }} "
                  f"else {{ Write-Host {q(_msg('fail', s['name']))} -ForegroundColor Yellow }} }} else {{ Write-Host {q(_msg('fail', s['name']))} -ForegroundColor Yellow }}"]
        f = d / f"pieslegt-{p}.ps1"
        f.write_text("\r\n".join(lines), encoding="utf-8-sig")
        ps = shutil.which("pwsh") or "powershell.exe"
        subprocess.Popen([ps, "-NoExit", "-ExecutionPolicy", "Bypass", "-File", str(f)], creationflags=NEW_CONSOLE)
        return {"mode": "terminal"}
    q = lambda t: "'" + t.replace("'", "'\\''") + "'"
    lines = ["#!/bin/bash", "clear", "unset " + " ".join(s["env"]), 'export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"']
    if not have:
        lines += [f"echo {q(_msg('install', s['name']))}; echo", INSTALL[p]["nix"], f"echo; echo {q(_msg('path', s['name']))}"]
    lines += [f"B={shlex.quote(have[-1]) if have and len(have) == 1 else ''}",
              f'[ -n "$B" ] || B="$(command -v {s["bin"]})"; [ -n "$B" ] || B="$HOME/.local/bin/{s["bin"]}"',
              f"echo; echo {q(_msg('login', s['name']))}; echo",
              f'if "$B" {" ".join(s["login"])}; then echo; echo {q(_msg("done", s["name"]))}; else echo; echo {q(_msg("fail", s["name"]))}; fi']
    f = d / f"pieslegt-{p}.command"
    f.write_text("\n".join(lines) + "\n", encoding="utf-8")
    os.chmod(f, 0o755)
    if config.IS_MAC:
        subprocess.Popen(["open", "-a", "Terminal", str(f)])
        return {"mode": "terminal"}
    return _terminal(["bash", str(f)])


def switch(p: str) -> dict:
    """"Mainīt kontu": atslēdz un uzreiz atver pieslēgšanos (pārlūkā jābūt ielogotam vajadzīgajā kontā)."""
    logout(p)
    return connect(p)


# --------------------------------------------------------------------------- atslēgas

def key(p: str) -> str:
    c = credentials.get(KEYED[p]) if p in KEYED else None
    if c and c[1]:
        return c[1]
    legacy = {"claude_api": "api_key", "openai_api": "openai_key"}.get(p)   # Vārdotāja vecās atslēgas settings.json
    return str(config.get(legacy) or "") if legacy else ""


def key_save(p: str, value: str) -> None:
    if p not in KEYED or not (value or "").strip():
        raise AIError("key")
    credentials.save(KEYED[p], "", value.strip())


def key_forget(p: str) -> None:
    if p in KEYED:
        credentials.forget(KEYED[p])


def _http(url: str, headers: dict | None = None, timeout: float = 15) -> dict:
    from .updater import _ssl_ctx
    req = urllib.request.Request(url, headers=headers or {})
    ctx = None if url.startswith("http://") else _ssl_ctx()
    with urllib.request.urlopen(req, timeout=timeout, context=ctx) as r:
        return json.loads(r.read(2_000_000).decode("utf-8", "replace") or "{}")


# --------------------------------------------------------------------------- stāvoklis un pārbaude

def ollama_url() -> str:
    return os.environ.get("OLLAMA_HOST", "http://127.0.0.1:11434").rstrip("/")


def status() -> dict:
    """Ātrs pārskats (bez tīkla, izņemot Ollama 0,5 s): kas uzstādīts / kam ir atslēga."""
    out = {}
    out["claude_sub"] = {"installed": bool(find_claude())}
    out["chatgpt_sub"] = {"installed": bool(find_codex())}
    for p in KEYED:
        out[p] = {"key": bool(key(p))}
    try:
        tags = _http(ollama_url() + "/api/tags", timeout=0.5)
        out["ollama"] = {"running": True, "models": [m.get("name", "") for m in tags.get("models", [])][:30]}
    except Exception:
        out["ollama"] = {"running": False, "models": []}
    try:
        from .server import _onedrive
        od = str(config.get("onedrive_dir") or "") or _onedrive()
    except Exception:
        od = ""
    out["onedrive"] = {"path": od}
    month = dt.date.today().strftime("%Y-%m")
    u = usage().get(month, {})
    bal = config.get("ai_balance") or {}
    for p in PROVIDERS:
        s = out.setdefault(p, {})
        s["spent"] = u.get(p, {})
        if p in bal:
            b = bal[p]
            since = sum(v.get("usd", 0) for m, mm in usage().items() if m >= str(b.get("at", ""))[:7] for q, v in mm.items() if q == p)
            s["balance"] = {"amount": b.get("amount"), "at": b.get("at"), "left": round(float(b.get("amount") or 0) - since, 2)}
        lim = _limits.get(p)
        if lim:
            s["limit"] = lim
    return out


def check(p: str) -> dict:
    """Īsta pārbaude (var aizņemt dažas sekundes). Neko nemaksā (tikai saraksti/stāvoklis)."""
    try:
        if p == "claude_sub":
            cmd = find_claude()
            if not cmd:
                return {"ok": False, "why": "not_installed"}
            rc, out = _run(cmd + ["auth", "status", "--json"], CLAUDE_ENV)
            m = re.search(r"\{.*\}", out, re.S)
            d = json.loads(m.group(0)) if m else {}
            acc = d.get("account") if isinstance(d.get("account"), dict) else {}
            email = d.get("email") or d.get("emailAddress") or acc.get("email") or acc.get("emailAddress") or ""
            plan = d.get("subscriptionType") or d.get("plan") or acc.get("subscriptionType") or ""
            return {"ok": bool(d.get("loggedIn")), "who": email, "plan": plan, "why": "" if d.get("loggedIn") else "not_logged_in"}
        if p == "chatgpt_sub":
            cmd = find_codex()
            if not cmd:
                return {"ok": False, "why": "not_installed"}
            rc, out = _run(cmd + ["login", "status"], CODEX_ENV)
            logged = rc == 0 and "not logged in" not in out.lower()
            return {"ok": logged, "who": out.splitlines()[0] if out else "", "why": "" if logged else "not_logged_in"}
        if p == "claude_api":
            k = key(p)
            if not k:
                return {"ok": False, "why": "no_key"}
            d = _http("https://api.anthropic.com/v1/models", {"x-api-key": k, "anthropic-version": "2023-06-01"})
            return {"ok": True, "models": [m.get("id") for m in d.get("data", [])][:20]}
        if p == "openai_api":
            k = key(p)
            if not k:
                return {"ok": False, "why": "no_key"}
            d = _http("https://api.openai.com/v1/models", {"Authorization": "Bearer " + k})
            return {"ok": True, "models": sorted(m.get("id") for m in d.get("data", []) if re.match(r"(gpt|o\d)", m.get("id", "")))[:30]}
        if p == "gemini_api":
            k = key(p)
            if not k:
                return {"ok": False, "why": "no_key"}
            d = _http("https://generativelanguage.googleapis.com/v1beta/models", {"x-goog-api-key": k})
            return {"ok": True, "models": [m.get("name", "").replace("models/", "") for m in d.get("models", [])
                                           if "generateContent" in (m.get("supportedGenerationMethods") or [])][:30]}
        if p == "ollama":
            d = _http(ollama_url() + "/api/tags", timeout=2)
            ms = [m.get("name", "") for m in d.get("models", [])]
            return {"ok": True, "models": ms, "why": "" if ms else "no_models"}
    except urllib.error.HTTPError as e:
        return {"ok": False, "why": "http_%d" % e.code}
    except Exception as e:
        return {"ok": False, "why": "error", "detail": str(e)[:160]}
    return {"ok": False, "why": "unknown"}


def login(p: str) -> dict:
    if p == "claude_sub":
        cmd = find_claude()
        if not cmd:
            raise AIError("not_installed")
        return _terminal(cmd + ["auth", "login", "--claudeai"], CLAUDE_ENV)
    if p == "chatgpt_sub":
        cmd = find_codex()
        if not cmd:
            raise AIError("not_installed")
        return _terminal(cmd + ["login"], CODEX_ENV)
    raise AIError("login")


def logout(p: str) -> None:
    if p == "claude_sub" and find_claude():
        _run(find_claude() + ["auth", "logout"], CLAUDE_ENV)
    elif p == "chatgpt_sub" and find_codex():
        _run(find_codex() + ["logout"], CODEX_ENV)
    elif p in KEYED:
        key_forget(p)


# --------------------------------------------------------------------------- patēriņš

_lock = threading.Lock()
_limits: dict = {}            # pieslēgums -> {"at": ISO, "reset": teksts} (tikai šajā palaišanā)


def _usage_file() -> Path:
    return config.app_dir() / "ai_usage.json"


def usage() -> dict:
    try:
        return json.loads(_usage_file().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def price(model: str) -> tuple[float, float] | None:
    m = (model or "").lower()
    for part, pin, pout in PRICES:
        if part in m:
            return pin, pout
    return None


def record(p: str, model: str = "", tin: int = 0, tout: int = 0, usd: float | None = None) -> None:
    """Pēc katras AI atbildes. Abonementiem (claude_sub/chatgpt_sub) un Ollama nauda netiek skaitīta — tikai tokeni."""
    if p not in PROVIDERS:
        return
    if usd is None:
        pr = price(model) if p in ("claude_api", "openai_api", "gemini_api") else None
        usd = (tin * pr[0] + tout * pr[1]) / 1e6 if pr else 0.0
    month = dt.date.today().strftime("%Y-%m")
    with _lock:
        d = usage()
        v = d.setdefault(month, {}).setdefault(p, {"n": 0, "tin": 0, "tout": 0, "usd": 0.0})
        v["n"] += 1
        v["tin"] += int(tin or 0)
        v["tout"] += int(tout or 0)
        v["usd"] = round(v["usd"] + float(usd or 0), 6)
        f = _usage_file()
        tmp = f.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, f)


def note_limit(p: str, reset: str = "") -> None:
    """Pakalpojums atbildēja "limits sasniegts" (atjaunosies …) — saskarnei."""
    _limits[p] = {"at": dt.datetime.now().isoformat(timespec="minutes"), "reset": reset[:80]}


def order(job: str) -> list[str]:
    """Kuri pieslēgumi šim darbam un kādā secībā (ai_roles); tukšs — moduļa noklusējums."""
    roles = config.get("ai_roles") or {}
    return [p for p in roles.get(job, []) if p in PROVIDERS]
