# Bannera šrifti

Abi faili ir **pārveidotas versijas** (apgriezti līdz vajadzīgajiem burtiem, svars 700) šriftiem ar SIL Open Font License 1.1.
Licence prasa: pārveidotai versijai **nedrīkst** lietot rezervēto nosaukumu (Reserved Font Name), tāpēc tās nosauktas citādi;
autortiesību paziņojums un licences teksts jāglabā kopā ar failiem (`OFL-*.txt`); šriftus nedrīkst pārdot atsevišķi.

| Fails | Iekšējais nosaukums | Pamatā | Licence |
|---|---|---|---|
| `BannerSerif-Bold.ttf` | Banner Serif Bold | Copyright 2012 The Libre Baskerville Project Authors | `OFL-LibreBaskerville.txt` |
| `BannerSerifCyr-Bold.ttf` | Banner Serif Cyr Bold | Copyright 2011 The Lora Project Authors | `OFL-Lora.txt` |

Avots: github.com/google/fonts (`ofl/librebaskerville`, `ofl/lora`). Kā pārveidots — `docs/sakuma-banneris.md` §3.
