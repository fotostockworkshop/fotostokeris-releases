"use strict";
/* Kopīgais sākuma banneris (docs/sakuma-banneris.md) — 0.3.1 no analitikis/dev/banner/banner.html (apstiprināts 2026-10-31).
   Modulis pirms core.js definē window.BANNER = { img, l10n: {lang: {title, steps[6]}}, face, title, nodes, hubs, wave, titlePos? }.
   CoreBanner.start(lang, version) — rāda; klikšķis aizver; pēc ~6,5 s aizveras pats; drošībai — 15 s. */
window.CoreBanner = (function () {
  const B = window.BANNER || {};
  const CSS = `
  /* Izmēri — tieši kā Vārdotāja banerim (vardotajs/web/app.css "sākuma banneris"): 16:9, ≤800 px, attēls 1600×900 */
    .bn-wrap { position: fixed; inset: 0; z-index: 120; display: grid; place-items: center;
    background: radial-gradient(ellipse at 30% 20%, #23303d, #0f1318 70%); transition: opacity .7s ease; }
  .bn-wrap.hide { opacity: 0; pointer-events: none; }
  .bn { position: relative; width: min(800px, 92vw); aspect-ratio: 16 / 9; border-radius: 14px; overflow: hidden; cursor: pointer;
    box-shadow: 0 30px 80px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.06); background: #000;
    opacity: 0; transform: scale(.96); transition: opacity .6s ease, transform .8s cubic-bezier(.2,.8,.2,1); }
  .bn-wrap.show .bn { opacity: 1; transform: scale(1); }
  .bn-wrap.hide .bn { transform: scale(1.03); }
  .bn img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: block; }
  .bn canvas { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }
  .bn-foot { position: absolute; left: 0; right: 0; bottom: 0; padding: 0 14px 9px; pointer-events: none;
    background: linear-gradient(to top, rgba(0,0,0,.72), rgba(0,0,0,0)); }
  .bn-row { display: flex; justify-content: space-between; align-items: flex-end; padding-top: 26px; margin-bottom: 6px;
    font-size: 11.5px; color: #d6f4ff; }
  #bnStep { opacity: .9; letter-spacing: .2px; }
  #bnVer { opacity: .6; font-size: 11px; letter-spacing: .6px; }
  .bn-bar { height: 3px; border-radius: 3px; background: rgba(255,255,255,.14); overflow: hidden; }
  .bn-bar i { display: block; height: 100%; width: 0; border-radius: 3px; transition: width .35s ease;
    background: linear-gradient(90deg, #2bb3ff, #6fe3ff, #b8ffd9); box-shadow: 0 0 8px #6fe3ff; }
  @font-face { font-family: "BannerTitle"; src: url("/core/fonts/BannerSerif-Bold.ttf") format("truetype"); font-weight: 700; }
  @font-face { font-family: "BannerTitleCyr"; src: url("/core/fonts/BannerSerifCyr-Bold.ttf") format("truetype"); font-weight: 700; }
`;
  let LANG = "lv", STEPS = [], L10N = B.l10n || {};
  const FACE = B.face || { x: 0.5, y: 0.3, rx: 0.08, ry: 0.15 };
  const TITLE = B.title || { x0: 0.3, x1: 0.7, y0: 0.74, y1: 0.93 };
  const NODES = B.nodes || [], HUBS = B.hubs || [[0.6, 0.4]], WAVE = B.wave || [0.6, 0.4];
  const AT = [0, 0.14, 0.34, 0.54, 0.74, 0.93];
  const DUR = 6500;
  
  /* vietas attēlā (daļas no platuma/augstuma) — šim foto */
  
  const $ = (s) => document.querySelector(s);
  const S = { raf: 0, closing: false, t0: 0, last: 0, rain: [], cards: [], huds: [], pulses: [], flash: 0, wave: -1 };
  let W = 0, H = 0, cx;
  
  function size() {
    const card = $("#bnCard"), cv = $("#bnFx"), r = card.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    W = r.width; H = r.height; cv.width = W * d; cv.height = H * d; cx = cv.getContext("2d"); cx.setTransform(d, 0, 0, d, 0, 0);
    initRain(); drawTitle();
  }
  /* cik spilgti drīkst zīmēt šajā vietā (0..1): seja, nosaukums, apakšējā josla — klusāk */
  function mask(x, y) {
    const fx = (x / W - FACE.x) / FACE.rx, fy = (y / H - FACE.y) / FACE.ry;
    let m = 1;
    const fd = fx * fx + fy * fy; if (fd < 1) m *= 0.15 + 0.85 * fd;
    const tx = x / W, ty = y / H;
    if (tx > TITLE.x0 && tx < TITLE.x1 && ty > TITLE.y0 - 0.06) m *= Math.max(0, (TITLE.y0 - ty) / 0.06);
    if (ty > 0.86) m *= Math.max(0, (0.93 - ty) / 0.07);
    return Math.max(0, m);
  }
  
  /* ---- 1. "Matrix" lietus: 0 un 1, retumis $ € % un cipari */
  const GLYPH = () => { const r = Math.random(); return r < 0.86 ? (Math.random() < 0.5 ? "0" : "1") : "$€%23456789"[Math.floor(Math.random() * 11)]; };
  function initRain() {
    const fs = Math.max(24, Math.round(W / 24)),   /* 22:03 lietotājs: 2,5× lielāks */ cols = Math.ceil(W / (fs * 1.15));
    S.fs = fs;
    /* 21:58 lietotājs: lietus nebija redzams → visas kolonnas, jau no sākuma pa visu banneri, garākas virknes */
    S.rain = Array.from({ length: cols }, (_, i) => ({ x: i * fs * 1.15 + fs * 0.3, y: Math.random() * H * 1.3, v: 0.045 + Math.random() * 0.08,
      len: 12 + Math.floor(Math.random() * 18), g: Array.from({ length: 30 }, GLYPH), on: Math.random() < 0.9 }));
  }
  function drawRain(dt) {
    const fs = S.fs; cx.font = `${fs}px ui-monospace, Menlo, Consolas, monospace`; cx.textAlign = "center";
    for (const c of S.rain) {
      if (!c.on) { if (Math.random() < 0.01 * dt / 16) { c.on = true; c.y = -c.len * fs; } continue; }
      c.y += c.v * dt;
      if (Math.random() < 0.05) c.g[Math.floor(Math.random() * c.g.length)] = GLYPH();
      for (let i = 0; i < c.len; i++) {
        const y = c.y - i * fs; if (y < -fs || y > H) continue;
        const m = mask(c.x, y); if (m <= 0.01) continue;
        const head = i === 0, a = (head ? 0.6 : 0.3 * (1 - i / c.len) + 0.04) * m;   /* 22:09: caurspīdīgāki */
        cx.fillStyle = head ? `rgba(255,255,255,${a})` : `rgba(205,255,232,${a})`;   /* 22:09: baltāki */
        if (head) { cx.shadowColor = "#e6fff4"; cx.shadowBlur = 6; }
        cx.fillText(c.g[i % c.g.length], c.x, y);
        if (head) cx.shadowBlur = 0;
      }
      if (c.y - c.len * fs > H) { c.on = Math.random() < 0.9; c.y = -Math.random() * H * 0.5; c.v = 0.035 + Math.random() * 0.07; }
    }
  }
  
  /* ---- 2. lidojošas bildes (programmā — lietotāja labāko bilžu sīktēli; šeit — zīmētas ainavas) */
  const SKIES = [["#ffb36b", "#6a4cc2"], ["#7fd3ff", "#2a5fb0"], ["#ffd27a", "#d0577a"], ["#a6f0c6", "#2f7d6b"], ["#c7a6ff", "#3d3a8f"]];
  function spawnCard() {
    const w = W * (0.055 + Math.random() * 0.035), side = Math.random();
    const x = side < 0.55 ? W * (0.02 + Math.random() * 0.22) : W * (0.70 + Math.random() * 0.26);
    return { x, y: H * (0.45 + Math.random() * 0.35), w, h: w * 0.66, vx: (Math.random() - 0.5) * 0.012, vy: -(0.012 + Math.random() * 0.02),
      rot: (Math.random() - 0.5) * 0.5, vr: (Math.random() - 0.5) * 0.00025, life: 0, max: 3800 + Math.random() * 2600,
      sky: SKIES[Math.floor(Math.random() * SKIES.length)], amt: (0.25 + Math.random() * 4.5).toFixed(2), sun: Math.random() };
  }
  function drawCard(q, dt) {
    q.life += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt;
    const f = q.life / q.max, al = Math.sin(Math.PI * Math.min(1, f)) * mask(q.x, q.y);
    if (al <= 0.01) return;
    cx.save(); cx.translate(q.x, q.y); cx.rotate(q.rot); cx.globalAlpha = 0.42 * al;
    const g = cx.createLinearGradient(0, -q.h / 2, 0, q.h / 2); g.addColorStop(0, q.sky[0]); g.addColorStop(1, q.sky[1]);
    cx.fillStyle = g; cx.fillRect(-q.w / 2, -q.h / 2, q.w, q.h);
    cx.fillStyle = "rgba(255,240,200,.9)"; cx.beginPath(); cx.arc(-q.w * 0.2 + q.sun * q.w * 0.4, -q.h * 0.12, q.h * 0.11, 0, 7); cx.fill();
    cx.fillStyle = "rgba(20,30,50,.75)"; cx.beginPath(); cx.moveTo(-q.w / 2, q.h / 2); cx.lineTo(-q.w * 0.18, -q.h * 0.02); cx.lineTo(q.w * 0.05, q.h * 0.2);
    cx.lineTo(q.w * 0.28, -q.h * 0.1); cx.lineTo(q.w / 2, q.h * 0.18); cx.lineTo(q.w / 2, q.h / 2); cx.fill();
    cx.globalAlpha = 0.85 * al; cx.strokeStyle = "rgba(120,220,255,.9)"; cx.lineWidth = 1; cx.shadowColor = "#6fe3ff"; cx.shadowBlur = 8;
    cx.strokeRect(-q.w / 2, -q.h / 2, q.w, q.h); cx.shadowBlur = 0;
    cx.font = `600 ${Math.max(8, q.h * 0.26)}px system-ui, sans-serif`; cx.textAlign = "left";
    cx.fillStyle = `rgba(110,231,168,${0.95 * al})`; cx.fillText("+$" + q.amt, -q.w / 2, -q.h / 2 - 4);
    cx.restore();
  }
  
  /* ---- 3. caurspīdīgas diagrammas (hologrammas) */
  function spawnHud() {
    /* 22:09 lietotājs: vairāk un lielākas (≈2×) */
    const kind = ["bars", "line", "pie", "bars", "line"][Math.floor(Math.random() * 5)], w = W * (0.14 + Math.random() * 0.08);
    const x = W * (0.01 + Math.random() * 0.80);
    return { kind, x, y: H * (0.30 + Math.random() * 0.40), w, h: w * 0.62, vy: -(0.008 + Math.random() * 0.012), vx: (Math.random() - 0.5) * 0.008,
      life: 0, max: 4200 + Math.random() * 2000, d: Array.from({ length: 7 }, (_, i) => 0.25 + Math.random() * 0.4 + i * 0.05), spin: Math.random() * 6 };
  }
  function drawHud(q, dt) {
    q.life += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.spin += 0.0012 * dt;
    const f = q.life / q.max, al = Math.sin(Math.PI * Math.min(1, f)) * mask(q.x + q.w / 2, q.y + q.h / 2), grow = Math.min(1, q.life / 1400);
    if (al <= 0.01) return;
    cx.save(); cx.translate(q.x, q.y);
    cx.fillStyle = `rgba(40,120,170,${0.14 * al})`; cx.strokeStyle = `rgba(120,220,255,${0.55 * al})`; cx.lineWidth = 1.2;
    cx.beginPath(); cx.roundRect ? cx.roundRect(0, 0, q.w, q.h, 5) : cx.rect(0, 0, q.w, q.h); cx.fill(); cx.stroke();
    const p = q.w * 0.1, bw = (q.w - 2 * p) / q.d.length;
    if (q.kind === "bars") {
      q.d.forEach((v, i) => { const h = (q.h - 2 * p) * v * grow; cx.fillStyle = `rgba(${i > 4 ? "110,231,168" : "111,227,255"},${0.5 * al})`;
        cx.fillRect(p + i * bw + bw * 0.15, q.h - p - h, bw * 0.7, h); });
    } else if (q.kind === "line") {
      cx.strokeStyle = `rgba(111,227,255,${0.8 * al})`; cx.lineWidth = 2.2; cx.beginPath();
      const n = Math.max(2, Math.ceil(q.d.length * grow));
      for (let i = 0; i < n; i++) { const x = p + i * (q.w - 2 * p) / (q.d.length - 1), y = q.h - p - (q.h - 2 * p) * q.d[i]; i ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      cx.stroke();
      for (let i = 0; i < n; i++) { const x = p + i * (q.w - 2 * p) / (q.d.length - 1), y = q.h - p - (q.h - 2 * p) * q.d[i];
        cx.fillStyle = `rgba(210,255,240,${0.9 * al})`; cx.beginPath(); cx.arc(x, y, 2.6, 0, 7); cx.fill(); }
    } else {
      const r = q.h * 0.36, c = [q.w / 2, q.h / 2]; let a0 = q.spin;
      [["111,227,255", 0.4], ["110,231,168", 0.25], ["199,166,255", 0.2], ["255,210,122", 0.15]].forEach(([col, part]) => {
        const a1 = a0 + part * Math.PI * 2 * grow; cx.strokeStyle = `rgba(${col},${0.7 * al})`; cx.lineWidth = r * 0.38;
        cx.beginPath(); cx.arc(c[0], c[1], r, a0, a1); cx.stroke(); a0 = a1; });
    }
    cx.restore();
  }
  
  /* ---- 4. datu tīkls: impulsi no ikonām/malām uz hologrammām */
  function curve(a, b, t) {
    const mx = (a[0] + b[0]) / 2, my = Math.min(a[1], b[1]) - 0.08, u = 1 - t;
    return [(u * u * a[0] + 2 * u * t * mx + t * t * b[0]) * W, (u * u * a[1] + 2 * u * t * my + t * t * b[1]) * H];
  }
  function spawnPulse() {
    const a = NODES[Math.floor(Math.random() * NODES.length)], b = HUBS[Math.floor(Math.random() * HUBS.length)];
    return { a, b, t: 0, v: 0.00045 + Math.random() * 0.0004, money: Math.random() < 0.22 };
  }
  function drawNet(now, dt, p) {
    /* tievas līnijas, kas "elpo" */
    cx.lineWidth = 0.8;
    NODES.forEach((a, i) => {
      const b = HUBS[i % HUBS.length], al = (0.05 + 0.05 * Math.sin(now / 900 + i)) * Math.min(1, p * 4);
      cx.strokeStyle = `rgba(111,227,255,${al})`; cx.beginPath();
      for (let k = 0; k <= 24; k++) { const [x, y] = curve(a, b, k / 24); k ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      cx.stroke();
      const [nx, ny] = [a[0] * W, a[1] * H], fl = S.flash > 0 ? S.flash : 0;
      const g = cx.createRadialGradient(nx, ny, 0, nx, ny, 9 + fl * 14);
      g.addColorStop(0, `rgba(200,250,255,${0.55 + fl * 0.45})`); g.addColorStop(1, "rgba(111,227,255,0)");
      cx.fillStyle = g; cx.beginPath(); cx.arc(nx, ny, 9 + fl * 14, 0, 7); cx.fill();
    });
    /* impulsi */
    S.pulses = S.pulses.filter((q) => (q.t += q.v * dt) < 1);
    for (const q of S.pulses) {
      for (let k = 0; k < 6; k++) {
        const t = q.t - k * 0.018; if (t < 0) continue;
        const [x, y] = curve(q.a, q.b, t), al = (1 - k / 6) * Math.sin(Math.PI * q.t);
        cx.fillStyle = q.money ? `rgba(110,231,168,${al})` : `rgba(190,245,255,${al})`;
        cx.beginPath(); cx.arc(x, y, (q.money ? 2.4 : 1.8) * (1 - k / 8), 0, 7); cx.fill();
      }
      if (q.money && q.t > 0.75) { const [x, y] = curve(q.a, q.b, q.t);
        cx.font = `600 ${Math.max(9, W / 80)}px system-ui, sans-serif`; cx.fillStyle = `rgba(110,231,168,${(1 - q.t) * 3})`; cx.fillText("+$", x + 6, y - 6); }
    }
  }
  
  /* ---- 5. "Gatavs": gaismas vilnis */
  function drawWave(dt) {
    if (S.wave < 0) return;
    S.wave += dt / 1100; if (S.wave > 1) { S.wave = -1; return; }
    const R = S.wave * W * 0.9, al = (1 - S.wave) * 0.5;
    cx.strokeStyle = `rgba(150,240,255,${al})`; cx.lineWidth = 2 + 6 * (1 - S.wave);
    cx.beginPath(); cx.arc(WAVE[0] * W, WAVE[1] * H, R, 0, 7); cx.stroke();
  }
  
  /* ---- nosaukums: zelta burti ar mirdzumu (kā oriģinālajā attēlā) */
  const TITLE_POS = B.titlePos || { x: 0.497, base: 0.885, maxW: 0.46, size: 0.135 };   // daļas no platuma/augstuma
  function drawTitle() {
    const cv = $("#bnTitle"), d = window.devicePixelRatio || 1;
    cv.width = W * d; cv.height = H * d; const t = cv.getContext("2d"); t.setTransform(d, 0, 0, d, 0, 0); t.clearRect(0, 0, W, H);
    const txt = L10N[LANG].title, fam = LANG === "uk" ? '"BannerTitleCyr", serif' : '"BannerTitle", serif';
    let fs = H * TITLE_POS.size; t.font = `700 ${fs}px ${fam}`;
    const w = t.measureText(txt).width; if (w > W * TITLE_POS.maxW) { fs *= W * TITLE_POS.maxW / w; t.font = `700 ${fs}px ${fam}`; }
    t.textAlign = "center"; t.textBaseline = "alphabetic";
    const x = W * TITLE_POS.x, y = H * TITLE_POS.base;
    /* 22:36: jaunajā bildē zem nosaukuma gaiši papīri — mīksts tumšs "mākonis" aiz uzraksta */
    { const tw0 = Math.min(t.measureText(txt).width, W * TITLE_POS.maxW), cy = y - fs * 0.3;
      t.save(); t.translate(x, cy); t.scale(1, 0.42);
      const rg = t.createRadialGradient(0, 0, 0, 0, 0, tw0 * 0.72);
      rg.addColorStop(0, "rgba(8,5,2,.88)"); rg.addColorStop(0.55, "rgba(8,5,2,.6)"); rg.addColorStop(1, "rgba(10,6,2,0)");
      t.fillStyle = rg; t.beginPath(); t.arc(0, 0, tw0 * 0.72, 0, 7); t.fill(); t.restore(); }
    /* tumša pamatne, lai burti atdalās no fona */
    t.save(); t.shadowColor = "rgba(0,0,0,.85)"; t.shadowBlur = fs * 0.35; t.fillStyle = "rgba(0,0,0,.55)"; t.fillText(txt, x, y); t.restore();
    /* zelta mirdzums */
    t.save(); t.shadowColor = "rgba(255,170,60,.9)"; t.shadowBlur = fs * 0.3; t.fillStyle = "rgba(120,60,10,.9)"; t.fillText(txt, x, y); t.restore();
    /* burti: gaiši krēmkrāsas augšā → zelts → silti oranžs apakšā */
    const g = t.createLinearGradient(0, y - fs * 0.78, 0, y + fs * 0.05);
    g.addColorStop(0, "#fff4d2"); g.addColorStop(0.35, "#fbdc8e"); g.addColorStop(0.68, "#f0b04a"); g.addColorStop(1, "#c46e1c");
    t.fillStyle = g; t.fillText(txt, x, y);
    t.lineWidth = Math.max(0.8, fs * 0.016); t.strokeStyle = "rgba(80,38,8,.75)"; t.strokeText(txt, x, y);
    /* 22:36: jaunajā bildē nav zelta svītras — zīmējam pašu (kā Vārdotāja/iepriekšējā bannerī) */
    const tw = Math.min(t.measureText(txt).width, W * TITLE_POS.maxW), sy = y + fs * 0.24;
    t.save(); t.globalCompositeOperation = "lighter"; t.lineCap = "round";
    const sg = t.createLinearGradient(x - tw * 0.75, 0, x + tw * 0.75, 0);
    sg.addColorStop(0, "rgba(255,170,60,0)"); sg.addColorStop(0.3, "rgba(255,200,110,.9)"); sg.addColorStop(0.6, "rgba(255,236,190,1)"); sg.addColorStop(1, "rgba(255,170,60,0)");
    t.strokeStyle = sg; t.shadowColor = "rgba(255,190,90,.9)"; t.shadowBlur = fs * 0.2; t.lineWidth = Math.max(1.6, fs * 0.05);
    t.beginPath(); t.moveTo(x - tw * 0.75, sy + fs * 0.06); t.bezierCurveTo(x - tw * 0.3, sy - fs * 0.12, x + tw * 0.25, sy + fs * 0.12, x + tw * 0.75, sy - fs * 0.05); t.stroke();
    t.restore();
  }
  
  function frame(now) {
    const dt = Math.min(50, now - (S.last || now)); S.last = now;
    const p = Math.min(1, (now - S.t0) / DUR);
    cx.clearRect(0, 0, W, H);
    cx.globalCompositeOperation = "lighter";   // 21:58: lietus pieskaitās gaismai — redzams arī uz bildes
    drawRain(dt);
    drawNet(now, dt, p);
    /* 22:03 lietotājs: bez "krītošajām zvaigznēm" (impulsiem) */
    cx.globalCompositeOperation = "source-over";
    if (!S.closing && S.cards.length < 6 && Math.random() < 0.02 * dt / 16) S.cards.push(spawnCard());
    if (!S.closing && S.huds.length < 6 && Math.random() < 0.03 * dt / 16) S.huds.push(spawnHud());   /* 22:09: atpakaļ, vairāk */
    S.huds = S.huds.filter((q) => q.life < q.max); S.huds.forEach((q) => drawHud(q, dt));
    S.cards = S.cards.filter((q) => q.life < q.max); S.cards.forEach((q) => drawCard(q, dt));
    cx.globalCompositeOperation = "lighter"; drawWave(dt); cx.globalCompositeOperation = "source-over";
    if (S.flash > 0) S.flash = Math.max(0, S.flash - dt / 900);
    if (!S.closing) {
      $("#bnBar").style.width = (p * 100).toFixed(1) + "%";
      let txt = STEPS[0]; AT.forEach((a, i) => { if (p >= a) txt = STEPS[i]; });
      if ($("#bnStep").textContent !== txt) {
        $("#bnStep").textContent = txt;
        if (txt === STEPS[STEPS.length - 1]) { S.wave = 0; S.flash = 1; }
      }
      if (p >= 1 && !S.doneAt) S.doneAt = now;
      if (S.doneAt && now - S.doneAt > 700) close();
    }
    S.raf = requestAnimationFrame(frame);
  }
  function start() {
    cancelAnimationFrame(S.raf);
    Object.assign(S, { closing: false, last: 0, cards: [], huds: [], pulses: [], flash: 0, wave: -1, doneAt: 0 });
    
    const wrap = $("#bnWrap"); wrap.classList.remove("hide"); wrap.classList.add("show");
    size(); S.t0 = performance.now();
    for (let i = 0; i < 3; i++) S.cards.push(Object.assign(spawnCard(), { life: Math.random() * 1500 }));
    for (let i = 0; i < 3; i++) S.huds.push(Object.assign(spawnHud(), { life: 200 + Math.random() * 1200 }));
    S.raf = requestAnimationFrame(frame);
  }
  function close() {
    if (S.closing || !$("#bnWrap")) return; S.closing = true; $("#bnBar").style.width = "100%";
    $("#bnWrap").classList.add("hide");
    setTimeout(() => { cancelAnimationFrame(S.raf); const w = $("#bnWrap"); if (w) w.remove(); }, 750);
  }
  
  function mount(ver) {
    if (document.getElementById("bnWrap")) return;
    const st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st);
    const w = document.createElement("div"); w.id = "bnWrap"; w.className = "bn-wrap";
    w.innerHTML = `<div class="bn" id="bnCard"><img id="bnImg" alt=""><canvas id="bnTitle"></canvas><canvas id="bnFx"></canvas>
      <div class="bn-foot"><div class="bn-row"><span id="bnStep"></span><span id="bnVer"></span></div><div class="bn-bar"><i id="bnBar"></i></div></div></div>`;
    document.body.appendChild(w);
    $("#bnVer").textContent = "v" + ver;
    $("#bnCard").addEventListener("click", close);
    window.addEventListener("resize", () => { if (!S.closing) size(); });
  }
  function startBanner(lang, ver) {
    if (!B.img) return false;
    LANG = L10N[lang] ? lang : "en"; STEPS = (L10N[LANG] || L10N.en || { steps: [""] }).steps;
    mount(ver);
    const img = $("#bnImg");
    const go = () => Promise.all([document.fonts.load('700 40px "BannerTitle"'), document.fonts.load('700 40px "BannerTitleCyr"', "Аналітик")])
      .catch(() => {}).then(() => requestAnimationFrame(start));
    img.onload = go; img.onerror = () => { const w = $("#bnWrap"); if (w) w.remove(); };
    img.src = B.img;
    setTimeout(close, 15000);
    return true;
  }
  return { start: startBanner, close };
})();
