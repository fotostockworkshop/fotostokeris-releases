; Fotostokera produkta Windows uzstādītājs (noteikumi §3 "Palaišana"; lietotājs 2026-10-31).
; Izveido core/win/make_installer.sh:  makensis -DSLUG=… -DNAME=… -DVER=… -DSRC=<programmas mape> -DOUT=<exe>
; Uzstāda lietotāja mapē (bez administratora tiesībām): %LOCALAPPDATA%\Programs\<Slug>; dati paliek %APPDATA%\<Slug>.
; Sagatavo Python vidi (.venv + bibliotēkas) uzstādīšanas laikā, izveido saīsnes Start izvēlnē un darbvirsmā.
Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"

Name "${NAME}"
OutFile "${OUT}"
InstallDir "$LOCALAPPDATA\Programs\${SLUG}"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Fotostock Workshop"
!define MUI_ICON "${SRC}\win\${SLUG}.ico"
!define MUI_UNICON "${SRC}\win\${SLUG}.ico"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN
!define MUI_FINISHPAGE_RUN_FUNCTION RunApp
!define MUI_LANGDLL_ALLLANGUAGES

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES

!insertmacro MUI_LANGUAGE "Latvian"
!insertmacro MUI_LANGUAGE "English"
!insertmacro MUI_LANGUAGE "German"
!insertmacro MUI_LANGUAGE "Spanish"
!insertmacro MUI_LANGUAGE "Ukrainian"

LangString NoPy ${LANG_LATVIAN} "Vajag Python 3.10 vai jaunāku. Atvērt python.org? Uzstādot atzīmē $\"Add python.exe to PATH$\" un tad palaid šo uzstādītāju vēlreiz."
LangString NoPy ${LANG_ENGLISH} "Python 3.10 or newer is needed. Open python.org? When installing, tick $\"Add python.exe to PATH$\" and then run this installer again."
LangString NoPy ${LANG_GERMAN} "Python 3.10 oder neuer wird benötigt. python.org öffnen? Beim Installieren $\"Add python.exe to PATH$\" ankreuzen und dann dieses Installationsprogramm erneut starten."
LangString NoPy ${LANG_SPANISH} "Se necesita Python 3.10 o posterior. ¿Abrir python.org? Al instalar, marca $\"Add python.exe to PATH$\" y vuelve a ejecutar este instalador."
LangString NoPy ${LANG_UKRAINIAN} "Потрібен Python 3.10 або новіший. Відкрити python.org? Під час встановлення познач $\"Add python.exe to PATH$\" і знову запусти цей інсталятор."
LangString Prep ${LANG_LATVIAN} "Sagatavoju vidi un bibliotēkas (pāris minūtes, vajag internetu)…"
LangString Prep ${LANG_ENGLISH} "Preparing the environment and libraries (a few minutes, internet needed)…"
LangString Prep ${LANG_GERMAN} "Bereite Umgebung und Bibliotheken vor (ein paar Minuten, Internet nötig)…"
LangString Prep ${LANG_SPANISH} "Preparando el entorno y las bibliotecas (unos minutos, se necesita internet)…"
LangString Prep ${LANG_UKRAINIAN} "Готую середовище й бібліотеки (кілька хвилин, потрібен інтернет)…"
LangString PipFail ${LANG_LATVIAN} "Bibliotēkas neizdevās uzstādīt (vai ir internets?). Programma mēģinās vēlreiz, kad to palaidīsi."
LangString PipFail ${LANG_ENGLISH} "The libraries could not be installed (is there internet?). The program will try again when you start it."
LangString PipFail ${LANG_GERMAN} "Die Bibliotheken konnten nicht installiert werden (gibt es Internet?). Das Programm versucht es beim Start erneut."
LangString PipFail ${LANG_SPANISH} "No se pudieron instalar las bibliotecas (¿hay internet?). El programa lo intentará de nuevo al iniciarse."
LangString PipFail ${LANG_UKRAINIAN} "Не вдалося встановити бібліотеки (чи є інтернет?). Програма спробує ще раз під час запуску."

VIProductVersion "${VERNUM}.0"
VIAddVersionKey /LANG=${LANG_ENGLISH} "ProductName" "${NAME}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "FileDescription" "${NAME} installer"
VIAddVersionKey /LANG=${LANG_ENGLISH} "FileVersion" "${VER}"
VIAddVersionKey /LANG=${LANG_ENGLISH} "CompanyName" "Fotostock Workshop"
VIAddVersionKey /LANG=${LANG_ENGLISH} "LegalCopyright" "Fotostock Workshop"

Var PY

Function .onInit
  !insertmacro MUI_LANGDLL_DISPLAY
FunctionEnd

Function FindPython
  StrCpy $PY ""
  nsExec::ExecToStack 'py -3 -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)"'
  Pop $0
  ${If} $0 == 0
    StrCpy $PY "py -3"
    Return
  ${EndIf}
  nsExec::ExecToStack 'python -c "import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)"'
  Pop $0
  ${If} $0 == 0
    StrCpy $PY "python"
  ${EndIf}
FunctionEnd

Section "Install"
  Call FindPython
  ${If} $PY == ""
    MessageBox MB_YESNO|MB_ICONEXCLAMATION "$(NoPy)" IDNO +2
      ExecShell "open" "https://www.python.org/downloads/windows/"
    Abort
  ${EndIf}
  ; programma jau darbojas? — aptur tikai šīs mapes Python procesus (2026-11-02: agrāk taskkill pēc loga nosaukuma
  ; "${NAME}*" — tam atbilda arī paša uzstādītāja logs, un uzstādītājs aizvēra pats sevi)
  nsExec::Exec `powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { $$_.Name -like 'python*' -and $$_.CommandLine -like '*$INSTDIR\*' } | ForEach-Object { Stop-Process -Id $$_.ProcessId -Force -ErrorAction SilentlyContinue }"`
  SetOutPath "$INSTDIR"
  File /r /x ".venv" /x "__pycache__" /x "*.command" /x "*.app" /x "mac" /x "dev" "${SRC}\*.*"
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  DetailPrint "$(Prep)"
  ${IfNot} ${FileExists} "$INSTDIR\.venv\Scripts\python.exe"
    nsExec::ExecToLog '$PY -m venv "$INSTDIR\.venv"'
    Pop $0
  ${EndIf}
  nsExec::ExecToLog '"$INSTDIR\.venv\Scripts\python.exe" -m pip install --upgrade pip'
  Pop $0
  nsExec::ExecToLog '"$INSTDIR\.venv\Scripts\python.exe" -m pip install -r "$INSTDIR\requirements.txt"'
  Pop $0
  ${If} $0 == 0
    CopyFiles /SILENT "$INSTDIR\requirements.txt" "$INSTDIR\.venv\req.txt"
  ${Else}
    DetailPrint "$(PipFail)"
  ${EndIf}
  ; saīsnes: pythonw bez konsoles loga (atjaunināšana palaiž run_windows.bat pati)
  CreateDirectory "$SMPROGRAMS\${NAME}"
  CreateShortCut "$SMPROGRAMS\${NAME}\${NAME}.lnk" "$INSTDIR\.venv\Scripts\pythonw.exe" '"$INSTDIR\${SLUG}.py"' "$INSTDIR\win\${SLUG}.ico"
  CreateShortCut "$SMPROGRAMS\${NAME}\Uninstall.lnk" "$INSTDIR\Uninstall.exe"
  CreateShortCut "$DESKTOP\${NAME}.lnk" "$INSTDIR\.venv\Scripts\pythonw.exe" '"$INSTDIR\${SLUG}.py"' "$INSTDIR\win\${SLUG}.ico"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "DisplayName" "${NAME}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "DisplayVersion" "${VER}"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "Publisher" "Fotostock Workshop"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "DisplayIcon" "$INSTDIR\win\${SLUG}.ico"
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegDWORD HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}" "NoModify" 1
SectionEnd

Function RunApp
  SetOutPath "$INSTDIR"
  Exec '"$INSTDIR\.venv\Scripts\pythonw.exe" "$INSTDIR\${SLUG}.py"'
FunctionEnd

Section "Uninstall"
  ; programmas faili; tavi dati (%APPDATA%\${SLUG}) paliek
  RMDir /r "$INSTDIR"
  Delete "$DESKTOP\${NAME}.lnk"
  RMDir /r "$SMPROGRAMS\${NAME}"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${SLUG}"
SectionEnd

Function un.onInit
  !insertmacro MUI_UNGETLANGUAGE
FunctionEnd
