#!/bin/bash
# Windows uzstādītājs (.exe) no Linux vai Mac ar NSIS (makensis).
#   bash core/win/make_installer.sh <programmas mape (izpakotais izlaidums)> <Slug> "<Nosaukums>" <versija> <izvades .exe>
# makensis: ja nav sistēmā, lejupielādē NSIS komplektu (electron-builder-binaries, GitHub) un 7-Zip (ip7z, GitHub)
# kešā ~/.cache/fotostokeris-nsis. Repozitorijā rīkus neglabā.
set -e
export LANG=C.UTF-8 LC_ALL=C.UTF-8          # makensis vajag UTF-8 lokāli (nosaukumā garumzīmes)
SRC="$(cd "$1" && pwd)"; SLUG="$2"; NAME="$3"; VER="$4"; OUT="$5"
HERE="$(cd "$(dirname "$0")" && pwd)"
CACHE="${XDG_CACHE_HOME:-$HOME/.cache}/fotostokeris-nsis"
MK="$(command -v makensis || true)"
if [ -z "$MK" ]; then
  if [ ! -x "$CACHE/nsis/linux/makensis" ]; then
    mkdir -p "$CACHE" && cd "$CACHE"
    curl -sSL -o 7z.tar.xz https://github.com/ip7z/7zip/releases/download/24.09/7z2409-linux-x64.tar.xz
    mkdir -p 7z && tar -xf 7z.tar.xz -C 7z
    curl -sSL -o nsis.7z https://github.com/electron-userland/electron-builder-binaries/releases/download/nsis-3.0.4.1/nsis-3.0.4.1.7z
    ./7z/7zz x -y -onsis nsis.7z >/dev/null
    chmod +x nsis/linux/makensis
    cd - >/dev/null
  fi
  MK="$CACHE/nsis/linux/makensis"; export NSISDIR="$CACHE/nsis"
fi
VERNUM=$(echo "$VER" | sed -E 's/^([0-9]+)\.([0-9]+)\.([0-9]+).*/\1.\2.\3/')
"$MK" -V2 -INPUTCHARSET UTF8 -DSLUG="$SLUG" -DNAME="$NAME" -DVER="$VER" -DVERNUM="$VERNUM" -DSRC="$SRC" -DOUT="$OUT" "$HERE/installer.nsi"
echo "Windows uzstādītājs: $OUT"
