"""Saites atvēršana parastajā pārlūkā — uz Windows logs nāk priekšplānā (lietotājs 2026-11-03: Google lapa atvērās aiz
citiem logiem). Lieto core/google.py un core/server.py (_api_open_url)."""
from __future__ import annotations

import os
import sys
import webbrowser


def open_url(url: str) -> None:
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.user32.AllowSetForegroundWindow(-1)     # ASFW_ANY — pārlūks drīkst nākt priekšā
        except Exception:
            pass
        try:
            os.startfile(url)                                     # noqa: S606 — noklusējuma pārlūks
            return
        except Exception:
            pass
    webbrowser.open(url)
