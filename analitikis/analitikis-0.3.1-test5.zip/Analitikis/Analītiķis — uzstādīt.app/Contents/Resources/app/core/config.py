"""Iestatījumi, datu mape un žurnāls (log.txt) — kopīgi visiem produktiem (noteikumi §3, §5)."""
from __future__ import annotations

import json
import os
import sys
import threading
import time
from pathlib import Path

from . import app as _app

IS_WIN = sys.platform.startswith("win")
IS_MAC = sys.platform == "darwin"

# kopīgās atslēgas (vienādas visos produktos, noteikumi §5)
CORE_DEFAULTS = {
    "lang": "lv",                       # lv | en
    "theme": "auto",                    # auto | light | dark | forest (Meža zaļais — Vārdotājs 0.9.0-test4)
    "author": "",
    "target_agencies": ["adobe", "shutterstock", "istock"],
    "my_rules": "",
    "show_splash": True,
    "update_channel": "auto",           # auto | stable | test | off (noteikumi §9a)
    "seen_version": "",                 # pēdējā versija, kuras "Kas jauns" lietotājs redzējis (noteikumi §9a)
    # rezerves kopijas (core/backup.py, noteikumi §5): mape (tukšs = Dokumenti/Fotostokeris rezerves kopijas/<Slug>),
    # biežums never | day | week | month, cik paturēt, pēdējās kopijas laiks
    "backup_dir": "",
    # Pieslēgumi (noteikumi §5 p.2, core/ai.py): kurš AI ko dara, ievadītie atlikumi, modeļi, OneDrive mape
    "ai_roles": {},                     # {darbs: [pieslēgums, …]} — secība; ja pirmajam limits/kļūda — nākamais
    "ai_balance": {},                   # {pieslēgums: {"amount": 10.0, "currency": "USD", "at": "2026-10-30"}}
    "gemini_model": "",                 # tukšs = pirmais "flash" no saraksta
    "ollama_model": "",
    "onedrive_dir": "",                 # tukšs = atrast automātiski
    "backup_every": "week",
    "backup_keep": 10,
    "google_sync": False,               # sinhronizācija ar citiem datoriem caur Google Drive (core/sync.py; datora iestatījums)
    "sync_last": "",                    # pēdējā veiksmīgā sinhronizācija (ISO)
    "sync_err": "",                     # pēdējā sinhronizācijas kļūda
    "backup_google": False,             # rezerves kopijas arī uz Google Drive (Google konts, core/google.py; datora iestatījums)
    "backup_last": "",
}


def defaults() -> dict:
    d = dict(CORE_DEFAULTS)
    d.update(_app.current().defaults)
    return d


def app_dir() -> Path:
    """Produkta datu mape (iestatījumi, datubāze, sesijas, žurnāls)."""
    slug = _app.current().slug
    if IS_WIN:
        base = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
        d = base / slug
    elif IS_MAC:
        d = Path.home() / "Library" / "Application Support" / slug
    else:
        d = Path(os.environ.get("XDG_CONFIG_HOME") or Path.home() / ".config") / slug.lower()
    d.mkdir(parents=True, exist_ok=True)
    return d


class JsonStore:
    def __init__(self, path: Path, default):
        self.path = path
        self.lock = threading.RLock()
        self.default = default
        self.data = self._load()

    def _load(self):
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if isinstance(self.default, dict) and isinstance(data, dict):
                merged = dict(self.default)
                merged.update(data)
                return merged
            return data
        except Exception:
            return json.loads(json.dumps(self.default))

    def save(self):
        with self.lock:
            tmp = self.path.with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.data, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)


_settings: JsonStore | None = None


def settings() -> JsonStore:
    global _settings
    if _settings is None:
        _settings = JsonStore(app_dir() / "settings.json", defaults())
    return _settings


def get(key):
    return settings().data.get(key, defaults().get(key))


def update(values: dict):
    s = settings()
    allowed = defaults()
    with s.lock:
        for k, v in values.items():
            if k in allowed:
                s.data[k] = v
        s.save()


# ---- žurnāls log.txt: rotācija un atkārtojumu saspiešana (noteikumi §3)
LOG_KEEP = 3                    # cik iepriekšējos žurnālus glabāt (log-1.txt … log-3.txt)
LOG_MAX = 2 * 1024 * 1024       # ja log.txt izaug lielāks, to sāk no jauna (vecais → log-1.txt)


def _log_path(i: int = 0) -> Path:
    return app_dir() / ("log.txt" if i == 0 else f"log-{i}.txt")


def _rotate_logs() -> bool:
    """log.txt → log-1.txt → … → log-N.txt (vecākais tiek izdzēsts). Ja fails aizņemts (Windows), nekas nenotiek."""
    if not _log_path().exists() or _log_path().stat().st_size == 0:
        return False
    try:
        _log_path(LOG_KEEP).unlink(missing_ok=True)
        for i in range(LOG_KEEP - 1, -1, -1):
            if _log_path(i).exists():
                os.replace(_log_path(i), _log_path(i + 1))
        return True
    except OSError:
        return False


class LogFile:
    """Raksta log.txt ar laiku katras rindas sākumā; vienādas rindas pēc kārtas saspiež
    ("atkārtojās N reizes"); pārsniedzot LOG_MAX, sāk jaunu failu."""

    def __init__(self):
        self.lock = threading.RLock()
        self.f = None
        self.buf = ""
        self.last = None
        self.rep = 0
        self.max = LOG_MAX
        self.open()

    def open(self, rotate: bool = False):
        with self.lock:
            if self.f:
                self._flush_rep()
                self.f.close()
                self.f = None
            if rotate:
                _rotate_logs()
            self.f = open(_log_path(), "a", encoding="utf-8", buffering=1)

    def _out(self, line: str):
        self.f.write(time.strftime("%Y-%m-%d %H:%M:%S ") + line + "\n")

    def _flush_rep(self):
        if self.rep:
            self._out(f"  (↑ atkārtojās vēl {self.rep} reizes)")
            self.rep = 0

    def write(self, s: str):
        with self.lock:
            self.buf += s
            while "\n" in self.buf:
                line, self.buf = self.buf.split("\n", 1)
                if not line.strip():
                    continue
                if line == self.last:
                    self.rep += 1
                    continue
                self._flush_rep()
                self.last = line
                self._out(line)
            try:
                if self.f.tell() > self.max:
                    self.open(rotate=True)
                    if self.f.tell() > self.max:          # neizdevās (fails aizņemts) — nemēģinām pie katras rindas
                        self.max = self.f.tell() + LOG_MAX
            except (OSError, ValueError):
                pass
        return len(s)

    def flush(self):
        with self.lock:
            try:
                self.f.flush()
            except (OSError, ValueError):
                pass

    def isatty(self):
        return False


_LOG: LogFile | None = None


def setup_log(rotate: bool = False):
    """Novirza print/kļūdas uz log.txt. rotate=True — galvenajā procesā pēc vecās instances apturēšanas."""
    global _LOG
    if _LOG is None:
        _LOG = LogFile()
        sys.stdout = sys.stderr = _LOG
    if rotate:
        _LOG.open(rotate=True)
