"""Valūtu kursi (EUR -> USD u.c.) ienākumu pārrēķinam dolāros.

Kursi tiek ņemti no Eiropas Centrālās bankas datiem (frankfurter API) un saglabāti catalog.db
(state tabulā), tāpēc internets vajadzīgs tikai, kad parādās jauni datumi. Ja kursu dabūt nevar,
tiek lietots aptuvens kurss (FALLBACK), un tas tiek pārrēķināts nākamajā reizē.
"""
from __future__ import annotations

import datetime as dt
import json
import os
import ssl
import threading
import urllib.request

FALLBACK = {"EUR": 1.10, "GBP": 1.27, "JPY": 0.0068}
URLS = ["https://api.frankfurter.dev/v1/{a}..{b}?base={cur}&symbols=USD",
        "https://api.frankfurter.app/{a}..{b}?from={cur}&to=USD"]

_lock = threading.Lock()
_cache: dict[str, dict[str, float]] = {}
_tried: set[str] = set()


def _ssl_ctx():
    """python.org Python uz Mac nezina sistēmas sertifikātus — tad lietojam macOS /etc/ssl/cert.pem."""
    ctx = ssl.create_default_context()
    if not ctx.get_ca_certs() and os.path.exists("/etc/ssl/cert.pem"):
        ctx = ssl.create_default_context(cafile="/etc/ssl/cert.pem")
    return ctx


def _load(db, cur: str) -> dict[str, float]:
    if cur not in _cache:
        _cache[cur] = db.get_state("_fx", cur, {}) or {}
    return _cache[cur]


def _fetch(cur: str, a: str, b: str) -> dict[str, float]:
    for u in URLS:
        try:
            req = urllib.request.Request(u.format(cur=cur, a=a, b=b), headers={"User-Agent": "Analitikis"})
            with urllib.request.urlopen(req, timeout=20, context=_ssl_ctx()) as r:
                data = json.loads(r.read().decode("utf-8"))
            return {d: float(v["USD"]) for d, v in (data.get("rates") or {}).items() if "USD" in v}
        except Exception as e:  # tīkla kļūda — mēģinām nākamo avotu
            print("fx:", u.split("/")[2], e)
    return {}


def rate(db, cur: str, day: str) -> float:
    """1 vienība valūtā `cur` dienā `day` (YYYY-MM-DD) = ? USD."""
    cur = (cur or "USD").upper()
    if cur == "USD":
        return 1.0
    with _lock:
        rates = _load(db, cur)
        if day not in rates and cur not in _tried and day <= dt.date.today().isoformat():
            _tried.add(cur)                          # vienreiz procesā: visa vēsture kopš 2012 (~80 KB)
            got = _fetch(cur, "2012-01-01", dt.date.today().isoformat())
            if got:
                rates.update(got)
                db.set_state("_fx", cur, rates)
        if day in rates:
            return rates[day]
        older = [d for d in rates if d <= day]       # brīvdienām — iepriekšējās darba dienas kurss
        if older:
            return rates[max(older)]
        if rates:
            return rates[min(rates)]
        return FALLBACK.get(cur, 1.0)


# --------------------------------------------------------------------------- 0.3.1: rādīšanas valūta (Izmaksu cilne)
DISPLAY = ("EUR", "USD", "GBP", "UAH")          # saskarnes valodu valstu valūtas (lietotājs 2026-11-01) + "agency"
NBU = "https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?valcode=USD&json"


def _uah_per_usd(db) -> float | None:
    """Ukrainas Nacionālās bankas oficiālais kurss (ECB grivnu nepublicē). Kešs dienai."""
    today = dt.date.today().isoformat()
    st = db.get_state("_fx", "UAH_USD", {}) or {}
    if st.get("day") == today and st.get("r"):
        return float(st["r"])
    try:
        req = urllib.request.Request(NBU, headers={"User-Agent": "Analitikis"})
        with urllib.request.urlopen(req, timeout=15, context=_ssl_ctx()) as r:
            data = json.loads(r.read().decode("utf-8"))
        v = float(data[0]["rate"])
        db.set_state("_fx", "UAH_USD", {"day": today, "r": v})
        return v
    except Exception as e:
        print("fx: bank.gov.ua", e)
        return float(st["r"]) if st.get("r") else None


def display_rates(db) -> dict[str, float | None]:
    """Cik vienību katrā rādīšanas valūtā ir 1 EUR šodien (aptuveni; vēsturiskām summām — EUR izmaksas dienā × šodienas kurss)."""
    day = dt.date.today().isoformat()
    usd_per_eur = rate(db, "EUR", day)
    out: dict[str, float | None] = {"EUR": 1.0, "USD": round(usd_per_eur, 6)}
    try:
        out["GBP"] = round(usd_per_eur / rate(db, "GBP", day), 6)
    except ZeroDivisionError:
        out["GBP"] = None
    u = _uah_per_usd(db)
    out["UAH"] = round(usd_per_eur * u, 4) if u else None
    return out
