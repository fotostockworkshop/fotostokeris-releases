"""Sesiju uzturēšana (test48, lietotājs 2026-10-30): kamēr Analītiķis atvērts, reizi dienā klusi atver to aģentūru
lapas, kuras >20 h nav atjaunotas, — daudzas aģentūras pēc apmeklējuma pagarina sesiju. Ielogošanās plūsmu NEaiztiek:
sinhronizācija ar silent=True — ja aģentūra prasa ielogoties, nekas netiek darīts (logs netiek rādīts, parole netiek
ievadīta, kļūda netiek rakstīta); to izdarīs nākamā parastā atjaunošana. Izslēdzams: sales_keepalive = false.
Skat. docs/ielogosanas-modulis.md."""
from __future__ import annotations

import datetime as dt
import threading
import time

from . import config, db, sync

AGE_H = 20          # cik stundas bez atjaunošanas, lai uzturētu
EVERY_S = 1800      # pārbaude ik pēc 30 min
FIRST_S = 600       # pirmā pārbaude 10 min pēc palaišanas (lai netraucētu automātisko atjaunošanu startā)


def _recent_fail(ag: str) -> bool:
    """0.3.1: sesiju uzturēšana šai aģentūrai nesen neizdevās (sesija beigusies) — līdz nākamajai parastajai
    atjaunošanai vai AGE_H stundām nemēģinām (2026-11-01 žurnāls: 123RF ik pēc 30 min)."""
    f = db.get_state(ag, "keep_fail")
    if not f:
        return False
    try:
        ff = dt.datetime.fromisoformat(str(f)[:19])
        ok = db.get_state(ag, "last_ok")
        if ok and dt.datetime.fromisoformat(str(ok)[:19]) > ff:
            return False
        return dt.datetime.now() - ff < dt.timedelta(hours=AGE_H)
    except ValueError:
        return False


def _old(ag: str) -> bool:
    if _recent_fail(ag):
        return False
    t = db.get_state(ag, "last_try") or db.get_state(ag, "last_ok")
    if not t:
        return False                      # nekad nav atjaunota — to dara lietotājs, ne uzturēšana
    try:
        return dt.datetime.now() - dt.datetime.fromisoformat(str(t)[:19]) > dt.timedelta(hours=AGE_H)
    except ValueError:
        return False


def tick() -> list[str]:
    if config.get("sales_keepalive") is False or sync.active():
        return []
    ags = [a for a in (config.get("sales_agencies") or []) if a in sync.START_URL and _old(a)]
    if not ags:
        return []
    ok, _ = sync.webview_available()
    if not ok:
        return []
    try:
        sync.start(ags, silent=True)
        print("sesiju uzturēšana: " + ", ".join(ags))
    except RuntimeError:
        return []
    return ags


def start() -> None:
    def loop():
        time.sleep(FIRST_S)
        while True:
            try:
                tick()
            except Exception as e:
                print("sesiju uzturēšana:", str(e)[:120])
            time.sleep(EVERY_S)
    threading.Thread(target=loop, daemon=True, name="keepalive").start()
