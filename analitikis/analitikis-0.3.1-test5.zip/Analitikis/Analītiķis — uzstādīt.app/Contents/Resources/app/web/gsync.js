"use strict";
/* Analītiķis — sinhronizācija ar citiem datoriem caur Google Drive (core/sync.py; noteikumi dati §7a).
   Rinda "Google konts": ķeksis, "Sinhronizēt tagad", "Pilnā kopija uz Drive", stāvoklis, paziņojumi.
   Sinhronizējas: iestatījumi (bez šī datora vērtībām), kolekcijas, bilžu apvienošana ar roku, RF/ED atzīmes,
   Microstockr sasaistes, portfeļa vēsture no CSV; jaunam datoram — pilna datubāzes kopija. Lieto google.js (gRow, GG, gWhy). */
const GS_I18N = {
  lv: { sy_chk: "Sinhronizēt ar citiem datoriem", sy_d: "Iestatījumi, kolekcijas, bilžu apvienošana, RF/ED atzīmes un imports (Microstockr, portfeļa vēsture) — caur Google Drive. Aģentūru datus katrs dators ielādē pats; jauns dators sāk no pilnas kopijas (atjaunojas ~reizi dienā). Ieslēdz katrā datorā.",
    sy_now: "Sinhronizēt tagad", sy_db: "Pilnā kopija uz Drive", sy_last: "Sinhronizēts: {d}", sy_never: "vēl nav sinhronizēts", sy_err: "Sinhronizācijas kļūda: {e}",
    sy_busy: "Sinhronizēju…", sy_done: "Sinhronizēts.", sy_db_done: "Pilnā datubāzes kopija augšupielādēta.", sy_db_skip: "Kopija netika augšupielādēta (notiek datu atjaunošana vai datubāze tukša).",
    sy_got: "Dati atjaunoti no datora {c}: {f}", sy_other: "Analītiķis nesen ({d}) lietots arī datorā {c} — nestrādā abos datoros vienlaikus.",
    sy_f_settings: "iestatījumi", sy_f_user_data: "kolekcijas un tavas atzīmes", sy_f_catalog_db_gz: "pilnā datubāze" },
  en: { sy_chk: "Sync with other computers", sy_d: "Settings, collections, merged photos, RF/ED marks and imports (Microstockr, portfolio history) — via Google Drive. Each computer loads agency data itself; a new computer starts from a full copy (updated ~once a day). Turn it on on every computer.",
    sy_now: "Sync now", sy_db: "Full copy to Drive", sy_last: "Synced: {d}", sy_never: "not synced yet", sy_err: "Sync error: {e}",
    sy_busy: "Syncing…", sy_done: "Synced.", sy_db_done: "Full database copy uploaded.", sy_db_skip: "The copy was not uploaded (data is being updated or the database is empty).",
    sy_got: "Data updated from computer {c}: {f}", sy_other: "Analītiķis was recently ({d}) used on computer {c} too — do not work on both computers at the same time.",
    sy_f_settings: "settings", sy_f_user_data: "collections and your marks", sy_f_catalog_db_gz: "full database" },
  de: { sy_chk: "Mit anderen Computern synchronisieren", sy_d: "Einstellungen, Kollektionen, zusammengeführte Bilder, RF/ED-Markierungen und Importe (Microstockr, Portfolio-Verlauf) — über Google Drive. Agenturdaten lädt jeder Computer selbst; ein neuer Computer startet mit einer vollständigen Kopie (ca. einmal täglich aktualisiert). Auf jedem Computer einschalten.",
    sy_now: "Jetzt synchronisieren", sy_db: "Vollständige Kopie zu Drive", sy_last: "Synchronisiert: {d}", sy_never: "noch nicht synchronisiert", sy_err: "Synchronisierungsfehler: {e}",
    sy_busy: "Synchronisiere…", sy_done: "Synchronisiert.", sy_db_done: "Vollständige Datenbankkopie hochgeladen.", sy_db_skip: "Kopie nicht hochgeladen (Daten werden aktualisiert oder Datenbank ist leer).",
    sy_got: "Daten von Computer {c} aktualisiert: {f}", sy_other: "Analītiķis wurde kürzlich ({d}) auch auf Computer {c} verwendet — nicht gleichzeitig auf beiden arbeiten.",
    sy_f_settings: "Einstellungen", sy_f_user_data: "Kollektionen und deine Markierungen", sy_f_catalog_db_gz: "vollständige Datenbank" },
  es: { sy_chk: "Sincronizar con otros ordenadores", sy_d: "Ajustes, colecciones, fotos unidas, marcas RF/ED e importaciones (Microstockr, historial de portafolio) — mediante Google Drive. Cada ordenador carga los datos de las agencias por sí mismo; uno nuevo empieza desde una copia completa (se actualiza ~una vez al día). Actívalo en cada ordenador.",
    sy_now: "Sincronizar ahora", sy_db: "Copia completa a Drive", sy_last: "Sincronizado: {d}", sy_never: "aún sin sincronizar", sy_err: "Error de sincronización: {e}",
    sy_busy: "Sincronizando…", sy_done: "Sincronizado.", sy_db_done: "Copia completa de la base de datos subida.", sy_db_skip: "La copia no se subió (se están actualizando datos o la base de datos está vacía).",
    sy_got: "Datos actualizados desde el ordenador {c}: {f}", sy_other: "Analītiķis se usó hace poco ({d}) también en el ordenador {c} — no trabajes en ambos a la vez.",
    sy_f_settings: "ajustes", sy_f_user_data: "colecciones y tus marcas", sy_f_catalog_db_gz: "base de datos completa" },
  uk: { sy_chk: "Синхронізувати з іншими комп’ютерами", sy_d: "Налаштування, колекції, об’єднані фото, позначки RF/ED та імпорт (Microstockr, історія портфоліо) — через Google Drive. Дані агентств кожен комп’ютер завантажує сам; новий комп’ютер починає з повної копії (оновлюється ~раз на день). Увімкни на кожному комп’ютері.",
    sy_now: "Синхронізувати зараз", sy_db: "Повна копія в Drive", sy_last: "Синхронізовано: {d}", sy_never: "ще не синхронізовано", sy_err: "Помилка синхронізації: {e}",
    sy_busy: "Синхронізую…", sy_done: "Синхронізовано.", sy_db_done: "Повну копію бази даних завантажено.", sy_db_skip: "Копію не завантажено (оновлюються дані або база порожня).",
    sy_got: "Дані оновлено з комп’ютера {c}: {f}", sy_other: "Analītiķis нещодавно ({d}) використовувався й на комп’ютері {c} — не працюй на обох одночасно.",
    sy_f_settings: "налаштування", sy_f_user_data: "колекції та твої позначки", sy_f_catalog_db_gz: "повна база даних" },
};
for (const l of Object.keys(GS_I18N)) window.I18N[l] = Object.assign(window.I18N[l] || {}, GS_I18N[l]);

const syFiles = (f) => (f || []).map((n) => t("sy_f_" + n.replace(/\.json$/, "").replace(/\./g, "_"))).join(", ");
const syErr = (e) => (gWhy(e) ? t(gWhy(e)) : e);
function syBox() {
  const row = $('.conn[data-p="google"]'); if (!row) return null;
  let b = $(".g-sync", row);
  if (b) return b;
  $(".cn-main", row).insertAdjacentHTML("beforeend", `<div class="g-sync hidden"><label class="chk"><input type="checkbox" class="g-sync-chk"> <span data-i18n="sy_chk"></span></label>
    <div class="muted small" data-i18n="sy_d"></div><div class="row"><button class="small-btn g-sync-now" data-i18n="sy_now"></button>
    <button class="small-btn ghost g-sync-db" data-i18n="sy_db"></button><span class="g-sync-st muted small"></span></div></div>`);
  b = $(".g-sync", row); applyI18n(b);
  $(".g-sync-chk", b).addEventListener("change", async (e) => {
    try { syPaint(await api("google", { do: "sync_set", on: e.target.checked })); S.settings.google_sync = e.target.checked; setTimeout(syPoll, 8000); }
    catch (err) { toast(err.message, "err"); }
  });
  $(".g-sync-now", b).addEventListener("click", async (e) => {
    const btn = e.target; btn.disabled = true; $(".g-sync-st", b).textContent = t("sy_busy");
    try { const d = await api("google", { do: "sync_now" }); syPaint(d); syGot(d); toast(t("sy_done"), "ok", 3000); }
    catch (err) { toast(t("sy_err", { e: syErr(err.message) }), "err", 9000); syLoad(); }
    finally { btn.disabled = false; }
  });
  $(".g-sync-db", b).addEventListener("click", async (e) => {
    const btn = e.target; btn.disabled = true; $(".g-sync-st", b).textContent = t("sy_busy");
    try { const d = await api("google", { do: "sync_db_now" }); toast(t(d.sent && d.sent.length ? "sy_db_done" : "sy_db_skip"), d.sent && d.sent.length ? "ok" : "err", 6000); }
    catch (err) { toast(t("sy_err", { e: syErr(err.message) }), "err", 9000); }
    finally { btn.disabled = false; syLoad(); }
  });
  return b;
}
function syPaint(d) {
  const b = syBox(); if (!b || !d) return;
  $(".g-sync-chk", b).checked = !!d.enabled;
  $(".g-sync-now", b).disabled = $(".g-sync-db", b).disabled = !d.enabled;
  $(".g-sync-st", b).textContent = !d.enabled ? "" : d.err ? t("sy_err", { e: syErr(d.err) }) : t("sy_last", { d: d.last ? fmtDT(d.last) : t("sy_never") });
}
async function syLoad() { try { syPaint(await api("google", { do: "sync_status" })); } catch (_) { /* */ } }
async function syGot(d) {
  if (d.other && GG.other !== d.other.computer) { GG.other = d.other.computer; toast(t("sy_other", { c: d.other.computer, d: fmtDT(d.other.last) }), "err sticky", 15000); }
  if (!d.got_at || d.got_at === GG.gotAt) return;
  GG.gotAt = d.got_at;
  toast(t("sy_got", { c: d.got_from || "?", f: syFiles(d.got) }), "ok sticky", 10000);
  try { S.settings = (await api("state")).settings; } catch (_) { /* */ }
  if ((d.got || []).some((n) => n !== "settings.json")) {
    try { if (typeof refreshColls === "function") await refreshColls(); if (typeof reloadView === "function") reloadView(); } catch (_) { /* */ }
  }
}
async function syPoll() {
  try { const d = await api("google", { do: "sync_status" }); if (d.enabled) { syGot(d); syPaint(d); } } catch (_) { /* */ }
}
const _syPaint0 = gPaint;
gPaint = function (s) {                              // eslint-disable-line no-func-assign
  _syPaint0(s);
  const b = syBox(); if (!b) return;
  const on = !!(s && s.connected);
  b.classList.toggle("hidden", !on);
  if (on) syLoad();
};
setInterval(syPoll, 60000);
setTimeout(syPoll, 15000);
