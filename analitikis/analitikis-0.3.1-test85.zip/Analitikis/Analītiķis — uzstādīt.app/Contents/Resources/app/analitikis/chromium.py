"""Chromium (Qt WebEngine) pārlūks aģentūru lapām uz Mac — izmēģinājums (lēmums 2026-11-19, tehnika §3).

Kāpēc: WKWebView palīgprocesā sīkdatņu krātuve katru reizi tukša ("Adobe sīkdatnes krātuvē: īslaicīgas 0,
ilgtermiņa 0") — ierīces atpazīšana pazūd, aģentūras prasa 2FA. Qt WebEngine profils datu mapē (profile/chromium)
glabā visas sīkdatnes (arī īslaicīgās — ForcePersistentCookies) un pārlūka krātuvi (localStorage, IndexedDB).

Bibliotēkas (QtPy, PyQt6, PyQt6-WebEngine, ~200 MB) uzstāda tikai, kad lietotājs ieslēdz (requirements.txt to nav).
Ja Qt nav vai neizdodas — palīgprocess lieto esošo WKWebView (nekas nesalūzt).
"""
from __future__ import annotations

import importlib.util
import subprocess
import sys
import threading

from . import config

PKGS = ["QtPy", "PyQt6", "PyQt6-WebEngine"]
# Chromium dzinējs → Chrome lietotāja aģents (Qt noklusējumā ir "QtWebEngine/…", ko daļa portālu atraida)
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/130.0.0.0 Safari/537.36")
state = {"installing": False, "msg": "", "ok": None}


def wanted() -> bool:
    return bool(config.IS_MAC and config.get("sales_browser") == "chromium")


def available() -> bool:
    try:
        return all(importlib.util.find_spec(m) is not None for m in ("qtpy", "PyQt6", "PyQt6.QtWebEngineWidgets"))
    except (ImportError, ValueError):
        return False


def use() -> bool:
    return wanted() and available() and not config.get("sales_browser_failed")


def status() -> dict:
    return {"wanted": wanted(), "available": available(), "installing": state["installing"], "msg": state["msg"],
            "mac": bool(config.IS_MAC)}


def install() -> None:
    """Fonā: pip install QtPy PyQt6 PyQt6-WebEngine (Analītiķa .venv) + pārbaude, ka Qt WebEngine ielādējas."""
    if state["installing"]:
        return

    def run():
        state.update(installing=True, msg="installing", ok=None)
        print("Chromium pārlūks: uzstādu bibliotēkas (" + ", ".join(PKGS) + ") …")
        try:
            r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", *PKGS],
                               capture_output=True, text=True, timeout=1800)
            if r.returncode != 0:
                raise RuntimeError((r.stderr or r.stdout)[-500:])
            chk = subprocess.run([sys.executable, "-c", "import qtpy; from qtpy.QtWebEngineWidgets import QWebEngineView; print('ok')"],
                                 capture_output=True, text=True, timeout=180)
            if chk.returncode != 0 or "ok" not in chk.stdout:
                raise RuntimeError((chk.stderr or chk.stdout)[-500:])
            state.update(msg="ok", ok=True)
            print("Chromium pārlūks: bibliotēkas uzstādītas ✓")
        except Exception as e:
            state.update(msg="error: " + str(e)[:400], ok=False)
            print("Chromium pārlūks: uzstādīšana neizdevās:", str(e)[:300])
        finally:
            state["installing"] = False

    threading.Thread(target=run, daemon=True).start()


def prepare(storage: str) -> None:
    """Pirms webview.start(gui="qt"): visiem logiem viens kopīgs pastāvīgs profils (pywebview katram logam veido savu
    ar vienu un to pašu nosaukumu — divi vienlaicīgi logi ar vienu krātuvi Qt nav droši) un ForcePersistentCookies."""
    import webview.platforms.qt as Q   # type: ignore
    Q._profile_storage_path = storage
    orig = Q.QWebEngineProfile
    shared: dict = {}

    def profile(*a, **k):
        if not a and not k:
            return orig()                                   # privātais režīms — nemainām
        name = a[0] if a else k.get("storageName", "pywebview")
        p = shared.get(name)
        if p is None:
            p = orig(name)
            p.setPersistentStoragePath(storage)
            try:
                pol = getattr(orig, "PersistentCookiesPolicy", orig).ForcePersistentCookies
            except AttributeError:
                pol = orig.ForcePersistentCookies
            p.setPersistentCookiesPolicy(pol)
            p.setHttpUserAgent(UA)
            shared[name] = p
        return p

    for attr in ("PersistentCookiesPolicy", "ForcePersistentCookies", "HttpCacheType"):
        if hasattr(orig, attr):
            setattr(profile, attr, getattr(orig, attr))
    profile.defaultProfile = lambda: profile("pywebview")     # vecākas pywebview versijas lieto noklusējuma profilu
    Q.QWebEngineProfile = profile
