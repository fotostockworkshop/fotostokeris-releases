"""Eksports uz Excel (test115, lietotājs 2026-11-22): Iestatījumi → Darbs ar datiem → "Eksports uz Excel".

Uzbūve: lapas "Dati …" ar rindām (var labot/papildināt) + atskaišu lapas ar formulām (SUMIFS u.c.), kas no tām rēķina.
Kopsavilkumā — valūta (USD/EUR), kurss un periods; katrā atskaitē periodu var mainīt arī atsevišķi (dzeltenās šūnas).
Summas datubāzē ir USD; EUR = USD × kurss (izmaksām — īstās EUR summas no izmaksu moduļa). Tikai lasa datus.
"""
from __future__ import annotations

import datetime as dt
import os
import subprocess
import sys
from pathlib import Path

from . import db
from .xlsx import Book, F, col, serial

REPORTS = ["years", "months", "agencies", "downloads", "season", "best", "payouts", "unpaid", "portfolio", "colls", "licenses"]

L = {
    "lv": {
        "sum": "Kopsavilkums", "years": "Pa gadiem", "months": "Pa mēnešiem", "agencies": "Aģentūras periodā",
        "downloads": "Lejupielādes un RPD", "season": "Sezonalitāte", "best": "Labākās 100", "payouts": "Izmaksas",
        "unpaid": "Neizmaksātais", "portfolio": "Portfelis", "colls": "Kolekcijas", "licenses": "Pārdošanas veids",
        "dm": "Dati mēneši", "ds": "Dati pārdošanas", "dl": "Dati labākās", "di": "Dati izmaksas", "dp": "Dati portfelis", "dk": "Dati kolekcijas",
        "title": "Analītiķis — ienākumu kopsavilkums", "made": "Izveidots", "params": "Iestatījumi (dzeltenās šūnas var mainīt — viss pārrēķināsies)",
        "cur": "Valūta", "rate": "Kurss: 1 USD = … EUR", "from": "No", "to": "Līdz", "period": "Periods",
        "per_note": "Periodu var mainīt šeit (dzeltenās šūnas); sākumā ņemts no Kopsavilkuma.",
        "all_time": "Visu laiku", "income": "Ienākumi", "dl_n": "Lejupielādes", "rpd": "Vidēji par lejupielādi (RPD)",
        "first_m": "Pirmais mēnesis", "last_m": "Pēdējais mēnesis", "best_y": "Labākais gads", "best_m": "Labākais mēnesis",
        "paid_tot": "Izmaksāts kopā (saņemts)", "unpaid_now": "Neizmaksāts tagad", "port_now": "Portfelis tagad (faili)",
        "sold_imgs": "Pārdotās bildes", "best_img": "Labākā bilde", "n_colls": "Kolekcijas", "n_ag": "Aģentūras ar ienākumiem",
        "year": "Gads", "month": "Mēnesis", "agency": "Aģentūra", "total": "Kopā", "growth": "Pieaugums", "growth_p": "Pieaugums %",
        "share": "Daļa", "port_end": "Portfelis perioda beigās", "per_file": "Ienākumi uz failu portfelī", "avg": "Vidēji",
        "all": "Visas", "sel_ag": "Aģentūra (izvēlies)", "season_note": "Krāsa: sarkans — vājākie, zaļš — labākie mēneši.",
        "nr": "Nr.", "ttl": "Nosaukums", "fn": "Faila nosaukums", "ags": "Aģentūras", "sales_n": "Pārdošanas", "first_s": "Pirmā pārdošana",
        "last_s": "Pēdējā pārdošana", "app_tot": "Visu laiku (Analītiķī), USD", "date": "Datums", "id": "ID", "lic": "Licence / veids",
        "kind": "Ieraksta veids", "amt_usd": "Summa, USD", "amount": "Summa", "status": "Statuss", "got": "saņemts", "onway": "ceļā",
        "unp": "Neizmaksāts", "avail": "Pieejams izmaksai", "unp_usd": "Neizmaksāts, USD", "unp_eur": "Neizmaksāts, EUR", "shown": "Izvēlētajā valūtā",
        "minp": "Minimums", "next": "Nākamā izmaksa", "lastp": "Pēdējā izmaksa", "lastp_amt": "Pēdējās izmaksas summa",
        "unp_note": "Dati uz eksporta brīdi. Nauda, kas vēl nav saņemta, ir šeit (arī ceļā esošā).",
        "start": "Perioda sākumā", "end": "Perioda beigās", "files": "Faili", "coll": "Kolekcija", "imgs": "Bildes", "per_img": "Uz bildi",
        "none": "(nav norādīts)", "other": "(citas)", "best_note": "Ienākumi periodā — no pārdošanu rindām (lapa “Dati labākās”).",
        "lic_note": "Licences un veidi — kā tos raksta aģentūras.", "pay_note": "Izmaksas pēc saņemšanas datuma; nākotnes datums — ceļā.",
        "port_note": "Faili portfelī mēneša beigās (mēneši bez datiem — pēdējā zināmā vērtība).",
        "data_note": "Šīs rindas var labot un papildināt — atskaites pārrēķināsies.",
        "cat": "Veids", "unsold": "",
    },
    "en": {
        "sum": "Summary", "years": "By year", "months": "By month", "agencies": "Agencies in period",
        "downloads": "Downloads and RPD", "season": "Seasonality", "best": "Top 100", "payouts": "Payouts",
        "unpaid": "Unpaid", "portfolio": "Portfolio", "colls": "Collections", "licenses": "Sale types",
        "dm": "Data months", "ds": "Data sales", "dl": "Data top", "di": "Data payouts", "dp": "Data portfolio", "dk": "Data collections",
        "title": "Analītiķis — earnings summary", "made": "Created", "params": "Settings (yellow cells can be changed — everything recalculates)",
        "cur": "Currency", "rate": "Rate: 1 USD = … EUR", "from": "From", "to": "To", "period": "Period",
        "per_note": "Change the period here (yellow cells); by default taken from the Summary.",
        "all_time": "All time", "income": "Earnings", "dl_n": "Downloads", "rpd": "Revenue per download (RPD)",
        "first_m": "First month", "last_m": "Last month", "best_y": "Best year", "best_m": "Best month",
        "paid_tot": "Paid out in total (received)", "unpaid_now": "Unpaid now", "port_now": "Portfolio now (files)",
        "sold_imgs": "Images sold", "best_img": "Best image", "n_colls": "Collections", "n_ag": "Agencies with earnings",
        "year": "Year", "month": "Month", "agency": "Agency", "total": "Total", "growth": "Growth", "growth_p": "Growth %",
        "share": "Share", "port_end": "Portfolio at period end", "per_file": "Earnings per portfolio file", "avg": "Average",
        "all": "All", "sel_ag": "Agency (choose)", "season_note": "Colour: red — weakest, green — best months.",
        "nr": "No.", "ttl": "Title", "fn": "File name", "ags": "Agencies", "sales_n": "Sales", "first_s": "First sale",
        "last_s": "Last sale", "app_tot": "All time (in Analītiķis), USD", "date": "Date", "id": "ID", "lic": "License / type",
        "kind": "Record type", "amt_usd": "Amount, USD", "amount": "Amount", "status": "Status", "got": "received", "onway": "on the way",
        "unp": "Unpaid", "avail": "Available for payout", "unp_usd": "Unpaid, USD", "unp_eur": "Unpaid, EUR", "shown": "In chosen currency",
        "minp": "Minimum", "next": "Next payout", "lastp": "Last payout", "lastp_amt": "Last payout amount",
        "unp_note": "Data at export time. Money not yet received is here (including money on the way).",
        "start": "Period start", "end": "Period end", "files": "Files", "coll": "Collection", "imgs": "Images", "per_img": "Per image",
        "none": "(not stated)", "other": "(other)", "best_note": "Earnings in period — from the sales rows (sheet “Data top”).",
        "lic_note": "Licenses and types — as the agencies name them.", "pay_note": "Payouts by date received; a future date — on the way.",
        "port_note": "Files in portfolio at month end (months without data — last known value).",
        "data_note": "These rows can be edited and extended — the reports recalculate.",
        "cat": "Type", "unsold": "",
    },
}
MONTHS = {"lv": ["janvāris", "februāris", "marts", "aprīlis", "maijs", "jūnijs", "jūlijs", "augusts", "septembris", "oktobris", "novembris", "decembris"],
          "en": ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]}


def _lang() -> str:
    try:
        from . import config
        lg = config.get("lang") or "lv"
    except Exception:
        lg = "lv"
    return lg if lg in L else "en"


def _agname(a: str) -> str:
    return (db.AGENCIES.get(a) or {}).get("name") or a


def _usd_eur() -> float:
    try:
        from . import fx
        r = fx.rate(db, "EUR", dt.date.today().isoformat())
        return round(1 / r, 6) if r else 0.92
    except Exception:
        return 0.92


def _out_path() -> Path:
    d = Path.home() / "Downloads"
    if not d.is_dir():
        from . import config
        d = config.app_dir() / "eksports"
        d.mkdir(parents=True, exist_ok=True)
    p = d / f"Analitikis_{dt.date.today().isoformat()}.xlsx"
    if p.exists():
        p = d / f"Analitikis_{dt.datetime.now().strftime('%Y-%m-%d_%H%M%S')}.xlsx"
    return p


def _open(p: Path) -> None:
    try:
        if sys.platform == "darwin":
            subprocess.Popen(["open", str(p)])
        elif os.name == "nt":
            os.startfile(str(p))  # type: ignore[attr-defined]
        else:
            subprocess.Popen(["xdg-open", str(p)])
    except Exception as e:
        print("Excel faila atvēršana:", str(e)[:120])


def _period_cells(sh, t, r=2):
    """No/Līdz šūnas (B2, D2) — sākumā no Kopsavilkuma; atgriež absolūtās adreses."""
    sh.set(r, 1, t["from"], "b")
    sh.set(r, 2, F("PerNo"), "indate")
    sh.set(r, 3, t["to"], "b")
    sh.set(r, 4, F("PerLidz"), "indate")
    sh.set(r + 1, 1, t["per_note"], "note")
    sh.widths.setdefault(1, 14)
    sh.widths.setdefault(2, 13)
    sh.widths.setdefault(4, 13)
    return "$B$2", "$D$2"


def export(sel: list[str] | None = None, open_file: bool = True) -> dict:
    lg = _lang()
    t = L[lg]
    sel = [s for s in (REPORTS if sel is None else sel) if s in REPORTS]
    today = dt.date.today()
    c = db.conn()

    # ---------- dati no datubāzes ----------
    mrows = db.q("SELECT agency, month, cat, SUM(earnings) e, SUM(downloads) n FROM monthly GROUP BY agency, month, cat ORDER BY month, agency")
    tot_by = {}
    for r in mrows:
        tot_by[r["agency"]] = tot_by.get(r["agency"], 0) + (r["e"] or 0)
    ags = [a for a, v in sorted(tot_by.items(), key=lambda x: -x[1]) if abs(v) >= 0.005]
    names = [_agname(a) for a in ags]
    months_all = sorted({r["month"] for r in mrows if r["month"]})
    first_m = months_all[0] if months_all else today.strftime("%Y-%m")
    years = list(range(int(first_m[:4]), today.year + 1))
    n_month_rows = (today.year - int(first_m[:4])) * 12 + today.month - int(first_m[5:7]) + 1 + 24

    b = Book()
    # ---------- Kopsavilkums (vienmēr; tajā — iestatījumi) ----------
    K = b.add(t["sum"])
    K.tab = "1F3A93"
    K.widths.update({1: 3, 2: 34, 3: 18, 4: 16, 5: 14, 6: 16, 7: 16, 8: 16})
    K.set(1, 2, t["title"], "title")
    K.set(2, 2, f"{t['made']}: {today.isoformat()}", "note")
    K.set(4, 2, t["params"], "b")
    K.row(5, 2, [t["cur"], "USD"], ["", "in"])
    K.lists.append(("C5", '"USD,EUR"'))
    K.row(6, 2, [t["rate"], _usd_eur()], ["", "inmoney"])
    K.row(7, 2, [t["from"], dt.date.fromisoformat(first_m + "-01")], ["", "indate"])
    K.row(8, 2, [t["to"], today], ["", "indate"])
    qk = K.q()
    b.name("Valuta", f"{qk}!$C$5")
    b.name("Kurss", f"{qk}!$C$6")
    b.name("PerNo", f"{qk}!$C$7")
    b.name("PerLidz", f"{qk}!$C$8")
    b.name("Reiz", 'IF(Valuta="EUR",Kurss,1)')

    # ---------- Dati mēneši ----------
    DM = b.add(t["dm"])
    DM.tab = "999999"
    DM.row(1, 1, [t["month"], t["year"], "Nr", t["agency"], t["cat"], t["amt_usd"], t["dl_n"]], "h")
    for i, r in enumerate(mrows, start=2):
        m = r["month"]
        DM.row(i, 1, [serial(m + "-01"), int(m[:4]), int(m[5:7]), _agname(r["agency"]), r["cat"] or "",
                      round(r["e"] or 0, 4), int(r["n"] or 0)], ["month", "", "", "", "", "money", "int"])
    DM.freeze = (1, 0)
    DM.filter = f"A1:G{max(2, len(mrows) + 1)}"
    DM.widths.update({1: 10, 2: 7, 3: 5, 4: 20, 5: 10, 6: 13, 7: 12})
    qm = DM.q()
    for nm, cl in [("DM_M", "A"), ("DM_G", "B"), ("DM_MN", "C"), ("DM_A", "D"), ("DM_K", "E"), ("DM_E", "F"), ("DM_N", "G")]:
        b.name(nm, f"{qm}!${cl}:${cl}")

    # ---------- Dati portfelis (aizpilda tukšos mēnešus ar pēdējo vērtību) ----------
    prow = db.q("SELECT agency, month, MAX(files) f FROM portfolio WHERE files IS NOT NULL GROUP BY agency, month ORDER BY agency, month")
    pdata, port_now = [], {}
    by_ag = {}
    for r in prow:
        by_ag.setdefault(r["agency"], []).append((r["month"], r["f"]))
    cur_m = today.strftime("%Y-%m")
    for a, lst in by_ag.items():
        known = dict(lst)
        m, last = lst[0][0], None
        while m <= cur_m:
            last = known.get(m, last)
            if last is not None:
                pdata.append((m, a, last))
            y, mo = int(m[:4]), int(m[5:7]) + 1
            m = f"{y + (mo > 12):04d}-{(mo - 1) % 12 + 1:02d}"
        port_now[a] = last
    pags = [a for a in sorted(port_now, key=lambda x: -(port_now[x] or 0))]
    DP = b.add(t["dp"])
    DP.tab = "999999"
    DP.row(1, 1, [t["month"], t["agency"], t["files"]], "h")
    for i, (m, a, f) in enumerate(pdata, start=2):
        DP.row(i, 1, [serial(m + "-01"), _agname(a), int(f)], ["month", "", "int"])
    DP.freeze = (1, 0)
    DP.filter = f"A1:C{max(2, len(pdata) + 1)}"
    DP.widths.update({1: 10, 2: 20, 3: 10})
    qp = DP.q()
    for nm, cl in [("DP_M", "A"), ("DP_A", "B"), ("DP_F", "C")]:
        b.name(nm, f"{qp}!${cl}:${cl}")

    # ---------- Dati izmaksas ----------
    try:
        irows = db.q("SELECT agency, paid_at, amount, currency, amount_usd, amount_eur, status FROM payouts WHERE paid_at IS NOT NULL ORDER BY paid_at")
    except Exception:
        irows = []
    DI = b.add(t["di"])
    DI.tab = "999999"
    DI.row(1, 1, [t["date"], t["month"], t["agency"], t["amount"], t["cur"], "USD", "EUR", t["status"]], "h")
    for i, r in enumerate(irows, start=2):
        d = (r["paid_at"] or "")[:10]
        DI.row(i, 1, [serial(d), serial(d[:7] + "-01"), _agname(r["agency"]), r["amount"], r["currency"] or "",
                      round(r["amount_usd"] or 0, 4), round(r["amount_eur"] or 0, 4), t["onway"] if d > today.isoformat() else t["got"]],
               ["date", "month", "", "money", "", "money", "money", ""])
    DI.freeze = (1, 0)
    DI.filter = f"A1:H{max(2, len(irows) + 1)}"
    DI.widths.update({1: 11, 2: 10, 3: 20, 4: 12, 5: 8, 6: 12, 7: 12, 8: 12})
    qi = DI.q()
    for nm, cl in [("DI_D", "A"), ("DI_M", "B"), ("DI_A", "C"), ("DI_U", "F"), ("DI_E", "G")]:
        b.name(nm, f"{qi}!${cl}:${cl}")

    # ---------- neizmaksātais (momentuzņēmums) ----------
    unpaid = []
    try:
        from . import payouts
        for r in payouts.overview()["rows"]:
            amt = float(r.get("unpaid") or 0)
            cur = r.get("currency") or "USD"
            usd = payouts.to_usd(c, r["agency"], amt, cur, today.isoformat()) if amt else 0.0
            eur = payouts.usd_to_eur(usd, today.isoformat()) if usd else 0.0
            last = r.get("last") or {}
            unpaid.append({"a": r["agency"], "unp": amt, "av": float(r.get("available") or 0), "cur": cur, "usd": round(usd, 2),
                           "eur": round(eur, 2), "min": r.get("min"), "next": r.get("next_date"),
                           "lp": (last.get("paid_at") or "")[:10], "lpa": last.get("amount"), "lpc": last.get("currency") or ""})
    except Exception as e:
        print("Excel eksports — neizmaksātais:", str(e)[:160])
    unp_usd = round(sum(x["usd"] for x in unpaid), 2)
    unp_eur = round(sum(x["eur"] for x in unpaid), 2)

    # ---------- Kopsavilkuma saturs ----------
    best_m = db.q1("SELECT month, SUM(earnings) e FROM monthly GROUP BY month ORDER BY e DESC LIMIT 1")
    sold = db.q1("SELECT COUNT(*) c FROM (SELECT DISTINCT agency, agency_item_id FROM sales WHERE kind!='other')")
    try:
        bi = db.best("all", "", True, 0, 1)["rows"]
    except Exception:
        bi = []
    try:
        ncoll = db.q1("SELECT COUNT(*) c FROM collections")["c"]
    except Exception:
        ncoll = 0
    r0 = 10
    K.set(r0, 2, t["all_time"], "title")
    yr0 = r0 + 15                                           # gadu tabulas sākums (vajag "labākajam gadam")
    yr_last = yr0 + len(years)
    lines = [
        (t["income"], F("SUM(DM_E)*Reiz"), "bmoney"),
        (t["dl_n"], F("SUM(DM_N)"), "bint"),
        (t["rpd"], F(f"IFERROR(C{r0 + 1}/C{r0 + 2},\"\")"), "rpd"),
        (t["first_m"], F("MIN(DM_M)"), "month"),
        (t["n_ag"], len(ags), "int"),
        (t["best_y"], F(f"INDEX($B${yr0 + 1}:$B${yr_last},MATCH(MAX($C${yr0 + 1}:$C${yr_last}),$C${yr0 + 1}:$C${yr_last},0))"), ""),
        (t["best_m"], serial(best_m["month"] + "-01") if best_m else "", "month"),
        (t["paid_tot"], F('IF(Valuta="EUR",SUMIFS(DI_E,DI_D,"<="&TODAY()),SUMIFS(DI_U,DI_D,"<="&TODAY()))'), "money"),
        (t["unpaid_now"], F(f'IF(Valuta="EUR",{unp_eur},{unp_usd})'), "money"),
        (t["port_now"], sum(v or 0 for v in port_now.values()), "int"),
        (t["sold_imgs"], (sold["c"] if sold else 0), "int"),
        (t["best_img"], (bi[0].get("title") or bi[0].get("filename") or "") if bi else "", ""),
        (t["n_colls"], ncoll, "int"),
    ]
    for i, (lab, v, st) in enumerate(lines, start=r0 + 1):
        K.set(i, 2, lab)
        K.set(i, 3, v, st)
    if best_m:
        K.set(r0 + 7, 4, F(f"{round(best_m['e'] or 0, 2)}*Reiz"), "money")
    if bi:
        K.set(r0 + 12, 4, F(f"{round(bi[0].get('e') or 0, 2)}*Reiz"), "money")
    # gadi (visu laiku)
    K.row(yr0, 2, [t["year"], t["income"], t["growth_p"], t["dl_n"], "RPD"], "h")
    for i, y in enumerate(years, start=yr0 + 1):
        K.set(i, 2, y)
        K.set(i, 3, F(f"SUMIFS(DM_E,DM_G,B{i})*Reiz"), "money")
        K.set(i, 4, F(f"IFERROR(C{i}/C{i - 1}-1,\"\")") if i > yr0 + 1 else "", "pct")
        K.set(i, 5, F(f"SUMIFS(DM_N,DM_G,B{i})"), "int")
        K.set(i, 6, F(f"IFERROR(C{i}/E{i},\"\")"), "rpd")
    # aģentūras (visu laiku)
    a0 = yr_last + 3
    K.row(a0, 2, [t["agency"], t["income"], t["share"], t["dl_n"], "RPD", t["first_m"], t["last_m"]], "h")
    for i, nm in enumerate(names, start=a0 + 1):
        K.set(i, 2, nm)
        K.set(i, 3, F(f"SUMIFS(DM_E,DM_A,B{i})*Reiz"), "money")
        K.set(i, 4, F(f"IFERROR(C{i}/$C${r0 + 1},\"\")"), "pct")
        K.set(i, 5, F(f"SUMIFS(DM_N,DM_A,B{i})"), "int")
        K.set(i, 6, F(f"IFERROR(C{i}/E{i},\"\")"), "rpd")
        K.set(i, 7, F(f'_xlfn.MINIFS(DM_M,DM_A,B{i},DM_E,"<>0")'), "month")
        K.set(i, 8, F(f'_xlfn.MAXIFS(DM_M,DM_A,B{i},DM_E,"<>0")'), "month")

    # ---------- palīgi atskaitēm ----------
    def ag_grid(sh, hdr_row, first_row, row_keys, cell_f, key_st="", label=None, total_row=True, tot_st="bmoney", val_st="money", extra=None):
        """Rindas × aģentūras + Kopā kolonna (+ Kopā rinda apakšā)."""
        sh.set(hdr_row, 1, label or "", "h")
        for j, nm in enumerate(names, start=2):
            sh.set(hdr_row, j, nm, "h")
            sh.widths[j] = max(12, min(18, len(nm) + 2))
        tc = len(names) + 2
        sh.set(hdr_row, tc, t["total"], "h")
        sh.widths[tc] = 14
        last = first_row + len(row_keys) - 1
        for i, k in enumerate(row_keys, start=first_row):
            sh.set(i, 1, k, key_st)
            for j in range(2, tc):
                sh.set(i, j, cell_f(i, j), val_st)
            sh.set(i, tc, F(f'IF($A{i}="","",SUM(B{i}:{col(tc - 1)}{i}))'), tot_st)
        if extra:
            extra(tc, last)
        if total_row and row_keys:
            tr = last + 1
            sh.set(tr, 1, t["total"], "b")
            for j in range(2, tc + 1):
                sh.set(tr, j, F(f"SUM({col(j)}{first_row}:{col(j)}{last})"), tot_st)
        sh.freeze = (hdr_row, 1)
        return tc, last

    def month_keys(sh, first_row, n, no="$B$2", lidz="$D$2"):
        keys = []
        for i in range(n):
            r = first_row + i
            if i == 0:
                keys.append(F(f"DATE(YEAR({no}),MONTH({no}),1)"))
            else:
                keys.append(F(f'IF(A{r - 1}="","",IF(EDATE(A{r - 1},1)>{lidz},"",EDATE(A{r - 1},1)))'))
        return keys

    per = 'DM_M,">="&$B$2,DM_M,"<="&$D$2'

    if "years" in sel:
        sh = b.add(t["years"])
        _period_cells(sh, t)
        sh.set(5, 1, t["income"] + " — " + t["year"], "b")
        tc, last = ag_grid(sh, 6, 7, years, lambda i, j: F(f"SUMIFS(DM_E,DM_A,{col(j)}$6,DM_G,$A{i},{per})*Reiz"), label=t["year"])
        sh.set(6, tc + 1, t["growth_p"], "h")
        for i in range(8, last + 1):
            sh.set(i, tc + 1, F(f'IFERROR({col(tc)}{i}/{col(tc)}{i - 1}-1,"")'), "pct")
        sh.widths[tc + 1] = 12

    if "months" in sel:
        sh = b.add(t["months"])
        _period_cells(sh, t)
        sh.set(5, 1, t["income"] + " — " + t["month"], "b")
        keys = month_keys(sh, 7, n_month_rows)
        ag_grid(sh, 6, 7, keys, lambda i, j: F(f'IF($A{i}="","",SUMIFS(DM_E,DM_A,{col(j)}$6,DM_M,$A{i})*Reiz)'), key_st="month", label=t["month"])

    if "agencies" in sel:
        sh = b.add(t["agencies"])
        _period_cells(sh, t)
        hdr = [t["agency"], t["income"], t["share"], t["dl_n"], "RPD", t["port_end"], t["per_file"]]
        sh.row(5, 1, hdr, "h")
        sh.widths.update({1: 22, 2: 14, 3: 9, 4: 13, 5: 10, 6: 14, 7: 14})
        last = 5 + len(names)
        for i, nm in enumerate(names, start=6):
            sh.set(i, 1, nm)
            sh.set(i, 2, F(f"SUMIFS(DM_E,DM_A,$A{i},{per})*Reiz"), "money")
            sh.set(i, 3, F(f'IFERROR(B{i}/$B${last + 1},"")'), "pct")
            sh.set(i, 4, F(f"SUMIFS(DM_N,DM_A,$A{i},{per})"), "int")
            sh.set(i, 5, F(f'IFERROR(B{i}/D{i},"")'), "rpd")
            sh.set(i, 6, F(f'SUMIFS(DP_F,DP_A,$A{i},DP_M,DATE(YEAR($D$2),MONTH($D$2),1))'), "int")
            sh.set(i, 7, F(f'IFERROR(B{i}/F{i},"")'), "rpd")
        tr = last + 1
        sh.set(tr, 1, t["total"], "b")
        for j, st in [(2, "bmoney"), (4, "bint"), (6, "bint")]:
            sh.set(tr, j, F(f"SUM({col(j)}6:{col(j)}{last})"), st)
        sh.set(tr, 3, F(f'IFERROR(B{tr}/B{tr},"")'), "bpct")
        sh.set(tr, 5, F(f'IFERROR(B{tr}/D{tr},"")'), "rpd")
        sh.set(tr, 7, F(f'IFERROR(B{tr}/F{tr},"")'), "rpd")
        sh.freeze = (5, 1)

    if "downloads" in sel:
        sh = b.add(t["downloads"])
        _period_cells(sh, t)
        sh.set(5, 1, t["dl_n"], "b")
        _tc, last = ag_grid(sh, 6, 7, years, lambda i, j: F(f"SUMIFS(DM_N,DM_A,{col(j)}$6,DM_G,$A{i},{per})"),
                            label=t["year"], tot_st="bint", val_st="int")
        h2 = last + 4
        sh.set(h2 - 1, 1, t["rpd"], "b")
        sh.set(h2, 1, t["year"], "h")
        for j, nm in enumerate(names, start=2):
            sh.set(h2, j, nm, "h")
        tc = len(names) + 2
        sh.set(h2, tc, t["total"], "h")
        for k, y in enumerate(years):
            i, src = h2 + 1 + k, 7 + k
            sh.set(i, 1, y)
            for j in range(2, tc):
                sh.set(i, j, F(f'IFERROR(SUMIFS(DM_E,DM_A,{col(j)}$6,DM_G,$A{i},{per})*Reiz/{col(j)}{src},"")'), "rpd")
            sh.set(i, tc, F(f'IFERROR(SUMIFS(DM_E,DM_G,$A{i},{per})*Reiz/{col(tc)}{src},"")'), "rpd")

    if "season" in sel:
        sh = b.add(t["season"])
        _period_cells(sh, t)
        sh.set(3, 1, t["sel_ag"], "b")
        sh.set(3, 2, t["all"], "in")
        lc = len(years) + 6
        sh.set(1, lc, t["agency"], "note")
        for k, nm in enumerate([t["all"]] + names):
            sh.set(2 + k, lc, nm, "note")
        sh.lists.append(("B3", f"${col(lc)}$2:${col(lc)}${2 + len(names)}"))
        sh.set(4, 1, t["season_note"], "note")
        sh.row(6, 1, ["Nr", t["month"]] + years + [t["avg"]], "h")
        crit = f'IF($B$3="{t["all"]}","*",$B$3)'
        for m in range(1, 13):
            i = 6 + m
            sh.set(i, 1, m)
            sh.set(i, 2, MONTHS.get(lg, MONTHS["en"])[m - 1])
            for k, y in enumerate(years):
                sh.set(i, 3 + k, F(f"SUMIFS(DM_E,DM_A,{crit},DM_G,{col(3 + k)}$6,DM_MN,$A{i},{per})*Reiz"), "money")
            sh.set(i, 3 + len(years), F(f'IFERROR(AVERAGEIF(C{i}:{col(2 + len(years))}{i},"<>0"),"")'), "money")
        sh.set(19, 2, t["total"], "b")
        for k in range(len(years) + 1):
            sh.set(19, 3 + k, F(f"SUM({col(3 + k)}7:{col(3 + k)}18)"), "bmoney")
        for k in range(len(years)):
            sh.scales.append(f"{col(3 + k)}7:{col(3 + k)}18")
        sh.widths.update({1: 5, 2: 14})
        for k in range(len(years) + 1):
            sh.widths[3 + k] = 11
        sh.freeze = (6, 2)

    if "best" in sel:
        try:
            top = db.best("all", "", True, 0, 100)["rows"]
        except Exception as e:
            print("Excel eksports — labākās:", str(e)[:160])
            top = []
        DL = b.add(t["dl"])
        DL.tab = "999999"
        DL.row(1, 1, [t["nr"], t["date"], t["agency"], t["id"], t["lic"], t["sales_n"], t["amt_usd"]], "h")
        rr = 2
        tags = []
        for nr, g in enumerate(top, start=1):
            for m in g.get("members") or []:
                if m["agency"] not in tags:
                    tags.append(m["agency"])
                for s in db.q("""SELECT day, license, cnt, COALESCE(amount_usd, amount) a FROM sales WHERE agency=? AND agency_item_id=?
                                 ORDER BY day""", (m["agency"], str(m["agency_item_id"]))):
                    DL.row(rr, 1, [nr, serial(s["day"]), _agname(m["agency"]), str(m["agency_item_id"]), s["license"] or "",
                                   int(s["cnt"] or 1), round(s["a"] or 0, 4)], ["", "date", "", "", "", "int", "money"])
                    rr += 1
        DL.freeze = (1, 0)
        DL.filter = f"A1:G{max(2, rr - 1)}"
        DL.widths.update({1: 6, 2: 11, 3: 18, 4: 16, 5: 22, 6: 10, 7: 12})
        ql = DL.q()
        for nm, cl in [("DL_NR", "A"), ("DL_D", "B"), ("DL_A", "C"), ("DL_N", "F"), ("DL_S", "G")]:
            b.name(nm, f"{ql}!${cl}:${cl}")
        sh = b.add(t["best"])
        _period_cells(sh, t)
        sh.set(4, 1, t["best_note"], "note")
        tn = [_agname(a) for a in tags]
        hdr = [t["nr"], t["ttl"], t["fn"], t["ags"], t["income"], t["sales_n"], t["first_s"], t["last_s"], t["app_tot"]] + tn
        sh.row(6, 1, hdr, "h")
        sh.widths.update({1: 5, 2: 40, 3: 22, 4: 26, 5: 13, 6: 11, 7: 12, 8: 12, 9: 14})
        pl = 'DL_D,">="&$B$2,DL_D,"<="&$D$2'
        for nr, g in enumerate(top, start=1):
            i = 6 + nr
            mem = g.get("members") or []
            sh.row(i, 1, [nr, g.get("title") or "", g.get("filename") or "", ", ".join(_agname(m["agency"]) for m in mem)])
            sh.set(i, 5, F(f"SUMIFS(DL_S,DL_NR,$A{i},{pl})*Reiz"), "money")
            sh.set(i, 6, F(f"SUMIFS(DL_N,DL_NR,$A{i},{pl})"), "int")
            sh.set(i, 7, F(f'IFERROR(1/(1/_xlfn.MINIFS(DL_D,DL_NR,$A{i})),"")'), "date")
            sh.set(i, 8, F(f'IFERROR(1/(1/_xlfn.MAXIFS(DL_D,DL_NR,$A{i})),"")'), "date")
            sh.set(i, 9, round(g.get("e") or 0, 2), "money")
            for k, nm in enumerate(tn):
                cj = 10 + k
                sh.set(i, cj, F(f"SUMIFS(DL_S,DL_NR,$A{i},DL_A,{col(cj)}$6,{pl})*Reiz"), "money")
                sh.widths[cj] = max(11, min(16, len(nm) + 2))
        if top:
            tr = 7 + len(top)
            sh.set(tr, 2, t["total"], "b")
            for j in [5, 6, 9] + [10 + k for k in range(len(tn))]:
                sh.set(tr, j, F(f"SUM({col(j)}7:{col(j)}{tr - 1})"), "bint" if j == 6 else "bmoney")
        sh.freeze = (6, 2)

    if "payouts" in sel:
        sh = b.add(t["payouts"])
        _period_cells(sh, t)
        sh.set(4, 1, t["pay_note"], "note")
        pags_i = []
        for r in irows:
            if r["agency"] not in pags_i:
                pags_i.append(r["agency"])
        pn = [_agname(a) for a in pags_i]
        sh.set(6, 1, t["month"], "h")
        for j, nm in enumerate(pn, start=2):
            sh.set(6, j, nm, "h")
            sh.widths[j] = max(12, min(18, len(nm) + 2))
        tc = len(pn) + 2
        sh.set(6, tc, t["total"], "h")
        sh.widths[tc] = 14
        keys = month_keys(sh, 7, n_month_rows)
        last = 6 + len(keys)
        for k, kf in enumerate(keys):
            i = 7 + k
            sh.set(i, 1, kf, "month")
            for j in range(2, tc):
                cj = f"{col(j)}$6"
                sh.set(i, j, F(f'IF($A{i}="","",IF(Valuta="EUR",SUMIFS(DI_E,DI_A,{cj},DI_M,$A{i}),SUMIFS(DI_U,DI_A,{cj},DI_M,$A{i})))'), "money")
            sh.set(i, tc, F(f'IF($A{i}="","",SUM(B{i}:{col(tc - 1)}{i}))'), "bmoney")
        sh.set(last + 1, 1, t["total"], "b")
        for j in range(2, tc + 1):
            sh.set(last + 1, j, F(f"SUM({col(j)}7:{col(j)}{last})"), "bmoney")
        sh.freeze = (6, 1)

    if "unpaid" in sel:
        sh = b.add(t["unpaid"])
        sh.set(1, 1, t["unpaid"], "title")
        sh.set(2, 1, t["unp_note"], "note")
        hdr = [t["agency"], t["unp"], t["avail"], t["cur"], t["unp_usd"], t["unp_eur"], t["shown"], t["minp"], t["next"], t["lastp"], t["lastp_amt"], t["cur"]]
        sh.row(4, 1, hdr, "h")
        sh.widths.update({1: 20, 2: 13, 3: 13, 4: 8, 5: 13, 6: 13, 7: 14, 8: 10, 9: 13, 10: 13, 11: 13, 12: 8})
        for i, x in enumerate(unpaid, start=5):
            sh.row(i, 1, [_agname(x["a"]), x["unp"], x["av"], x["cur"], x["usd"], x["eur"]],
                   ["", "money", "money", "", "money", "money"])
            sh.set(i, 7, F(f'IF(Valuta="EUR",F{i},E{i})'), "money")
            sh.set(i, 8, x["min"], "money")
            sh.set(i, 9, serial(x["next"]) if x["next"] else "", "date")
            sh.set(i, 10, serial(x["lp"]) if x["lp"] else "", "date")
            sh.set(i, 11, x["lpa"], "money")
            sh.set(i, 12, x["lpc"])
        if unpaid:
            tr = 5 + len(unpaid)
            sh.set(tr, 1, t["total"], "b")
            for j in (5, 6, 7):
                sh.set(tr, j, F(f"SUM({col(j)}5:{col(j)}{tr - 1})"), "bmoney")
        sh.freeze = (4, 1)

    if "portfolio" in sel:
        sh = b.add(t["portfolio"])
        _period_cells(sh, t)
        sh.set(4, 1, t["port_note"], "note")
        pn = [_agname(a) for a in pags]
        sh.set(6, 1, "", "h")
        for j, nm in enumerate(pn, start=2):
            sh.set(6, j, nm, "h")
            sh.widths[j] = max(11, min(18, len(nm) + 2))
        tc = len(pn) + 2
        sh.set(6, tc, t["total"], "h")
        sh.set(6, tc + 1, t["growth"], "h")
        sh.widths[tc] = 12
        sh.widths[tc + 1] = 12
        # sākums: pirmais zināmais mēnesis, ja periods sākas pirms portfeļa datiem; beigas: pēdējais zināmais
        lab = [(7, t["start"], "MAX(DATE(YEAR($B$2),MONTH($B$2),1),_xlfn.MINIFS(DP_M,DP_A,{h}))"),
               (8, t["end"], "MIN(DATE(YEAR($D$2),MONTH($D$2),1),_xlfn.MAXIFS(DP_M,DP_A,{h}))")]
        for r, l, mf in lab:
            sh.set(r, 1, l, "b")
            for j in range(2, tc):
                sh.set(r, j, F(f"SUMIFS(DP_F,DP_A,{col(j)}$6,DP_M,{mf.format(h=col(j) + '$6')})"), "bint")
            sh.set(r, tc, F(f"SUM(B{r}:{col(tc - 1)}{r})"), "bint")
        sh.set(9, 1, t["growth"], "b")
        sh.set(10, 1, t["growth_p"], "b")
        for j in range(2, tc + 1):
            sh.set(9, j, F(f"{col(j)}8-{col(j)}7"), "bint")
            sh.set(10, j, F(f'IFERROR({col(j)}9/{col(j)}7,"")'), "bpct")
        sh.set(12, 1, t["month"], "h")
        for j in range(2, tc):
            sh.set(12, j, F(f"{col(j)}$6"), "h")
        sh.set(12, tc, t["total"], "h")
        sh.set(12, tc + 1, t["growth"], "h")
        keys = month_keys(sh, 13, n_month_rows)
        for k, kf in enumerate(keys):
            i = 13 + k
            sh.set(i, 1, kf, "month")
            for j in range(2, tc):
                sh.set(i, j, F(f'IF($A{i}="","",SUMIFS(DP_F,DP_A,{col(j)}$6,DP_M,$A{i}))'), "int")
            sh.set(i, tc, F(f'IF($A{i}="","",SUM(B{i}:{col(tc - 1)}{i}))'), "bint")
            if k:
                sh.set(i, tc + 1, F(f'IF($A{i}="","",{col(tc)}{i}-{col(tc)}{i - 1})'), "int")
        sh.freeze = (12, 1)

    if "colls" in sel:
        try:
            crow = db.q("""SELECT c.name, ci.agency, ci.agency_item_id FROM collections c JOIN collection_items ci ON ci.collection_id=c.id
                           ORDER BY c.name""")
        except Exception:
            crow = []
        DK = b.add(t["dk"])
        DK.tab = "999999"
        DK.row(1, 1, [t["coll"], t["date"], t["agency"], t["id"], t["sales_n"], t["amt_usd"]], "h")
        rr, cnt = 2, {}
        for r in crow:
            cnt[r["name"]] = cnt.get(r["name"], 0) + 1
            for s in db.q("SELECT day, cnt, COALESCE(amount_usd, amount) a FROM sales WHERE agency=? AND agency_item_id=? ORDER BY day",
                          (r["agency"], str(r["agency_item_id"]))):
                DK.row(rr, 1, [r["name"], serial(s["day"]), _agname(r["agency"]), str(r["agency_item_id"]), int(s["cnt"] or 1),
                               round(s["a"] or 0, 4)], ["", "date", "", "", "int", "money"])
                rr += 1
        DK.freeze = (1, 0)
        DK.filter = f"A1:F{max(2, rr - 1)}"
        DK.widths.update({1: 22, 2: 11, 3: 18, 4: 16, 5: 10, 6: 12})
        qc = DK.q()
        for nm, cl in [("DK_K", "A"), ("DK_D", "B"), ("DK_N", "E"), ("DK_S", "F")]:
            b.name(nm, f"{qc}!${cl}:${cl}")
        sh = b.add(t["colls"])
        _period_cells(sh, t)
        sh.row(5, 1, [t["coll"], t["imgs"], t["income"], t["sales_n"], t["per_img"], t["share"]], "h")
        sh.widths.update({1: 26, 2: 9, 3: 14, 4: 12, 5: 12, 6: 9})
        pk = 'DK_D,">="&$B$2,DK_D,"<="&$D$2'
        cn = sorted(cnt)
        last = 5 + len(cn)
        for i, nm in enumerate(cn, start=6):
            sh.set(i, 1, nm)
            sh.set(i, 2, cnt[nm], "int")
            sh.set(i, 3, F(f'SUMIFS(DK_S,DK_K,"="&$A{i},{pk})*Reiz'), "money")
            sh.set(i, 4, F(f'SUMIFS(DK_N,DK_K,"="&$A{i},{pk})'), "int")
            sh.set(i, 5, F(f'IFERROR(C{i}/B{i},"")'), "money")
            sh.set(i, 6, F(f'IFERROR(C{i}/(SUMIFS(DM_E,{per})*Reiz),"")'), "pct")
        sh.freeze = (5, 1)

    if "licenses" in sel:
        srows = db.q("""SELECT day, agency, agency_item_id, license, kind, cnt, COALESCE(amount_usd, amount) a FROM sales ORDER BY day""")
        tot = {}
        for s in srows:
            k = (s["agency"], (s["license"] or "").strip() or t["none"])
            tot[k] = tot.get(k, 0) + (s["a"] or 0)
        keep = set(k for k, _v in sorted(tot.items(), key=lambda x: -x[1])[:300])
        DS = b.add(t["ds"])
        DS.tab = "999999"
        DS.row(1, 1, [t["date"], t["agency"], t["id"], t["lic"], t["kind"], t["sales_n"], t["amt_usd"]], "h")
        for i, s in enumerate(srows, start=2):
            lic = (s["license"] or "").strip() or t["none"]
            if (s["agency"], lic) not in keep:
                lic = t["other"]
            DS.row(i, 1, [serial(s["day"]), _agname(s["agency"]), str(s["agency_item_id"] or ""), lic, s["kind"] or "",
                          int(s["cnt"] or 1), round(s["a"] or 0, 4)], ["date", "", "", "", "", "int", "money"])
        DS.freeze = (1, 0)
        DS.filter = f"A1:G{max(2, len(srows) + 1)}"
        DS.widths.update({1: 11, 2: 18, 3: 16, 4: 30, 5: 8, 6: 10, 7: 12})
        qs = DS.q()
        for nm, cl in [("DS_D", "A"), ("DS_A", "B"), ("DS_L", "D"), ("DS_N", "F"), ("DS_S", "G")]:
            b.name(nm, f"{qs}!${cl}:${cl}")
        combos = {}
        for (a, lic), v in tot.items():
            lic2 = lic if (a, lic) in keep else t["other"]
            combos[(a, lic2)] = combos.get((a, lic2), 0) + v
        order = sorted(combos, key=lambda k: (-tot_by.get(k[0], 0), -combos[k]))
        sh = b.add(t["licenses"])
        _period_cells(sh, t)
        sh.set(4, 1, t["lic_note"], "note")
        sh.row(5, 1, [t["agency"], t["lic"], t["income"], t["sales_n"], t["avg"], t["share"]], "h")
        sh.widths.update({1: 20, 2: 34, 3: 14, 4: 12, 5: 11, 6: 9})
        ps = 'DS_D,">="&$B$2,DS_D,"<="&$D$2'
        for i, (a, lic) in enumerate(order, start=6):
            sh.set(i, 1, _agname(a))
            sh.set(i, 2, lic)
            sh.set(i, 3, F(f'SUMIFS(DS_S,DS_A,$A{i},DS_L,"="&$B{i},{ps})*Reiz'), "money")
            sh.set(i, 4, F(f'SUMIFS(DS_N,DS_A,$A{i},DS_L,"="&$B{i},{ps})'), "int")
            sh.set(i, 5, F(f'IFERROR(C{i}/D{i},"")'), "rpd")
            sh.set(i, 6, F(f'IFERROR(C{i}/(SUMIFS(DS_S,DS_A,$A{i},{ps})*Reiz),"")'), "pct")
        sh.filter = f"A5:F{5 + len(order)}"
        sh.freeze = (5, 2)

    # datu lapas — beigās
    data = [s for s in b.sheets if s.tab == "999999"]
    b.sheets = [s for s in b.sheets if s.tab != "999999"] + data
    for s in data:
        s.set(1, 12, t["data_note"], "note")
    p = _out_path()
    b.save(str(p), t["title"])
    print(f"Excel eksports: {p} ({len(b.sheets)} lapas)")
    if open_file:
        _open(p)
    return {"path": str(p), "sheets": len(b.sheets)}
