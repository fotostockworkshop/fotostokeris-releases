"""Mazs .xlsx rakstītājs bez papildu bibliotēkām (test115, Excel eksports).

Atbalsta: teksts, skaitļi, datumi, formulas (Excel pārrēķina, atverot — fullCalcOnLoad), stili (fiksēts komplekts),
kolonnu platumi, iesaldētas rindas/kolonnas, automātiskais filtrs, krāsu skala, saraksta izvēle šūnā, nosauktās šūnas.
"""
from __future__ import annotations

import datetime as dt
import re
import zipfile
from xml.sax.saxutils import escape

# stilu indeksi (cellXfs secība styles.xml)
S = {"": 0, "h": 1, "money": 2, "int": 3, "date": 4, "month": 5, "pct": 6, "bmoney": 7, "bint": 8,
     "in": 9, "title": 10, "indate": 11, "rpd": 12, "note": 13, "b": 14, "bpct": 15, "inmoney": 16, "inmonth": 17}

_STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<numFmts count="6"><numFmt numFmtId="164" formatCode="#,##0.00"/><numFmt numFmtId="165" formatCode="yyyy\\-mm\\-dd"/>
<numFmt numFmtId="166" formatCode="yyyy\\-mm"/><numFmt numFmtId="167" formatCode="0.0%"/><numFmt numFmtId="168" formatCode="#,##0.000"/>
<numFmt numFmtId="169" formatCode="#,##0"/></numFmts>
<fonts count="5"><font><sz val="11"/><name val="Calibri"/><family val="2"/></font>
<font><b/><sz val="11"/><name val="Calibri"/><family val="2"/></font>
<font><b/><sz val="15"/><name val="Calibri"/><family val="2"/></font>
<font><i/><sz val="10"/><color rgb="FF666666"/><name val="Calibri"/><family val="2"/></font>
<font><sz val="11"/><color rgb="FF1F3A93"/><name val="Calibri"/><family val="2"/></font></fonts>
<fills count="5"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFDCE6F1"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFFFF2CC"/><bgColor indexed="64"/></patternFill></fill>
<fill><patternFill patternType="solid"><fgColor rgb="FFEDEDED"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
<border><left/><right/><top/><bottom style="thin"><color rgb="FF999999"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="18">
<xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
<xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyFont="1" applyFill="1" applyBorder="1"><alignment wrapText="1" vertical="center"/></xf>
<xf numFmtId="164" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="169" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="165" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="166" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="167" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="164" fontId="1" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="169" fontId="1" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="0" fontId="4" fillId="3" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
<xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
<xf numFmtId="165" fontId="4" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="168" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>
<xf numFmtId="0" fontId="3" fillId="0" borderId="0" xfId="0" applyFont="1"><alignment wrapText="0"/></xf>
<xf numFmtId="0" fontId="1" fillId="4" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
<xf numFmtId="167" fontId="1" fillId="4" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="168" fontId="4" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
<xf numFmtId="166" fontId="4" fillId="3" borderId="0" xfId="0" applyNumberFormat="1" applyFont="1" applyFill="1"/>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>"""

_BAD = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
_EPOCH = dt.date(1899, 12, 30)


def col(n: int) -> str:
    """1 → A, 27 → AA"""
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def ref(r: int, c: int, abs_: bool = False) -> str:
    return f"${col(c)}${r}" if abs_ else f"{col(c)}{r}"


def serial(d) -> float | None:
    if not d:
        return None
    if isinstance(d, str):
        try:
            d = dt.date.fromisoformat(d[:10] if len(d) >= 10 else d[:7] + "-01")
        except ValueError:
            return None
    if isinstance(d, dt.datetime):
        d = d.date()
    return float((d - _EPOCH).days)


class F(str):
    """Formula (bez sākuma "=")."""


class Sheet:
    def __init__(self, name: str):
        self.name = name[:31]
        self.cells: dict[int, dict[int, tuple]] = {}
        self.widths: dict[int, float] = {}
        self.freeze: tuple[int, int] | None = None
        self.filter: str | None = None
        self.scales: list[str] = []
        self.lists: list[tuple[str, str]] = []
        self.merges: list[str] = []
        self.tab: str | None = None

    def set(self, r: int, c: int, v, st: str = ""):
        if v is None or v == "":
            if st:
                self.cells.setdefault(r, {})[c] = (None, S[st])
            return
        self.cells.setdefault(r, {})[c] = (v, S[st])

    def row(self, r: int, c0: int, vals: list, st: str | list = ""):
        for i, v in enumerate(vals):
            self.set(r, c0 + i, v, st[i] if isinstance(st, list) else st)

    def q(self) -> str:
        """Lapas nosaukums formulām."""
        return "'" + self.name.replace("'", "''") + "'"

    def xml(self) -> str:
        out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
               '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
               'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">']
        if self.tab:
            out.append(f'<sheetPr><tabColor rgb="FF{self.tab}"/></sheetPr>')
        out.append('<sheetViews><sheetView workbookViewId="0">')
        if self.freeze:
            fr, fc = self.freeze
            tl = ref(fr + 1, fc + 1)
            attrs = (f' xSplit="{fc}"' if fc else "") + (f' ySplit="{fr}"' if fr else "")
            pane = "bottomRight" if fr and fc else ("bottomLeft" if fr else "topRight")
            out.append(f'<pane{attrs} topLeftCell="{tl}" activePane="{pane}" state="frozen"/>'
                       f'<selection pane="{pane}"/>')
        out.append('</sheetView></sheetViews><sheetFormatPr defaultRowHeight="15"/>')
        if self.widths:
            out.append("<cols>" + "".join(f'<col min="{c}" max="{c}" width="{w}" customWidth="1"/>'
                                          for c, w in sorted(self.widths.items())) + "</cols>")
        out.append("<sheetData>")
        for r in sorted(self.cells):
            cs = []
            for c in sorted(self.cells[r]):
                v, s = self.cells[r][c]
                a = f'r="{col(c)}{r}"' + (f' s="{s}"' if s else "")
                if v is None:
                    cs.append(f"<c {a}/>")
                elif isinstance(v, F):
                    cs.append(f"<c {a}><f>{escape(str(v))}</f></c>")
                elif isinstance(v, bool):
                    cs.append(f'<c {a} t="b"><v>{int(v)}</v></c>')
                elif isinstance(v, (int, float)):
                    cs.append(f"<c {a}><v>{repr(float(v)) if isinstance(v, float) else v}</v></c>")
                elif isinstance(v, (dt.date, dt.datetime)):
                    cs.append(f"<c {a}><v>{serial(v)}</v></c>")
                else:
                    t = escape(_BAD.sub("", str(v)))
                    cs.append(f'<c {a} t="inlineStr"><is><t xml:space="preserve">{t}</t></is></c>')
            out.append(f'<row r="{r}">' + "".join(cs) + "</row>")
        out.append("</sheetData>")
        if self.filter:
            out.append(f'<autoFilter ref="{self.filter}"/>')
        if self.merges:
            out.append(f'<mergeCells count="{len(self.merges)}">' + "".join(f'<mergeCell ref="{m}"/>' for m in self.merges) + "</mergeCells>")
        for i, rng in enumerate(self.scales):
            out.append(f'<conditionalFormatting sqref="{rng}"><cfRule type="colorScale" priority="{i + 1}"><colorScale>'
                       '<cfvo type="min"/><cfvo type="percentile" val="50"/><cfvo type="max"/>'
                       '<color rgb="FFF8696B"/><color rgb="FFFFEB84"/><color rgb="FF63BE7B"/></colorScale></cfRule></conditionalFormatting>')
        if self.lists:
            out.append(f'<dataValidations count="{len(self.lists)}">' + "".join(
                f'<dataValidation type="list" allowBlank="1" showDropDown="0" sqref="{c}"><formula1>{escape(f)}</formula1></dataValidation>'
                for c, f in self.lists) + "</dataValidations>")
        out.append("</worksheet>")
        return "".join(out)


class Book:
    def __init__(self):
        self.sheets: list[Sheet] = []
        self.names: list[tuple[str, str]] = []

    def add(self, name: str) -> Sheet:
        s = Sheet(name)
        self.sheets.append(s)
        return s

    def name(self, n: str, target: str):
        self.names.append((n, target))

    def save(self, path: str, title: str = "") -> None:
        n = len(self.sheets)
        ct = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
              '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
              '<Default Extension="xml" ContentType="application/xml"/>'
              '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
              '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
              '<Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>'
              '<Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>'
              + "".join(f'<Override PartName="/xl/worksheets/sheet{i + 1}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(n))
              + "</Types>")
        rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>'
                '<Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>'
                "</Relationships>")
        now = dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        core = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" '
                'xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:dcterms="http://purl.org/dc/terms/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">'
                f"<dc:title>{escape(title)}</dc:title><dc:creator>Analītiķis</dc:creator>"
                f'<dcterms:created xsi:type="dcterms:W3CDTF">{now}</dcterms:created></cp:coreProperties>')
        app = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">'
               "<Application>Analītiķis</Application></Properties>")
        wrels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 + "".join(f'<Relationship Id="rId{i + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i + 1}.xml"/>' for i in range(n))
                 + f'<Relationship Id="rId{n + 1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
                 "</Relationships>")
        dn = [f'<definedName name="{escape(k)}">{escape(v)}</definedName>' for k, v in self.names]
        for i, s in enumerate(self.sheets):
            if s.filter:
                a, b = s.filter.split(":")
                ab = lambda x: re.sub(r"([A-Z]+)(\d+)", r"$\1$\2", x)  # noqa: E731
                dn.append(f'<definedName name="_xlnm._FilterDatabase" localSheetId="{i}" hidden="1">{escape(s.q())}!{ab(a)}:{ab(b)}</definedName>')
        wb = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
              'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
              '<bookViews><workbookView activeTab="0"/></bookViews><sheets>'
              + "".join(f'<sheet name="{escape(s.name)}" sheetId="{i + 1}" r:id="rId{i + 1}"/>' for i, s in enumerate(self.sheets))
              + "</sheets>" + (f"<definedNames>{''.join(dn)}</definedNames>" if dn else "")
              + '<calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>')
        with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
            z.writestr("[Content_Types].xml", ct)
            z.writestr("_rels/.rels", rels)
            z.writestr("docProps/core.xml", core)
            z.writestr("docProps/app.xml", app)
            z.writestr("xl/workbook.xml", wb)
            z.writestr("xl/_rels/workbook.xml.rels", wrels)
            z.writestr("xl/styles.xml", _STYLES)
            for i, s in enumerate(self.sheets):
                z.writestr(f"xl/worksheets/sheet{i + 1}.xml", s.xml())
