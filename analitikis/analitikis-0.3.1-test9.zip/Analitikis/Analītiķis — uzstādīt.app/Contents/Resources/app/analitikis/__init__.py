"""Analītiķis — Fotostokera modulis: ienākumu savākšana no aģentūrām un pārskati."""

APP_NAME = "Analītiķis"
VERSION = "0.3.1-test9"
