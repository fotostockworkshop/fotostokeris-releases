/* Envato Elements: author.envato.com/reports */
async function collect() {
  if (location.hostname === "portfolio.envato.com") return { skipped: "portfolio" };   // portfeļa lapa (portNav) — bez uzdevuma nekas nav jādara
  if (location.hostname !== "author.envato.com") throw LOGIN;
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (!/^\/reports/.test(location.pathname) || !meta) {
    location.href = "https://author.envato.com/reports/earnings";
    return { navigated: true };
  }
  const H = { "Content-Type": "application/json", "X-CSRF-Token": meta.getAttribute("content") };
  const R = (u) => getj("/reports/api/v1/" + u, H);

  say("total", 5);
  const tot = await R("earnings/total");
  if (!tot || !tot.data) throw LOGIN;
  const first = (tot.data.first_record_date || "2022-07-01").slice(0, 10);

  say("monthly", 10);
  const mon = await R(`earnings/detail?view=monthly&start_date=${first}&end_date=${today}`);
  await send("monthly", { rows: mon.data || [] });
  /* gaidāmā izmaksa (test48): šī mēneša Elements ienākumi līdz šodienai (bruto, mainās katru dienu) */
  try {
    const cur = (mon.data || []).find((r) => String(r.date || "").slice(0, 7) === today.slice(0, 7));
    if (cur) await sendPayInfo({ unpaid: +cur.total_earnings_elements || 0, currency: "USD" });
  } catch (_) { /* */ }

  const dfirst = (mon.daily_first_record_date || first).slice(0, 10);
  const dstart = OPTS.mode === "full" ? dfirst : (OPTS.since > dfirst ? OPTS.since : dfirst);
  say("daily", 20);
  const day = await R(`earnings/detail?view=daily&start_date=${dstart}&end_date=${today}`);
  await send("daily", { start: dstart, end: today, rows: day.data || [] });

  /* vienumu ienākumi pa mēnešiem */
  const md = await R("performance/meta_data?shopfront=Elements");
  const ef = (md.earliest_record_date || dfirst).slice(0, 10), el = (md.latest_record_date || today).slice(0, 10);
  let months = monthsBack(+ef.slice(0, 4), +ef.slice(5, 7), +el.slice(0, 4), +el.slice(5, 7));
  /* lietotājs 2026-11-01: tikai mēneši kopš pēdējās atjaunošanas (OPTS.items_from), ne visi gadi */
  const recentM = (l) => l.filter(([y, m]) => `${y}-${String(m).padStart(2, "0")}` >= (OPTS.items_from || "9999"));
  if (OPTS.mode !== "full") { months = recentM(months); if (!months.length) months = [[+today.slice(0, 4), +today.slice(5, 7)]]; }
  for (let i = 0; i < months.length; i++) {
    const [y, m] = months[i];
    const ms = `${y}-${String(m).padStart(2, "0")}`;
    const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    const s = `${ms}-01` < ef ? ef : `${ms}-01`, e = last > el ? el : last;
    let page = 1, pages = 1;
    do {
      say(`${ms} · ${page}/${pages}`, 25 + Math.round((i / months.length) * 70));
      const q = new URLSearchParams({ shopfront: "Elements", start_date: s, end_date: e, sort_by: "total_earnings",
        sort_direction: "desc", new_item_only: "false", page: String(page) });
      const j = await R("performance/item_performance?" + q);
      pages = Math.max(1, j.total_pages || 1);
      const rows = j.data || [];
      const stop = !rows.length || rows.every((r) => !(+r.total_earnings));   // kārtots dilstoši — tālāk tikai nulles
      await send("items", { month: ms, page, rows, shopfront: "Elements", last: i === months.length - 1 && (page >= pages || stop) });
      if (stop) break;
      page++;
    } while (page <= pages && page < 200);
  }
  /* Envato Market (tie paši autora dati): vienumu ienākumi pa mēnešiem, ja portāls tos dod */
  try {
    const mm = await R("performance/meta_data?shopfront=Market");
    const mf = ((mm && mm.earliest_record_date) || "").slice(0, 10), ml = ((mm && mm.latest_record_date) || today).slice(0, 10);
    if (mf) {
      let mlist = monthsBack(+mf.slice(0, 4), +mf.slice(5, 7), +ml.slice(0, 4), +ml.slice(5, 7));
      if (OPTS.mode !== "full" && sales_state_market_done()) mlist = recentM(mlist);
      let n = 0;
      for (let i = 0; i < mlist.length; i++) {
        const [y, m] = mlist[i];
        const ms = `${y}-${String(m).padStart(2, "0")}`;
        const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
        const s = `${ms}-01` < mf ? mf : `${ms}-01`, e = last > ml ? ml : last;
        let page = 1, pages = 1;
        do {
          say(`Market ${ms} · ${page}/${pages}`, 95);
          const q = new URLSearchParams({ shopfront: "Market", start_date: s, end_date: e, sort_by: "total_earnings",
            sort_direction: "desc", new_item_only: "false", page: String(page) });
          const j = await R("performance/item_performance?" + q);
          pages = Math.max(1, j.total_pages || 1);
          const rows = j.data || [];
          const stop = !rows.length || rows.every((r) => !(+r.total_earnings));
          if (rows.length && !window.__vdMk) { window.__vdMk = 1; const r0 = rows[0];
            B.log(AG, "Envato Market rindas atslēgas: " + keysOf(r0) + " · " + ["item_name", "name", "title", "category", "url"].map((k) => k + "=" + String(r0[k] == null ? "" : r0[k]).slice(0, 40)).join(" | ")); }
          n += rows.length;
          await send("items", { month: ms, page, rows, shopfront: "Market", last: i === mlist.length - 1 && (page >= pages || stop) });
          if (stop) break;
          page++;
        } while (page <= pages && page < 200);
      }
      B.log(AG, `Envato Market: ${mlist.length} mēneši${mlist.length ? " (" + mlist[mlist.length - 1].join("-") + "…" + mlist[0].join("-") + ")" : ""}, ${n} vienumu rindas`);
    } else B.log(AG, "Envato Market: vienumu datu nav");
  } catch (e) { if (e && e.login) throw e; B.log(AG, "Envato Market vienumi: " + ((e && e.message) || e)); }
  /* 0.3.1-test3 (lietotājs 2026-11-01): Market atlikums — author.envato.com/profile → "Balances" → Market (pēc nodokļa;
     Elements kartīte lielāko laiku tukša — Elements prognoze paliek no atskaitēm). Minimums $50, atsevišķi no Elements. */
  try {
    say("Market atlikums", 96);
    const mb = await framed("/profile", (t) => {
      const i = t.search(/\bBalances\b/); if (i < 0) return null;
      const m = t.slice(i).match(/\bMarket\b\s*\$\s*([\d,]+(?:\.\d{1,2})?)/); return m ? m[1] : null; }, 20000);
    if (mb != null) { await send("market_info", { unpaid: money(mb), available: money(mb), min: 50, currency: "USD" }); B.log(AG, "Market atlikums (Balances): $" + mb); }
    else B.log(AG, "Market atlikums: Balances lapā nav atrasts");
  } catch (e) { if (e && e.login) throw e; B.log(AG, "Market atlikums: " + ((e && e.message) || e)); }
  /* izmaksu vēsture — author.envato.com/payout_method ("<summa> USD SENT Sent: Oct 15, 2026") */
  await payoutsSafe(async () => {
    /* 0.3.1-test6 (lietotājs 2026-11-03: žurnālā rāmī redzams tikai sīkdatņu paziņojums): aizveram paziņojumu,
       izvēlamies "All Payments", gaidām ilgāk; ja neizdodas — žurnālā teksts AIZ paziņojuma (izpētei) */
    let clicked = false, tries = 0, lastT = "", vaClicked = false, vaT = 0;
    let apis = [];
    const txt = await framed("/payout_method", (t, d) => {
      lastT = t;
      try { apis = [...new Set(d.defaultView.performance.getEntriesByType("resource").filter((e) => /fetch|xmlhttprequest/.test(e.initiatorType)).map((e) => { const u = new URL(e.name); return u.host + u.pathname; }))].slice(0, 15); } catch (_) { /* */ }
      const vaBtn = () => { try { return [...d.querySelectorAll("a, button")].find((b) => /view all payments/i.test(b.innerText || "")); } catch (_) { return null; } };
      if (/Sent:\s*[A-Z][a-z]+ \d/.test(t)) {
        const va = vaBtn();
        if (va && !vaClicked) { vaClicked = true; vaT = Date.now(); va.click(); return null; }   // visa vēsture
        if (!vaClicked || Date.now() - vaT > 6000) return t;
        return null;
      }
      /* 2026-11-05 (lietotāja ekrānuzņēmums): "Recent Payments" lapas apakšā — "228.64 USD SENT · Sent: Oct 15, 2026";
         ielādējas, kad saraksts redzams → ritinām uz leju; "View all payments" — visa vēsture */
      try { d.defaultView.scrollTo(0, d.body.scrollHeight); } catch (_) { /* */ }
      if (++tries % 3 === 0) {
        try {
          const bs = [...d.querySelectorAll("button, a, [role=button], [role=option], option, li")];
          const ck = bs.find((b) => /^(accept all|accept|allow all|i agree|got it)$/i.test((b.innerText || b.textContent || "").trim()));
          if (ck) ck.click();
          const sel = [...d.querySelectorAll("select")].find((x) => [...x.options].some((o) => /all payments/i.test(o.text)));
          if (sel && !/all payments/i.test(sel.options[sel.selectedIndex].text)) {
            sel.value = [...sel.options].find((o) => /all payments/i.test(o.text)).value;
            sel.dispatchEvent(new Event("change", { bubbles: true }));
          } else if (!clicked) {
            const ap = bs.find((b) => /^all payments$/i.test((b.innerText || b.textContent || "").trim()));
            if (ap) { ap.click(); clicked = true; }
          }
        } catch (_) { /* */ }
      }
      return null;
    }, 45000, null, true);
    if (!txt) {
      /* 2026-11-06 (žurnāls): saraksts rāmī neparādās — pierakstām, ko lapa ielādē (lai ņemtu tieši no API) */
      B.log(AG, "izmaksas: lapas API: " + (apis.join(" · ") || "nav"));
      const body = lastT.replace(/\s+/g, " ");
      const k = body.search(/accept all|reject all|cookie settings/i);
      B.log(AG, "izmaksas: payout_method lapā izmaksu nav; teksts aiz paziņojuma: " + (k >= 0 ? body.slice(k, k + 300) : body.slice(0, 300)) + " … beigas: " + body.slice(-250) + ` (garums ${body.length})`);
      return;
    }
    const rows = [], re = /([\d,]+\.\d{2})\s*USD\s*SENT\s*Sent:\s*([A-Z][a-z]+ \d{1,2}, \d{4})/g;
    let m; while ((m = re.exec(txt))) rows.push({ date: pdate(m[2]), amount: money(m[1]), currency: "USD" });
    await sendPayouts(rows);
  });
  const pn = await portfolioSafe([
    ["meta_data", async () => countKey(md, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["total", async () => { const n = countKey(tot && tot.data, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: total atslēgas: " + keysOf(tot && tot.data)); return n; }],
  ]);
  /* Portfolio Manager — portfolio.envato.com/items "Approved for Sale (N)" (lietotājs 2026-10-30); cits domēns → logs pāriet */
  /* 2026-11-05: Portfolio Manager atveram reizi dienā arī tad, ja skaits jau atrasts — tur ir iesniegumu statusu CSV */
  if (!pn || OPTS.port_due || OPTS.sub_due) { const r = await portNav("https://portfolio.envato.com/items", "Approved for Sale\\s*\\(\\s*(\\d[\\d,]*)\\s*\\)", "Portfolio Manager (Approved for Sale)"); if (r) return r; }
  return { months: months.length };
}
function sales_state_market_done() { return !!OPTS.market_done; }

/* Portfolio Manager lapā (portfolio.envato.com/items): bilžu sīktēli un nosaukumi — sīktēliem pārdošanu sarakstā
   (sasaiste pēc nosaukuma; item_performance sīktēlus dod ne visām bildēm). Lapo, ritinot uz leju. */
/* 2026-11-05 (lietotājs): Portfolio Manager → "Download CSV" — visas bildes ar statusu (In Review / Changes required /
   Approved for Sale / Unavailable), faila nosaukumu, virsrakstu, atslēgvārdiem. Lejupielādi pārtveram (blob vai saite),
   neko nesaglabājam diskā; rindas sūtām Analītiķim (iesniegumu statusi, noteikumi §7). */
function csvParse(t) {
  const out = []; let row = [], f = "", q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; continue; }
    if (ch === '"') q = true; else if (ch === ",") { row.push(f); f = ""; }
    else if (ch === "\n") { row.push(f); out.push(row); row = []; f = ""; } else if (ch !== "\r") f += ch;
  }
  if (f || row.length) { row.push(f); out.push(row); }
  return out;
}
async function envCsv() {
  const btn = [...document.querySelectorAll("button, a, [role=button]")].find((b) => /download csv/i.test((b.innerText || b.textContent || "").trim()));
  if (!btn) { B.log(AG, "statusi: poga \"Download CSV\" nav atrasta"); return; }
  let got = null;
  const oCreate = URL.createObjectURL, oClick = HTMLAnchorElement.prototype.click, oOpen = window.open;
  const t0 = performance.now();
  URL.createObjectURL = function (b) { if (b && b.text && !got) got = b.text(); return oCreate.apply(this, arguments); };
  HTMLAnchorElement.prototype.click = function () {
    const h = this.href || "";
    if (/\.csv|download|export/i.test(h + " " + (this.download || "")) && !got) {
      got = h.startsWith("blob:") ? fetch(h).then((r) => r.text()) : fetch(h, { credentials: "include" }).then((r) => r.text());
      return;                                                     // neļaujam pārlūkam saglabāt failu
    }
    return oClick.apply(this, arguments);
  };
  window.open = function (u) { if (!got && u) { got = fetch(u, { credentials: "include" }).then((r) => r.text()); return null; } return oOpen.apply(this, arguments); };
  try {
    btn.click();
    for (let i = 0; i < 90 && !got; i++) await sleep(500);
  } finally { URL.createObjectURL = oCreate; HTMLAnchorElement.prototype.click = oClick; window.open = oOpen; }
  if (!got) {
    const res = performance.getEntriesByType("resource").filter((e) => e.startTime >= t0).map((e) => e.name.replace(/\?.*$/, "")).slice(0, 12);
    B.log(AG, "statusi: CSV nepārtverts; pieprasījumi pēc klikšķa: " + (res.join(" | ") || "nav"));
    return;
  }
  const text = await got;
  const rows = csvParse(text || "");
  const head = (rows.shift() || []).map((x) => x.trim().toLowerCase());
  const ix = (k) => head.indexOf(k);
  if (ix("item_uuid") < 0 || ix("status") < 0) { B.log(AG, "statusi: CSV galva negaidīta: " + head.join(",").slice(0, 200)); return; }
  const items = rows.filter((r) => r.length >= head.length - 1).map((r) => ({ id: r[ix("item_uuid")], file: r[ix("file_name")] || "",
    title: r[ix("title")] || "", tags: r[ix("tags")] || "", status: r[ix("status")] || "", submitted: r[ix("submitted_at")] || "" }));
  const N = 500, parts = Math.ceil(items.length / N) || 1;
  for (let p = 0; p < parts; p++) await send("sub_items", { rows: items.slice(p * N, (p + 1) * N), part: p + 1, parts });
  B.log(AG, `statusi: Portfolio Manager CSV — ${items.length} bildes`);
}
async function portPageExtra() {
  try { await envCsv(); } catch (e) { B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); }
  const seen = new Map();
  const idOf = (el) => {
    const a = el && el.closest && el.closest("a");
    const h = (a && a.href) || "";
    const m = h.match(/(?:items?|item_id=|\/)(\d{5,})(?:[/?#]|$)/) || String((el && el.closest && (el.closest("[data-item-id],[data-id]") || {}).dataset && JSON.stringify(el.closest("[data-item-id],[data-id]").dataset)) || "").match(/(\d{5,})/);
    return m ? m[1] : "";
  };
  const grab = () => {
    /* fona attēli (div style="background-image") — daži saraksti sīktēlus rāda tā */
    for (const el of document.querySelectorAll("[style*='background-image']")) {
      const m = (el.getAttribute("style") || "").match(/url\(["']?(https?:[^"')]+)/);
      if (!m) continue;
      const card = el.closest("a, li, article, [class*=card], [class*=item]") || el.parentElement;
      const title = ((card && card.innerText) || "").split("\n").map((x) => x.trim()).filter((x) => x.length > 6 && !/^approved|^in review|^photo|^image$/i.test(x))[0] || "";
      const key = title || idOf(el);
      if (key && !seen.has(key)) seen.set(key, { title: title.replace(/[…\.]+$/, "").trim(), thumb: m[1], href: (el.closest("a") || {}).href || "", id: idOf(el) });
    }
    for (const img of document.images) {
      const src = img.currentSrc || img.src || "";
      if (!/^https?:/.test(src) || (img.naturalWidth && img.naturalWidth < 60)) continue;
      const card = img.closest("a, li, article, [class*=card], [class*=item]") || img.parentElement;
      let title = (img.alt || "").trim();
      if (!title || title.length < 4) title = ((card && card.innerText) || "").split("\n").map((x) => x.trim()).filter((x) => x.length > 6 && !/^approved|^in review|^photo|^image$/i.test(x))[0] || "";
      const id = idOf(img);
      if (!title && !id) continue;
      const a = img.closest("a");
      const key = title || id;
      if (!seen.has(key)) seen.set(key, { title: title.replace(/[…\.]+$/, "").trim(), thumb: src, href: a ? a.href : "", id });
    }
  };
  for (let i = 0; i < 25; i++) {
    grab();
    const before = document.documentElement.scrollHeight;
    window.scrollTo(0, before);
    await sleep(1200);
    if (document.documentElement.scrollHeight <= before && i > 2) { grab(); break; }
  }
  const rows = [...seen.values()];
  if (rows[0]) B.log(AG, `Portfolio Manager: ${rows.length} bildes ar sīktēliem (ar ID: ${rows.filter((r) => r.id).length}); saites paraugs: ${String(rows[0].href).replace(/\d{6,}/g, "N").slice(0, 80)}`);
  else {
    /* test52: izpētei — kāpēc nekas netika atrasts (31.10 žurnālā nebija ne rindas) */
    const imgs = [...document.images];
    const shape = (u) => { try { const x = new URL(u); return x.host + x.pathname.replace(/\d{3,}/g, "N").slice(0, 50); } catch (_) { return String(u).slice(0, 40); } };
    B.log(AG, `Portfolio Manager: sīktēli nav atrasti; lapa ${location.host}${location.pathname}; img ${imgs.length} (http ${imgs.filter((i) => /^https?:/.test(i.currentSrc || i.src)).length}); ` +
      `paraugi: ${imgs.slice(0, 4).map((i) => `${shape(i.currentSrc || i.src)} ${i.naturalWidth}px alt="${(i.alt || "").slice(0, 25)}"`).join(" | ")}; ` +
      `fona: ${document.querySelectorAll("[style*='background-image']").length}; iframe: ${document.querySelectorAll("iframe").length}; teksts: ${(document.body.innerText || "").slice(0, 160).replace(/\s+/g, " ")}`);
  }
  if (rows.length) await send("thumbs_title", { rows });
}
