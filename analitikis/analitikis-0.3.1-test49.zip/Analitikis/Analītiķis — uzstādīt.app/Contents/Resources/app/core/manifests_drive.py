"""Manifesti Google Drive `Fotostokeris/Manifesti/` caur programmas Google kontu (noteikumi: docs/fotostokeris-dati.md
§7a (c) un "Manifesti Drive — kopīgi rakstīšanas noteikumi"; lēmumi 2026-11-09 20:40, 21:25).

Kopīgs visiem moduļiem (moduļi viens otru neimportē — tikai šis kods un faili):
- Rakstītāji: Vārdotājs (sērijas, writer="vardotajs") un Tirgotājs (atzīmes "pārvietota" / "deleted" sērijās un savi komplekti,
  writer="tirgotajs"). `queue(...)` — fails uzreiz nokopēts rindā datu mapē `drive_queue/` (uz Mac Synology vietējos
  failus var drīz dzēst), augšupielāde fonā pēc aiztures; Google nav pieejams → mēģina vēlāk (arī pēc restarta).
- Pārraksta to pašu failu pēc ID (Drive neaug); failu atrod pēc `__<ID8>` visās `Manifesti` mapēs; ja nosaukums
  mainījies — pārdēvē. Jaunus liek vecākajā `Manifesti` mapē.
- Pirms pārrakstīšanas nolasa Drive versiju un apvieno (`merge`): katrs rakstītājs maina tikai savus laukus; bildes, kas
  Drive ir, bet lokāli vairs nav, paliek (arī to sīktēli zip failā).
- writer="backfill" — vienreizēja jau esošo manifestu augšupielāde (Vārdotājs test12): tikai tos, kuru Drive vēl nav.
- Lasītāji (Analītiķis, Tirgotājs): `pull(dest)` — lejupielādē jaunākos (pēc modifiedTime) mapē `dest`.
"""
from __future__ import annotations

import io
import json
import os
import shutil
import threading
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import config, google

DIR = "Manifesti"
TEXT_FIELDS = ("file", "path", "status", "category", "title", "description", "keywords", "hint", "taken_at", "phash",
               "width", "height", "sig", "bytes", "md5", "orig_file", "updated")
LIVE_DELAY = 60.0          # "dzīvais" manifests — augšupielāde ~1 min pēc pēdējās izmaiņas
NOW_DELAY = 3.0            # poga "Manifests", "Uz iesniegšanu"
RETRY = 300.0              # kļūda / nav savienojuma — pēc 5 min

_lock = threading.RLock()
_timer: threading.Timer | None = None
_status = {"last": "", "error": "", "pending": 0}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def qdir() -> Path:
    d = config.app_dir() / "drive_queue"
    d.mkdir(parents=True, exist_ok=True)
    return d


def enabled() -> bool:
    try:
        return google.connected()
    except Exception:
        return False


# --------------------------------------------------------------------------- apvienošana

def _kind(d: dict) -> str:
    return d.get("kind") or "series"


def merge(remote: dict | None, local: dict, writer: str = "vardotajs") -> dict:
    """Apvieno Drive versiju ar vietējo (dati §7a (c) 1. punkts). Atgriež jaunu dict."""
    if not remote or remote.get("series_id") != local.get("series_id"):
        out = dict(local)
    elif writer == "tirgotajs":
        # Tirgotājs: ņem Drive versiju, maina tikai "pārvietota"
        out = dict(remote)
        mine = {it.get("stem"): it for it in local.get("images") or [] if it.get("status") == "moved"}
        # atcelts komplekts — bilde atgriezta NAS sērijā (Tirgotājs 2026-11-11: "Atcelt komplektu" → atpakaļ uz NAS)
        back = {it.get("stem"): it for it in local.get("images") or [] if it.get("returned") and it.get("status") != "moved"}
        # izdzēsta no NAS (Tirgotājs 2026-11-11 15:20: `_Izdzestas/`, dati §7a (c) 1)
        gone = {it.get("stem"): it for it in local.get("images") or [] if it.get("status") == "deleted"}
        imgs = []
        for it in remote.get("images") or []:
            m = mine.pop(it.get("stem"), None)
            b = back.pop(it.get("stem"), None)
            g = gone.pop(it.get("stem"), None)
            if g:
                it = {k: v for k, v in it.items() if k != "moved_to"}
                it.update(status="deleted", deleted_at=g.get("deleted_at") or _now(), updated=g.get("updated") or _now())
            elif m:
                it = dict(it, status="moved", moved_to=m.get("moved_to"), updated=m.get("updated") or _now())
            elif b:
                it = {k: v for k, v in it.items() if k != "moved_to"}
                it.update(status=b.get("status") or "ready", path=b.get("path") or it.get("path"), returned=b.get("returned"),
                          updated=b.get("updated") or _now())
            imgs.append(it)
        imgs += list(back.values())
        imgs += list(mine.values())
        imgs += list(gone.values())
        out["images"] = imgs
    else:
        # Vārdotājs: savi lauki no vietējās; Tirgotāja "pārvietota" un lokāli trūkstošās bildes — no Drive
        out = dict(local)
        rem = {it.get("stem"): it for it in remote.get("images") or [] if it.get("stem")}
        # pārdēvētas bildes ("Uz iesniegšanu": <kods>_<oriģinālais>) — vecais ieraksts ar oriģinālo nosaukumu vairs nav jāpatur
        for it in local.get("images") or []:
            o = os.path.splitext(it.get("orig_file") or "")[0]
            if o and o != it.get("stem"):
                rem.pop(o, None)
        imgs = []
        for it in local.get("images") or []:
            r = rem.pop(it.get("stem"), None)
            if r and r.get("status") == "moved" and it.get("status") != "moved" and not it.get("returned"):
                it = dict(it, status="moved", moved_to=r.get("moved_to"))
            elif r and r.get("status") == "deleted" and it.get("status") != "deleted":
                it = dict(it, status="deleted", deleted_at=r.get("deleted_at"))   # Tirgotājs izdzēsis no NAS — paliek
            imgs.append(it)
        imgs += list(rem.values())
        out["images"] = imgs
        for k in ("created", "series_code"):
            if not out.get(k) and remote.get(k):
                out[k] = remote[k]
    out["kind"] = _kind(local)
    if _kind(out) == "series":
        out["count"] = sum(1 for it in out.get("images") or [] if it.get("status") not in ("moved", "deleted"))
        out["ready"] = sum(1 for it in out.get("images") or [] if it.get("status") == "ready")
    return out


# --------------------------------------------------------------------------- Drive

def _folders() -> list[dict]:
    fs = google.root_folders(DIR)
    if not fs:
        google.folder(DIR)
        fs = google.root_folders(DIR)
    return fs


def _remote_files(folders: list[dict]) -> list[dict]:
    out = []
    for f in folders:
        for x in google.list_files(f["id"]):
            x["parent"] = f["id"]
            out.append(x)
    return out


def _pick(files: list[dict], id8: str, suffix: str) -> dict | None:
    """Jaunākais fails ar `__<id8><suffix>` nosaukuma beigās."""
    c = [f for f in files if f["name"].endswith(f"__{id8}{suffix}")]
    return max(c, key=lambda f: f.get("modifiedTime") or "") if c else None


def _push(base: str, jpath: Path, zpath: Path | None, writer: str) -> bool:
    local = json.loads(jpath.read_text(encoding="utf-8"))
    id8 = str(local.get("series_id") or "")[:8]
    if not id8:
        return False
    folders = _folders()
    files = _remote_files(folders)
    rj, rz = _pick(files, id8, ".json"), _pick(files, id8, "-sikteli.zip")
    if writer == "backfill" and rj:
        return False    # vienreizējā augšupielāde: Drive jau ir (tur var būt jaunāka versija) — neaiztiek
    remote = None
    if rj:
        try:
            remote = json.loads(google.download(rj["id"]).decode("utf-8"))
        except (ValueError, google.GoogleError) as e:
            print("Drive manifests: nevar nolasīt", rj["name"], e)
    data = merge(remote, local, "vardotajs" if writer == "backfill" else writer)
    stems = {it.get("stem") for it in data.get("images") or [] if it.get("status") != "deleted"}
    # sīktēli: lokālajā zip trūkstošos (bildes, kuru datorā vairs nav) ņem no Drive zip
    zbytes = None
    if zpath and zpath.is_file():
        try:
            with zipfile.ZipFile(zpath) as z:
                have = {n: z.read(n) for n in z.namelist()}
        except (OSError, zipfile.BadZipFile):
            have = {}
        need = {s + ".jpg" for s in stems if s} - set(have)
        if need and rz:
            try:
                with zipfile.ZipFile(io.BytesIO(google.download(rz["id"]))) as z:
                    for n in z.namelist():
                        if n in need:
                            have[n] = z.read(n)
            except (zipfile.BadZipFile, google.GoogleError) as e:
                print("Drive manifests: sīktēli", e)
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_STORED) as z:
            for n, b in have.items():
                if n[:-4] in stems:
                    z.writestr(n, b)
        zbytes = buf.getvalue()
    target = folders[0]["id"]
    jname, zname = base + ".json", base + "-sikteli.zip"
    google.put_bytes(target, jname, json.dumps(data, ensure_ascii=False, indent=1).encode("utf-8"),
                     rj["id"] if rj else None)
    if rj and rj["name"] != jname:
        google.rename(rj["id"], jname)
    if zbytes is not None:
        tmp = qdir() / (base + ".upload.zip")
        tmp.write_bytes(zbytes)
        try:
            google.upload(tmp, target, zname, file_id=rz["id"] if rz else None)
        finally:
            tmp.unlink(missing_ok=True)
    return True


# --------------------------------------------------------------------------- rinda

def queue(base: str, jpath: str, zpath: str | None = None, writer: str = "vardotajs", now: bool = False) -> None:
    """Ieliek manifestu (un sīktēlus) rindā augšupielādei. base = `<sērija>__<ID8>` (kā kopīgajā manifestu mapē).
    Bez Google konta — nekas nenotiek."""
    if not enabled():
        return
    q = qdir()
    with _lock:
        for n in os.listdir(q):                      # tā pati sērija ar citu nosaukumu (pārdēvēta) — vecā rinda prom
            if n.endswith(".meta") and n.split("__")[-1][:8] == base.split("__")[-1][:8] and not n.startswith(base + "."):
                for ext in (".meta", ".json", ".zip"):
                    (q / (n[:-5] + ext)).unlink(missing_ok=True)
        shutil.copyfile(jpath, q / (base + ".json.tmp"))
        os.replace(q / (base + ".json.tmp"), q / (base + ".json"))
        if zpath and os.path.isfile(zpath):
            shutil.copyfile(zpath, q / (base + ".zip.tmp"))
            os.replace(q / (base + ".zip.tmp"), q / (base + ".zip"))
        (q / (base + ".meta")).write_text(json.dumps({"writer": writer, "at": _now()}), encoding="utf-8")
    kick(NOW_DELAY if now else LIVE_DELAY)


def kick(delay: float = NOW_DELAY) -> None:
    global _timer
    with _lock:
        if _timer:
            _timer.cancel()
        _timer = threading.Timer(delay, _run)
        _timer.daemon = True
        _timer.start()


def _run() -> None:
    q = qdir()
    with _lock:
        todo = sorted(n[:-5] for n in os.listdir(q) if n.endswith(".meta"))
    left = 0
    for base in todo:
        if not enabled():
            left += 1
            continue
        try:
            with _lock:
                meta = json.loads((q / (base + ".meta")).read_text(encoding="utf-8"))
                stamp = meta.get("at")
                work = q / (base + ".sending.json")
                shutil.copyfile(q / (base + ".json"), work)
                zsrc = q / (base + ".zip")
                zwork = q / (base + ".sending.zip") if zsrc.is_file() else None
                if zwork:
                    shutil.copyfile(zsrc, zwork)
            try:
                sent = _push(base, work, zwork, meta.get("writer") or "vardotajs")
            finally:
                work.unlink(missing_ok=True)
                if zwork:
                    zwork.unlink(missing_ok=True)
            with _lock:                               # ja kamēr sūtīja, nāca jaunāka versija — paliek rindā
                cur = json.loads((q / (base + ".meta")).read_text(encoding="utf-8"))
                if cur.get("at") == stamp:
                    for ext in (".meta", ".json", ".zip"):
                        (q / (base + ext)).unlink(missing_ok=True)
                else:
                    left += 1
            _status.update(last=_now(), error="")
            print("Drive manifests:", "augšupielādēts" if sent else "jau ir Drive", base)
        except Exception as e:
            left += 1
            _status["error"] = str(e)
            print("Drive manifests:", base, e)
    _status["pending"] = left
    if left:
        kick(RETRY)


def start() -> None:
    """Moduļa startā: ja rindā kas palicis no iepriekšējās reizes — mēģina pēc ~30 s."""
    try:
        if any(n.endswith(".meta") for n in os.listdir(qdir())):
            kick(30.0)
    except OSError:
        pass


def status() -> dict:
    try:
        _status["pending"] = sum(1 for n in os.listdir(qdir()) if n.endswith(".meta"))
    except OSError:
        pass
    return dict(_status)


# --------------------------------------------------------------------------- lasītājiem

def pull(dest: str | Path) -> dict:
    """Lejupielādē jaunākos manifestus un sīktēlus no visām `Manifesti` mapēm uz `dest` (piem. `Manifesti-drive/`).
    Atgriež {"new": n, "total": n}. Vienas sērijas vairākas kopijas — ņem jaunāko."""
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    stp = dest / "_drive.json"
    try:
        state = json.loads(stp.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        state = {}
    fs = google.root_folders(DIR)
    best: dict[str, dict] = {}
    for f in _remote_files(fs):
        n = f["name"]
        if not (n.endswith(".json") or n.endswith("-sikteli.zip")) or "__" not in n:
            continue
        key = n.rsplit("__", 1)[1]                    # <ID8>.json / <ID8>-sikteli.zip
        if key not in best or (f.get("modifiedTime") or "") > (best[key].get("modifiedTime") or ""):
            best[key] = f
    new = 0
    for key, f in best.items():
        if state.get(key, {}).get("m") == f.get("modifiedTime") and (dest / f["name"]).is_file():
            continue
        old = state.get(key, {}).get("name")
        tmp = dest / (f["name"] + ".tmp")
        tmp.write_bytes(google.download(f["id"]))
        os.replace(tmp, dest / f["name"])
        if old and old != f["name"]:
            (dest / old).unlink(missing_ok=True)
        state[key] = {"m": f.get("modifiedTime"), "name": f["name"]}
        new += 1
    stp.write_text(json.dumps(state, ensure_ascii=False), encoding="utf-8")
    return {"new": new, "total": len(best)}
