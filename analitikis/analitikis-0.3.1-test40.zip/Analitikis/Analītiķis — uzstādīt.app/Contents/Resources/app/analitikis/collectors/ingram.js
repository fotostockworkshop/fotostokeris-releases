/* Ingram (ingramportal.com, GBP): Reports → Royalties — mēneša summas pa gadiem (bez bildēm).
   Lapas uzbūve vēl nav redzēta (Claude pārlūkā portāls neatveras) — savācējs meklē pēc tekstiem un raksta
   žurnālā, ko atrada. */
async function collect() {
  if (!/(^|\.)ingramportal\.com$/.test(location.hostname)) throw LOGIN;
  /* "cilvēka" pārbaude (traffic-verifier u.c.) vai lapa vēl ielādējas — nav kļūda: gaidām (logs paliek lietotājam) */
  /* Pārbaudi meklējam tikai tad, ja nav portāla izvēlnes (Royalties saites): lapās var būt paslēpti
     traffic-verifier skripti vai "protected by reCAPTCHA" uzraksts — tie nenozīmē, ka pārbaude notiek. */
  const hasMenu = [...document.querySelectorAll("a[href]")].some((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")))
    || /royalt/i.test(location.pathname);
  if (!hasMenu) {
    const why = !document.querySelector("a[href]") ? "lapā vēl nav saišu"
      : /verif|human|robot|checking your browser/i.test(document.title) ? "pārbaude (virsraksts)" : "";
    if (why) { B.log(AG, `${why} — gaidu (${location.pathname})`); throw LOGIN; }
  }
  const MONS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  /* Royalties lapa: saite ar tekstu "Royalties" (vai jau esam tajā) */
  let doc = document, url = location.href;
  if (!/royalt/i.test(location.pathname + " " + txt(document.querySelector("h1, h2")))) {
    const a = [...document.querySelectorAll("a[href]")].find((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")));
    if (!a) {
      B.log(AG, "Royalties saite nav atrasta; saites: " + [...document.querySelectorAll("a[href]")].slice(0, 25)
        .map((x) => txt(x).slice(0, 20) + "→" + new URL(x.getAttribute("href"), location.href).pathname).join(" · "));
      throw LOGIN;                          // vēl nav ielogots / izvēlne nav ielādēta — gaidām, logu neaizveram
    }
    url = new URL(a.getAttribute("href"), location.href).href;
    doc = await getdoc(url);
  }
  if (doc.querySelector('input[type="password"]') && !/royalt/i.test(txt(doc.body).slice(0, 4000))) {
    B.log(AG, "Royalties lapas vietā ielogošanās forma — gaidu"); throw LOGIN;
  }
  const body = txt(doc.body);
  const since = body.match(/since last pay-?out:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
  if (since) await send("balance", { amount: money(since[1]), currency: "GBP" });
  /* izmaksas: jāpieprasa ("Request payment", vismaz £40); pieprasāms = TOTAL ROYALTIES; vēstures ar summām nav */
  await payoutsSafe(async () => {
    const tot = body.match(/TOTAL ROYALTIES:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
    const mn = body.match(/at least\s*£?\s*(\d+(?:\.\d+)?)\s*GBP/i);
    const v = tot ? money(tot[1]) : since ? money(since[1]) : null;
    if (v != null) await sendPayInfo({ unpaid: v, available: v, min: mn ? +mn[1] : null, currency: "GBP" });
  });
  /* gadu cilnes: saites/pogas ar gadu tekstu → katra gada lapa vai paslēpts bloks */
  const years = [...new Set([...doc.querySelectorAll("a, button, li")].map((x) => txt(x)).filter((t) => /^20\d\d$/.test(t)))].sort();
  B.log(AG, `Royalties: ${new URL(url).pathname}; gadi: ${years.join(",") || "–"}; tabulas: ${doc.querySelectorAll("table").length}`);
  const rows = [];
  function grab(d, yearHint) {
    for (const t of d.querySelectorAll("table")) {
      const head = txt(t.querySelector("tr"));
      if (!/month/i.test(head) || !/royalt/i.test(head)) continue;
      let y = yearHint;
      const box = t.closest("[id], section, div");
      const ym = String(box ? box.id + " " + txt(box.querySelector("h2,h3,h4,.tab-title")) : "").match(/20\d\d/);
      if (ym) y = +ym[0];
      for (const tr of [...t.querySelectorAll("tr")].slice(1)) {
        const c = [...tr.cells].map(txt);
        if (c.length < 2) continue;
        const mm = c[0].match(/([A-Za-z]{3})[a-z]*\s*(20\d\d)?/);
        if (!mm || !MONS[mm[1].toLowerCase()]) continue;
        const yy = mm[2] ? +mm[2] : y;
        if (!yy) continue;
        rows.push({ month: `${yy}-${String(MONS[mm[1].toLowerCase()]).padStart(2, "0")}`, cat: "royalties", e: money(c[c.length - 1]), n: 0 });
      }
    }
  }
  grab(doc, years.length ? +years[years.length - 1] : 0);
  /* ja gadu tabulas nav visas vienā lapā — mēģinām gadu saites */
  /* gada cilne: īsta saite → tā; citādi (JavaScript cilne) mēģinām adresi ar gada parametru */
  const tried = [];
  /* ikdienas atjaunošana: tikai šis gads (janvārī–februārī arī iepriekšējais) — vecie gadi nemainās */
  const tyI = +today.slice(0, 4), tmI = +today.slice(5, 7);
  const needY = OPTS.mode === "full" ? years : years.filter((y) => +y === tyI || (tmI <= 2 && +y === tyI - 1));
  for (const y of needY) {
    if (rows.some((r) => r.month.startsWith(y + "-"))) continue;
    const a = [...doc.querySelectorAll("a[href]")].find((x) => txt(x) === y && !/^#|javascript:/i.test(x.getAttribute("href")));
    const base = new URL(url);
    const cands = a ? [new URL(a.getAttribute("href"), location.href).href] : [];
    for (const k of ["year", "y", "Year"]) { const u = new URL(base); u.searchParams.set(k, y); cands.push(u.href); }
    for (const c of cands) {
      const before = rows.length;
      try { grab(await getdoc(c), +y); } catch (e) { if (e && e.login) throw e; }
      await sleep(300);
      if (rows.slice(before).some((r) => r.month.startsWith(y + "-"))) { tried.push(`${y}:${new URL(c).search || new URL(c).pathname}`); break; }
    }
  }
  if (tried.length) B.log(AG, "gadi no adresēm: " + tried.join(" "));
  const uniq = {};
  for (const r of rows) uniq[r.month] = r;
  const list = Object.values(uniq).sort((a, b) => (a.month < b.month ? -1 : 1));
  B.log(AG, `mēneši: ${list.length}`);
  if (!list.length) throw new Error("Ingram: Royalties tabula nav atrasta");
  /* ikdienas atjaunošanā aizstājam tikai nolasītos gadus (vecos mēnešus nedzēšam) */
  await send("months", { start: OPTS.mode === "full" ? list[0].month + "-01" : list[0].month + "-01", end: today, currency: "GBP", rows: list });
  if (OPTS.sub_due) { try { await igStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["contributor area", () => portPage("/index.cfm?/carea_EN", [/Images online:?\s*(\d[\d,]*)/i, ...PORT_RE])],
    ["sākumlapa", () => portPage("/", [/Images online:?\s*(\d[\d,]*)/i, ...PORT_RE])],
  ]);
  return { months: list.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /index.cfm?id=273&careaAct=portfolio&phase=new (awaiting approval),
   phase=approved (online, 28 lapā, lapas "Next Page"), phase=rejected; sīktēlu uzklikšķinot — logs "<faila nosaukums> - Enter
   metadata" (Ingram pārdēvē failu, piem. IST_24335_11778.jpg; oriģināls varbūt "Show file information"). Lasām sīktēlus;
   žurnālā pirmā sīktēla HTML atribūti, lai precizētu. Gaidošajām nosaukumu ņemam, uzklikšķinot (≤30). */
async function igStatus() {
  /* 2026-11-06 (žurnāls): bildes lapā ielādējas ar ajax — lasām rāmī; adreses kā izvēlnē: index.cfm?/carea_portfolio_EN&phase=… */
  const base = "/index.cfm?/carea_portfolio_EN&phase=";
  const L = [["new", "Awaiting approval"], ["rejected", "Rejected"], ["approved", "Online"]];
  const all = new Map();
  let probed = false;
  for (const [ph, raw] of L) {
    const r = await framed(base + ph, (t, d) => (/No images found/i.test(t) || (/Images? found/i.test(t) && [...d.querySelectorAll("img")].some((i) => i.naturalWidth > 60)) ? true : null), 30000, async ({ doc }) => {
      await sleep(800);
      const t = doc.body.innerText || "";
      const cnt = (t.match(/(\d[\d,]*)\s+Images? found/i) || [])[1] || "0";
      const imgs = [...doc.querySelectorAll("img")].filter((i) => i.naturalWidth > 60 && !/logo|ajax-loader/i.test(i.src));
      if (!probed && imgs[0]) { probed = true; B.log(AG, "statusi: sīktēla HTML: " + (imgs[0].closest("a, div, li") || imgs[0]).outerHTML.replace(/\s+/g, " ").slice(0, 400)); }
      let n = 0;
      for (const im of imgs) {
        const h = (im.closest("a, div, li, td") || im).outerHTML;
        const id = (h.match(/(?:image_?id|imageid|img_?id|data-id|mediaid|[?&]id)=["']?(\d{4,12})/i) || im.src.match(/(\d{5,12})(?=[^\d]*$)/) || [])[1];
        if (!id || all.has(id)) continue;
        all.set(id, { id, file: "", title: (im.alt || im.title || "").slice(0, 250), submitted: "", status: raw }); n++;
      }
      return { n, cnt };
    });
    B.log(AG, `statusi: ${raw} — ${r ? r.n : "lapa neielādējās"} bildes (lapā kopā ${r ? r.cnt : "?"})`);
  }
  /* oriģinālais faila nosaukums: uzklikšķinot sīktēlu → "Show file information" → "Original : d738_….jpg", "Submitted: 05 Nov 2026"
     (lietotājs 2026-11-06). Tikai gaidošajām un noraidītajām (≤30). */
  let got = 0;
  /* test39: laika limits (lietotājs 2026-11-10: Ingram "pārtraukts: stalled" — 2×30 bildes × līdz 4,5 s bez ziņām > 5 min).
     Tikai bildes, kurām faila nosaukums vēl nav zināms (iepriekšējās reizēs nolasītie — no datubāzes), ≤90 s kopā, ziņa ik 5 bildes. */
  const t0 = Date.now(), known = new Set((OPTS.sub_known || []).map(String));
  for (const [ph, raw] of [["new", "Awaiting approval"], ["rejected", "Rejected"]]) {
    if (![...all.values()].some((r) => r.status === raw && !known.has(String(r.id)))) continue;
    if (Date.now() - t0 > 90000) break;
    await framed(base + ph, (t, d) => (/Images? found/i.test(t) && [...d.querySelectorAll("img")].some((i) => i.naturalWidth > 60) ? true : null), 30000, async ({ doc }) => {
      const imgs = [...doc.querySelectorAll("img")].filter((i) => i.naturalWidth > 60 && !/logo|ajax-loader/i.test(i.src) && !i.closest("header, nav, footer")).slice(0, 30);
      let n = 0;
      for (const im of imgs) {
        if (Date.now() - t0 > 90000) break;
        const iid = ((im.closest("[ximgid]") || {}).getAttribute || (() => null)).call(im.closest("[ximgid]") || im, "ximgid");
        if (iid && known.has(String(iid))) continue;
        if (++n % 5 === 0) say(`${raw}: ${n}/${imgs.length}`, 95);
        (im.closest("a, [onclick], div") || im).click();
        let t = "";
        for (let k = 0; k < 15; k++) {
          await sleep(300);
          const sh = [...doc.querySelectorAll("a, span, div, button")].find((e) => /^\s*Show file information\s*$/i.test(e.innerText || ""));
          if (sh) sh.click();
          t = doc.body.innerText || "";
          if (/Original\s*:/i.test(t)) break;
        }
        const orig = ((t.match(/Original\s*:\s*([^\n]+(?:\n[^\n:]+\.(?:jpe?g|tiff?|png))?)/i) || [])[1] || "").replace(/\s+/g, "");
        const ist = (t.match(/(IST_\d+_(\d+))\.jpe?g/i) || []);
        const sub = (t.match(/Submitted:\s*(\d{1,2} [A-Za-z]{3} \d{4})/i) || [])[1];
        const ttl = (t.match(/Caption \(English\):\s*\n?\s*([^\n]{3,250})/i) || [])[1] || "";
        let r = (ist[2] && all.get(ist[2])) || [...all.values()].find((x) => x.status === raw && !x.file && x.title && ttl && ttl.startsWith(x.title.slice(0, 30)));
        if (!r && ist[2]) { r = { id: ist[2], file: "", title: ttl, submitted: "", status: raw }; all.set(ist[2], r); }
        if (r && /\.(jpe?g|tiff?|png)$/i.test(orig)) { r.file = orig; if (sub) r.submitted = pdate(sub) || r.submitted; got++; }
        const x = [...doc.querySelectorAll("button, a")].find((e) => /^\s*Cancel\s*$/i.test(e.innerText || ""));
        if (x) x.click();
        await sleep(300);
      }
      return true;
    }).catch(() => null);
  }
  B.log(AG, `statusi: oriģinālie faila nosaukumi — ${got}`);
  const rows = [...all.values()];
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
