"""Portfeļa lielums pa aģentūrām un mēnešiem (Analītiķis 0.3.0-test42; noteikumi §8 tabula `portfolio`).

- Vienā mēnesī viena vērtība: mēneša pēdējā zināmā (aģentūras nolasītā vai importētā).
- Aģentūras pašas nolasītā vērtība (`source='agency'`) ir noteicošā — imports to nepārraksta.
- Vēsturi lietotājs ielasa vienreiz no CSV (agency,month,files) — Iestatījumi → "Portfeļa vēsture". Ielasa tikai
  aģentūras, kas ir Analītiķī (ne arhīva); vēsturiskie nosaukumi (Fotolia → Adobe u.c.) tiek pārvērsti.
- Savācēji portfeli nolasa reizi dienā (common.js portfolioSafe → send("portfolio", {files})).
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import re

from . import config, db

SCHEMA = """
CREATE TABLE IF NOT EXISTS portfolio(agency TEXT, month TEXT, files INTEGER, source TEXT, updated TEXT,
  PRIMARY KEY(agency, month));
"""

# vēsturiskie / citi nosaukumi → §4 identifikators (Fotolia = Adobe Stock pirms 2019 rebrendinga)
ALIASES = {"fotolia": "adobe", "adobestock": "adobe", "adobe stock": "adobe", "freepik": "magnific",
           "bigstockphoto": "bigstock", "shuterstock": "shutterstock", "gettyimages": "istock", "getty": "istock",
           "istock (gettyimages)": "istock", "envato elements": "envato", "photodune": "envato_market"}
MAX_FILES = 10_000_000


def ensure(c=None) -> None:
    (c or db.conn()).executescript(SCHEMA)


def _now() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def _valid_agencies() -> set[str]:
    return {a for a, v in db.AGENCIES.items() if not v.get("archive")}


# --------------------------------------------------------------------------- aģentūras nolasītā vērtība

def ingest(agency: str, d: dict) -> None:
    """Savācēja vērtība šodienas mēnesim (noteicošā)."""
    if d.get("public_url") and not d.get("files"):           # 123RF: publiskā profila adrese (lasa Python, test52)
        db.set_state(agency, "public_url", str(d["public_url"])[:300])
        return
    try:
        n = int(float(d.get("files")))
    except (TypeError, ValueError):
        return
    if n <= 0 or n > MAX_FILES:
        return
    month = (d.get("month") or dt.date.today().isoformat())[:7]
    # drošībai: lapā atrasts nepareizs skaitlis (piem. gads) — ja ļoti atšķiras no iepriekš zināmā, neņemam
    prev = db.q1("SELECT files FROM portfolio WHERE agency=? AND month<=? ORDER BY month DESC LIMIT 1", (agency, month))
    if prev and prev["files"] and not 0.5 * prev["files"] <= n <= 2 * prev["files"]:
        print(f"[{agency}] portfelis: {n} ({d.get('src') or '?'}) — ļoti atšķiras no iepriekšējā {prev['files']}, neņemu")
        db.set_state(agency, "port_day", dt.date.today().isoformat())
        return
    with db._lock:
        c = db.conn()
        c.execute("INSERT OR REPLACE INTO portfolio VALUES(?,?,?,?,?)", (agency, month, n, "agency", _now()))
        c.commit()
    db.set_state(agency, "port_day", dt.date.today().isoformat())
    print(f"[{agency}] portfelis: {n} ({d.get('src') or '?'})")


def due(agency: str) -> bool:
    """Vai šodien vēl jānolasa portfelis (reizi dienā)."""
    return db.get_state(agency, "port_day") != dt.date.today().isoformat()


# --------------------------------------------------------------------------- CSV imports

def _parse(text: str) -> dict:
    """CSV → {rows: [(agency, month, files)], skipped: {nosaukums: rindas}, bad: N}."""
    text = (text or "").lstrip("﻿")
    try:
        dialect = csv.Sniffer().sniff(text[:2000], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    rd = csv.reader(io.StringIO(text), dialect)
    valid = _valid_agencies()
    head = None
    rows, skipped, bad = {}, {}, 0
    for r in rd:
        r = [x.strip() for x in r]
        if not any(r):
            continue
        if head is None:
            low = [x.lower() for x in r]
            if "agency" in low or "aģentūra" in low:
                head = {k: low.index(k) for k in ("agency", "month", "files") if k in low}
                if "aģentūra" in low:
                    head.setdefault("agency", low.index("aģentūra"))
                if len(head) < 3:
                    raise ValueError("port_bad_head")
                continue
            head = {"agency": 0, "month": 1, "files": 2}
        try:
            ag_raw = r[head["agency"]].lower()
            month = r[head["month"]]
            files = int(float(r[head["files"]].replace(" ", "").replace(",", "")))
        except (IndexError, ValueError):
            bad += 1
            continue
        if not re.fullmatch(r"\d{4}-\d{2}", month) or not 0 < files <= MAX_FILES:
            bad += 1
            continue
        alias = ag_raw not in valid and ag_raw in ALIASES
        ag = ALIASES.get(ag_raw, ag_raw) if ag_raw not in valid else ag_raw
        if ag not in valid:
            skipped[ag_raw] = skipped.get(ag_raw, 0) + 1
            continue
        key = (ag, month)
        # aģentūras pašas nosaukums ir svarīgāks par vēsturisko (ja abiem ir tas pats mēnesis)
        if key in rows and alias:
            continue
        rows[key] = files
    return {"rows": [(a, m, f) for (a, m), f in sorted(rows.items())], "skipped": skipped, "bad": bad}


def preview(text: str) -> dict:
    p = _parse(text)
    by = {}
    for a, m, f in p["rows"]:
        x = by.setdefault(a, {"agency": a, "from": m, "to": m, "months": 0, "last": f})
        x["from"], x["to"] = min(x["from"], m), max(x["to"], m)
        x["months"] += 1
        if m >= x["to"]:
            x["last"] = f
    have = {(r["agency"], r["month"]) for r in db.q("SELECT agency, month FROM portfolio WHERE source='agency'")}
    keep = sum(1 for a, m, _f in p["rows"] if (a, m) in have)
    order = {a: i for i, a in enumerate(db.AG_ORDER)}
    return {"agencies": sorted(by.values(), key=lambda x: order.get(x["agency"], 99)), "rows": len(p["rows"]),
            "skipped": p["skipped"], "bad": p["bad"], "keep_agency": keep}


def do_import(text: str) -> dict:
    p = _parse(text)
    now = _now()
    with db._lock:
        c = db.conn()
        before = c.total_changes
        c.executemany("""INSERT INTO portfolio VALUES(?,?,?,'import',?)
                         ON CONFLICT(agency, month) DO UPDATE SET files=excluded.files, updated=excluded.updated
                         WHERE portfolio.source!='agency'""",
                      [(a, m, f, now) for a, m, f in p["rows"]])
        c.commit()
        n = c.total_changes - before
    db.set_state("_portfolio", "import", {"at": now, "rows": n})
    print(f"portfelis: importētas {n} rindas (izlaistas aģentūras: {', '.join(sorted(p['skipped'])) or '—'})")
    return {"rows": n, "skipped": p["skipped"], "bad": p["bad"]}


# --------------------------------------------------------------------------- pārskati

def _series() -> dict[str, dict[str, int]]:
    out: dict[str, dict[str, int]] = {}
    for r in db.q("SELECT agency, month, files FROM portfolio ORDER BY month"):
        out.setdefault(r["agency"], {})[r["month"]] = r["files"]
    return out


def _prev_month(m: str) -> str:
    y, mo = int(m[:4]), int(m[5:7]) - 1
    if mo < 1:
        y, mo = y - 1, 12
    return f"{y:04d}-{mo:02d}"


def at(agency_series: dict[str, int], month: str) -> tuple[int | None, int | None]:
    """(portfelis mēneša beigās vai pēdējais zināmais līdz tam, iepriekšējā mēneša vērtība) — izmaiņai."""
    ks = [k for k in agency_series if k <= month]
    if not ks:
        return None, None
    k = max(ks)
    cur = agency_series[k]
    pk = [x for x in agency_series if x <= _prev_month(k)]
    prev = agency_series[max(pk)] if pk else None
    return cur, prev


def for_agencies(end_month: str | None) -> dict[str, dict]:
    """{aģentūra: {files, delta, month}} — Aģentūru tabulai (perioda beigās vai jaunākais)."""
    end = end_month or "9999-12"
    out = {}
    for a, s in _series().items():
        cur, prev = at(s, end)
        if cur is None:
            continue
        k = max(x for x in s if x <= end)
        out[a] = {"files": cur, "delta": (cur - prev) if prev is not None else None, "month": k}
    return out


def enabled() -> bool:
    """Portfeļa analīze — atsevišķs aizsargāts modulis (test35; līdz tam Beta), ieslēdzams iestatījumos."""
    return config.get("sales_portfolio_on") is not False


def table(year: str = "all") -> dict:
    """Skats "Portfelis pa mēnešiem": year=YYYY → 12 mēneši; year=all → gadi (gada beigu vērtība)."""
    s = _series()
    order = {a: i for i, a in enumerate(db.AG_ORDER)}
    ags = sorted(s, key=lambda a: order.get(a, 99))
    months = sorted({m for v in s.values() for m in v})
    years = sorted({m[:4] for m in months}, reverse=True)
    if not months:
        return {"year": year, "keys": [], "agencies": [], "rows": [], "total": [], "years": []}
    cur_m = dt.date.today().isoformat()[:7]
    if year != "all" and re.fullmatch(r"\d{4}", year or ""):
        keys = [f"{year}-{m:02d}" for m in range(1, 13)]
        prev_key = f"{int(year) - 1}-12"
    else:
        year = "all"
        keys = [str(y) for y in range(int(years[-1]), int(years[0]) + 1)]
        prev_key = None

    def val(a: str, k: str) -> int | None:
        """Šūnas vērtība: mēnesis — tikai tieši zināmā; gads — pēdējā zināmā tajā gadā."""
        v = s[a]
        if len(k) == 7:
            return v.get(k)
        ks = [m for m in v if m[:4] == k]
        return v[max(ks)] if ks else None

    def carry(a: str, k: str) -> int | None:
        """Kopsummai: robs starp zināmām vērtībām aizpildīts ar iepriekšējo (ne pēc pēdējās zināmās)."""
        v = s[a]
        end = k if len(k) == 7 else k + "-12"
        if k > cur_m[: len(k)]:
            return None
        ks = [m for m in v if m <= end]
        if not ks:
            return None
        # pēc pēdējās zināmās vērtības — tikai tekošajā mēnesī (aģentūra šomēnes vēl nav nolasīta)
        if len(k) == 7 and k > max(v) and not (k == cur_m and max(v) >= _prev_month(cur_m)):
            return None
        return v[max(ks)]

    rows = []
    for a in ags:
        cells = [val(a, k) for k in keys]
        if not any(x is not None for x in cells):
            continue
        first = next((x for x in cells if x is not None), None)
        last = next((x for x in reversed(cells) if x is not None), None)
        base = carry(a, prev_key) if prev_key else None
        growth = (last - (base if base is not None else first)) if last is not None and first is not None else None
        rows.append({"agency": a, "cells": cells, "growth": growth, "last": last})
    total = []
    for k in keys:
        vals = [carry(r["agency"], k) for r in rows]
        vals = [x for x in vals if x is not None]
        total.append(sum(vals) if vals else None)
    return {"year": year, "keys": keys, "rows": rows, "total": total, "years": years,
            "import": db.get_state("_portfolio", "import")}


# --------------------------------------------------------------------------- publiskais portfelis (test44)
# iStock: portfeļa lielums redzams tikai publiskajā lapā istockphoto.com/portfolio/<vārds> (cits domēns nekā ESP, tāpēc
# savācējs to nevar nolasīt). Vārds — iestatījumos (sales_portfolio_names), kodā to neierakstām.

def _public_count(url: str, pattern: str) -> int | None:
    import re
    import urllib.request
    from core.updater import _ssl_ctx
    req = urllib.request.Request(url, headers={
        "User-Agent": ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) "
                       "Version/17.4 Safari/605.1.15"),
        "Accept": "text/html,application/xhtml+xml", "Accept-Language": "en-US,en;q=0.9"})
    with urllib.request.urlopen(req, timeout=25, context=_ssl_ctx()) as r:
        html = r.read(3_000_000).decode("utf-8", "replace")
    m = re.search(pattern, html, re.I)
    return int(re.sub(r"[^\d]", "", m.group(1))) if m else None


PUBLIC: dict = {"123rf": 1}      # test52: 123RF publiskais profils (neielogots pieprasījums, bez sesijas)
PUBLIC_OFF = {"123rf": ("https://www.123rf.com/profile_{name}", r"(\d[\d,.]*)\s*(?:</?\w+[^>]*>\s*)*Royalty[\s-]*free"),
              "istock": ("https://www.istockphoto.com/portfolio/{name}?mediatype=photography",
                     r"([\d,.]+)\s+(?:Images|Videos)?\s*(?:and|&amp;|&)?\s*Stock Photos")}


def public_fetch(agency: str) -> None:
    """Sinhronizācijas procesā pēc aģentūras atjaunošanas (fonā). Kļūdas — tikai žurnālā."""
    from urllib.parse import quote
    from core import config
    names = config.get("sales_portfolio_names") or {}
    name = str(names.get(agency) or "").strip()
    if agency not in PUBLIC:     # test44: Python pieprasījumu iStock atraida (403) — tagad to dara aģentūras logs
        return
    url, pat = PUBLIC_OFF[agency]
    known = db.get_state(agency, "public_url")
    if known and str(known).startswith("https://"):
        full = str(known).rstrip("/")
    elif name:
        full = url.format(name=quote(name))
    else:
        print(f"[{agency}] portfelis: publiskā profila adrese nav zināma")
        return
    try:
        n = _public_count(full, pat)
    except Exception as e:
        print(f"[{agency}] portfelis: publiskā lapa — {str(e)[:100]}")
        return
    if n:
        ingest(agency, {"files": n, "src": "publiskais portfelis"})
    else:
        print(f"[{agency}] portfelis: publiskajā lapā skaitlis nav atrasts (iespējams, pārbaude \"vai esi cilvēks\")")
