/* Alamy: konta izraksts (ASP.NET lapa). Neto ienākums = pārdošana − Alamy un izplatītāja komisijas. */
async function collect() {
  if (!/(^|\.)alamy\.com$/.test(location.hostname)) throw LOGIN;
  const BASE = "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1";
  let doc = await getdoc(BASE);
  const formOf = (d) => d.querySelector("form#form1") || d.forms[0];
  if (!formOf(doc) || !doc.querySelector('[name="drpPeriod"]')) throw LOGIN;

  /* ASP.NET "postback": visi formas lauki + izmaiņas */
  let CUR = BASE;                        // 2026-11-08: lapošanas POST jāsūta uz to pašu adresi (ar datumu parametriem)
  async function post(d, set, base = CUR) {
    const f = formOf(d);
    const fd = new URLSearchParams();
    for (const el of f.querySelectorAll("input, select, textarea")) {
      if (!el.name || ["submit", "button", "image", "reset"].includes(el.type)) continue;
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) continue;
      fd.set(el.name, el.value || "");
    }
    for (const k in set) fd.set(k, set[k]);
    return getdoc(base, { method: "POST", body: fd, headers: { "Content-Type": "application/x-www-form-urlencoded" } });
  }
  const pageInfo = (d) => { const m = (d.body.textContent || "").replace(/\s+/g, " ").match(/Page\s*(\d+)\s*of\s*(\d+)/i); return m ? [+m[1], +m[2]] : [1, 1]; };

  say("izraksts", 3);
  if (OPTS.mode === "full" || OPTS.payouts_full) {
    /* 2026-11-08 (pārbaudīts lietotāja Chrome): datumu intervāls caur adresi strādā — 2010…šodien, 20 lapas, 26 izmaksas */
    const M3 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"], t = new Date();
    const ed = `${String(t.getDate()).padStart(2, "0")}-${M3[t.getMonth()]}-${t.getFullYear()}`;
    CUR = `${BASE}&sdate=01-Jan-2010&edate=${ed}&r2checked=True&drpval=1&netType=1`;
    doc = await getdoc(CUR);
    B.log(AG, `izraksts: 2010…${ed}, lapas ${pageInfo(doc).join("/")}`);
  } else doc = await post(doc, { __EVENTTARGET: "drpPeriod", __EVENTARGUMENT: "", drpPeriod: "2", drpPagesize: "100" });
  const body = txt(doc.body);
  const sm = body.match(/Summary for (\d{1,2} [A-Za-z]+ \d{4}) to (\d{1,2} [A-Za-z]+ \d{4})/);
  /* izmaksu vēsture vēl nav (payouts_full) — pirmo reizi lasām visu izrakstu (arī ikdienas atjaunošanā) */
  const start = sm ? pdate(sm[1]) : (OPTS.mode === "full" || OPTS.payouts_full ? "2000-01-01" : OPTS.since);
  const end = sm ? pdate(sm[2]) : today;
  const bal = body.match(/Balance carried forward:\s*\$\s*(-?[\d,.]+)/i);
  if (bal) await send("balance", { amount: money(bal[1]), currency: "USD" });

  const cleared = body.match(/Cleared balance:?\s*\$\s*(-?[\d,.]+)/i);
  const nextPay = body.match(/Next payment date:?\s*(\d{1,2}[\s/.-]+[A-Za-z0-9]+[\s/.-]+\d{4})/i);
  const pays = [];                       // izmaksas izrakstā (PayPal u.c.)
  const agg = new Map();                 // (diena|ID) -> {neto, skaits}
  const hasRows = (d) => [...d.querySelectorAll("table tr")].some((tr) => tr.cells.length >= 7 && pdate(txt(tr.cells[0])));
  async function readAll(d) {
    let [pg, pages] = pageInfo(d);
    for (let guard = 0; guard < 500; guard++) {
      say(`${pg}/${pages}`, Math.min(95, 5 + Math.round((pg / Math.max(1, pages)) * 90)));
      for (const tr of d.querySelectorAll("table tr")) {
        const c = [...tr.cells].map((x) => txt(x));
        if (c.length < 7) continue;
        const day = pdate(c[0]);
        if (!day) continue;
        const desc = c[1], id = c[2];
        if (/paypal|payment|transfer|bank|cheque|withdraw|brought forward/i.test(desc)) {
          if (!/brought forward/i.test(desc)) pays.push({ date: day, amount: Math.abs(money(c[4]) || money(c[5])), currency: "USD" });
          continue;
        }
        const key = day + "|" + id;
        const a = agg.get(key) || { e: 0, n: 0 };
        a.e += money(c[5]) - money(c[4]);
        if (/^sale$/i.test(desc)) a.n += 1;
        if (/^sale refunded/i.test(desc)) a.n -= 1;
        agg.set(key, a);
      }
      if (pg >= pages) break;
      const before = pg;
      d = await post(d, { __EVENTTARGET: "", __EVENTARGUMENT: "", txtGotopage: String(pg + 1), btnGotopage: "Go" });
      [pg, pages] = pageInfo(d);
      if (pg <= before) break;              // lapošana neizdevās — beidzam ar to, kas ir
      await sleep(300);
    }
  }
  /* 2026-11-06 (lietotājs): periods "All" (no 2000.) rāda tukšu izrakstu ar lapu numuriem — tad lasām pa gadiem ar datumu
     intervālu ("Please enter a date range": no 01-Jan-YYYY līdz 31-Dec-YYYY), kas darbojas */
  if (!hasRows(doc) && (OPTS.mode === "full" || OPTS.payouts_full)) {
    const f = formOf(doc), MON3 = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    const dts = [...f.querySelectorAll('input[type="text"]')].filter((i) => /^\d{2}-[A-Za-z]{3}-\d{4}$/.test(i.value || ""));
    const radios = [...f.querySelectorAll('input[type="radio"]')];
    const goBtn = [...f.querySelectorAll('input[type="submit"], input[type="image"], button')].find((b) => /^go$/i.test((b.value || b.innerText || "").trim()) && !/gotopage/i.test(b.name || b.id || ""));
    B.log(AG, `izraksts: "All" tukšs — lasu pa gadiem (lauki: ${dts.map((i) => i.name).join(", ") || "nav"}; radio: ${radios.map((r) => r.name + "=" + r.value).join(", ")}; poga: ${goBtn ? goBtn.name : "nav"})`);
    if (dts.length >= 2) {
      const fmt = (y, m, dd) => `${String(dd).padStart(2, "0")}-${MON3[m]}-${y}`;
      const y0 = +today.slice(0, 4);
      let empty = 0;
      for (let y = y0; y >= 2005 && empty < 3; y--) {
        say(`izraksts ${y}`, 5);
        const set = { __EVENTTARGET: "", __EVENTARGUMENT: "", [dts[0].name]: fmt(y, 0, 1), [dts[1].name]: y === y0 ? fmt(y, +today.slice(5, 7) - 1, +today.slice(8, 10)) : fmt(y, 11, 31), drpPagesize: "100" };
        if (radios.length >= 2) set[radios[1].name] = radios[1].value;
        if (goBtn && goBtn.name) set[goBtn.name] = goBtn.value || "Go";
        const d = await post(doc, set);
        if (hasRows(d)) { empty = 0; await readAll(d); } else empty++;
        await sleep(400);
      }
    }
  } else await readAll(doc);
  const rows = [];
  for (const [key, a] of agg) {
    const [day, id] = key.split("|");
    if (Math.abs(a.e) < 0.0001 && !a.n) continue;
    rows.push({ day, id, amount: Math.round(a.e * 10000) / 10000, cnt: a.n, kind: "sale",
      url: id ? `https://www.alamy.com/search.html?qt=${encodeURIComponent(id)}` : "" });
  }
  await sendRows(rows, { start, end });
  /* sīktēli (test48): pārdošanu vēsture Rep=0 — pie katras pārdošanas sīktēls c7.alamy.com/thumbs/…/<ID>.jpg;
     pirmo reizi visa vēsture, pēc tam reizi dienā jaunākās */
  if (OPTS.full_thumbs || OPTS.port_due) {        // port_due = pirmā atjaunošana šodien
    try {
      const B0 = BASE.replace("Rep=1", "Rep=0");
      let d0 = await getdoc(B0);
      if (formOf(d0) && d0.querySelector('[name="drpPeriod"]')) {
        d0 = await post(d0, { __EVENTTARGET: "drpPeriod", __EVENTARGUMENT: "", drpPeriod: OPTS.full_thumbs ? "2000" : "2", drpPagesize: "100" }, B0);
        const th = new Map();
        let [p0, n0] = pageInfo(d0);
        for (let g = 0; g < 80; g++) {
          for (const img of d0.querySelectorAll("img[src*='alamy.com/thumbs'], img[src*='alamy.com/comp'], img[data-src*='alamy.com/thumbs']")) {
            const src = (img.getAttribute("src") || img.getAttribute("data-src") || "").replace(/\s+/g, "");
            const m = src.match(/\/([A-Z0-9]{5,10})\.jpg/i);
            if (m && !th.has(m[1])) th.set(m[1], src.startsWith("//") ? "https:" + src : src);
          }
          if (p0 >= n0) break;
          const b = p0;
          d0 = await post(d0, { __EVENTTARGET: "", __EVENTARGUMENT: "", txtGotopage: String(p0 + 1), btnGotopage: "Go" }, B0);
          [p0, n0] = pageInfo(d0);
          if (p0 <= b) break;
          await sleep(300);
        }
        B.log(AG, `sīktēli: ${th.size}`);
        if (th.size) await send("thumbs", { rows: [...th].map(([id, thumb]) => ({ id, thumb })), all: !!OPTS.full_thumbs });
      } else B.log(AG, "sīktēli: Rep=0 forma nav atrasta");
    } catch (e) { if (e && e.login) throw e; B.log(AG, "sīktēli: " + String((e && e.message) || e).slice(0, 100)); }
  }
  /* izmaksas: automātiskas nākamajā mēnesī, ja "Cleared balance" ≥ minimums (lietotājs: $50) */
  await payoutsSafe(async () => {
    await sendPayInfo({ unpaid: bal ? money(bal[1]) : null, available: cleared ? money(cleared[1]) : null, currency: "USD",
      next_date: nextPay ? pdate(nextPay[1]) : null });
    await sendPayouts(pays, OPTS.mode === "full" || OPTS.payouts_full ? {} : { full: false, start });
  });
  const AIM = (t) => { const m = t.match(/All submissions[\s\S]{0,60}?Images:?\s*(\d[\d,]*)/i); return m ? numOf(m[1]) : null; };
  if (OPTS.sub_due) { try { await alStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["Image Manager (All submissions)", async () => AIM(txt((await getdoc("https://www.alamy.com/myupload/Index.aspx")).body)) || framed("https://www.alamy.com/myupload/Index.aspx", AIM)],
    ["izraksts", async () => countIn(body)],
    ["dashboard", () => portPage("https://www.alamy.com/alamycontributorreports/")],
    ["contributor", () => portPage("https://www.alamy.com/contributor/dashboard/")],
  ]);
  return { rows: rows.length, start, end };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): Image Manager www.alamy.com/myupload/Index.aspx
   (bez filtriem; jaunākie iesniegumi augšā) — kartītēs "<faila nosaukums> · Image ID: 3G1JM7N · Image in QC | On sale | …"
   un atrodamības josla (oranža = vāja → jāpapildina kategorijas/atslēgvārdi; zaļa = laba). Bildes ielādējas ritinot.
   Lasām līdz ~300 jaunākajām kartītēm. Atrodamību glabājam statusā: "On sale (atrodamība NN%)". */
/* 0.3.1-test31 (Chrome 2026-11-09): Image Manager datus ņem no JSON
   POST /myupload/myuploadservice.asmx/GetFilterResultsInternal {filter:"",pageno,pagesize:50,status:10,uploadedfrom:""}
   → d.Submission[].Images[] {Ref, Status (110 = On sale), Caption, Discoverable, UploadFileName, Reason}; d.RecordCount, d.PassedCount.
   Rāmja lasīšana (zemāk) paliek kā rezerve. */
const AL_ST = { 110: "On sale" };
async function alStatusApi() {
  const rows = new Map();
  let total = null;
  for (let p = 1; p <= 6 && rows.size < 300; p++) {
    const r = await fetch("/myupload/myuploadservice.asmx/GetFilterResultsInternal", {
      method: "POST", credentials: "include", headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify({ filter: "", pageno: p, pagesize: 50, status: 10, uploadedfrom: "" }) });
    if (!r.ok) throw new Error("GetFilterResultsInternal HTTP " + r.status);
    const d = ((await r.json()) || {}).d || {};
    if (total == null) total = d.RecordCount;
    const subs = d.Submission || [];
    if (!subs.length) break;
    for (const s of subs) for (const i of s.Images || []) {
      if (!i.Ref || rows.has(i.Ref)) continue;
      const st = AL_ST[i.Status] || (i.Reason ? "Failed QC" : s.InQC ? "Image in QC" : "Status " + i.Status);
      const disc = i.Discoverable != null && st === "On sale" ? ` (atrodamība ${Math.min(100, Math.round(+i.Discoverable))}%)` : "";
      rows.set(i.Ref, { id: i.Ref, file: i.UploadFileName || "", title: i.Caption || "", submitted: s.UploadDate || "",
        status: st + disc + (i.Reason ? ` — ${i.Reason}` : "") });
    }
  }
  return { list: [...rows.values()], total };
}

async function alStatus() {
  try {
    const { list, total } = await alStatusApi();
    if (list.length) {
      const f = list[0], codes = [...new Set(list.map((x) => x.status.split(" (")[0].split(" —")[0]))].join(", ");
      B.log(AG, `statusi: ${list.length} bildes (API; kopā ${total}); statusi: ${codes}; paraugs: ID ${f.id}, fails "${f.file}", ${f.status}`);
      await send("sub_items", { rows: list, part: 1, parts: 1 });
      await send("sub_done", { full: false });
      return;
    }
    B.log(AG, "statusi: API — 0 bildes, mēģinu no lapas");
  } catch (e) {
    if (e && e.login) throw e;
    B.log(AG, "statusi: API — " + String((e && e.message) || e).slice(0, 120) + ", mēģinu no lapas");
  }
  const rows = new Map();
  const r = await framed("/myupload/Index.aspx", (t) => (/Image ID:/i.test(t) ? true : null), 40000, async ({ doc, win }) => {
    const scan = () => {
      for (const el of doc.querySelectorAll("body *")) {
        const t = (el.innerText || "").replace(/\s+/g, " ").trim();
        if (!/^\S.*Image ID:\s*[0-9A-Z]{5,8}\b/.test(t) || t.length > 200 || [...el.children].some((c) => /Image ID:/.test(c.innerText || ""))) continue;
        let card = el; for (let i = 0; i < 4 && card.parentElement && ((card.parentElement.innerText || "").match(/Image ID:/g) || []).length === 1; i++) card = card.parentElement;
        const ct = (card.innerText || "").replace(/\s+/g, " ");
        const id = (ct.match(/Image ID:\s*([0-9A-Z]{5,8})\b/) || [])[1]; if (!id || rows.has(id)) continue;
        const file = ((ct.match(/(\S+\.(?:jpe?g|tiff?|png))/i) || [])[1] || "").replace(/…$/, "");
        const st = (ct.match(/\b(Image in QC|On sale|Not on sale|Failed QC|QC fail\w*|Rejected|Suspended|Deleted)\b/i) || [])[1] || "";
        /* atrodamība: joslas aizpildījuma platums (elementa ar fona krāsu daļa no rāmja) */
        let disc = "";
        for (const b of card.querySelectorAll("div, span")) {
          const w = b.getBoundingClientRect().width, pw = b.parentElement ? b.parentElement.getBoundingClientRect().width : 0;
          const bg = win.getComputedStyle(b).backgroundColor;
          if (pw > 40 && w > 0 && w < pw && b.getBoundingClientRect().height < 14 && !/rgba\(0, 0, 0, 0\)|transparent|rgb\(255, 255, 255\)/.test(bg)) { disc = String(Math.round((w / pw) * 100)); break; }
        }
        rows.set(id, { id, file, title: "", submitted: "", status: (st || "Uploaded") + (disc && /on sale/i.test(st) ? ` (atrodamība ${disc}%)` : "") });
      }
    };
    const box = [...doc.querySelectorAll("div")].filter((d) => d.scrollHeight > d.clientHeight + 200 && /Image ID:/.test(d.innerText || "")).sort((a, b) => b.scrollHeight - a.scrollHeight)[0];
    let last = -1, same = 0;
    for (let i = 0; i < 60 && rows.size < 300; i++) {
      scan();
      if (rows.size === last) { if (++same >= 4) break; } else { same = 0; last = rows.size; }
      if (box) box.scrollTop += 1500; else win.scrollBy(0, 1500);
      await sleep(900);
    }
    scan();
    if (!rows.size) {      /* 2026-11-06 (žurnāls): 0 bildes — lapas uzbūves izpētei */
      try {
        const urls = [...new Set(win.performance.getEntriesByType("resource").filter((e) => /fetch|xmlhttprequest/.test(e.initiatorType)).map((e) => { const u = new URL(e.name); return u.host + u.pathname; }))].slice(0, 12);
        B.log(AG, "statusi: lapas API: " + (urls.join(" · ") || "nav"));
      } catch (_) { /* */ }
      const card = [...doc.querySelectorAll("body *")].find((e) => /Image ID/i.test(e.textContent || "") && (e.textContent || "").length < 400);
      B.log(AG, "statusi: kartīte: " + (card ? card.outerHTML.replace(/\s+/g, " ").slice(0, 400) : "nav; teksts: " + (doc.body.innerText || "").replace(/\s+/g, " ").slice(0, 300)));
    }
    return true;
  }, true);
  const list = [...rows.values()], f = list[0];
  const weak = list.filter((x) => { const m = x.status.match(/atrodamība (\d+)%/); return m && +m[1] < 60; }).length;
  B.log(AG, `statusi: ${list.length} bildes` + (f ? `; paraugs: ID ${f.id}, fails "${f.file}", ${f.status}` : "") + (weak ? `; vāja atrodamība: ${weak}` : "") + (r == null ? "; lapa neielādējās" : ""));
  if (list.length) await send("sub_items", { rows: list, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
