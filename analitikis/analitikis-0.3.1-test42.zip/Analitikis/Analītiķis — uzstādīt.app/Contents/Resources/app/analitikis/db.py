"""Pārdošanu datubāze catalog.db (SQLite): ievade no aģentūru savācējiem un vaicājumi pārskatiem.

Tabulas:
  assets   — aģentūras vienums (bilde): nosaukums, sīktēls, faila vārds, sasaistes atslēgas:
             fkey = oriģinālā faila nosaukums bez paplašinājuma (galvenā, sk. integrācijas plānu),
             mkey = normalizēts virsraksts (rezerves; vieno vienu bildi starp aģentūrām)
  files    — kopīgā bilžu tabula (§8), Analītiķī vēl tukša
  sales    — pārdošanas: Adobe katra atsevišķi, Shutterstock pa dienām/bildēm/kategorijām,
             Envato Elements pa mēnešiem/vienumiem
  daily    — ienākumi un lejupielādes pa dienām un kategorijām (paneļu kopsummas)
  monthly  — tas pats pa mēnešiem (Envato no API, pārējām aprēķināts no daily)
  totals   — vienuma kopsummas visā vēsturē (Shutterstock no API, pārējām aprēķināts)
  balance  — neizmaksātais atlikums
  buyers   — pēdējo pārdošanu pircēju valstis (Shutterstock)
  state    — sinhronizācijas stāvoklis
  portfolio — portfeļa lielums pa aģentūrām un mēnešiem (portfolio.py)
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sqlite3
import sys
import threading
import time
from pathlib import Path

from . import config

# counts = aģentūra dod lejupielāžu skaitu; lag = ienākumi parādās ar nobīdi (nav "šodien");
# currency = aģentūras valūta (summas pārrēķina USD, sk. fx.py)
AGENCIES = {
    "adobe": {"name": "Adobe Stock", "counts": True, "lag": False, "currency": "USD"},
    "shutterstock": {"name": "Shutterstock", "counts": True, "lag": False, "currency": "USD"},
    "envato": {"name": "Envato Elements", "counts": False, "lag": True, "currency": "USD"},
    "istock": {"name": "iStock / Getty", "counts": True, "lag": True, "currency": "USD"},
    "alamy": {"name": "Alamy", "counts": True, "lag": False, "currency": "USD"},
    "123rf": {"name": "123RF", "counts": True, "lag": False, "currency": "USD"},
    "dreamstime": {"name": "Dreamstime", "counts": True, "lag": False, "currency": "USD"},
    "depositphotos": {"name": "Depositphotos", "counts": True, "lag": False, "currency": "USD"},
    "magnific": {"name": "Magnific", "counts": True, "lag": False, "currency": "EUR"},
    "pixta": {"name": "Pixta", "counts": True, "lag": False, "currency": "USD"},
    "pond5": {"name": "Pond5", "counts": True, "lag": False, "currency": "USD"},
    "bigstock": {"name": "Bigstock", "counts": True, "lag": False, "currency": "USD"},
    "zoonar": {"name": "Zoonar", "counts": True, "lag": True, "currency": "EUR"},
    "ingram": {"name": "Ingram", "counts": False, "lag": True, "currency": "GBP"},
    # Envato Market: tie paši Envato autoru portāla dati (savāc Envato logs) — atsevišķa aģentūra
    "envato_market": {"name": "Envato Market", "counts": False, "lag": True, "currency": "USD", "via": "envato"},
    # arhīva aģentūras (dati tikai no Microstockr importa; vairs netiek atjaunotas)
    "eyeem": {"name": "EyeEm", "counts": True, "lag": False, "currency": "USD", "archive": True},
    "mostphotos": {"name": "Mostphotos", "counts": True, "lag": False, "currency": "USD", "archive": True},
    "yayimages": {"name": "Yayimages", "counts": True, "lag": False, "currency": "USD", "archive": True},
    # 2026-11-08: arhīva aģentūras tikai vēsturiskām izmaksām (payouts_hist.py)
    "twenty20": {"name": "Twenty20", "counts": False, "lag": False, "currency": "USD", "archive": True},
    "vecteezy": {"name": "Vecteezy", "counts": False, "lag": False, "currency": "USD", "archive": True},
    "foap": {"name": "Foap", "counts": False, "lag": False, "currency": "USD", "archive": True},
    "storyblocks": {"name": "Storyblocks", "counts": False, "lag": False, "currency": "USD", "archive": True},
    "500px": {"name": "500px", "counts": False, "lag": False, "currency": "USD", "archive": True},
}
AG_ORDER = list(AGENCIES)
MONTHLY_ITEMS = {"envato", "envato_market", "ingram"}     # aģentūras, kuru "pārdošanas" ir (vienuma) mēneša ienākumi
MONTH_ROW_TITLE = {"ingram": "Ingram — ienākumi par mēnesi (bez sadalījuma pa bildēm)"}

_lock = threading.RLock()
_conn: sqlite3.Connection | None = None
_path_override: Path | None = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS assets(agency TEXT, agency_item_id TEXT, title TEXT, thumb TEXT, filename TEXT, url TEXT,
  media TEXT, uploaded TEXT, mkey TEXT, fkey TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE INDEX IF NOT EXISTS assets_fkey ON assets(fkey);
CREATE INDEX IF NOT EXISTS assets_mkey ON assets(mkey);
CREATE INDEX IF NOT EXISTS assets_fn ON assets(filename);
-- sales: lauki pēc fotostokeris-noteikumi.md §8 (+ pievienoti day, cnt, kind)
CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, agency TEXT, agency_item_id TEXT, file_id INTEGER,
  sold_at TEXT, amount REAL, currency TEXT DEFAULT 'USD', license TEXT, country TEXT, raw TEXT,
  day TEXT, cnt INTEGER, kind TEXT);
-- files: kopīgā tabula (§8); Analītiķis to vēl neaizpilda — sasaiste notiek pēc assets.fkey = files.stem
CREATE TABLE IF NOT EXISTS files(id INTEGER PRIMARY KEY, stem TEXT UNIQUE, path TEXT, taken_at TEXT,
  width INT, height INT, category TEXT, status TEXT, updated_at TEXT);
CREATE INDEX IF NOT EXISTS sales_day ON sales(day);
CREATE INDEX IF NOT EXISTS sales_ag_day ON sales(agency, day);
CREATE INDEX IF NOT EXISTS sales_asset ON sales(agency, agency_item_id);
CREATE TABLE IF NOT EXISTS daily(agency TEXT, day TEXT, cat TEXT, earnings REAL, downloads INTEGER,
  PRIMARY KEY(agency, day, cat));
CREATE TABLE IF NOT EXISTS monthly(agency TEXT, month TEXT, cat TEXT, earnings REAL, downloads INTEGER,
  PRIMARY KEY(agency, month, cat));
CREATE TABLE IF NOT EXISTS totals(agency TEXT, agency_item_id TEXT, cat TEXT, earnings REAL, downloads INTEGER,
  PRIMARY KEY(agency, agency_item_id, cat));
CREATE TABLE IF NOT EXISTS balance(agency TEXT PRIMARY KEY, amount REAL, currency TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS buyers(agency TEXT, sold_at TEXT, agency_item_id TEXT, amount REAL, country TEXT, city TEXT,
  PRIMARY KEY(agency, sold_at, agency_item_id));
CREATE TABLE IF NOT EXISTS state(agency TEXT, key TEXT, value TEXT, PRIMARY KEY(agency, key));
-- jaunās pārdošanas: stāvoklis pirms atjaunošanas (snap_*) un tas, kas pēc tās nāca klāt (fresh)
CREATE TABLE IF NOT EXISTS snap_items(agency TEXT, item TEXT, day TEXT, cnt INTEGER, amt REAL, PRIMARY KEY(agency, item, day));
CREATE TABLE IF NOT EXISTS snap_days(agency TEXT, day TEXT, e REAL, n INTEGER, PRIMARY KEY(agency, day));
CREATE TABLE IF NOT EXISTS fresh(agency TEXT, item TEXT, day TEXT, cnt INTEGER, amt REAL, PRIMARY KEY(agency, item, day));
"""


def db_path() -> Path:
    return _path_override or (config.app_dir() / "catalog.db")


def conn() -> sqlite3.Connection:
    global _conn
    with _lock:
        if _conn is None:
            c = sqlite3.connect(str(db_path()), timeout=30, check_same_thread=False)
            c.row_factory = sqlite3.Row
            try:
                c.execute("PRAGMA journal_mode=WAL")
            except sqlite3.DatabaseError:
                pass
            c.executescript(SCHEMA)
            from . import colls, lookalike, portfolio
            c.executescript(colls.SCHEMA)
            c.executescript(lookalike.SCHEMA)
            c.executescript(portfolio.SCHEMA)
            _migrate(c)
            c.commit()
            _conn = c
        return _conn


def _migrate(c: sqlite3.Connection) -> None:
    """Datubāzes papildināšana no vecākām versijām (lauki tiek tikai pievienoti, §8)."""
    cols = {r[1] for r in c.execute("PRAGMA table_info(sales)")}
    if "amount_usd" not in cols:
        c.execute("ALTER TABLE sales ADD COLUMN amount_usd REAL")
        c.execute("UPDATE sales SET amount_usd=amount WHERE amount_usd IS NULL")
    if "batch" not in cols:
        c.execute("ALTER TABLE sales ADD COLUMN batch TEXT")
    acols = {r[1] for r in c.execute("PRAGMA table_info(assets)")}
    if "gid" not in acols:
        c.execute("ALTER TABLE assets ADD COLUMN gid TEXT")
    # 0.1.0 unikālais indekss attiecās uz visām aģentūrām; tagad tikai Adobe (pārdošanas ar precīzu laiku)
    c.execute("DROP INDEX IF EXISTS sales_uniq")
    c.execute("CREATE UNIQUE INDEX IF NOT EXISTS sales_uniq_adobe ON sales(agency, sold_at, agency_item_id, kind, license, amount)"
              " WHERE agency='adobe'")
    c.execute("CREATE INDEX IF NOT EXISTS sales_batch ON sales(agency, batch)")
    c.execute("CREATE INDEX IF NOT EXISTS assets_gid ON assets(gid)")


def close():
    """Aizver datubāzi (rezerves kopijas atjaunošanai); nākamais vaicājums to atver no jauna."""
    global _conn
    with _lock:
        if _conn:
            try:
                _conn.close()
            except Exception:
                pass
        _conn = None


def backup_info(path) -> dict:
    """Rezerves kopijas pārskatam: cik pārdošanu, bilžu, aģentūru, kolekciju; periods."""
    c = sqlite3.connect(str(path))
    try:
        one = lambda sql: (c.execute(sql).fetchone() or [None])[0]
        def safe(sql):
            try:
                return one(sql)
            except sqlite3.Error:
                return None
        return {"sales": safe("SELECT COUNT(*) FROM sales"), "assets": safe("SELECT COUNT(*) FROM assets"),
                "agencies": safe("SELECT COUNT(DISTINCT agency) FROM sales"), "collections": safe("SELECT COUNT(*) FROM collections"),
                "portfolio": safe("SELECT COUNT(*) FROM portfolio"), "first": safe("SELECT MIN(day) FROM sales"),
                "last": safe("SELECT MAX(day) FROM sales")}
    finally:
        c.close()


def use_path(p: Path):
    """Testiem: cita datubāzes vieta."""
    global _conn, _path_override
    with _lock:
        if _conn:
            _conn.close()
        _conn = None
        _path_override = p


def q(sql: str, args=()) -> list[sqlite3.Row]:
    with _lock:
        return conn().execute(sql, args).fetchall()


def q1(sql: str, args=()):
    r = q(sql, args)
    return r[0] if r else None


# --------------------------------------------------------------------------- palīgi

_WORD = re.compile(r"[^\w]+", re.UNICODE)


def mkey(title: str | None) -> str | None:
    """Salīdzināšanas atslēga pēc nosaukuma (Vārdotāja virsraksti ir unikāli, aģentūras tos pārņem)."""
    s = _WORD.sub(" ", (title or "").lower()).strip()
    if len(s.split()) < 4:
        return None
    return s[:100].strip()


def fkey(filename: str | None) -> str | None:
    """Oriģinālā faila nosaukums bez paplašinājuma, mazajiem burtiem: '2021-AKO_8016.jpg' -> '2021-ako_8016'."""
    n = (filename or "").strip().replace("\\", "/").split("/")[-1]
    if not n or n.lower() == "source":
        return None
    stem = n.rsplit(".", 1)[0] if "." in n else n
    return stem.lower() or None


def num(v) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def get_state(agency: str, key: str, default=None):
    r = q1("SELECT value FROM state WHERE agency=? AND key=?", (agency, key))
    if not r:
        return default
    try:
        return json.loads(r["value"])
    except (TypeError, ValueError):
        return r["value"]


def set_state(agency: str, key: str, value):
    with _lock:
        c = conn()
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, key, json.dumps(value)))
        c.commit()


def _upsert_asset(c, agency, agency_item_id, title=None, thumb=None, filename=None, url=None, media=None, uploaded=None):
    if agency_item_id in (None, ""):
        return
    agency_item_id = str(agency_item_id)
    old = c.execute("SELECT * FROM assets WHERE agency=? AND agency_item_id=?", (agency, agency_item_id)).fetchone()
    vals = {"title": title, "thumb": thumb, "filename": filename, "url": url, "media": media, "uploaded": uploaded}
    if old:
        vals = {k: (v if v not in (None, "") else old[k]) for k, v in vals.items()}
    fn = (vals["filename"] or "").strip()
    c.execute("INSERT OR REPLACE INTO assets(agency, agency_item_id, title, thumb, filename, url, media, uploaded, mkey, fkey, gid)"
              " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              (agency, agency_item_id, vals["title"], vals["thumb"], fn or None, vals["url"], vals["media"],
               vals["uploaded"], mkey(vals["title"]), fkey(fn), None))


def _rebuild_monthly(c, agency: str, months: set[str]):
    for m in months:
        c.execute("DELETE FROM monthly WHERE agency=? AND month=?", (agency, m))
        c.execute("""INSERT INTO monthly SELECT agency, substr(day,1,7), cat, SUM(earnings), SUM(downloads)
                     FROM daily WHERE agency=? AND substr(day,1,7)=? GROUP BY cat""", (agency, m))


def _months_between(a: str, b: str) -> set[str]:
    y, m = int(a[:4]), int(a[5:7])
    out = set()
    while f"{y:04d}-{m:02d}" <= b[:7]:
        out.add(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def _day(ts: str) -> str:
    return (ts or "")[:10]


# --------------------------------------------------------------------------- ievade

_data_at = [0.0]


def data_at() -> str:
    """2026-11-06 (pilnā sinhronizācija): kad šajā datorā pēdējo reizi ienāca aģentūru dati (ISO, UTC)."""
    return str(get_state("_sync", "data_at") or "")


def set_data_at(v: str) -> None:
    set_state("_sync", "data_at", v)


def ingest(agency: str, kind: str, d: dict) -> None:
    """Viena datu porcija no savienotāja (sk. vardotajs/collectors/*.js)."""
    if time.time() - _data_at[0] > 30:          # atzīme "dati mainījušies" (ne biežāk kā ik 30 s)
        _data_at[0] = time.time()
        try:
            set_state("_sync", "data_at", dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"))
        except Exception:
            pass
    if kind == "sub_items":                      # 2026-11-05: iesniegumu statusi (Envato Portfolio Manager CSV)
        from . import substatus
        substatus.ingest(agency, d)
        return
    if kind == "sub_done":                       # 2026-11-06: statusi nolasīti (Adobe u.c.; full = visas lapas vienreiz)
        set_state(agency, "sub_at", dt.datetime.now().isoformat(timespec="seconds"))
        set_state(agency, "sub_v", 3)                # 0.3.1-test11: statusu loģika mainīta (iStock published_at) — pēc atjaunināšanas lasa uzreiz
        if d.get("full"):
            set_state(agency, "sub_full", _today().isoformat())
        return
    if kind == "sub_probe":                      # 2026-11-05: iesniegumu lapu izpēte izdarīta (žurnālā)
        set_state(agency, "sub_probe", _today().isoformat())
        return
    if kind == "portfolio":                      # portfeļa lielums (visas aģentūras vienādi)
        from . import portfolio
        portfolio.ingest(agency, d)
        return
    fn = INGEST.get((agency, kind))
    if not fn:
        return
    with _lock:
        c = conn()
        try:
            fn(c, d)
            c.commit()
        except Exception:
            c.rollback()
            raise


def _bal(agency):
    def f(c, d):
        c.execute("INSERT OR REPLACE INTO balance VALUES(?,?,?,?)",
                  (agency, num(d.get("amount")), d.get("currency") or "USD", dt.datetime.now().isoformat(timespec="seconds")))
        from . import payouts
        payouts.note_balance(c, agency, num(d.get("amount")), d.get("currency") or "USD")
    return f


# --- Adobe Stock
ADOBE_EUR_UNTIL = "2023-03-01"     # Adobe konts EUR līdz 2023-02 (pēdējā EUR izmaksa 2023-02-28, pirmā USD 2023-04-01)


def _adobe_cur(day: str) -> str:
    return "EUR" if str(day or "")[:10] < ADOBE_EUR_UNTIL else "USD"


def _adobe_sales(c, d):
    """Pārdošanas periodā [start, end]; pirmā lapa periodu notīra (aizstāšana)."""
    s, e = d["start"], d["end"]
    if int(d.get("page") or 1) == 1:
        c.execute("DELETE FROM sales WHERE agency='adobe' AND kind!='other' AND day BETWEEN ? AND ?", (s, e))
    outside = set()
    for r in d.get("rows") or []:
        aid = str(r.get("id") or "")
        com = r.get("commission") or {}
        amount = num(com.get("amount") if isinstance(com, dict) else None) or num(r.get("commissionAmount"))
        wh = r.get("withholdings") or {}
        _upsert_asset(c, "adobe", aid, r.get("title"), r.get("thumbnailUrl"), r.get("originalName"),
                      f"https://stock.adobe.com/search?k={aid}" if aid else None, str(r.get("assetType") or ""))
        ts = r.get("saleDate") or ""
        if not (s <= _day(ts) <= e):
            outside.add(_day(ts))
        # 0.3.1-test16 (Chrome 2026-11-08): līdz 2023-02 konts bija EUR; Adobe vecās summas rāda ar "$", bet tās ir EUR
        # (mēneša ienākumi = nākamās EUR izmaksas, piem. 2023-02 217.37 → izmaksa €217.38)
        cur = _adobe_cur(_day(ts))
        c.execute("INSERT OR IGNORE INTO sales(agency,day,sold_at,agency_item_id,amount,currency,amount_usd,cnt,kind,license,raw) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  ("adobe", _day(ts), ts, aid, amount, cur, amount if cur == "USD" else _to_usd(c, "adobe", amount, cur, _day(ts)), 1, "sale", r.get("license") or "",
                   json.dumps({"wh": num(wh.get("amount") if isinstance(wh, dict) else 0),
                               "type": r.get("transactionType")})))
    for day in outside:
        _adobe_daily(c, day, day)
    if d.get("last"):
        _adobe_daily(c, s, e)
        _adobe_totals(c)


def _adobe_daily(c, s, e):
    """Adobe dienas un mēnešu kopsummas no atsevišķajām pārdošanām."""
    c.execute("DELETE FROM daily WHERE agency='adobe' AND cat='sale' AND day BETWEEN ? AND ?", (s, e))
    c.execute("""INSERT INTO daily SELECT 'adobe', day, 'sale', SUM(amount_usd), SUM(cnt) FROM sales
                 WHERE agency='adobe' AND kind='sale' AND day BETWEEN ? AND ? GROUP BY day""", (s, e))
    _rebuild_monthly(c, "adobe", _months_between(s, e))


def _adobe_totals(c):
    c.execute("DELETE FROM totals WHERE agency='adobe'")
    c.execute("""INSERT INTO totals SELECT 'adobe', agency_item_id, 'sale', SUM(amount_usd), SUM(cnt) FROM sales
                 WHERE agency='adobe' AND kind='sale' GROUP BY agency_item_id""")


ADOBE_OTHER_TYPES = {77: "AI / datu licencēšana", 79: "AI / datu licencēšana"}


def _adobe_other(c, d):
    """Citi maksājumi (AI datu kopu licencēšana, bonusi) — vienmēr visa vēsture."""
    old_days = {r["day"] for r in c.execute("SELECT DISTINCT day FROM daily WHERE agency='adobe' AND cat='other'")}
    c.execute("DELETE FROM sales WHERE agency='adobe' AND kind='other'")
    c.execute("DELETE FROM daily WHERE agency='adobe' AND cat='other'")
    days = set()
    for r in d.get("rows") or []:
        ts = str(r.get("creation") or "").replace(" ", "T")[:19]
        typ = r.get("creditTransactionTypeId")
        aid = f"other-{typ}"
        _upsert_asset(c, "adobe", aid, "Adobe Stock — " + ADOBE_OTHER_TYPES.get(typ, f"cits maksājums ({typ})"), None, None, None, "other")
        c.execute("INSERT OR IGNORE INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,cnt,kind,license,raw) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  ("adobe", _day(ts), ts, aid, num(r.get("amount")), num(r.get("amount")), 0, "other", "", json.dumps({"type": typ})))
        days.add(_day(ts))
    # 0.3.1-test16: nedēļas grafiks − pārdošanas − citi maksājumi = bonusi, kas citur nav redzami (2021–2023)
    chart = d.get("chart") or {}
    if chart:
        wk = {}
        for r in c.execute("SELECT day, amount AS amount_usd FROM sales WHERE agency='adobe'"):   # aģentūras valūtā (kā grafikā)
            try:
                y, w, _ = dt.date.fromisoformat(r["day"][:10]).isocalendar()
            except (TypeError, ValueError):
                continue
            wk[(y, w)] = wk.get((y, w), 0.0) + (r["amount_usd"] or 0)
        _upsert_asset(c, "adobe", "other-chart", "Adobe Stock — bonuss / cits maksājums (no grafika)", None, None, None, "other")
        for k, v in chart.items():
            try:
                y, w = int(str(k)[:4]), int(str(k)[5:7])
                v = v[0] if isinstance(v, list) else v
                diff = round(num(v) - wk.get((y, w), 0.0), 2)
                if diff < 0.5:
                    continue
                day = dt.date.fromisocalendar(y, w, 1).isoformat()
                wcur = _adobe_cur(day)
            except (TypeError, ValueError):
                continue
            c.execute("INSERT OR IGNORE INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,cnt,kind,license,raw) VALUES(?,?,?,?,?,?,?,?,?,?)",
                      ("adobe", day, day + "T00:00:00", "other-chart", diff,
                       diff if wcur == "USD" else _to_usd(c, "adobe", diff, wcur, day), 0, "other", "", json.dumps({"type": "chart", "week": k, "cur": wcur})))
            days.add(day)
    c.execute("""INSERT INTO daily SELECT 'adobe', day, 'other', SUM(amount_usd), 0 FROM sales
                 WHERE agency='adobe' AND kind='other' GROUP BY day""")
    _rebuild_monthly(c, "adobe", {x[:7] for x in days | old_days if x})


# --- Shutterstock
def _ss_daily(c, d):
    """Mēneša dienu kopsummas pa kategorijām (aizstāj visu mēnesi)."""
    y, m = int(d["year"]), int(d["month"])
    month = f"{y:04d}-{m:02d}"
    c.execute("DELETE FROM daily WHERE agency='shutterstock' AND substr(day,1,7)=?", (month,))
    for day in d.get("days") or []:
        date = day.get("date")
        found = False
        for k, v in day.items():
            if isinstance(v, dict) and ("earnings" in v or "downloads" in v):
                c.execute("INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?)",
                          ("shutterstock", date, k, num(v.get("earnings")), int(num(v.get("downloads")))))
                found = True
        if not found and (num(day.get("earnings")) or num(day.get("downloads"))):
            c.execute("INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?)",
                      ("shutterstock", date, "other", num(day.get("earnings")), int(num(day.get("downloads")))))
    _rebuild_monthly(c, "shutterstock", {month})


_SS_THUMB_LOGGED = set()


def _log_thumb(agency: str, url: str | None) -> None:
    """Izpētei: vienreiz žurnālā sīktēla adreses forma (domēns, ceļa sākums, parametru nosaukumi — bez vērtībām)."""
    if not url or agency in _SS_THUMB_LOGGED:
        return
    _SS_THUMB_LOGGED.add(agency)
    from urllib.parse import urlparse, parse_qs
    u = urlparse(url)
    print(f"[{agency}] sīktēla adreses paraugs: {u.scheme}://{u.netloc}{u.path[:60]}… parametri: {sorted(parse_qs(u.query))}")


def _ss_day_media(c, d):
    """Vienas dienas pārdošanas pa bildēm (visas kategorijas kopā; aizstāj dienu)."""
    date = d["date"]
    if d.get("rows"):
        _log_thumb("shutterstock", ((d["rows"][0].get("details") or {}).get("previewImageUrl")))
    c.execute("DELETE FROM sales WHERE agency='shutterstock' AND day=?", (date,))
    for r in d.get("rows") or []:
        mid = str(r.get("mediaId") or "")
        det = r.get("details") or {}
        _upsert_asset(c, "shutterstock", mid, det.get("description"), det.get("previewImageUrl"), None,
                      f"https://www.shutterstock.com/search/{mid}" if mid else None, r.get("assetType"), r.get("uploadDate"))
        c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,cnt,kind,license,raw) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  ("shutterstock", date, date, mid, num(r.get("total")), num(r.get("total")), int(num(r.get("count")) or 1),
                   r.get("category") or "", "", None))


def _ss_totals(c, d):
    if d.get("begin"):
        c.execute("DELETE FROM totals WHERE agency='shutterstock'")
        # kopsummu momentuzņēmuma diena: pārdošanas pēc tās tiek pieskaitītas (TOTALS_SQL)
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", ("shutterstock", "totals_day", json.dumps(_today().isoformat())))
        return
    cat = d.get("category") or ""
    for r in d.get("rows") or []:
        mid = str(r.get("mediaId") or "")
        det = r.get("details") or {}
        _upsert_asset(c, "shutterstock", mid, det.get("description"), det.get("previewImageUrl"), None,
                      f"https://www.shutterstock.com/search/{mid}" if mid else None, r.get("mediaType"), r.get("uploadDate"))
        c.execute("INSERT OR REPLACE INTO totals VALUES(?,?,?,?,?)",
                  ("shutterstock", mid, cat, num(r.get("total")), int(num(r.get("count")))))


def _ss_recent(c, d):
    """Pēdējās ~20 pārdošanas: faila vārds un pircēja valsts."""
    for r in d.get("rows") or []:
        media = r.get("media") or {}
        mid = str(media.get("id") or "")
        img = media.get("cdnImage") or {}
        _upsert_asset(c, "shutterstock", mid, media.get("description"), img.get("url"), media.get("filename"))
        g = r.get("geoip") or {}
        c.execute("INSERT OR REPLACE INTO buyers VALUES(?,?,?,?,?,?)",
                  ("shutterstock", r.get("time") or "", mid, num(r.get("amount")), g.get("countryName") or g.get("countryCode") or "",
                   g.get("city") or ""))


# --- Envato
def _env_monthly(c, d):
    c.execute("DELETE FROM monthly WHERE agency IN ('envato','envato_market')")
    for r in d.get("rows") or []:
        m = str(r.get("date") or "")[:7]
        if not m:
            continue
        el, mk = num(r.get("total_earnings_elements")), num(r.get("total_earnings_market"))
        if el:
            c.execute("INSERT OR REPLACE INTO monthly VALUES(?,?,?,?,?)", ("envato", m, "elements", el, 0))
        if mk:
            c.execute("INSERT OR REPLACE INTO monthly VALUES(?,?,?,?,?)", ("envato_market", m, "market", mk, 0))


def _env_daily(c, d):
    s, e = d["start"], d["end"]
    c.execute("DELETE FROM daily WHERE agency IN ('envato','envato_market') AND day BETWEEN ? AND ?", (s, e))
    for r in d.get("rows") or []:
        day = str(r.get("date") or "")[:10]
        el, mk = num(r.get("total_earnings_elements")), num(r.get("total_earnings_market"))
        if el:
            c.execute("INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?)", ("envato", day, "elements", el, 0))
        if mk:
            c.execute("INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?)", ("envato_market", day, "market", mk, 0))


def _env_items(c, d):
    """Vienumu ienākumi vienā mēnesī (lapa pa lapai; 1. lapa notīra mēnesi). shopfront=Market → envato_market."""
    month = d["month"]
    day = month + "-01"
    ag = "envato_market" if str(d.get("shopfront") or "").lower() == "market" else "envato"
    kind = "market" if ag == "envato_market" else "elements"
    if int(d.get("page") or 1) == 1:
        c.execute("DELETE FROM sales WHERE agency=? AND day=?", (ag, day))
    for r in d.get("rows") or []:
        iid = str(r.get("item_id") or "")
        amt = num(r.get("total_earnings"))
        if not amt:
            continue
        # Market rindās "title" mēdz būt birka ("road") — vispirms īstais vienuma nosaukums (test48)
        _upsert_asset(c, ag, iid, r.get("item_name") or r.get("name") or r.get("title"),
                      r.get("thumbnail_url") or r.get("thumbnail") or r.get("preview_url") or r.get("image_url") or None, None, r.get("url"),
                      r.get("category"), r.get("published_date"))
        c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,cnt,kind,license,raw) VALUES(?,?,?,?,?,?,?,?,?,?)",
                  (ag, day, day, iid, amt, amt, int(num(r.get("sales") or r.get("sales_count") or 0)), kind, "", None))
    if d.get("last"):
        c.execute("DELETE FROM totals WHERE agency=?", (ag,))
        c.execute("""INSERT INTO totals SELECT agency, agency_item_id, ?, SUM(amount_usd), SUM(cnt) FROM sales
                     WHERE agency=? GROUP BY agency_item_id""", (kind, ag))


# --- Kopīgā ievade jaunajām aģentūrām (0.2.0): savācējs jau sagatavo vienādas formas rindas
def _to_usd(c, agency: str, amount: float, cur: str | None, day: str) -> float:
    cur = (cur or AGENCIES.get(agency, {}).get("currency") or "USD").upper()
    if cur == "USD" or not amount:
        return amount
    from . import fx
    return round(amount * fx.rate(sys.modules[__name__], cur, day or _today().isoformat()), 6)


def _thumbs(agency):
    """Tikai sīktēli esošiem (vai vēl nezināmiem) vienumiem.  d = {rows: [{id, thumb}], all?}"""
    def f(c, d):
        for r in d.get("rows") or []:
            iid, th = str(r.get("id") or ""), r.get("thumb") or ""
            if not iid or not th.startswith("http"):
                continue
            if c.execute("UPDATE assets SET thumb=? WHERE agency=? AND agency_item_id=?", (th, agency, iid)).rowcount == 0:
                _upsert_asset(c, agency, iid, thumb=th)
        if d.get("all"):
            c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "thumbs_done", "true"))
    return f


def _thumbs_title(agency):
    """Sīktēli pēc bildes nosaukuma (Envato Portfolio Manager, test48): tikai bildēm, kurām sīktēla vēl nav."""
    def f(c, d):
        n = 0
        for r in d.get("rows") or []:
            t, th = str(r.get("title") or "").strip().lower(), str(r.get("thumb") or "")
            if not th.startswith("http"):
                continue
            if r.get("id") and agency == "envato":   # test21: Envato Portfolio Manager — pilns virsraksts un oriģinālais faila nosaukums
                o = c.execute("SELECT title, thumb, filename FROM assets WHERE agency=? AND agency_item_id=?", (agency, str(r["id"]))).fetchone()
                if o:
                    full = str(r.get("title") or "").strip()
                    better = full if full and (" " in full) and " " not in str(o["title"] or "").strip() else None   # pārdošanu virsraksts ir 1 vārds (piem. "business")
                    fnm = str(r.get("filename") or "").strip()
                    # test29: agrāk sīktēls pēc virsraksta → 85 "close-up" bildēm viens (zemenes) sīktēls; ID sīktēls vienmēr pareizāks
                    if th.startswith("http") and str(o["thumb"] or "").split("?")[0] != th.split("?")[0]:
                        c.execute("UPDATE assets SET thumb=? WHERE agency=? AND agency_item_id=?", (th, agency, str(r["id"])))
                        c.execute("DELETE FROM thumb_hash WHERE agency=? AND agency_item_id=?", (agency, str(r["id"])))
                        n += 1
                    if better or (fnm and not o["filename"]):
                        _upsert_asset(c, agency, str(r["id"]), title=better, thumb=None,
                                      filename=fnm if fnm and not o["filename"] else None)
                        n += 1
                    continue
            if r.get("id"):                     # test52: pēc vienuma ID (drošāk nekā pēc nosaukuma)
                k = c.execute("UPDATE assets SET thumb=? WHERE agency=? AND agency_item_id=? AND (thumb IS NULL OR thumb NOT LIKE 'http%')",
                              (th, agency, str(r["id"]))).rowcount
                n += k
                if k:
                    continue
            if len(t) < 6:
                continue
            n += c.execute("UPDATE assets SET thumb=? WHERE agency=? AND (thumb IS NULL OR thumb NOT LIKE 'http%') AND lower(title) LIKE ?",
                           (th, agency, t.replace("%", "").replace("_", "") + "%")).rowcount
        print(f"[{agency}] sīktēli pēc nosaukuma: {n}")
    return f


def _rows(agency):
    """Pārdošanu rindas.  d = {first, last, batch? | start?+end?, currency?, derive?, rows: [
         {day, ts?, id, title?, thumb?, filename?, url?, amount, cnt?, kind?, license?, country?, raw?}]}
    first: notīra iepriekšējos datus (pēc batch vai perioda [start, end]);
    last: pārrēķina kopsummas (derive=False — dienas dati nāk atsevišķi ar 'days')."""
    def f(c, d):
        batch = d.get("batch")
        if d.get("first"):
            if batch:
                c.execute("DELETE FROM sales WHERE agency=? AND batch=?", (agency, batch))
            elif d.get("start") and d.get("end"):
                c.execute("DELETE FROM sales WHERE agency=? AND day BETWEEN ? AND ?", (agency, d["start"], d["end"]))
        cur = d.get("currency")
        for r in d.get("rows") or []:
            iid = str(r.get("id") or "")
            day = _day(r.get("day") or r.get("ts") or "")
            if not day:
                continue
            _upsert_asset(c, agency, iid, r.get("title"), r.get("thumb"), r.get("filename"), r.get("url"),
                          "other" if r.get("kind") == "other" else r.get("media"))
            amt = num(r.get("amount"))
            raw = r.get("raw")
            c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,currency,cnt,kind,license,country,raw,batch)"
                      " VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
                      (agency, day, r.get("ts") or day, iid, amt, _to_usd(c, agency, amt, cur, day),
                       (cur or AGENCIES[agency]["currency"]).upper(), int(num(r.get("cnt", 1))), r.get("kind") or "sale",
                       r.get("license") or "", r.get("country") or "", json.dumps(raw) if raw else None, batch))
        if d.get("last"):
            if d.get("derive", True):
                _derive_daily(c, agency)
            _derive_totals(c, agency)
    return f


def _derive_daily(c, agency: str):
    """Dienu un mēnešu kopsummas no pārdošanu rindām (pilns pārrēķins — dati nav lieli)."""
    c.execute("DELETE FROM daily WHERE agency=?", (agency,))
    c.execute("""INSERT INTO daily SELECT agency, day, COALESCE(NULLIF(kind,''),'sale'), SUM(amount_usd), SUM(cnt)
                 FROM sales WHERE agency=? GROUP BY day, COALESCE(NULLIF(kind,''),'sale')""", (agency,))
    c.execute("DELETE FROM monthly WHERE agency=?", (agency,))
    c.execute("""INSERT INTO monthly SELECT agency, substr(day,1,7), cat, SUM(earnings), SUM(downloads)
                 FROM daily WHERE agency=? GROUP BY substr(day,1,7), cat""", (agency,))


def _derive_totals(c, agency: str):
    c.execute("DELETE FROM totals WHERE agency=?", (agency,))
    c.execute("""INSERT INTO totals SELECT agency, agency_item_id, 'sale', SUM(amount_usd), SUM(cnt) FROM sales
                 WHERE agency=? AND kind!='other' AND agency_item_id!='' GROUP BY agency_item_id""", (agency,))


def _days(agency):
    """Dienu kopsummas.  d = {start, end, currency?, days: [{day, cat, e, n}]} — aizstāj periodu."""
    def f(c, d):
        s, e = d["start"], d["end"]
        cur = d.get("currency")
        c.execute("DELETE FROM daily WHERE agency=? AND day BETWEEN ? AND ?", (agency, s, e))
        for r in d.get("days") or []:
            day = _day(r.get("day"))
            if not day or not (num(r.get("e")) or num(r.get("n"))):
                continue
            c.execute("INSERT OR REPLACE INTO daily VALUES(?,?,?,?,?)",
                      (agency, day, r.get("cat") or "sale", _to_usd(c, agency, num(r.get("e")), cur, day), int(num(r.get("n")))))
        _rebuild_monthly(c, agency, _months_between(s, e))
    return f


def _months(agency):
    """Mēnešu kopsummas (aģentūrām bez dienu datiem).  d = {start, end (YYYY-MM), currency?, rows: [{month, cat, e, n}]}"""
    def f(c, d):
        cur = d.get("currency")
        c.execute("DELETE FROM monthly WHERE agency=? AND month BETWEEN ? AND ?", (agency, d["start"][:7], d["end"][:7]))
        for r in d.get("rows") or []:
            m = str(r.get("month") or "")[:7]
            if m and (num(r.get("e")) or num(r.get("n"))):
                c.execute("INSERT OR REPLACE INTO monthly VALUES(?,?,?,?,?)",
                          (agency, m, r.get("cat") or "sale", _to_usd(c, agency, num(r.get("e")), cur, m + "-15"), int(num(r.get("n")))))
        # aģentūras bez bildēm (Ingram): katrs mēnesis arī kā viena rinda pārdošanu sarakstā ("cits maksājums" —
        # nav piesaistīts bildei, tāpēc nerādās Labākajās)
        if agency in MONTH_ROW_TITLE:
            # 0.3.1-test21 (lietotājs 2026-11-08): katrs mēnesis — atsevišķs ieraksts "month-YYYY-MM" (ne viena kopsumma)
            c.execute("DELETE FROM sales WHERE agency=? AND day BETWEEN ? AND ?", (agency, d["start"][:7] + "-01", d["end"][:7] + "-31"))
            for r in d.get("rows") or []:
                m, e = str(r.get("month") or "")[:7], num(r.get("e"))
                iid = "month-" + m
                if m and e:
                    _upsert_asset(c, agency, iid, MONTH_ROW_TITLE[agency], None, None, None, "month")
                    c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,currency,cnt,kind,license,raw)"
                              " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                              (agency, m + "-01", m + "-01", iid, e, _to_usd(c, agency, e, cur, m + "-15"),
                               (cur or AGENCIES[agency]["currency"]).upper(), int(num(r.get("n"))), "other", "", None))
    return f


def _bal_conv(agency):
    """Atlikums; ja aģentūras valūta nav USD, glabā pārrēķinātu USD un oriģinālo summu."""
    def f(c, d):
        cur = (d.get("currency") or AGENCIES[agency]["currency"]).upper()
        amt = num(d.get("amount"))
        c.execute("INSERT OR REPLACE INTO balance VALUES(?,?,?,?)",
                  (agency, _to_usd(c, agency, amt, cur, _today().isoformat()), "USD" if cur == "USD" else f"USD ({amt:.2f} {cur})",
                   dt.datetime.now().isoformat(timespec="seconds")))
        from . import payouts
        payouts.note_balance(c, agency, amt, cur)
    return f


INGEST = {
    ("adobe", "sales"): _adobe_sales,
    ("adobe", "other"): _adobe_other,
    ("adobe", "balance"): _bal("adobe"),
    ("shutterstock", "daily"): _ss_daily,
    ("shutterstock", "day_media"): _ss_day_media,
    ("shutterstock", "totals"): _ss_totals,
    ("shutterstock", "recent"): _ss_recent,
    ("shutterstock", "balance"): _bal("shutterstock"),
    ("envato", "monthly"): _env_monthly,
    ("envato", "daily"): _env_daily,
    ("envato", "items"): _env_items,
}
for _ag in AG_ORDER:
    INGEST.setdefault((_ag, "rows"), _rows(_ag))
    INGEST.setdefault((_ag, "days"), _days(_ag))
    INGEST.setdefault((_ag, "months"), _months(_ag))
    INGEST.setdefault((_ag, "balance"), _bal_conv(_ag))
    INGEST.setdefault((_ag, "thumbs"), _thumbs(_ag))
    INGEST.setdefault((_ag, "thumbs_title"), _thumbs_title(_ag))

from .izmaksas import aprekins as _payouts  # noqa: E402  — izmaksu ievade (payouts, payout_info)
_payouts.register()


# --------------------------------------------------------------------------- jaunās pārdošanas

FRESH_DAYS = 120          # cik dienas atpakaļ salīdzina (Envato ~40 d. nobīde, iStock mēneša atskaites)


def _fresh_since() -> str:
    return (_today() - dt.timedelta(days=FRESH_DAYS)).isoformat()


def snapshot(agency: str) -> None:
    """Pirms aģentūras atjaunošanas (pirmie dati): atceramies, kas bija zināms."""
    since = _fresh_since()
    with _lock:
        c = conn()
        c.execute("DELETE FROM snap_items WHERE agency=?", (agency,))
        c.execute("DELETE FROM snap_days WHERE agency=?", (agency,))
        c.execute("""INSERT INTO snap_items SELECT agency, agency_item_id, day, SUM(cnt), SUM(amount_usd) FROM sales
                     WHERE agency=? AND kind!='other' AND day>=? GROUP BY agency_item_id, day""", (agency, since))
        c.execute("""INSERT INTO snap_days SELECT agency, day, SUM(earnings), SUM(downloads) FROM daily
                     WHERE agency=? AND day>=? GROUP BY day""", (agency, since))
        # pirmā ielāde (vēl nekad nav atjaunots) — tad "jaunas" ir viss, un nekas netiek izcelts
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)",
                  (agency, "snap", json.dumps({"first": not get_state(agency, "last_ok"),
                                               "at": dt.datetime.now().isoformat(timespec="seconds")})))
        c.commit()


def clear_fresh() -> None:
    """Jauna atjaunošanas reize: iepriekšējās "jaunās" pārdošanas visām aģentūrām kļūst parastas."""
    with _lock:
        c = conn()
        c.execute("DELETE FROM fresh")
        c.execute("DELETE FROM state WHERE key='fresh'")
        c.commit()


def mark_fresh(agency: str) -> dict:
    """Pēc veiksmīgas atjaunošanas: kas nāca klāt kopš momentuzņēmuma. Iepriekšējās "jaunās" kļūst parastas."""
    since = _fresh_since()
    snap = get_state(agency, "snap") or {}
    with _lock:
        c = conn()
        c.execute("DELETE FROM fresh WHERE agency=?", (agency,))
        res = {"e": 0.0, "n": 0, "items": 0, "at": dt.datetime.now().isoformat(timespec="seconds")}
        if snap and not snap.get("first"):
            c.execute("""INSERT INTO fresh
                SELECT s.agency, s.agency_item_id, s.day,
                       SUM(s.cnt) - COALESCE(MAX(p.cnt), 0), SUM(s.amount_usd) - COALESCE(MAX(p.amt), 0)
                FROM sales s LEFT JOIN snap_items p ON p.agency=s.agency AND p.item=s.agency_item_id AND p.day=s.day
                WHERE s.agency=? AND s.kind!='other' AND s.day>=? AND s.agency_item_id!=''
                GROUP BY s.agency_item_id, s.day
                HAVING SUM(s.cnt) > COALESCE(MAX(p.cnt), 0)
                    OR (SUM(s.cnt) = COALESCE(MAX(p.cnt), 0) AND SUM(s.amount_usd) > COALESCE(MAX(p.amt), 0) + 0.005)""",
                      (agency, since))
            # kopsumma pa dienām (arī aģentūrām, kas dod tikai dienu summas)
            d = c.execute("""SELECT SUM(e) e, SUM(n) n FROM (
                    SELECT d.day, SUM(d.earnings) - COALESCE(MAX(p.e), 0) e, SUM(d.downloads) - COALESCE(MAX(p.n), 0) n
                    FROM daily d LEFT JOIN snap_days p ON p.agency=d.agency AND p.day=d.day
                    WHERE d.agency=? AND d.day>=? GROUP BY d.day) WHERE e > 0.005 OR n > 0""", (agency, since)).fetchone()
            res["e"] = round(max(0.0, d["e"] or 0), 2)
            res["n"] = max(0, int(d["n"] or 0))
            res["items"] = c.execute("SELECT COUNT(*) FROM fresh WHERE agency=?", (agency,)).fetchone()[0]
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "fresh", json.dumps(res)))
        c.commit()
    return res


def fresh_summary() -> dict:
    by = {}
    for a in AG_ORDER:
        f = get_state(a, "fresh")
        if f and (f.get("e") or f.get("n") or f.get("items")):
            by[a] = f
    return {"e": round(sum(v.get("e", 0) for v in by.values()), 2), "n": sum(v.get("n", 0) for v in by.values()), "by": by}


def _flag_fresh(rows: list[dict]) -> None:
    """Atzīmē jaunās rindas (rows jau sakārtotas no jaunākās). Ja dienā vairākas pārdošanas un jaunas tikai
    daļa — atzīmē jaunākās."""
    keys = {(r["agency"], r["agency_item_id"], r["day"]) for r in rows}
    if not keys:
        return
    left = {}
    for f in q("SELECT agency, item, day, cnt FROM fresh"):
        k = (f["agency"], f["item"], f["day"])
        if k in keys:
            left[k] = max(1, f["cnt"] or 0)
    for r in rows:
        k = (r["agency"], r["agency_item_id"], r["day"])
        if left.get(k, 0) > 0 and r.get("kind") != "other":
            r["fresh"] = True
            left[k] -= max(1, r.get("cnt") or 1)


# --------------------------------------------------------------------------- bilžu apvienošana starp aģentūrām

def regroup() -> int:
    """Piešķir assets.gid: viena un tā pati bilde dažādās aģentūrās (pēc faila nosaukuma vai virsraksta).
    Apvieno TIKAI dažādu aģentūru vienumus — vienā grupā katra aģentūra ne vairāk kā vienreiz
    (sērijas ar vienādu virsrakstu vienā aģentūrā netiek saskaitītas kopā)."""
    with _lock:
        c = conn()
        # mtag — Microstockr "viena bilde vairākās aģentūrās" (importēts; lietotāja pārbaudīta sasaiste — pirmā)
        # man — lietotāja "Apvienot / Atdalīt" (noteicošā; šie vienumi citās sasaistēs nepiedalās);
        # auto — pēc sīktēla izskata (lookalike.py)
        rows = c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, a.fkey, l.tag mtag, im.key man, ia.key auto FROM assets a
                            LEFT JOIN mr_link l ON l.agency=a.agency AND l.agency_item_id=a.agency_item_id
                            LEFT JOIN img_link im ON im.agency=a.agency AND im.agency_item_id=a.agency_item_id AND im.src='man'
                            LEFT JOIN img_link ia ON ia.agency=a.agency AND ia.agency_item_id=a.agency_item_id AND ia.src='auto'""").fetchall()
        # atslēga, kas vienā aģentūrā atkārtojas (sērija), šīs aģentūras vienumus nesasaista — citas aģentūras gan
        amb = {"mtag": set(), "man": set(), "auto": set()}
        for col in ("fkey", "mkey"):
            amb[col] = {(r[0], r[1]) for r in c.execute(
                f"SELECT {col}, agency FROM assets WHERE {col} IS NOT NULL GROUP BY {col}, agency HAVING COUNT(*)>1")}
        parent, ags = {}, {}

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for r in rows:
            k = (r["agency"], r["agency_item_id"])
            parent[k] = k
            ags[k] = {r["agency"]}
        # secība: lietotāja, Microstockr, sīktēla izskats, faila nosaukums (drošāks), tad virsraksts
        # (Microstockr tag vairs tieši neapvieno — tajā var būt vairāki vienas sērijas kadri; to izšķir lookalike.py pēc nospieduma)
        for col in ("man", "auto", "fkey", "mkey"):
            first = {}
            for r in rows:
                v = r[col]
                if not v or (v, r["agency"]) in amb[col]:
                    continue
                if col != "man" and r["man"]:      # lietotājs jau izlēma par šo vienumu
                    continue
                k = (r["agency"], r["agency_item_id"])
                if v not in first:
                    first[v] = k
                    continue
                a, b = find(first[v]), find(k)
                if a != b and (col == "man" or not (ags[a] & ags[b])):
                    parent[b] = a
                    ags[a] |= ags[b]
        upd = []
        for r in rows:
            k = (r["agency"], r["agency_item_id"])
            root = find(k)
            upd.append(("|".join(root), r["agency"], r["agency_item_id"]))
        c.executemany("UPDATE assets SET gid=? WHERE agency=? AND agency_item_id=?", upd)
        c.commit()
        return len(upd)


def fix_market() -> None:
    """0.3.0: Envato Market ienākumi agrāk bija aģentūrā envato (kategorija market) → envato_market."""
    try:
        with _lock:
            c = conn()
            n = c.execute("UPDATE daily SET agency='envato_market' WHERE agency='envato' AND cat='market'").rowcount
            n += c.execute("UPDATE monthly SET agency='envato_market' WHERE agency='envato' AND cat='market'").rowcount
            if n and not get_state("envato_market", "last_ok"):
                last = get_state("envato", "last_ok")
                if last:
                    c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", ("envato_market", "last_ok", json.dumps(last)))
            c.commit()
    except sqlite3.DatabaseError as e:
        print("fix_market:", e)


def fix_orphans() -> None:
    """0.3.1-test19: lieki aktīvi — ID "null"/"undefined"/tukšs (agrākas kļūdas) un aktīvi bez nosaukuma, sīktēla,
    pārdošanām un atsaucēm (Pond5 10 gab., lietotājs 2026-11-08). Vienreiz."""
    try:
        if not get_state("", "month_split_v1"):     # test21: Ingram "month" → "month-YYYY-MM"
            with _lock:
                c = conn()
                for ag, title in MONTH_ROW_TITLE.items():
                    for (m,) in c.execute("SELECT DISTINCT substr(day,1,7) FROM sales WHERE agency=? AND agency_item_id='month'", (ag,)).fetchall():
                        _upsert_asset(c, ag, "month-" + m, title, None, None, None, "month")
                    c.execute("UPDATE sales SET agency_item_id='month-'||substr(day,1,7) WHERE agency=? AND agency_item_id='month'", (ag,))
                    c.execute("DELETE FROM assets WHERE agency=? AND agency_item_id='month'", (ag,))
                    c.execute("DELETE FROM collection_items WHERE agency=? AND agency_item_id='month'", (ag,))
                c.commit()
            set_state("", "month_split_v1", True)
        if get_state("", "orphans_v1"):
            return
        with _lock:
            c = conn()
            n = c.execute("DELETE FROM assets WHERE agency_item_id IN ('null','undefined','') AND NOT EXISTS "
                          "(SELECT 1 FROM sales s WHERE s.agency=assets.agency AND s.agency_item_id=assets.agency_item_id)").rowcount
            n += c.execute("""DELETE FROM assets WHERE COALESCE(title,'')='' AND COALESCE(thumb,'')='' AND COALESCE(filename,'')=''
                AND NOT EXISTS (SELECT 1 FROM sales s WHERE s.agency=assets.agency AND s.agency_item_id=assets.agency_item_id)
                AND NOT EXISTS (SELECT 1 FROM totals t WHERE t.agency=assets.agency AND t.agency_item_id=assets.agency_item_id)
                AND NOT EXISTS (SELECT 1 FROM sub_status u WHERE u.agency=assets.agency AND u.item_id=assets.agency_item_id)""").rowcount
            c.commit()
        set_state("", "orphans_v1", True)
        print(f"lieki aktīvi izdzēsti: {n}")
    except Exception as e:
        print("fix_orphans:", e)


def fix_month_rows() -> None:
    """0.3.0: aģentūrām bez bildēm (Ingram) mēneši arī pārdošanu sarakstā — no jau saglabātajām mēnešu summām
    (USD; nākamā atjaunošana tās aizstās ar oriģinālās valūtas summām)."""
    try:
        with _lock:
            c = conn()
            for ag, title in MONTH_ROW_TITLE.items():
                if c.execute("SELECT 1 FROM sales WHERE agency=? LIMIT 1", (ag,)).fetchone():
                    continue
                rows = c.execute("SELECT month, SUM(earnings) e, SUM(downloads) n FROM monthly WHERE agency=? GROUP BY month", (ag,)).fetchall()
                if not rows:
                    continue
                for m, e, n in rows:
                    if e:
                        _upsert_asset(c, ag, "month-" + m, title, None, None, None, "month")
                        c.execute("INSERT INTO sales(agency,day,sold_at,agency_item_id,amount,amount_usd,currency,cnt,kind,license,raw)"
                                  " VALUES(?,?,?,?,?,?,?,?,?,?,?)", (ag, m + "-01", m + "-01", "month-" + m, e, e, "USD", int(n or 0), "other", "", None))
            c.commit()
    except sqlite3.DatabaseError as e:
        print("fix_month_rows:", e)


def fix_other() -> None:
    """Depositphotos "RSM Subscription" (Revenue Share Program — abonementu ieņēmumu daļa) agrāk bija saglabāts
    kā bildes pārdošana; tagad tas ir "cits maksājums" (vienots vienums other-rsm)."""
    try:
        with _lock:
            c = conn()
            ids = [r[0] for r in c.execute("SELECT agency_item_id FROM assets WHERE agency='depositphotos' "
                                           "AND agency_item_id!='other-rsm' AND filename LIKE 'RSM%'")]
            if not ids:
                return
            _upsert_asset(c, "depositphotos", "other-rsm", DP_RSM_TITLE, None, None, None, "other")
            for iid in ids:
                c.execute("UPDATE sales SET kind='other', agency_item_id='other-rsm', cnt=0 WHERE agency='depositphotos' AND agency_item_id=?", (iid,))
                c.execute("DELETE FROM assets WHERE agency='depositphotos' AND agency_item_id=?", (iid,))
            _derive_daily(c, "depositphotos")
            _derive_totals(c, "depositphotos")
            c.commit()
    except sqlite3.DatabaseError as e:
        print("fix_other:", e)


DP_RSM_TITLE = "Depositphotos — RSM (abonementu ieņēmumu daļa)"


def ensure_groups():
    try:
        if q1("SELECT 1 FROM assets WHERE gid IS NULL LIMIT 1"):
            regroup()
    except sqlite3.DatabaseError:
        pass


def _thumb_for(gid: str | None, exclude: str | None = None) -> str | None:
    """Sīktēls no tās pašas bildes citā aģentūrā (exclude — jau zināmais, kas varbūt neielādējas)."""
    if not gid:
        return None
    r = q1("SELECT thumb FROM assets WHERE gid=? AND thumb IS NOT NULL AND thumb!='' AND thumb!=? LIMIT 1", (gid, exclude or ""))
    return r["thumb"] if r else None


# --------------------------------------------------------------------------- vaicājumi

def _today() -> dt.date:
    return dt.date.today()


def _sum_daily(a: str, b: str, agencies=None) -> dict:
    where, args = "day BETWEEN ? AND ?", [a, b]
    if agencies:
        where += f" AND agency IN ({','.join('?' * len(agencies))})"
        args += list(agencies)
    rows = q(f"SELECT agency, SUM(earnings) e, SUM(downloads) n FROM daily WHERE {where} GROUP BY agency", args)
    by = {r["agency"]: {"e": round(r["e"] or 0, 2), "n": int(r["n"] or 0)} for r in rows}
    return {"e": round(sum(v["e"] for v in by.values()), 2), "n": sum(v["n"] for v in by.values()), "by": by}


def _sum_months(a: str, b: str) -> dict:
    rows = q("SELECT agency, SUM(earnings) e, SUM(downloads) n FROM monthly WHERE month BETWEEN ? AND ? GROUP BY agency", (a, b))
    by = {r["agency"]: {"e": round(r["e"] or 0, 2), "n": int(r["n"] or 0)} for r in rows}
    return {"e": round(sum(v["e"] for v in by.values()), 2), "n": sum(v["n"] for v in by.values()), "by": by}


def connected() -> list[str]:
    return [a for a in AG_ORDER if get_state(a, "last_ok")]


def overview() -> dict:
    t = _today()
    iso = t.isoformat()
    month0 = t.replace(day=1)
    year0 = t.replace(month=1, day=1)
    prev_m_end = month0 - dt.timedelta(days=1)
    prev_m0 = prev_m_end.replace(day=1)
    same_day_prev = prev_m0 + dt.timedelta(days=min(t.day, prev_m_end.day) - 1)
    days_in_month = ((month0 + dt.timedelta(days=32)).replace(day=1) - month0).days

    cards = {
        "today": _sum_daily(iso, iso),
        "yesterday": _sum_daily((t - dt.timedelta(days=1)).isoformat(), (t - dt.timedelta(days=1)).isoformat()),
        # kalendārā nedēļa no pirmdienas (lietotājs 2026-10-31; mēnesis un gads jau ir kalendārie)
        "week": _sum_daily((t - dt.timedelta(days=t.weekday())).isoformat(), iso),
        "month": _sum_daily(month0.isoformat(), iso),
        "prev_month_same": _sum_daily(prev_m0.isoformat(), same_day_prev.isoformat()),
        "prev_month": _sum_months(prev_m0.isoformat()[:7], prev_m0.isoformat()[:7]),
        "year": _sum_months(year0.isoformat()[:7], iso[:7]),
        "all": _sum_months("0000-00", "9999-99"),
    }
    # mēneša prognoze: aģentūras bez nobīdes — pēc šī mēneša tempa; ar nobīdi — pēc pagājušā mēneša
    live = [a for a in AG_ORDER if not AGENCIES[a]["lag"]]
    mt = sum(cards["month"]["by"].get(a, {}).get("e", 0) for a in live)
    lagged = sum(v.get("e", 0) for a, v in cards["prev_month"]["by"].items() if AGENCIES.get(a, {}).get("lag"))
    cards["forecast"] = round((mt / t.day * days_in_month if t.day else 0) + lagged, 2)
    bal = [dict(r) for r in q("SELECT * FROM balance")]
    from . import payouts as _po   # 2026-11-07: Depositphotos "Balance" ietver pieprasīto, vēl nesaņemto izmaksu — atņemam
    for b in bal:
        _pr = _po.pending_req(b["agency"])
        if _pr and b.get("amount") is not None:
            b["amount"] = round(max(0.0, b["amount"] - _pr), 2)
    ags = []
    for a in AG_ORDER:
        info = dict(AGENCIES[a])
        info.update(id=a, last_ok=get_state(a, "last_ok"), last_try=get_state(a, "last_try"),
                    last_err=get_state(a, "last_err"), full=bool(get_state(a, "full_done")))
        last = q1("SELECT MAX(day) d FROM daily WHERE agency=?", (a,))
        lm = q1("SELECT MAX(month) m FROM monthly WHERE agency=?", (a,))
        info["last_day"] = (last["d"] if last else None) or ((lm["m"] + "-01") if lm and lm["m"] else None)
        info["fresh_until"] = fresh_until(a)
        ags.append(info)
    return {"today": iso, "cards": cards, "balance": bal, "fresh": fresh_summary(),
            "balance_total": round(sum(b["amount"] or 0 for b in bal), 2), "agencies": ags}


def fresh_until(agency: str) -> str | None:
    """Līdz kuram brīdim aģentūras dati skaitās svaigi (ISO) — vai None (atjaunošanas biežums: freshness.py)."""
    from . import freshness
    return freshness.fresh_until(agency)


def chart(view: str, year: int, month: int | None = None) -> dict:
    """view=month: dienas izvēlētajā mēnesī; view=year: mēneši gadā; view=all: gadi."""
    series = {}
    if view == "month":
        m = f"{year:04d}-{month:02d}"
        rows = q("SELECT agency, day k, SUM(earnings) e, SUM(downloads) n FROM daily WHERE substr(day,1,7)=? GROUP BY agency, day", (m,))
        first = dt.date(year, month, 1)
        nd = ((first + dt.timedelta(days=32)).replace(day=1) - first).days
        keys = [f"{m}-{d:02d}" for d in range(1, nd + 1)]
        # aģentūras, kurām šim mēnesim ir tikai mēneša kopsumma (bez dienām)
        only_m = q("""SELECT agency, SUM(earnings) e, SUM(downloads) n FROM monthly WHERE month=?
                      AND agency NOT IN (SELECT DISTINCT agency FROM daily WHERE substr(day,1,7)=?) GROUP BY agency""", (m, m))
        monthly_only = {r["agency"]: [round(r["e"] or 0, 2), int(r["n"] or 0)] for r in only_m if r["e"] or r["n"]}
    elif view == "year":
        rows = q("SELECT agency, month k, SUM(earnings) e, SUM(downloads) n FROM monthly WHERE substr(month,1,4)=? GROUP BY agency, month",
                 (f"{year:04d}",))
        keys = [f"{year:04d}-{m:02d}" for m in range(1, 13)]
        monthly_only = {}
    else:
        rows = q("SELECT agency, substr(month,1,4) k, SUM(earnings) e, SUM(downloads) n FROM monthly GROUP BY agency, substr(month,1,4)")
        ys = sorted({r["k"] for r in rows}) or [str(_today().year)]
        keys = [str(y) for y in range(int(ys[0]), max(int(ys[-1]), _today().year) + 1)]
        monthly_only = {}
    for r in rows:
        series.setdefault(r["agency"], {})[r["k"]] = [round(r["e"] or 0, 2), int(r["n"] or 0)]
    tot_e = sum(v[0] for s in series.values() for v in s.values()) + sum(v[0] for v in monthly_only.values())
    tot_n = sum(v[1] for s in series.values() for v in s.values()) + sum(v[1] for v in monthly_only.values())
    return {"view": view, "keys": keys, "series": series, "total": {"e": round(tot_e, 2), "n": tot_n},
            "monthly_only": monthly_only, "agencies": [a for a in AG_ORDER if a in series or a in monthly_only]}


def _period(period: str) -> tuple[str, str] | None:
    t = _today()
    if period == "month":
        return t.replace(day=1).isoformat(), t.isoformat()
    if period == "30d":
        return (t - dt.timedelta(days=29)).isoformat(), t.isoformat()
    if period == "year":
        return t.replace(month=1, day=1).isoformat(), t.isoformat()
    if period == "12m":
        return (t - dt.timedelta(days=365)).isoformat(), t.isoformat()
    if re.fullmatch(r"\d{4}", period or ""):
        return f"{period}-01-01", f"{period}-12-31"
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", period or ""):                          # viena diena
        return period, period
    m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})\.\.(\d{4}-\d{2}-\d{2})", period or "")  # laika intervāls
    if m:
        return tuple(sorted((m.group(1), m.group(2))))
    if re.fullmatch(r"\d{4}-\d{2}", period or ""):
        y, m = int(period[:4]), int(period[5:])
        first = dt.date(y, m, 1)
        last = (first + dt.timedelta(days=32)).replace(day=1) - dt.timedelta(days=1)
        return first.isoformat(), last.isoformat()
    return None   # visa vēsture


TWENTY20_TO = "2022-08"      # Envato nopirka Twenty20; Envato atskaitē mēneši līdz šim = Twenty20 (vispārīgs fakts, ne lietotāja dati)


def _other_label(agency: str, title: str | None, lic: str | None) -> str:
    t = (title or lic or "").strip()
    nm = AGENCIES.get(agency, {}).get("name", agency)
    for p in (nm + " — ", nm + " - "):
        if t.startswith(p):
            t = t[len(p):]
    return t                       # tukšs → saskarne raksta "citi ienākumi" izvēlētajā valodā


def explain() -> dict:
    """Pārskata "Visā vēsturē" (aģentūru mēnešu kopsummas) = pārdošanas par bildēm + citi ienākumi (nav par bildi)
    + mēneši tikai ar kopsummu (bez sadalījuma pa bildēm) + nesakritība (lietotājs 2026-10-30 23:05/23:13).
    Vienādība izpildās vienmēr; der jebkuram lietotājam (nekas nav ierakstīts ar roku)."""
    T: dict = {}
    for r in q("SELECT agency, month, SUM(earnings) e FROM monthly GROUP BY agency, month"):
        T.setdefault(r["agency"], {})[r["month"][:7]] = r["e"] or 0
    S: dict = {}
    for r in q("SELECT agency, substr(day,1,7) m, SUM(amount_usd) e FROM sales WHERE kind!='other' GROUP BY agency, m"):
        S.setdefault(r["agency"], {})[r["m"]] = r["e"] or 0
    O: dict = {}            # agency -> month -> summa
    types: dict = {}        # (agency, label) -> {e, n, from, to}

    def add_o(ag, m, lab, e, n):
        O.setdefault(ag, {})[m] = O.get(ag, {}).get(m, 0) + e
        x = types.setdefault((ag, lab), {"agency": ag, "label": lab, "e": 0.0, "n": 0, "from": m, "to": m})
        x["e"] += e
        x["n"] += n
        x["from"], x["to"] = min(x["from"], m), max(x["to"], m)

    for r in q("""SELECT s.agency, substr(s.day,1,7) m, s.agency_item_id iid, a.title, s.license, SUM(s.amount_usd) e, COUNT(*) n
                  FROM sales s LEFT JOIN assets a ON a.agency=s.agency AND a.agency_item_id=s.agency_item_id
                  WHERE s.kind='other' GROUP BY s.agency, m, s.agency_item_id, a.title, s.license"""):
        if r["agency"] in MONTH_ROW_TITLE and str(r["iid"]).startswith("month"):
            continue                                    # Ingram: mēneša kopsumma, nevis "cits ienākums"
        add_o(r["agency"], r["m"], _other_label(r["agency"], r["title"], r["license"]), r["e"] or 0, r["n"])
    for r in q("SELECT agency, cat, substr(day,1,7) m, SUM(earnings) e FROM daily GROUP BY agency, cat, m"):
        lab = _other_cat(r["agency"], r["cat"])
        if lab and (r["e"] or 0):
            add_o(r["agency"], r["m"], lab, r["e"], 0)
    rows = []
    for ag in sorted(set(T) | set(S) | set(O)):
        tm, sm, om = T.get(ag, {}), S.get(ag, {}), O.get(ag, {})
        only = [m for m in tm if abs(sm.get(m, 0)) < 0.005 and abs(om.get(m, 0)) < 0.005 and abs(tm[m]) >= 0.005]
        only_e = sum(tm[m] for m in only)
        t20 = [m for m in only if ag == "envato" and m <= TWENTY20_TO]
        total, sale, oth = sum(tm.values()), sum(sm.values()), sum(om.values())
        rest = total - sale - oth - only_e
        only_rest = sorted(set(only) - set(t20))
        rows.append({"agency": ag, "total": round(total, 2), "sale": round(sale, 2), "other": round(oth, 2),
                     "only": round(only_e, 2), "only_n": len(only_rest), "only_e": round(sum(tm[m] for m in only_rest), 2),
                     "only_from": only_rest[0] if only_rest else None, "only_to": only_rest[-1] if only_rest else None,
                     "t20": round(sum(tm[m] for m in t20), 2), "t20_n": len(t20),
                     "t20_from": min(t20) if t20 else None, "t20_to": max(t20) if t20 else None, "rest": round(rest, 2)})
    rows.sort(key=lambda r: -r["total"])
    tl = sorted(({**v, "e": round(v["e"], 2)} for v in types.values() if abs(v["e"]) >= 0.005), key=lambda v: -v["e"])
    k = ("total", "sale", "other", "only", "rest")
    return {"rows": rows, "types": tl, **{x: round(sum(r[x] for r in rows), 2) for x in k}}


def coverage(period: str = "", agency: str = "", monthly: bool = False) -> dict:
    """Pārdošanās: Pārskata summa (aģentūru mēnešu kopsummas) pret sarakstu (tikai pārdošanas par bildēm)."""
    rng = _period(period) if period and period != "all" else None
    m0, m1 = (rng[0][:7], rng[1][:7]) if rng else ("0000-00", "9999-99")
    d0, d1 = (rng[0], rng[1]) if rng else ("0000-00-00", "9999-99-99")
    w, a = ("AND agency=?", (agency,)) if agency else ("", ())
    t_e = q1(f"SELECT SUM(earnings) e FROM monthly WHERE month BETWEEN ? AND ? {w}", (m0, m1) + a)["e"] or 0
    s_e = q1(f"SELECT SUM(amount_usd) e FROM sales WHERE kind!='other' AND day BETWEEN ? AND ? {w}", (d0, d1) + a)["e"] or 0
    return {"total": round(t_e, 2), "list": round(s_e, 2)}


def feed(agency: str = "", offset: int = 0, limit: int = 80, search: str = "", start: str = "", end: str = "",
         period: str = "", monthly: bool = False, kind: str = "", ed: str = "", ed_split: bool = False) -> dict:
    """Pārdošanu plūsma. Envato Elements (mēneša ienākumi pa vienumiem) — tikai, ja monthly vai izvēlēta aģentūra envato.
    kind: "" — viss, "sale" — tikai bilžu pārdošanas, "other" — tikai citi maksājumi (sk. other_feed)."""
    if period and period != "all":
        rng = _period(period)
        if rng:
            start, end = rng
    if kind == "other":
        return other_feed(agency, start, end, offset, limit)
    where, args = [], []
    if kind == "sale":
        where.append("s.kind!='other'")
    if ed in ("rf", "ed") or ed_split:              # Beta RF/ED (ed.py)
        from . import ed as _ed
        _ed.refresh()
    if ed in ("rf", "ed"):
        where.append("EXISTS(SELECT 1 FROM ed_cls e WHERE e.agency=s.agency AND e.agency_item_id=s.agency_item_id AND e.ed=?)")
        args.append(1 if ed == "ed" else 0)
    # test50: Envato/Ingram mēneša ienākumi pa bildēm ir sarakstā vienmēr (ar mēneša nosaukumu) — "Visi ienākumi" = visi
    if agency:
        where.append("s.agency=?")
        args.append(agency)
    if start:
        where.append("s.day>=?")
        args.append(start)
    if end:
        where.append("s.day<=?")
        args.append(end)
    if search:
        where.append("(a.title LIKE ? OR a.filename LIKE ? OR printf('%.2f', s.amount) LIKE ?)")
        args += [f"%{search}%", f"%{search}%", f"{search.lstrip('$€')}%"]
    w = " AND ".join(where) or "1=1"
    base = f"FROM sales s LEFT JOIN assets a ON a.agency=s.agency AND a.agency_item_id=s.agency_item_id WHERE {w}"
    tot = q1(f"SELECT COUNT(*) c, SUM(s.amount_usd) e, SUM(s.cnt) n, COUNT(DISTINCT s.agency||s.agency_item_id) f {base}", args)
    split = None
    if ed_split:
        split = {"rf": 0.0, "ed": 0.0}
        for r in q(f"""SELECT COALESCE(e.ed,0) k, SUM(s.amount_usd) v FROM sales s
                       LEFT JOIN assets a ON a.agency=s.agency AND a.agency_item_id=s.agency_item_id
                       LEFT JOIN ed_cls e ON e.agency=s.agency AND e.agency_item_id=s.agency_item_id WHERE {w} GROUP BY k""", args):
            split["ed" if r["k"] else "rf"] += round(r["v"] or 0, 2)
    rows = q(f"""SELECT s.agency, s.day, s.sold_at, s.agency_item_id, s.amount, s.amount_usd, s.currency, s.cnt, s.kind,
                        s.license, s.raw, a.title, a.thumb, a.filename, a.url, a.gid, a.media
                 {base} ORDER BY s.day DESC, s.sold_at DESC, s.id DESC LIMIT ? OFFSET ?""", args + [limit, offset])
    out = []
    for r in rows:
        r = dict(r)
        if not r["thumb"]:
            r["thumb"] = _thumb_for(r["gid"])
        r["alt"] = _thumb_for(r["gid"], r["thumb"]) if r["thumb"] else None   # rezerve, ja sīktēls neielādējas
        raw = r.pop("raw", None)
        if raw:
            try:
                r["q"] = (json.loads(raw) or {}).get("q")      # Dreamstime: pircēja meklēšanas vārdi
            except (TypeError, ValueError, AttributeError):
                pass
        out.append(r)
    # "1. pārdošana": vienuma pirmā pārdošana šajā aģentūrā
    for r in out:
        if r["kind"] == "other":
            continue
        f = q1("SELECT MIN(day) d FROM sales WHERE agency=? AND agency_item_id=? AND kind!='other'", (r["agency"], r["agency_item_id"]))
        r["first"] = bool(f and f["d"] == r["day"] and _full(r["agency"]))
    _flag_fresh(out)
    return {"rows": out, "count": tot["c"] or 0, "earnings": round(tot["e"] or 0, 2), "downloads": tot["n"] or 0,
            "files": tot["f"] or 0, "offset": offset, "limit": limit, "ed_split": split}


# Citi maksājumi, kas aģentūrās ir tikai dienu/mēnešu kopsummās (bez bildēm)
OTHER_CATS = {"123rf": {"ai_ml_deals": "AI / ML darījumi", "others": "citi ienākumi"}}
_OTHER_CAT_RE = re.compile(r"pool|licens|dataset|data_|ai_|_ai", re.I)      # Shutterstock: datu licencēšana u.c.


def _other_cat(agency: str, cat: str) -> str | None:
    if cat in OTHER_CATS.get(agency, {}):
        return OTHER_CATS[agency][cat]
    if agency == "shutterstock" and _OTHER_CAT_RE.search(cat or ""):
        return cat.replace("_", " ")
    return None


def other_feed(agency: str = "", start: str = "", end: str = "", offset: int = 0, limit: int = 80) -> dict:
    """Tikai citi maksājumi: atsevišķās rindas (Adobe "Other payments", Depositphotos RSM, Pond5 vienreizējie …)
    + mēnešu kopsummas tām kategorijām, kas aģentūrā ir tikai kopsummās (123RF AI/ML, Shutterstock datu licencēšana)."""
    a, b = start or "0000-00-00", end or "9999-99-99"
    rows = []
    for r in q("""SELECT s.agency, s.day, s.sold_at, s.agency_item_id, s.amount, s.amount_usd, s.currency, s.cnt, s.kind,
                         s.license, a.title, a.thumb, a.filename, a.url, a.gid, a.media
                  FROM sales s LEFT JOIN assets a ON a.agency=s.agency AND a.agency_item_id=s.agency_item_id
                  WHERE s.kind='other' AND s.day BETWEEN ? AND ?""" + (" AND s.agency=?" if agency else ""),
               (a, b, agency) if agency else (a, b)):
        if r["agency"] in MONTH_ROW_TITLE and str(r["agency_item_id"]).startswith("month"):
            continue
        rows.append(dict(r))
    for r in q("""SELECT agency, cat, substr(day,1,7) m, MAX(day) d, SUM(earnings) e FROM daily
                  WHERE day BETWEEN ? AND ?""" + (" AND agency=?" if agency else "") + " GROUP BY agency, cat, m",
               (a, b, agency) if agency else (a, b)):
        lab = _other_cat(r["agency"], r["cat"])
        if not lab or not (r["e"] or 0):
            continue
        rows.append({"agency": r["agency"], "day": r["d"], "sold_at": r["d"], "agency_item_id": "cat-" + r["cat"],
                     "amount": round(r["e"], 2), "amount_usd": round(r["e"], 2), "currency": "USD", "cnt": 0, "kind": "other",
                     "license": "", "title": f"{AGENCIES.get(r['agency'], {}).get('name', r['agency'])} — {lab}",
                     "thumb": None, "filename": None, "url": None, "gid": None, "media": "other", "monthly": True})
    rows.sort(key=lambda x: (x["day"] or "", x["sold_at"] or ""), reverse=True)
    for r in rows:
        r["alt"] = None
        r["first"] = False
    page = rows[offset:offset + limit]
    return {"rows": page, "count": len(rows), "earnings": round(sum(r["amount_usd"] or 0 for r in rows), 2), "downloads": 0,
            "files": len({(r["agency"], r["agency_item_id"]) for r in rows}), "offset": offset, "limit": limit}


FIRST_SALE_AGENCIES = {"adobe", "istock", "alamy", "dreamstime", "depositphotos", "bigstock", "pond5", "123rf"}


def _full(agency: str) -> bool:
    """'1. pārdošana' var droši rādīt tikai, ja ielādēta visa vēsture ar katru pārdošanu atsevišķi."""
    return agency in FIRST_SALE_AGENCIES and bool(get_state(agency, "full_done"))


def best(period: str = "all", agency: str = "", group: bool = True, offset: int = 0, limit: int = 48,
         search: str = "", sort: str = "e", include_other: bool = False, only_other: bool = False,
         coll: int = 0) -> dict:
    ensure_groups()
    rng = _period(period)
    args: list = []
    if only_other:
        include_other = True
        src = "SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE kind='other'"
        if rng:
            src += " AND day BETWEEN ? AND ?"
            args += list(rng)
        src += " GROUP BY agency, agency_item_id"
    elif rng is None:
        # visa vēsture: kopsummas (totals), bet ja tur vienuma vēl nav vai tās ir mazākas (piem. Shutterstock
        # kopsummu ielāde nav pabeigta) — pārdošanu summa
        oth = "" if include_other else " WHERE kind!='other'"
        src = f"""SELECT agency, agency_item_id, MAX(e) e, MAX(n) n FROM (
                    {TOTALS_SQL.format(oth=oth.replace("WHERE", "AND"))}
                    UNION ALL
                    SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales{oth} GROUP BY agency, agency_item_id)
                  GROUP BY agency, agency_item_id"""
    else:
        src = "SELECT agency, agency_item_id, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE day BETWEEN ? AND ?"
        args += list(rng)
        if not include_other:
            src += " AND kind!='other'"
        src += " GROUP BY agency, agency_item_id"
    where = ["1=1"]
    if agency:
        where.append("t.agency=?")
        args.append(agency)
    if not include_other:
        where.append("t.agency_item_id NOT LIKE 'other-%'")
    if search:
        where.append("(a.title LIKE ? OR a.filename LIKE ?)")
        args += [f"%{search}%", f"%{search}%"]
    gkey = "COALESCE(a.gid, t.agency||'|'||t.agency_item_id)" if group else "t.agency||'|'||t.agency_item_id"
    if coll:                                       # kolekcija: bildes, kuru grupa (visas kopijas) ir kolekcijā
        from . import colls
        where.append(colls.filter_sql("COALESCE(a.gid, t.agency||'|'||t.agency_item_id)"))
        args.append(int(coll))
    order = "n DESC, e DESC" if sort == "n" else "e DESC, n DESC"
    sql = f"""WITH t AS ({src})
      SELECT {gkey} g, SUM(t.e) e, SUM(t.n) n, COUNT(*) parts,
             GROUP_CONCAT(t.agency||'|'||t.agency_item_id||'|'||ROUND(t.e,2)||'|'||t.n, ';') members,
             MAX(a.title) title, MAX(a.thumb) thumb, MAX(a.filename) filename, MAX(a.gid) gid, MAX(a.media) media
      FROM t LEFT JOIN assets a ON a.agency=t.agency AND a.agency_item_id=t.agency_item_id
      WHERE {' AND '.join(where)} GROUP BY g HAVING SUM(t.e) > 0 OR SUM(t.n) > 0"""
    tot = q1(f"SELECT COUNT(*) c, SUM(e) e, SUM(n) n FROM ({sql})", args)
    rows = q(f"{sql} ORDER BY {order} LIMIT ? OFFSET ?", args + [limit, offset])
    out = []
    for r in rows:
        mem = []
        for part in (r["members"] or "").split(";"):
            bits = part.rsplit("|", 2)
            if len(bits) == 3 and "|" in bits[0]:
                ag, iid = bits[0].split("|", 1)
                mem.append({"agency": ag, "agency_item_id": iid, "e": num(bits[1]), "n": int(num(bits[2]))})
        mem.sort(key=lambda m: -m["e"])
        thumb = r["thumb"] or _thumb_for(r["gid"])
        out.append({"key": r["g"], "e": round(r["e"] or 0, 2), "n": int(r["n"] or 0), "title": r["title"],
                    "thumb": thumb, "alt": _thumb_for(r["gid"], thumb) if thumb else None, "filename": r["filename"], "members": mem, "media": r["media"],
                    "counts": any(AGENCIES.get(m["agency"], {}).get("counts") for m in mem)})
    return {"rows": out, "count": tot["c"] or 0, "earnings": round(tot["e"] or 0, 2), "downloads": int(tot["n"] or 0),
            "offset": offset, "limit": limit, "period": period}


# kopsummas (totals) + pārdošanas pēc kopsummu momentuzņēmuma dienas (state totals_day; Shutterstock kopsummas
# vairs nelasa katru dienu — lietotājs 2026-10-29)
TOTALS_SQL = """SELECT t.agency, t.agency_item_id, t.e + COALESCE(s.e, 0) e, t.n + COALESCE(s.n, 0) n
    FROM (SELECT agency, agency_item_id, SUM(earnings) e, SUM(downloads) n FROM totals GROUP BY agency, agency_item_id) t
    LEFT JOIN (SELECT sa.agency, sa.agency_item_id, SUM(sa.amount_usd) e, SUM(sa.cnt) n FROM sales sa
               JOIN state st ON st.agency = sa.agency AND st.key = 'totals_day'
               WHERE sa.day > trim(st.value, '"') {oth} GROUP BY sa.agency, sa.agency_item_id) s
    USING (agency, agency_item_id)"""


def item(agency: str, agency_item_id: str) -> dict:
    """Viena vienuma (un tās pašas bildes citās aģentūrās) detaļas."""
    ensure_groups()
    a = q1("SELECT * FROM assets WHERE agency=? AND agency_item_id=?", (agency, agency_item_id))
    if not a:
        return {}
    group = [dict(r) for r in q("SELECT * FROM assets WHERE gid=?", (a["gid"],))] if a["gid"] else [dict(a)]
    members = []
    for g in group:
        tot = q1(f"SELECT e, n FROM ({TOTALS_SQL.format(oth='')}) WHERE agency=? AND agency_item_id=?", (g["agency"], g["agency_item_id"]))
        first = q1("SELECT MIN(day) d, MAX(day) l, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE agency=? AND agency_item_id=?",
                   (g["agency"], g["agency_item_id"]))
        e = max((tot["e"] or 0) if tot else 0, (first["e"] or 0) if first else 0)     # kopsummas var vēl nebūt ielādētas
        n = max((tot["n"] or 0) if tot else 0, (first["n"] or 0) if first else 0)
        members.append({**g, "e": round(e, 2), "n": int(n),
                        "first": first["d"] if first else None, "last": first["l"] if first else None,
                        "counts": AGENCIES.get(g["agency"], {}).get("counts", True)})
    members.sort(key=lambda m: -m["e"])
    keys = [(m["agency"], m["agency_item_id"]) for m in members]
    cond = " OR ".join(["(agency=? AND agency_item_id=?)"] * len(keys))
    flat = [x for k in keys for x in k]
    years = q(f"SELECT substr(day,1,4) y, SUM(amount_usd) e, SUM(cnt) n FROM sales WHERE {cond} GROUP BY y ORDER BY y", flat)
    recent = q(f"SELECT agency, day, amount, currency, cnt, kind, license, raw FROM sales WHERE {cond} ORDER BY day DESC, id DESC LIMIT 30", flat)
    rec = []
    for r in recent:
        r = dict(r)
        raw = r.pop("raw", None)
        if raw:
            try:
                r["q"] = (json.loads(raw) or {}).get("q")
            except (TypeError, ValueError, AttributeError):
                pass
        rec.append(r)
    title = next((m["title"] for m in members if m["title"] and len(m["title"]) > 25), None) or a["title"]
    return {"title": title, "thumb": next((m["thumb"] for m in members if m["thumb"]), None), "members": members,
            "e": round(sum(m["e"] for m in members), 2), "n": sum(m["n"] for m in members),
            "counts": any(m["counts"] for m in members),
            "years": [dict(r) for r in years], "recent": rec}


def agencies_table(period: str = "month") -> dict:
    rng = _period(period)
    if rng is None:
        rows = q("SELECT agency, SUM(earnings) e, SUM(downloads) n FROM monthly GROUP BY agency")
    elif period in ("year",) or re.fullmatch(r"\d{4}", period or ""):
        rows = q("SELECT agency, SUM(earnings) e, SUM(downloads) n FROM monthly WHERE month BETWEEN ? AND ? GROUP BY agency",
                 (rng[0][:7], rng[1][:7]))
    else:
        rows = q("""SELECT agency, SUM(e) e, SUM(n) n FROM (
                      SELECT agency, SUM(earnings) e, SUM(downloads) n FROM daily WHERE day BETWEEN ? AND ? GROUP BY agency
                      UNION ALL
                      SELECT agency, SUM(earnings), SUM(downloads) FROM monthly WHERE month BETWEEN ? AND ?
                        AND agency NOT IN (SELECT DISTINCT agency FROM daily) GROUP BY agency) GROUP BY agency""",
                 (rng[0], rng[1], rng[0][:7], rng[1][:7]))
    out = []
    for r in rows:
        files = None
        if rng:
            f = q1("SELECT COUNT(DISTINCT agency_item_id) c FROM sales WHERE agency=? AND day BETWEEN ? AND ? AND kind!='other'",
                   (r["agency"], *rng))
            files = f["c"] if f and f["c"] else None
        e, n = r["e"] or 0, r["n"] or 0
        counts = AGENCIES.get(r["agency"], {}).get("counts", True)
        out.append({"agency": r["agency"], "e": round(e, 2), "n": int(n) if counts else None, "files": files,
                    "rpd": round(e / n, 2) if n and counts else None})
    # portfelis perioda beigās (vai jaunākais) + izmaiņa pret iepriekšējo mēnesi + ienākumi uz bildi portfelī
    from . import portfolio
    port = portfolio.for_agencies(rng[1][:7] if rng else None)
    have = {x["agency"] for x in out}
    for a, p in port.items():
        if a not in have and a in AGENCIES and not AGENCIES[a].get("archive"):
            out.append({"agency": a, "e": 0.0, "n": None, "files": None, "rpd": None})
    for x in out:
        p = port.get(x["agency"])
        x["port"] = p["files"] if p else None
        x["port_delta"] = p["delta"] if p else None
        x["port_month"] = p["month"] if p else None
        x["epf"] = round(x["e"] / p["files"], 7) if p and p["files"] and x["e"] else None
    out.sort(key=lambda x: -x["e"])
    tot = sum(x["e"] for x in out)
    for x in out:
        x["share"] = round(x["e"] / tot * 100, 1) if tot else 0
    ptot = sum(x["port"] or 0 for x in out)
    return {"rows": out, "total": round(tot, 2), "period": period, "range": rng,
            "port_total": ptot or None, "epf_total": round(tot / ptot, 7) if ptot and tot else None}


def match_files(items: list[dict]) -> dict:
    """Lokālo failu sasaiste ar pārdošanām: pēc faila vārda un virsraksta/apraksta (visas aģentūras).
    items: [{path, name, title, desc}] -> {path: {e, n, ag: [...]}}"""
    out = {}
    if not items:
        return out
    try:
        if not q1("SELECT 1 FROM assets LIMIT 1"):
            return out
    except sqlite3.DatabaseError:
        return out
    ensure_groups()
    for it in items:
        gids = set()
        fk = fkey(it.get("name"))
        if fk:
            gids |= {r["gid"] for r in q("SELECT gid FROM assets WHERE fkey=?", (fk,))}
        for txt in (it.get("title"), it.get("desc")):
            k = mkey(txt)
            if k:
                gids |= {r["gid"] for r in q("SELECT gid FROM assets WHERE mkey=?", (k,))}
        gids.discard(None)
        if not gids:
            continue
        e = n = 0.0
        ags = set()
        first = None
        for g in gids:
            for r in q("""SELECT a.agency, a.agency_item_id, SUM(t.earnings) e, SUM(t.downloads) n FROM assets a
                          JOIN totals t ON t.agency=a.agency AND t.agency_item_id=a.agency_item_id
                          WHERE a.gid=? GROUP BY a.agency, a.agency_item_id""", (g,)):
                if r["e"] or r["n"]:
                    e += r["e"] or 0
                    n += r["n"] or 0
                    ags.add(r["agency"])
                    first = first or [r["agency"], r["agency_item_id"]]
        if e or n:
            out[it["path"]] = {"e": round(e, 2), "n": int(n), "ag": sorted(ags), "key": first}
    return out
