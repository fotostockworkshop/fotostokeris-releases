/* Alamy: konta izraksts (ASP.NET lapa). Neto ienākums = pārdošana − Alamy un izplatītāja komisijas. */
async function collect() {
  if (!/(^|\.)alamy\.com$/.test(location.hostname)) throw LOGIN;
  const BASE = "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1";
  let doc = await getdoc(BASE);
  const formOf = (d) => d.querySelector("form#form1") || d.forms[0];
  if (!formOf(doc) || !doc.querySelector('[name="drpPeriod"]')) throw LOGIN;

  /* ASP.NET "postback": visi formas lauki + izmaiņas */
  async function post(d, set) {
    const f = formOf(d);
    const fd = new URLSearchParams();
    for (const el of f.querySelectorAll("input, select, textarea")) {
      if (!el.name || ["submit", "button", "image", "reset"].includes(el.type)) continue;
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) continue;
      fd.set(el.name, el.value || "");
    }
    for (const k in set) fd.set(k, set[k]);
    return getdoc(BASE, { method: "POST", body: fd, headers: { "Content-Type": "application/x-www-form-urlencoded" } });
  }
  const pageInfo = (d) => { const m = txt(d.body).match(/Page\s+(\d+)\s+of\s+(\d+)/i); return m ? [+m[1], +m[2]] : [1, 1]; };

  say("izraksts", 3);
  doc = await post(doc, { __EVENTTARGET: "drpPeriod", __EVENTARGUMENT: "", drpPeriod: OPTS.mode === "full" ? "2000" : "2",
    drpPagesize: "100" });
  const body = txt(doc.body);
  const sm = body.match(/Summary for (\d{1,2} [A-Za-z]+ \d{4}) to (\d{1,2} [A-Za-z]+ \d{4})/);
  const start = sm ? pdate(sm[1]) : (OPTS.mode === "full" ? "2000-01-01" : OPTS.since);
  const end = sm ? pdate(sm[2]) : today;
  const bal = body.match(/Balance carried forward:\s*\$\s*(-?[\d,.]+)/i);
  if (bal) await send("balance", { amount: money(bal[1]), currency: "USD" });

  const cleared = body.match(/Cleared balance:?\s*\$\s*(-?[\d,.]+)/i);
  const nextPay = body.match(/Next payment date:?\s*(\d{1,2}[\s/.-]+[A-Za-z0-9]+[\s/.-]+\d{4})/i);
  const pays = [];                       // izmaksas izrakstā (PayPal u.c.)
  const agg = new Map();                 // (diena|ID) -> {neto, skaits}
  let [pg, pages] = pageInfo(doc);
  for (let guard = 0; guard < 500; guard++) {
    say(`${pg}/${pages}`, Math.min(95, 5 + Math.round((pg / Math.max(1, pages)) * 90)));
    for (const tr of doc.querySelectorAll("table tr")) {
      const c = [...tr.cells].map((x) => txt(x));
      if (c.length < 7) continue;
      const day = pdate(c[0]);
      if (!day) continue;
      const desc = c[1], id = c[2];
      if (/paypal|payment|transfer|bank|cheque|withdraw|brought forward/i.test(desc)) {
        if (!/brought forward/i.test(desc)) pays.push({ date: day, amount: Math.abs(money(c[4]) || money(c[5])), currency: "USD" });
        continue;
      }
      const key = day + "|" + id;
      const a = agg.get(key) || { e: 0, n: 0 };
      a.e += money(c[5]) - money(c[4]);
      if (/^sale$/i.test(desc)) a.n += 1;
      if (/^sale refunded/i.test(desc)) a.n -= 1;
      agg.set(key, a);
    }
    if (pg >= pages) break;
    const before = pg;
    doc = await post(doc, { __EVENTTARGET: "", __EVENTARGUMENT: "", txtGotopage: String(pg + 1), btnGotopage: "Go" });
    [pg, pages] = pageInfo(doc);
    if (pg <= before) break;              // lapošana neizdevās — beidzam ar to, kas ir
    await sleep(300);
  }
  const rows = [];
  for (const [key, a] of agg) {
    const [day, id] = key.split("|");
    if (Math.abs(a.e) < 0.0001 && !a.n) continue;
    rows.push({ day, id, amount: Math.round(a.e * 10000) / 10000, cnt: a.n, kind: "sale",
      url: id ? `https://www.alamy.com/search.html?qt=${encodeURIComponent(id)}` : "" });
  }
  await sendRows(rows, { start, end });
  /* izmaksas: automātiskas nākamajā mēnesī, ja "Cleared balance" ≥ minimums (lietotājs: $50) */
  await payoutsSafe(async () => {
    await sendPayInfo({ unpaid: bal ? money(bal[1]) : null, available: cleared ? money(cleared[1]) : null, currency: "USD",
      next_date: nextPay ? pdate(nextPay[1]) : null });
    await sendPayouts(pays, OPTS.mode === "full" ? {} : { full: false, start });
  });
  await portfolioSafe([
    ["izraksts", async () => countIn(body)],
    ["dashboard", () => portPage("https://www.alamy.com/alamycontributorreports/")],
    ["contributor", () => portPage("https://www.alamy.com/contributor/dashboard/")],
  ]);
  return { rows: rows.length, start, end };
}
