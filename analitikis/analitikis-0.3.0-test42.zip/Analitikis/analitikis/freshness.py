"""Atjaunošanas biežums katrai aģentūrai un Envato datu maiņas laiks (Analītiķis 0.3.0-test42).

Iestatījums `sales_refresh` = {aģentūra: "always" | "day" | "week"} (tukšs = noklusējums DEFAULT). "Atjaunot visas"
un automātiskā atjaunošana izlaiž aģentūras, kuru dati vēl ir svaigi; pašā kartītē var atjaunot jebkurā brīdī.

Envato (lietotājs 2026-10-30): dati mainās reizi dienā, bet laiks nav publisks. Pēc katras Envato atjaunošanas
pierakstām, vai dati mainījās (paraksts: summas un pēdējā diena) un starp kuriem brīžiem. Kad ir ≥3 novērojumi ar
šauru logu (≤12 h), zināms aptuvenais laiks T — tad Envato ir svaigs līdz nākamajam T (nevis 24 h kopš atjaunošanas).
"""
from __future__ import annotations

import datetime as dt
import json
import statistics

from . import config
from . import db

HOURS = {"always": 0, "day": 24, "week": 168}
# lietotājs 2026-10-30: reizi 24 h — aģentūras, kuru dati mainās lēni vai ar nobīdi
DEFAULT = {"envato": "day", "istock": "day", "ingram": "day", "zoonar": "day", "alamy": "day", "123rf": "day"}
WATCH = "envato"
MAX_OBS = 20
NARROW_H = 12
NEED_OBS = 3
SAFETY_MIN = 30


def mode(agency: str) -> str:
    ag = db.AGENCIES.get(agency, {}).get("via") or agency
    user = config.get("sales_refresh") or {}
    m = user.get(ag) if isinstance(user, dict) else None
    return m if m in HOURS else DEFAULT.get(ag, "always")


def modes() -> dict:
    return {a: mode(a) for a in db.AG_ORDER if not db.AGENCIES[a].get("archive") and not db.AGENCIES[a].get("via")}


def _parse(s):
    try:
        return dt.datetime.fromisoformat(s)
    except (TypeError, ValueError):
        return None


def fresh_until(agency: str) -> str | None:
    h = HOURS[mode(agency)]
    last = _parse(db.get_state(agency, "last_ok")) if h else None
    if not last:
        return None
    until = last + dt.timedelta(hours=h)
    t = learned_time() if h == 24 and (db.AGENCIES.get(agency, {}).get("via") or agency) == WATCH else None
    if t is not None:
        cand = last.replace(hour=t // 60, minute=t % 60, second=0, microsecond=0)
        if last >= cand:
            cand += dt.timedelta(days=1)
        until = cand
    return until.isoformat(timespec="seconds") if until > dt.datetime.now() else None


# --------------------------------------------------------------------------- Envato maiņas laiks

def _signature() -> str:
    r = db.q1("""SELECT (SELECT ROUND(COALESCE(SUM(earnings),0),2) FROM monthly WHERE agency IN ('envato','envato_market')) e,
                        (SELECT MAX(day) FROM daily WHERE agency IN ('envato','envato_market')) d,
                        (SELECT MAX(month) FROM monthly WHERE agency IN ('envato','envato_market')) m,
                        (SELECT COUNT(*) FROM sales WHERE agency IN ('envato','envato_market')) n""")
    return json.dumps([r["e"], r["d"], r["m"], r["n"]]) if r else ""


def note_sync(agency: str, full: bool) -> None:
    """Pēc veiksmīgas atjaunošanas (sync.done). Pilnajā ielādē paraksts mainās tāpat — novērojumu nepierakstām."""
    if agency != WATCH:
        return
    now = dt.datetime.now()
    w = db.get_state(WATCH, "change_watch") or {}
    sig = _signature()
    prev_at = _parse(w.get("at"))
    obs = list(w.get("obs") or [])
    changed = bool(w.get("sig")) and sig != w.get("sig")
    if changed and not full and prev_at:
        obs.append({"a": prev_at.isoformat(timespec="minutes"), "b": now.isoformat(timespec="minutes")})
        obs = obs[-MAX_OBS:]
        hrs = (now - prev_at).total_seconds() / 3600
        print(f"[{WATCH}] dati mainījušies starp {prev_at:%m-%d %H:%M} un {now:%m-%d %H:%M} ({hrs:.1f} h)"
              + (f"; aptuvenais maiņas laiks ~{fmt(learned_time(obs))}" if learned_time(obs) is not None else ""))
    elif w.get("sig"):
        print(f"[{WATCH}] dati kopš {prev_at:%m-%d %H:%M} nav mainījušies" if prev_at else f"[{WATCH}] dati nav mainījušies")
    db.set_state(WATCH, "change_watch", {"sig": sig, "at": now.isoformat(timespec="seconds"), "obs": obs})


def _tod(d: dt.datetime) -> int:
    return d.hour * 60 + d.minute


def learned_time(obs: list | None = None) -> int | None:
    """Aptuvenais Envato datu maiņas laiks (minūtes no pusnakts) vai None, ja vēl nav zināms."""
    if obs is None:
        obs = (db.get_state(WATCH, "change_watch") or {}).get("obs") or []
    mids = []
    for o in obs:
        a, b = _parse(o.get("a")), _parse(o.get("b"))
        if not a or not b or b <= a or (b - a).total_seconds() > NARROW_H * 3600:
            continue
        mids.append(_tod(a + (b - a) / 2))
    if len(mids) < NEED_OBS:
        return None
    # laiki ap pusnakti: ja izkliede liela, pārbīdām (23:50 un 00:10 ir tuvi)
    if max(mids) - min(mids) > 720:
        mids = [m + 1440 if m < 720 else m for m in mids]
    t = int(statistics.median(mids)) + SAFETY_MIN
    t = ((t + 14) // 15 * 15) % 1440
    return t


def fmt(t: int | None) -> str:
    return "" if t is None else f"{t // 60:02d}:{t % 60:02d}"


def info() -> dict:
    """Iestatījumu lapai un Envato kartītei."""
    w = db.get_state(WATCH, "change_watch") or {}
    t = learned_time()
    return {"modes": modes(), "defaults": DEFAULT, "envato_time": fmt(t) if t is not None else None,
            "envato_obs": len(w.get("obs") or [])}
