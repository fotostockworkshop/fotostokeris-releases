/* Ingram (ingramportal.com, GBP): Reports → Royalties — mēneša summas pa gadiem (bez bildēm).
   Lapas uzbūve vēl nav redzēta (Claude pārlūkā portāls neatveras) — savācējs meklē pēc tekstiem un raksta
   žurnālā, ko atrada. */
async function collect() {
  if (!/(^|\.)ingramportal\.com$/.test(location.hostname)) throw LOGIN;
  /* "cilvēka" pārbaude (traffic-verifier u.c.) vai lapa vēl ielādējas — nav kļūda: gaidām (logs paliek lietotājam) */
  /* Pārbaudi meklējam tikai tad, ja nav portāla izvēlnes (Royalties saites): lapās var būt paslēpti
     traffic-verifier skripti vai "protected by reCAPTCHA" uzraksts — tie nenozīmē, ka pārbaude notiek. */
  const hasMenu = [...document.querySelectorAll("a[href]")].some((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")))
    || /royalt/i.test(location.pathname);
  if (!hasMenu) {
    const why = !document.querySelector("a[href]") ? "lapā vēl nav saišu"
      : /verif|human|robot|checking your browser/i.test(document.title) ? "pārbaude (virsraksts)" : "";
    if (why) { B.log(AG, `${why} — gaidu (${location.pathname})`); throw LOGIN; }
  }
  const MONS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  /* Royalties lapa: saite ar tekstu "Royalties" (vai jau esam tajā) */
  let doc = document, url = location.href;
  if (!/royalt/i.test(location.pathname + " " + txt(document.querySelector("h1, h2")))) {
    const a = [...document.querySelectorAll("a[href]")].find((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")));
    if (!a) {
      B.log(AG, "Royalties saite nav atrasta; saites: " + [...document.querySelectorAll("a[href]")].slice(0, 25)
        .map((x) => txt(x).slice(0, 20) + "→" + new URL(x.getAttribute("href"), location.href).pathname).join(" · "));
      throw LOGIN;                          // vēl nav ielogots / izvēlne nav ielādēta — gaidām, logu neaizveram
    }
    url = new URL(a.getAttribute("href"), location.href).href;
    doc = await getdoc(url);
  }
  if (doc.querySelector('input[type="password"]') && !/royalt/i.test(txt(doc.body).slice(0, 4000))) {
    B.log(AG, "Royalties lapas vietā ielogošanās forma — gaidu"); throw LOGIN;
  }
  const body = txt(doc.body);
  const since = body.match(/since last pay-?out:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
  if (since) await send("balance", { amount: money(since[1]), currency: "GBP" });
  /* izmaksas: jāpieprasa ("Request payment", vismaz £40); pieprasāms = TOTAL ROYALTIES; vēstures ar summām nav */
  await payoutsSafe(async () => {
    const tot = body.match(/TOTAL ROYALTIES:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
    const mn = body.match(/at least\s*£?\s*(\d+(?:\.\d+)?)\s*GBP/i);
    const v = tot ? money(tot[1]) : since ? money(since[1]) : null;
    if (v != null) await sendPayInfo({ unpaid: v, available: v, min: mn ? +mn[1] : null, currency: "GBP" });
  });
  /* gadu cilnes: saites/pogas ar gadu tekstu → katra gada lapa vai paslēpts bloks */
  const years = [...new Set([...doc.querySelectorAll("a, button, li")].map((x) => txt(x)).filter((t) => /^20\d\d$/.test(t)))].sort();
  B.log(AG, `Royalties: ${new URL(url).pathname}; gadi: ${years.join(",") || "–"}; tabulas: ${doc.querySelectorAll("table").length}`);
  const rows = [];
  function grab(d, yearHint) {
    for (const t of d.querySelectorAll("table")) {
      const head = txt(t.querySelector("tr"));
      if (!/month/i.test(head) || !/royalt/i.test(head)) continue;
      let y = yearHint;
      const box = t.closest("[id], section, div");
      const ym = String(box ? box.id + " " + txt(box.querySelector("h2,h3,h4,.tab-title")) : "").match(/20\d\d/);
      if (ym) y = +ym[0];
      for (const tr of [...t.querySelectorAll("tr")].slice(1)) {
        const c = [...tr.cells].map(txt);
        if (c.length < 2) continue;
        const mm = c[0].match(/([A-Za-z]{3})[a-z]*\s*(20\d\d)?/);
        if (!mm || !MONS[mm[1].toLowerCase()]) continue;
        const yy = mm[2] ? +mm[2] : y;
        if (!yy) continue;
        rows.push({ month: `${yy}-${String(MONS[mm[1].toLowerCase()]).padStart(2, "0")}`, cat: "royalties", e: money(c[c.length - 1]), n: 0 });
      }
    }
  }
  grab(doc, years.length ? +years[years.length - 1] : 0);
  /* ja gadu tabulas nav visas vienā lapā — mēģinām gadu saites */
  /* gada cilne: īsta saite → tā; citādi (JavaScript cilne) mēģinām adresi ar gada parametru */
  const tried = [];
  /* ikdienas atjaunošana: tikai šis gads (janvārī–februārī arī iepriekšējais) — vecie gadi nemainās */
  const tyI = +today.slice(0, 4), tmI = +today.slice(5, 7);
  const needY = OPTS.mode === "full" ? years : years.filter((y) => +y === tyI || (tmI <= 2 && +y === tyI - 1));
  for (const y of needY) {
    if (rows.some((r) => r.month.startsWith(y + "-"))) continue;
    const a = [...doc.querySelectorAll("a[href]")].find((x) => txt(x) === y && !/^#|javascript:/i.test(x.getAttribute("href")));
    const base = new URL(url);
    const cands = a ? [new URL(a.getAttribute("href"), location.href).href] : [];
    for (const k of ["year", "y", "Year"]) { const u = new URL(base); u.searchParams.set(k, y); cands.push(u.href); }
    for (const c of cands) {
      const before = rows.length;
      try { grab(await getdoc(c), +y); } catch (e) { if (e && e.login) throw e; }
      await sleep(300);
      if (rows.slice(before).some((r) => r.month.startsWith(y + "-"))) { tried.push(`${y}:${new URL(c).search || new URL(c).pathname}`); break; }
    }
  }
  if (tried.length) B.log(AG, "gadi no adresēm: " + tried.join(" "));
  const uniq = {};
  for (const r of rows) uniq[r.month] = r;
  const list = Object.values(uniq).sort((a, b) => (a.month < b.month ? -1 : 1));
  B.log(AG, `mēneši: ${list.length}`);
  if (!list.length) throw new Error("Ingram: Royalties tabula nav atrasta");
  /* ikdienas atjaunošanā aizstājam tikai nolasītos gadus (vecos mēnešus nedzēšam) */
  await send("months", { start: OPTS.mode === "full" ? list[0].month + "-01" : list[0].month + "-01", end: today, currency: "GBP", rows: list });
  if (OPTS.sub_due) { try { await igStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["contributor area", () => portPage("/index.cfm?/carea_EN", [/Images online:?\s*(\d[\d,]*)/i, ...PORT_RE])],
    ["sākumlapa", () => portPage("/", [/Images online:?\s*(\d[\d,]*)/i, ...PORT_RE])],
  ]);
  return { months: list.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /index.cfm?id=273&careaAct=portfolio&phase=new (awaiting approval),
   phase=approved (online, 28 lapā, lapas "Next Page"), phase=rejected; sīktēlu uzklikšķinot — logs "<faila nosaukums> - Enter
   metadata" (Ingram pārdēvē failu, piem. IST_24335_11778.jpg; oriģināls varbūt "Show file information"). Lasām sīktēlus;
   žurnālā pirmā sīktēla HTML atribūti, lai precizētu. Gaidošajām nosaukumu ņemam, uzklikšķinot (≤30). */
async function igStatus() {
  /* test53 (izpēte Chrome 2026-11-12): saraksti — GET /_components/ContributorArea.Portfolio/img_fetch_images.cfm?…&state=new|rejected|approved
     (28 lapā, jaunākās augšā; kartītē `displayEditImageBox('IMSIMAGE:…', <id>, …)`); bildes dati — GET img_metadata_editor.cfm?lang=EN&cuitemuuid=…
     (lauki `origfile`, `title`, teksts "Submitted: 12 Nov 2026"). Bez klikšķināšanas rāmī (agrāk 0 nosaukumu). */
  const C = "/_components/ContributorArea.Portfolio/";
  const L = [["new", "Awaiting approval", 2], ["rejected", "Rejected", 2], ["approved", "Online", 3]];
  const all = new Map(), uuid = new Map();
  for (const [st, raw, pages] of L) {
    let n = 0;
    for (let p = 0; p < pages; p++) {
      let h = "";
      try { h = await (await fetch(`${C}img_fetch_images.cfm?showImageDataInGrid=0&startrow=${p * 28 + 1}&maximages=28&state=${st}&autoOpenFirst=0`, { credentials: "include" })).text(); }
      catch (e) { B.log(AG, `statusi: ${raw} — ${String((e && e.message) || e).slice(0, 80)}`); break; }
      const m = [...h.matchAll(/displayEditImageBox\('(IMSIMAGE:[0-9A-F-]+)',\s*(\d+)/gi)];
      for (const [, u, id] of m) if (!all.has(id)) { all.set(id, { id, file: "", title: "", submitted: "", status: raw }); uuid.set(id, u); n++; }
      if (m.length < 28) break;
      await sleep(400);
    }
    B.log(AG, `statusi: ${raw} — ${n} bildes`);
  }
  /* faila nosaukums + virsraksts + datums — tikai vēl nezināmām. test56: Ingram atbild lēni (~3 s bildei; Chrome 2026-11-12) →
     4 vienlaicīgi, ≤150 s; secība: gaida → noraidītas → tiešsaistē (nepaspētās — nākamajā reizē, zināmās izlaiž) */
  const t0 = Date.now(), known = new Set((OPTS.sub_known || []).map(String));
  let got = 0, k = 0;
  const todo = [...all.values()].filter((r) => !known.has(String(r.id)));
  const one = async (r) => {
    try {
      const d = new DOMParser().parseFromString(await (await fetch(`${C}img_metadata_editor.cfm?lang=EN&cuitemuuid=${encodeURIComponent(uuid.get(r.id))}`, { credentials: "include" })).text(), "text/html");
      const v = (n) => ((d.querySelector(`[name="${n}"]`) || {}).value || "").trim();
      const sub = ((d.body.textContent || "").match(/Submitted:\s*(\d{1,2} [A-Za-z]{3} \d{4})/i) || [])[1];
      r.file = v("origfile"); r.title = v("title").slice(0, 250); if (sub) r.submitted = pdate(sub) || "";
      if (r.file) got++;
    } catch (e) { /* nākamreiz */ }
  };
  const q = todo.slice();
  await Promise.all([0, 1, 2, 3].map(async () => {
    while (q.length && Date.now() - t0 < 150000) {
      await one(q.shift());
      if (++k % 10 === 0) say(`Ingram: ${k}/${todo.length}`, 95);
    }
  }));
  B.log(AG, `statusi: oriģinālie faila nosaukumi — ${got}/${todo.length}`);
  const rows = [...all.values()];
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
