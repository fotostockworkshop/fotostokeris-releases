/* Pixta: www.pixtastock.com/mypage/earning — pārdošanas pa gadiem un pārdošanas veidiem */
async function collect() {
  if (!/(^|\.)pixtastock\.com$/.test(location.hostname)) throw LOGIN;
  const doc = await getdoc("/mypage/earning");
  const ysel = doc.querySelector('select[name="year"]');
  if (!ysel) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Pixta: ienākumu lapa nav atrasta");
  }
  const bm = txt(doc.body).match(/Account Balance\s*:\s*([\d.,]+)/i);
  if (bm) await send("balance", { amount: money(bm[1]), currency: "USD" });

  /* pārdošanas veidi (earned_from) no saitēm "Sales: All / Single Purchase / Subscription / Other" */
  const srcs = new Set();
  for (const a of doc.querySelectorAll('a[href*="earned_from="]')) {
    const m = (a.getAttribute("href") || "").match(/earned_from=([^&]+)/);
    if (m) srcs.add(decodeURIComponent(m[1]));
  }
  let sources = srcs.has("all") ? ["all"] : [...srcs];
  if (!sources.length) sources = ["pixta", "subscription", "other"];

  function parse(d) {
    const out = [];
    for (const tr of d.querySelectorAll("table tr")) {
      const v = [...tr.cells].map((c) => txt(c));
      if (v.length < 4) continue;
      const day = v.map(pdate).find(Boolean);
      const id = v.find((x) => /^\d{6,}$/.test(x));
      if (!day || !id) continue;
      const img = tr.querySelector("img");
      out.push({ day, ts: (v.find((x) => /\d{1,2}\/\d{1,2}\/\d{4}/.test(x)) || ""), id, amount: money(v[v.length - 1]), cnt: 1, kind: "sale",
        thumb: img ? img.getAttribute("src") : "", url: `https://www.pixtastock.com/photo/${id}` });
    }
    return out;
  }

  const years = [...ysel.options].map((o) => o.value).filter((v) => /^\d{4}$/.test(v)).sort().reverse();
  const minY = OPTS.mode === "full" ? "0000" : OPTS.since.slice(0, 4);
  let total = 0, found = false, empty = 0;
  for (let i = 0; i < years.length; i++) {
    const y = years[i];
    if (y < minY) break;
    let yearRows = 0;
    for (const src of sources) {
      say(`${y} · ${src}`, Math.min(95, Math.round((i / years.length) * 95)));
      const rows = [];
      let prev = "";
      for (let page = 1; page < 50; page++) {
        /* test42: bez content_type — ar "content_type=0,1" un earned_from=all Pixta rāda tikai tiešos pirkumus (2026: 1 no 31;
           abonementa pārdošanas kopš septembra netika nolasītas — pārbaudīts Chrome 2026-11-11) */
        const u = `/mypage/earning?earned_from=${encodeURIComponent(src)}&year=${y}&month=&per_page=200` +
          (page > 1 ? `&page=${page}` : "");
        const r = parse(await getdoc(u)).filter((x) => x.day.startsWith(y));
        const s = r.slice(0, 2).map((x) => x.id + x.ts).join();
        if (!r.length || s === prev) break;
        prev = s;
        rows.push(...r);
        if (r.length < 200) break;
        await sleep(250);
      }
      yearRows += rows.length;
      await sendRows(rows, { batch: `pixta-${src}-${y}` });
    }
    total += yearRows;
    if (yearRows) { found = true; empty = 0; } else if (++empty >= (found ? 2 : 4)) break;
  }
  /* izmaksas (2026-11-06): /mypage/earning/use_history — Date of Request | … | Total Payout | Date of Payment;
     izmaksā 15. datumā aiz nākamā mēneša. Bez maksājuma datuma = pieprasīta → ceļā (aptuveni). */
  await payoutsSafe(async () => {
    const t = tableObjs(await getdoc("/mypage/earning/use_history"), [/request/i, /payment/i]) || [];
    const p15 = (d) => { const x = new Date(d + "T12:00:00Z"); x.setUTCMonth(x.getUTCMonth() + 2, 15); return x.toISOString().slice(0, 10); };
    const rows = t.map((o) => {
      const rq = pdate(pick(o, /date of request/)), pd = pdate(pick(o, /date of payment/)), a = money(pick(o, /total payout/) || pick(o, /converted/));
      if (!rq || !a) return null;
      return pd ? { date: pd, amount: a, currency: "USD" } : { date: p15(rq), amount: a, currency: "USD", status: "aptuveni", ref: "req:" + rq };
    }).filter(Boolean);
    B.log(AG, `izmaksas: ${rows.length} (use_history)`);
    if (rows.length) await sendPayouts(rows);
  });
  if (OPTS.sub_due) { try { await pxStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["mypage (On sale summa)", async () => sumAll(txt((await getdoc("/mypage")).body), /On sale:\s*(\d[\d,]*)/i)],
    ["mypage", () => portPage("/mypage")],
    ["mypage/contents", () => portPage("/mypage/contents")],
  ]);
  return { rows: total, sources };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi un CSV 2026-11-06): /mypage/manager — jaunākās augšā, 50 lapā
   (File No. | Type | Status Pending/Online/… | Date of Upload). CSV (poga "CSV" → gads/mēnesis → Download) satur arī
   File Name (d738_…) un Title. Avots: (1) CSV šim un iepriekšējam mēnesim, ja atrodam formas adresi; (2) saraksta lapa (bez faila nosaukuma). */
async function pxStatus() {
  const all = new Map();
  const add = (r) => { if (r.id && !all.has(r.id)) all.set(r.id, r); };
  const csvRows = (t) => {
    const lines = t.replace(/^﻿/, "").split(/\r?\n/).filter(Boolean); if (lines.length < 2) return [];
    const split = (l) => { const o = []; let c = "", q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === "," && !q) { o.push(c); c = ""; } else c += ch; } o.push(c); return o; };
    const h = split(lines[0]).map((x) => x.trim().toLowerCase()), ix = (re) => h.findIndex((x) => re.test(x));
    const iI = ix(/file no/), iS = ix(/^status/), iD = ix(/date of upload/), iT = ix(/^title/), iF = ix(/file name/);
    if (iI < 0 || iS < 0) return [];
    return lines.slice(1).map(split).map((c) => ({ id: (c[iI] || "").trim(), file: iF >= 0 ? (c[iF] || "").trim() : "", title: iT >= 0 ? (c[iT] || "").slice(0, 250) : "",
      submitted: iD >= 0 ? pdate(c[iD]) || "" : "", status: (c[iS] || "").trim() }));
  };
  let src = "";
  try {
    const d = await getdoc("/mypage/manager");
    const f = [...d.querySelectorAll("form")].find((x) => /csv|download/i.test((x.getAttribute("action") || "") + x.innerHTML.slice(0, 2000)) && x.querySelector("select"));
    if (f) {
      const now = new Date();
      for (const back of [0, 1]) {
        const dt = new Date(now.getFullYear(), now.getMonth() - back, 1);
        const fd = new URLSearchParams();
        for (const el of f.querySelectorAll("input, select")) if (el.name && el.type !== "submit") fd.set(el.name, el.value || "");
        const sels = [...f.querySelectorAll("select")];
        const ys = sels.find((x) => [...x.options].some((o) => /^20\d\d$/.test(o.text.trim())));
        const ms = sels.find((x) => [...x.options].some((o) => /^(January|February|March|April|May|June|July|August|September|October|November|December|\d{1,2})$/i.test(o.text.trim())) && x !== ys);
        if (ys) fd.set(ys.name, [...ys.options].find((o) => o.text.trim() === String(dt.getFullYear()))?.value || String(dt.getFullYear()));
        if (ms) { const mo = [...ms.options][dt.getMonth() + ([...ms.options].length > 12 ? 1 : 0)]; if (mo) fd.set(ms.name, mo.value); }
        const act = f.getAttribute("action") || "/mypage/manager";
        const r = await fetch(act, { method: (f.method || "GET").toUpperCase() === "POST" ? "POST" : "GET", credentials: "include", ...((f.method || "").toUpperCase() === "POST" ? { body: fd } : {}) }).catch(() => null);
        const url2 = (f.method || "").toUpperCase() === "POST" ? null : act + (act.includes("?") ? "&" : "?") + fd.toString();
        const t = r && (f.method || "").toUpperCase() === "POST" ? await r.text() : url2 ? await (await fetch(url2, { credentials: "include" })).text() : "";
        const rows = csvRows(t); rows.forEach(add);
        if (rows.length) src = "CSV";
      }
      /* 2026-11-06 (žurnāls): forma action="#" (sūta JS) — mēģinām zināmās adreses ar tiem pašiem laukiem */
      if (!src) {
        const now = new Date();
        const fd = new URLSearchParams();
        for (const el of f.querySelectorAll("input, select")) if (el.name && el.type !== "submit") fd.set(el.name, el.value || "");
        fd.set("date[year]", String(now.getFullYear())); fd.set("date[month]", String(now.getMonth() + 1)); fd.set("date[day]", "1");
        for (const u of ["/mypage/manager/csv", "/mypage/manager/download_csv", "/mypage/manager/export", "/mypage/manager.csv"]) {
          for (const m of ["POST", "GET"]) {
            const r = await fetch(m === "GET" ? u + "?" + fd : u, { method: m, credentials: "include", ...(m === "POST" ? { body: fd } : {}) }).catch(() => null);
            if (!r || !r.ok) continue;
            const rows = csvRows(await r.text());
            if (rows.length) { rows.forEach(add); src = "CSV " + m + " " + u; break; }
          }
          if (src) break;
        }
        const btn = f.querySelector("[onclick], [data-url], [data-action]");
        if (!src && btn) B.log(AG, "statusi: CSV poga: " + btn.outerHTML.slice(0, 250));
      }
      if (!src) B.log(AG, `statusi: CSV forma ${f.getAttribute("action")} — rindas nav; lauki: ${[...f.elements].map((e) => e.name).filter(Boolean).join(",")}`);
    } else B.log(AG, "statusi: CSV forma nav atrasta");
    if (!src) {
      const rowsOf = (doc) => {
        let n = 0;
        for (const tr of doc.querySelectorAll("tr")) {
          const c = [...tr.cells].map((x) => txt(x));
          const id = c.find((x) => /^\d{8,10}$/.test(x)) || (txt(tr).match(/\b(\d{9})\b/) || [])[1];
          const st = c.find((x) => /^(Pending|Online|Rejected|Not approved|Under review|Suspended|Unavailable)$/i.test(x));
          /* test43: virsraksts — sīktēla alt ("<virsraksts> <File No.>"; pārbaudīts Chrome 2026-11-11) → sasaiste ar Vārdotāja bildēm */
          const alt = ((tr.querySelector("img") || {}).alt || "").replace(/\s*\d{8,10}\s*$/, "").trim();
          if (id && st) { add({ id, file: "", title: alt.slice(0, 250), submitted: pdate(c.find((x) => /\d{2}\/\d{2}\/\d{4}/.test(x)) || "") || "", status: st }); n++; }
        }
        return n;
      };
      rowsOf(d);
      src = "saraksts";
      /* test63 (Chrome 2026-11-14): lapā 50 bildes; nākamās — POST /mypage/manager "page=N" (X-CSRF-Token no meta, X-Requested-With) → atbilde
         text/javascript ar HTML virknē. Agrāk lasījām tikai 1. lapu (50) → daļa komplektu bilžu trūka. Lasām līdz 8 lapām (~400 jaunākās). */
      const tok = (d.querySelector("meta[name=csrf-token]") || document.querySelector("meta[name=csrf-token]") || {}).content || "";
      const BS = String.fromCharCode(92);
      for (let pg = 2; pg <= 8 && tok; pg++) {
        const r = await fetch("/mypage/manager", { method: "POST", credentials: "include", body: "page=" + pg,
          headers: { "X-CSRF-Token": tok, "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8", Accept: "*/*;q=0.5, text/javascript, application/javascript", "X-Requested-With": "XMLHttpRequest" } }).catch(() => null);
        if (!r || !r.ok) break;
        let t = await r.text();
        for (const [k, v] of [["u003c", "<"], ["u003e", ">"], ["u0026", "&"], ["n", "\n"], ['"', '"'], ["'", "'"], ["/", "/"]]) t = t.split(BS + k).join(v);
        const n = rowsOf(new DOMParser().parseFromString("<table>" + t + "</table>", "text/html"));
        if (n < 50) break;
        await sleep(300);
      }
      if (all.size > 50) src = "saraksts, " + Math.ceil(all.size / 50) + " lapas";
      /* gaidošajām/noraidītajām sīktēla vēl nav (alt tukšs) → faila nosaukums un virsraksts no detaļu lapas */
      let det = 0;
      for (const r of all.values()) {
        if (r.title || det >= 40) continue;
        det++;
        try {
          const dd = await getdoc("/mypage/manager/detail/" + r.id);
          const lines = (dd.body.innerText || dd.body.textContent || "").split("\n").map((x) => x.trim()).filter(Boolean);
          const at = (re) => { const i = lines.findIndex((x) => re.test(x)); return i >= 0 ? lines[i + 1] || "" : ""; };
          r.file = at(/^file name$/i); r.title = at(/^title$/i).slice(0, 250);
        } catch (e) { /* paliek bez */ }
        await sleep(200);
      }
    }
  } catch (e) { if (e && e.login) throw e; }
  const rows = [...all.values()], f = rows[0];
  B.log(AG, `statusi: ${rows.length} bildes (${src})` + (f ? `; paraugs: ${f.id}, "${f.file}", ${f.status}` : ""));
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
