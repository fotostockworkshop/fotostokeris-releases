/* Pond5: www.pond5.com — pēdējās pārdošanas (JSON ar X-Access-Token no lapas) un atlikums */
async function collect() {
  if (!/(^|\.)pond5\.com$/.test(location.hostname)) throw LOGIN;
  for (let i = 0; i < 50 && !window.token_header; i++) await sleep(200);
  if (!window.token_header) throw LOGIN;
  const H = Object.assign({}, window.token_header);
  const sales = await getj("/ajax/dashboard/sales", H);
  const items = (sales && sales.items) || [];
  const rows = items.map((x) => ({
    day: String(x.createdAt || "").slice(0, 10), ts: String(x.createdAt || "").replace(" ", "T").slice(0, 19),
    id: String(x.itemId || ""), title: x.isOneOff ? (x.oneOffTitle || "Additional revenue") + " " + (x.name || "") : x.name,
    thumb: x.isOneOff ? "" : x.previewUrl, url: x.link, amount: +x.amount || 0, cnt: x.isOneOff ? 0 : 1,
    kind: x.isOneOff ? "other" : "sale" })).filter((r) => r.day);
  const start = rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today;
  await sendRows(rows, { start, end: today });
  try {
    const b = await getj("/ajax/user/balance", H);
    const t = ((b && b.info) || []).find((x) => x.id === "total");
    if (t) await send("balance", { amount: +t.amount || 0, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: automātiskas ~15. datumā; financials/<gads>/<mēn> → lastPayoutDate/Amount, accountBalance */
  await payoutsSafe(async () => {
    const ty = +today.slice(0, 4), tm = +today.slice(5, 7);
    const pfull = !!OPTS.payouts_full;
    const from = pfull ? new Date(2018, 0, 1) : new Date(ty, tm - 1 - 3, 1);
    /* financials katrā mēnesī rāda to pašu "pēdējo izmaksu" (2026-10-29: cikls līdz 2012 deva 1 izmaksu, 1 min) —
       tāpēc tikai pēdējie mēneši; vēsture krājas pamazām. Pilnai vēsturei jāatrod cits avots. */
    const months = monthsBack(from.getFullYear(), from.getMonth() + 1, ty, tm);
    const seen = new Map();
    let empty = 0, first = true;
    for (const [y, m] of months) {
      let j;
      try { j = await getj(`/ajax/user-account/financials/${y}/${pad(m)}`, H); } catch (e) { if (e && e.login) throw e; break; }
      const sm = (j && j.financials && j.financials.summary) || {};
      if (first) { first = false; if (sm.accountBalance != null) await sendPayInfo({ unpaid: +sm.accountBalance || 0, currency: "USD" }); }
      const d = pdate(sm.lastPayoutDate || "");
      if (d && sm.lastPayoutAmount) seen.set(d, Math.abs(+sm.lastPayoutAmount));
      /* test44: mēneša "Total Payout Activity" (lietotājs 2026-10-30) — izmaksa šajā mēnesī (~15. datumā) */
      let act = null;
      for (const k in sm) if (/payout/i.test(k) && !/last|date/i.test(k) && !isNaN(parseFloat(sm[k])) && Math.abs(parseFloat(sm[k])) > 0.004) { act = Math.abs(parseFloat(sm[k])); break; }
      if (y === ty && m === tm && !OPTS.__p5keys) { OPTS.__p5keys = 1; B.log(AG, "izmaksas: financials summary atslēgas: " + keysOf(sm)); }
      /* 2026-11-08 (pārbaudīts ar PayPal): summary.totalPayout < 0 = izmaksa (accountEarnings datums), > 0 = ienākums
         (abonements u.c., NAV izmaksa). Visa vēsture: 10 izmaksas 2020-12…2025-12 sakrīt ar PayPal. */
      void act;
      if (+sm.totalPayout < 0) {
        const ae = ((j.financials.accountEarnings || []).find((a) => +a.profit < 0) || {});
        const dd = pdate(ae.createdAt || "") || `${y}-${pad(m)}-15`;
        seen.set(dd, Math.abs(+sm.totalPayout));
      }
      if (!(j && j.financials && ((j.financials.clipSales || []).length || sm.totalEarnings))) { if (!pfull && ++empty >= 18) break; } else empty = 0;
      await sleep(200);
    }
    /* pilnai vēsturei — izpēte (žurnālā atslēgas): citi iespējamie avoti */
    if (OPTS.payouts_full || seen.size < 2) {
      for (const u of ["/ajax/user-account/payouts", "/ajax/user/payouts", "/ajax/user-account/payout-history"]) {
        try { const j = await getj(u, H); B.log(AG, `izmaksas: ${u} atslēgas: ${keysOf(j)}`); }
        catch (e) { if (e && e.login) { B.log(AG, `izmaksas: ${u} — nav`); continue; } B.log(AG, `izmaksas: ${u} — ${((e && e.message) || e).toString().slice(0, 80)}`); }
      }
    }
    const rows = [...seen].map(([date, amount]) => ({ date, amount, currency: "USD" })).sort((a, b) => (a.date < b.date ? 1 : -1));
    /* aizstāj no vecākās redzētās izmaksas (pēdējās zināmās) — tā izzūd agrāk kļūdaini ierakstītās "izmaksas" */
    const st = rows.length ? rows[rows.length - 1].date : null;
    await sendPayouts(rows, pfull && rows.length > 1 ? { full: true } : (st ? { full: false, start: st } : { full: false }));
  });
  if (OPTS.sub_due) { try { await p5Status(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["storefront (Photos+Illustrations+Videos)", async () => {
      /* paša autora veikals pond5.com/artist/<vārds> — vārdu ņemam no lapas saites, kodā to nerakstām */
      const RE = /(\d[\d,]*)\s+(?:Photos|Illustrations|Videos|Music|Sound Effects|3D Models|After Effects)\b/i;
      let u = hrefOf(document, /storefront|my profile|view profile|portfolio/i, /\/artist\//) || hrefOf(document, /./, /\/artist\//);
      if (!u) { const d = await getdoc("/my-recent-sales"); u = hrefOf(d, /storefront|my profile|portfolio/i, /\/artist\//) || hrefOf(d, /./, /\/artist\//); }
      if (!u) { B.log(AG, "portfelis: veikala (artist) saite nav atrasta"); return null; }
      return sumAll(txt((await getdoc(u)).body), RE) || framed(u, (t) => sumAll(t, RE));
    }],
    ["dashboard", async () => countKey(sales, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["user/portfolio", () => portJson("/ajax/user/portfolio", H)],
    ["dashboard/stats", () => portJson("/ajax/dashboard/stats", H)],
  ]);
  return { rows: rows.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /index.php?page=my_uploads — filtrs STATUS (Processing, Needs Edits,
   Pending, Online, Rejected, Returned), TYPE (Photo), MAX PER PAGE 100; tabula ID | TITLE | DESCRIPTION | … | STATUS
   ("PENDING REVIEW", "ONLINE", "REJECTED", "RETURNED"). Faila nosaukuma sarakstā nav — sasaiste pēc virsraksta.
   Online — tikai 1. lapa (jaunākās). Filtru maina rāmī (izvēlne + Search), jo adrese nemainās. */
async function p5Status() {
  /* test54 (izpēte iebūvētajā pārlūkā 2026-11-12): filtrs ir forma POST /index.php?page=my_uploads (prefs_submit=Search,
     status=-2|21|20|30|22|25, max_per_page=100, media_type=16) — atbildē tabula ar rindām: ID | TITLE (saīsināts "..") | DESCRIPTION | …
     | STATUS. Rāmī izvēlnes maiņa nedeva rindas (0). Forma saglabā lietotāja filtru — beigās atjaunojam iepriekšējo. */
  const WANT = [["21", "Needs Edits"], ["20", "Pending"], ["-2", "Processing"], ["22", "Rejected"], ["25", "Returned"], ["30", "Online"]];
  const all = new Map();
  let prev = null;
  const post = async (st) => {
    const b = new URLSearchParams({ prefs_submit: "Search", kux_filter_search: "", status: st, in_public_bin: "-1", max_per_page: "100", media_type: "16" });
    const r = await fetch("/index.php?page=my_uploads", { method: "POST", body: b, credentials: "include" });
    if (!r.ok) throw new Error("HTTP " + r.status);
    return new DOMParser().parseFromString(await r.text(), "text/html");
  };
  try {                                                          // lietotāja pašreizējais filtrs (lai beigās atjaunotu)
    const d0 = new DOMParser().parseFromString(await (await fetch("/index.php?page=my_uploads", { credentials: "include" })).text(), "text/html");
    const o = d0.querySelector("select[name=status] option[selected]"); prev = o ? o.value : null;
  } catch (e) { /* nav */ }
  /* test63 (Chrome 2026-11-14): lapā ≤100 rindas (jaunākās augšā); nākamās — GET ?page=my_uploads&at_page=N (0 = pirmā) ar saglabāto filtru.
     Online agrāk tikai pirmās 100 → daļa komplektu bilžu (Nov 5–6) tabulā trūka. Lasām līdz 5 lapām (Online) / 3 (pārējās). */
  const page = async (n) => new DOMParser().parseFromString(await (await fetch("/index.php?page=my_uploads&at_page=" + n, { credentials: "include" })).text(), "text/html");
  for (const [st, raw] of WANT) {
    let n = 0;
    try {
      for (let pg = 0, more = true; more && pg < (st === "30" ? 5 : 3); pg++) {
      const d = pg ? await page(pg) : await post(st);
      let got = 0;
      for (const tr of d.querySelectorAll("tr")) {
        const c = [...tr.children].map((td) => (td.textContent || "").replace(/\s+/g, " ").trim());
        const id = c.find((x) => /^\d{8,10}$/.test(x));
        if (!id || all.has(id)) continue;
        const k = c.indexOf(id), stt = c.find((x) => /^(Pending review|Online|Rejected|Returned|Processing|Needs edits)$/i.test(x)) || raw;
        all.set(id, { id, file: "", title: (c[k + 1] || "").replace(/\.{2,}$/, "").slice(0, 250), submitted: "", status: /^returned$/i.test(stt) ? "Returned (jālabo)" : stt });
        n++; got++;
      }
      more = got >= 100;
      if (more) await sleep(400);
      }
    } catch (e) { B.log(AG, `statusi: ${raw} — ${String((e && e.message) || e).slice(0, 80)}`); }
    B.log(AG, `statusi: ${raw} — ${n} bildes`);
    await sleep(500);
  }
  try { if (prev) await post(prev); } catch (e) { /* filtrs paliek */ }
  const rows = [...all.values()], cnt = {};
  for (const r of rows) cnt[r.status] = (cnt[r.status] || 0) + 1;
  B.log(AG, `statusi: ${rows.length} bildes ${JSON.stringify(cnt)}`);
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
