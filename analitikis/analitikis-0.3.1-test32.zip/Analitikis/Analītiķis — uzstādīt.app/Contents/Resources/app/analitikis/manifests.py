"""Vārdotāja manifesti → "Manas bildes aģentūrās" (portfeļa modulis; lietotājs 2026-11-09:
"vārdotājs speciāli šim mērķim gatavo manifestu, sīktēlu un digitālo nospiedumu. Jaunajām bildēm būtu jānolasās 100%").

Kur meklē (noteikumi, dati §7a): iestatījums `sales_manifest_dir`; citādi Vārdotāja iestatījumi tajā pašā datorā
(`<datu mapes vecāks>/Vardotajs/settings.json`: `manifest_dir`, citādi `<ready_dir>/Manifesti`), citādi `Vardotajs/Manifesti`;
papildus Vārdotāja `manifests.json` (sēriju mapes ar `.fotostokeris/` / `_fotostokeris/`).
Moduļi viens otru neimportē — lasām tikai failus.
Google Drive (test32, dati §7a (c)): ja Google konts pieslēgts — `core.manifests_drive.pull` uz datu mapi `Manifesti-drive/`
(ne biežāk kā ik 15 min; poga "Pārlasīt" — uzreiz). Manifestus ar `"kind": "set"` (Tirgotāja komplekti) neskaita.
Pēc sasaistes — `agenturas_bildes.json` Tirgotājam (datu mapē + Drive `Fotostokeris/Kopigi/`, dati §8c).

Sasaiste katrai aģentūrai (sub_status statusi + assets pārdošanas):
  1) faila nosaukums (`<kods>_<oriģinālais>` vai oriģinālais) — drošākais;
  2) virsraksts (≥ 25 zīmes, vienāds) — Vārdotāja virsraksts nonāk aģentūrā;
  3) vizuālais nospiedums — Analītiķis pats rēķina no manifesta sīktēliem (`-sikteli.zip`) ar lookalike.dhash
     (tā pati metode kā aģentūru sīktēliem; manifesta `phash` rēķināts bez malu apgriešanas, tāpēc to nelieto).
"""
from __future__ import annotations

import datetime as dt
import io
import json
import os
import re
import zipfile
from pathlib import Path

from . import config, db

SCHEMA = """
CREATE TABLE IF NOT EXISTS own_images(stem TEXT PRIMARY KEY, file TEXT, series TEXT, series_id TEXT, title TEXT,
  category TEXT, status TEXT, taken_at TEXT, width INT, height INT, dh TEXT, updated TEXT, src TEXT);
CREATE TABLE IF NOT EXISTS own_links(stem TEXT, agency TEXT, agency_item_id TEXT, how TEXT,
  PRIMARY KEY(stem, agency, agency_item_id));
"""
EXPORT = "agenturas_bildes.json"
PULL_EVERY = 900         # s — Drive manifestu pārbaude
HASH_DIST = 5            # nospiedums: stingri (tā pati bilde, cits sīktēla izmērs/kvalitāte)


def ensure(c) -> None:
    c.executescript(SCHEMA)
    if "orig" not in {r[1] for r in c.execute("PRAGMA table_info(own_images)")}:
        c.execute("ALTER TABLE own_images ADD COLUMN orig TEXT")


def drive_dir() -> Path:
    return Path(config.app_dir()) / "Manifesti-drive"


def pull(force: bool = False) -> dict | None:
    """Jaunākie manifesti no Google Drive `Fotostokeris/Manifesti/` (tikai, ja Google konts pieslēgts)."""
    try:
        from core import google, manifests_drive
        if not google.connected():
            return None
    except Exception:
        return None
    last = db.get_state("", "own_pull") or ""
    try:
        if not force and last and (dt.datetime.now() - dt.datetime.fromisoformat(last)).total_seconds() < PULL_EVERY:
            return None
    except ValueError:
        pass
    try:
        r = manifests_drive.pull(drive_dir())
        print(f"manifesti no Google Drive: jauni {r.get('new')}, kopā {r.get('total')}")
    except Exception as e:
        print("manifesti no Google Drive:", str(e)[:200])
        r = None
    db.set_state("", "own_pull", dt.datetime.now().isoformat(timespec="seconds"))
    return r


def _vard_dir() -> Path:
    return Path(config.app_dir()).parent / "Vardotajs"


def dirs() -> list[str]:
    out: list[str] = []
    own = str(config.get("sales_manifest_dir") or "").strip()
    if own:
        out.append(own)
    vd = _vard_dir()
    try:
        s = json.loads((vd / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        s = {}
    md, rd = str(s.get("manifest_dir") or "").strip(), str(s.get("ready_dir") or "").strip()
    if md:
        out.append(md)
    if rd:
        out.append(os.path.join(rd, "Manifesti"))
    out.append(str(vd / "Manifesti"))
    out.append(str(drive_dir()))
    try:                                                     # sēriju mapes, kuras Vārdotājs pierakstījis
        idx = json.loads((vd / "manifests.json").read_text(encoding="utf-8"))
        for v in (idx.values() if isinstance(idx, dict) else idx):
            p = v.get("path") if isinstance(v, dict) else v
            if isinstance(p, str) and p:
                out.append(os.path.dirname(p) if p.endswith(".json") else p)
    except (OSError, ValueError, AttributeError):
        pass
    seen, res = set(), []
    for d in out:
        for sub in (d, os.path.join(d, ".fotostokeris"), os.path.join(d, "_fotostokeris")):
            k = os.path.normcase(os.path.abspath(sub))
            if k not in seen and os.path.isdir(sub):
                seen.add(k)
                res.append(sub)
    return res


def _files() -> list[str]:
    found: dict[str, str] = {}
    for d in dirs():
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in names:
            if n.endswith(".json") and not n.startswith(".") and n != "manifests.json":
                p = os.path.join(d, n)
                try:
                    j = json.load(open(p, encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                if not isinstance(j, dict) or "images" not in j or j.get("kind") == "set":
                    continue                                  # Tirgotāja komplekti — tās pašas bildes, neskaita
                sid = str(j.get("series_id") or p)
                if sid not in found or os.path.getmtime(p) > os.path.getmtime(found[sid]):   # jaunākā kopija uzvar
                    found[sid] = p
    # sērijas ar skaidru "kind": "series" pirmās — ja bilde vecā manifestā bez "kind" atkārtojas, uzvar sērija
    def _explicit(p):
        try:
            return 0 if json.load(open(p, encoding="utf-8")).get("kind") == "series" else 1
        except (OSError, ValueError):
            return 1
    return sorted(found.values(), key=_explicit)


def _key(name: str) -> str:
    b = os.path.basename(str(name or "")).strip().lower()
    return re.sub(r"\.(jpe?g|tiff?|png|eps|ai|svg|psd|dng|cr2|cr3|nef|arw|raf|orf|heic|mov|mp4)$", "", b)


def _orig(k: str) -> str:
    return re.sub(r"^[0-9a-f]{4}_", "", k)                   # bez Vārdotāja koda "d738_"


def scan(force: bool = False) -> dict:
    """Ielasa manifestus (bildes + nospiedumi no sīktēliem) un piesaista aģentūru ierakstus. Ātri; var saukt bieži."""
    from . import lookalike
    pull(force)
    files = _files()
    now = dt.datetime.now().isoformat(timespec="seconds")
    imgs = 0
    seen: set[str] = set()
    with db._lock:
        c = db.conn()
        ensure(c)
        known = {r[0]: (r[1], r[2]) for r in c.execute("SELECT stem, updated, dh FROM own_images")}
    for p in files:
        try:
            j = json.load(open(p, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        zpath = p[:-5] + "-sikteli.zip"
        try:
            zf = zipfile.ZipFile(zpath) if os.path.exists(zpath) else None
        except (OSError, zipfile.BadZipFile):
            zf = None
        rows = []
        for im in j.get("images") or []:
            stem = str(im.get("stem") or "").strip()
            if not stem or im.get("status") == "moved" or stem in seen:
                continue
            seen.add(stem)
            upd = str(im.get("updated") or "")
            dh = None
            old = known.get(stem)
            if old and old[0] == upd and old[1]:
                dh = old[1]
            elif zf:
                try:
                    dh = lookalike.dhash(zf.read(stem + ".jpg"))
                except (KeyError, OSError, zipfile.BadZipFile):
                    dh = None
            rows.append((stem, im.get("file") or "", j.get("name") or "", j.get("series_id") or "", im.get("title") or "",
                         im.get("category") or "", im.get("status") or "", im.get("taken_at") or "",
                         im.get("width"), im.get("height"), dh, upd, p, im.get("orig_file") or ""))
        if zf:
            zf.close()
        with db._lock:
            c = db.conn()
            c.executemany("INSERT OR REPLACE INTO own_images(stem,file,series,series_id,title,category,status,taken_at,"
                          "width,height,dh,updated,src,orig) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            c.commit()
        imgs += len(rows)
    if files:                                                # bildes, kuru vairs nav nevienā manifestā
        with db._lock:
            c = db.conn()
            gone = [r[0] for r in c.execute("SELECT stem FROM own_images") if r[0] not in seen]
            c.executemany("DELETE FROM own_images WHERE stem=?", [(g,) for g in gone])
            c.commit()
    n = link()
    print(f"manifesti: {len(files)} sērijas, {imgs} bildes, sasaistes {n}")
    db.set_state("", "own_scan", now)
    try:
        export()
    except Exception as e:
        print("agenturas_bildes.json:", str(e)[:200])
    return {"series": len(files), "images": imgs, "links": n, "dirs": dirs()}


def link() -> int:
    """Sasaiste: faila nosaukums → virsraksts → nospiedums. Katrai bildei katrā aģentūrā — labākais."""
    from . import lookalike
    with db._lock:
        c = db.conn()
        ensure(c)
        own = [dict(r) for r in c.execute("SELECT stem, file, title, dh FROM own_images")]
        if not own:
            return 0
        by_key, by_title = {}, {}
        for o in own:
            for k in {_key(o["stem"]), _key(o["file"]), _orig(_key(o["stem"])), _orig(_key(o["file"]))}:
                if len(k) >= 5:
                    by_key.setdefault(k, o["stem"])
            t = (o["title"] or "").strip().lower()
            if len(t) >= 25:
                by_title.setdefault(t[:25], []).append((t, o["stem"]))   # prefikss — aģentūras saīsina (Dreamstime ~40 zīmes)
        cand = []                                            # (agency, item_id, file, title, thumb_hash)
        for r in c.execute("SELECT agency, item_id, file_name, title FROM sub_status"):
            cand.append((r[0], r[1], r[2], r[3], None))
        hashes = {(r[0], r[1]): r[2] for r in c.execute("SELECT agency, agency_item_id, h FROM thumb_hash WHERE h!=''")}
        for r in c.execute("SELECT agency, agency_item_id, filename, title FROM assets WHERE COALESCE(media,'') NOT IN ('other','month')"):
            cand.append((r[0], r[1], r[2], r[3], hashes.get((r[0], r[1]))))
        dh_own = [(o["stem"], o["dh"]) for o in own if o["dh"]]
        links = {}
        for ag, iid, fn, ti, h in cand:
            stem, how = None, ""
            k = _key(fn)
            if k and (k in by_key or _orig(k) in by_key):
                stem, how = by_key.get(k) or by_key.get(_orig(k)), "fails"
            elif ti and len(ti.strip()) >= 25 and ti.strip().lower()[:25] in by_title:
                tt = ti.strip().lower().rstrip("….").strip()
                hit = [st for full, st in by_title[tt[:25]] if full == tt or full.startswith(tt)]
                if len(hit) == 1:                                  # tikai viennozīmīgi
                    stem, how = hit[0], "virsraksts"
            elif h and dh_own:
                best = min(((lookalike.dist(h, d), s) for s, d in dh_own), default=(99, None))
                if best[0] <= HASH_DIST:
                    stem, how = best[1], "nospiedums"
            if stem:
                links[(stem, ag, str(iid))] = how
        c.execute("DELETE FROM own_links")
        c.executemany("INSERT OR REPLACE INTO own_links VALUES(?,?,?,?)", [(s, a, i, h) for (s, a, i), h in links.items()])
        c.commit()
        return len(links)


def table(series: str | None = None) -> dict:
    """Sērijas ar bilžu skaitu un katrā aģentūrā: pieņemtas / pārbaudē / noraidītas / jālabo / pārdotas (+ summa).
    Ar `series` — šīs sērijas bildes ar statusu katrā aģentūrā."""
    with db._lock:
        c = db.conn()
        ensure(c)
        imgs = [dict(r) for r in c.execute("SELECT stem, file, series, series_id, title, category, status, taken_at FROM own_images"
                                           + (" WHERE series_id=?" if series else ""), ((series,) if series else ()))]
        st = {}
        for r in c.execute("""SELECT l.stem, l.agency, s.status FROM own_links l
                              JOIN sub_status s ON s.agency=l.agency AND s.item_id=l.agency_item_id"""):
            st[(r[0], r[1])] = r[2]
        sold = {}
        for r in c.execute("""SELECT l.stem, l.agency, ROUND(SUM(x.amount_usd),2), SUM(x.cnt) FROM own_links l
                              JOIN sales x ON x.agency=l.agency AND x.agency_item_id=l.agency_item_id GROUP BY 1,2"""):
            sold[(r[0], r[1])] = (r[2] or 0, r[3] or 0)
        linked = {(r[0], r[1]) for r in c.execute("SELECT stem, agency FROM own_links")}
    ags = sorted({a for _, a in linked} | {a for _, a in st})
    def cell(stem, ag):
        s = st.get((stem, ag)) or ("accepted" if (stem, ag) in sold else ("linked" if (stem, ag) in linked else None))
        e, n = sold.get((stem, ag), (0, 0))
        return {"s": s, "e": e, "n": n}
    if series:
        return {"agencies": ags, "rows": [{**i, "cells": {a: cell(i["stem"], a) for a in ags}} for i in sorted(imgs, key=lambda x: x["stem"])]}
    ser = {}
    for i in imgs:
        g = ser.setdefault(i["series_id"], {"series_id": i["series_id"], "name": i["series"], "n": 0, "taken": "", "ag": {}})
        g["n"] += 1
        g["taken"] = max(g["taken"], i["taken_at"] or "")
        for a in ags:
            x = cell(i["stem"], a)
            if x["s"]:
                z = g["ag"].setdefault(a, {"accepted": 0, "review": 0, "rejected": 0, "changes": 0, "linked": 0, "other": 0, "sold": 0, "e": 0.0})
                z[x["s"] if x["s"] in z else "other"] += 1
                if x["n"] or x["e"]:
                    z["sold"] += 1
                    z["e"] = round(z["e"] + x["e"], 2)
    return {"agencies": ags, "series": sorted(ser.values(), key=lambda g: g["taken"], reverse=True), "dirs": dirs()}


def export() -> dict:
    """`agenturas_bildes.json` Tirgotājam (dati §8c): manifestu bildes, kas atrastas aģentūrās, ar statusu katrā."""
    from core import config as cc, sync as _sync
    today = dt.date.today().isoformat()
    with db._lock:
        c = db.conn()
        ensure(c)
        imgs = {r[0]: {"stem": r[0], "orig_file": r[1] or "", "series_id": r[2] or "", "agencies": {}}
                for r in c.execute("SELECT stem, orig, series_id FROM own_images")}
        st = {(r[0], str(r[1])): (r[2], (r[3] or "")[:10]) for r in c.execute("SELECT agency, item_id, status, seen_at FROM sub_status")}
        links = c.execute("SELECT stem, agency, agency_item_id FROM own_links").fetchall()
    rank = {"accepted": 5, "review": 4, "changes": 3, "other": 2, "rejected": 1}
    for stem, ag, iid in links:
        im = imgs.get(stem)
        if not im:
            continue
        s, seen = st.get((ag, str(iid)), ("accepted", today))   # tikai pārdošanās / portfelī → pārdošanā
        old = im["agencies"].get(ag)
        if not old or rank.get(s or "other", 2) > rank.get(old["status"], 2):
            im["agencies"][ag] = {"status": s or "other", "item_id": str(iid), "seen": seen or today}
    out = [i for i in imgs.values() if i["agencies"]]
    d = {"format": 1, "updated": dt.datetime.now().isoformat(timespec="seconds"), "computer": _sync.computer(),
         "images": sorted(out, key=lambda i: i["stem"])}
    data = json.dumps(d, ensure_ascii=False).encode("utf-8")
    (cc.app_dir() / EXPORT).write_bytes(data)
    where = "datu mapē"
    try:
        from core import google
        if google.connected():
            fid = google.folder("Kopigi")
            old = next((f["id"] for f in google.list_files(fid) if f["name"] == EXPORT), None)
            google.put_bytes(fid, EXPORT, data, old)
            where += " un Google Drive Fotostokeris/Kopigi"
    except Exception as e:
        print("agenturas_bildes.json: Google Drive —", str(e)[:120])
    db.set_state("", "own_export", d["updated"])
    db.set_state("", "own_export_data", db.data_at())
    print(f"agenturas_bildes.json: {len(out)} bildes — {where}")
    return {"images": len(out), "where": where}


def start() -> None:
    """Fonā: ~3 min pēc palaišanas un tad ik 5 min — ja aģentūru dati mainījušies (un atjaunošana nenotiek) vai pienācis
    laiks pārbaudīt Drive manifestus → pārlasa, sasaista un atjauno `agenturas_bildes.json`."""
    import threading
    import time

    def loop():
        time.sleep(180)
        while True:
            try:
                from . import sync as _s
                if not _s.active():
                    changed = (db.data_at() or "") != (db.get_state("", "own_export_data") or "")
                    last = db.get_state("", "own_pull") or ""
                    due = not last or (dt.datetime.now() - dt.datetime.fromisoformat(last)).total_seconds() >= PULL_EVERY
                    if changed or due:
                        scan()
            except Exception as e:
                print("manifesti fonā:", str(e)[:200])
            time.sleep(300)
    threading.Thread(target=loop, daemon=True, name="own").start()
