/* Envato Elements: author.envato.com/reports */
async function collect() {
  if (location.hostname !== "author.envato.com") throw LOGIN;
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (!/^\/reports/.test(location.pathname) || !meta) {
    location.href = "https://author.envato.com/reports/earnings";
    return { navigated: true };
  }
  const H = { "Content-Type": "application/json", "X-CSRF-Token": meta.getAttribute("content") };
  const R = (u) => getj("/reports/api/v1/" + u, H);

  say("total", 5);
  const tot = await R("earnings/total");
  if (!tot || !tot.data) throw LOGIN;
  const first = (tot.data.first_record_date || "2022-07-01").slice(0, 10);

  say("monthly", 10);
  const mon = await R(`earnings/detail?view=monthly&start_date=${first}&end_date=${today}`);
  await send("monthly", { rows: mon.data || [] });

  const dfirst = (mon.daily_first_record_date || first).slice(0, 10);
  const dstart = OPTS.mode === "full" ? dfirst : (OPTS.since > dfirst ? OPTS.since : dfirst);
  say("daily", 20);
  const day = await R(`earnings/detail?view=daily&start_date=${dstart}&end_date=${today}`);
  await send("daily", { start: dstart, end: today, rows: day.data || [] });

  /* vienumu ienākumi pa mēnešiem */
  const md = await R("performance/meta_data?shopfront=Elements");
  const ef = (md.earliest_record_date || dfirst).slice(0, 10), el = (md.latest_record_date || today).slice(0, 10);
  let months = monthsBack(+ef.slice(0, 4), +ef.slice(5, 7), +el.slice(0, 4), +el.slice(5, 7));
  if (OPTS.mode !== "full") months = months.slice(0, 3);
  for (let i = 0; i < months.length; i++) {
    const [y, m] = months[i];
    const ms = `${y}-${String(m).padStart(2, "0")}`;
    const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    const s = `${ms}-01` < ef ? ef : `${ms}-01`, e = last > el ? el : last;
    let page = 1, pages = 1;
    do {
      say(`${ms} · ${page}/${pages}`, 25 + Math.round((i / months.length) * 70));
      const q = new URLSearchParams({ shopfront: "Elements", start_date: s, end_date: e, sort_by: "total_earnings",
        sort_direction: "desc", new_item_only: "false", page: String(page) });
      const j = await R("performance/item_performance?" + q);
      pages = Math.max(1, j.total_pages || 1);
      const rows = j.data || [];
      const stop = !rows.length || rows.every((r) => !(+r.total_earnings));   // kārtots dilstoši — tālāk tikai nulles
      await send("items", { month: ms, page, rows, shopfront: "Elements", last: i === months.length - 1 && (page >= pages || stop) });
      if (stop) break;
      page++;
    } while (page <= pages && page < 200);
  }
  /* Envato Market (tie paši autora dati): vienumu ienākumi pa mēnešiem, ja portāls tos dod */
  try {
    const mm = await R("performance/meta_data?shopfront=Market");
    const mf = ((mm && mm.earliest_record_date) || "").slice(0, 10), ml = ((mm && mm.latest_record_date) || today).slice(0, 10);
    if (mf) {
      let mlist = monthsBack(+mf.slice(0, 4), +mf.slice(5, 7), +ml.slice(0, 4), +ml.slice(5, 7));
      if (OPTS.mode !== "full" && sales_state_market_done()) mlist = mlist.slice(0, 3);
      let n = 0;
      for (let i = 0; i < mlist.length; i++) {
        const [y, m] = mlist[i];
        const ms = `${y}-${String(m).padStart(2, "0")}`;
        const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
        const s = `${ms}-01` < mf ? mf : `${ms}-01`, e = last > ml ? ml : last;
        let page = 1, pages = 1;
        do {
          say(`Market ${ms} · ${page}/${pages}`, 95);
          const q = new URLSearchParams({ shopfront: "Market", start_date: s, end_date: e, sort_by: "total_earnings",
            sort_direction: "desc", new_item_only: "false", page: String(page) });
          const j = await R("performance/item_performance?" + q);
          pages = Math.max(1, j.total_pages || 1);
          const rows = j.data || [];
          const stop = !rows.length || rows.every((r) => !(+r.total_earnings));
          n += rows.length;
          await send("items", { month: ms, page, rows, shopfront: "Market", last: i === mlist.length - 1 && (page >= pages || stop) });
          if (stop) break;
          page++;
        } while (page <= pages && page < 200);
      }
      B.log(AG, `Envato Market: ${mlist.length} mēneši, ${n} vienumu rindas`);
    } else B.log(AG, "Envato Market: vienumu datu nav");
  } catch (e) { if (e && e.login) throw e; B.log(AG, "Envato Market vienumi: " + ((e && e.message) || e)); }
  await portfolioSafe([
    ["Portfolio Manager (Approved for Sale)", async () => {
      const RE = /Approved for Sale\s*\(\s*(\d[\d,]*)\s*\)/i, f = (t) => { const m = t.match(RE); return m ? numOf(m[1]) : null; };
      const u = hrefOf(document, /portfolio manager|my items|^items$|portfolio/i, /author\.envato\.com|^\//);
      for (const p of [u, "/portfolio", "/items", "/my-items"].filter(Boolean)) {
        const n = await framed(p, f, 15000);
        if (n) return n;
      }
      return null;
    }],
    ["meta_data", async () => countKey(md, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["total", async () => { const n = countKey(tot && tot.data, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: total atslēgas: " + keysOf(tot && tot.data)); return n; }],
  ]);
  return { months: months.length };
}
function sales_state_market_done() { return !!OPTS.market_done; }
