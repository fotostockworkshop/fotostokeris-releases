/* Magnific (bij. Freepik): contributor.magnific.com/xhr — ienākumi (EUR) un lejupielādes pa dienām */
async function collect() {
  if (location.hostname === "taxcenter.magnific.com") return taxcenter();
  if (location.hostname !== "contributor.magnific.com") throw LOGIN;
  const XH = { "X-Requested-With": "XMLHttpRequest" };
  const user = await getj("/xhr/user", XH);
  if (!user || user.success === false) throw LOGIN;
  const S = (fmt, a, b) => getj(`/xhr/stats?format=${fmt}&license=all&typeFile=all&dateStart=${a}&dateEnd=${b}`, XH);
  const ser = (j, re) => ((((j || {}).data || {}).series || []).find((s) => re.test(s.name)) || {}).data || [];

  /* mēneši ar ienākumiem */
  say("mēneši", 3);
  const mon = await S("monthly", "2015-01-01", today);
  const cats = ((mon || {}).data || {}).categories || [];
  const rev = ser(mon, /revenue/i);
  const months = [];
  for (let i = 0; i < rev.length; i++) {
    let m = cats[i] ? (String(cats[i]).match(/(\d{4})-(\d{2})/) || [])[0] : "";
    if (!m) {                                       // bez etiķetēm: pēdējā vērtība = šis mēnesis
      const d = new Date(+today.slice(0, 4), +today.slice(5, 7) - 1 - (rev.length - 1 - i), 15);
      m = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    }
    if (+rev[i] > 0) months.push(m);
  }
  const cur = today.slice(0, 7);
  if (!months.includes(cur)) months.push(cur);
  let list = months.sort().reverse();
  if (OPTS.mode !== "full") list = list.filter((m) => m >= OPTS.since.slice(0, 7));

  for (let i = 0; i < list.length; i++) {
    const m = list[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(m, 5 + Math.round((i / list.length) * 90));
    const end = monthEnd(y, mo) < today ? monthEnd(y, mo) : today;
    const d = await S("daily", `${m}-01`, end);
    const dc = ((d || {}).data || {}).categories || [];
    const r = ser(d, /revenue/i), prem = ser(d, /premium/i), free = ser(d, /free/i);
    const days = dc.map((day, k) => ({ day: pdate(day), cat: "premium", e: +r[k] || 0, n: (+prem[k] || 0) + (+free[k] || 0) }))
      .filter((x) => x.day);
    await send("days", { start: `${m}-01`, end, currency: "EUR", days });
    await sleep(200);
  }
  const PUB = (t) => { const m = String(t || "").match(/Published\s*(\d[\d,]*)/i); return m ? numOf(m[1]) : null; };
  await portfolioSafe([
    ["izvēlne (Published)", async () => PUB(document.body && document.body.innerText) || framed("/", PUB)],
    ["user", async () => { const n = countKey(user, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: user atslēgas: " + keysOf(user && (user.data || user))); return n; }],
    ["resources/data", () => portJson("/xhr/resources/data", XH)],
    ["resources", () => portJson("/xhr/resources?page=1&limit=1", XH)],
    ["stats/resources", () => portJson("/xhr/stats/resources", XH)],
  ]);
  /* izmaksas — atsevišķā vietnē taxcenter.magnific.com (lietotājs 2026-10-30): pāriet uz turieni, tur skripts turpina */
  if (OPTS.payouts_full || OPTS.pay_due) {
    try { sessionStorage.setItem("__vdMagTax", String(Date.now())); } catch (_) { /* */ }
    say("izmaksas", 97);
    location.href = "https://taxcenter.magnific.com/";
    return { navigated: true };
  }
  return { months: list.length };
}

/* Tax center → Invoices: "Paid Invoices" (datums | numurs | summa €) un "Pending Invoices" */
async function taxcenter() {
  const RE = /(\d{4}-\d{2}-\d{2})\s+(FR-[\w.-]+)\s+([\d.,]+)\s*€/g;
  let t = "";
  for (let i = 0; i < 40; i++) { t = (document.body && document.body.innerText) || ""; if (RE.test(t) || /no pending invoices/i.test(t) && /paid invoices/i.test(t) && i > 10) break; RE.lastIndex = 0; await sleep(500); }
  RE.lastIndex = 0;
  const rows = [], seen = new Set();
  const grab = () => { let m; const s = (document.body && document.body.innerText) || ""; const g = new RegExp(RE.source, "g"); let n = 0;
    while ((m = g.exec(s))) { if (seen.has(m[2])) continue; seen.add(m[2]); n++; rows.push({ date: m[1], amount: money(m[3]), currency: "EUR", ref: m[2] }); } return n; };
  grab();
  /* lappuses: "nākamā" poga, ja ir */
  for (let pg = 2; pg <= 20; pg++) {
    const nx = [...document.querySelectorAll("button, a, [role=button]")].find((e) => !e.disabled && e.getAttribute("aria-disabled") !== "true" &&
      (/next/i.test(e.getAttribute("aria-label") || "") || /^\s*(›|>|»|next)\s*$/i.test(e.innerText || "")));
    if (!nx) break;
    nx.click(); await sleep(1500);
    if (!grab()) break;
  }
  const pend = ((document.body && document.body.innerText) || "").match(/Pending Invoices[\s\S]{0,400}?([\d.,]+)\s*€/i);
  if (pend && !/no pending invoices/i.test(pend[0])) await sendPayInfo({ unpaid: money(pend[1]), currency: "EUR" });
  if (!rows.length) B.log(AG, "izmaksas: Tax center — rēķini nav atrasti; teksts: " + ((document.body && document.body.innerText) || "").replace(/\S+@\S+/g, "…").replace(/\d{6,}/g, "N").slice(0, 200));
  await sendPayouts(rows.sort((a, b) => (a.date < b.date ? 1 : -1)), { full: rows.length > 1 });
  await send("pay_checked", {});
  return { payouts: rows.length };
}
