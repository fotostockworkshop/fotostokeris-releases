"""Aģentūru sesiju saglabāšana starp programmas palaišanām (Mac).

Kāpēc: uz Mac (WKWebView) "īslaicīgās" sīkdatnes (bez derīguma termiņa) pazūd, kad process beidzas — aģentūras
(Adobe, Envato) katrā palaišanā redz jaunu ielogošanos un prasa 2FA / apstiprinājumu telefonā. Uz Windows
(WebView2) tās saglabājas pašas, tāpēc tur šis modulis neko nedara.

Kā: pēc veiksmīgas aģentūras atjaunošanas — šīs aģentūras domēnu īslaicīgās sīkdatnes tiek saglabātas datu mapē
(`sessions.bin`), **šifrētas** (SHA-256 atslēgas plūsma + HMAC; atslēga — tikai sistēmas drošajā glabātuvē,
ieraksts "sessions_key", noteikumi §3). Nākamajā palaišanā, pirms aģentūru logi atveras, tās tiek ieliktas atpakaļ
(arī kā īslaicīgas). Vecākas par KEEP_DAYS — netiek lietotas. Žurnālā tikai skaits, ne vērtības.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import threading
import time

from . import config
from . import credentials

FILE = "sessions.bin"
KEEP_DAYS = 30
KEY_NAME = "sessions_key"


def enabled() -> bool:
    return bool(config.IS_MAC) and credentials.available()


# --------------------------------------------------------------------------- šifrēšana

def _key(create: bool) -> bytes | None:
    c = credentials.get(KEY_NAME)
    if c and c[1]:
        try:
            return bytes.fromhex(c[1])
        except ValueError:
            pass
    if not create:
        return None
    k = secrets.token_bytes(32)
    credentials.save(KEY_NAME, "key", k.hex())
    return k


def _stream(key: bytes, nonce: bytes, n: int) -> bytes:
    out = bytearray()
    i = 0
    while len(out) < n:
        out += hashlib.sha256(key + nonce + i.to_bytes(8, "big")).digest()
        i += 1
    return bytes(out[:n])


def _seal(key: bytes, data: bytes) -> bytes:
    nonce = secrets.token_bytes(16)
    ct = bytes(a ^ b for a, b in zip(data, _stream(key, nonce, len(data))))
    tag = hmac.new(key, nonce + ct, hashlib.sha256).digest()
    return b"FSS1" + nonce + tag + ct


def _open(key: bytes, blob: bytes) -> bytes | None:
    if len(blob) < 52 or blob[:4] != b"FSS1":
        return None
    nonce, tag, ct = blob[4:20], blob[20:52], blob[52:]
    if not hmac.compare_digest(tag, hmac.new(key, nonce + ct, hashlib.sha256).digest()):
        return None
    return bytes(a ^ b for a, b in zip(ct, _stream(key, nonce, len(ct))))


# --------------------------------------------------------------------------- fails

def _path():
    return config.app_dir() / FILE


def _read() -> dict:
    """{aģentūra: {"t": laiks, "cookies": [...]}}"""
    try:
        blob = _path().read_bytes()
    except OSError:
        return {}
    key = _key(False)
    raw = _open(key, blob) if key else None
    if raw is None:
        return {}
    try:
        return json.loads(raw.decode("utf-8")) or {}
    except ValueError:
        return {}


_lock = threading.Lock()


def save(agency: str, cookies: list[dict]) -> None:
    with _lock:
        data = _read()
        if cookies:
            data[agency] = {"t": time.time(), "cookies": cookies}
        else:
            data.pop(agency, None)
        key = _key(True)
        p = _path()
        tmp = p.with_suffix(".tmp")
        tmp.write_bytes(_seal(key, json.dumps(data).encode("utf-8")))
        try:
            import os
            os.chmod(tmp, 0o600)
            os.replace(tmp, p)
        except OSError:
            tmp.replace(p)


def load(agencies: list[str] | None = None) -> dict:
    """{aģentūra: [sīkdatnes]} — tikai ne vecākas par KEEP_DAYS."""
    data = _read()
    lim = time.time() - KEEP_DAYS * 86400
    return {a: v.get("cookies") or [] for a, v in data.items()
            if (agencies is None or a in agencies) and float(v.get("t") or 0) >= lim}


def forget() -> None:
    try:
        _path().unlink()
    except OSError:
        pass


# --------------------------------------------------------------------------- Mac (WKWebView sīkdatņu glabātuve)

def _store():
    import WebKit  # type: ignore
    return WebKit.WKWebsiteDataStore.defaultDataStore().httpCookieStore()


def _match(domain: str, hosts: list[str]) -> bool:
    d = (domain or "").lstrip(".").lower()
    return any(d == h or d.endswith("." + h) for h in hosts)


def _on_main(fn, timeout: float):
    """Izpilda fn galvenajā pavedienā (WebKit to prasa — citādi process avarē, 2026-10-29) un gaida, kamēr fn
    pats atbrīvo semaforu (fn saņem `done` funkciju)."""
    from PyObjCTools import AppHelper  # type: ignore
    sem = threading.Semaphore(0)

    def run():
        try:
            fn(sem.release)
        except Exception as e:
            print("websession:", str(e)[:120])
            sem.release()
    AppHelper.callAfter(run)
    return sem.acquire(timeout=timeout)


def mac_session_cookies(hosts: list[str], timeout: float = 8.0) -> list[dict]:
    """Īslaicīgās sīkdatnes šiem domēniem (getAllCookies — galvenajā pavedienā)."""
    out: list[dict] = []

    def fn(done):
        def handler(cookies):
            try:
                for c in cookies or []:
                    try:
                        if not c.isSessionOnly() or not _match(str(c.domain()), hosts):
                            continue
                        out.append({"name": str(c.name()), "value": str(c.value()), "domain": str(c.domain()),
                                    "path": str(c.path() or "/"), "secure": bool(c.isSecure()), "httponly": bool(c.isHTTPOnly())})
                    except Exception:
                        continue
            finally:
                done()
        _store().getAllCookies_(handler)

    _on_main(fn, timeout)
    return out


def mac_restore(cookies: list[dict], timeout: float = 8.0) -> int:
    """Ieliek sīkdatnes atpakaļ (īslaicīgas — bez termiņa), visu galvenajā pavedienā. Atgriež, cik nodotas."""
    from Foundation import NSHTTPCookie  # type: ignore
    objs = []
    for c in cookies:
        props = {"Name": c.get("name", ""), "Value": c.get("value", ""), "Domain": c.get("domain", ""),
                 "Path": c.get("path") or "/"}
        if c.get("secure"):
            props["Secure"] = "TRUE"
        if c.get("httponly"):
            props["HttpOnly"] = "TRUE"
        ck = NSHTTPCookie.cookieWithProperties_(props)
        if ck is not None:
            objs.append(ck)
    if not objs:
        return 0
    left = [len(objs)]

    def fn(done):
        store = _store()

        def one():
            left[0] -= 1
            if left[0] <= 0:
                done()
        for ck in objs:
            store.setCookie_completionHandler_(ck, one)

    return len(objs) if _on_main(fn, timeout) else 0


def mac_count(hosts: list[str], timeout: float = 8.0) -> tuple[int, int]:
    """(īslaicīgās, ilgtermiņa) sīkdatnes šiem domēniem WebKit krātuvē — diagnostikai (vai krātuve saglabā uz diska)."""
    n = [0, 0]

    def fn(done):
        def handler(cookies):
            try:
                for c in cookies or []:
                    try:
                        if _match(str(c.domain()), hosts):
                            n[0 if c.isSessionOnly() else 1] += 1
                    except Exception:
                        continue
            finally:
                done()
        _store().getAllCookies_(handler)

    _on_main(fn, timeout)
    return n[0], n[1]


def mac_forget(cookies: list[dict], timeout: float = 8.0) -> int:
    """Izdzēš tieši šīs (agrāk atjaunotās) sīkdatnes — pēc vārda un domēna; citas neaiztiek."""
    want = {(c.get("name", ""), c.get("domain", "")) for c in cookies}
    if not want:
        return 0
    gone = [0]

    def fn(done):
        store = _store()

        def handler(all_):
            hits = [c for c in (all_ or []) if (str(c.name()), str(c.domain())) in want]
            if not hits:
                done()
                return
            left = [len(hits)]

            def one():
                gone[0] += 1
                left[0] -= 1
                if left[0] <= 0:
                    done()
            for c in hits:
                store.deleteCookie_completionHandler_(c, one)
        store.getAllCookies_(handler)

    _on_main(fn, timeout)
    return gone[0]
