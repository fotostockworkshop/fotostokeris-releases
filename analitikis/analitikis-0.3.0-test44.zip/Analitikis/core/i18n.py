"""Servera ziņojumu tulkojumi: kopīgie (šeit) + moduļa (App.msgs). Saskarnes teksti — web/ i18n failos."""
from __future__ import annotations

from . import app as _app
from . import config

MSG = {
    "error": {"lv": "Kļūda", "en": "Error"},
    "forbidden": {"lv": "Nav atļauts", "en": "Forbidden"},
    "bk_bad": {"lv": "Fails nav šīs programmas rezerves kopija vai ir bojāts.", "en": "The file is not a backup of this program or is damaged."},
    "bk_other": {"lv": "Šī ir citas programmas rezerves kopija.", "en": "This is a backup of a different program."},
}


def T(key: str, **kw) -> str:
    lang = config.get("lang") or "lv"
    m = _app.current().msgs.get(key) or MSG.get(key) or {}
    s = m.get(lang) or m.get("lv") or key
    try:
        return s.format(**kw)
    except (KeyError, IndexError):
        return s
