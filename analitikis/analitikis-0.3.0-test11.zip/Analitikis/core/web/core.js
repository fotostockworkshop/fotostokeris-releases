"use strict";
/* Fotostokeris — kopīgā saskarne visiem produktiem (core/web/core.js, noteikumi §5, §6).
   Dod: $, $$, esc, t, applyI18n, api, toast, uiDialog, uiConfirm un window.Core
   (tēma, statusu josla, iestatījumu rāmis, labojumu vēsture, sākuma banneris, aizvēršana).
   Modulis pirms šī faila iestata window.API_PREFIX un window.I18N (savi teksti). */

window.CORE_I18N = {
  lv: {
    quit: "Aizvērt", quit_title: "Aizvērt programmu", cancel: "Atcelt", saved: "Saglabāts", close: "Aizvērt",
    s_lang: "Valoda", s_theme: "Izskats", theme: "Tēma",
    theme_auto: "Kā sistēmā", theme_light: "Gaišā", theme_dark: "Tumšā",
    s_shared: "Kopīgie dati", s_author: "Noklusējuma autors",
    s_agencies: "Mērķa aģentūras (kopīgas visiem Fotostokera moduļiem):",
    s_myrules: "Mana pieredze ar aģentūrām",
    s_myrules_ph: "Piem.: Getty noraida auto izstāžu bildes. Adobe pieņem auto ielu bildes kā illustrative editorial.",
    s_other: "Cits", s_splash: "Rādīt sākuma banneri",
    app_info: "{app} v{v} · lietotnes datu mape:",
    open_folder: "Atvērt mapi", changelog: "Labojumu vēsture", settings_save: "Saglabāt iestatījumus",
    closed: "Programma aizvērta. Šo logu var aizvērt.",
    conn_lost: "Savienojums ar programmu pārtrūka (piemēram, dators gulēja). Mēģinu atjaunot…",
    conn_dead: "Programma neatbild. Ja dators gulēja, tā varēja aizvērties — palaid to vēlreiz; šī lapa atjaunosies pati.",
    conn_retry: "Mēģināt vēlreiz",
    upd_avail: "Pieejama jauna versija {v} (tev ir {cur}).", upd_install: "Uzstādīt", upd_whats: "Kas jauns", upd_later: "Vēlāk",
    upd_q: "Uzstādīt versiju {v}? Programma lejupielādēs jauno versiju, saglabās pašreizējo (atgriešanai) un palaidīsies no jauna. Tavi dati, paroles un sesijas netiek aiztikti.",
    upd_download: "Lejupielādēju versiju {v}… {p}%", upd_installing: "Uzstādu versiju {v}…", upd_restart: "Versija {v} uzstādīta — programma palaižas no jauna…",
    upd_error: "Atjaunināšana neizdevās: {e}", upd_busy: "Pagaidi, kamēr beidzas datu atjaunošana, un mēģini vēlreiz.",
    upd_dev: "Izstrādes režīmā programma sevi neatjaunina.",
    s_updates: "Atjauninājumi", upd_channel: "Kuras versijas saņemt",
    upd_ch_auto: "Automātiski (testa versijas, ja tagad ir testa versija)", upd_ch_stable: "Tikai gatavās versijas", upd_ch_test: "Arī testa versijas", upd_ch_off: "Nepārbaudīt",
    upd_check: "Pārbaudīt tagad", upd_none: "Tev ir jaunākā versija ({v}).", upd_fail: "Neizdevās pārbaudīt: {e}",
    s_creds: "Pieslēgšanās dati aģentūrām",
    s_creds_d: "Lietotājvārds un parole glabājas tikai šī datora drošajā glabātuvē (Windows — Credential Manager, Mac — Keychain), nevis programmas failos vai mākonī. Kad aģentūra prasa ielogoties, programma pati ieraksta lietotājvārdu un paroli. 2FA kodu, “vai esi cilvēks” pārbaudi un Google/Facebook pieteikšanos dari pats. Katrā datorā paroles jāievada atsevišķi.",
    s_creds_na: "Drošā glabātuve nav pieejama (nav uzstādīta bibliotēka keyring) — palaid programmu no jauna ar palaidēju, tas to uzstādīs. Līdz tam ielogojies aģentūru logos pats.",
    cr_user: "Lietotājvārds / e-pasts", cr_pass: "Parole", cr_saved_ph: "•••••• (saglabāta)",
    cr_save: "Saglabāt", cr_forget: "Aizmirst", cr_saved: "saglabāta ✓", cr_none: "nav saglabāta",
    cr_need_pass: "Ievadi paroli.", cr_forget_q: "Aizmirst {a} lietotājvārdu un paroli šajā datorā?", cr_ok: "{a}: saglabāts drošajā glabātuvē",
    ver_mismatch: "Darbojas cita programmas versija ({server}), bet saskarne ir {page}. Spied “Aizvērt” un palaid programmu no jauna.",
  },
  en: {
    quit: "Close", quit_title: "Close the program", cancel: "Cancel", saved: "Saved", close: "Close",
    s_lang: "Language", s_theme: "Appearance", theme: "Theme",
    theme_auto: "As system", theme_light: "Light", theme_dark: "Dark",
    s_shared: "Shared data", s_author: "Default author",
    s_agencies: "Target agencies (shared by all Fotostokeris modules):",
    s_myrules: "My experience with agencies",
    s_myrules_ph: "E.g.: Getty rejects auto show photos. Adobe accepts street car photos as illustrative editorial.",
    s_other: "Other", s_splash: "Show the start banner",
    app_info: "{app} v{v} · app data folder:",
    open_folder: "Open folder", changelog: "Changelog", settings_save: "Save settings",
    closed: "The program is closed. You can close this window.",
    conn_lost: "Connection to the program was lost (e.g. the computer was asleep). Reconnecting…",
    conn_dead: "The program does not respond. If the computer was asleep it may have closed — start it again; this page will reload by itself.",
    conn_retry: "Try again",
    upd_avail: "A new version {v} is available (you have {cur}).", upd_install: "Install", upd_whats: "What's new", upd_later: "Later",
    upd_q: "Install version {v}? The program will download it, keep the current version (to go back) and restart. Your data, passwords and sessions are not touched.",
    upd_download: "Downloading version {v}… {p}%", upd_installing: "Installing version {v}…", upd_restart: "Version {v} installed — the program is restarting…",
    upd_error: "Update failed: {e}", upd_busy: "Wait until the data refresh finishes and try again.",
    upd_dev: "In development mode the program does not update itself.",
    s_updates: "Updates", upd_channel: "Which versions to receive",
    upd_ch_auto: "Automatic (test versions if a test version is running now)", upd_ch_stable: "Released versions only", upd_ch_test: "Test versions too", upd_ch_off: "Do not check",
    upd_check: "Check now", upd_none: "You have the latest version ({v}).", upd_fail: "Could not check: {e}",
    s_creds: "Agency sign-in details",
    s_creds_d: "The user name and password are kept only in this computer's secure store (Windows — Credential Manager, Mac — Keychain), not in program files or the cloud. When an agency asks you to sign in, the program fills in the user name and password itself. 2FA codes, “are you human” checks and Google/Facebook sign-in are up to you. Passwords are entered separately on each computer.",
    s_creds_na: "The secure store is not available (the keyring library is not installed) — start the program again with its launcher, it will install it. Until then, sign in to the agency windows yourself.",
    cr_user: "User name / e-mail", cr_pass: "Password", cr_saved_ph: "•••••• (saved)",
    cr_save: "Save", cr_forget: "Forget", cr_saved: "saved ✓", cr_none: "not saved",
    cr_need_pass: "Enter the password.", cr_forget_q: "Forget the {a} user name and password on this computer?", cr_ok: "{a}: saved in the secure store",
    ver_mismatch: "A different program version ({server}) is running, but the page is {page}. Click “Close” and start the program again.",
  },
};

/* §4 aģentūru identifikatori (kopīgo datu ķekšiem) */
const CORE_AGENCIES = [["adobe", "Adobe Stock"], ["shutterstock", "Shutterstock"], ["istock", "iStock / Getty"],
  ["alamy", "Alamy"], ["dreamstime", "Dreamstime"], ["depositphotos", "Depositphotos"], ["123rf", "123RF"],
  ["pond5", "Pond5"], ["envato", "Envato"], ["bigstock", "Bigstock"], ["pixta", "Pixta"], ["canva", "Canva"],
  ["magnific", "Magnific"], ["zoonar", "Zoonar"], ["ingram", "Ingram"]];

window.LANG = window.LANG || "lv";
window.t = function (key, vars) {
  const L = window.LANG;
  const m = window.I18N || {}, c = window.CORE_I18N;
  let s = (m[L] && m[L][key]) ?? (c[L] && c[L][key]) ?? (m.lv && m.lv[key]) ?? c.lv[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = String(s).split("{" + k + "}").join(String(v));
  return s;
};
window.applyI18n = function (root = document) {
  document.documentElement.lang = window.LANG;
  root.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  root.querySelectorAll("[data-i18n-title]").forEach((el) => { el.title = t(el.dataset.i18nTitle); });
};

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

async function api(name, body = {}) {
  let r;
  try {
    r = await fetch("/api/" + (window.API_PREFIX || "") + name, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Token": window.TOKEN },
      body: JSON.stringify(body),
    });
  } catch (e) {                       // serveris neatbild (piem. pēc datora miega) — "Failed to fetch"
    if (window.Core) Core.lost();
    const err = new Error(t("conn_lost")); err.lost = true; throw err;
  }
  if (r.status === 403 && window.Core) Core.lost(true);   // programma palaista no jauna (cits žetons)
  const d = await r.json();
  if (!d.ok) { const e = new Error(d.error || "Error"); e.data = d; throw e; }
  return d;
}

function toast(msg, kind = "", ms = 3500) {
  const el = document.createElement("div");
  el.className = "toast " + kind;
  const sticky = kind.includes("err") || kind.includes("sticky");
  el.innerHTML = `<span>${esc(msg)}</span>` + (sticky ? `<button class="tclose">×</button>` : "");
  if (sticky) $(".tclose", el).addEventListener("click", () => el.remove());
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), sticky ? Math.max(ms, 30000) : ms);
}

/* --- dialogi (bez pārlūka confirm) --- */
let dlgResolve = null;
function uiDialog(msg, buttons) {
  return new Promise((resolve) => {
    if (dlgResolve) dlgResolve(null);
    dlgResolve = resolve;
    $("#dlgMsg").textContent = msg;
    const box = $("#dlgBtns");
    box.innerHTML = "";
    buttons.forEach((b) => {
      const el = document.createElement("button");
      el.textContent = b.label;
      if (b.cls) el.className = b.cls;
      el.addEventListener("click", () => closeDlg(b.v));
      box.appendChild(el);
    });
    $("#dlg").classList.remove("hidden");
    setTimeout(() => box.querySelector("button")?.focus(), 30);
  });
}
function closeDlg(v) {
  $("#dlg").classList.add("hidden");
  const r = dlgResolve; dlgResolve = null;
  if (r) r(v);
}
const uiConfirm = async (msg, ok = "OK") => (await uiDialog(msg, [{ v: true, label: ok, cls: "primary" }, { v: false, label: t("cancel") }])) === true;

window.Core = (function () {
  const C = { settings: {}, state: null, opts: {}, status: {} };

  /* ---------- kopīgie DOM elementi (dialogi, paziņojumi, statusu josla …) ---------- */
  function mountShell() {
    const icon = C.opts.icon || "/static/icon.svg";
    document.body.insertAdjacentHTML("beforeend", `
<footer id="statusbar" class="statusbar">
  <span id="statusLeft" class="row" style="gap:16px;flex-wrap:nowrap;min-width:0"></span>
  <span class="spacer"></span>
  <span class="si" data-i18n="theme"></span>
  <span class="theme-sw" id="themeSw">
    <button data-th="light" data-i18n="theme_light"></button><button data-th="dark" data-i18n="theme_dark"></button><button data-th="auto" data-i18n="theme_auto"></button>
  </span>
</footer>
<div id="changelogModal" class="modal hidden"><div class="modal-box wide">
  <button class="x" id="changelogClose" data-i18n-title="close">×</button>
  <h3 data-i18n="changelog"></h3><div id="changelogBody" class="changelog"></div></div></div>
<div id="dlg" class="modal dlg hidden"><div class="modal-box"><div id="dlgMsg" class="dlg-msg"></div><div id="dlgBtns" class="row-btns end"></div></div></div>
<div id="tip" class="tip hidden"></div>
<div id="splash" class="splash hidden"><div class="splash-card"><img src="${esc(icon)}" alt=""><div class="splash-name" id="splashName"></div><div id="splashVer" class="muted"></div></div></div>
<div id="toasts" class="toasts"></div>
<div id="updBar" class="upd-bar hidden"><span id="updMsg"></span><span id="updBtns" class="row" style="gap:8px">
  <button id="updNotes" class="ghost" data-i18n="upd_whats"></button><button id="updGo" class="primary" data-i18n="upd_install"></button>
  <button id="updLater" class="ghost" data-i18n="upd_later"></button></span></div>
<div id="connLost" class="conn-lost hidden"><span id="connLostMsg"></span><button id="connRetry" data-i18n="conn_retry"></button></div>`);
    $("#connRetry").addEventListener("click", reconnect);
    $("#updGo").addEventListener("click", installUpdate);
    $("#updNotes").addEventListener("click", showUpdNotes);
    $("#updLater").addEventListener("click", () => {
      $("#updBar").classList.add("hidden");
      try { sessionStorage.setItem("updLater", upd && upd.latest ? upd.latest.version : ""); } catch (_) {}
    });
    $$("#themeSw button").forEach((b) => b.addEventListener("click", () => setTheme(b.dataset.th, true)));
    $("#changelogClose").addEventListener("click", () => $("#changelogModal").classList.add("hidden"));
  }

  /* ---------- tēma ---------- */
  const mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  function applyTheme() {
    const pref = C.settings.theme || "auto";
    const dark = pref === "dark" || (pref === "auto" && mq && mq.matches);
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    $$("#themeSw button").forEach((b) => b.classList.toggle("on", b.dataset.th === pref));
    if (C.opts.onTheme) C.opts.onTheme(dark);
  }
  if (mq && mq.addEventListener) mq.addEventListener("change", applyTheme);
  async function setTheme(v, persist) {
    C.settings.theme = v;
    applyTheme();
    if (persist) await save({ theme: v });
  }

  /* ---------- statusu josla: modulis iestata savus vienumus ---------- */
  function setStatus(id, item) {           // item: {text, cls: ok|run|err, title} vai null
    if (item) C.status[id] = item; else delete C.status[id];
    $("#statusLeft").innerHTML = Object.values(C.status).map((s) =>
      `<span class="si ${esc(s.cls || "")}" title="${esc(s.title || s.text)}"><i></i>${esc(s.text)}</span>`).join("");
  }

  /* ---------- iestatījumi ---------- */
  async function save(vals) {
    try {
      const d = await api("settings", { settings: vals });
      C.settings = d.settings;
      return d.settings;
    } catch (e) { toast(e.message, "err"); throw e; }
  }

  /* Iestatījumu lapa (§5): Valoda · Izskats · [Kopīgie dati] · moduļa sadaļas · Cits.
     o = {root, shared: ["author","agencies","my_rules"], moduleHtml, otherHtml, load(s), collect(), onSaved(s)} */
  function settingsFrame(o) {
    const root = $(o.root);
    const sh = new Set(o.shared || []);
    root.innerHTML = `<div class="settings">
  <section><h2 data-i18n="s_lang"></h2>
    <select id="sLang"><option value="lv">Latviešu</option><option value="en">English</option></select></section>
  <section><h2 data-i18n="s_theme"></h2>
    <div class="card-radio">
      <label><input type="radio" name="sTheme" value="light"> <span data-i18n="theme_light"></span></label>
      <label><input type="radio" name="sTheme" value="dark"> <span data-i18n="theme_dark"></span></label>
      <label><input type="radio" name="sTheme" value="auto"> <span data-i18n="theme_auto"></span></label>
    </div></section>
  ${sh.size ? `<section><h2 data-i18n="s_shared"></h2>
    ${sh.has("author") ? `<div class="grid2"><label><span data-i18n="s_author"></span><input id="sAuthor" spellcheck="false"></label></div>` : ""}
    ${sh.has("agencies") ? `<div class="agencies"><span class="small muted" data-i18n="s_agencies"></span>
      ${CORE_AGENCIES.map(([id, n]) => `<label class="chk"><input type="checkbox" class="sAg" value="${id}"> ${esc(n)}</label>`).join("")}</div>` : ""}
    ${sh.has("my_rules") ? `<label><span data-i18n="s_myrules"></span><textarea id="sMyRules" rows="4" spellcheck="false" data-i18n-ph="s_myrules_ph"></textarea></label>` : ""}
  </section>` : ""}
  ${o.moduleHtml || ""}
  ${o.creds && o.creds.length ? `<section id="credsSec"><h2 data-i18n="s_creds"></h2>
    <p class="muted small" data-i18n="s_creds_d"></p><div id="credsNa" class="note warn hidden" data-i18n="s_creds_na"></div>
    <div class="creds">${o.creds.map(([id, n]) => `<div class="cred" data-id="${esc(id)}">
      <span class="cred-n">${esc(n)}</span>
      <input class="cr-u" autocomplete="off" spellcheck="false" data-i18n-ph="cr_user">
      <input class="cr-p" type="password" autocomplete="new-password" data-i18n-ph="cr_pass">
      <button class="cr-save" data-i18n="cr_save"></button>
      <span class="cr-st muted small"></span>
      <button class="ghost cr-forget hidden" data-i18n="cr_forget"></button></div>`).join("")}</div></section>` : ""}
  <section><h2 data-i18n="s_updates"></h2>
    <div class="grid2"><label><span data-i18n="upd_channel"></span>
      <select id="sUpdCh"><option value="auto" data-i18n="upd_ch_auto"></option><option value="stable" data-i18n="upd_ch_stable"></option>
        <option value="test" data-i18n="upd_ch_test"></option><option value="off" data-i18n="upd_ch_off"></option></select></label></div>
    <div class="row"><button id="sUpdCheck" data-i18n="upd_check"></button><span id="sUpdMsg" class="muted small"></span></div>
  </section>
  <section><h2 data-i18n="s_other"></h2>
    <label class="chk"><input type="checkbox" id="sSplash"> <span data-i18n="s_splash"></span></label>
    <div id="appInfo" class="muted small app-info"></div>
    <div class="row"><button id="sOpenDir" data-i18n="open_folder"></button>${o.otherHtml || ""}<button id="changelogBtn" data-i18n="changelog"></button></div>
  </section>
  <div class="save-row sticky"><button id="settingsSave" class="primary" data-i18n="settings_save"></button><span id="settingsMsg" class="muted"></span></div>
</div>`;
    applyI18n(root);
    $("#sLang").addEventListener("change", (e) => setLang(e.target.value));
    $$("input[name=sTheme]", root).forEach((r) => r.addEventListener("change", () => setTheme(r.value, true)));
    $("#sOpenDir").addEventListener("click", () => api("reveal").catch((e) => toast(e.message, "err")));
    $("#changelogBtn").addEventListener("click", showChangelog);
    $("#sUpdCh").addEventListener("change", () => save({ update_channel: $("#sUpdCh").value }).catch(() => {}));
    $("#sUpdCheck").addEventListener("click", async () => {
      $("#sUpdMsg").textContent = "…";
      const d = await checkUpdate(true);
      $("#sUpdMsg").textContent = !d ? "" : d.error ? t("upd_fail", { e: d.error }) : d.available ? t("upd_avail", { v: d.latest.version, cur: d.current }) : t("upd_none", { v: d.current });
    });
    const credName = (id) => ((o.creds || []).find((c) => c[0] === id) || [id, id])[1];
    async function loadCreds() {
      if (!$("#credsSec")) return;
      try {
        const d = await api("creds", { names: o.creds.map((c) => c[0]) });
        $("#credsNa").classList.toggle("hidden", d.available);
        $$(".cred", root).forEach((row) => {
          const c = d.creds[row.dataset.id];
          $(".cr-u", row).value = c ? c.user : "";
          $(".cr-p", row).value = "";
          $(".cr-p", row).placeholder = t(c ? "cr_saved_ph" : "cr_pass");
          $(".cr-st", row).textContent = t(c ? "cr_saved" : "cr_none");
          $(".cr-st", row).classList.toggle("ok", !!c);
          $(".cr-forget", row).classList.toggle("hidden", !c);
          $$("input,button", row).forEach((x) => (x.disabled = !d.available));
        });
      } catch (_) { /* toast jau parādīts */ }
    }
    $$(".cred", root).forEach((row) => {
      const id = row.dataset.id;
      $(".cr-save", row).addEventListener("click", async () => {
        const user = $(".cr-u", row).value.trim(), password = $(".cr-p", row).value;
        if (!password && $(".cr-forget", row).classList.contains("hidden")) { toast(t("cr_need_pass"), "err"); return; }
        try {
          await api("cred_save", { name: id, user, password });
          $(".cr-p", row).value = "";
          toast(t("cr_ok", { a: credName(id) }), "ok", 2500);
        } catch (e) { toast(e.message, "err"); }
        loadCreds();
      });
      $(".cr-p", row).addEventListener("keydown", (e) => { if (e.key === "Enter") $(".cr-save", row).click(); });
      $(".cr-forget", row).addEventListener("click", async () => {
        if (!(await uiConfirm(t("cr_forget_q", { a: credName(id) }), t("cr_forget")))) return;
        try { await api("cred_forget", { name: id }); } catch (e) { toast(e.message, "err"); }
        loadCreds();
      });
    });
    $("#settingsSave").addEventListener("click", async () => {
      const s = C.settings;
      const vals = { lang: $("#sLang").value, show_splash: $("#sSplash").checked, update_channel: $("#sUpdCh").value };
      if ($("#sAuthor")) vals.author = $("#sAuthor").value.trim();
      if ($(".sAg")) vals.target_agencies = $$(".sAg").filter((c) => c.checked).map((c) => c.value);
      if ($("#sMyRules")) vals.my_rules = $("#sMyRules").value;
      Object.assign(vals, o.collect ? o.collect(s) : {});
      try {
        const ns = await save(vals);
        $("#settingsMsg").textContent = t("saved");
        toast(t("saved"), "ok", 1500);
        if (o.onSaved) o.onSaved(ns);
      } catch (_) { /* toast jau parādīts */ }
    });
    return {
      load() {
        const s = C.settings;
        $("#sLang").value = window.LANG;
        $$("input[name=sTheme]", root).forEach((r) => (r.checked = r.value === (s.theme || "auto")));
        if ($("#sAuthor")) $("#sAuthor").value = s.author || "";
        $$(".sAg").forEach((c) => (c.checked = (s.target_agencies || []).includes(c.value)));
        if ($("#sMyRules")) $("#sMyRules").value = s.my_rules || "";
        $("#sSplash").checked = s.show_splash !== false;
        $("#sUpdCh").value = s.update_channel || "auto";
        const st = C.state || {};
        $("#appInfo").innerHTML = esc(t("app_info", { app: st.app || "", v: window.PAGE_VERSION })) + `<br><code>${esc(st.app_dir || "")}</code>`;
        $("#settingsMsg").textContent = "";
        loadCreds();
        if (o.load) o.load(s);
      },
    };
  }

  function showChangelog() {
    $("#changelogBody").innerHTML = (window.CHANGELOG || []).map((c) => `<h4>${esc(c.v)} <span class="muted small">${esc(c.d)}</span></h4><ul>${(c[window.LANG] || c.lv).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`).join("");
    $("#changelogModal").classList.remove("hidden");
  }

  /* ---------- atjauninājumi (noteikumi §9a) ---------- */
  let upd = null;
  async function checkUpdate(force = false) {
    let d;
    try { d = await api("update_check", { force }); } catch (_) { return null; }
    upd = d;
    const bar = $("#updBar");
    if (d.available && d.latest) {
      let dismissed = null;
      try { dismissed = sessionStorage.getItem("updLater"); } catch (_) {}
      if (force || dismissed !== d.latest.version) {
        $("#updMsg").textContent = t("upd_avail", { v: d.latest.version, cur: d.current });
        bar.classList.remove("hidden");
      }
    } else bar.classList.add("hidden");
    return d;
  }
  async function installUpdate() {
    if (!upd || !upd.latest) return;
    const v = upd.latest.version;
    if (!upd.can_install) { toast(t("upd_dev"), "err"); return; }
    if (!(await uiConfirm(t("upd_q", { v }), t("upd_install")))) return;
    try { await api("update_install", { latest: upd.latest }); }
    catch (e) { toast(e.message === "busy" ? t("upd_busy") : t("upd_error", { e: e.message }), "err"); return; }
    $("#updBtns").classList.add("hidden");
    const poll = async () => {
      let s;
      try { s = (await api("update_status")).state; } catch (_) { return setTimeout(poll, 1500); }   // pārstartējas
      if (s.status === "download") $("#updMsg").textContent = t("upd_download", { v, p: s.pct || 0 });
      else if (s.status === "install") $("#updMsg").textContent = t("upd_installing", { v });
      else if (s.status === "restart") { $("#updMsg").textContent = t("upd_restart", { v }); quitting = false; }
      else if (s.status === "error") { $("#updMsg").textContent = t("upd_error", { e: s.msg }); $("#updBtns").classList.remove("hidden"); return; }
      setTimeout(poll, 800);
    };
    poll();
  }
  function showUpdNotes() {
    const n = (upd && upd.latest && upd.latest.notes) || {};
    const list = n[window.LANG] || n.lv || [];
    $("#changelogBody").innerHTML = `<h4>${esc(upd.latest.version)} <span class="muted small">${esc(upd.latest.date || "")}</span></h4>` +
      (Array.isArray(list) ? `<ul>${list.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : `<p>${esc(list)}</p>`);
    $("#changelogModal").classList.remove("hidden");
  }

  /* ---------- savienojums ar serveri (miegs, pārstartēšana) ---------- */
  let lostTimer = null, lostSince = 0, quitting = false;
  function lost(restarted = false) {
    if (quitting) return;
    if (!lostSince) lostSince = Date.now();
    const box = $("#connLost");
    if (box) {
      box.classList.remove("hidden");
      $("#connLostMsg").textContent = t(Date.now() - lostSince > 15000 ? "conn_dead" : "conn_lost");
    }
    if (restarted) return reconnect();
    if (!lostTimer) lostTimer = setTimeout(reconnect, 3000);
  }
  /* Ja serveris atbild — pārlādējam lapu (jauns žetons, ja programma palaista no jauna). */
  async function reconnect() {
    lostTimer = null;
    try {
      const r = await fetch("/", { cache: "no-store" });
      if (r.ok) { location.reload(); return; }
    } catch (_) { /* vēl neatbild */ }
    lost();
  }

  /* ---------- valoda ---------- */
  function setLang(lang, persist = true) {
    window.LANG = lang === "en" ? "en" : "lv";
    applyI18n();
    document.title = t("app_name");
    if ($("#langQuick")) $("#langQuick").value = window.LANG;
    if ($("#sLang")) $("#sLang").value = window.LANG;
    if (persist) save({ lang: window.LANG }).catch(() => {});
    if (C.opts.onLang) C.opts.onLang(window.LANG);
  }

  /* ---------- sākums: o = {icon, onLang, onTheme, busyOnQuit(): bool, quitQ} ---------- */
  function init(o = {}) {
    C.opts = o;
    mountShell();
    applyI18n();
    if ($("#langQuick")) $("#langQuick").addEventListener("change", (e) => setLang(e.target.value));
    if ($("#quitBtn")) $("#quitBtn").addEventListener("click", async () => {
      if (o.busyOnQuit && o.busyOnQuit() && !(await uiConfirm(o.quitQ ? o.quitQ() : t("quit_title"), t("quit")))) return;
      quitting = true;
      try { await api("quit"); } catch (_) {}
      document.body.innerHTML = `<div style="padding:60px;text-align:center;color:#6f778b;font:15px sans-serif">${esc(t("closed"))}</div>`;
      setTimeout(() => window.close(), 300);
    });
    setInterval(() => api("ping").catch(() => {}), 60000);
    // pēc datora miega / loga atgriešanās — uzreiz pārbaudām savienojumu
    document.addEventListener("visibilitychange", () => { if (!document.hidden) api("ping").catch(() => {}); });
    window.addEventListener("focus", () => api("ping").catch(() => {}));
  }

  /* pēc servera "state": iestatījumi, valoda, tēma, versija, banneris */
  function boot(st) {
    C.state = st;
    C.settings = st.settings || {};
    window.LANG = C.settings.lang === "en" ? "en" : "lv";
    applyTheme();
    applyI18n();
    document.title = t("app_name");
    if ($("#langQuick")) $("#langQuick").value = window.LANG;
    if ($("#appVer")) $("#appVer").textContent = "v" + st.version;
    $("#splashName").textContent = t("app_name");
    $("#splashVer").textContent = "v" + st.version;
    if (window.PAGE_VERSION && st.version !== window.PAGE_VERSION) toast(t("ver_mismatch", { server: st.version, page: window.PAGE_VERSION }), "err");
    setTimeout(() => checkUpdate(false), 3000);
    setInterval(() => checkUpdate(false), 6 * 3600e3);
    let seen = null;
    try { seen = sessionStorage.getItem("boot"); } catch (_) {}
    if (C.settings.show_splash !== false && seen !== st.boot) {
      try { sessionStorage.setItem("boot", st.boot); } catch (_) {}
      const sp = $("#splash");
      sp.classList.remove("hidden");
      setTimeout(() => { sp.classList.add("fade"); setTimeout(() => sp.classList.add("hidden"), 500); }, 1400);
    }
  }

  return {
    init, boot, save, setLang, setTheme, setStatus, settingsFrame, showChangelog, lost, checkUpdate,
    get settings() { return C.settings; }, set settings(v) { C.settings = v; },
    get state() { return C.state; },
  };
})();
