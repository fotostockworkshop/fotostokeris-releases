/* Zoonar: www.zoonar.com — /api/user/profile/user_sales/<lapa> (pārdošanas un izmaksas, EUR, neto).
   Personas datus (payout_user: adrese, tālrunis) NEŅEMAM — tikai vajadzīgos laukus. */
async function collect() {
  if (!/(^|\.)zoonar\.com$/.test(location.hostname)) throw LOGIN;
  /* Zoonar (Vue lietotne) API prasa ieejas žetonu no pārlūka atmiņas (localStorage), ne tikai sīkdatnes.
     Žetonu tikai pievienojam pieprasījumam — nekur nesaglabājam un žurnālā nerakstām. */
  function token() {
    for (const st of [localStorage, sessionStorage]) {
      for (let i = 0; i < st.length; i++) {
        const k = st.key(i);
        if (!/token|auth|jwt|user/i.test(k)) continue;
        let v = st.getItem(k) || "";
        try { const o = JSON.parse(v); v = (o && (o.access_token || o.token || o.accessToken || (o.auth && o.auth.token) || (o.user && o.user.token))) || (typeof o === "string" ? o : ""); } catch (_) { /* vienkārša virkne */ }
        if (/^[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+$/.test(v) || (/token/i.test(k) && v.length > 20 && !/\s/.test(v))) return { k, v };
      }
    }
    return null;
  }
  const tk = token();
  B.log(AG, "ieejas žetons: " + (tk ? `atrasts (${tk.k})` : "nav"));
  const H = Object.assign({ "X-Requested-With": "XMLHttpRequest" }, tk ? { Authorization: `Bearer ${tk.v}` } : {});
  const P = (n) => getj(`/api/user/profile/user_sales/${n}`, H);
  const first = await P(0);
  if (!first || !Array.isArray(first.balance_rows)) { B.log(AG, "atbildē nav balance_rows: " + Object.keys(first || {}).slice(0, 10).join(",")); throw LOGIN; }
  const pages = Math.max(1, +first.total_pages || 1);
  let all = first.balance_rows.slice();
  for (let n = 1; n < pages && n < 200; n++) {
    say(`${n + 1}/${pages}`, Math.round((n / pages) * 80));
    const j = await P(n);
    all = all.concat((j && j.balance_rows) || []);
    await sleep(200);
  }
  /* virsraksts no adreses: …/photo/riga-old-town_123456.html → "riga old town" */
  const slug = (u) => {
    const m = String(u || "").match(/\/([^/?#]+?)\/?(?:[?#].*)?$/);
    if (!m) return "";
    return decodeURIComponent(m[1]).replace(/\.html?$/i, "").replace(/[-_]?\d{3,}$/, "").replace(/[-_]+/g, " ").trim();
  };
  const rows = [];
  for (const r of all) {
    if (r.is_payout) continue;                          // izmaksas — 3. daļā (izmaksu vēsture)
    const day = pdate(r.date);
    const amount = money(r.value);
    if (!day || !amount) continue;
    const id = String(r.res_id || "");
    rows.push({ day, id, title: slug(r.res_url), thumb: r.img_url || "", url: r.res_url || "", amount, cnt: 1, kind: "sale",
      license: [r.partner || "Zoonar", r.license || ""].filter(Boolean).join(" · ") });
  }
  B.log(AG, `pārdošanas: ${rows.length} (rindas kopā ${all.length}, lapas ${pages})`);
  const start = rows.length ? rows.reduce((m, x) => (x.day < m ? x.day : m), today) : today;
  await sendRows(rows, { start, end: today, currency: "EUR" });
  if (first.current_balance != null) await send("balance", { amount: money(first.current_balance), currency: "EUR" });
  return { rows: rows.length };
}
