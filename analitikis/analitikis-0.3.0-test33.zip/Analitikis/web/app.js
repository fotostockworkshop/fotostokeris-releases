"use strict";
/* Analītiķis — saskarne. Viss modulis vienā failā ar skaidru inicializāciju (init()), lai vēlāk to
   varētu ielādēt kā sadaļu kopējā programmā kopā ar Vārdotāju. */

/* $, $$, esc, api, toast, uiDialog, uiConfirm, t — /core/core.js */

/* --- formāti --- */
let AG = [];            // aģentūru secība no servera (state.agencies)
const S = {
  settings: {}, agencies: {}, ov: null, page: "overview",
  chart: { view: "month", year: 0, month: 0, data: null, table: false },
  feed: { offset: 0, rows: [] }, best: { offset: 0, rows: [] }, years: [],
  sync: null, pollTimer: null, wasRunning: false,
};
const loc = () => (window.LANG === "en" ? "en-GB" : "lv-LV");
const usd = (v, d = 2) => "$" + (+v || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const usd0 = (v) => usd(v, Math.abs(v) >= 1000 ? 0 : 2);
const int = (v) => (+v || 0).toLocaleString(loc());
const agName = (a) => (S.agencies[a] && S.agencies[a].name) || a;
const dot = (a) => `<i class="dot" style="background:var(--ag-${esc(a)}, var(--ag-other))"></i>`;
const hasCounts = (a) => !(S.agencies[a] && S.agencies[a].counts === false);
/* summa oriģinālajā valūtā (pārdošanu rindām) */
const amt = (r) => (r.currency && r.currency !== "USD" ? (r.currency === "EUR" ? "€" : r.currency === "GBP" ? "£" : r.currency + " ") +
  (+r.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : usd(r.amount));
const dlTxt = (n, counts = true) => (counts && n ? `↓ ${int(n)}` : "");
const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
/* savākšanas kļūdu kodi (sync.py) → saprotams teksts */
const errText = (m) => (m && /^[a-z_]+$/.test(m) && t("err_" + m) !== "err_" + m ? t("err_" + m) : m || "");
const ACTIVE = ["queued", "waiting", "loading", "running", "login"];
const MONTHLY = new Set(["envato", "envato_market", "ingram"]);   // vienumu ienākumi pa mēnešiem (bez pārdošanas dienas)
/* bildes nosaukums; ja aģentūra to nedod (Alamy, Pixta) — aģentūra un bildes numurs */
const label = (r, ag, id) => r.title || r.filename || (ag ? `${agName(ag)} · ${id || ""}` : "");
function fmtDate(s, opts = null) {
  if (!s) return "";
  const d = new Date(s.length <= 10 ? s + "T12:00:00" : s);
  if (isNaN(d)) return s;
  if (opts) return d.toLocaleDateString(loc(), opts);
  const mon = d.toLocaleDateString(loc(), { month: "short" });
  const y = d.getFullYear() !== new Date().getFullYear() ? " " + d.getFullYear() : "";
  return window.LANG === "en" ? `${d.getDate()} ${mon}${y}` : `${d.getDate()}. ${mon}${y}`;
}
function fmtMonth(y, m) {
  return cap(new Date(y, m - 1, 15).toLocaleDateString(loc(), { month: "long" })) + " " + y;
}
function ago(iso) {
  if (!iso) return t("never");
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 90) return t("just_now");
  if (s < 3600) return t("min_ago", { n: Math.round(s / 60) });
  if (s < 86400 * 2) return t("h_ago", { n: Math.round(s / 3600) });
  return fmtDate(iso);
}
const thumb = (u, size = 240) => (u ? u.replace("/110_F_", `/${size}_F_`) : "");
const bg = (u) => (u ? `style="background-image:url('${esc(u)}')"` : "");
/* Sīktēls ar rezervēm: ja adrese neielādējas (piem. daļai Shutterstock jaunāko pārdošanu), mēģina tās pašas
   bildes sīktēlu citā aģentūrā, tad Shutterstock publisko priekšskatījumu, un beigās rāda nosaukumu. */
const ssThumb = (id) => (/^\d+$/.test(String(id || "")) ? `https://www.shutterstock.com/image-photo/photo-260nw-${id}.jpg` : "");
function thAttr(r, size = 240, nt = "") {
  const ss = r.agency === "shutterstock" ? r.agency_item_id : ((r.members || []).find((m) => m.agency === "shutterstock") || {}).agency_item_id;
  const list = [...new Set([thumb(r.thumb, size), thumb(r.alt, size), r.thumb || r.alt ? ssThumb(ss) : ""].filter(Boolean))];
  if (!list.length) return "";
  return `${bg(list[0])} data-th="${esc(JSON.stringify(list))}" data-nt="${esc(nt)}"`;
}
function probeThumb(el, list, i) {
  if (i >= list.length) {
    el.style.backgroundImage = "";
    if (el.classList.contains("img")) {
      el.classList.add("noimg");
      if (el.dataset.nt && !el.querySelector(".nt")) el.insertAdjacentHTML("afterbegin", `<span class="nt">${esc(el.dataset.nt)}</span>`);
      const ttl = el.parentElement && el.parentElement.querySelector(".ttl:not(.q)");
      if (ttl) ttl.remove();
    }
    return;
  }
  const im = new Image();
  im.onload = () => { if (im.naturalWidth > 2) { if (i) el.style.backgroundImage = `url('${list[i]}')`; } else probeThumb(el, list, i + 1); };
  im.onerror = () => probeThumb(el, list, i + 1);
  im.src = list[i];
}
function fixThumbs(root) {
  $$("[data-th]", root).forEach((el) => {
    if (el.dataset.probed) return;
    el.dataset.probed = "1";
    try { probeThumb(el, JSON.parse(el.dataset.th), 0); } catch (_) { /* */ }
  });
}

/* ============================================================ lapas */
function showPage(name) {
  S.page = name;
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "overview") loadOverview();
  if (name === "sales") loadFeed(true);
  if (name === "best") loadBest(true);
  if (name === "payouts") loadPayouts();
  if (name === "agencies") loadAgencies();
  if (name === "settings") loadSettings();
}
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));
$$("[data-goto]").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.goto)));

/* ============================================================ pārskats */
async function loadOverview() {
  try {
    const d = await api("overview");
    S.ov = d;
    renderCards(d);
    renderFresh(d);
    renderEmptyHint(d);
    applySync(d.sync);
  } catch (e) { toast(e.message, "err"); }
  loadChart();
}
function byRows(by, keyFilter) {
  const rows = AG.filter((a) => by && by[a] && (by[a].e || by[a].n) && (!keyFilter || keyFilter(a)));
  if (!rows.length) return "";
  return `<div class="by">${rows.map((a) => `<div class="agrow">${dot(a)}<span class="nm">${esc(agName(a))}</span><span class="val">${usd(by[a].e)}</span></div>`).join("")}</div>`;
}
function renderCards(d) {
  const c = d.cards;
  const dl = (n) => (n ? `↓ ${int(n)}` : "&nbsp;");
  const cmp = c.prev_month_same.e;
  const cards = [
    { k: t("c_today"), v: c.today.e, n: c.today.n, sub: `${t("yesterday")}: <b>${usd(c.yesterday.e)}</b>`, by: c.today.by },
    { k: t("c_week"), v: c.week.e, n: c.week.n, sub: "", by: c.week.by },
    { k: t("c_month"), v: c.month.e, n: c.month.n,
      sub: `${t("forecast")}: <b>~${usd0(c.forecast)}</b><br>${t("prev_same")}: <b>${usd(cmp)}</b>`, by: c.month.by },
    { k: t("c_year"), v: c.year.e, n: c.year.n, sub: `${t("all_time")}: <b>${usd0(c.all.e)}</b>`, by: c.year.by },
    { k: t("c_balance"), v: d.balance_total, n: 0, cls: "balance", sub: t("balance_note"),
      by: Object.fromEntries((d.balance || []).map((b) => [b.agency, { e: b.amount, n: 0 }])) },
  ];
  $("#cards").innerHTML = cards.map((x) => `<div class="card ${x.cls || ""}"><div class="k">${esc(x.k)}</div>
      <div class="v">${usd(x.v)}</div><div class="n">${dl(x.n)}</div>
      ${x.sub ? `<div class="sub">${x.sub}</div>` : ""}${byRows(x.by)}</div>`).join("");
}
/* jaunās pārdošanas kopš iepriekšējās atjaunošanas — līdz nākamajai atjaunošanai */
function renderFresh(d) {
  const f = d.fresh || { e: 0, n: 0, by: {} };
  const el = $("#freshNote");
  const ags = AG.filter((a) => f.by[a] && (f.by[a].e || f.by[a].n));
  el.classList.toggle("hidden", !ags.length);
  if (!ags.length) return;
  el.innerHTML = `<span>${esc(t("fresh_h"))}</span><span class="big">+${usd(f.e)}</span>${f.n ? `<span>↓ ${int(f.n)}</span>` : ""}` +
    ags.map((a) => `<span class="fag" title="${esc(t("fresh_at", { t: ago(f.by[a].at) }))}">${dot(a)}${esc(agName(a))} <b>+${usd(f.by[a].e)}</b>${f.by[a].n ? ` ↓${int(f.by[a].n)}` : ""}</span>`).join("");
}
function renderEmptyHint(d) {
  const has = d.agencies.some((a) => a.last_ok);
  const el = $("#emptyHint");
  el.classList.toggle("hidden", has);
  if (!has) el.innerHTML = `<h3>${esc(t("welcome_h"))}</h3><div>${t("welcome_txt")}</div>
     <div class="row-btns"><button class="primary" id="welcomeGo">${esc(t("welcome_btn"))}</button></div>`;
  if (!has) $("#welcomeGo").addEventListener("click", () => showPage("agencies"));
}

/* --- grafiks --- */
$$("#chartView button").forEach((b) => b.addEventListener("click", () => { S.chart.view = b.dataset.v; loadChart(); }));
$("#chartPrev").addEventListener("click", () => shiftChart(-1));
$("#chartNext").addEventListener("click", () => shiftChart(1));
$("#chartTableBtn").addEventListener("click", () => { S.chart.table = !S.chart.table; renderChart(); });
function shiftChart(dir) {
  const c = S.chart;
  if (c.view === "month") { c.month += dir; if (c.month < 1) { c.month = 12; c.year--; } if (c.month > 12) { c.month = 1; c.year++; } }
  else if (c.view === "year") c.year += dir;
  loadChart();
}
async function loadChart() {
  const c = S.chart;
  if (!c.year) { const n = new Date(); c.year = n.getFullYear(); c.month = n.getMonth() + 1; }
  $$("#chartView button").forEach((b) => b.classList.toggle("on", b.dataset.v === c.view));
  $(".period-nav").classList.toggle("hidden", c.view === "all");
  $("#chartLabel").textContent = c.view === "month" ? fmtMonth(c.year, c.month) : String(c.year);
  $("#chartTitle").textContent = t(c.view === "month" ? "ch_month" : c.view === "year" ? "ch_year" : "ch_all");
  try {
    const d = await api("chart", { view: c.view, year: c.year, month: c.month });
    c.data = d.chart;
    renderChart();
  } catch (e) { toast(e.message, "err"); }
  loadOvLists();
}
function keyLabel(k, view, short = true) {
  if (view === "month") return String(+k.slice(8, 10));
  if (view === "year") return new Date(+k.slice(0, 4), +k.slice(5, 7) - 1, 15).toLocaleDateString(loc(), { month: short ? "short" : "long" });
  return k;
}
function keyLong(k, view) {
  if (view === "month") return cap(new Date(k + "T12:00:00").toLocaleDateString(loc(), { weekday: "long" })) + ", " + fmtDate(k);
  if (view === "year") return fmtMonth(+k.slice(0, 4), +k.slice(5, 7));
  return k;
}
function niceMax(v) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
/* Vairāk nekā 8 krāsas grafikā nav salasāmas: mazākās aģentūras apvieno "Citas" */
function foldSeries(d) {
  const tot = (a) => Object.values(d.series[a] || {}).reduce((s, v) => s + v[0], 0);
  let ags = AG.filter((a) => d.series[a]).sort((a, b) => tot(b) - tot(a));
  if (ags.length > 8) {
    const keep = ags.slice(0, 7), rest = ags.slice(7);
    const other = {};
    for (const a of rest) for (const [k, v] of Object.entries(d.series[a])) {
      const o = other[k] || [0, 0]; other[k] = [o[0] + v[0], o[1] + v[1]];
    }
    d.series._other = other;
    d._otherList = rest;
    ags = keep.concat(["_other"]);
  }
  d._ags = AG.filter((a) => ags.includes(a)).concat(ags.includes("_other") ? ["_other"] : []);
}
const agLabel = (a) => (a === "_other" ? t("others") : agName(a));
function renderChart() {
  const d = S.chart.data;
  if (!d) return;
  const view = d.view;
  foldSeries(d);
  const ags = d._ags;
  const col = (k) => ags.map((a) => ({ a, e: (d.series[a][k] || [0, 0])[0], n: (d.series[a][k] || [0, 0])[1] }));
  const totals = d.keys.map((k) => col(k).reduce((s, x) => s + x.e, 0));
  // leģenda
  $("#chartLegend").innerHTML = ags.length ? ags.map((a) => {
    const sum = Object.values(d.series[a]).reduce((s, v) => s + v[0], 0);
    return `<span class="li" ${a === "_other" ? `title="${esc((d._otherList || []).map(agName).join(", "))}"` : ""}>${dot(a)}${esc(agLabel(a))} <b>${usd(sum)}</b></span>`;
  }).join("") + Object.entries(d.monthly_only || {}).map(([a, v]) =>
    `<span class="li" title="${esc(t("monthly_only_t"))}">${dot(a)}${esc(agName(a))} <b>${usd(v[0])}</b> <span class="muted">(${esc(t("monthly_only"))})</span></span>`).join("")
    : `<span class="muted">${esc(t("no_data"))}</span>`;
  // RPD tikai no aģentūrām, kas dod lejupielāžu skaitu (Envato ienākumi to sagrozītu)
  const cntE = AG.filter((a) => hasCounts(a)).reduce((s, a) =>
    s + Object.values(d.series[a] || {}).reduce((x, v) => x + v[0], 0) + ((d.monthly_only || {})[a] || [0])[0], 0);
  const rpd = d.total.n ? cntE / d.total.n : 0;
  $("#chartSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.total.e)}</b></span><span>${esc(t("downloads"))}: <b>${int(d.total.n)}</b></span>` +
    (rpd ? `<span title="${esc(t("rpd_title"))}">RPD: <b>${usd(rpd)}</b></span>` : "");
  const envNote = (ags.includes("envato") || (d._otherList || []).includes("envato")) && view !== "all";
  $("#chartNote").textContent = envNote ? t("envato_lag") : "";
  // tabula
  $("#chart").classList.toggle("hidden", S.chart.table);
  $("#chartTable").classList.toggle("hidden", !S.chart.table);
  $("#chartTableBtn").textContent = t(S.chart.table ? "as_chart" : "as_table");
  if (S.chart.table) {
    $("#chartTable").innerHTML = `<table class="t"><thead><tr><th></th>${ags.map((a) => `<th>${esc(agLabel(a))}</th>`).join("")}<th>${esc(t("total"))}</th><th>↓</th></tr></thead><tbody>` +
      d.keys.map((k, i) => { const c = col(k); return `<tr><td>${esc(keyLong(k, view))}</td>${c.map((x) => `<td>${x.e ? usd(x.e) : "–"}</td>`).join("")}<td><b>${usd(totals[i])}</b></td><td>${int(c.reduce((s, x) => s + x.n, 0))}</td></tr>`; }).join("") +
      "</tbody></table>";
    return;
  }
  // SVG stabiņi (sakrauti pa aģentūrām)
  const el = $("#chart");
  const W = Math.max(320, el.clientWidth), H = el.clientHeight || 270;
  const L = 52, R = 6, T = 8, B = 24;
  const iw = W - L - R, ih = H - T - B;
  const max = niceMax(Math.max(...totals, 0));
  const n = d.keys.length;
  const step = iw / n;
  const bw = Math.max(3, Math.min(46, step * 0.66));
  const y = (v) => T + ih - (v / max) * ih;
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc($("#chartTitle").textContent)}"><g class="grid">`;
  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = (max / ticks) * i, yy = y(v);
    svg += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}"/>`;
  }
  svg += `</g><g class="axis">`;
  for (let i = 0; i <= ticks; i++) { const v = (max / ticks) * i; svg += `<text x="${L - 8}" y="${y(v) + 4}" text-anchor="end">${usd0(v)}</text>`; }
  const every = Math.ceil(n / Math.max(1, Math.floor(iw / 34)));
  d.keys.forEach((k, i) => { if (i % every === 0) svg += `<text x="${L + step * i + step / 2}" y="${H - 6}" text-anchor="middle">${esc(keyLabel(k, view))}</text>`; });
  svg += `</g>`;
  const today = new Date().toISOString().slice(0, 10);
  d.keys.forEach((k, i) => {
    const x = L + step * i + (step - bw) / 2;
    let base = T + ih;
    const parts = col(k).filter((p) => p.e > 0);
    svg += `<g class="col" data-i="${i}">`;
    parts.forEach((p, j) => {
      const h = (p.e / max) * ih;
      const top = j === parts.length - 1;
      const gap = j > 0 ? 2 : 0;                 // 2px virsmas sprauga starp segmentiem
      const hh = Math.max(0, h - gap);
      const yy = base - h;
      if (hh > 0.5) {
        if (top && hh > 4) {
          const r = Math.min(4, bw / 2, hh);
          svg += `<path class="seg-r" fill="var(--ag-${p.a}, var(--ag-other))" d="M${x},${base - gap} V${yy + r} Q${x},${yy} ${x + r},${yy} H${x + bw - r} Q${x + bw},${yy} ${x + bw},${yy + r} V${base - gap} Z"/>`;
        } else {
          svg += `<rect class="seg-r" fill="var(--ag-${p.a}, var(--ag-other))" x="${x}" y="${yy}" width="${bw}" height="${hh}"/>`;
        }
      }
      base -= h;
    });
    svg += `<rect class="hit" data-i="${i}" x="${L + step * i}" y="${T}" width="${step}" height="${ih}"/></g>`;
    if (k === today) svg += `<circle cx="${L + step * i + step / 2}" cy="${T + ih + 3}" r="2.5" fill="var(--blue)"/>`;
  });
  svg += `</svg>`;
  el.innerHTML = svg;
  $$(".hit", el).forEach((h) => {
    h.addEventListener("mousemove", (ev) => showTip(ev, +h.dataset.i));
    h.addEventListener("mouseleave", hideTip);
    h.addEventListener("click", () => drill(+h.dataset.i));
  });
}
function showTip(ev, i) {
  const d = S.chart.data, k = d.keys[i];
  const parts = (d._ags || []).map((a) => ({ a, v: (d.series[a][k] || [0, 0]) }));
  const tot = parts.reduce((s, p) => s + p.v[0], 0), n = parts.reduce((s, p) => s + p.v[1], 0);
  const tip = $("#tip");
  tip.innerHTML = `<div class="th">${esc(keyLong(k, d.view))}</div>` +
    parts.filter((p) => p.v[0] || p.v[1]).map((p) => `<div class="tr"><span>${dot(p.a)}${esc(agLabel(p.a))}</span><span>${usd(p.v[0])}${p.v[1] ? ` · ↓${p.v[1]}` : ""}</span></div>`).join("") +
    `<div class="tr tt"><span>${esc(t("total"))}</span><span>${usd(tot)}${n ? ` · ↓${n}` : ""}</span></div>` +
    (d.view !== "month" ? `<div class="muted small" style="margin-top:4px;color:#c4d0dd">${esc(t("click_drill"))}</div>` : "");
  tip.classList.remove("hidden");
  const w = tip.offsetWidth, x = ev.clientX + 14 + w > innerWidth ? ev.clientX - w - 14 : ev.clientX + 14;
  tip.style.left = x + "px";
  tip.style.top = Math.max(8, ev.clientY - tip.offsetHeight - 10) + "px";
}
function hideTip() { $("#tip").classList.add("hidden"); }
function drill(i) {
  const d = S.chart.data, k = d.keys[i];
  hideTip();
  if (d.view === "year") { S.chart.view = "month"; S.chart.year = +k.slice(0, 4); S.chart.month = +k.slice(5, 7); loadChart(); }
  else if (d.view === "all") { S.chart.view = "year"; S.chart.year = +k; loadChart(); }
}
let resizeT = null;
window.addEventListener("resize", () => { clearTimeout(resizeT); resizeT = setTimeout(() => { if (S.page === "overview") renderChart(); if (S.page === "payouts") renderPayChart(); }, 120); });

/* --- jaunākās un labākās pārskatā --- */
function mrow(r, amount, sub) {
  return `<div class="mrow${r.fresh ? " fresh" : ""}" data-ag="${esc(r.agency)}" data-id="${esc(r.agency_item_id)}">
    <div class="th" ${thAttr(r, 160)}></div>
    <div class="tx"><div title="${esc(r.title || "")}">${esc(label(r, r.agency, r.agency_item_id))}</div><div class="m">${sub}</div></div>
    <div class="am">${amount}</div></div>`;
}
function bindRows(root) {
  fixThumbs(root);
  $$(".mrow, .tile[data-ag]", root).forEach((el) => el.addEventListener("click", () => openItem(el.dataset.ag, el.dataset.id)));
}
/* Saraksti zem grafika rāda to pašu periodu, kas izvēlēts grafikā (mēnesis / gads / visi gadi) */
function chartPeriod() {
  const c = S.chart;
  if (c.view === "month") return { period: `${c.year}-${String(c.month).padStart(2, "0")}`, label: fmtMonth(c.year, c.month) };
  if (c.view === "year") return { period: String(c.year), label: String(c.year) };
  return { period: "all", label: t("p_all") };
}
function feedSub(r) {
  const monthly = MONTHLY.has(r.agency);
  return `${dot(r.agency)}${esc(agName(r.agency))} · ${esc(monthly ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) + " (" + t("month_income") + ")" : fmtDate(r.day))}` +
    `${r.first ? ` · <b>${esc(t("first_sale"))}</b>` : ""}${r.q ? ` · <span title="${esc(t("buyer_q"))}">🔍 ${esc(r.q)}</span>` : ""}`;
}
async function loadOvLists() {
  const p = chartPeriod();
  $("#ovFeedTitle").textContent = S.chart.view === "all" ? t("latest") : t("sales_in", { p: p.label });
  $("#ovBestTitle").textContent = t("best_in", { p: p.label });
  try {
    const f = await api("feed", { limit: 10, period: p.period === "all" ? "" : p.period, monthly: S.chart.view === "month" });
    $("#ovFeed").innerHTML = f.rows.length ? f.rows.map((r) => mrow(r, `${amt(r)}${r.cnt > 1 ? `<small>×${r.cnt}</small>` : ""}`, feedSub(r))).join("")
      : `<div class="empty">${esc(t("no_sales"))}</div>`;
    bindRows($("#ovFeed"));
    const b = await api("best", { period: p.period, limit: 10 });
    $("#ovBest").innerHTML = b.rows.length ? b.rows.map((r) => mrow({ ...r, agency: r.members[0]?.agency, agency_item_id: r.members[0]?.agency_item_id },
      `${usd(r.e)}${r.counts && r.n ? `<small>↓ ${int(r.n)}</small>` : ""}`, r.members.map((m) => `${dot(m.agency)}${usd(m.e)}`).join(" &nbsp;"))).join("")
      : `<div class="empty">${esc(t("no_sales"))}</div>`;
    bindRows($("#ovBest"));
  } catch (e) { toast(e.message, "err"); }
}
$("#ovFeedMore").addEventListener("click", () => { PP.f.set(chartPeriod().period); showPage("sales"); });
$("#ovBestMore").addEventListener("click", () => { PP.b.set(chartPeriod().period); showPage("best"); });

/* ============================================================ perioda izvēle (kā Microstockr)
   Izvēlne: Visa vēsture · Diena · Mēnesis · Gads · Laika intervāls; bultiņas ‹ › pāršķir dienas / mēnešus / gadus.
   Vērtība serverim: "all" | "YYYY-MM-DD" | "YYYY-MM" | "YYYY" | "YYYY-MM-DD..YYYY-MM-DD". */
const isoD = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function PeriodPicker(sel, onChange, initial = "month") {
  const root = $(sel);
  const P = { kind: "month", d: new Date(), from: "", to: "" };
  root.innerHTML = `<select class="pp-kind"></select>
    <span class="period-nav pp-nav"><button class="icon pp-prev" data-i18n-title="prev">‹</button><span class="pp-label"></span><button class="icon pp-next" data-i18n-title="next">›</button></span>
    <span class="pp-range hidden"><input type="date" class="pp-from"> – <input type="date" class="pp-to"></span>`;
  const kindSel = $(".pp-kind", root);
  function render() {
    kindSel.innerHTML = [["all", "p_all"], ["day", "pk_day"], ["month", "pk_month"], ["year", "pk_year"], ["range", "pk_range"]]
      .map(([v, k]) => `<option value="${v}">${esc(t(k))}</option>`).join("");
    kindSel.value = P.kind;
    applyI18n(root);
    $(".pp-nav", root).classList.toggle("hidden", P.kind === "all" || P.kind === "range");
    $(".pp-range", root).classList.toggle("hidden", P.kind !== "range");
    const d = P.d;
    $(".pp-label", root).textContent = P.kind === "day" ? cap(d.toLocaleDateString(loc(), { weekday: "short" })) + ", " + fmtDate(isoD(d)) + (d.getFullYear() === new Date().getFullYear() ? " " + d.getFullYear() : "")
      : P.kind === "month" ? fmtMonth(d.getFullYear(), d.getMonth() + 1) : String(d.getFullYear());
    $(".pp-next", root).disabled = !canShift(1);
    if (P.kind === "range") { $(".pp-from", root).value = P.from; $(".pp-to", root).value = P.to; }
  }
  function shifted(dir) {
    const d = new Date(P.d);
    if (P.kind === "day") d.setDate(d.getDate() + dir);
    else if (P.kind === "month") { d.setDate(1); d.setMonth(d.getMonth() + dir); }
    else d.setFullYear(d.getFullYear() + dir);
    return d;
  }
  function canShift(dir) {
    if (dir < 0) return true;
    const n = shifted(1), now = new Date();
    if (P.kind === "day") return isoD(n) <= isoD(now);
    if (P.kind === "month") return n.getFullYear() * 12 + n.getMonth() <= now.getFullYear() * 12 + now.getMonth();
    return n.getFullYear() <= now.getFullYear();
  }
  function changed() { render(); onChange(); }
  kindSel.addEventListener("change", () => {
    P.kind = kindSel.value;
    P.d = new Date();                       // jauns perioda veids — sākam no šodienas
    if (P.kind === "range" && !P.from) { const n = new Date(); P.to = isoD(n); n.setDate(n.getDate() - 29); P.from = isoD(n); }
    changed();
  });
  $(".pp-prev", root).addEventListener("click", () => { P.d = shifted(-1); changed(); });
  $(".pp-next", root).addEventListener("click", () => { if (canShift(1)) { P.d = shifted(1); changed(); } });
  [".pp-from", ".pp-to"].forEach((c) => $(c, root).addEventListener("change", () => {
    P.from = $(".pp-from", root).value; P.to = $(".pp-to", root).value;
    if (P.from && P.to) onChange();
  }));
  const api_ = {
    get value() {
      const d = P.d, y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0");
      if (P.kind === "all") return "all";
      if (P.kind === "day") return isoD(d);
      if (P.kind === "month") return `${y}-${m}`;
      if (P.kind === "year") return String(y);
      return P.from && P.to ? `${P.from}..${P.to}` : "all";
    },
    set(v, quiet = false) {
      v = String(v || "all");
      let m;
      if (v === "all") P.kind = "all";
      else if ((m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/))) { P.kind = "day"; P.d = new Date(+m[1], +m[2] - 1, +m[3]); }
      else if ((m = v.match(/^(\d{4})-(\d{2})$/))) { P.kind = "month"; P.d = new Date(+m[1], +m[2] - 1, 1); }
      else if ((m = v.match(/^(\d{4})$/))) { P.kind = "year"; P.d = new Date(+m[1], 0, 1); }
      else if ((m = v.match(/^(\S+)\.\.(\S+)$/))) { P.kind = "range"; P.from = m[1]; P.to = m[2]; }
      else if (v === "month") { P.kind = "month"; P.d = new Date(); }
      else if (v === "year") { P.kind = "year"; P.d = new Date(); }
      render();
    },
    render,
  };
  api_.set(initial);
  return api_;
}
/* ============================================================ pārdošanas (plūsma) */
function agencyOptions(sel) {
  const cur = sel.value;
  sel.innerHTML = `<option value="">${esc(t("all_agencies"))}</option>` + AG.map((a) => `<option value="${a}">${esc(agName(a))}</option>`).join("");
  sel.value = cur || "";
}
let feedT = null;
["#fSearch"].forEach((s) => $(s).addEventListener("input", () => { clearTimeout(feedT); feedT = setTimeout(() => loadFeed(true), 300); }));
["#fAgency", "#fKind"].forEach((s) => $(s).addEventListener("change", () => loadFeed(true)));
$("#feedMore").addEventListener("click", () => loadFeed(false));
async function loadFeed(reset) {
  if (reset) { S.feed.offset = 0; S.feed.rows = []; }
  try {
    const d = await api("feed", { agency: $("#fAgency").value, period: PP.f.value, kind: $("#fKind").value, search: $("#fSearch").value, offset: S.feed.offset, limit: 80,
      monthly: MONTHLY.has($("#fAgency").value) });
    S.feed.rows = S.feed.rows.concat(d.rows);
    S.feed.offset += d.rows.length;
    $("#fSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.earnings)}</b></span>${d.downloads ? `<span>${esc(t("downloads"))}: <b>${int(d.downloads)}</b></span>` : ""}<span>${esc(t("files"))}: <b>${int(d.files)}</b></span>`;
    const g = $("#feedGrid");
    const html = d.rows.map((r) => `<div class="tile${r.fresh ? " fresh" : ""}" data-ag="${esc(r.agency)}" data-id="${esc(r.agency_item_id)}" title="${esc(r.title || "")}">
      <div class="img ${r.thumb ? "" : "noimg"}" ${thAttr(r, 240, label(r, r.agency, r.agency_item_id))}>${r.thumb ? "" : `<span class="nt">${esc(label(r, r.agency, r.agency_item_id))}</span>`}${r.first ? `<span class="badge">${esc(t("first_sale"))}</span>` : ""}${r.cnt > 1 ? `<span class="cnt">×${r.cnt}</span>` : ""}</div>
      <div class="body"><div class="am">${amt(r)}${r.kind === "other" ? `<small>${esc(t("other_pay"))}</small>` : ""}</div>
      <div class="meta">${dot(r.agency)}${esc(agName(r.agency))}<span class="d">${esc(MONTHLY.has(r.agency) || r.monthly ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) : fmtDate(r.day))}</span></div>
      ${r.thumb ? `<div class="ttl">${esc(r.title || r.filename || "")}</div>` : ""}
      ${r.q ? `<div class="ttl q" title="${esc(t("buyer_q"))}">🔍 ${esc(r.q)}</div>` : ""}</div></div>`).join("");
    if (reset) g.innerHTML = html || `<div class="empty">${esc(t("no_sales"))}</div>`;
    else g.insertAdjacentHTML("beforeend", html);
    bindRows(g);
    $("#feedMore").classList.toggle("hidden", S.feed.offset >= d.count);
  } catch (e) { toast(e.message, "err"); }
}

/* ============================================================ labākās */
let bestT = null;
$("#bSearch").addEventListener("input", () => { clearTimeout(bestT); bestT = setTimeout(() => loadBest(true), 300); });
["#bAgency", "#bSort", "#bGroup", "#bOther"].forEach((s) => $(s).addEventListener("change", () => loadBest(true)));
$("#bestMore").addEventListener("click", () => loadBest(false));
async function loadBest(reset) {
  if (reset) { S.best.offset = 0; S.best.rows = []; }
  try {
    const d = await api("best", { agency: $("#bAgency").value, period: PP.b.value, search: $("#bSearch").value, sort: $("#bSort").value,
      group: $("#bGroup").checked, other: $("#bOther").value, offset: S.best.offset, limit: 48 });
    const start = S.best.offset;
    S.best.rows = S.best.rows.concat(d.rows);
    S.best.offset += d.rows.length;
    $("#bSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.earnings)}</b></span>${d.downloads ? `<span>${esc(t("downloads"))}: <b>${int(d.downloads)}</b></span>` : ""}<span>${esc(t("items"))}: <b>${int(d.count)}</b></span>`;
    const ag = $("#bAgency").value;
    $("#bestNote").textContent = (!ag || ag === "envato") && d.rows.some((r) => r.members.some((m) => m.agency === "envato")) ? t("envato_best_note") : "";
    const g = $("#bestGrid");
    const html = d.rows.map((r, i) => {
      const m0 = r.members[0] || {};
      const img = thumb(r.thumb);
      return `<div class="tile" data-ag="${esc(m0.agency)}" data-id="${esc(m0.agency_item_id)}" title="${esc(r.title || "")}">
        <div class="img ${img ? "" : "noimg"}" ${thAttr(r, 240, label(r, m0.agency, m0.agency_item_id))}>${img ? "" : `<span class="nt">${esc(label(r, m0.agency, m0.agency_item_id))}</span>`}<span class="rank">#${start + i + 1}</span></div>
        <div class="body"><div class="am">${usd(r.e)}${r.counts && r.n ? `<small>↓ ${int(r.n)}</small>` : ""}</div>
        <div class="mem">${r.members.map((m) => `<span title="${esc(agName(m.agency))}">${dot(m.agency)}${usd(m.e)}</span>`).join("")}</div>
        ${img ? `<div class="ttl">${esc(r.title || r.filename || "")}</div>` : ""}</div></div>`;
    }).join("");
    if (reset) g.innerHTML = html || `<div class="empty">${esc(t("no_sales"))}</div>`;
    else g.insertAdjacentHTML("beforeend", html);
    bindRows(g);
    $("#bestMore").classList.toggle("hidden", S.best.offset >= d.count);
  } catch (e) { toast(e.message, "err"); }
}

/* --- vienuma logs --- */
async function openItem(agency, id) {
  if (!agency || !id) return;
  try {
    const { item } = await api("item", { agency, agency_item_id: id });
    if (!item || !item.members) return;
    const maxY = Math.max(...item.years.map((y) => y.e), 0.01);
    const img = thumb(item.thumb, 500);
    $("#itemBody").innerHTML = `<div class="item-head">
        <div class="big" ${bg(img)}></div>
        <div><h3>${esc(item.title || "")}</h3>
          <div class="item-tot"><div class="money"><b>${usd(item.e)}</b>${esc(t("earnings"))}</div>${item.counts && item.n ? `<div><b>${int(item.n)}</b>${esc(t("downloads"))}</div>
            <div><b>${usd(item.e / item.n)}</b>RPD</div>` : ""}</div>
          <table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("earnings"))}</th><th>↓</th><th>${esc(t("first_sold"))}</th><th>${esc(t("last_sold"))}</th><th></th></tr></thead><tbody>
          ${item.members.map((m) => `<tr><td>${dot(m.agency)} ${esc(agName(m.agency))}${m.filename ? `<div class="muted small">${esc(m.filename)}</div>` : ""}</td><td>${usd(m.e)}</td><td>${m.counts && m.n ? int(m.n) : "–"}</td>
            <td>${esc(fmtDate(m.first))}</td><td>${esc(fmtDate(m.last))}</td><td>${m.url ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(t("open"))}</a>` : ""}</td></tr>`).join("")}
          </tbody></table>
          ${item.members.length > 1 ? `<p class="muted small">${esc(t("grouped_note"))}</p>` : ""}
        </div></div>
      <div class="two">
        <div class="item-sec"><h4>${esc(t("by_year"))}</h4><div class="ybars">${item.years.map((y) => `<div class="ybar"><span>${esc(y.y)}</span><span class="b"><i style="width:${(y.e / maxY) * 100}%"></i></span><span>${usd(y.e)}</span></div>`).join("") || `<span class="muted small">–</span>`}</div></div>
        <div class="item-sec"><h4>${esc(t("recent_sales"))}</h4>
          <table class="t"><tbody>${item.recent.map((r) => `<tr><td>${dot(r.agency)} ${esc(MONTHLY.has(r.agency) ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) : fmtDate(r.day))}</td><td class="muted">${esc(r.license || kindLabel(r.kind))}${r.q ? ` · 🔍 ${esc(r.q)}` : ""}</td><td>${r.cnt > 1 ? "×" + r.cnt : ""}</td><td>${amt(r)}</td></tr>`).join("")}</tbody></table>
          ${item.recent.length ? "" : `<span class="muted small">${esc(t("no_detail"))}</span>`}</div>
      </div>`;
    $("#itemModal").classList.remove("hidden");
  } catch (e) { toast(e.message, "err"); }
}
function kindLabel(k) {
  const L = { "25_a_day": t("k_sub"), single_image_and_other: t("k_single"), on_demand: t("k_od"), elements: t("k_elements"), other: t("other_pay"), sale: "" };
  return k in L ? L[k] : (k || "");
}
$("#itemClose").addEventListener("click", () => $("#itemModal").classList.add("hidden"));
$("#itemModal").addEventListener("click", (e) => { if (e.target.id === "itemModal") $("#itemModal").classList.add("hidden"); });
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!$("#dlg").classList.contains("hidden")) return closeDlg(null);
  $$(".modal").forEach((m) => m.classList.add("hidden"));
});

/* ============================================================ izmaksas (3. daļa) */
const eur = (v, d = 2) => "€" + (+v || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const eur0 = (v) => eur(v, Math.abs(v) >= 1000 ? 0 : 2);
const inCur = (v, cur) => (v == null ? "–" : cur === "EUR" ? eur(v) : cur === "GBP" ? "£" + (+v).toFixed(2) : usd(v));
S.pay = { year: 0, data: null, table: false };
$("#payPrev").addEventListener("click", () => { S.pay.year--; loadPayouts(); });
$("#payNext").addEventListener("click", () => { S.pay.year++; loadPayouts(); });
$("#payTableBtn").addEventListener("click", () => { S.pay.table = !S.pay.table; renderPayChart(); });
async function loadPayouts() {
  if (!S.pay.year) S.pay.year = new Date().getFullYear();
  try {
    const d = await api("payouts", { year: S.pay.year });
    S.pay.data = d.payouts; S.pay.rules = d.rules; S.pay.recent = d.recent;
    renderPayouts();
  } catch (e) { toast(e.message, "err"); }
}
const modeTxt = (m) => t(m === "auto" ? "pay_auto" : m === "request" ? "pay_request" : "pay_unknown");
function renderPayouts() {
  const d = S.pay.data;
  if (!d) return;
  const sal = d.salary;
  const byList = (o) => `<div class="by">${AG.filter((a) => o[a]).map((a) => `<div class="agrow">${dot(a)}<span class="nm">${esc(agName(a))}</span><span class="val">${eur(o[a])}</span></div>`).join("")}</div>`;
  const expBy = Object.fromEntries(sal.expected_by.map((x) => [x.agency, x.eur]));
  const mName = (ym) => fmtMonth(+ym.slice(0, 4), +ym.slice(5, 7));
  const cards = [
    { k: t("pay_c_received", { m: mName(sal.month) }), v: eur(sal.received), sub: "", by: byList(sal.received_by) },
    { k: t("pay_c_expected", { m: mName(sal.next_month) }), v: "~" + eur(sal.expected), cls: "salary", sub: t("pay_c_expected_d"), by: byList(expBy) },
    { k: t("pay_c_unpaid"), v: "~" + eur(sal.unpaid_total), sub: t("pay_c_unpaid_d"), by: "" },
    { k: t("pay_c_avg", { y: d.year }), v: eur(d.avg), sub: t("pay_c_avg_d", { s: eur(d.year_tot), n: d.avg_months }), by: "" },
  ];
  $("#payCards").innerHTML = cards.map((x) => `<div class="card ${x.cls || ""}"><div class="k">${esc(x.k)}</div><div class="v">${x.v}</div>
    ${x.sub ? `<div class="sub">${esc(x.sub)}</div>` : ""}${x.by}</div>`).join("");
  // var pieprasīt
  const rq = $("#payReq");
  rq.classList.toggle("hidden", !d.can_request.length);
  rq.classList.toggle("last-day", !!d.last_day);
  if (d.can_request.length) {
    rq.innerHTML = `<div class="panel-head"><h2>${esc(t(d.last_day ? "pay_req_today" : "pay_req_h"))}</h2><span class="spacer"></span>
        <button class="primary" id="payReqAll">${esc(t("pay_req_all"))}</button></div>
      <p class="muted small">${esc(t("pay_req_d"))}</p>
      <div class="req-list">${d.can_request.map((x) => `<div class="req">${dot(x.agency)}<b>${esc(agName(x.agency))}</b>
        <span class="amt">${inCur(x.amount, x.currency)}</span>${x.currency !== "EUR" ? `<span class="muted">~${eur(x.eur)}</span>` : ""}
        <a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(t("pay_open"))}</a></div>`).join("")}</div>`;
    $("#payReqAll").addEventListener("click", () => requestPayouts(d.can_request));
  }
  // aģentūru tabula
  const rows = d.rows;
  $("#payTable").innerHTML = rows.length ? `<table class="t pay-t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("pay_mode"))}</th>
      <th>${esc(t("pay_unpaid"))}</th><th>${esc(t("pay_available"))}</th><th>${esc(t("pay_min"))}</th><th>${esc(t("pay_progress"))}</th>
      <th>${esc(t("pay_last"))}</th><th></th></tr></thead><tbody>` +
    rows.map((r) => `<tr class="${r.ready ? "ready" : ""}"><td>${dot(r.agency)} ${esc(agName(r.agency))}</td>
      <td><span class="mode ${r.mode || "none"}">${esc(modeTxt(r.mode))}</span></td>
      <td>${inCur(r.unpaid, r.currency)}</td><td>${r.available == null ? "–" : inCur(r.available, r.currency)}</td>
      <td>${r.min ? inCur(r.min, r.currency) : "–"}</td>
      <td>${r.pct == null ? "–" : `<span class="share"><i style="width:${r.pct}%;background:${r.ready ? "var(--ok)" : "var(--ag-" + r.agency + ")"}"></i></span> ${r.ready ? `<b class="okc">${esc(t("pay_ready"))}</b>` : r.pct + "%"}`}</td>
      <td>${r.last ? `${esc(fmtDate(r.last.paid_at))} · ${inCur(r.last.amount, r.last.currency)}` : "–"}${r.next_date ? `<div class="muted small">${esc(t("pay_next", { d: fmtDate(r.next_date) }))}</div>` : ""}${r.req ? `<div class="small ${r.req.ok ? "okc" : "badc"}" title="${esc(r.req.info || "")}">${esc(t(r.req.ok ? "pay_req_was" : "pay_req_failed", { d: fmtDate(r.req.at) }))}</div>` : ""}</td>
      <td><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(t("pay_open"))}</a></td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // gadi
  $("#payYears").innerHTML = d.years.length ? `<table class="t"><thead><tr><th>${esc(t("pay_year"))}</th><th>${esc(t("pay_paid_eur"))}</th><th>+/-</th></tr></thead><tbody>` +
    d.years.slice().reverse().map((y) => `<tr><td>${esc(y.y)}</td><td><b>${eur(y.e)}</b></td><td>${y.d == null ? "–" : `<span class="${y.d >= 0 ? "okc" : "badc"}">${y.d >= 0 ? "+" : ""}${y.d}%</span>`}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // pēdējās izmaksas
  $("#payRecent").innerHTML = (S.pay.recent || []).length ? `<table class="t"><tbody>` + S.pay.recent.slice(0, 15).map((r) =>
    `<tr><td>${esc(fmtDate(r.paid_at))}</td><td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td>${inCur(r.amount, r.currency)}</td><td class="muted">${r.currency !== "EUR" ? "~" + eur(r.amount_eur) : ""}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // neizmaksātais mēneša beigās
  $("#payHistTitle").textContent = t("pay_hist", { y: d.year });
  const hAg = AG.filter((a) => d.hist[a]);
  const mm = [...Array(12)].map((_, i) => i + 1);
  const mShort = (m) => new Date(2000, m - 1, 15).toLocaleDateString(loc(), { month: "short" });
  $("#payHist").innerHTML = hAg.length ? `<table class="t"><thead><tr><th></th>${mm.map((m) => `<th>${esc(mShort(m))}</th>`).join("")}</tr></thead><tbody>` +
    hAg.map((a) => `<tr><td>${dot(a)} ${esc(agName(a))}</td>${mm.map((m) => `<td>${d.hist[a][m] ? inCur(d.hist[a][m][0], d.hist[a][m][1]) : ""}</td>`).join("")}</tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_hist_empty"))}</div>`;
  renderPayChart();
}
/* "Pieprasīt visas": apstiprinājums → aģentūru logi (redzami) pieprasa izmaksu (noteikumi §2.4) */
async function requestPayouts(list) {
  const lines = list.map((x) => `${agName(x.agency)}: ${inCur(x.amount, x.currency)}`);
  if (!(await uiConfirm(t("pay_req_q", { l: lines.join(" · ") }), t("pay_req_all")))) return;
  try {
    const d = await api("payout_request", { agencies: list.map((x) => x.agency) });
    S.payoutRun = new Set(d.agencies);
    applySync(d.sync);
    toast(t("pay_req_started"), "ok", 7000);
  } catch (e) {
    if (e.data && e.data.need_webview) showPage("agencies");
    toast(e.message === "nothing" ? t("pay_req_nothing") : e.message, "err");
  }
}
function renderPayChart() {
  const d = S.pay.data;
  if (!d) return;
  $("#payYear").textContent = String(d.year);
  $("#payNext").disabled = d.year >= new Date().getFullYear();
  $("#payPrev").disabled = d.year <= +d.min_year;
  $("#payChartTitle").textContent = t("pay_chart", { y: d.year });
  const ags = AG.filter((a) => d.matrix[a]);
  const mm = [...Array(12)].map((_, i) => i + 1);
  const tot = (a) => Object.values(d.matrix[a]).reduce((s, v) => s + v, 0);
  $("#payLegend").innerHTML = ags.length ? ags.map((a) => `<span class="li">${dot(a)}${esc(agName(a))} <b>${eur(tot(a))}</b></span>`).join("") : `<span class="muted">${esc(t("pay_none"))}</span>`;
  $("#paySum").innerHTML = `<span>${esc(t("pay_year_tot"))}: <b>${eur(d.year_tot)}</b></span><span>${esc(t("pay_avg"))}: <b>${eur(d.avg)}</b></span>`;
  $("#payChart").classList.toggle("hidden", S.pay.table);
  $("#payMatrix").classList.toggle("hidden", !S.pay.table);
  $("#payTableBtn").textContent = t(S.pay.table ? "as_chart" : "as_table");
  const mLong = (m) => cap(new Date(d.year, m - 1, 15).toLocaleDateString(loc(), { month: "long" }));
  if (S.pay.table) {
    let cum = 0;
    $("#payMatrix").innerHTML = `<table class="t"><thead><tr><th></th>${ags.map((a) => `<th>${esc(agName(a))}</th>`).join("")}<th>${esc(t("pay_month_tot"))}</th><th>${esc(t("pay_avg_cum"))}</th></tr></thead><tbody>` +
      mm.map((m) => { cum += d.month_tot[m] || 0; return `<tr><td>${esc(mLong(m))}</td>${ags.map((a) => `<td>${d.matrix[a][m] ? eur(d.matrix[a][m]) : "–"}</td>`).join("")}<td><b>${d.month_tot[m] ? eur(d.month_tot[m]) : "–"}</b></td><td class="muted">${m <= d.avg_months ? eur(cum / m) : ""}</td></tr>`; }).join("") +
      `<tr class="tot"><td><b>${esc(t("total"))}</b></td>${ags.map((a) => `<td><b>${eur(tot(a))}</b></td>`).join("")}<td><b>${eur(d.year_tot)}</b></td><td></td></tr></tbody></table>`;
    return;
  }
  const el = $("#payChart");
  const W = Math.max(320, el.clientWidth), H = el.clientHeight || 250;
  const L = 52, R = 6, T = 8, B = 24, iw = W - L - R, ih = H - T - B;
  const max = niceMax(Math.max(...mm.map((m) => d.month_tot[m] || 0), 0));
  const step = iw / 12, bw = Math.max(6, Math.min(46, step * 0.62));
  const y = (v) => T + ih - (v / max) * ih;
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(t("pay_chart", { y: d.year }))}"><g class="grid">`;
  for (let i = 0; i <= 4; i++) svg += `<line x1="${L}" x2="${W - R}" y1="${y((max / 4) * i)}" y2="${y((max / 4) * i)}"/>`;
  svg += `</g><g class="axis">`;
  for (let i = 0; i <= 4; i++) svg += `<text x="${L - 8}" y="${y((max / 4) * i) + 4}" text-anchor="end">${eur0((max / 4) * i)}</text>`;
  mm.forEach((m, i) => { svg += `<text x="${L + step * i + step / 2}" y="${H - 6}" text-anchor="middle">${esc(new Date(2000, m - 1, 15).toLocaleDateString(loc(), { month: "short" }))}</text>`; });
  svg += `</g>`;
  mm.forEach((m, i) => {
    const x = L + step * i + (step - bw) / 2;
    let base = T + ih;
    const parts = ags.map((a) => ({ a, e: d.matrix[a][m] || 0 })).filter((p) => p.e > 0);
    svg += `<g class="col">`;
    parts.forEach((p, j) => {
      const h = (p.e / max) * ih, gap = j > 0 ? 2 : 0, hh = Math.max(0, h - gap);
      if (hh > 0.5) svg += `<rect class="seg-r" fill="var(--ag-${p.a}, var(--ag-other))" x="${x}" y="${base - h}" width="${bw}" height="${hh}" rx="${j === parts.length - 1 ? 3 : 0}"/>`;
      base -= h;
    });
    svg += `<rect class="hit" data-m="${m}" x="${L + step * i}" y="${T}" width="${step}" height="${ih}"/></g>`;
  });
  el.innerHTML = svg + `</svg>`;
  $$(".hit", el).forEach((h) => {
    h.addEventListener("mousemove", (ev) => {
      const m = +h.dataset.m, tip = $("#tip");
      const parts = ags.map((a) => [a, d.matrix[a][m] || 0]).filter((p) => p[1]);
      tip.innerHTML = `<div class="th">${esc(mLong(m))} ${d.year}</div>` + parts.map(([a, v]) => `<div class="tr"><span>${dot(a)}${esc(agName(a))}</span><span>${eur(v)}</span></div>`).join("") +
        `<div class="tr tt"><span>${esc(t("total"))}</span><span>${eur(d.month_tot[m] || 0)}</span></div>`;
      tip.classList.remove("hidden");
      const w = tip.offsetWidth, xx = ev.clientX + 14 + w > innerWidth ? ev.clientX - w - 14 : ev.clientX + 14;
      tip.style.left = xx + "px"; tip.style.top = Math.max(8, ev.clientY - tip.offsetHeight - 10) + "px";
    });
    h.addEventListener("mouseleave", hideTip);
  });
}

/* ============================================================ aģentūras */
async function loadAgencies() {
  try {
    const d = await api("overview");
    S.ov = d;
    applySync(d.sync);
    renderAgencies();
    $("#wvBox").classList.toggle("hidden", d.webview);
  } catch (e) { toast(e.message, "err"); }
  loadAgTable();
}
function renderAgencies() {
  const d = S.ov;
  if (!d) return;
  const sy = S.sync || {};
  const en = new Set(d.enabled || []);
  /* Aģentūru kartītēs Envato Market neatsevišķi — tas atjaunojas Envato logā; kartīte "Envato" = Elements + Market
     (citur sarakstos abi paliek atsevišķi) */
  $("#agCards").innerHTML = d.agencies.filter((a) => !a.via).map((a) => {
    const live = sy.running && sy.agencies && sy.agencies[a.id];
    const st = live ? live.state : null;
    let cls = "", txt;
    if (st === "running") { cls = "run"; txt = t("st_running") + (live.msg ? ` · ${live.msg}` : ""); }
    /* aģentūra šajā reizē jau beigusi — laiks uzreiz, negaidot pārējās */
    else if (st === "done") { cls = "ok"; txt = t("st_ok", { t: ago(new Date((live.t || Date.now() / 1000) * 1000).toISOString()) }); }
    else if (st === "error") { cls = "err"; txt = t("st_error"); }
    else if (st === "login") { cls = "run"; txt = t(live.visible ? "st_login" : "st_autologin"); }
    else if (st === "loading" || st === "waiting") { cls = "run"; txt = t("st_loading"); }
    else if (st === "queued") { cls = "run"; txt = t("st_queued"); }
    else if (a.last_err && (!a.last_ok || a.last_try > a.last_ok)) { cls = "err"; txt = t("st_error"); }
    else if (a.last_ok) { cls = "ok"; txt = t("st_ok", { t: ago(a.last_ok) }); }
    else txt = en.has(a.id) ? t("st_never") : t("st_off");
    const pct = live && st === "running" ? live.pct || 0 : 0;
    const busy = !!(live && ACTIVE.includes(st));   // aizņemta tikai šī aģentūra
    return `<div class="ag" style="--c:var(--ag-${a.id})">
      <h3>${dot(a.id)}${esc(a.id === "envato" ? "Envato" : a.name)}</h3>
      <div class="st ${cls}"><i></i><span>${esc(txt)}</span></div>
      ${live && st === "running" ? `<div class="prog"><i style="width:${pct}%"></i></div>` : ""}
      <div class="info">${a.id === "envato" ? esc(t("envato_both")) + "<br>" : ""}${esc(t("note_" + a.id))}${a.last_ok ? `<br>${esc(t(a.full ? "hist_full" : "hist_partial"))}` : ""}${a.last_day ? `<br>${esc(t("last_data", { d: fmtDate(a.last_day) }))}` : ""}</div>
      ${a.last_err && cls === "err" ? `<div class="info err">${esc(errText(a.last_err))}</div>` : ""}
      <div class="btns">
        ${a.via ? `<span class="muted small">${esc(t("via_note", { a: agName(a.via) }))}</span>` : a.last_ok || en.has(a.id)
          ? `<button class="primary" data-act="sync" data-ag="${a.id}" ${busy ? "disabled" : ""}>${esc(t("refresh"))}</button>
             ${!a.last_ok || cls === "err" ? `<button data-act="show" data-ag="${a.id}" ${busy ? "disabled" : ""} title="${esc(t("relogin_title"))}">${esc(t("relogin"))}</button>` : ""}
             <button data-act="full" data-ag="${a.id}" ${busy ? "disabled" : ""} title="${esc(t("full_title"))}">${esc(t("full"))}</button>
             ${en.has(a.id) ? `<button class="ghost" data-act="off" data-ag="${a.id}">${esc(t("disconnect"))}</button>` : ""}`
          : `<button class="primary" data-act="show" data-ag="${a.id}" ${busy ? "disabled" : ""}>${esc(t("connect"))}</button>`}
      </div></div>`;
  }).join("");
  $$("#agCards [data-act]").forEach((b) => b.addEventListener("click", () => agAction(b.dataset.act, b.dataset.ag)));
}
async function agAction(act, ag) {
  try {
    if (act === "off") {
      if (!(await uiConfirm(t("disconnect_q", { a: agName(ag) }), t("disconnect")))) return;
      await api("disconnect", { agency: ag });
      return loadAgencies();
    }
    if (act === "full" && !(await uiConfirm(t("full_q", { a: agName(ag) }), t("full")))) return;
    if (act === "show") toast(t("connect_hint", { a: agName(ag) }), "ok", 9000);
    const d = await api("sync", { agencies: [ag], show: act === "show" ? ag : null, full: act === "full" ? [ag] : [] });
    applySync(d.sync);
    renderAgencies();
  } catch (e) {
    if (e.data && e.data.need_webview) { showPage("agencies"); $("#wvBox").classList.remove("hidden"); }
    toast(e.message, "err");
  }
}

async function loadAgTable() {
  try {
    const d = await api("agencies", { period: PP.ag.value || "month" });
    $("#agTable").innerHTML = d.rows.length ? `<table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("earnings"))}</th><th>${esc(t("downloads"))}</th><th>${esc(t("files_sold"))}</th><th title="${esc(t("rpd_title"))}">RPD</th><th>${esc(t("share"))}</th></tr></thead><tbody>` +
      d.rows.map((r) => `<tr><td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td><b>${usd(r.e)}</b></td><td>${r.n != null && r.n ? int(r.n) : "–"}</td><td>${r.files ? int(r.files) : "–"}</td><td>${r.rpd ? usd(r.rpd) : "–"}</td>
        <td>${r.share}%<span class="share"><i style="width:${r.share}%;background:var(--ag-${r.agency})"></i></span></td></tr>`).join("") +
      `<tr><td><b>${esc(t("total"))}</b></td><td><b>${usd(d.total)}</b></td><td>${int(d.rows.reduce((s, r) => s + (r.n || 0), 0))}</td><td></td><td></td><td></td></tr></tbody></table>` +
      (d.rows.some((r) => r.agency === "envato") ? `<p class="muted small">${esc(t("envato_rpd"))}</p>` : "")
      : `<div class="empty">${esc(t("no_data"))}</div>`;
  } catch (e) { toast(e.message, "err"); }
}
$("#wvInstall").addEventListener("click", async () => {
  try { await api("install_webview"); $("#wvInstall").disabled = true; pollInstall(); } catch (e) { toast(e.message, "err"); }
});
async function pollInstall() {
  const d = await api("state");
  $("#wvMsg").textContent = d.install_msg || "";
  if (d.installing) return setTimeout(pollInstall, 1500);
  $("#wvInstall").disabled = false;
  if (d.webview || /pywebview/.test(d.install_msg) && !/Kļūda|Error/.test(d.install_msg)) { toast(d.install_msg, "ok"); loadAgencies(); }
  else toast(d.install_msg, "err");
}

/* ============================================================ datu savākšana (stāvoklis) */
$("#syncBtn").addEventListener("click", async () => {
  if (S.sync && S.sync.running) {
    const login = Object.entries(S.sync.agencies || {}).find(([, v]) => v.state === "login" && v.visible);
    if (login) return toast(t("login_hint", { a: agName(login[0]) }), "ok", 8000);
    if (await uiConfirm(t("stop_q"), t("stop"))) { await api("stop"); pollSync(); }
    return;
  }
  const en = (S.ov && S.ov.enabled) || S.settings.sales_agencies || [];
  if (!en.length) { showPage("agencies"); return toast(t("connect_first")); }
  startSync(en);
});
async function startSync(agencies) {
  try { const d = await api("sync", { agencies }); applySync(d.sync); }
  catch (e) {
    if (e.data && e.data.need_webview) showPage("agencies");
    toast(e.message, "err");
  }
}
function applySync(sy) {
  S.sync = sy || {};
  const running = !!S.sync.running;
  const ag = S.sync.agencies || {};
  const vals = Object.values(ag);
  /* "ielogojies logā" — tikai, ja logs tiešām parādīts; citādi programma ielogojas pati vai gaida pāradresāciju */
  const login = Object.entries(ag).filter(([, v]) => v.state === "login" && v.visible).map(([k]) => k);
  const b = $("#syncBtn");
  b.classList.toggle("busy", running && !login.length);
  b.classList.toggle("login", running && !!login.length);
  b.classList.toggle("idle", !running);
  const pct = vals.length ? vals.reduce((s, v) => s + (ACTIVE.includes(v.state) ? v.pct || 0 : 100), 0) / vals.length : 0;
  $("#syncFill").style.width = pct + "%";
  if (running) {
    const cur = Object.entries(ag).filter(([, v]) => v.state === "running").map(([k]) => agName(k));
    const left = vals.filter((v) => ACTIVE.includes(v.state)).length;
    $("#syncText").textContent = login.length ? t("sync_login_short", { a: agName(login[0]) })
      : cur.length ? cur.join(", ") + (left > cur.length ? ` · ${t("sync_left", { n: left - cur.length })}` : "") : t("sync_starting");
  } else $("#syncText").textContent = t("sync_btn");
  const ban = $("#syncBanner");
  const show = running && login.length;
  ban.classList.toggle("hidden", !show);
  document.body.classList.toggle("has-banner", !!show);
  if (show) ban.innerHTML = `<b>${esc(login.map(agName).join(", "))}:</b> <span>${esc(t("login_banner"))}</span>`;
  if (running) { S.wasRunning = true; if (!S.pollTimer) S.pollTimer = setTimeout(pollSync, 1500); }
  else if (S.wasRunning) {
    S.wasRunning = false;
    const res = Object.entries(ag);
    const paid = res.filter(([, v]) => v.state === "done" && v.msg === "payout_ok").map(([k]) => agName(k));
    const manual = res.filter(([, v]) => v.state === "error" && /^payout_/.test(v.msg || "")).map(([k]) => agName(k));
    if (paid.length) toast(t("pay_req_done", { a: paid.join(", ") }), "ok", 9000);
    if (manual.length) toast(t("pay_req_manual", { a: manual.join(", ") }), "err", 12000);
    const ok = res.filter(([, v]) => v.state === "done" && v.msg !== "payout_ok").map(([k]) => agName(k));
    const bad = res.filter(([, v]) => v.state === "error" && !/^payout_/.test(v.msg || "")).map(([k, v]) => `${agName(k)}: ${errText(v.msg)}`);
    const cancelled = res.filter(([, v]) => v.state === "cancelled" || v.state === "stopped").map(([k]) => agName(k));
    if (ok.length) toast(t("sync_done", { a: ok.join(", ") }), "ok", 5000);
    if (bad.length) toast(bad.join(" · "), "err");
    if (cancelled.length) toast(t("sync_cancelled", { a: cancelled.join(", ") }), "", 5000);
    refreshPage();
  }
  if (S.page === "agencies" && S.ov) renderAgencies();
  updateStatus(pct);
}
/* statusu josla apakšā: atjaunošana, pieslēgtās aģentūras, kļūdas */
function updateStatus(pct = 0) {
  const sy = S.sync || {}, d = S.ov;
  if (sy.running) {
    const cur = Object.entries(sy.agencies || {}).find(([, v]) => v.state === "running" || v.state === "login");
    Core.setStatus("sync", { text: t("sb_running", { a: cur ? agName(cur[0]) : "…", p: Math.round(pct) }), cls: "run" });
  } else Core.setStatus("sync", null);
  if (!d) return;
  const en = new Set(d.enabled || []);
  const ags = d.agencies.filter((a) => en.has(a.id));
  const errs = ags.filter((a) => a.last_err && (!a.last_ok || a.last_try > a.last_ok));
  const last = ags.map((a) => a.last_ok).filter(Boolean).sort().pop();
  Core.setStatus("agencies", { text: t("sb_agencies", { n: ags.length }) + (errs.length ? " · " + t("sb_errors", { n: errs.length }) : ""),
    cls: errs.length ? "err" : ags.length ? "ok" : "", title: errs.map((a) => a.name).join(", ") });
  Core.setStatus("updated", last ? { text: t("sb_updated", { t: ago(last) }) } : null);
}
async function pollSync() {
  S.pollTimer = null;
  try { const d = await api("status"); applySync(d.sync); } catch (_) { S.pollTimer = setTimeout(pollSync, 3000); }
}
function refreshPage() {
  api("years").then((d) => { S.years = d.years; }).catch(() => {});
  if (S.page === "overview") loadOverview();
  else if (S.page === "sales") loadFeed(true);
  else if (S.page === "best") loadBest(true);
  else if (S.page === "payouts") loadPayouts();
  else if (S.page === "agencies") loadAgencies();
}

/* ============================================================ iestatījumi (rāmis — core.js) */
/* aģentūras, kurām var saglabāt paroli automātiskai ielogošanai (Envato — tikai Google/… sesija, nav vajadzīgs) */
const AG_CREDS = [["adobe", "Adobe Stock"], ["shutterstock", "Shutterstock"], ["istock", "iStock / Getty"], ["alamy", "Alamy"],
  ["123rf", "123RF"], ["dreamstime", "Dreamstime"], ["depositphotos", "Depositphotos"], ["magnific", "Magnific"],
  ["pixta", "Pixta"], ["pond5", "Pond5"], ["bigstock", "Bigstock"], ["envato", "Envato"], ["zoonar", "Zoonar"], ["ingram", "Ingram"]];
const settingsPage = Core.settingsFrame({
  root: "#page-settings",
  shared: [],          // noteikumi §5: kopīgos laukus (autors, mērķa aģentūras, pieredze) Analītiķis nelieto
  moduleHtml: `<section><h2 data-i18n="s_sales"></h2>
    <div class="grid2"><label><span data-i18n="s_autosync"></span>
      <select id="sAuto"><option value="0" data-i18n="s_auto_0"></option>
        <option value="3">3 h</option><option value="6">6 h</option><option value="12">12 h</option><option value="24">24 h</option></select></label>
      <label><span data-i18n="s_parallel"></span>
      <select id="sParallel"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></label></div>
    <p class="muted small" data-i18n="s_sales_d"></p></section>
    <section><h2 data-i18n="s_pay"></h2><p class="muted small" data-i18n="s_pay_d"></p>
      <div id="sPayRules" class="pay-rules"></div>
      <label class="chk"><input type="checkbox" id="sPayRemind"> <span data-i18n="s_pay_remind"></span></label></section>
    <section><h2 data-i18n="s_mail"></h2><p class="muted small" data-i18n="s_mail_d"></p>
      <label class="chk"><input type="checkbox" id="sMailOn"> <span data-i18n="s_mail_on"></span></label>
      <div class="grid2">
        <label><span data-i18n="s_mail_to"></span><input id="sMailTo" type="email" placeholder="vards@gmail.com"></label>
        <label><span data-i18n="s_mail_when"></span><select id="sMailWhen">
          <option value="lastday" data-i18n="s_mail_lastday"></option><option value="day" data-i18n="s_mail_day"></option>
          <option value="threshold" data-i18n="s_mail_threshold"></option></select></label>
        <label id="sMailDayL"><span data-i18n="s_mail_dayn"></span><input id="sMailDay" type="number" min="1" max="31"></label>
        <label><span data-i18n="s_mail_hour"></span><input id="sMailHour" type="number" min="0" max="23"></label>
        <label><span data-i18n="s_smtp_host"></span><input id="sSmtpHost" placeholder="smtp.gmail.com"></label>
        <label><span data-i18n="s_smtp_port"></span><input id="sSmtpPort" type="number" min="1" max="65535"></label>
        <label><span data-i18n="s_smtp_user"></span><input id="sSmtpUser" type="email" autocomplete="off"></label>
        <label><span data-i18n="s_smtp_pw"></span><input id="sSmtpPw" type="password" autocomplete="new-password"></label>
      </div>
      <div class="row-btns"><button id="sSmtpSave" data-i18n="s_smtp_save"></button><button id="sSmtpForget" class="ghost" data-i18n="s_smtp_forget"></button>
        <button id="sMailTest" data-i18n="s_mail_test"></button><span id="sSmtpSt" class="muted small"></span></div>
      <p class="muted small" data-i18n="s_smtp_d"></p></section>`,
  creds: AG_CREDS,
  otherHtml: `<button id="clearSessions" data-i18n="clear_sessions" data-i18n-title="clear_sessions_title"></button>`,
  load: (s) => {
    $("#sAuto").value = String(s.sales_autosync_hours ?? 6); $("#sParallel").value = String(s.sales_parallel ?? 2);
    $("#sPayRemind").checked = s.sales_payout_remind !== false;
    $("#sMailOn").checked = !!s.sales_mail_on; $("#sMailTo").value = s.sales_mail_to || "";
    $("#sMailWhen").value = s.sales_mail_when || "lastday"; $("#sMailDay").value = s.sales_mail_day ?? 28;
    $("#sMailHour").value = s.sales_mail_hour ?? 9; $("#sSmtpHost").value = s.sales_smtp_host || "smtp.gmail.com";
    $("#sSmtpPort").value = s.sales_smtp_port ?? 587;
    $("#sMailDayL").classList.toggle("hidden", $("#sMailWhen").value !== "day");
    loadSmtp();
    loadPayRules(s.sales_payout || {});
  },
  collect: () => ({ sales_autosync_hours: +$("#sAuto").value, sales_parallel: +$("#sParallel").value,
    sales_payout_remind: $("#sPayRemind").checked, sales_payout: collectPayRules(),
    sales_mail_on: $("#sMailOn").checked, sales_mail_to: $("#sMailTo").value.trim(), sales_mail_when: $("#sMailWhen").value,
    sales_mail_day: +$("#sMailDay").value || 28, sales_mail_hour: +$("#sMailHour").value || 0,
    sales_smtp_host: $("#sSmtpHost").value.trim() || "smtp.gmail.com", sales_smtp_port: +$("#sSmtpPort").value || 587 }),
  onSaved: (s) => { S.settings = s; },
});
function loadSettings() { settingsPage.load(); }
/* e-pasta pieslēgšanās dati — tikai sistēmas drošajā glabātuvē (core/credentials, ieraksts "smtp") */
async function loadSmtp() {
  try {
    const d = await api("creds", { names: ["smtp"] });
    const c = (d.creds || {}).smtp || {};
    $("#sSmtpUser").value = c.user || ""; $("#sSmtpPw").value = "";
    $("#sSmtpPw").placeholder = c.saved ? t("s_smtp_saved") : "";
    $("#sSmtpSt").textContent = !d.available ? t("s_smtp_nokr") : c.saved ? t("s_smtp_saved") : "";
  } catch (_) { /* */ }
}
$("#sMailWhen").addEventListener("change", () => $("#sMailDayL").classList.toggle("hidden", $("#sMailWhen").value !== "day"));
$("#sSmtpSave").addEventListener("click", async () => {
  try { await api("cred_save", { name: "smtp", user: $("#sSmtpUser").value.trim(), password: $("#sSmtpPw").value || null }); toast(t("saved"), "ok"); loadSmtp(); }
  catch (e) { toast(e.message, "err"); }
});
$("#sSmtpForget").addEventListener("click", async () => { try { await api("cred_forget", { name: "smtp" }); loadSmtp(); } catch (e) { toast(e.message, "err"); } });
$("#sMailTest").addEventListener("click", async () => {
  $("#settingsSave").click();                     // vispirms saglabājam adresi un serveri
  await new Promise((r) => setTimeout(r, 700));
  try { await api("mail_test"); toast(t("s_mail_sent", { to: $("#sMailTo").value }), "ok", 6000); }
  catch (e) { toast(t("err_" + e.message) !== "err_" + e.message ? t("err_" + e.message) : e.message, "err", 9000); }
});
/* izmaksu veids un minimums pa aģentūrām: tukšs = noklusējums (aģentūras lapā nolasītais vai izpētītais) */
async function loadPayRules(user) {
  let defs = {};
  try { defs = (await api("payouts", { rules_only: true })).defaults || {}; } catch (_) { /* */ }
  const curSym = (a) => ({ EUR: "€", GBP: "£" }[(S.agencies[a] || {}).currency] || "$");
  $("#sPayRules").innerHTML = `<table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("pay_mode"))}</th><th>${esc(t("pay_min"))}</th></tr></thead><tbody>` +
    AG.map((a) => {
      const u = user[a] || {}, df = defs[a] || {};
      return `<tr data-ag="${a}"><td>${dot(a)} ${esc(agName(a))}</td>
        <td><select class="pr-mode"><option value="">${esc(t("pay_default", { v: modeTxt(df.mode) }))}</option>
          <option value="auto">${esc(t("pay_auto"))}</option><option value="request">${esc(t("pay_request"))}</option></select></td>
        <td><span class="cur">${curSym(a)}</span><input class="pr-min" type="number" min="0" step="1" placeholder="${df.min != null ? esc(String(df.min)) : "–"}" value="${u.min != null ? esc(String(u.min)) : ""}"></td></tr>`;
    }).join("") + `</tbody></table>`;
  $$("#sPayRules tr[data-ag]").forEach((tr) => { const u = user[tr.dataset.ag] || {}; $(".pr-mode", tr).value = u.mode || ""; });
}
function collectPayRules() {
  if (!$$("#sPayRules tr[data-ag]").length) return S.settings.sales_payout || {};    // tabula vēl nav ielādēta
  const out = {};
  $$("#sPayRules tr[data-ag]").forEach((tr) => {
    const mode = $(".pr-mode", tr).value, min = $(".pr-min", tr).value;
    if (mode || min !== "") out[tr.dataset.ag] = Object.assign({}, mode ? { mode } : {}, min !== "" ? { min: +min } : {});
  });
  return out;
}
$("#clearSessions").addEventListener("click", async () => {
  if (!(await uiConfirm(t("clear_sessions_q"), t("clear_sessions")))) return;
  try { await api("clear_sessions"); toast(t("sessions_cleared"), "ok", 5000); } catch (e) { toast(e.message, "err"); }
});

/* ============================================================ valoda */
function onLang() {
  PP.f.render(); PP.b.render(); PP.ag.render();
  agencyOptions($("#fAgency")); agencyOptions($("#bAgency"));
  applySync(S.sync);
  showPage(S.page);
}
const PP = {
  f: PeriodPicker("#fPeriod", () => loadFeed(true), "month"),
  b: PeriodPicker("#bPeriod", () => loadBest(true), "all"),
  ag: PeriodPicker("#agPeriod", () => loadAgTable(), "month"),
};
Core.init({
  onLang,
  onTheme: () => { if (S.chart.data) renderChart(); if (S.pay && S.pay.data) renderPayChart(); },
  busyOnQuit: () => !!(S.sync && S.sync.running),
  quitQ: () => t("quit_running_q"),
});

/* ============================================================ sākums */
async function init() {
  let st;
  try { st = await api("state"); } catch (e) { toast(e.message, "err"); return; }
  Core.boot(st);
  S.settings = st.settings;
  S.appDir = st.app_dir;
  st.agencies.forEach((a) => (S.agencies[a.id] = a));
  AG = st.agencies.map((a) => a.id);
  try { S.years = (await api("years")).years; } catch (_) {}
  applyI18n();
  PP.f.render(); PP.b.render(); PP.ag.render();
  agencyOptions($("#fAgency")); agencyOptions($("#bAgency"));
  await loadOverview();
  autoSync();
  payReminder();
}
/* mēneša pēdējā dienā: "var pieprasīt izmaksu" (iestatījums sales_payout_remind), vienreiz dienā */
async function payReminder() {
  if (S.settings.sales_payout_remind === false) return;
  try {
    const d = (await api("payouts", {})).payouts;
    if (!d.last_day || !d.can_request.length) return;
    let seen = null;
    try { seen = localStorage.getItem("payRemind"); } catch (_) { /* */ }
    if (seen === d.today) return;
    try { localStorage.setItem("payRemind", d.today); } catch (_) { /* */ }
    const ban = $("#payBanner");
    ban.innerHTML = `<b>${esc(t("pay_req_today"))}:</b> ${d.can_request.map((x) => `${esc(agName(x.agency))} ${inCur(x.amount, x.currency)}`).join(" · ")}
      <button class="small-btn" id="payBannerGo">${esc(t("pay_go"))}</button><button class="x" id="payBannerX">×</button>`;
    ban.classList.remove("hidden");
    $("#payBannerGo").addEventListener("click", () => { ban.classList.add("hidden"); showPage("payouts"); });
    $("#payBannerX").addEventListener("click", () => ban.classList.add("hidden"));
  } catch (_) { /* */ }
}
function autoSync() {
  const d = S.ov;
  const h = +(S.settings.sales_autosync_hours ?? 6);
  if (!d || !h || !d.webview || (d.sync && d.sync.running)) return;
  const en = d.enabled || [];
  const stale = en.filter((a) => {
    const x = d.agencies.find((y) => y.id === a);
    return x && x.last_ok && Date.now() - new Date(x.last_try || x.last_ok).getTime() > h * 3600e3;
  });
  if (stale.length) { toast(t("autosync", { a: stale.map(agName).join(", ") }), "", 4000); startSync(stale); }
}
init();
