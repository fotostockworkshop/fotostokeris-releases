/* Analītiķis — automātiska ielogošanās (aizpilda lietotājvārdu un paroli no datora drošās glabātuves).
   Python (sync.py: Runner.autofill) aizstāj __CR__ ar {u, p, hosts} un izpilda šo izteiksmi lapā.
   Atgriež: "pass" (parole ievadīta un nosūtīta), "user" (tikai 1. solis — e-pasts), "filled" (aizpildīts,
   bet lapā ir pārbaude "vai esi cilvēks" — to dara lietotājs), "none" (formas nav), "host" (sveša lapa).
   Nekad neko neraksta žurnālā un nesūta citur. */
(function (cr) {
  var host = location.hostname;
  if (!cr.hosts.some(function (h) { return host === h || host.slice(-h.length - 1) === "." + h; })) return "host";
  function vis(el) {
    if (!el || el.disabled || el.readOnly) return false;
    var r = el.getBoundingClientRect(), st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== "hidden" && st.display !== "none";
  }
  function setv(el, v) {
    try { el.focus(); } catch (e) { /* */ }
    var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    d.set.call(el, v);                                   // React/Vue lauki "redz" tikai šādu vērtību
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  var all = [].slice.call(document.querySelectorAll("input")).filter(vis);
  var pw = all.filter(function (i) { return i.type === "password"; })[0];
  var USER = "input[type=email],input[autocomplete~=username],input[autocomplete~=email],input[name*=user i]," +
    "input[name*=email i],input[name*=login i],input[id*=user i],input[id*=email i],input[id*=login i]";
  var skip = { password: 1, hidden: 1, checkbox: 1, radio: 1, submit: 1, button: 1, search: 1 };
  var u = all.filter(function (i) { return !skip[i.type] && i.matches(USER); })[0];
  if (!u && pw) {                                        // teksta lauks pirms paroles tajā pašā formā
    var scope = pw.form || pw.closest("div,section,main") || document;
    u = [].slice.call(scope.querySelectorAll("input")).filter(function (i) { return vis(i) && !skip[i.type]; })[0];
  }
  if (!pw && !u) {
    /* forma vēl nav atvērta (123RF — logs pēc "Log in", Magnific/Depositphotos — "Continue with email"):
       vienreiz lapā nospiežam e-pasta ielogošanās pogu (nekad Google/Facebook/Apple) */
    if (window.__vdOpened) return "none";
    var cl = [].slice.call(document.querySelectorAll("button,a,[role=button]")).filter(vis);
    var lt = function (x) { return (x.innerText || x.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim(); };
    var social = /google|facebook|apple|microsoft|twitter|github|sso/i;
    var o = cl.filter(function (x) { var t = lt(x); return /(log ?in|sign ?in|continue)\s+(with\s+)?e-?mail|^e-?mail$/i.test(t) && !social.test(t); })[0] ||
      cl.filter(function (x) { var t = lt(x); return /^(log ?in|sign ?in)$/i.test(t) && !social.test(t); })[0];
    if (!o) return "none";
    window.__vdOpened = true;
    o.click();
    return "open";
  }
  if (u && cr.u && u.value !== cr.u) setv(u, cr.u);
  if (pw) setv(pw, cr.p);
  /* "Atcerēties mani" / "Keep me signed in" / "Trust this device" — ilgāka sesija, retāk jāielogojas.
     Tikai ķeksis ar šādu tekstu (nekad "jaunumi", "noteikumi" u.c.). */
  var REM = /remember|keep me (signed|logged)|stay (signed|logged)|trust this (device|browser|computer)|don.?t ask (again|on this)|angemeldet bleiben|atcerēties|paturēt/i;
  [].slice.call(document.querySelectorAll("input[type=checkbox]")).forEach(function (c) {
    if (c.checked || c.disabled) return;
    var lab = (c.labels && c.labels[0] ? c.labels[0].innerText : "") || (c.closest("label") ? c.closest("label").innerText : "") ||
      c.getAttribute("aria-label") || c.name || c.id || "";
    if (!REM.test(lab) || /newsletter|terms|privacy|offer|subscribe/i.test(lab)) return;
    try { c.click(); } catch (e) { /* */ }
    if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); }
  });
  /* Tikai pārbaude, kas jāizpilda cilvēkam (ķeksis "I'm not a robot", hCaptcha, "Press & Hold").
     Neredzamā reCAPTCHA (v3 / size=invisible, stūra zīmīte .grecaptcha-badge) netraucē — pogu spiežam. */
  var captcha = [].slice.call(document.querySelectorAll("iframe[src*='recaptcha/api2/anchor'],iframe[src*='recaptcha/enterprise/anchor'],iframe[src*=hcaptcha],#px-captcha"))
    .some(function (el) { return vis(el) && !/size=invisible/.test(el.src || "") && !el.closest(".grecaptcha-badge"); });
  if (captcha || cr.submit === false) return "filled";
  var field = pw || u;
  var box = field.form || field.closest("form,[role=dialog],section,main") || document;
  var btns = [].slice.call(box.querySelectorAll("button,input[type=submit],[role=button]")).filter(vis);
  var TXT = /sign ?in|log ?in|continue|next|submit|weiter|ielogo|turpin|ログイン|次へ/i;
  var b = btns.filter(function (x) { return x.type === "submit"; })[0] ||
    btns.filter(function (x) { return TXT.test((x.innerText || x.value || x.getAttribute("aria-label") || "").trim()); })[0];
  setTimeout(function () {
    if (b) b.click();
    else if (field.form) { if (field.form.requestSubmit) field.form.requestSubmit(); else field.form.submit(); }
    else field.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
  }, 500);
  return pw ? "pass" : "user";
})(__CR__)
