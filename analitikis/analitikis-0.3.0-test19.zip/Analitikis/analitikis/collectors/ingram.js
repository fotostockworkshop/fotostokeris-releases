/* Ingram (ingramportal.com, GBP): Reports → Royalties — mēneša summas pa gadiem (bez bildēm).
   Lapas uzbūve vēl nav redzēta (Claude pārlūkā portāls neatveras) — savācējs meklē pēc tekstiem un raksta
   žurnālā, ko atrada. */
async function collect() {
  if (!/(^|\.)ingramportal\.com$/.test(location.hostname)) throw LOGIN;
  /* "cilvēka" pārbaude (traffic-verifier u.c.) vai lapa vēl ielādējas — nav kļūda: gaidām (logs paliek lietotājam) */
  /* Pārbaudi meklējam tikai tad, ja nav portāla izvēlnes (Royalties saites): lapās var būt paslēpti
     traffic-verifier skripti vai "protected by reCAPTCHA" uzraksts — tie nenozīmē, ka pārbaude notiek. */
  const hasMenu = [...document.querySelectorAll("a[href]")].some((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")))
    || /royalt/i.test(location.pathname);
  if (!hasMenu) {
    const why = !document.querySelector("a[href]") ? "lapā vēl nav saišu"
      : /verif|human|robot|checking your browser/i.test(document.title) ? "pārbaude (virsraksts)" : "";
    if (why) { B.log(AG, `${why} — gaidu (${location.pathname})`); throw LOGIN; }
  }
  const MONS = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  /* Royalties lapa: saite ar tekstu "Royalties" (vai jau esam tajā) */
  let doc = document, url = location.href;
  if (!/royalt/i.test(location.pathname + " " + txt(document.querySelector("h1, h2")))) {
    const a = [...document.querySelectorAll("a[href]")].find((x) => /royalt/i.test(txt(x) + " " + x.getAttribute("href")));
    if (!a) {
      B.log(AG, "Royalties saite nav atrasta; saites: " + [...document.querySelectorAll("a[href]")].slice(0, 25)
        .map((x) => txt(x).slice(0, 20) + "→" + new URL(x.getAttribute("href"), location.href).pathname).join(" · "));
      throw LOGIN;                          // vēl nav ielogots / izvēlne nav ielādēta — gaidām, logu neaizveram
    }
    url = new URL(a.getAttribute("href"), location.href).href;
    doc = await getdoc(url);
  }
  if (doc.querySelector('input[type="password"]') && !/royalt/i.test(txt(doc.body).slice(0, 4000))) {
    B.log(AG, "Royalties lapas vietā ielogošanās forma — gaidu"); throw LOGIN;
  }
  const body = txt(doc.body);
  const since = body.match(/since last pay-?out:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
  if (since) await send("balance", { amount: money(since[1]), currency: "GBP" });
  /* izmaksas: jāpieprasa ("Request payment", vismaz £40); pieprasāms = TOTAL ROYALTIES; vēstures ar summām nav */
  await payoutsSafe(async () => {
    const tot = body.match(/TOTAL ROYALTIES:?\s*£\s*(\d[\d,]*(?:\.\d{1,2})?)/i);
    const mn = body.match(/at least\s*£?\s*(\d+(?:\.\d+)?)\s*GBP/i);
    const v = tot ? money(tot[1]) : since ? money(since[1]) : null;
    if (v != null) await sendPayInfo({ unpaid: v, available: v, min: mn ? +mn[1] : null, currency: "GBP" });
  });
  /* gadu cilnes: saites/pogas ar gadu tekstu → katra gada lapa vai paslēpts bloks */
  const years = [...new Set([...doc.querySelectorAll("a, button, li")].map((x) => txt(x)).filter((t) => /^20\d\d$/.test(t)))].sort();
  B.log(AG, `Royalties: ${new URL(url).pathname}; gadi: ${years.join(",") || "–"}; tabulas: ${doc.querySelectorAll("table").length}`);
  const rows = [];
  function grab(d, yearHint) {
    for (const t of d.querySelectorAll("table")) {
      const head = txt(t.querySelector("tr"));
      if (!/month/i.test(head) || !/royalt/i.test(head)) continue;
      let y = yearHint;
      const box = t.closest("[id], section, div");
      const ym = String(box ? box.id + " " + txt(box.querySelector("h2,h3,h4,.tab-title")) : "").match(/20\d\d/);
      if (ym) y = +ym[0];
      for (const tr of [...t.querySelectorAll("tr")].slice(1)) {
        const c = [...tr.cells].map(txt);
        if (c.length < 2) continue;
        const mm = c[0].match(/([A-Za-z]{3})[a-z]*\s*(20\d\d)?/);
        if (!mm || !MONS[mm[1].toLowerCase()]) continue;
        const yy = mm[2] ? +mm[2] : y;
        if (!yy) continue;
        rows.push({ month: `${yy}-${String(MONS[mm[1].toLowerCase()]).padStart(2, "0")}`, cat: "royalties", e: money(c[c.length - 1]), n: 0 });
      }
    }
  }
  grab(doc, years.length ? +years[years.length - 1] : 0);
  /* ja gadu tabulas nav visas vienā lapā — mēģinām gadu saites */
  /* gada cilne: īsta saite → tā; citādi (JavaScript cilne) mēģinām adresi ar gada parametru */
  const tried = [];
  for (const y of years) {
    if (rows.some((r) => r.month.startsWith(y + "-"))) continue;
    const a = [...doc.querySelectorAll("a[href]")].find((x) => txt(x) === y && !/^#|javascript:/i.test(x.getAttribute("href")));
    const base = new URL(url);
    const cands = a ? [new URL(a.getAttribute("href"), location.href).href] : [];
    for (const k of ["year", "y", "Year"]) { const u = new URL(base); u.searchParams.set(k, y); cands.push(u.href); }
    for (const c of cands) {
      const before = rows.length;
      try { grab(await getdoc(c), +y); } catch (e) { if (e && e.login) throw e; }
      await sleep(300);
      if (rows.slice(before).some((r) => r.month.startsWith(y + "-"))) { tried.push(`${y}:${new URL(c).search || new URL(c).pathname}`); break; }
    }
  }
  if (tried.length) B.log(AG, "gadi no adresēm: " + tried.join(" "));
  const uniq = {};
  for (const r of rows) uniq[r.month] = r;
  const list = Object.values(uniq).sort((a, b) => (a.month < b.month ? -1 : 1));
  B.log(AG, `mēneši: ${list.length}`);
  if (!list.length) throw new Error("Ingram: Royalties tabula nav atrasta");
  await send("months", { start: list[0].month + "-01", end: today, currency: "GBP", rows: list });
  return { months: list.length };
}
