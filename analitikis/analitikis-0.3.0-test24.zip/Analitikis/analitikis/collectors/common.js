/* Analītiķis — datu savācējs. Darbojas aģentūras lapā (ar lietotāja sesiju) un nodod datus
   programmai caur pywebview tiltu. Python šo failu apvieno ar aģentūras failu (sync.py: _script). */
(async () => {
  if (window.__vdRun) return;
  window.__vdRun = true;
  const AG = "__AG__";
  const OPTS = __OPTS__;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let B;
  if (OPTS.poll) {
    /* Mac: pywebview tilts nestrādā lapās ar stingru drošības politiku (CSP, piem. Adobe) —
       ziņas krājas rindā, un Python tās pats savāc (Runner.pump) un atbild ar window.__vdIn */
    let n = 0;
    window.__vdQ = []; window.__vdCb = {};
    window.__vdOut = () => { const q = window.__vdQ || []; window.__vdQ = []; return JSON.stringify(q); };
    window.__vdIn = (id, ok, val) => { const c = window.__vdCb[id]; delete window.__vdCb[id]; if (c) (ok ? c[0] : c[1])(ok ? val : new Error(val)); };
    const call = (fn) => (...args) => new Promise((res, rej) => { const id = ++n; window.__vdCb[id] = [res, rej]; window.__vdQ.push({ id, fn, args }); });
    B = {};
    for (const fn of ["begin", "put", "progress", "login", "log", "done", "fail"]) B[fn] = call(fn);
  } else {
    for (let i = 0; i < 100 && !(window.pywebview && window.pywebview.api && window.pywebview.api.put); i++) await sleep(100);
    B = window.pywebview && window.pywebview.api;
    if (!B) { window.__vdRun = false; return; }
  }
  const LOGIN = { login: true };
  const send = (kind, data) => B.put(AG, kind, JSON.stringify(data));
  const say = (msg, pct) => B.progress(AG, String(msg), pct == null ? -1 : pct);
  const iso = (d) => d.toISOString().slice(0, 10);
  const today = OPTS.today;
  /* JSON pieprasījums; ja atbilde nav JSON (pāradresācija uz ielogošanos) — vajag ielogoties */
  async function getj(url, headers = {}) {
    let r;
    for (let a = 0; a < 3; a++) {
      try {
        r = await fetch(url, { credentials: "include", headers: Object.assign({ Accept: "application/json" }, headers) });
      } catch (e) { if (a === 2) throw e; await sleep(1500 * (a + 1)); continue; }
      if (r.status === 429 || r.status >= 500) { if (a === 2) break; await sleep(3000 * (a + 1)); continue; }
      break;
    }
    const path = new URL(url, location.href).pathname;
    if (r.status === 401 || r.status === 403) { B.log(AG, `pieprasījums ${path}: HTTP ${r.status}`); throw LOGIN; }
    const ct = r.headers.get("content-type") || "";
    if (!ct.includes("json")) {
      if (r.redirected || /<html/i.test((await r.text()).slice(0, 300))) { B.log(AG, `pieprasījums ${path}: nav JSON (${r.redirected ? "→ " + new URL(r.url).pathname : "HTML"})`); throw LOGIN; }
      throw new Error(url + ": " + r.status);
    }
    if (!r.ok) throw new Error(url + ": HTTP " + r.status);
    return r.json();
  }
  function monthsBack(fromY, fromM, toY, toM) {   // [[y,m], ...] no jaunākā uz vecāko
    const out = [];
    let y = toY, m = toM;
    while (y > fromY || (y === fromY && m >= fromM)) { out.push([y, m]); m--; if (m < 1) { m = 12; y--; } }
    return out;
  }
  function daysBetween(a, b) {               // ['YYYY-MM-DD', ...] no b uz a
    const out = [];
    const d = new Date(b + "T00:00:00Z"), s = new Date(a + "T00:00:00Z");
    while (d >= s) { out.push(iso(d)); d.setUTCDate(d.getUTCDate() - 1); }
    return out;
  }
  /* HTML lapa kā Document; ja aizveda uz ielogošanos — LOGIN */
  async function getdoc(url, init = {}, loginRe = /log-?in|sign-?in|auth/i) {
    let r;
    for (let a = 0; a < 3; a++) {
      try { r = await fetch(url, Object.assign({ credentials: "include" }, init)); }
      catch (e) { if (a === 2) throw e; await sleep(1500 * (a + 1)); continue; }
      if (r.status === 429 || r.status >= 500) { if (a === 2) break; await sleep(3000 * (a + 1)); continue; }
      break;
    }
    if (r.status === 401 || r.status === 403) { B.log(AG, `pieprasījums ${new URL(url, location.href).pathname}: HTTP ${r.status}`); throw LOGIN; }
    if (r.redirected && loginRe.test(new URL(r.url).pathname)) { B.log(AG, `pieprasījums ${new URL(url, location.href).pathname} → ${new URL(r.url).host}${new URL(r.url).pathname}`); throw LOGIN; }
    if (!r.ok) throw new Error(url + ": HTTP " + r.status);
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.__url = r.url;
    return doc;
  }
  const txt = (el) => (el ? (el.innerText || el.textContent || "") : "").replace(/\s+/g, " ").trim();
  /* "$1,234.56" / "€0.27" / "0,74" / "(0.10)" -> skaitlis */
  function money(s) {
    s = String(s == null ? "" : s).replace(/\s/g, "");
    const neg = /^\(.*\)$/.test(s) || /^-/.test(s) || /^[^\d]*-/.test(s);
    s = s.replace(/[^\d.,]/g, "");
    if (/^\d{1,3}(,\d{3})+$/.test(s)) s = s.replace(/,/g, "");              // 1,535 — tūkstoši
    else if (s.includes(",") && !s.includes(".")) s = s.replace(",", ".");  // 0,74 — decimāldaļa
    else s = s.replace(/,/g, "");
    const v = parseFloat(s);
    return isNaN(v) ? 0 : (neg ? -v : v);
  }
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const pad = (n) => String(n).padStart(2, "0");
  const ymd = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  const localIso = (d) => ymd(d.getFullYear(), d.getMonth() + 1, d.getDate());
  /* Datums dažādos formātos -> "YYYY-MM-DD" (vai "" ja neizdevās) */
  function pdate(s) {
    s = String(s || "").trim();
    let m;
    if ((m = s.match(/(\d{4})-(\d{2})-(\d{2})/))) return ymd(+m[1], +m[2], +m[3]);
    if ((m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/))) return ymd(+m[3], +m[1], +m[2]);           // 09/28/2026
    if ((m = s.match(/(\d{1,2})[-\s.]+([A-Za-z]{3,})[a-z]*[-\s.,]+(\d{4})/))) {                  // 02-Sep-2026, 07 October 2026
      const mo = MON[m[2].slice(0, 3).toLowerCase()]; if (mo) return ymd(+m[3], mo, +m[1]);
    }
    if ((m = s.match(/([A-Za-z]{3,})[a-z]*[\s.]+(\d{1,2}),?\s+(\d{4})/))) {                     // Oct.22, 2026, July 7, 2026
      const mo = MON[m[1].slice(0, 3).toLowerCase()]; if (mo) return ymd(+m[3], mo, +m[2]);
    }
    return "";
  }
  const monthEnd = (y, m) => ymd(y, m, new Date(y, m, 0).getDate());
  /* Pārdošanu rindas pa porcijām: o = {batch} vai {start, end}, + {currency, derive} */
  async function sendRows(rows, o = {}) {
    const N = 500;
    if (!rows.length) { await send("rows", Object.assign({}, o, { rows: [], first: true, last: true })); return; }
    for (let i = 0; i < rows.length; i += N)
      await send("rows", Object.assign({}, o, { rows: rows.slice(i, i + N), first: i === 0, last: i + N >= rows.length }));
  }
  /* ---- izmaksas (3. daļa) ----
     tableObjs: tabula, kuras virsraksta rindā ir visi `need` (regex) → [{kolonnas nosaukums: teksts}]; tikai pašas tabulas rindas.
     Saņēmēja datus (PayPal e-pasts u.c.) nesūtām: rindās tikai datums, summa, valūta, statuss. */
  function tableObjs(doc, need) {
    for (const t of doc.querySelectorAll("table")) {
      if (t.parentElement && t.parentElement.closest("table")) continue;
      const rows = [...t.rows];
      const hi = rows.findIndex((tr) => need.every((re) => re.test(txt(tr))));
      if (hi < 0) continue;
      const h = [...rows[hi].cells].map((c) => txt(c).toLowerCase());
      return rows.slice(hi + 1).map((tr) => {
        const o = {};
        [...tr.cells].forEach((c, i) => { o[h[i] || "c" + i] = txt(c); });
        return o;
      }).filter((o) => Object.keys(o).length >= 2);
    }
    return null;
  }
  const pick = (o, re) => { for (const k in o) if (re.test(k)) return o[k]; return ""; };
  const curOf = (s, dflt = "USD") => (/€|eur/i.test(s) ? "EUR" : /£|gbp/i.test(s) ? "GBP" : /\$|usd/i.test(s) ? "USD" : dflt);
  /* izmaksu nolasīšana nekad neaptur pārdošanu savākšanu: kļūda → žurnālā */
  async function payoutsSafe(fn) {
    if (!OPTS.daily) return;                     // izmaksu vēsture — reizi dienā (ātrumam)
    try { say("izmaksas", 97); await fn(); }
    catch (e) { if (e && e.login) { B.log(AG, "izmaksas: vajag ielogoties (izlaižu)"); return; } B.log(AG, "izmaksas: " + ((e && e.message) || e)); }
  }
  async function sendPayouts(rows, o = {}) {
    rows = rows.filter((r) => r.date && r.amount);
    B.log(AG, `izmaksas: ${rows.length}${rows.length ? ` (${rows[rows.length - 1].date} … ${rows[0].date})` : ""}`);
    if (rows.length) await send("payouts", Object.assign({ full: true }, o, { rows }));
  }
  const sendPayInfo = (o) => send("payout_info", o);
  /* ---- aģentūras kods ---- */
  __COLLECT__
  /* ------------------------ */
  /* Ielogošanās lapā fonā neko nepieprasām: aģentūras katrā pāradresācijā uz /login izsniedz jaunu formas
     zīmi (CSRF), un lietotāja atvērtā forma tad tiek klusi noraidīta (Bigstock 2026-10-29). */
  /* "Atcerēties mani" / "Trust this device" ķeksis (arī 2FA lapā, kur paroles lauka nav) — sesija pārdzīvo programmas
     restartu. Tikai ķeksis ar šādu tekstu, vienreiz lapā; neko nespiež un nesūta. */
  function tickRemember() {
    if (window.__vdRem) return;
    const REM = /remember|keep me (signed|logged)|stay (signed|logged)|trust this (device|browser|computer)|don.?t ask (again|on this)|angemeldet bleiben|atcerēties|paturēt/i;
    for (const c of document.querySelectorAll("input[type=checkbox]")) {
      if (c.checked || c.disabled) continue;
      const lab = (c.labels && c.labels[0] ? c.labels[0].innerText : "") || (c.closest("label") ? c.closest("label").innerText : "") ||
        c.getAttribute("aria-label") || c.name || c.id || "";
      if (!REM.test(lab) || /newsletter|terms|privacy|offer|subscribe/i.test(lab)) continue;
      try { c.click(); } catch (_) { /* */ }
      if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); }
      window.__vdRem = true;
      B.log(AG, "atzīmēts: " + lab.trim().slice(0, 40));
    }
  }
  function onLoginPage() {
    try { tickRemember(); } catch (_) { /* */ }
    if (/(^|\/)(log-?in|sign-?in|sign_in|signin)(\/|$|\.)/i.test(location.pathname)) return true;
    /* "cilvēka" pārbaude (HUMAN/PerimeterX "Press & Hold", Cloudflare u.c.) — lapa pati ir pārbaude: neko nepieprasām */
    if (document.querySelector("#px-captcha, #challenge-form") ||
        /press\s*&\s*hold|access to this page has been denied|verify you are (a )?human|checking your browser/i.test(document.title + " " + txt(document.body).slice(0, 1500))) {
      B.log(AG, "lapā cilvēka pārbaude — gaidu (fonā nekas netiek pieprasīts)");
      return true;
    }
    /* tikai tiešām redzams paroles lauks: ekrānā, ne caurspīdīgs, ne paslēptā (aizvērtā) logā */
    const vw = innerWidth, vh = innerHeight;
    const seen = (el) => {
      const r = el.getBoundingClientRect();
      if (!(r.width > 0 && r.height > 0) || r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) return false;
      for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
        const st = getComputedStyle(e);
        if (st.display === "none" || st.visibility === "hidden" || +st.opacity === 0 || e.getAttribute("aria-hidden") === "true") return false;
      }
      return true;
    };
    const pw = [...document.querySelectorAll('input[type="password"]')];
    const hit = pw.find(seen);
    if (pw.length) B.log(AG, `paroles lauki lapā: ${pw.length}, redzams: ${hit ? "jā" : "nē"}`);
    return !!hit;
  }
  try {
    const ok = await B.begin(AG, location.href);
    if (!ok) return;
    if (onLoginPage()) throw LOGIN;
    const res = await collect();
    if (res && res.navigated) return;
    await B.done(AG, JSON.stringify(res || {}));
  } catch (e) {
    if (e && e.login) {
      B.log(AG, "vajag ielogoties? lapa: " + location.host + location.pathname);   // bez parametriem (tajos var būt žetoni)
      await B.login(AG, location.href);
    }
    else await B.fail(AG, String((e && (e.message || e)) || "?"));
  } finally {
    window.__vdRun = false;
  }
})();
