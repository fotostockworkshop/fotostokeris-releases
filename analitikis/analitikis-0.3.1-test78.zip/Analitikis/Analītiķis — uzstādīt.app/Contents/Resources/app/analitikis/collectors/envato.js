/* Envato Elements: author.envato.com/reports */
async function collect() {
  if (location.hostname === "portfolio.envato.com") return { skipped: "portfolio" };
  if (/trolley\.com$/.test(location.hostname)) return { skipped: "trolley" };          // izmaksu logrīks bez uzdevuma   // portfeļa lapa (portNav) — bez uzdevuma nekas nav jādara
  if (location.hostname !== "author.envato.com") throw LOGIN;
  const meta = document.querySelector('meta[name="csrf-token"]');
  if (!/^\/reports/.test(location.pathname) || !meta) {
    location.href = "https://author.envato.com/reports/earnings";
    return { navigated: true };
  }
  const H = { "Content-Type": "application/json", "X-CSRF-Token": meta.getAttribute("content") };   // performance/* API vēl strādā (2026-11-17)
  const R = (u) => getj("/reports/api/v1/" + u, H);

  /* 0.3.1-test74 (lietotājs 2026-11-17, Chrome): Envato noņēma /reports/api/v1/earnings/* (404). Dati tagad ir servera HTML lapā
     /reports/earnings?view_type=daily|monthly&start=…&end=… — katrs stabiņš ar paskaidrojumu "17 November 2025 Elements Earnings: $7.44".
     Dienas: start/end YYYY-MM-DD, mēneši: YYYY-MM; līdz 12 mēnešiem vienā reizē. Tikai Elements (Market — themeforest.net). */
  const MON = { january: 1, february: 2, march: 3, april: 4, may: 5, june: 6, july: 7, august: 8, september: 9, october: 10, november: 11, december: 12 };
  const p2 = (n) => String(n).padStart(2, "0");
  async function bars(view, st, en) {
    const r = await fetch(`/reports/earnings?view_type=${view}&start=${st}&end=${en}`, { credentials: "include" });
    if (!r.ok) throw new Error(`/reports/earnings ${view}: HTTP ${r.status}`);
    const d = new DOMParser().parseFromString(await r.text(), "text/html");
    if (!d.querySelector('[data-controller="date-range"]')) throw LOGIN;
    const out = [];
    for (const e of d.querySelectorAll("[role=tooltip]")) {
      const m = e.textContent.replace(/\s+/g, " ").trim().match(/^(?:(\d{1,2})\s+)?([A-Za-z]+)\s+(\d{4})\s+Elements Earnings:\s*\$\s*([\d,]+(?:\.\d+)?)/i);
      if (!m || !MON[m[2].toLowerCase()]) continue;
      const v = (+m[4].replace(/,/g, "")).toFixed(2);
      out.push({ date: `${m[3]}-${p2(MON[m[2].toLowerCase()])}-${p2(m[1] || 1)}`, total_earnings: v, total_earnings_elements: v });
    }
    return out;
  }
  const dr = document.querySelector('[data-controller="date-range"]');
  if (!dr) throw LOGIN;
  const first = String(dr.dataset.dateRangeMinValue || "2021-05-01").slice(0, 10);
  const lastD = String(dr.dataset.dateRangeMaxValue || today).slice(0, 10);
  const tot = null;

  say("monthly", 10);
  const mon = { data: [] };
  for (let y = +first.slice(0, 4); y <= +today.slice(0, 4); y++) {
    const ms = y === +first.slice(0, 4) ? first.slice(0, 7) : `${y}-01`, me = y === +today.slice(0, 4) ? today.slice(0, 7) : `${y}-12`;
    mon.data.push(...(await bars("monthly", ms, me)));
    await sleep(300);
  }
  B.log(AG, `mēneši: ${mon.data.length} (lapa /reports/earnings; dienas līdz ${lastD})`);
  /* test67 (Chrome 2026-11-15): lapas "Earnings Overview" rāda jaunāko, vēl nepabeigto mēnesi ("Latest monthly earnings in October 2026
     $37.63"), mēnešu skatā tā vēl nav — ņemam lapas summu, ja lielāka. */
  try {
    const m = document.body.innerText.replace(/\s+/g, " ").match(/Latest monthly earnings in\s+([A-Za-z]+)\s+(\d{4})\s*\$\s*([\d,]+\.\d{2})/i);
    if (m && MON[m[1].toLowerCase()]) {
      const ym = `${m[2]}-${p2(MON[m[1].toLowerCase()])}`, v = +m[3].replace(/,/g, "");
      let r = mon.data.find((x) => String(x.date || "").slice(0, 7) === ym);
      if (!r) { r = { date: ym + "-01" }; mon.data.push(r); }
      if (v > (+r.total_earnings || 0)) {
        B.log(AG, `${ym}: lapā $${v.toFixed(2)}, mēnešu skatā $${(+r.total_earnings || 0).toFixed(2)} — ņemu lapas summu (mēnesis vēl nav pabeigts)`);
        r.total_earnings = r.total_earnings_elements = v.toFixed(2);
      }
    }
  } catch (e) { /* lapas teksts — tikai papildinājums */ }
  await send("monthly", { rows: mon.data, only: "elements" });
  /* gaidāmā izmaksa (test48): šī mēneša Elements ienākumi līdz šodienai (bruto, mainās katru dienu) */
  try {
    const cur = mon.data.find((r) => String(r.date || "").slice(0, 7) === today.slice(0, 7));
    if (cur) await sendPayInfo({ unpaid: +cur.total_earnings_elements || 0, currency: "USD" });
  } catch (_) { /* */ }

  const dfirst = first;
  const dstart = OPTS.mode === "full" ? dfirst : (OPTS.since > dfirst ? OPTS.since : dfirst);
  say("daily", 20);
  const drows = [];
  for (let s0 = dstart; s0 <= lastD; ) {
    const e0d = new Date(s0 + "T00:00:00Z"); e0d.setUTCDate(e0d.getUTCDate() + 360);
    const e0 = e0d.toISOString().slice(0, 10) < lastD ? e0d.toISOString().slice(0, 10) : lastD;
    drows.push(...(await bars("daily", s0, e0)));
    e0d.setUTCDate(e0d.getUTCDate() + 1); s0 = e0d.toISOString().slice(0, 10);
    await sleep(300);
  }
  await send("daily", { start: dstart, end: lastD, rows: drows, only: "elements" });

  /* vienumu ienākumi pa mēnešiem */
  const md = await R("performance/meta_data?shopfront=Elements");
  const ef = (md.earliest_record_date || dfirst).slice(0, 10), el = (md.latest_record_date || today).slice(0, 10);
  let months = monthsBack(+ef.slice(0, 4), +ef.slice(5, 7), +el.slice(0, 4), +el.slice(5, 7));
  /* lietotājs 2026-11-01: tikai mēneši kopš pēdējās atjaunošanas (OPTS.items_from), ne visi gadi */
  const recentM = (l) => l.filter(([y, m]) => `${y}-${String(m).padStart(2, "0")}` >= (OPTS.items_from || "9999"));
  if (OPTS.mode !== "full") { months = recentM(months); if (!months.length) months = [[+today.slice(0, 4), +today.slice(5, 7)]]; }
  for (let i = 0; i < months.length; i++) {
    const [y, m] = months[i];
    const ms = `${y}-${String(m).padStart(2, "0")}`;
    const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
    const s = `${ms}-01` < ef ? ef : `${ms}-01`, e = last > el ? el : last;
    let page = 1, pages = 1;
    do {
      say(`${ms} · ${page}/${pages}`, 25 + Math.round((i / months.length) * 70));
      const q = new URLSearchParams({ shopfront: "Elements", start_date: s, end_date: e, sort_by: "total_earnings",
        sort_direction: "desc", new_item_only: "false", page: String(page) });
      const j = await R("performance/item_performance?" + q);
      pages = Math.max(1, j.total_pages || 1);
      const rows = j.data || [];
      const stop = !rows.length || rows.every((r) => !(+r.total_earnings));   // kārtots dilstoši — tālāk tikai nulles
      await send("items", { month: ms, page, rows, shopfront: "Elements", last: i === months.length - 1 && (page >= pages || stop) });
      if (stop) break;
      page++;
    } while (page <= pages && page < 200);
  }
  /* Envato Market (tie paši autora dati): vienumu ienākumi pa mēnešiem, ja portāls tos dod */
  try {
    const mm = await R("performance/meta_data?shopfront=Market");
    const mf = ((mm && mm.earliest_record_date) || "").slice(0, 10), ml = ((mm && mm.latest_record_date) || today).slice(0, 10);
    if (mf) {
      let mlist = monthsBack(+mf.slice(0, 4), +mf.slice(5, 7), +ml.slice(0, 4), +ml.slice(5, 7));
      if (OPTS.mode !== "full" && sales_state_market_done()) mlist = recentM(mlist);
      let n = 0;
      for (let i = 0; i < mlist.length; i++) {
        const [y, m] = mlist[i];
        const ms = `${y}-${String(m).padStart(2, "0")}`;
        const last = new Date(Date.UTC(y, m, 0)).toISOString().slice(0, 10);
        const s = `${ms}-01` < mf ? mf : `${ms}-01`, e = last > ml ? ml : last;
        let page = 1, pages = 1;
        do {
          say(`Market ${ms} · ${page}/${pages}`, 95);
          const q = new URLSearchParams({ shopfront: "Market", start_date: s, end_date: e, sort_by: "total_earnings",
            sort_direction: "desc", new_item_only: "false", page: String(page) });
          const j = await R("performance/item_performance?" + q);
          pages = Math.max(1, j.total_pages || 1);
          const rows = j.data || [];
          const stop = !rows.length || rows.every((r) => !(+r.total_earnings));
          if (rows.length && !window.__vdMk) { window.__vdMk = 1; const r0 = rows[0];
            B.log(AG, "Envato Market rindas atslēgas: " + keysOf(r0) + " · " + ["item_name", "name", "title", "category", "url"].map((k) => k + "=" + String(r0[k] == null ? "" : r0[k]).slice(0, 40)).join(" | ")); }
          n += rows.length;
          await send("items", { month: ms, page, rows, shopfront: "Market", last: i === mlist.length - 1 && (page >= pages || stop) });
          if (stop) break;
          page++;
        } while (page <= pages && page < 200);
      }
      B.log(AG, `Envato Market: ${mlist.length} mēneši${mlist.length ? " (" + mlist[mlist.length - 1].join("-") + "…" + mlist[0].join("-") + ")" : ""}, ${n} vienumu rindas`);
    } else B.log(AG, "Envato Market: vienumu datu nav");
  } catch (e) { if (e && e.login) throw e; B.log(AG, "Envato Market vienumi: " + ((e && e.message) || e)); }
  /* 0.3.1-test3 (lietotājs 2026-11-01): Market atlikums — author.envato.com/profile → "Balances" → Market (pēc nodokļa;
     Elements kartīte lielāko laiku tukša — Elements prognoze paliek no atskaitēm). Minimums $50, atsevišķi no Elements. */
  try {
    say("Market atlikums", 96);
    let eb = null, etx = null;   // test68: arī Elements atlikums ("Elements $499.93 (This amount includes an after-tax component of $275.00)")
    const mb = await framed("/profile", (t) => {
      const i = t.search(/\bBalances\b/); if (i < 0) return null;
      const e = t.slice(i).match(/\bElements\b\s*\$\s*([\d,]+(?:\.\d{1,2})?)/);
      if (e) { eb = e[1]; const x = t.slice(i).match(/after-tax component of\s*\$\s*([\d,]+(?:\.\d{1,2})?)/i); etx = x ? x[1] : null; }
      const m = t.slice(i).match(/\bMarket\b\s*\$\s*([\d,]+(?:\.\d{1,2})?)/); return m ? m[1] : null; }, 20000);
    if (eb != null) { await send("elements_balance", { amount: money(eb), after_tax: etx != null ? money(etx) : null });
      B.log(AG, "Elements atlikums (Balances): $" + eb + (etx ? ` (t.sk. pēc nodokļa $${etx})` : "")); }
    if (mb != null) { await send("market_info", { unpaid: money(mb), available: money(mb), min: 50, currency: "USD" }); B.log(AG, "Market atlikums (Balances): $" + mb); }
    else B.log(AG, "Market atlikums: Balances lapā nav atrasts");
  } catch (e) { if (e && e.login) throw e; B.log(AG, "Market atlikums: " + ((e && e.message) || e)); }
  let trolleyUrl = "";
  /* izmaksu vēsture — author.envato.com/payout_method ("<summa> USD SENT Sent: Oct 15, 2026") */
  await payoutsSafe(async () => {
    /* 0.3.1-test6 (lietotājs 2026-11-03: žurnālā rāmī redzams tikai sīkdatņu paziņojums): aizveram paziņojumu,
       izvēlamies "All Payments", gaidām ilgāk; ja neizdodas — žurnālā teksts AIZ paziņojuma (izpētei) */
    let clicked = false, tries = 0, lastT = "", vaClicked = false, vaT = 0;
    let apis = [];
    const txt = await framed("/payout_method", (t, d) => {
      lastT = t;
      /* 2026-11-06 (lietotāja saglabātā lapa): izmaksas ir Trolley logrīkā (widget.trolley.com, cits domēns, parakstīta
         adrese) — rāmī nolasīt nevar; adresi paņemam un pēc galvenā darba atveram to pašā logā (payNav) */
      try { const tf = d.querySelector('iframe[src*="widget.trolley.com"]'); if (tf && tf.src) { trolleyUrl = tf.src; return "trolley"; } } catch (_) { /* */ }
      try { apis = [...new Set(d.defaultView.performance.getEntriesByType("resource").filter((e) => /fetch|xmlhttprequest/.test(e.initiatorType)).map((e) => { const u = new URL(e.name); return u.host + u.pathname; }))].slice(0, 15); } catch (_) { /* */ }
      const vaBtn = () => { try { return [...d.querySelectorAll("a, button")].find((b) => /view all payments/i.test(b.innerText || "")); } catch (_) { return null; } };
      if (/Sent:\s*[A-Z][a-z]+ \d/.test(t)) {
        const va = vaBtn();
        if (va && !vaClicked) { vaClicked = true; vaT = Date.now(); va.click(); return null; }   // visa vēsture
        if (!vaClicked || Date.now() - vaT > 6000) return t;
        return null;
      }
      /* 2026-11-05 (lietotāja ekrānuzņēmums): "Recent Payments" lapas apakšā — "228.64 USD SENT · Sent: Oct 15, 2026";
         ielādējas, kad saraksts redzams → ritinām uz leju; "View all payments" — visa vēsture */
      try { d.defaultView.scrollTo(0, d.body.scrollHeight); } catch (_) { /* */ }
      if (++tries % 3 === 0) {
        try {
          const bs = [...d.querySelectorAll("button, a, [role=button], [role=option], option, li")];
          const ck = bs.find((b) => /^(accept all|accept|allow all|i agree|got it)$/i.test((b.innerText || b.textContent || "").trim()));
          if (ck) ck.click();
          const sel = [...d.querySelectorAll("select")].find((x) => [...x.options].some((o) => /all payments/i.test(o.text)));
          if (sel && !/all payments/i.test(sel.options[sel.selectedIndex].text)) {
            sel.value = [...sel.options].find((o) => /all payments/i.test(o.text)).value;
            sel.dispatchEvent(new Event("change", { bubbles: true }));
          } else if (!clicked) {
            const ap = bs.find((b) => /^all payments$/i.test((b.innerText || b.textContent || "").trim()));
            if (ap) { ap.click(); clicked = true; }
          }
        } catch (_) { /* */ }
      }
      return null;
    }, 45000, null, true);
    if (txt === "trolley") { B.log(AG, "izmaksas: Trolley logrīks atrasts — atvēršu pēc galvenā darba"); return; }
    if (!txt) {
      /* 2026-11-06 (žurnāls): saraksts rāmī neparādās — pierakstām, ko lapa ielādē (lai ņemtu tieši no API) */
      B.log(AG, "izmaksas: lapas API: " + (apis.join(" · ") || "nav"));
      const body = lastT.replace(/\s+/g, " ");
      const k = body.search(/accept all|reject all|cookie settings/i);
      B.log(AG, "izmaksas: payout_method lapā izmaksu nav; teksts aiz paziņojuma: " + (k >= 0 ? body.slice(k, k + 300) : body.slice(0, 300)) + " … beigas: " + body.slice(-250) + ` (garums ${body.length})`);
      return;
    }
    const rows = [], re = /([\d,]+\.\d{2})\s*USD\s*SENT\s*Sent:\s*([A-Z][a-z]+ \d{1,2}, \d{4})/g;
    let m; while ((m = re.exec(txt))) rows.push({ date: pdate(m[2]), amount: money(m[1]), currency: "USD" });
    await sendPayouts(rows);
  });
  const pn = await portfolioSafe([
    ["meta_data", async () => countKey(md, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["total", async () => { const n = countKey(tot && tot.data, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: total atslēgas: " + keysOf(tot && tot.data)); return n; }],
  ]);
  /* Portfolio Manager — portfolio.envato.com/items "Approved for Sale (N)" (lietotājs 2026-10-30); cits domēns → logs pāriet */
  /* 2026-11-05: Portfolio Manager atveram reizi dienā arī tad, ja skaits jau atrasts — tur ir iesniegumu statusu CSV */
  if (trolleyUrl) { return await payNav(trolleyUrl, { port: !pn || OPTS.port_due || OPTS.sub_due }); }
  if (!pn || OPTS.port_due || OPTS.sub_due) { const r = await portNav("https://portfolio.envato.com/items", "Approved for Sale\\s*\\(\\s*(\\d[\\d,]*)\\s*\\)", "Portfolio Manager (Approved for Sale)", false, true); if (r) return r; }
  return { months: months.length };
}
function sales_state_market_done() { return !!OPTS.market_done; }

/* Portfolio Manager lapā (portfolio.envato.com/items): bilžu sīktēli un nosaukumi — sīktēliem pārdošanu sarakstā
   (sasaiste pēc nosaukuma; item_performance sīktēlus dod ne visām bildēm). Lapo, ritinot uz leju. */
/* 2026-11-05 (lietotājs): Portfolio Manager → "Download CSV" — visas bildes ar statusu (In Review / Changes required /
   Approved for Sale / Unavailable), faila nosaukumu, virsrakstu, atslēgvārdiem. Lejupielādi pārtveram (blob vai saite),
   neko nesaglabājam diskā; rindas sūtām Analītiķim (iesniegumu statusi, noteikumi §7). */
function csvParse(t) {
  const out = []; let row = [], f = "", q = false;
  for (let i = 0; i < t.length; i++) {
    const ch = t[i];
    if (q) { if (ch === '"') { if (t[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; continue; }
    if (ch === '"') q = true; else if (ch === ",") { row.push(f); f = ""; }
    else if (ch === "\n") { row.push(f); out.push(row); row = []; f = ""; } else if (ch !== "\r") f += ch;
  }
  if (f || row.length) { row.push(f); out.push(row); }
  return out;
}
async function envCsv() {
  const btn = [...document.querySelectorAll("button, a, [role=button]")].find((b) => /download csv/i.test((b.innerText || b.textContent || "").trim()));
  if (!btn) { B.log(AG, "statusi: poga \"Download CSV\" nav atrasta"); return; }
  let got = null;
  const oCreate = URL.createObjectURL, oClick = HTMLAnchorElement.prototype.click, oOpen = window.open;
  const t0 = performance.now();
  URL.createObjectURL = function (b) { if (b && b.text && !got) got = b.text(); return oCreate.apply(this, arguments); };
  HTMLAnchorElement.prototype.click = function () {
    const h = this.href || "";
    if (/\.csv|download|export/i.test(h + " " + (this.download || "")) && !got) {
      got = h.startsWith("blob:") ? fetch(h).then((r) => r.text()) : fetch(h, { credentials: "include" }).then((r) => r.text());
      return;                                                     // neļaujam pārlūkam saglabāt failu
    }
    return oClick.apply(this, arguments);
  };
  window.open = function (u) { if (!got && u) { got = fetch(u, { credentials: "include" }).then((r) => r.text()); return null; } return oOpen.apply(this, arguments); };
  try {
    btn.click();
    for (let i = 0; i < 90 && !got; i++) await sleep(500);
  } finally { URL.createObjectURL = oCreate; HTMLAnchorElement.prototype.click = oClick; window.open = oOpen; }
  if (!got) {
    const res = performance.getEntriesByType("resource").filter((e) => e.startTime >= t0).map((e) => e.name.replace(/\?.*$/, "")).slice(0, 12);
    B.log(AG, "statusi: CSV nepārtverts; pieprasījumi pēc klikšķa: " + (res.join(" | ") || "nav"));
    return;
  }
  const text = await got;
  const rows = csvParse(text || "");
  const head = (rows.shift() || []).map((x) => x.trim().toLowerCase());
  const ix = (k) => head.indexOf(k);
  if (ix("item_uuid") < 0 || ix("status") < 0) { B.log(AG, "statusi: CSV galva negaidīta: " + head.join(",").slice(0, 200)); return; }
  const items = rows.filter((r) => r.length >= head.length - 1).map((r) => ({ id: r[ix("item_uuid")], file: r[ix("file_name")] || "",
    title: r[ix("title")] || "", tags: r[ix("tags")] || "", status: r[ix("status")] || "", submitted: r[ix("submitted_at")] || "" }));
  const N = 500, parts = Math.ceil(items.length / N) || 1;
  for (let p = 0; p < parts; p++) await send("sub_items", { rows: items.slice(p * N, (p + 1) * N), part: p + 1, parts });
  B.log(AG, `statusi: Portfolio Manager CSV — ${items.length} bildes`);
}
async function portPageExtra() {
  try { await envCsv(); } catch (e) { B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); }
  /* 0.3.1-test19 (Chrome 2026-11-08): lapa ņem bildes no JSON /items/search (uuid + thumbnail_url) — tas pats ID kā pārdošanām;
     agrāk lapas attēli bez ID → "sīktēli nav atrasti" (3756 Envato bildes bez sīktēla) */
  try {
    const out = [];
    for (let p = 1; p <= 200; p++) {
      const j = await fetch(`/items/search?status=&page=${p}&per_page=100&sort=newest`, { credentials: "include", headers: { accept: "application/json" } }).then((r) => r.json());
      for (const it of (j && j.items) || []) if (it.uuid && it.thumbnail_url) out.push({ id: it.uuid, title: it.title || "", thumb: it.thumbnail_url, href: "",
        filename: /^E\d{3}X/i.test(it.main_file_download_filename || "") ? "" : (it.main_file_download_filename || "") });   // vecajām Envato pārdēvētas (E101X…)
      const tp = ((j && j.meta) || {}).total_pages || 1;
      if (p >= tp || !((j && j.items) || []).length) break;
      await sleep(250);
    }
    if (out.length) {
      for (let i = 0; i < out.length; i += 500) await send("thumbs_title", { rows: out.slice(i, i + 500) });
      B.log(AG, `Portfolio Manager: sīktēli no /items/search — ${out.length}`);
      return;
    }
    B.log(AG, "Portfolio Manager: /items/search — 0 bildes, mēģinu no lapas");
  } catch (e) { B.log(AG, "Portfolio Manager: /items/search — " + String((e && e.message) || e).slice(0, 120)); }
  const seen = new Map();
  const idOf = (el) => {
    const a = el && el.closest && el.closest("a");
    const h = (a && a.href) || "";
    const m = h.match(/(?:items?|item_id=|\/)(\d{5,})(?:[/?#]|$)/) || String((el && el.closest && (el.closest("[data-item-id],[data-id]") || {}).dataset && JSON.stringify(el.closest("[data-item-id],[data-id]").dataset)) || "").match(/(\d{5,})/);
    return m ? m[1] : "";
  };
  const grab = () => {
    /* fona attēli (div style="background-image") — daži saraksti sīktēlus rāda tā */
    for (const el of document.querySelectorAll("[style*='background-image']")) {
      const m = (el.getAttribute("style") || "").match(/url\(["']?(https?:[^"')]+)/);
      if (!m) continue;
      const card = el.closest("a, li, article, [class*=card], [class*=item]") || el.parentElement;
      const title = ((card && card.innerText) || "").split("\n").map((x) => x.trim()).filter((x) => x.length > 6 && !/^approved|^in review|^photo|^image$/i.test(x))[0] || "";
      const key = title || idOf(el);
      if (key && !seen.has(key)) seen.set(key, { title: title.replace(/[…\.]+$/, "").trim(), thumb: m[1], href: (el.closest("a") || {}).href || "", id: idOf(el) });
    }
    for (const img of document.images) {
      const src = img.currentSrc || img.src || "";
      if (!/^https?:/.test(src) || (img.naturalWidth && img.naturalWidth < 60)) continue;
      const card = img.closest("a, li, article, [class*=card], [class*=item]") || img.parentElement;
      let title = (img.alt || "").trim();
      if (!title || title.length < 4) title = ((card && card.innerText) || "").split("\n").map((x) => x.trim()).filter((x) => x.length > 6 && !/^approved|^in review|^photo|^image$/i.test(x))[0] || "";
      const id = idOf(img);
      if (!title && !id) continue;
      const a = img.closest("a");
      const key = title || id;
      if (!seen.has(key)) seen.set(key, { title: title.replace(/[…\.]+$/, "").trim(), thumb: src, href: a ? a.href : "", id });
    }
  };
  for (let i = 0; i < 25; i++) {
    grab();
    const before = document.documentElement.scrollHeight;
    window.scrollTo(0, before);
    await sleep(1200);
    if (document.documentElement.scrollHeight <= before && i > 2) { grab(); break; }
  }
  const rows = [...seen.values()];
  if (rows[0]) B.log(AG, `Portfolio Manager: ${rows.length} bildes ar sīktēliem (ar ID: ${rows.filter((r) => r.id).length}); saites paraugs: ${String(rows[0].href).replace(/\d{6,}/g, "N").slice(0, 80)}`);
  else {
    /* test52: izpētei — kāpēc nekas netika atrasts (31.10 žurnālā nebija ne rindas) */
    const imgs = [...document.images];
    const shape = (u) => { try { const x = new URL(u); return x.host + x.pathname.replace(/\d{3,}/g, "N").slice(0, 50); } catch (_) { return String(u).slice(0, 40); } };
    B.log(AG, `Portfolio Manager: sīktēli nav atrasti; lapa ${location.host}${location.pathname}; img ${imgs.length} (http ${imgs.filter((i) => /^https?:/.test(i.currentSrc || i.src)).length}); ` +
      `paraugi: ${imgs.slice(0, 4).map((i) => `${shape(i.currentSrc || i.src)} ${i.naturalWidth}px alt="${(i.alt || "").slice(0, 25)}"`).join(" | ")}; ` +
      `fona: ${document.querySelectorAll("[style*='background-image']").length}; iframe: ${document.querySelectorAll("iframe").length}; teksts: ${(document.body.innerText || "").slice(0, 160).replace(/\s+/g, " ")}`);
  }
  if (rows.length) await send("thumbs_title", { rows });
}

/* Trolley logrīks (widget.trolley.com, atvērts ar Envato parakstīto adresi): "All Payments" →
   "228.64 USD Sent · Sent: Oct 15, 2026" (lietotāja saglabātā lapa 2026-11-06). Pēc tam — uz Portfolio Manager. */
async function payNavDone(o) {
  let t = "";
  /* 2026-11-06 (žurnāls: tikai 3 izmaksas, bez nodokļa): vispirms "View all payments", tad izvēršam katru izmaksu */
  for (let i = 0; i < 30; i++) {
    t = (document.body && document.body.innerText) || "";
    if (/Sent:\s*[A-Z][a-z]{2,8}\.? \d{1,2}, \d{4}/.test(t)) break;
    await sleep(500);
  }
  const va = [...document.querySelectorAll("a, button, [role=button]")].find((x) => /view all payments/i.test((x.innerText || "").trim()));
  if (va) { va.click(); for (let i = 0; i < 20; i++) { await sleep(500); if (/All Payments/i.test(document.body.innerText || "") && !/view all payments/i.test(document.body.innerText || "")) break; } await sleep(800); }
  /* 2026-11-07 (žurnāls: 7 izmaksas no 2026-04, izvērstas 0): rindas atpazīstam vaļīgāk; lasām visas lapas / "Load more" */
  const rows = [];
  const re = /([\d,]+\.\d{2})\s*(USD|EUR|GBP)\s*(Sent|Paid|Processed|Pending|Processing|Returned|Failed)\s*[·•|-]?\s*(?:Sent|Paid|Date|Processed|Created)?:?\s*([A-Z][a-z]{2,8}\.? \d{1,2},? \d{4})/gi;
  const parse = (t) => {
    let m;
    re.lastIndex = 0;
    while ((m = re.exec(t))) {
      if (/return|fail/i.test(m[3] || "")) continue;
      const d = pdate(m[4].replace(/(\d),? (\d{4})/, "$1, $2"));
      if (!d) continue;
      const seg = t.slice(m.index, m.index + 700), nx = seg.slice(30).search(/[\d,]+\.\d{2}\s*(USD|EUR|GBP)\s*(SENT|Sent)\b/);
      const part = nx > 0 ? seg.slice(0, 30 + nx) : seg;
      const net = (part.match(/You Receive\s*\$?\s*([\d,]+\.\d{2})/i) || [])[1];
      const gross = money(m[1]);
      if (net && money(net) < gross) rows.push({ date: d, amount: money(net), currency: m[2], status: "bruto " + gross });
      else rows.push({ date: d, amount: gross, currency: m[2] });
    }
  };
  /* test77 (Chrome 2026-11-17, žurnāls: "izvērstas 8, You Receive 0"): Trolley ieraksti ir akordeons ([aria-expanded], vienlaikus
     atvērts tikai viens); .click() tos NEatver — atver taustiņš Enter. Atveram pa vienam un nolasām katru ("You Receive" = neto). */
  const expand = async () => {
    const items = [...document.querySelectorAll("[aria-expanded]")].filter((b) => /[\d,]+\.\d{2}\s*(USD|EUR|GBP)[\s\S]{0,80}Sent:/i.test(b.textContent || ""));
    let n = 0;
    for (const b2 of items.slice(0, 60)) {
      try {
        /* test78 (žurnāls test77: "izvērstas 8, You Receive 0" — Analītiķa logā, Chrome strādāja): katra ieraksta saturs ir
           b2.parentElement (virsraksts + detaļas); lasām textContent (ietver arī vēl neattēloto), gaidām līdz 3 s */
        const box = b2.parentElement || b2;
        const has = () => /You Receive/i.test(box.textContent || "");
        /* test78 (lietotājs 2026-11-17: "pietiek atvērt tikai tos, kas Analītiķim nav zināmi"): zināmās (neto jau ierakstīts vai
           pirms 2026-09, kad Envato vēl neieturēja nodokli) neatveram un nesūtām — paliek, kā ir */
        const h0 = (b2.textContent || "").replace(/\s+/g, " ");
        re.lastIndex = 0;
        const m0 = re.exec(h0.replace(/(USD|EUR|GBP)(?=[A-Za-z])/g, "$1 ").replace(/(SENT|PAID|PROCESSED)(?=Sent|Paid)/gi, "$1 "));
        const d0 = m0 ? pdate(m0[4].replace(/(\d),? (\d{4})/, "$1, $2")) : null;
        if (d0 && isKnown(d0)) { skipped++; continue; }
        if (!has()) {
          if (b2.getAttribute("aria-expanded") !== "true") {
            b2.focus();
            for (const ty of ["keydown", "keyup"]) b2.dispatchEvent(new KeyboardEvent(ty, { key: "Enter", code: "Enter", keyCode: 13, which: 13, bubbles: true }));
          }
          for (let i = 0; i < 6 && !has() && b2.getAttribute("aria-expanded") !== "true"; i++) await sleep(150);
          if (!has() && b2.getAttribute("aria-expanded") !== "true") {
            const o = { bubbles: true, cancelable: true, view: window };
            for (const ty of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) {
              try { b2.dispatchEvent(ty.startsWith("pointer") ? new PointerEvent(ty, o) : new MouseEvent(ty, o)); } catch (_) { /* */ }
            }
          }
          for (let i = 0; i < 20 && !has(); i++) await sleep(150);
        }
        if (b2.getAttribute("aria-expanded") === "true" || has()) n++;
        if (!diag) diag = `pirmais: atvērts ${b2.getAttribute("aria-expanded")}, You Receive ${has() ? "ir" : "nav"}, lapa ${document.visibilityState}`;
        const h = (b2.textContent || "").replace(/\s+/g, " "), bx = (box.textContent || "").replace(/\s+/g, " ");
        re.lastIndex = 0;
        const m = re.exec(h.replace(/(USD|EUR|GBP)(?=[A-Za-z])/g, "$1 ").replace(/(SENT|PAID|PROCESSED)(?=Sent|Paid)/gi, "$1 "));
        if (!m || /return|fail/i.test(m[3] || "")) continue;
        const d = pdate(m[4].replace(/(\d),? (\d{4})/, "$1, $2"));
        if (!d) continue;
        const net = (bx.match(/You Receive\s*\$?\s*([\d,]+\.\d{2})/i) || [])[1], gross = money(m[1]);
        if (net && money(net) < gross) { rows.push({ date: d, amount: money(net), currency: m[2], status: "bruto " + gross }); yr++; }
        else rows.push({ date: d, amount: gross, currency: m[2] });
      } catch (_) { /* */ }
    }
    return n;
  };
  let diag = "", yr = 0, skipped = 0;
  const known = OPTS.payouts_full ? [] : (OPTS.pay_known || []);
  const isKnown = (d) => known.some((k) => Math.abs((new Date(k) - new Date(d)) / 864e5) <= 6);
  let opened = 0, pages = 0, btnInfo = "";
  for (let pg = 0; pg < 30; pg++) {
    opened += await expand();
    t = (document.body && document.body.innerText) || "";
    pages++;
    const btns = [...document.querySelectorAll("button, a, [role=button]")];
    if (pg === 0) btnInfo = btns.map((e) => ((e.getAttribute("aria-label") || e.innerText || "").trim().slice(0, 18) + (e.disabled || e.getAttribute("aria-disabled") === "true" ? "(x)" : ""))).filter(Boolean).slice(-20).join(" | ");
    const nb = btns.find((e) => !e.disabled && e.getAttribute("aria-disabled") !== "true" &&
      (/^(load more|show more|more|next|›|>|»)$/i.test((e.innerText || "").trim()) || /next page|load more|show more/i.test(e.getAttribute("aria-label") || "")));
    if (!nb) break;
    const before = t;
    nb.click();
    let changed = false;
    for (let i = 0; i < 20; i++) { await sleep(500); if (((document.body && document.body.innerText) || "") !== before) { changed = true; break; } }
    if (!changed) break;
    await sleep(800);
  }
  B.log(AG, `izmaksas: Trolley — lapas ${pages}, izvērstas ${opened}, "You Receive" ${yr}, zināmas (neatvērtas) ${skipped}, rindas ${rows.length}; ${diag}`);
  if (!opened && !skipped) {
    const k = t.search(/[\d,]+\.\d{2}\s*(USD|EUR|GBP)/);
    B.log(AG, "izmaksas: Trolley paraugs: " + (k >= 0 ? t.slice(k, k + 250) : t.slice(0, 250)).replace(/\s+/g, " ") + " · pogas: " + btnInfo);
  }
  /* test77: ja kādā lapas nolasījumā tai pašai dienai ir neto ("You Receive") — bruto rindu (tā pati summa) izmetam */
  const netBy = new Map(rows.filter((r) => /^bruto /.test(r.status || "")).map((r) => [r.date + "|" + r.status.slice(6), r]));
  const seen = new Set(), uniq = rows.filter((r) => !(!r.status && netBy.has(r.date + "|" + r.amount)))
    .filter((r) => { const k = r.date + r.amount; if (seen.has(k)) return false; seen.add(k); return true; })
    .sort((a, b) => (a.date < b.date ? 1 : -1));
  /* tikai jaunās/nezināmās: aizstājam no agrākās nolasītās dienas (vecās paliek); pilnajā — visu */
  if (uniq.length) { await sendPayouts(uniq, known.length ? { full: false, start: uniq[uniq.length - 1].date } : {}); await send("pay_checked", {}); }
  else if (skipped) { B.log(AG, "izmaksas: jaunu izmaksu nav"); await send("pay_checked", {}); }
  else B.log(AG, "izmaksas: Trolley lapā izmaksas nav atrastas; teksts: " + t.replace(/\s+/g, " ").slice(0, 300));
  if (o.port) { const r = await portNav("https://portfolio.envato.com/items", "Approved for Sale\\s*\\(\\s*(\\d[\\d,]*)\\s*\\)", "Portfolio Manager (Approved for Sale)", false, true); if (r) return "nav"; }
  await B.done(AG, JSON.stringify({ payouts: uniq.length }));
  return "nav";
}
