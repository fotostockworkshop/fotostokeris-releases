#!/bin/bash
# Fotostokera produkta uzstādīšana uz Mac kā parasta lietotne (noteikumi §3 "Palaišana").
#   bash core/mac/install_app.sh <Slug> "<Nosaukums>" <bundle id> [ikona.icns]
# Programmas mape (ar core/, web/, run_mac.command) tiek nokopēta lietotnes iekšienē:
#   /Applications/<Nosaukums>.app/Contents/Resources/app   (ja nav rakstāms — ~/Applications)
# Lietotni izveido šis dators pats, tāpēc tai nav "lejupielādēts no interneta" atzīmes un macOS to vairs
# neprasa apstiprināt. Datu mape (~/Library/Application Support/<Slug>) netiek aiztikta.
set -e
SLUG="$1"; NAME="$2"; BID="$3"; ICNS="$4"
SRC="$(cd "$(dirname "$0")/../.." && pwd)"                 # izpakotā programmas mape
[ -f "$SRC/$SLUG.py" ] || { echo "Nav atrasts $SLUG.py mapē $SRC"; exit 1; }

echo "== $NAME — uzstādīšana =="
xattr -dr com.apple.quarantine "$SRC" 2>/dev/null || true

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 nav atrasts. Uzstādi to no https://www.python.org/downloads/ un palaid šo failu vēlreiz."
  exit 1
fi

DEST_DIR="/Applications"
[ -w "$DEST_DIR" ] || { DEST_DIR="$HOME/Applications"; mkdir -p "$DEST_DIR"; }
APP="$DEST_DIR/$NAME.app"
RES="$APP/Contents/Resources/app"

# programma jau darbojas? — aptur (tā pati darbība kā palaižot jaunu versiju)
pkill -f "$SLUG.py" 2>/dev/null || true
sleep 1

echo "Lietotne: $APP"
mkdir -p "$APP/Contents/MacOS" "$RES"
# programmas faili (vecie tiek aizstāti; .venv paliek, ja jau ir)
( cd "$SRC" && find . -mindepth 1 -maxdepth 1 ! -name .venv ! -name '*.command' -exec cp -R {} "$RES/" \; )
cp "$SRC/run_mac.command" "$RES/run_mac.command"           # vajadzīgs automātiskajai atjaunināšanai
chmod +x "$RES/run_mac.command"
[ -n "$ICNS" ] && [ -f "$SRC/$ICNS" ] && cp "$SRC/$ICNS" "$APP/Contents/Resources/AppIcon.icns"

VER=$(sed -n 's/^VERSION = "\(.*\)"/\1/p' "$RES/$(echo "$SLUG" | tr '[:upper:]' '[:lower:]')/__init__.py" 2>/dev/null | head -1)
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$NAME</string>
  <key>CFBundleDisplayName</key><string>$NAME</string>
  <key>CFBundleIdentifier</key><string>$BID</string>
  <key>CFBundleExecutable</key><string>$SLUG</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VER:-0}</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
</dict></plist>
PLIST

# lietotnes palaidējs: tas pats, ko dara run_mac.command, tikai bez termināļa loga
cat > "$APP/Contents/MacOS/$SLUG" <<SH
#!/bin/bash
cd "\$(dirname "\$0")/../Resources/app" || exit 1
LOGDIR="\$HOME/Library/Application Support/$SLUG"
mkdir -p "\$LOGDIR"
# no Finder palaistai lietotnei PATH ir īss — vispirms python.org / Homebrew Python
PY=""
for c in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 /usr/local/bin/python3 /opt/homebrew/bin/python3; do
  [ -x "\$c" ] && { PY="\$c"; break; }
done
[ -n "\$PY" ] || PY=\$(command -v python3)
if [ ! -x .venv/bin/python ]; then
  osascript -e 'display notification "Pirmā palaišana — sagatavoju vidi (~1 min)…" with title "$NAME"' 2>/dev/null
  "\$PY" -m venv .venv >> "\$LOGDIR/log-start.txt" 2>&1
fi
if ! cmp -s requirements.txt .venv/req.txt; then
  osascript -e 'display notification "Uzstādu jaunās bibliotēkas…" with title "$NAME"' 2>/dev/null
  .venv/bin/python -m pip install --upgrade pip >> "\$LOGDIR/log-start.txt" 2>&1
  .venv/bin/python -m pip install -r requirements.txt >> "\$LOGDIR/log-start.txt" 2>&1 && cp requirements.txt .venv/req.txt
fi
export $(echo "$SLUG" | tr '[:lower:]' '[:upper:]')_LOG=1
exec .venv/bin/python -u $SLUG.py > "\$LOGDIR/log-start.txt" 2>&1
SH
chmod +x "$APP/Contents/MacOS/$SLUG"

# vide un bibliotēkas — tagad (terminālī redzams), lai pirmā palaišana būtu ātra
cd "$RES"
if [ ! -x .venv/bin/python ]; then
  echo "Sagatavoju vidi (minūte)…"
  python3 -m venv .venv
fi
if ! cmp -s requirements.txt .venv/req.txt; then
  echo "Uzstādu bibliotēkas (pywebview, keyring)…"
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  if .venv/bin/python -m pip install -r requirements.txt; then
    cp requirements.txt .venv/req.txt
  else
    echo "Bibliotēkas neizdevās uzstādīt (vai ir internets?). Programma mēģinās vēlreiz, kad to palaidīsi."
  fi
fi

xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"                                              # Finder/Launchpad ikonas atjaunošanai
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" 2>/dev/null || true

echo
echo "Gatavs! $NAME ir uzstādīts: $APP"
echo "Turpmāk palaid to no Launchpad, Spotlight vai mapes Programmas (Applications)."
echo "Ieteikums: kad programma atvērta, Dock ikonai labais klikšķis → Opcijas → Paturēt Dock."
echo "Šo mapi ($SRC) tagad var izdzēst. Tavi dati un paroles paliek savā vietā."
open "$APP" 2>/dev/null || true
