"""Vienas bildes kopiju apvienošana starp aģentūrām: ar roku un pēc sīktēla izskata (lietotājs 2026-10-30).

Problēma: sērijā vairākām bildēm vienāds virsraksts katrā aģentūrā → pēc virsraksta nevar zināt, kura Shutterstock
bilde atbilst kurai Adobe bildei (db.regroup tās neapvieno), un viena bilde izskatās kā vairākas kartītes.

1) Ar roku: lietotājs atzīmē kartītes → "Apvienot: tā pati bilde" (visi vienumi vienā grupā) vai "Atdalīt" (katrs
   vienums atsevišķi). Glabājas img_link (src='man'); šie vienumi pārējās automātiskajās sasaistēs nepiedalās.
2) Automātiski: vienumiem, kuru virsraksts aģentūrā atkārtojas (un tas pats virsraksts ir citās aģentūrās), programma
   lejupielādē sīktēlu, aprēķina dHash (8×8, noteikumi §8 phash) un sasaista līdzīgākos dažādu aģentūru vienumus
   (attālums ≤ MAX_DIST, katra aģentūra grupā vienreiz). img_link src='auto'.
"""
from __future__ import annotations

import hashlib
import io
import threading
import time
import urllib.request
import uuid

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS img_link(agency TEXT, agency_item_id TEXT, key TEXT, src TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE INDEX IF NOT EXISTS img_link_key ON img_link(key);
CREATE TABLE IF NOT EXISTS thumb_hash(agency TEXT, agency_item_id TEXT, thumb TEXT, h TEXT, PRIMARY KEY(agency, agency_item_id));
"""
MAX_DIST = 10            # dHash attālums (no 64 bitiem), līdz kuram uzskata par to pašu bildi
PER_RUN = 300            # cik sīktēlus lejupielādēt vienā reizē (pārējos — nākamreiz)
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"

_run_lock = threading.Lock()


def ensure(c=None) -> None:
    (c or db.conn()).executescript(SCHEMA)


# --------------------------------------------------------------------------- ar roku

def _members(c, items: list[dict]) -> list[tuple[str, str]]:
    out = []
    for it in items:
        ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
        if not ag or not iid:
            continue
        a = c.execute("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
        if a and a["gid"]:
            out += [(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM assets WHERE gid=?", (a["gid"],))]
        out.append((ag, iid))
    return sorted(set(out))


def merge(items: list[dict]) -> int:
    """Atzīmētās kartītes (ar visām to kopijām) — viena bilde."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        mem = _members(c, items)
        key = "m:" + uuid.uuid4().hex[:12]
        for ag, iid in mem:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (ag, iid, key, "man"))
        c.commit()
    db.regroup()
    return len(mem)


def split(items: list[dict]) -> int:
    """Kartīte(s) — katrs aģentūras vienums atsevišķi (automātika tos vairs neapvieno)."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        mem = _members(c, items)
        for ag, iid in mem:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (ag, iid, f"s:{ag}|{iid}", "man"))
        c.commit()
    db.regroup()
    return len(mem)


# --------------------------------------------------------------------------- automātiski (sīktēla līdzība)

def dhash(data: bytes) -> str | None:
    """dHash 8×8 (64 biti, 16 hex) no attēla baitiem; None, ja Pillow nav vai attēls bojāts."""
    try:
        from PIL import Image  # type: ignore
    except ImportError:
        return None
    try:
        im = Image.open(io.BytesIO(data)).convert("L")
        w, h = im.size
        if w > 40 and h > 40:                 # ūdenszīmes/rāmji malās — nedaudz apgriežam
            im = im.crop((int(w * .04), int(h * .04), int(w * .96), int(h * .96)))
        im = im.resize((9, 8), Image.LANCZOS)
        px = list(im.getdata())
        bits = 0
        for y in range(8):
            for x in range(8):
                bits = (bits << 1) | (1 if px[y * 9 + x] > px[y * 9 + x + 1] else 0)
        return f"{bits:016x}"
    except Exception:
        return None


def dist(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


def _fetch(url: str) -> bytes | None:
    try:
        req = urllib.request.Request(url, headers={"User-Agent": UA, "Accept": "image/*"})
        with urllib.request.urlopen(req, timeout=12) as r:
            return r.read(2_000_000)
    except Exception:
        return None


def bucket(mk: str | None) -> str | None:
    """Virsraksta sākums (5 vārdi): aģentūras virsrakstus saīsina dažādi (iStock ~50 zīmes), tāpēc salīdzina sākumu."""
    w = (mk or "").split()
    return " ".join(w[:5]) if len(w) >= 5 else None


def _candidates(c) -> list:
    """Vienumi, kuru virsraksta sākums vienā aģentūrā atkārtojas un ir arī citā aģentūrā (tur virsraksts nepalīdz)."""
    rows = c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, a.thumb, th.thumb hthumb, th.h FROM assets a
                        LEFT JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id
                        WHERE a.mkey IS NOT NULL AND a.thumb LIKE 'http%'""").fetchall()
    by = {}
    for r in rows:
        b = bucket(r["mkey"])
        if b:
            by.setdefault(b, []).append(r)
    out = []
    for b, items in by.items():
        ags = [i["agency"] for i in items]
        if len(set(ags)) > 1 and len(ags) > len(set(ags)):
            out += items
    return out


def run() -> dict:
    """Viena kārta: lejupielādē trūkstošos sīktēlus (≤ PER_RUN), aprēķina dHash, sasaista. Drošs atkārtot."""
    if not _run_lock.acquire(blocking=False):
        return {"busy": True}
    try:
        try:
            from PIL import Image  # noqa: F401
        except ImportError:
            return {"no_pillow": True}
        with db._lock:
            c = db.conn()
            ensure(c)
            rows = [dict(r) for r in _candidates(c)]
        todo = [r for r in rows if r["h"] is None or r["hthumb"] != r["thumb"]][:PER_RUN]
        got = 0
        for r in todo:
            data = _fetch(r["thumb"])
            h = dhash(data) if data else None
            with db._lock:
                c = db.conn()
                c.execute("INSERT OR REPLACE INTO thumb_hash VALUES(?,?,?,?)", (r["agency"], r["agency_item_id"], r["thumb"], h or ""))
                c.commit()
            r["h"] = h or ""
            got += 1 if h else 0
            time.sleep(0.05)
        linked = _link()
        if got or linked:
            db.regroup()
        return {"candidates": len(rows), "hashed": got, "linked": linked, "left": len([r for r in rows if r["h"] is None])}
    finally:
        _run_lock.release()


def _cluster(items: list[dict], key_prefix: str, c) -> int:
    """Dažādu aģentūru vienumi ar līdzīgu nospiedumu (h) → viena grupa; līdzīgākie pāri pirmie, aģentūra grupā vienreiz."""
    if len({i["agency"] for i in items}) < 2:
        return 0
    pairs = sorted(((dist(a["h"], b["h"]), ia, ib) for ia, a in enumerate(items) for ib, b in enumerate(items)
                    if ia < ib and a["agency"] != b["agency"]), key=lambda x: x[0])
    parent = list(range(len(items)))
    ags = [{i["agency"]} for i in items]

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for d, ia, ib in pairs:
        if d > MAX_DIST:
            break
        ra, rb = find(ia), find(ib)
        if ra != rb and not (ags[ra] & ags[rb]):
            parent[rb] = ra
            ags[ra] |= ags[rb]
    groups = {}
    for i in range(len(items)):
        groups.setdefault(find(i), []).append(items[i])
    n = 0
    for g in groups.values():
        if len(g) < 2:
            continue
        g.sort(key=lambda x: (x["agency"], x["agency_item_id"]))
        key = key_prefix + hashlib.sha1((g[0]["agency"] + "|" + g[0]["agency_item_id"]).encode()).hexdigest()[:12]
        for it in g:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (it["agency"], it["agency_item_id"], key, "auto"))
            n += 1
    return n


def _link() -> int:
    """Automātiskās sasaistes no jauna: (1) Microstockr grupās — pēc Microstockr nospieduma; (2) pārējās — pēc mūsu
    dHash vienumiem ar līdzīgu virsraksta sākumu. Lietotāja lēmumi (man) netiek aiztikti."""
    with db._lock:
        c = db.conn()
        ensure(c)
        manual = {(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM img_link WHERE src='man'")}
        c.execute("DELETE FROM img_link WHERE src='auto'")
        n, done = 0, set()
        # (1) Microstockr: tag grupā (sērija var būt vienā grupā) — nospiedums izšķir kadrus
        mr = c.execute("""SELECT l.agency, l.agency_item_id, l.tag, h.h FROM mr_link l JOIN mr_hash h
                          ON h.agency=l.agency AND h.agency_item_id=l.agency_item_id""").fetchall()
        by = {}
        for r in mr:
            if (r["agency"], r["agency_item_id"]) not in manual:
                by.setdefault(r["tag"], []).append(dict(r))
        for tag, items in by.items():
            k = _cluster(items, "r:", c)
            n += k
            done |= {(i["agency"], i["agency_item_id"]) for i in items}
        # (2) mūsu dHash pēc virsraksta sākuma
        rows = c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, th.h FROM assets a
                            JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id AND th.thumb=a.thumb
                            WHERE th.h != '' AND a.mkey IS NOT NULL""").fetchall()
        by = {}
        for r in rows:
            b = bucket(r["mkey"])
            k = (r["agency"], r["agency_item_id"])
            if b and k not in manual and k not in done:
                by.setdefault(b, []).append(dict(r))
        for b, items in by.items():
            n += _cluster(items, "h:", c)
        c.commit()
        return n


def start() -> None:
    """Fonā: pēc palaišanas un tad ik 30 min (jaunām bildēm)."""
    def loop():
        time.sleep(45)
        while True:
            try:
                r = run()
                if r.get("hashed") or r.get("linked"):
                    print(f"bilžu apvienošana pēc izskata: sīktēli {r.get('hashed', 0)}, sasaistīti {r.get('linked', 0)}")
                if r.get("left"):
                    time.sleep(60)
                    continue
            except Exception as e:
                print("bilžu apvienošana:", str(e)[:160])
            time.sleep(1800)
    threading.Thread(target=loop, daemon=True).start()
