/* Shutterstock Contributor: submit.shutterstock.com */
async function collect() {
  if (location.hostname !== "submit.shutterstock.com") throw LOGIN;
  const A = (u) => getj("/api/next/" + u);
  const head = await A("v2/earnings/header");
  if (!head || !head.unpaid) throw LOGIN;
  await send("balance", { amount: +head.unpaid.total || 0, currency: "USD" });

  const ty = +today.slice(0, 4), tm = +today.slice(5, 7);
  const full = OPTS.mode === "full";
  const since = OPTS.since;
  const months = full ? monthsBack(2004, 1, ty, tm) : monthsBack(+since.slice(0, 4), +since.slice(5, 7), ty, tm);
  const detailFrom = full ? OPTS.detail_from : (OPTS.detail_since || since);
  const cats = new Set(["25_a_day", "single_image_and_other", "on_demand"]);
  const detailDays = [];   // [date, [cat, ...]]
  let found = false, empty = 0;
  for (let i = 0; i < months.length; i++) {
    const [y, m] = months[i];
    say(`${y}-${String(m).padStart(2, "0")}`, full ? Math.min(40, Math.round(i / 3)) : 20);
    const j = await A(`v2/earnings/aggregate?aggregation_period=day&year=${y}&month=${m}`);
    const days = (j && j.days) || [];
    await send("daily", { year: y, month: m, days });
    for (const d of days) {
      const dc = Object.keys(d).filter((k) => d[k] && typeof d[k] === "object" && (d[k].downloads || d[k].earnings));
      dc.forEach((c) => cats.add(c));
      /* "earning_pools_*" (datu licencēšana u.c.) nav sadalījuma pa bildēm (HTTP 400) — tās ir tikai dienu summās */
      const per = dc.filter((c) => !/pool/i.test(c));
      if (d.date >= detailFrom && per.length) detailDays.push([d.date, per]);
    }
    if (full) {
      if (days.length) { found = true; empty = 0; } else empty++;
      if ((found && empty >= 24) || (!found && empty >= 48)) break;
    }
  }

  /* pārdošanas pa bildēm katrā dienā */
  for (let i = 0; i < detailDays.length; i++) {
    const [date, dc] = detailDays[i];
    say(date, 40 + Math.round((i / Math.max(1, detailDays.length)) * 40));
    let rows = [];
    for (const c of dc) {
      let page = 1, pages = 1;
      do {
        let j;
        /* dažām kategorijām (piem. jaunā "earning_pools_commission") sadalījuma pa bildēm nav — HTTP 400 */
        try { j = await A(`v2/earnings/media_stats/day?date=${date}&display_column=${c}&page=${page}&per_page=100`); }
        catch (e) { if (e && e.login) throw e; B.log(AG, `${date} ${c}: ${(e && e.message) || e}`); break; }
        rows = rows.concat(((j && j.media) || []).map((r) => Object.assign({ category: c }, r)));
        pages = Math.max(1, (j && j.pages) || 1);
        page++;
      } while (page <= pages && page < 30);
    }
    await send("day_media", { date, rows });
  }

  /* bilžu kopsummas visā vēsturē (≈2 min) — tikai pilnajā ielādē vai pirmo reizi; pēc tam tās papildina jaunās pārdošanas */
  if (OPTS.totals) {
  await send("totals", { begin: true });
  const mtypes = ["photo", "video"];
  let mi = 0;
  for (const mt of mtypes) {
    for (const c of cats) {
      let page = 1, pages = 1;
      say(`${mt} · ${c}`, 80 + Math.round((mi++ / (mtypes.length * cats.size)) * 15));
      do {
        let j;
        try { j = await A(`v2/earnings/media_summary?media_type=${mt}&display_column=${c}&page=${page}&per_page=500`); }
        catch (e) { if (e && e.login) throw e; break; }
        await send("totals", { category: c, media_type: mt, rows: (j && j.media) || [] });
        pages = Math.max(1, (j && j.pages) || 1);
        page++;
      } while (page <= pages && page < 100);
    }
  }

  }
  try { const r = await A("earnings/recent"); await send("recent", { rows: Array.isArray(r) ? r : [] }); } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: automātiskas (līdz 15. datumam), minimums — lietotāja iestatījums; vēsture /payments (10 lapas) */
  await payoutsSafe(async () => {
    const d = await getdoc("/payments");
    const mm = txt(d.body).match(/minimum payout amount is set to\s*\$\s*([\d.,]+)/i);
    await sendPayInfo({ unpaid: +head.unpaid.total || 0, currency: "USD", min: mm ? money(mm[1]) : null });
    const seen = new Set();
    let rows = [];
    const pfull = full || OPTS.payouts_full;
    for (let pg = 1; pg <= (pfull ? 15 : 1); pg++) {
      const dd = pg === 1 ? d : await getdoc(`/payments?page=${pg}`);
      const t = tableObjs(dd, [/date/i, /amount/i]);
      if (!t) { if (pg === 1) B.log(AG, "izmaksu tabula nav atrasta; virsraksti: " + [...dd.querySelectorAll("th, [role=columnheader]")].slice(0, 8).map(txt).join(" | ")); break; }
      const r = t.map((o) => ({ date: pdate(pick(o, /date/)), amount: money(pick(o, /amount/)), currency: "USD" })).filter((x) => x.date);
      const k = r.map((x) => x.date + x.amount).join();
      if (!r.length || seen.has(k)) break;
      seen.add(k);
      rows = rows.concat(r);
      await sleep(250);
    }
    await sendPayouts(rows, pfull ? {} : { full: false, start: rows.length ? rows.reduce((m, x) => (x.date < m ? x.date : m), today) : today });
  });
  return { months: months.length, days: detailDays.length };
}
