/* Izmaksas pieprasīšana aģentūrā (noteikumi §2.4). Palaiž TIKAI pēc lietotāja apstiprinājuma programmā
   ("Pieprasīt visas"), logs ir redzams. Drošības noteikumi:
   - spiež tikai aģentūras izmaksas pogu, ja lapā ir TIEŠI VIENA redzama atbilstoša poga;
   - nekad neievada un nemaina laukus (saņēmēju, summu, maksājuma veidu); ja forma prasa aizpildīt — logs paliek lietotājam;
   - apstiprinājuma logā spiež tikai vienu skaidru "apstiprināt" pogu;
   - ja kaut kas neskaidrs — B.fail("…"): logs paliek atvērts, lietotājs pabeidz pats. */
async function collect() {
  const P = {
    adobe: { host: /(^|\.)contributor\.stock\.adobe\.com$/, path: /\/insights\/sales/, btn: /^\s*payout\b/i },
    dreamstime: { host: /(^|\.)dreamstime\.com$/, path: /\/account\/request-payment/, btn: /request\s*(a\s*)?pay(ment|out)|send request/i },
    depositphotos: { host: /(^|\.)depositphotos\.com$/, path: /request[-_]earnings/, btn: /^\s*(request|withdraw)(\s+(earnings|payment|payout|money))?\s*$/i },
    zoonar: { host: /(^|\.)zoonar\.com$/, path: /\/user\/sales/, btn: /payout balance|guthaben auszahlen|^\s*auszahlen\s*$/i },
    ingram: { host: /(^|\.)ingramportal\.com$/, path: null, btn: /request\s*pay(ment|out)/i },
  }[AG];
  if (!P) throw new Error("payout_unsupported");
  if (!P.host.test(location.hostname)) throw LOGIN;
  /* pēc pogas nospiešanas lapa var pārlādēties, un skripts tiek palaists no jauna — NEKAD nespiežam otrreiz
     (atzīme lapas sesijas atmiņā saglabājas pārlādē; derīga 15 min) */
  const MARK = "__vdPayoutClicked_" + AG;
  let clickedAt = 0;
  try { clickedAt = +sessionStorage.getItem(MARK) || 0; } catch (_) { /* */ }
  const OK_RE = /(request(ed)?|payout|payment|withdraw\w*|auszahlung|anfrage)[^.]{0,60}(sent|received|submitted|successful\w*|requested|created|erfolgreich|beantragt|processing|pending)|thank you|success/i;
  if (clickedAt && Date.now() - clickedAt < 15 * 60e3) {
    const m = txt(document.body).slice(0, 20000).match(OK_RE);
    if (m) return { requested: true, note: m[0].slice(0, 120) + " (pēc pārlādes)" };
    throw new Error("payout_unconfirmed");          // nospiests, bet apstiprinājuma nav — lietotājs pārbauda logā
  }

  const visible = (el) => {
    const r = el.getBoundingClientRect();
    if (!(r.width > 0 && r.height > 0)) return false;
    for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
      const st = getComputedStyle(e);
      if (st.display === "none" || st.visibility === "hidden" || +st.opacity === 0) return false;
    }
    return true;
  };
  const label = (el) => txt(el) || el.value || el.getAttribute("aria-label") || "";
  const buttons = (root = document) => [...root.querySelectorAll('button, input[type="submit"], input[type="button"], a[role="button"], [role="button"]')]
    .filter((el) => visible(el) && !el.disabled && el.getAttribute("aria-disabled") !== "true");

  /* Ingram: pogas lapa — Royalties (no sānu izvēlnes) */
  if (!P.path && AG === "ingram" && !/royalt/i.test(location.pathname + location.search + " " + txt(document.querySelector("h1, h2")))) {
    const a = [...document.querySelectorAll("a[href]")].find((x) => /royalt/i.test(txt(x)));
    if (!a) throw LOGIN;
    location.href = new URL(a.getAttribute("href"), location.href).href;
    return { navigated: true };
  }
  if (P.path && !P.path.test(location.pathname)) {
    if (OPTS.url) { location.href = OPTS.url; return { navigated: true }; }
    throw new Error("payout_page");
  }

  /* SPA lapas zīmējas lēni — gaidām pogu līdz 20 s */
  let cands = [];
  for (let i = 0; i < 40; i++) {
    cands = buttons().filter((el) => P.btn.test(label(el)));
    if (cands.length) break;
    await sleep(500);
  }
  if (cands.length !== 1) {
    B.log(AG, `izmaksa: atbilstošas pogas ${cands.length}; redzamās pogas: ` + buttons().slice(0, 12).map((b) => label(b).slice(0, 30)).join(" | "));
    throw new Error(cands.length ? "payout_ambiguous" : "payout_no_button");
  }
  const btn = cands[0];
  /* forma ar tukšiem obligātiem laukiem — to aizpilda lietotājs (summa, maksājuma veids u.c.) */
  const form = btn.form || btn.closest("form");
  if (form) {
    const empty = [...form.querySelectorAll("input, select, textarea")].filter((el) => visible(el) && el.required && !el.value);
    if (empty.length) { B.log(AG, "izmaksa: formā tukši obligāti lauki — atstāju lietotājam"); throw new Error("payout_form"); }
  }
  const before = txt(document.body).slice(0, 20000);
  B.log(AG, `izmaksa: spiežu "${label(btn).slice(0, 40)}"`);
  try { sessionStorage.setItem(MARK, String(Date.now())); } catch (_) { throw new Error("payout_storage"); }
  btn.click();

  /* apstiprinājuma logs: viena skaidra poga */
  const CONFIRM = /^\s*(confirm|yes|ok|request|submit|continue|payout|send|bestätigen|ja|auszahlen|jā|apstiprināt)\b/i;
  for (let i = 0; i < 12; i++) {
    await sleep(500);
    const dlg = [...document.querySelectorAll('[role="dialog"], [role="alertdialog"], .modal, dialog[open]')].filter(visible).pop();
    if (!dlg) continue;
    const ok = buttons(dlg).filter((b) => CONFIRM.test(label(b)) && !/cancel|close|atcelt|abbrechen|^no\b/i.test(label(b)));
    if (ok.length === 1) { B.log(AG, `izmaksa: apstiprinu "${label(ok[0]).slice(0, 30)}"`); ok[0].click(); break; }
    if (ok.length > 1) { B.log(AG, "izmaksa: apstiprinājuma logā vairākas pogas — atstāju lietotājam"); throw new Error("payout_confirm"); }
  }
  /* rezultāts: lapas teksts mainījies vai ir apstiprinājuma vārdi */
  let res = "";
  for (let i = 0; i < 20; i++) {
    await sleep(500);
    const now = txt(document.body).slice(0, 20000);
    const m = now.match(OK_RE);
    if (m && !before.includes(m[0])) { res = m[0].slice(0, 120); break; }   // tikai jauns teksts (ne "Payout history" u.c.)
    if (now !== before && i >= 6) { res = "lapa mainījās"; break; }
  }
  if (!res) throw new Error("payout_unconfirmed");
  return { requested: true, note: res };
}
