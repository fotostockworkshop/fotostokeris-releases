/* Pond5: www.pond5.com — pēdējās pārdošanas (JSON ar X-Access-Token no lapas) un atlikums */
async function collect() {
  if (!/(^|\.)pond5\.com$/.test(location.hostname)) throw LOGIN;
  for (let i = 0; i < 50 && !window.token_header; i++) await sleep(200);
  if (!window.token_header) throw LOGIN;
  const H = Object.assign({}, window.token_header);
  const sales = await getj("/ajax/dashboard/sales", H);
  const items = (sales && sales.items) || [];
  const rows = items.map((x) => ({
    day: String(x.createdAt || "").slice(0, 10), ts: String(x.createdAt || "").replace(" ", "T").slice(0, 19),
    id: String(x.itemId || ""), title: x.isOneOff ? (x.oneOffTitle || "Additional revenue") + " " + (x.name || "") : x.name,
    thumb: x.isOneOff ? "" : x.previewUrl, url: x.link, amount: +x.amount || 0, cnt: x.isOneOff ? 0 : 1,
    kind: x.isOneOff ? "other" : "sale" })).filter((r) => r.day);
  const start = rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today;
  await sendRows(rows, { start, end: today });
  try {
    const b = await getj("/ajax/user/balance", H);
    const t = ((b && b.info) || []).find((x) => x.id === "total");
    if (t) await send("balance", { amount: +t.amount || 0, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: automātiskas ~15. datumā; financials/<gads>/<mēn> → lastPayoutDate/Amount, accountBalance */
  await payoutsSafe(async () => {
    const ty = +today.slice(0, 4), tm = +today.slice(5, 7);
    const from = new Date(ty, tm - 1 - 3, 1);
    /* financials katrā mēnesī rāda to pašu "pēdējo izmaksu" (2026-10-29: cikls līdz 2012 deva 1 izmaksu, 1 min) —
       tāpēc tikai pēdējie mēneši; vēsture krājas pamazām. Pilnai vēsturei jāatrod cits avots. */
    const months = monthsBack(from.getFullYear(), from.getMonth() + 1, ty, tm);
    const seen = new Map();
    let empty = 0, first = true;
    for (const [y, m] of months) {
      let j;
      try { j = await getj(`/ajax/user-account/financials/${y}/${pad(m)}`, H); } catch (e) { if (e && e.login) throw e; break; }
      const sm = (j && j.financials && j.financials.summary) || {};
      if (first) { first = false; if (sm.accountBalance != null) await sendPayInfo({ unpaid: +sm.accountBalance || 0, currency: "USD" }); }
      const d = pdate(sm.lastPayoutDate || "");
      if (d && sm.lastPayoutAmount) seen.set(d, Math.abs(+sm.lastPayoutAmount));
      if (!(j && j.financials && ((j.financials.clipSales || []).length || sm.totalEarnings))) { if (++empty >= 18) break; } else empty = 0;
      await sleep(200);
    }
    const rows = [...seen].map(([date, amount]) => ({ date, amount, currency: "USD" })).sort((a, b) => (a.date < b.date ? 1 : -1));
    await sendPayouts(rows, { full: false });
  });
  return { rows: rows.length };
}
