"""Izmaksas (0.3.0, 3. daļa): izmaksu vēsture, neizmaksātais / pieejamais atlikums, minimums, "alga".

Tabulas (catalog.db):
  payouts   — izmaksas: aģentūra, datums, summa aģentūras valūtā, USD un EUR (ECB kurss izmaksas dienā)
  pinfo     — aģentūras izmaksu stāvoklis: neizmaksāts, pieejams izmaksai, minimums (aģentūras valūtā)
  bal_hist  — neizmaksātais atlikums mēneša beigās (katrā atjaunošanā pārraksta tekošā mēneša vērtību)

Savācēji sūta:  send("payouts", {rows: [{date, amount, currency, status?, ref?}], full?: true, start?})
                send("payout_info", {unpaid?, available?, currency, min?, next_date?})
Saņēmēju dati (PayPal e-pasts, adrese) netiek sūtīti un netiek glabāti.

Izmaksu veids un minimums: noklusējums PAYOUT (izpēte 2026-10-28), lietotājs var mainīt iestatījumos
(`sales_payout` = {aģentūra: {mode, min}}) — noteikumi §2.6.
"""
from __future__ import annotations

import calendar
import datetime as dt
import json

from . import config
from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS payouts(agency TEXT, paid_at TEXT, amount REAL, currency TEXT, amount_usd REAL, amount_eur REAL,
  status TEXT, ref TEXT DEFAULT '', PRIMARY KEY(agency, paid_at, amount, ref));
CREATE TABLE IF NOT EXISTS pinfo(agency TEXT PRIMARY KEY, unpaid REAL, available REAL, currency TEXT, min_payout REAL,
  next_date TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS bal_hist(agency TEXT, month TEXT, amount REAL, currency TEXT, PRIMARY KEY(agency, month));
"""

# mode: "auto" — aģentūra izmaksā pati; "request" — jāpieprasa (poga aģentūras lapā); None — nezināms
# min — izmaksas minimums aģentūras valūtā; url — kur pieprasa / redz izmaksas
PAYOUT = {
    "adobe": {"mode": "request", "min": 25, "url": "https://contributor.stock.adobe.com/en/insights/sales"},
    "shutterstock": {"mode": "auto", "min": 25, "url": "https://submit.shutterstock.com/payments"},
    "istock": {"mode": "auto", "min": 100, "url": "https://esp.gettyimages.com/ui/account_manager?path=Reports/Dashboard"},
    "alamy": {"mode": "auto", "min": 50, "url": "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1"},
    "123rf": {"mode": "auto", "min": 50, "url": "https://www.123rf.com/contributor/account-settings"},
    "dreamstime": {"mode": "request", "min": 100, "url": "https://www.dreamstime.com/account/request-payment"},
    "depositphotos": {"mode": "request", "min": 25, "url": "https://depositphotos.com/request-earnings.html"},
    "pond5": {"mode": "auto", "min": 25, "url": "https://www.pond5.com/index.php?page=my_financials"},
    "zoonar": {"mode": "request", "min": 20, "url": "https://www.zoonar.com/user/sales"},
    "ingram": {"mode": "request", "min": 40, "url": "https://www.ingramportal.com/"},
    "bigstock": {"mode": None, "min": None, "url": "https://www.bigstockphoto.com/account/commissions/payment-history/"},
    "envato": {"mode": None, "min": None, "url": "https://author.envato.com/"},
    "envato_market": {"mode": None, "min": None, "url": "https://author.envato.com/"},
    "magnific": {"mode": None, "min": None, "url": "https://www.freepik.com/"},
    "pixta": {"mode": None, "min": None, "url": "https://www.pixtastock.com/"},
}
MODES = ("auto", "request")


def ensure(c) -> None:
    c.executescript(SCHEMA)


# --------------------------------------------------------------------------- valūtas

def _cur(agency: str, cur: str | None) -> str:
    return (cur or db.AGENCIES.get(agency, {}).get("currency") or "USD").upper()


def to_usd(c, agency: str, amount: float, cur: str, day: str) -> float:
    return db._to_usd(c, agency, amount, cur, day)


def usd_to_eur(usd: float, day: str) -> float:
    """USD → EUR pēc ECB kursa dienā (fx.rate dod: 1 EUR = ? USD)."""
    if not usd:
        return 0.0
    from . import fx
    r = fx.rate(db, "EUR", day or db._today().isoformat())
    return round(usd / r, 6) if r else usd


def to_eur(c, agency: str, amount: float, cur: str, day: str) -> float:
    cur = _cur(agency, cur)
    if cur == "EUR":
        return amount
    return usd_to_eur(to_usd(c, agency, amount, cur, day), day)


# --------------------------------------------------------------------------- ievade

def _payouts(agency):
    """Izmaksu vēsture. d = {rows: [{date, amount, currency?, status?, ref?}], full?: bool, start?: 'YYYY-MM-DD'}.
    full — visa aģentūras vēsture (vecā tiek aizstāta); start — aizstāj no šī datuma; citādi tikai papildina."""
    def f(c, d):
        ensure(c)
        rows = [r for r in (d.get("rows") or []) if str(r.get("date") or "")[:10] and db.num(r.get("amount"))]
        if d.get("full") and rows:
            c.execute("DELETE FROM payouts WHERE agency=?", (agency,))
        elif d.get("start"):
            c.execute("DELETE FROM payouts WHERE agency=? AND paid_at>=?", (agency, str(d["start"])[:10]))
        for r in rows:
            day = str(r["date"])[:10]
            amt = abs(db.num(r.get("amount")))
            cur = _cur(agency, r.get("currency") or d.get("currency"))
            usd = to_usd(c, agency, amt, cur, day)
            c.execute("INSERT OR REPLACE INTO payouts VALUES(?,?,?,?,?,?,?,?)",
                      (agency, day, amt, cur, usd, usd_to_eur(usd, day) if cur != "EUR" else amt,
                       str(r.get("status") or "")[:40], str(r.get("ref") or "")[:40]))
    return f


def _info(agency):
    """Izmaksu stāvoklis. d = {unpaid?, available?, currency?, min?, next_date?} — tikai atnākušie lauki tiek mainīti."""
    def f(c, d):
        ensure(c)
        cur = _cur(agency, d.get("currency"))
        old = c.execute("SELECT * FROM pinfo WHERE agency=?", (agency,)).fetchone()
        o = dict(old) if old else {"unpaid": None, "available": None, "min_payout": None, "next_date": None}
        for k, col in (("unpaid", "unpaid"), ("available", "available"), ("min", "min_payout")):
            if d.get(k) is not None and str(d.get(k)) != "":
                o[col] = db.num(d.get(k))
        if d.get("next_date"):
            o["next_date"] = str(d["next_date"])[:10]
        c.execute("INSERT OR REPLACE INTO pinfo VALUES(?,?,?,?,?,?,?)",
                  (agency, o["unpaid"], o["available"], cur, o["min_payout"], o["next_date"],
                   dt.datetime.now().isoformat(timespec="seconds")))
        if d.get("unpaid") is not None:
            _hist(c, agency, db.num(d["unpaid"]), cur)
    return f


def _hist(c, agency: str, amount: float, cur: str) -> None:
    c.execute("INSERT OR REPLACE INTO bal_hist VALUES(?,?,?,?)", (agency, db._today().isoformat()[:7], amount, cur))


def note_balance(c, agency: str, amount: float, cur: str) -> None:
    """Esošais "balance" ziņojums (neizmaksātais) — arī izmaksu stāvoklī un mēneša vēsturē."""
    ensure(c)
    cur = _cur(agency, cur)
    old = c.execute("SELECT available, min_payout, next_date FROM pinfo WHERE agency=?", (agency,)).fetchone()
    c.execute("INSERT OR REPLACE INTO pinfo VALUES(?,?,?,?,?,?,?)",
              (agency, amount, old["available"] if old else None, cur, old["min_payout"] if old else None,
               old["next_date"] if old else None, dt.datetime.now().isoformat(timespec="seconds")))
    _hist(c, agency, amount, cur)


def _checked(agency: str):
    """Izmaksas pārbaudītas: atceramies dienu un tā brīža atlikumu (nākamreiz pārbauda tikai, ja atlikums
    samazinājies — tātad bijusi izmaksa — vai pagājušas CHECK_DAYS dienas)."""
    def f(c, d):
        r = c.execute("SELECT amount FROM balance WHERE agency=?", (agency,)).fetchone()
        val = json.dumps({"day": db._today().isoformat(), "bal": r["amount"] if r else None})
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "pay_check", val))
    return f


CHECK_DAYS = 7


def check_opts(agency: str) -> dict:
    """Savācējam: vai izmaksas jāpārbauda obligāti (pay_due) un atlikums iepriekšējā pārbaudē (pay_bal)."""
    pc = db.get_state(agency, "pay_check") or {}
    today = db._today()
    try:
        ago = (today - dt.date.fromisoformat(pc.get("day") or "")).days
    except ValueError:
        ago = 9999
    last = calendar.monthrange(today.year, today.month)[1]
    # pieprasīšanas laiks: mēneša pēdējās 3 dienas, e-pasta atgādinājuma diena vai "tiklīdz sasniegts minimums" —
    # tad "pieejamā" summa vajadzīga svaiga (reizi dienā)
    when = config.get("sales_mail_when") or "lastday"
    mail = bool(config.get("sales_mail_on"))
    day = min(max(1, int(config.get("sales_mail_day") or 28)), last)
    season = today.day >= last - 2 or (mail and (when == "threshold" or (when == "day" and today.day >= day - 1)))
    due = ago >= CHECK_DAYS or (season and ago >= 1)
    return {"pay_due": due, "pay_bal": pc.get("bal")}


def register() -> None:
    for a in db.AG_ORDER:
        db.INGEST.setdefault((a, "payouts"), _payouts(a))
        db.INGEST.setdefault((a, "payout_info"), _info(a))
        db.INGEST.setdefault((a, "pay_checked"), _checked(a))


# --------------------------------------------------------------------------- noteikumi (iestatījumi)

def rules() -> dict:
    """{aģentūra: {mode, min, cur, url}} — noklusējums + lietotāja iestatījumi (sales_payout)."""
    user = config.get("sales_payout") or {}
    out = {}
    for a in db.AG_ORDER:
        if db.AGENCIES[a].get("archive"):          # arhīva aģentūras (Microstockr imports) — izmaksu nav
            continue
        base = dict(PAYOUT.get(a, {"mode": None, "min": None, "url": ""}))
        u = user.get(a) if isinstance(user, dict) else None
        if isinstance(u, dict):
            if u.get("mode") in MODES or u.get("mode") == "":
                base["mode"] = u.get("mode") or None
            if u.get("min") not in (None, ""):
                try:
                    base["min"] = float(u["min"])
                    base["user_min"] = True
                except (TypeError, ValueError):
                    pass
        base["cur"] = db.AGENCIES[a]["currency"]
        out[a] = base
    return out


# --------------------------------------------------------------------------- pārskats

def _month_add(ym: str, n: int) -> str:
    y, m = int(ym[:4]), int(ym[5:7]) + n
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    return f"{y:04d}-{m:02d}"


def is_last_day(d: dt.date | None = None) -> bool:
    d = d or db._today()
    return d.day == calendar.monthrange(d.year, d.month)[1]


def overview(year: int | None = None) -> dict:
    """Izmaksu lapa: aģentūru stāvoklis, "var pieprasīt", alga, izmaksas € pa mēnešiem, gadu salīdzinājums."""
    today = db._today()
    iso = today.isoformat()
    year = int(year or today.year)
    with db._lock:
        c = db.conn()
        ensure(c)
        c.commit()
    R = rules()
    info = {r["agency"]: dict(r) for r in db.q("SELECT * FROM pinfo")}
    last = {r["agency"]: dict(r) for r in db.q(
        "SELECT agency, paid_at, amount, currency, amount_eur FROM payouts p WHERE paid_at=(SELECT MAX(paid_at) FROM payouts WHERE agency=p.agency)")}
    enabled = set(config.get("sales_agencies") or [])
    rows, can_request = [], []
    for a in db.AG_ORDER:
        if a not in R:
            continue
        i = info.get(a, {})
        if a not in enabled and not i and a not in last:
            continue
        r = R[a]
        cur = i.get("currency") or r["cur"]
        unpaid = i.get("unpaid")
        avail = i.get("available")
        base = avail if avail is not None else unpaid
        # minimums: lietotāja iestatījums → aģentūras lapā nolasītais → noklusējums
        minv = r["min"] if r.get("user_min") else (i.get("min_payout") if i.get("min_payout") is not None else r["min"])
        ready = bool(base is not None and minv and base >= minv - 1e-9)
        eur = to_eur(db.conn(), a, base or 0, cur, iso) if base else 0.0
        row = {"agency": a, "mode": r["mode"], "min": minv, "currency": cur, "unpaid": unpaid, "available": avail,
               "ready": ready, "eur": round(eur, 2), "pct": round(min(100, (base or 0) / minv * 100)) if minv else None,
               "url": r["url"], "next_date": i.get("next_date"), "updated": i.get("updated"),
               "last": last.get(a), "req": db.get_state(a, "payout_req")}
        rows.append(row)
        if ready and r["mode"] == "request":
            can_request.append({"agency": a, "amount": base, "currency": cur, "eur": round(eur, 2), "url": r["url"]})

    # alga: šomēnes saņemts; nākamajā mēnesī gaidāms (auto — atlikums ≥ minimums; pieprasāmās — pieprasīs mēneša beigās)
    m0 = iso[:7]
    got = db.q("SELECT agency, SUM(amount_eur) e FROM payouts WHERE substr(paid_at,1,7)=? GROUP BY agency", (m0,))
    expected = [{"agency": r["agency"], "eur": r["eur"], "mode": r["mode"]} for r in rows if r["ready"] and r["mode"] in MODES]
    salary = {
        "month": m0, "next_month": _month_add(m0, 1),
        "received": round(sum(g["e"] or 0 for g in got), 2),
        "received_by": {g["agency"]: round(g["e"] or 0, 2) for g in got},
        "expected": round(sum(x["eur"] for x in expected), 2), "expected_by": expected,
        "unpaid_total": round(sum(r["eur"] if r["available"] is None else to_eur(db.conn(), r["agency"], r["unpaid"] or 0, r["currency"], iso)
                                  for r in rows if r["unpaid"]), 2),
    }

    # izmaksas € pa mēnešiem gadā
    mrows = db.q("""SELECT agency, CAST(substr(paid_at,6,2) AS INT) m, SUM(amount_eur) e, SUM(amount_usd) u FROM payouts
                    WHERE substr(paid_at,1,4)=? GROUP BY agency, m""", (str(year),))
    matrix: dict = {}
    for r in mrows:
        matrix.setdefault(r["agency"], {})[r["m"]] = round(r["e"] or 0, 2)
    month_tot = {m: round(sum(v.get(m, 0) for v in matrix.values()), 2) for m in range(1, 13)}
    last_m = 12 if year < today.year else today.month
    year_tot = round(sum(month_tot.values()), 2)
    avg = round(year_tot / last_m, 2) if year <= today.year and last_m else 0
    years = [dict(r) for r in db.q("SELECT substr(paid_at,1,4) y, SUM(amount_eur) e, COUNT(*) n FROM payouts GROUP BY y ORDER BY y")]
    for i, y in enumerate(years):
        y["e"] = round(y["e"] or 0, 2)
        prev = years[i - 1]["e"] if i else 0
        y["d"] = round((y["e"] - prev) / prev * 100, 1) if prev else None
    # neizmaksātais mēneša beigās (oriģinālajā valūtā)
    hist: dict = {}
    for r in db.q("SELECT agency, CAST(substr(month,6,2) AS INT) m, amount, currency FROM bal_hist WHERE substr(month,1,4)=?", (str(year),)):
        hist.setdefault(r["agency"], {})[r["m"]] = [round(r["amount"] or 0, 2), r["currency"]]
    return {"today": iso, "last_day": is_last_day(today), "year": year, "rows": rows, "can_request": can_request,
            "salary": salary, "matrix": matrix, "month_tot": month_tot, "year_tot": year_tot, "avg": avg, "avg_months": last_m,
            "years": years, "hist": hist, "min_year": (years[0]["y"] if years else str(today.year))}


def recent(limit: int = 50) -> list[dict]:
    return [dict(r) for r in db.q("SELECT * FROM payouts ORDER BY paid_at DESC LIMIT ?", (limit,))]
