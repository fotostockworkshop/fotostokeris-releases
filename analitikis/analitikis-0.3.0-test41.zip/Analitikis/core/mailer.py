"""E-pasta sūtīšana (SMTP) visiem produktiem — piem. Analītiķa atgādinājums par izmaksām.

Pieslēgšanās: serveris/ports iestatījumos (`<prefikss>smtp_host`, `…smtp_port`), lietotājvārds un parole — TIKAI
sistēmas drošajā glabātuvē (core/credentials.py, ieraksts "smtp"; noteikumi §3). Gmail: lietotnes parole
(Google konts → Drošība → Lietotņu paroles), nevis parastā parole. Žurnālā paroles un vēstules saturs netiek rakstīti.
"""
from __future__ import annotations

import smtplib
import ssl
from email.message import EmailMessage

from . import credentials

CRED = "smtp"


def _ctx():
    from .updater import _ssl_ctx          # Mac python.org: sistēmas sertifikāti no /etc/ssl/cert.pem
    return _ssl_ctx()


def send(host: str, port: int, to: str, subject: str, text: str, html: str | None = None) -> None:
    """Nosūta vēstuli. Kļūdas gadījumā — izņēmums ar saprotamu tekstu (bez paroles)."""
    c = credentials.get(CRED)
    if not c or not c[0] or not c[1]:
        raise RuntimeError("smtp_no_cred")
    user, pw = c
    if not to:
        raise RuntimeError("smtp_no_to")
    msg = EmailMessage()
    msg["From"] = user
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
    port = int(port or 587)
    try:
        if port == 465:
            with smtplib.SMTP_SSL(host, port, context=_ctx(), timeout=30) as s:
                s.login(user, pw)
                s.send_message(msg)
        else:
            with smtplib.SMTP(host, port, timeout=30) as s:
                s.starttls(context=_ctx())
                s.login(user, pw)
                s.send_message(msg)
    except smtplib.SMTPAuthenticationError as e:
        raise RuntimeError("smtp_auth") from e
    except (OSError, smtplib.SMTPException) as e:
        raise RuntimeError(f"smtp: {type(e).__name__}: {str(e)[:120]}") from e
