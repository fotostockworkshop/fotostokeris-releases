"""Izmaksas (0.3.0, 3. daļa): izmaksu vēsture, neizmaksātais / pieejamais atlikums, minimums, "alga".

Tabulas (catalog.db):
  payouts   — izmaksas: aģentūra, datums, summa aģentūras valūtā, USD un EUR (ECB kurss izmaksas dienā)
  pinfo     — aģentūras izmaksu stāvoklis: neizmaksāts, pieejams izmaksai, minimums (aģentūras valūtā)
  bal_hist  — neizmaksātais atlikums mēneša beigās (katrā atjaunošanā pārraksta tekošā mēneša vērtību)

Savācēji sūta:  send("payouts", {rows: [{date, amount, currency, status?, ref?}], full?: true, start?})
                send("payout_info", {unpaid?, available?, currency, min?, next_date?})
Saņēmēju dati (PayPal e-pasts, adrese) netiek sūtīti un netiek glabāti.

Izmaksu veids un minimums: noklusējums PAYOUT (izpēte 2026-10-28), lietotājs var mainīt iestatījumos
(`sales_payout` = {aģentūra: {mode, min}}) — noteikumi §2.6.
"""
from __future__ import annotations

import calendar
import datetime as dt
import json

from . import config
from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS payouts(agency TEXT, paid_at TEXT, amount REAL, currency TEXT, amount_usd REAL, amount_eur REAL,
  status TEXT, ref TEXT DEFAULT '', PRIMARY KEY(agency, paid_at, amount, ref));
CREATE TABLE IF NOT EXISTS pinfo(agency TEXT PRIMARY KEY, unpaid REAL, available REAL, currency TEXT, min_payout REAL,
  next_date TEXT, updated TEXT);
CREATE TABLE IF NOT EXISTS bal_hist(agency TEXT, month TEXT, amount REAL, currency TEXT, PRIMARY KEY(agency, month));
"""

# mode: "auto" — aģentūra izmaksā pati; "request" — jāpieprasa (poga aģentūras lapā); None — nezināms
# min — izmaksas minimums aģentūras valūtā; url — kur pieprasa / redz izmaksas
PAYOUT = {
    # 2026-11-06 (lietotājs: Adobe vēsturē 1. okt., PayPal saņemts 10. okt.): Adobe izmaksu vēsturē datums = pieprasījuma diena
    "adobe": {"mode": "request", "min": 25, "url": "https://contributor.stock.adobe.com/en/insights/sales", "paid_delay_d": 9},   # aptuveni (iestatāms)
    "shutterstock": {"mode": "auto", "min": 25, "url": "https://submit.shutterstock.com/payments", "paid_delay_d": 7},   # tabulā mēneša beigas; PayPal 5.–8. datumā (lietotājs 2026-11-06)
    "istock": {"mode": "auto", "min": 100, "url": "https://esp.gettyimages.com/ui/account_manager?path=Reports/Dashboard", "paid_delay_d": -2, "prev_workday": True},   # Getty datē 25. (arī brīvdienā), PayPal ~2 d. pirms apstrādes dienas (lietotājs 2026-11-06)
    "alamy": {"mode": "auto", "min": 50, "url": "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1", "paid_delay_d": 8},   # Alamy 4.05., PayPal 12.05. (lietotājs 2026-11-06)
    "123rf": {"mode": "auto", "min": 50, "url": "https://www.123rf.com/contributor/account-settings"},
    "dreamstime": {"mode": "request", "min": 100, "url": "https://www.dreamstime.com/account/request-payment"},
    "depositphotos": {"mode": "request", "min": 25, "url": "https://depositphotos.com/request-earnings.html"},
    "pond5": {"mode": "auto", "min": 25, "url": "https://www.pond5.com/index.php?page=my_financials"},
    # 2026-11-04 (lietotājs: pieprasīts 31.10. €25.56, saņemts 02.11. €21.52): Zoonar ietur Vācijas nodokli ārvalstu autoriem
    # (§50a EStG 15% + solidaritātes piemaksa 5.5% no tā = 15.825%; 25.56 × 0.84175 = 21.52). Zoonar vēsturē izmaksas
    # datums = pieprasījuma diena, nauda pienāk nākamajā darba dienā. Nodokļa % — lietotāja iestatījums (vācu rezidentam 0).
    "zoonar": {"mode": "request", "min": 20, "url": "https://www.zoonar.com/user/sales", "tax_pct": 15.825,
               "paid_next_workday": True},
    "ingram": {"mode": "request", "min": 40, "url": "https://www.ingramportal.com/"},
    # lietotājs 2026-10-31: jāpieprasa, > $25; pārdošanas pieprasāmas pēc 7 d, partneru komisijas pēc 45 d
    "bigstock": {"mode": "request", "min": 25, "url": "https://www.bigstockphoto.com/account/commissions/payment-history/",
                 "hold_d": 7},
    # lietotājs 2026-11-01: abi automātiski 15. datumā, minimums $50 katram ATSEVIŠĶI (pirms nodokļa); docs/stoku-izmaksu-noteikumi.md
    "envato": {"mode": "auto", "min": 50, "url": "https://author.envato.com/payout_method", "pay_day": 15},
    "envato_market": {"mode": "auto", "min": 50, "url": "https://author.envato.com/profile", "pay_day": 15},
    # lietotājs 2026-10-31: rēķins 4., jāapstiprina 4.–9. (taxcenter), izmaksa 10.–15.; par lejupielādēm līdz M−2 beigām;
    # min €50; ietur nodokli (noklusējums 24% — lietotāja vērtība, iestatāma). docs/stoku-izmaksu-noteikumi.md
    "magnific": {"mode": "request", "min": 50, "url": "https://taxcenter.magnific.com/", "validate": (4, 9),
                 "pay_day": 15, "pay_lag_m": 2, "tax_pct": 24, "paid_delay_d": 9,   # Magnific datē ~5., PayPal 11.–14. (2026-11-06)
                 "min_net": True},   # lietotājs 18:25: minimums €50 skaitās PĒC nodokļa
    # lietotājs 2026-10-31: jāpieprasa, minimums 50 kredīti (= USD); izmaksa aiznākamā mēneša 15. datumā pēc pieprasījuma
    "pixta": {"mode": "request", "min": 50, "url": "https://www.pixtastock.com/mypage/earning", "pay_day": 15, "pay_lag_m": 2},
}
MODES = ("auto", "request")


def ensure(c) -> None:
    c.executescript(SCHEMA)
    _migrate_req_dated(c)


def _next_workday(day: str) -> str:
    d = dt.date.fromisoformat(day[:10]) + dt.timedelta(days=1)
    while d.weekday() >= 5:
        d += dt.timedelta(days=1)
    return d.isoformat()


def _net_row(agency: str, day: str, amt: float, R: dict | None = None):
    """Aģentūras vēstures izmaksa → saņemtā: (datums, summa, status, ref). Aģentūrām ar `paid_next_workday` vēstures
    datums ir pieprasījuma diena (ref "req:<datums>"), nauda — nākamajā darba dienā; `tax_pct` — ieturētais nodoklis
    (status "bruto <summa>"). Citām — kā aģentūra rāda."""
    r = (R if R is not None else rules()).get(agency) or PAYOUT.get(agency) or {}
    dly = int(r.get("paid_delay_d") or 0)
    if dly:                                          # 2026-11-06 Adobe: aptuvenā saņemšanas diena = pieprasījums + N dienas
        d0 = dt.date.fromisoformat(day[:10])
        if r.get("prev_workday"):                    # iStock: "apstrādā 25., ja brīvdiena — iepriekšējā darba dienā" (ESP)
            while d0.weekday() >= 5:
                d0 -= dt.timedelta(days=1)
        d2 = (d0 + dt.timedelta(days=dly)).isoformat()
        return d2, amt, f"aptuveni {dly:+d}", f"req:{day[:10]}"
    if not r.get("paid_next_workday"):
        return None
    tx = float(r.get("tax_pct") or 0)
    return _next_workday(day), round(amt * (1 - tx / 100.0), 2), f"bruto {amt:.2f}", f"req:{day[:10]}"


def _migrate_req_dated(c) -> None:
    """Vienreiz katrai aģentūrai: jau saglabātās izmaksas → saņemšanas diena (+ summa pēc nodokļa). Zoonar 2026-11-04,
    Adobe 2026-11-06 (aptuveni +9 dienas), Shutterstock 2026-11-06 (+7)."""
    for ag in ("zoonar", "adobe", "shutterstock", "istock", "alamy", "magnific"):
        if c.execute("SELECT 1 FROM state WHERE agency=? AND key='pay_net_v'", (ag,)).fetchone():
            continue
        try:
            R = rules()
            for x in c.execute("SELECT * FROM payouts WHERE agency=? AND ref NOT LIKE 'req:%'", (ag,)).fetchall():
                n = _net_row(ag, x["paid_at"], x["amount"], R)
                if not n:
                    continue
                c.execute("DELETE FROM payouts WHERE agency=? AND paid_at=? AND amount=? AND ref=?",
                          (x["agency"], x["paid_at"], x["amount"], x["ref"]))
                cur = x["currency"] or "USD"
                usd = to_usd(c, ag, n[1], cur, n[0])
                c.execute("INSERT OR REPLACE INTO payouts VALUES(?,?,?,?,?,?,?,?)",
                          (ag, n[0], n[1], cur, usd, n[1] if cur == "EUR" else usd_to_eur(usd, n[0]), n[2], n[3]))
            c.execute("INSERT OR REPLACE INTO state VALUES(?,'pay_net_v','1')", (ag,))
        except Exception as e:
            print(f"{ag} izmaksu pārrēķins:", str(e)[:120])


# --------------------------------------------------------------------------- valūtas

def _cur(agency: str, cur: str | None) -> str:
    return (cur or db.AGENCIES.get(agency, {}).get("currency") or "USD").upper()


def to_usd(c, agency: str, amount: float, cur: str, day: str) -> float:
    return db._to_usd(c, agency, amount, cur, day)


def usd_to_eur(usd: float, day: str) -> float:
    """USD → EUR pēc ECB kursa dienā (fx.rate dod: 1 EUR = ? USD)."""
    if not usd:
        return 0.0
    from . import fx
    r = fx.rate(db, "EUR", day or db._today().isoformat())
    return round(usd / r, 6) if r else usd


def to_eur(c, agency: str, amount: float, cur: str, day: str) -> float:
    cur = _cur(agency, cur)
    if cur == "EUR":
        return amount
    return usd_to_eur(to_usd(c, agency, amount, cur, day), day)


# --------------------------------------------------------------------------- ievade

def _payouts(agency):
    """Izmaksu vēsture. d = {rows: [{date, amount, currency?, status?, ref?}], full?: bool, start?: 'YYYY-MM-DD'}.
    full — visa aģentūras vēsture (vecā tiek aizstāta); start — aizstāj no šī datuma; citādi tikai papildina."""
    def f(c, d):
        ensure(c)
        rows = [r for r in (d.get("rows") or []) if str(r.get("date") or "")[:10] and db.num(r.get("amount"))]
        if d.get("full") and rows:
            c.execute("DELETE FROM payouts WHERE agency=?", (agency,))
        elif d.get("start"):                         # "req:" rindām salīdzina aģentūras (pieprasījuma) datumu
            c.execute("""DELETE FROM payouts WHERE agency=? AND
                         (CASE WHEN ref LIKE 'req:%' THEN substr(ref,5,10) ELSE paid_at END)>=?""", (agency, str(d["start"])[:10]))
        R = rules()
        for r in rows:
            day = str(r["date"])[:10]
            amt = abs(db.num(r.get("amount")))
            cur = _cur(agency, r.get("currency") or d.get("currency"))
            st, ref = str(r.get("status") or "")[:40], str(r.get("ref") or "")[:40]
            n = _net_row(agency, day, amt, R)
            if n:
                day, amt, st, ref = n
            usd = to_usd(c, agency, amt, cur, day)
            c.execute("INSERT OR REPLACE INTO payouts VALUES(?,?,?,?,?,?,?,?)",
                      (agency, day, amt, cur, usd, usd_to_eur(usd, day) if cur != "EUR" else amt, st, ref))
    return f


def _info(agency):
    """Izmaksu stāvoklis. d = {unpaid?, available?, currency?, min?, next_date?} — tikai atnākušie lauki tiek mainīti."""
    def f(c, d):
        ensure(c)
        cur = _cur(agency, d.get("currency"))
        old = c.execute("SELECT * FROM pinfo WHERE agency=?", (agency,)).fetchone()
        o = dict(old) if old else {"unpaid": None, "available": None, "min_payout": None, "next_date": None}
        for k, col in (("unpaid", "unpaid"), ("available", "available"), ("min", "min_payout")):
            if d.get(k) is not None and str(d.get(k)) != "":
                o[col] = db.num(d.get(k))
        if d.get("next_date"):
            o["next_date"] = str(d["next_date"])[:10]
        c.execute("INSERT OR REPLACE INTO pinfo VALUES(?,?,?,?,?,?,?)",
                  (agency, o["unpaid"], o["available"], cur, o["min_payout"], o["next_date"],
                   dt.datetime.now().isoformat(timespec="seconds")))
        if d.get("unpaid") is not None:
            _hist(c, agency, db.num(d["unpaid"]), cur)
    return f


def _hist(c, agency: str, amount: float, cur: str) -> None:
    c.execute("INSERT OR REPLACE INTO bal_hist VALUES(?,?,?,?)", (agency, db._today().isoformat()[:7], amount, cur))


def note_balance(c, agency: str, amount: float, cur: str) -> None:
    """Esošais "balance" ziņojums (neizmaksātais) — arī izmaksu stāvoklī un mēneša vēsturē."""
    ensure(c)
    cur = _cur(agency, cur)
    old = c.execute("SELECT unpaid, available, min_payout, next_date, updated FROM pinfo WHERE agency=?", (agency,)).fetchone()
    avail = old["available"] if old else None
    # 0.3.1 (lietotājs 2026-10-31: Adobe pēc atjaunošanas Pārskatā jaunā pārdošana bija, bet atgādinājumā un prognozē —
    # vecā summa): izmaksu lapu lasa ne katru reizi (payoutsSafe), tāpēc "pieejams" palika vecs. Aģentūrām, kur pieejamais
    # = neizmaksātais (Adobe, Dreamstime, Zoonar, Ingram), atjaunojam arī to.
    if old and avail is not None and old["unpaid"] is not None and abs(avail - old["unpaid"]) < 0.005:
        avail = amount
    try:                                              # 0.3.1: atlikums nokritās "jāpieprasa" aģentūrā → lietotājs pieprasīja izmaksu
        R = rules().get(agency) or {}
        pr = c.execute("SELECT value FROM state WHERE agency=? AND key='payout_req'", (agency,)).fetchone() if old else None
        prev = json.loads(pr["value"]) if pr and pr["value"] else None
        # 2026-11-04: lietotājs pats atzīmēja "Izmaksu jau pieprasīju" — atlikuma kritums ir tā pati izmaksa, datumu nemainām
        manual = isinstance(prev, dict) and prev.get("manual") and str(prev.get("at") or "") >= str(old["updated"] or "")[:10]
        if old and not manual and R.get("mode") == "request" and R.get("min") and (old["unpaid"] or 0) >= R["min"] and amount < (old["unpaid"] or 0) * 0.5:
            c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "payout_req", json.dumps(
                # 2026-11-03 (lietotājs: Adobe/Zoonar pieprasīti 31.10., programma rādīja 2./3.11.): īstais pieprasījums bija
                # starp iepriekšējo nolasījumu (`from`) un šodienu (`at`)
                {"at": db._today().isoformat(), "from": str(old["updated"] or "")[:10] or None,
                 "ok": True, "auto": True, "info": f"{old['unpaid']:.2f} → {amount:.2f}",
                 "amount": round((old["unpaid"] or 0) - amount, 2), "currency": cur})))
    except Exception:
        pass
    c.execute("INSERT OR REPLACE INTO pinfo VALUES(?,?,?,?,?,?,?)",
              (agency, amount, avail, cur, old["min_payout"] if old else None,
               old["next_date"] if old else None, dt.datetime.now().isoformat(timespec="seconds")))
    _hist(c, agency, amount, cur)


def _checked(agency: str):
    """Izmaksas pārbaudītas: atceramies dienu un tā brīža atlikumu (nākamreiz pārbauda tikai, ja atlikums
    samazinājies — tātad bijusi izmaksa — vai pagājušas CHECK_DAYS dienas)."""
    def f(c, d):
        r = c.execute("SELECT amount FROM balance WHERE agency=?", (agency,)).fetchone()
        val = json.dumps({"day": db._today().isoformat(), "bal": r["amount"] if r else None})
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "pay_check", val))
        c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (agency, "pay_v", json.dumps(PAY_V)))
    return f


CHECK_DAYS = 7
# izmaksu nolasīšanas versija: kad savācējs iemācās jaunu avotu, pārējās vēsturi vienreiz no jauna (test44)
PAY_V = 44
PAY_V_AG = {"pond5", "shutterstock", "bigstock", "istock", "magnific", "123rf"}


def rescan(agency: str) -> bool:
    return agency in PAY_V_AG and (db.get_state(agency, "pay_v") or 0) < PAY_V


def check_opts(agency: str) -> dict:
    """Savācējam: vai izmaksas jāpārbauda obligāti (pay_due) un atlikums iepriekšējā pārbaudē (pay_bal)."""
    pc = db.get_state(agency, "pay_check") or {}
    today = db._today()
    try:
        ago = (today - dt.date.fromisoformat(pc.get("day") or "")).days
    except ValueError:
        ago = 9999
    last = calendar.monthrange(today.year, today.month)[1]
    # pieprasīšanas laiks: mēneša pēdējās 3 dienas, e-pasta atgādinājuma diena vai "tiklīdz sasniegts minimums" —
    # tad "pieejamā" summa vajadzīga svaiga (reizi dienā)
    when = config.get("sales_mail_when") or "lastday"
    mail = bool(config.get("sales_mail_on"))
    day = min(max(1, int(config.get("sales_mail_day") or 28)), last)
    season = today.day >= last - 2 or (mail and (when == "threshold" or (when == "day" and today.day >= day - 1)))
    due = ago >= CHECK_DAYS or (season and ago >= 1)
    return {"pay_due": due, "pay_bal": pc.get("bal")}


def register() -> None:
    for a in db.AG_ORDER:
        db.INGEST.setdefault((a, "payouts"), _payouts(a))
        db.INGEST.setdefault((a, "payout_info"), _info(a))
        db.INGEST.setdefault((a, "pay_checked"), _checked(a))
    db.INGEST.setdefault(("envato", "market_info"), _info("envato_market"))   # Market atlikums nāk ar Envato logu


# --------------------------------------------------------------------------- noteikumi (iestatījumi)

def rules() -> dict:
    """{aģentūra: {mode, min, cur, url}} — noklusējums + lietotāja iestatījumi (sales_payout)."""
    user = config.get("sales_payout") or {}
    out = {}
    for a in db.AG_ORDER:
        if db.AGENCIES[a].get("archive"):          # arhīva aģentūras (Microstockr imports) — izmaksu nav
            continue
        base = dict(PAYOUT.get(a, {"mode": None, "min": None, "url": ""}))
        u = user.get(a) if isinstance(user, dict) else None
        if isinstance(u, dict):
            if u.get("mode") in MODES or u.get("mode") == "":
                base["mode"] = u.get("mode") or None
            if u.get("min") not in (None, ""):
                try:
                    base["min"] = float(u["min"])
                    base["user_min"] = True
                except (TypeError, ValueError):
                    pass
            if u.get("tax_pct") not in (None, ""):   # 0.3.1: aģentūras ieturētais nodoklis pirms izmaksas (%)
                try:
                    base["tax_pct"] = float(u["tax_pct"])
                except (TypeError, ValueError):
                    pass
            if u.get("paid_delay_d") not in (None, ""):   # 2026-11-06: nauda pienāk N dienas pēc aģentūras datuma (Adobe ~9)
                try:
                    base["paid_delay_d"] = max(-30, min(60, int(u["paid_delay_d"])))
                except (TypeError, ValueError):
                    pass
        base["cur"] = db.AGENCIES[a]["currency"]
        out[a] = base
    return out


# --------------------------------------------------------------------------- pārskats

def _month_add(ym: str, n: int) -> str:
    y, m = int(ym[:4]), int(ym[5:7]) + n
    while m > 12:
        y, m = y + 1, m - 12
    while m < 1:
        y, m = y - 1, m + 12
    return f"{y:04d}-{m:02d}"


def is_last_day(d: dt.date | None = None) -> bool:
    d = d or db._today()
    return d.day == calendar.monthrange(d.year, d.month)[1]


def overview(year: int | None = None) -> dict:
    """Izmaksu lapa: aģentūru stāvoklis, "var pieprasīt", alga, izmaksas € pa mēnešiem, gadu salīdzinājums."""
    today = db._today()
    iso = today.isoformat()
    year = int(year or today.year)
    with db._lock:
        c = db.conn()
        ensure(c)
        c.commit()
    R = rules()
    info = {r["agency"]: dict(r) for r in db.q("SELECT * FROM pinfo")}
    # 2026-11-06: izmaksas ar aptuveno saņemšanas datumu nākotnē (Adobe +9 d.) — "ceļā": vēl nav saņemtas
    tdy = db._today().isoformat()
    last = {r["agency"]: dict(r) for r in db.q(
        "SELECT agency, paid_at, amount, currency, amount_eur, status, ref FROM payouts p WHERE paid_at=(SELECT MAX(paid_at) FROM payouts WHERE agency=p.agency AND paid_at<=?)", (tdy,))}
    onway = {r["agency"]: dict(r) for r in db.q(
        "SELECT agency, paid_at, amount, currency, amount_eur, status, ref FROM payouts WHERE paid_at>? ORDER BY paid_at", (tdy,))}
    enabled = set(config.get("sales_agencies") or [])
    rows, can_request = [], []
    for a in db.AG_ORDER:
        if a not in R:
            continue
        i = info.get(a, {})
        if a not in enabled and not i and a not in last:
            continue
        r = R[a]
        cur = i.get("currency") or r["cur"]
        unpaid = i.get("unpaid")
        avail = i.get("available")
        base = avail if avail is not None else unpaid
        # minimums: lietotāja iestatījums → aģentūras lapā nolasītais → noklusējums
        minv = r["min"] if r.get("user_min") else (i.get("min_payout") if i.get("min_payout") is not None else r["min"])
        ready = bool(base is not None and minv and base >= minv - 1e-9)
        eur = to_eur(db.conn(), a, base or 0, cur, iso) if base else 0.0
        extra = {}
        # 0.3.1 Bigstock (lietotājs 2026-10-31): pārdošanas pieprasāmas tikai pēc hold_d dienām → pieejamais ≈ neizmaksātais − pēdējo dienu pārdošanas
        if r.get("hold_d") and avail is None and unpaid is not None:
            since = (today - dt.timedelta(days=int(r["hold_d"]))).isoformat()
            rec = db.q1("SELECT SUM(amount) s FROM sales WHERE agency=? AND substr(sold_at,1,10) > ?", (a, since))
            avail = max(0.0, round((unpaid or 0) - ((rec["s"] if rec else 0) or 0), 2))
            base = avail
            extra["hold_d"] = int(r["hold_d"])
        # 0.3.1-test3 Envato Elements (lietotājs 2026-11-01): neizmaksātā = pieejamā = gaidāmā izmaksa (Envato maksā laikā)
        if a == "envato":
            ed = _envato_due(today, last.get(a))
            if ed:
                unpaid = avail = base = ed["amount"]
                cur = "USD"
                extra["next_date"] = ed["date"]
                extra["env_for"] = ed["for"]
                ready = base >= (minv or 50) - 1e-9
        # 0.3.1 Magnific (lietotājs 2026-10-31): rēķinā lejupielādes līdz M−2 beigām; minimums skaitās PĒC nodokļa
        if a == "magnific" and r.get("validate"):
            extra["mag"] = mag = _magnific(r, last.get(a), today, i)
            # 2026-11-04: ja Magnific jau izrakstījis rēķinu — pieejams = rēķina summa (Magnific skaitlis, ne mūsu aprēķins)
            base = mag["pending"] if mag["pending"] is not None else mag["net"]
            # 2026-11-03 (lietotājs): gaidošs rēķins zem minimuma (€36.33 < €50) nav "var izmaksāt"; pieejams = neto pēc nodokļa
            mag["pending_ok"] = bool(mag["pending"] is not None and mag["pending"] >= (minv or 50) - 1e-9)
            ready = mag["pending_ok"] or mag["net"] >= (minv or 50) - 1e-9
            unpaid = mag["net_all"]                   # 2026-11-04 (lietotājs): neizmaksātais — jau pēc nodokļa
            avail = base
        # 0.3.1 Pixta u.c.: "ja pieprasīsi šodien — izmaksa ~DD.MM." (pay_day, pay_lag_m)
        if r.get("pay_day") and r.get("mode") == "request" and a != "magnific":
            ym = _month_add(iso[:7], int(r.get("pay_lag_m") or 0))
            extra["pay_if_today"] = f"{ym}-{int(r['pay_day']):02d}"
        if base is not None and minv and a != "magnific":
            ready = ready or base >= minv - 1e-9
        eur = to_eur(db.conn(), a, base or 0, cur, iso) if base else 0.0
        req = _requested(a, r, last.get(a))
        if a in onway:                                 # aģentūra jau izmaksāja, nauda vēl ceļā (aptuvenais datums nākotnē)
            ow = onway[a]
            req = {"ok": True, "auto": True, "at": str(ow.get("ref") or "")[4:14] or ow["paid_at"], "eta": ow["paid_at"],
                   "amount": ow["amount"], "onway": True}
        row = {"agency": a, "mode": r["mode"], "min": minv, "currency": cur, "unpaid": unpaid, "available": avail,
               "ready": ready, "eur": round(eur, 2), "pct": round(min(100, (base or 0) / minv * 100)) if minv else None,
               "url": r["url"], "next_date": extra.pop("next_date", None) or i.get("next_date"), "updated": i.get("updated"),
               "last": last.get(a), "req": req, "base": base, "tax_pct": r.get("tax_pct"),
               **extra}
        # 2026-11-04 (lietotājs): rādām to, ko tiešām izmaksās — pēc ieturētā nodokļa (minimums un % — kā aģentūra skaita)
        tf = 1 - float(r.get("tax_pct") or 0) / 100.0 if a != "magnific" else 1.0
        row["tf"] = tf
        if tf < 1:
            row["gross"] = {"unpaid": unpaid, "available": avail}
            row["unpaid"] = round(unpaid * tf, 2) if unpaid is not None else None
            row["available"] = round(avail * tf, 2) if avail is not None else None
        rows.append(row)
        if ready and r["mode"] == "request" and not req:
            if a == "magnific":
                mag = extra["mag"]
                if not (mag.get("pending_ok") or 4 <= today.day <= 9):
                    continue                       # Magnific: atgādinām tikai rēķina apstiprināšanas laikā (4.–9.)
            amt_r = mag["pending"] if a == "magnific" and mag.get("pending_ok") else base   # 2026-11-03: bija €0.00
            can_request.append({"agency": a, "amount": round(amt_r * tf, 2) if amt_r is not None else None, "gross_amount": amt_r,
                                "currency": cur, "eur": round(eur * tf, 2), "url": r["url"], "validate": a == "magnific"})

    # alga: šomēnes saņemts + prognoze. Lietotājs 2026-11-01: līdz pēdējai iespējamajai izmaksas dienai mēnesī
    # (aģentūru ierastās izmaksu dienas no vēstures, piem. iStock ~25.) prognoze ir ŠIM mēnesim — tas, kas vēl
    # gaidāms (pieprasītās, automātiskās, Envato, Magnific rēķins), bez jau saņemtā; pēc tās — nākamajam mēnesim.
    m0 = iso[:7]
    got = db.q("SELECT agency, SUM(amount_eur) e FROM payouts WHERE substr(paid_at,1,7)=? AND paid_at<=? GROUP BY agency", (m0, iso))
    got_ag = {g["agency"] for g in got}
    pday = {r["agency"]: _pay_day(r["agency"]) for r in rows}
    # lietotājs 2026-11-01 18:44: robeža = iStock izmaksas diena (~25.), ne citu aģentūru (Alamy u.c.) vēlākās dienas
    last_pay = pday.get("istock") or _pay_day("istock") or LAST_PAY_DAY
    cur_m = today.day <= last_pay
    fm = m0 if cur_m else _month_add(m0, 1)
    expected = []
    for r in rows:
        a = r["agency"]
        if cur_m and a in got_ag:
            continue                                   # šomēnes jau saņemts
        if a == "envato":
            continue                                   # Envato Elements — zemāk (par mēnesi prognozes mēnesis −2)
        q = r.get("req")
        if q and q.get("ok"):                         # pieprasīts — gaida izmaksu
            lag = int(R.get(a, {}).get("pay_lag_m") or 0)
            # 2026-11-04: bez pay_lag_m izmaksa nāk dažās dienās → prognozes mēnesī (arī pieprasot pēc robežas, piem. 30.10.)
            due = str(q["eta"])[:7] if q.get("eta") else (_month_add(str(q.get("at") or iso)[:7], lag) if lag else fm)
            amt = q.get("amount")
            if amt is None:
                try:
                    x, y = [float(v) for v in str(q.get("info") or "").split("→")]
                    amt = round(x - y, 2)
                except ValueError:
                    amt = None
            if due == fm and amt:
                expected.append({"agency": a, "amount": amt, "currency": r["currency"], "mode": "req",
                                 "eur": round(to_eur(db.conn(), a, amt, r["currency"], iso), 2),
                                 "req_at": q.get("at"), "req_from": q.get("from"), "eta": q.get("eta")})   # "pieprasīts DD.MM."
            continue
        if a == "magnific" and r.get("mag"):
            mg = r["mag"]
            if cur_m and mg.get("pending_ok"):        # 2026-11-03: tikai rēķins ≥ minimuma; rēķins apstiprināšanai/apstiprināts — izmaksa 10.–15.
                net = round(mg["pending"], 2)          # 2026-11-03 (taxcenter ekrānuzņēmums): rēķina summa jau ir PĒC nodokļa
                expected.append({"agency": a, "amount": net, "currency": "EUR", "eur": net, "mode": "request"})
            elif not cur_m and r["ready"]:
                expected.append({"agency": a, "amount": mg["net"], "currency": "EUR", "eur": mg["net"], "mode": "request"})
            continue
        if r["ready"] and r["mode"] == "auto":
            d = pday.get(a)
            if cur_m and d and d < today.day:
                continue                               # šomēnes izmaksas diena jau pagājusi
            # pēc robežas: šomēnes gaidītā izmaksa (diena pagājusi), kas vēl nav redzēta, — uzskatām par notikušu
            if not cur_m and a != "envato" and a not in got_ag and d and d <= today.day:
                continue
            expected.append({"agency": a, "eur": r["eur"], "mode": "auto", "amount": r.get("base"), "currency": r["currency"]})
        elif r["ready"] and r["mode"] == "request" and not cur_m:
            expected.append({"agency": a, "eur": r["eur"], "mode": "request", "amount": r.get("base"), "currency": r["currency"]})
    # Envato Elements: ienākumi par mēnesi M tiek izmaksāti M+2 15. datumā, ja ≥ $50 (docs/stoku-izmaksu-noteikumi.md)
    em = _month_add(fm, -2)
    eamt = _envato_ev(em)
    emin = (R.get("envato") or {}).get("min") or 50
    if eamt >= emin - 1e-9 and not (cur_m and ("envato" in got_ag or today.day > 16)):
        expected.append({"agency": "envato", "eur": round(usd_to_eur(eamt, iso), 2), "mode": "auto", "for": em,
                         "amount": eamt, "currency": "USD", "pay_date": f"{fm}-15"})   # 2026-11-04: "izmaksa 15.11."
    for x in expected:                                 # ieturētais nodoklis (Magnific jau ieskaitīts)
        tx = (R.get(x["agency"]) or {}).get("tax_pct")
        if tx and x["agency"] != "magnific":
            x["amount"] = round((x.get("amount") or 0) * (1 - tx / 100.0), 2)
            x["eur"] = round(x["eur"] * (1 - tx / 100.0), 2)
    salary = {
        "month": m0, "next_month": fm, "fc_current": cur_m, "last_pay_day": last_pay,
        "received": round(sum(g["e"] or 0 for g in got), 2),
        "received_by": {g["agency"]: round(g["e"] or 0, 2) for g in got},
        "expected": round(sum(x["eur"] for x in expected), 2), "expected_by": expected,
        "unpaid_total": round(sum(r["eur"] * r["tf"] if r["available"] is None else to_eur(db.conn(), r["agency"], r["unpaid"] or 0, r["currency"], iso)
                                  for r in rows if r["unpaid"]), 2),
    }

    # izmaksas € pa mēnešiem gadā
    mrows = db.q("""SELECT agency, CAST(substr(paid_at,6,2) AS INT) m, SUM(amount_eur) e, SUM(amount_usd) u FROM payouts
                    WHERE substr(paid_at,1,4)=? GROUP BY agency, m""", (str(year),))
    matrix: dict = {}
    for r in mrows:
        matrix.setdefault(r["agency"], {})[r["m"]] = round(r["e"] or 0, 2)
    month_tot = {m: round(sum(v.get(m, 0) for v in matrix.values()), 2) for m in range(1, 13)}
    last_m = 12 if year < today.year else today.month
    year_tot = round(sum(month_tot.values()), 2)
    avg = round(year_tot / last_m, 2) if year <= today.year and last_m else 0
    years = [dict(r) for r in db.q("SELECT substr(paid_at,1,4) y, SUM(amount_eur) e, COUNT(*) n FROM payouts GROUP BY y ORDER BY y")]
    for i, y in enumerate(years):
        y["e"] = round(y["e"] or 0, 2)
        prev = years[i - 1]["e"] if i else 0
        y["d"] = round((y["e"] - prev) / prev * 100, 1) if prev else None
    # neizmaksātais mēneša beigās (oriģinālajā valūtā)
    # tikai pēdējā zināmā vērtība katrai aģentūrai + mēnesis, kura beigās tā bija (lietotājs 2026-10-30 22:27:
    # neizmaksātais pārceļas uz nākamo periodu, līdz sasniedz minimumu — vēsture pa mēnešiem nav vajadzīga)
    hist: dict = {}
    for r in db.q("""SELECT agency, month, amount, currency FROM bal_hist b
                     WHERE month = (SELECT MAX(month) FROM bal_hist WHERE agency = b.agency)"""):
        hist[r["agency"]] = [round(r["amount"] or 0, 2), r["currency"], r["month"][:7]]
    return {"today": iso, "last_day": is_last_day(today), "year": year, "rows": rows, "can_request": can_request,
            "salary": salary, "matrix": matrix, "month_tot": month_tot, "year_tot": year_tot, "avg": avg, "avg_months": last_m,
            "years": years, "hist": hist, "min_year": (years[0]["y"] if years else str(today.year))}


def _envato_ev(month: str):
    ev = db.q1("SELECT SUM(earnings) e FROM monthly WHERE agency='envato' AND month=?", (month,))
    if not ev or not (ev["e"] or 0):     # mēnesis vēl rēķinās — Envato mēneša skatā to nedod, dienās ir (test53)
        ev = db.q1("SELECT SUM(earnings) e FROM daily WHERE agency='envato' AND substr(day,1,7)=?", (month,))
    return round(ev["e"], 2) if ev and (ev["e"] or 0) > 0 else 0.0


def _envato_due(today: dt.date, lastp: dict | None):
    """Nākamā Envato Elements izmaksa: 15. datumā par M−2; ja šomēnes jau izmaksāts (vai pēc 16.) — nākamajā mēnesī par M−1."""
    m0 = today.isoformat()[:7]
    paid = bool(lastp and str(lastp.get("paid_at") or "")[:7] == m0) or today.day > 16
    pm = _month_add(m0, 1) if paid else m0
    fm = _month_add(pm, -2)
    return {"for": fm, "amount": _envato_ev(fm), "date": f"{pm}-15"}


LAST_PAY_DAY = 25      # ja vēstures nav: pēdējā ierastā izmaksas diena mēnesī (iStock ~25., lietotājs 2026-11-01)


def _pay_day(a: str) -> int | None:
    """Aģentūras ierastā izmaksas diena mēnesī — mediāna no pēdējām 6 izmaksām (vai PAYOUT pay_day)."""
    ds = sorted(int(str(x["paid_at"])[8:10]) for x in db.q(
        "SELECT paid_at FROM payouts WHERE agency=? ORDER BY paid_at DESC LIMIT 6", (a,)) if len(str(x["paid_at"])) >= 10)
    return ds[len(ds) // 2] if ds else PAYOUT.get(a, {}).get("pay_day")


def _magnific(r: dict, lastp: dict | None, today: dt.date, info: dict) -> dict:
    """Magnific rēķins: ienākumi par mēnešiem pēc pēdējā apmaksātā rēķina perioda līdz M−2 ("nobrieduši") → bruto € un
    neto pēc nodokļa (tax_pct, lietotāja iestatījums sales_payout.magnific.tax_pct). Slieksnis €50 — PĒC nodokļa."""
    tax = float(r.get("tax_pct") if r.get("tax_pct") is not None else 24)   # rules(): lietotāja vērtība vai 24
    m0 = today.isoformat()[:7]
    covered = _month_add(str(lastp["paid_at"])[:7], -2) if lastp and lastp.get("paid_at") else "0000-00"
    matured_to = _month_add(m0, -2)
    months = [dict(x) for x in db.q("""SELECT month, SUM(earnings) e FROM monthly WHERE agency='magnific' AND month > ?
                                       GROUP BY month ORDER BY month""", (covered,))]
    gross = gross_all = 0.0
    inv_month = None                  # kad (rēķina mēnesis) neto sasniegs minimumu: mēnesis X nobriest mēnesī X+2
    mn = float(r.get("min") or 50)
    for x in months:
        e = usd_to_eur(x["e"] or 0, x["month"] + "-15")
        gross_all += e
        if x["month"] <= matured_to:
            gross += e
        if inv_month is None and gross_all * (1 - tax / 100.0) >= mn - 1e-9:
            inv_month = max(_month_add(x["month"], 2), m0 if today.day <= 9 else _month_add(m0, 1))
    net = gross * (1 - tax / 100.0)
    pending = info.get("unpaid") if info.get("updated") and info.get("unpaid") else None
    # nākamais rēķins: ja jau tagad ≥ min — šī mēneša 4. (vai nākamā, ja 4.–9. pagājis); citādi — kad nobriedīs
    nxt = f"{m0}-04" if today.day <= 9 else f"{_month_add(m0, 1)}-04"
    return {"gross": round(gross, 2), "net": round(net, 2), "gross_all": round(gross_all, 2),
            "net_all": round(gross_all * (1 - tax / 100.0), 2), "tax": tax,
            "matured_to": matured_to, "covered": covered, "pending": pending, "next_invoice": nxt,
            "inv_month": inv_month}


def _requested(a: str, r: dict, lastp: dict | None):
    """0.3.1 (lietotājs 2026-10-31): izmaksu pieprasa lietotājs pats. Ja "jāpieprasa" aģentūras atlikums strauji nokritās
    (pieprasīts), bet izmaksas vēsturē vēl nav jaunas izmaksas — "pieprasīts DD.MM. — gaida izmaksu"."""
    q = db.get_state(a, "payout_req")
    if not q or not isinstance(q, dict):
        return None
    start = str(q.get("from") or q.get("at") or "")[:10]
    paid = str((lastp or {}).get("paid_at") or "")[:10]
    if paid and paid >= start:
        return None                                  # izmaksa jau pienākusi (aģentūras izmaksu datums var būt pieprasījuma diena)
    # 2026-11-04 (Zoonar €25.56 prognozē, lai gan izmaksāts): ieraksts bez `from` (pirms 03.11. labojuma) vai ķeksis
    # atzīmēts dienu vēlāk — aģentūra izmaksu datē ar pieprasījuma dienu (Zoonar 31.10.), kas ir PIRMS `at`. Ja tā pati
    # summa izmaksāta ≤ 7 dienas pirms — skaitās pienākusi.
    try:
        near = paid and (dt.date.fromisoformat(start) - dt.date.fromisoformat(paid)).days <= 7
    except ValueError:
        near = False
    amt = q.get("amount")
    got = float(lastp.get("amount") or 0) if lastp else 0.0
    gross = str((lastp or {}).get("status") or "")
    if gross.startswith("bruto "):                   # Zoonar: pieprasīta bruto summa, saņemta pēc nodokļa
        try:
            got = float(gross[6:])
        except ValueError:
            pass
    if near and (amt is None or abs(got - float(amt)) <= max(1.0, float(amt) * 0.05)):
        return None
    if q.get("auto") is False:                        # vecie ieraksti no "Pieprasīt visas" (0.3.0) — rādām kā līdz šim
        return q
    return q


def mark_requested(agency: str, on: bool = True) -> None:
    """2026-11-04 (lietotājs): ķeksis "Izmaksu jau pieprasīju" atgādinājumā — šodiena = pieprasījuma datums, summa =
    tagad pieejamā; par šo izmaksu vairs neatgādina. Noņemot — ieraksts dzēsts (tikai paša atzīmētais)."""
    if not on:
        q = db.get_state(agency, "payout_req")
        if isinstance(q, dict) and q.get("manual"):
            db.set_state(agency, "payout_req", None)
        return
    row = next((x for x in overview()["can_request"] if x["agency"] == agency), None)
    day = db._today().isoformat()
    db.set_state(agency, "payout_req", {"at": day, "from": day, "ok": True, "auto": False, "manual": True,
                                        "amount": round(row["gross_amount"], 2) if row and row.get("gross_amount") is not None else None,
                                        "currency": row["currency"] if row else None, "info": "ķeksis"})


def recent(limit: int = 50) -> list[dict]:
    return [dict(r) for r in db.q("SELECT * FROM payouts ORDER BY paid_at DESC LIMIT ?", (limit,))]
