"""Vārdotāja manifesti → "Manas bildes aģentūrās" (portfeļa modulis; lietotājs 2026-11-09:
"vārdotājs speciāli šim mērķim gatavo manifestu, sīktēlu un digitālo nospiedumu. Jaunajām bildēm būtu jānolasās 100%").

Kur meklē (noteikumi, dati §7a): iestatījums `sales_manifest_dir`; citādi Vārdotāja iestatījumi tajā pašā datorā
(`<datu mapes vecāks>/Vardotajs/settings.json`: `manifest_dir`, citādi `<ready_dir>/Manifesti`), citādi `Vardotajs/Manifesti`;
papildus Vārdotāja `manifests.json` (sēriju mapes ar `.fotostokeris/` / `_fotostokeris/`).
Moduļi viens otru neimportē — lasām tikai failus.
Google Drive (test32, dati §7a (c)): ja Google konts pieslēgts — `core.manifests_drive.pull` uz datu mapi `Manifesti-drive/`
(ne biežāk kā ik 15 min; poga "Pārlasīt" — uzreiz). Kopš test49 lasa TIKAI `"kind": "set"` (Tirgotāja komplekti — OneDrive
sagatavotās/iesniegtās bildes); Vārdotāja sēriju manifestus izlaiž; bildes ar `deleted`/`moved` neskaita.
Pēc sasaistes — `agenturas_bildes.json` Tirgotājam (datu mapē + Drive `Fotostokeris/Kopigi/`, dati §8c).

Sasaiste katrai aģentūrai (sub_status statusi + assets pārdošanas):
  1) faila nosaukums (`<kods>_<oriģinālais>` vai oriģinālais) — drošākais;
  2) virsraksts (≥ 25 zīmes, vienāds) — Vārdotāja virsraksts nonāk aģentūrā;
  3) vizuālais nospiedums — Analītiķis pats rēķina no manifesta sīktēliem (`-sikteli.zip`) ar lookalike.dhash
     (tā pati metode kā aģentūru sīktēliem; manifesta `phash` rēķināts bez malu apgriešanas, tāpēc to nelieto).
"""
from __future__ import annotations

import datetime as dt
import io
import json
import os
import re
import zipfile
from pathlib import Path

from . import config, db

SCHEMA = """
CREATE TABLE IF NOT EXISTS own_images(stem TEXT PRIMARY KEY, file TEXT, series TEXT, series_id TEXT, title TEXT,
  category TEXT, status TEXT, taken_at TEXT, width INT, height INT, dh TEXT, updated TEXT, src TEXT);
CREATE TABLE IF NOT EXISTS own_links(stem TEXT, agency TEXT, agency_item_id TEXT, how TEXT,
  PRIMARY KEY(stem, agency, agency_item_id));
"""
EXPORT = "agenturas_bildes.json"
PULL_EVERY = 900         # s — Drive manifestu pārbaude
HASH_DIST = 4            # nospiedums: stingri (tā pati bilde, cits sīktēla izmērs/kvalitāte); test35: bija 5
PROJECT_START = "2026-10-01"  # test37: Vārdotāja manifesti; agrāk aģentūrās nonākušas bildes — vecas, neskaita
HASH_GAP = 3             # test35: otrai tuvākajai bildei jābūt vismaz par tik tālāk (citādi — neviennozīmīgi)


def ensure(c) -> None:
    from . import substatus
    c.executescript(SCHEMA + substatus.SCHEMA)
    cols = {r[1] for r in c.execute("PRAGMA table_info(own_images)")}
    if "orig" not in cols:
        c.execute("ALTER TABLE own_images ADD COLUMN orig TEXT")
    if "since" not in cols:                                  # test36: kad Vārdotājs bildi sagatavoja (manifesta `created`)
        c.execute("ALTER TABLE own_images ADD COLUMN since TEXT")
    if "descr" not in cols:                                  # test45: apraksts (Depositphotos/Pond5 rāda aprakstu kā virsrakstu)
        c.execute("ALTER TABLE own_images ADD COLUMN descr TEXT")


def enabled() -> bool:
    """Beta "Manas bildes aģentūrās" (test35: atsevišķi ieslēdzams)."""
    return not config.get("sales_beta_off") and config.get("sales_beta_own") is not False


def drive_dir() -> Path:
    # test50 (dati §7a vienkāršotā kārtība p.10): tikai Google `Fotostokeris/Komplekti` (raksta Tirgotājs)
    return Path(config.app_dir()) / "Komplekti-drive"


def shown_dirs() -> list[str]:
    """Saskarnei: Google lejupielādes mapes vietā — "Google Drive Fotostokeris/Komplekti"."""
    g = os.path.normcase(os.path.abspath(str(drive_dir())))
    out = []
    for d in dirs():
        if os.path.normcase(os.path.abspath(d)).startswith(g):
            d = "Google Drive Fotostokeris/Komplekti"
        if d not in out:
            out.append(d)
    return out


def pull(force: bool = False) -> dict | None:
    """Jaunākie komplektu manifesti no Google Drive `Fotostokeris/Komplekti/` (tikai, ja Google konts pieslēgts)."""
    try:
        from core import google, manifests_drive
        if not google.connected():
            return None
    except Exception:
        return None
    last = db.get_state("", "own_pull") or ""
    try:
        if not force and last and (dt.datetime.now() - dt.datetime.fromisoformat(last)).total_seconds() < PULL_EVERY:
            return None
    except ValueError:
        pass
    try:
        r = manifests_drive.pull(drive_dir(), folder=getattr(manifests_drive, "KOMPLEKTI", "Komplekti"))
        print(f"komplekti no Google Drive (Komplekti): jauni {r.get('new')}, kopā {r.get('total')}")
    except Exception as e:
        print("manifesti no Google Drive:", str(e)[:200])
        r = None
    db.set_state("", "own_pull", dt.datetime.now().isoformat(timespec="seconds"))
    if r and r.get("total"):
        _trash_old(google)
    return r


def _trash_old(google) -> None:
    """test60 (dati §7a vienkāršotā kārtība p.16; lietotājs 2026-11-12: "ja tā google mape nav vairs vajadzīga, dzēšam to"):
    veco Google `Fotostokeris/Manifesti/` pārvieto uz Google Drive atkritni (ne neatgriezeniski — 30 dienas var atjaunot).
    Vienreiz (stāvoklis `own_old_trashed`); tikai pēc veiksmīgas `Komplekti` nolasīšanas. Lokālo `Manifesti-drive/` izdzēš."""
    if db.get_state("", "own_old_trashed"):
        return
    try:
        n = 0
        for f in google.root_folders("Manifesti"):
            google._json("PATCH", f"{google.DRIVE}/files/{f['id']}", params={"fields": "id,trashed"}, body={"trashed": True})
            n += 1
        print(f"vecā Google mape Fotostokeris/Manifesti → atkritnē ({n})")
        import shutil
        shutil.rmtree(Path(config.app_dir()) / "Manifesti-drive", ignore_errors=True)
        db.set_state("", "own_old_trashed", dt.datetime.now().isoformat(timespec="seconds"))
    except Exception as e:
        print("vecā Google mape Manifesti:", str(e)[:200])


def _vard_dir() -> Path:
    return Path(config.app_dir()).parent / "Vardotajs"


def dirs() -> list[str]:
    out: list[str] = []
    own = str(config.get("sales_manifest_dir") or "").strip()
    if own:
        out.append(own)
    if _google():                                            # test34: ar Google kontu — tikai Google (+ pašu norādītā mape)
        out.append(str(drive_dir()))
        return _uniq(out)
    vd = _vard_dir()
    try:
        s = json.loads((vd / "settings.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        s = {}
    md, rd = str(s.get("manifest_dir") or "").strip(), str(s.get("ready_dir") or "").strip()
    if md:
        out.append(md)
    if rd:
        out.append(os.path.join(rd, "Manifesti"))
    out.append(str(vd / "Manifesti"))
    out.append(str(drive_dir()))
    try:                                                     # sēriju mapes, kuras Vārdotājs pierakstījis
        idx = json.loads((vd / "manifests.json").read_text(encoding="utf-8"))
        for v in (idx.values() if isinstance(idx, dict) else idx):
            p = v.get("path") if isinstance(v, dict) else v
            if isinstance(p, str) and p:
                out.append(os.path.dirname(p) if p.endswith(".json") else p)
    except (OSError, ValueError, AttributeError):
        pass
    return _uniq(out)


def _google() -> bool:
    try:
        from core import google
        return bool(google.connected())
    except Exception:
        return False


def _uniq(out: list[str]) -> list[str]:
    seen, res = set(), []
    for d in out:
        for sub in (d, os.path.join(d, ".fotostokeris"), os.path.join(d, "_fotostokeris")):
            k = os.path.normcase(os.path.abspath(sub))
            if k not in seen and os.path.isdir(sub):
                seen.add(k)
                res.append(sub)
    return res


def _files() -> list[str]:
    found: dict[str, str] = {}
    for d in dirs():
        try:
            names = os.listdir(d)
        except OSError:
            continue
        for n in names:
            if n.endswith(".json") and not n.startswith(".") and n != "manifests.json":
                p = os.path.join(d, n)
                try:
                    j = json.load(open(p, encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                if not isinstance(j, dict) or "images" not in j:
                    continue
                # test49 (lietotājs 2026-11-11, lēmums 16:45): tikai Tirgotāja komplekti — bildes, kas OneDrive sagatavotas
                # iesniegšanai. Vārdotāja sērijas (vēl nesagatavotas) netiek ne rādītas, ne meklētas aģentūrās.
                if not (j.get("kind") == "set" or j.get("set_id")):
                    continue
                sid = str(j.get("set_id") or j.get("series_id") or p)
                if sid not in found or os.path.getmtime(p) > os.path.getmtime(found[sid]):   # jaunākā kopija uzvar
                    found[sid] = p
    return sorted(found.values())


def _key(name: str) -> str:
    b = os.path.basename(str(name or "")).strip().lower()
    return re.sub(r"\.(jpe?g|tiff?|png|eps|ai|svg|psd|dng|cr2|cr3|nef|arw|raf|orf|heic|mov|mp4)$", "", b)


def _orig(k: str) -> str:
    return re.sub(r"^[0-9a-f]{4}_", "", k)                   # bez Vārdotāja koda "d738_"


def scan(force: bool = False) -> dict:
    """Ielasa manifestus (bildes + nospiedumi no sīktēliem) un piesaista aģentūru ierakstus. Ātri; var saukt bieži."""
    from . import lookalike
    pull(force)
    files = _files()
    now = dt.datetime.now().isoformat(timespec="seconds")
    imgs = 0
    seen: set[str] = set()
    with db._lock:
        c = db.conn()
        ensure(c)
        known = {r[0]: (r[1], r[2]) for r in c.execute("SELECT stem, updated, dh FROM own_images")}
    for p in files:
        try:
            j = json.load(open(p, encoding="utf-8"))
        except (OSError, ValueError):
            continue
        zpath = _zip_for(p)
        try:
            zf = zipfile.ZipFile(zpath) if os.path.exists(zpath) else None
        except (OSError, zipfile.BadZipFile):
            zf = None
        rows = []
        for im in j.get("images") or []:
            stem = str(im.get("stem") or "").strip()
            if not stem or im.get("status") in ("moved", "deleted") or stem in seen:   # deleted — dati §7a (c) 1
                continue
            seen.add(stem)
            upd = str(im.get("updated") or "")
            dh = None
            old = known.get(stem)
            if old and old[0] == upd and old[1]:
                dh = old[1]
            elif zf:
                try:
                    dh = lookalike.dhash(zf.read(stem + ".jpg"))
                except (KeyError, OSError, zipfile.BadZipFile):
                    dh = None
            rows.append((stem, im.get("file") or "", j.get("name") or "", j.get("set_id") or j.get("series_id") or "", im.get("title") or "",
                         im.get("category") or "", im.get("status") or "", im.get("taken_at") or "",
                         im.get("width"), im.get("height"), dh, upd, p, im.get("orig_file") or "",
                         str(j.get("created") or im.get("updated") or now)[:10], str(im.get("description") or "")[:500]))
        if zf:
            zf.close()
        with db._lock:
            c = db.conn()
            c.executemany("INSERT OR REPLACE INTO own_images(stem,file,series,series_id,title,category,status,taken_at,"
                          "width,height,dh,updated,src,orig,since,descr) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", rows)
            c.commit()
        imgs += len(rows)
    if True:                                                 # bildes, kuru vairs nav nevienā komplektā (test49: arī visas sēriju bildes)
        with db._lock:
            c = db.conn()
            gone = [r[0] for r in c.execute("SELECT stem FROM own_images") if r[0] not in seen]
            c.executemany("DELETE FROM own_images WHERE stem=?", [(g,) for g in gone])
            c.commit()
    n = link()
    print(f"manifesti: {len(files)} komplekti, {imgs} bildes, sasaistes {n}")
    db.set_state("", "own_scan", now)
    try:
        export()
    except Exception as e:
        print("agenturas_bildes.json:", str(e)[:200])
    return {"series": len(files), "images": imgs, "links": n, "dirs": shown_dirs()}


_MON = {m: i for i, m in enumerate(["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"], 1)}


def _date(v) -> str:
    """'2026-09-08', '2023-01-23T06:50:09Z', '05 November 2026', 'Nov 5, 2026' → 'YYYY-MM-DD' ('' — nezināms)."""
    s = str(v or "").strip()
    if re.fullmatch(r"\d{10}|\d{13}", s):                  # unix laiks (s / ms)
        return dt.datetime.utcfromtimestamp(int(s[:10])).strftime("%Y-%m-%d")
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", s)
    if m:
        return m.group(0)
    m = re.match(r"(\d{1,2})\.? ([A-Za-z]{3})[a-z]*\.? (\d{4})", s) or None
    if m and m.group(2).lower() in _MON:
        return f"{m.group(3)}-{_MON[m.group(2).lower()]:02d}-{int(m.group(1)):02d}"
    m = re.match(r"([A-Za-z]{3})[a-z]*\.? (\d{1,2}),? (\d{4})", s)
    if m and m.group(1).lower() in _MON:
        return f"{m.group(3)}-{_MON[m.group(1).lower()]:02d}-{int(m.group(2)):02d}"
    m = re.match(r"(\d{1,2})[./](\d{1,2})[./](\d{4})", s)
    return f"{m.group(3)}-{int(m.group(2)):02d}-{int(m.group(1)):02d}" if m else ""


def _noed(t: str) -> str:
    """test48: ED priekšvārds "dubrovnik, croatia - september 17, 2025:  " — salīdzinot neņem vērā."""
    return re.sub(r"^[^:]{5,80}?\b\d{4}\s*:\s+", "", t or "")


def _words(x: str) -> str:
    """test64: tikai burti/cipari ar vienu atstarpi (Magnific "Dubrovnik39s" = "Dubrovnik's")."""
    x = re.sub(r"(?<=[a-z])(?:&#39;|39)(?=s\b)", "", (x or "").lower())
    return re.sub(r"[^0-9a-z]+", "", x)


HIDES_REJECTED = ("zoonar",)   # test65: aģentūras, kas noraidītās lapā nerāda
THUMB_MAX = 200          # test65: statusu sīktēlu nospiedumi — ne vairāk kā tik vienā reizē (lejupielāde ~0,2–1 s)
HASH_SOLO = 2            # test65: komplekta bildei (nesens iesniegums) nospiedums ≤ šim un viennozīmīgs — pietiek ar to vien


def hash_status_thumbs() -> int:
    """test65 (lietotājs 2026-11-14: "visiem komplektiem ir manifesti un sīktēli, kāpēc neizmanto tos?"): iesniegumu statusu
    rindām ar sīktēla adresi (`sub_status.thumb`) aprēķina nospiedumu → `thumb_hash` (tā pati tabula kā pārdošanām).
    Tikai pēdējo 120 dienu / neapstiprinātās un tikai tās, kam ieraksta vēl nav (Magnific adresēm mainās parametri —
    nepārrēķinām; pārdošanu sīktēlam jau esošo ierakstu neaiztiekam)."""
    from . import lookalike, substatus
    cut = (dt.date.today() - dt.timedelta(days=120)).isoformat()
    with db._lock:
        c = db.conn()
        c.executescript(substatus.SCHEMA)
        substatus._cols(c)
        lookalike.ensure(c)
        todo = [tuple(r) for r in c.execute(
            """SELECT s.agency, s.item_id, s.thumb FROM sub_status s
               LEFT JOIN thumb_hash th ON th.agency=s.agency AND th.agency_item_id=s.item_id
               WHERE COALESCE(s.thumb,'')!='' AND th.agency IS NULL
                 AND (s.status!='accepted' OR COALESCE(s.submitted_at,'')='' OR s.submitted_at>=?)
               ORDER BY s.seen_at DESC LIMIT ?""", (cut, THUMB_MAX))]
    if not todo:
        return 0
    got = []
    for ag, iid, url in todo:
        b = lookalike._fetch(url)
        got.append((ag, iid, url, (lookalike.dhash(b) if b else None) or ""))
    with db._lock:
        c = db.conn()
        c.executemany("INSERT OR REPLACE INTO thumb_hash VALUES(?,?,?,?)", got)
        c.commit()
    n = sum(1 for g in got if g[3])
    print(f"statusu sīktēli: nospiedumi {n}/{len(got)}")
    return n


def link() -> int:
    """Sasaiste (test36, lietotājs: "ja skaitīsi tikai tās bildes, nokļūdīties būs grūtāk"):
    1) Vārdotāja kods faila nosaukumā `<kods>_<oriģinālais>` — drošs, vienmēr;
    2) citādi — aģentūra bildi saņēmusi NE AGRĀK, kā Vārdotājs to sagatavoja (`since`; bez datuma — tikai iesniegumu
       statusu saraksti, tie ir nesenie), UN vismaz DIVAS sakritības no: oriģinālais faila nosaukums, pilns virsraksts
       (aģentūras saīsinātais — ≥40 zīmes), sīktēla nospiedums (viennozīmīgs, ≤4). Vecas bildes (pirms projekta) netiek skaitītas."""
    from . import lookalike
    try:
        hash_status_thumbs()
    except Exception as e:                                   # sīktēli — tikai palīgs; sasaiste notiek arī bez tiem
        print("statusu sīktēli:", str(e)[:160])
    with db._lock:
        c = db.conn()
        ensure(c)
        own = [dict(r) for r in c.execute("SELECT stem, file, title, dh, taken_at, descr FROM own_images")]
        if not own:
            return 0
        # test37: aģentūrā ne agrāk par projekta sākumu un ne agrāk, nekā bilde uzņemta (manifesta `created` var būt vēlāks
        # par iesniegšanu — manifestus pārraksta)
        since = {o["stem"]: max(PROJECT_START, (o["taken_at"] or "")[:10]) for o in own}
        taken = {o["stem"]: (o["taken_at"] or "")[:10] for o in own}
        by_code, by_orig, titles = {}, {}, []
        for o in own:
            for k in {_key(o["stem"]), _key(o["file"])}:
                if re.match(r"^[0-9a-f]{4}_.{3,}", k):
                    by_code.setdefault(k, o["stem"])
                if len(_orig(k)) >= 5:
                    by_orig.setdefault(_orig(k), set()).add(o["stem"])
            for t in {_noed((o["title"] or "").strip().lower()), _noed((o["descr"] or "").strip().lower())}:   # test45: arī apraksts
                if len(t) >= 25:
                    titles.append((t, o["stem"]))
        titles_w = [(_words(t), st) for t, st in titles]      # test64
        cand = []                                            # (agency, item_id, file, title, thumb_hash, datums, statusu saraksts?)
        # test37: statusu sarakstos ir viss portfelis (Envato — 7000 vecu bilžu) → arī tiem datums (`submitted_at`);
        # bez datuma "nesens" — viss, kas nav "accepted" (Zoonar u.c. dod tikai jaunākos)
        hashes = {(r[0], r[1]): r[2] for r in c.execute("SELECT agency, agency_item_id, h FROM thumb_hash WHERE h!=''")}
        for r in c.execute("SELECT agency, item_id, file_name, title, status, submitted_at FROM sub_status"):
            # test65: arī statusu rindām nospiedums (sīktēls no aģentūras saraksta)
            cand.append((r[0], r[1], r[2], r[3], hashes.get((r[0], r[1])), _date(r[5]), r[4] in ("review", "changes", "rejected", "other"), True))
        for r in c.execute("SELECT agency, agency_item_id, filename, title, uploaded FROM assets WHERE COALESCE(media,'') NOT IN ('other','month')"):
            cand.append((r[0], r[1], r[2], r[3], hashes.get((r[0], r[1])), (r[4] or "")[:10], False, False))
        dh_own = [(o["stem"], o["dh"]) for o in own if o["dh"]]
        links = {}
        # test51: Shutterstock saīsina garus nosaukumus vidū ("9bd2_DJI202....05.11-5.jpg") → atrod pēc sākuma un beigām
        alln = lambda x: re.sub(r"[^0-9a-z]", "", x.lower())
        keys = [(alln(x), x) for x in set(by_code) | set(by_orig)]
        for ag, iid, fn, ti, h, up, recent, is_sub in cand:
            k = _key(fn)
            if k and ("..." in k or "…" in k):
                pre, suf = re.split(r"\.{3,}|…", k, maxsplit=1)
                pre, suf = alln(pre), alln(suf)
                hit = {x for n, x in keys if len(pre) >= 4 and len(suf) >= 2 and n.startswith(pre) and n.endswith(suf)
                       and len(n) >= len(pre) + len(suf)}
                hit = {by_code.get(x) or (next(iter(by_orig[x])) if len(by_orig.get(x, ())) == 1 else x) for x in hit}
                k = _key(next(iter(hit))) if len(hit) == 1 else ""
            if k and (k in by_code or (re.match(r"^[0-9a-f]{4}_", k) and len(by_orig.get(_orig(k), ())) == 1)):
                # Vārdotāja kods aģentūras faila nosaukumā ("d738_2026-AKO_5548") — bilde gāja caur Vārdotāju
                links[(by_code.get(k) or next(iter(by_orig[_orig(k)])), ag, str(iid))] = "fails"
                continue
            votes: dict[str, list[str]] = {}
            for st in by_orig.get(_orig(k), ()) if k else ():
                votes.setdefault(st, []).append("nosaukums")
                # test51: tikai komplektu bildes (iesniegtas) → viennozīmīgs nosaukums ar gadu/numuru ("2025-NZ6_4548") pietiek
                if len(by_orig[_orig(k)]) == 1 and re.search(r"\d{4}", _orig(k)):
                    votes[st].append("unikāls")
            tt = _noed((ti or "").strip().lower()).rstrip("….").strip()
            if len(tt) >= 25:
                norm = lambda x: x.rstrip(" .…")
                exact = list({st for full, st in titles if norm(full) == norm(tt)})
                hit = exact or list({st for full, st in titles if len(tt) >= 40 and full.startswith(norm(tt))})
                if not hit:
                    # test64 (Chrome 2026-11-14): Magnific virsrakstam izmet pieturzīmes ("Dubrovniks", "redroofed",
                    # "Dubrovnik39s" no &#39;) → salīdzinām tikai burtus un ciparus
                    tw = _words(tt)
                    if len(tw) >= 25:
                        hit = list({st for full, st in titles_w if full == tw or (len(tw) >= 40 and full.startswith(tw))})
                if len(hit) == 1:                            # pilns garš AI virsraksts — praktiski unikāls → 2 balsis
                    # test45: arī aģentūras saīsināts (Zoonar ~70 zīmes) ≥60 zīmju sākums, ja viennozīmīgs
                    votes.setdefault(hit[0], []).extend(["virsraksts", "pilns"] if len(tt) >= 60 else ["virsraksts"])
            if h and dh_own and 10 <= bin(int(h, 16)).count("1") <= 54:
                ds = sorted((lookalike.dist(h, d), s) for s, d in dh_own)
                if ds[0][0] <= HASH_DIST and (len(ds) < 2 or ds[1][0] - ds[0][0] >= HASH_GAP):
                    votes.setdefault(ds[0][1], []).append("nospiedums")
                    # test65: iesniegumu statusu rinda (komplekta bilde, nesen iesniegta) + ļoti tuvs viennozīmīgs nospiedums → pietiek
                    if is_sub and ds[0][0] <= HASH_SOLO and (len(ds) < 2 or ds[1][0] - ds[0][0] >= HASH_GAP + 2):
                        votes[ds[0][1]].append("tuvs")
            best = [(st, v) for st, v in votes.items() if len(v) >= 2]
            if len(best) != 1:
                continue
            st, v = best[0]
            # test45: datums nezināms un "accepted" (Zoonar saraksts — jaunākās) → tikai, ja pati bilde uzņemta ≥ 2025 (ne veca)
            if not ((recent and not up) or (up and up >= since[st]) or (not up and taken.get(st, "") >= "2025-01-01")):
                continue                                     # aģentūrā agrāk, nekā Vārdotājs bildi sagatavoja — cita bilde
            links[(st, ag, str(iid))] = "+".join(v)
        c.execute("DELETE FROM own_links")
        c.executemany("INSERT OR REPLACE INTO own_links VALUES(?,?,?,?)", [(s, a, i, h) for (s, a, i), h in links.items()])
        c.commit()
        return len(links)


def table(series: str | None = None) -> dict:
    """Sērijas ar bilžu skaitu un katrā aģentūrā: pieņemtas / pārbaudē / noraidītas / jālabo / pārdotas (+ summa).
    Ar `series` — šīs sērijas bildes ar statusu katrā aģentūrā."""
    with db._lock:
        c = db.conn()
        ensure(c)
        imgs = [dict(r) for r in c.execute("SELECT stem, file, series, series_id, title, category, status, taken_at FROM own_images"
                                           + (" WHERE series_id=?" if series else ""), ((series,) if series else ()))]
        st = {}
        for r in c.execute("""SELECT l.stem, l.agency, s.status FROM own_links l
                              JOIN sub_status s ON s.agency=l.agency AND s.item_id=l.agency_item_id"""):
            st[(r[0], r[1])] = r[2]
        sold = {}
        for r in c.execute("""SELECT l.stem, l.agency, ROUND(SUM(x.amount_usd),2), SUM(x.cnt) FROM own_links l
                              JOIN sales x ON x.agency=l.agency AND x.agency_item_id=l.agency_item_id GROUP BY 1,2"""):
            sold[(r[0], r[1])] = (r[2] or 0, r[3] or 0)
        linked = {(r[0], r[1]) for r in c.execute("SELECT stem, agency FROM own_links")}
    found = {a for _, a in linked} | {a for _, a in st}
    conn = [a for a in (config.get("sales_agencies") or []) if isinstance(a, str)]
    ags = conn + sorted(found - set(conn))                   # test34: visas pieslēgtās aģentūras, ne tikai atrastās
    def cell(stem, ag):
        s = st.get((stem, ag)) or ("accepted" if (stem, ag) in sold else ("linked" if (stem, ag) in linked else None))
        e, n = sold.get((stem, ag), (0, 0))
        return {"s": s, "e": e, "n": n}
    if series:                                               # test35: atvērtajā sērijā tikai aģentūras ar šīs sērijas bildēm
        mine = {i["stem"] for i in imgs}
        ags = [a for a in ags if any((s, a) in linked or (s, a) in st for s in mine)]
        return {"agencies": ags, "rows": [{**i, "cells": {a: cell(i["stem"], a) for a in ags}} for i in sorted(imgs, key=lambda x: x["stem"])]}
    ser = {}
    for i in imgs:
        g = ser.setdefault(i["series_id"], {"series_id": i["series_id"], "name": i["series"], "n": 0, "taken": "", "ag": {}, "thumbs": []})
        g["n"] += 1
        if len(g["thumbs"]) < 3:
            g["thumbs"].append(i["stem"])
        g["taken"] = max(g["taken"], i["taken_at"] or "")
        for a in ags:
            x = cell(i["stem"], a)
            if x["s"]:
                z = g["ag"].setdefault(a, {"accepted": 0, "review": 0, "rejected": 0, "changes": 0, "linked": 0, "other": 0, "sold": 0, "e": 0.0})
                z[x["s"] if x["s"] in z else "other"] += 1
                if x["n"] or x["e"]:
                    z["sold"] += 1
                    z["e"] = round(z["e"] + x["e"], 2)
    # test63 (lietotājs 2026-11-14): komplekts iesniegts visā aģentūrā; ja tur ir ≥1 tā bilde, pārējās — "?" (iesniegtas, statuss nav nolasīts)
    # test65: Zoonar noraidītās savā lapā nerāda (tikai e-pastā; lietotājs 2026-11-14) — ja Zoonar pārbaudē 0, trūkstošās = noraidītas
    hide_rej = {a for a in HIDES_REJECTED if str(db.get_state(a, "sub_review") or "") == "0"}
    for g in ser.values():
        for a, z in g["ag"].items():
            k = sum(z[x] for x in ("accepted", "review", "rejected", "changes", "linked", "other"))
            z["unknown"] = max(0, g["n"] - k)
            if a in hide_rej and z["unknown"]:
                z["rej_inf"], z["unknown"] = z["unknown"], 0
    return {"agencies": ags, "series": sorted(ser.values(), key=lambda g: g["taken"], reverse=True), "dirs": shown_dirs()}


def export() -> dict:
    """`agenturas_bildes.json` Tirgotājam (dati §8c): manifestu bildes, kas atrastas aģentūrās, ar statusu katrā."""
    from core import config as cc, sync as _sync
    today = dt.date.today().isoformat()
    with db._lock:
        c = db.conn()
        ensure(c)
        imgs = {r[0]: {"stem": r[0], "orig_file": r[1] or "", "series_id": r[2] or "", "agencies": {}}
                for r in c.execute("SELECT stem, orig, series_id FROM own_images")}
        st = {(r[0], str(r[1])): (r[2], (r[3] or "")[:10]) for r in c.execute("SELECT agency, item_id, status, seen_at FROM sub_status")}
        links = c.execute("SELECT stem, agency, agency_item_id FROM own_links").fetchall()
    rank = {"accepted": 5, "review": 4, "changes": 3, "other": 2, "rejected": 1}
    for stem, ag, iid in links:
        im = imgs.get(stem)
        if not im:
            continue
        s, seen = st.get((ag, str(iid)), ("accepted", today))   # tikai pārdošanās / portfelī → pārdošanā
        old = im["agencies"].get(ag)
        if not old or rank.get(s or "other", 2) > rank.get(old["status"], 2):
            im["agencies"][ag] = {"status": s or "other", "item_id": str(iid), "seen": seen or today}
    out = [i for i in imgs.values() if i["agencies"]]
    d = {"format": 1, "updated": dt.datetime.now().isoformat(timespec="seconds"), "computer": _sync.computer(),
         "images": sorted(out, key=lambda i: i["stem"])}
    data = json.dumps(d, ensure_ascii=False).encode("utf-8")
    (cc.app_dir() / EXPORT).write_bytes(data)
    where = "datu mapē"
    try:
        from core import google
        if google.connected():
            fid = google.folder("Kopigi")
            old = next((f["id"] for f in google.list_files(fid) if f["name"] == EXPORT), None)
            google.put_bytes(fid, EXPORT, data, old)
            where += " un Google Drive Fotostokeris/Kopigi"
    except Exception as e:
        print("agenturas_bildes.json: Google Drive —", str(e)[:120])
    db.set_state("", "own_export", d["updated"])
    db.set_state("", "own_export_data", db.data_at())
    print(f"agenturas_bildes.json: {len(out)} bildes — {where}")
    return {"images": len(out), "where": where}


def start() -> None:
    """Fonā: ~3 min pēc palaišanas un tad ik 5 min — ja aģentūru dati mainījušies (un atjaunošana nenotiek) vai pienācis
    laiks pārbaudīt Drive manifestus → pārlasa, sasaista un atjauno `agenturas_bildes.json`."""
    import threading
    import time

    def loop():
        time.sleep(180)
        while True:
            try:
                from . import sync as _s
                if enabled() and not _s.active():
                    changed = (db.data_at() or "") != (db.get_state("", "own_export_data") or "")
                    last = db.get_state("", "own_pull") or ""
                    due = not last or (dt.datetime.now() - dt.datetime.fromisoformat(last)).total_seconds() >= PULL_EVERY
                    if changed or due:
                        scan()
            except Exception as e:
                print("manifesti fonā:", str(e)[:200])
            time.sleep(300)
    threading.Thread(target=loop, daemon=True, name="own").start()


def _zip_for(json_path: str) -> str:
    """Sīktēlu zip blakus manifestam. test38: ja sērija pārdēvēta, Drive zip var palikt ar veco nosaukumu
    (`<vecais>__<ID8>-sikteli.zip`) → meklē pēc ID8."""
    z = json_path[:-5] + "-sikteli.zip"
    if os.path.isfile(z) or "__" not in os.path.basename(json_path):
        return z
    id8 = os.path.basename(json_path)[:-5].rsplit("__", 1)[1]
    d = os.path.dirname(json_path)
    try:
        alt = sorted((f for f in os.listdir(d) if f.endswith("__" + id8 + "-sikteli.zip")),
                     key=lambda f: os.path.getmtime(os.path.join(d, f)), reverse=True)
    except OSError:
        alt = []
    return os.path.join(d, alt[0]) if alt else z


def thumb(stem: str) -> bytes | None:
    """test34: bildes sīktēls no manifesta `-sikteli.zip` (`<stem>.jpg`)."""
    with db._lock:
        r = db.conn().execute("SELECT src FROM own_images WHERE stem=?", (stem,)).fetchone()
    if not r or not r[0] or not str(r[0]).endswith(".json"):
        return None
    try:
        with zipfile.ZipFile(_zip_for(str(r[0]))) as zf:
            return zf.read(stem + ".jpg")
    except (OSError, KeyError, zipfile.BadZipFile):
        return None


def get_thumb(q: dict):
    from core import server as cs
    if q.get("t") != cs.TOKEN:
        return 403, b"forbidden", "text/plain", None
    b = thumb(str(q.get("stem") or ""))
    if not b:
        return 404, b"", "image/jpeg", None
    return 200, b, "image/jpeg", {"Cache-Control": "private, max-age=86400"}
