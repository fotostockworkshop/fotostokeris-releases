/* Magnific (bij. Freepik): contributor.magnific.com/xhr — ienākumi (EUR) un lejupielādes pa dienām */
async function collect() {
  if (location.hostname === "taxcenter.magnific.com") return taxcenter();
  if (location.hostname !== "contributor.magnific.com") throw LOGIN;
  const XH = { "X-Requested-With": "XMLHttpRequest" };
  const user = await getj("/xhr/user", XH);
  if (!user || user.success === false) throw LOGIN;
  const S = (fmt, a, b) => getj(`/xhr/stats?format=${fmt}&license=all&typeFile=all&dateStart=${a}&dateEnd=${b}`, XH);
  const ser = (j, re) => ((((j || {}).data || {}).series || []).find((s) => re.test(s.name)) || {}).data || [];

  /* mēneši ar ienākumiem */
  say("mēneši", 3);
  const mon = await S("monthly", "2015-01-01", today);
  const cats = ((mon || {}).data || {}).categories || [];
  const rev = ser(mon, /revenue/i);
  const months = [];
  for (let i = 0; i < rev.length; i++) {
    let m = cats[i] ? (String(cats[i]).match(/(\d{4})-(\d{2})/) || [])[0] : "";
    if (!m) {                                       // bez etiķetēm: pēdējā vērtība = šis mēnesis
      const d = new Date(+today.slice(0, 4), +today.slice(5, 7) - 1 - (rev.length - 1 - i), 15);
      m = `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
    }
    if (+rev[i] > 0) months.push(m);
  }
  const cur = today.slice(0, 7);
  if (!months.includes(cur)) months.push(cur);
  let list = months.sort().reverse();
  if (OPTS.mode !== "full") list = list.filter((m) => m >= OPTS.since.slice(0, 7));

  for (let i = 0; i < list.length; i++) {
    const m = list[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(m, 5 + Math.round((i / list.length) * 90));
    const end = monthEnd(y, mo) < today ? monthEnd(y, mo) : today;
    const d = await S("daily", `${m}-01`, end);
    const dc = ((d || {}).data || {}).categories || [];
    const r = ser(d, /revenue/i), prem = ser(d, /premium/i), free = ser(d, /free/i);
    const days = dc.map((day, k) => ({ day: pdate(day), cat: "premium", e: +r[k] || 0, n: (+prem[k] || 0) + (+free[k] || 0) }))
      .filter((x) => x.day);
    await send("days", { start: `${m}-01`, end, currency: "EUR", days });
    await sleep(200);
  }
  const PUB = (t) => { const m = String(t || "").match(/Published\s*(\d[\d,]*)/i); return m ? numOf(m[1]) : null; };
  if (OPTS.sub_due) { try { await mgStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["upload/count", async () => { const j = await sJson("/xhr/upload/count?assetType=photo", MGH); const n = j && j.data && +j.data.published; return n > 0 ? n : null; }],   // test63
    ["izvēlne (Published)", async () => {
      let n = PUB(document.body && document.body.innerText);
      if (n) return n;
      /* sānu izvēlnē "Files" jāatver — zem tās "Published N" (lietotājs 2026-10-30); spiežam tikai izvēršanas pogu, ne saiti */
      if (clickText(document, /^files$/i, "button, [aria-expanded], [role=button], summary")) {
        for (let i = 0; i < 10 && !n; i++) { await sleep(400); n = PUB(document.body && document.body.innerText); }
        if (n) return n;
      }
      apiSeen(window, /xhr|api/i, 25);                 // avota atklāšanai (kur lapa ņem "Published")
      for (const p of ["/files", "/files/published", "/resources"]) { const m = await framed(p, PUB, 12000); if (m) return m; }
      return null;
    }],
    ["user", async () => { const n = countKey(user, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: user atslēgas: " + keysOf(user && (user.data || user))); return n; }],
    ["resources/data", () => portJson("/xhr/resources/data", XH)],
    ["resources", () => portJson("/xhr/resources?page=1&limit=1", XH)],
    ["stats/resources", () => portJson("/xhr/stats/resources", XH)],
  ]);
  /* izmaksas — atsevišķā vietnē taxcenter.magnific.com (lietotājs 2026-10-30): pāriet uz turieni, tur skripts turpina */
  /* 0.3.1: rēķina apstiprināšanas laikā (4.–9. datums) taxcenter pārbaudām katrā atjaunošanā (Pending Invoices) */
  const dom = new Date().getDate();
  if (OPTS.payouts_full || OPTS.pay_due || (dom >= 4 && dom <= 9)) {
    try { sessionStorage.setItem("__vdMagTax", String(Date.now())); } catch (_) { /* */ }
    say("izmaksas", 97);
    location.href = "https://taxcenter.magnific.com/";
    return { navigated: true };
  }
  return { months: list.length };
}

/* Tax center → Invoices: "Paid Invoices" (datums | numurs | summa €) un "Pending Invoices" */
async function taxcenter() {
  const RE = /(\d{4}-\d{2}-\d{2})\s+(FR-[\w.-]+)\s+([\d.,]+)\s*€/g;
  let t = "";
  for (let i = 0; i < 40; i++) { t = (document.body && document.body.innerText) || ""; if (RE.test(t) || /no pending invoices/i.test(t) && /paid invoices/i.test(t) && i > 10) break; RE.lastIndex = 0; await sleep(500); }
  RE.lastIndex = 0;
  const rows = [], seen = new Set();
  /* 2026-11-03 (lietotājs): gaidošais rēķins ("Pending Invoices") NAV izmaksa — izmaksu vēsturē tikai "Paid Invoices" daļa */
  const paidTxt = () => { const s = (document.body && document.body.innerText) || ""; const k = s.search(/Paid Invoices/i); return k >= 0 ? s.slice(k) : s; };
  const grab = () => { let m; const s = paidTxt(); const g = new RegExp(RE.source, "g"); let n = 0;
    while ((m = g.exec(s))) { if (seen.has(m[2])) continue; seen.add(m[2]); n++; rows.push({ date: m[1], amount: money(m[3]), currency: "EUR", ref: m[2] }); } return n; };
  grab();
  /* lappuses: "nākamā" poga, ja ir */
  for (let pg = 2; pg <= 20; pg++) {
    const nx = [...document.querySelectorAll("button, a, [role=button]")].find((e) => !e.disabled && e.getAttribute("aria-disabled") !== "true" &&
      (/next/i.test(e.getAttribute("aria-label") || "") || /^\s*(›|>|»|next)\s*$/i.test(e.innerText || "")));
    if (!nx) break;
    nx.click(); await sleep(1500);
    if (!grab()) break;
  }
  /* 0.3.1: tikai "Pending Invoices" daļa (līdz "Paid Invoices"); ja rēķina nav — 0 (citādi vecā summa paliktu) */
  const all = (document.body && document.body.innerText) || "";
  const pi = all.search(/Pending Invoices/i), pp = all.search(/Paid Invoices/i);
  const pendTxt = pi >= 0 ? all.slice(pi, pp > pi ? pp : pi + 600) : "";
  const pend = pendTxt.match(/([\d.,]+)\s*€/);
  if (pi >= 0) {
    const v = pend && !/no pending invoices/i.test(pendTxt) ? money(pend[1]) : 0;
    await sendPayInfo({ unpaid: v, currency: "EUR" });
    B.log(AG, "izmaksas: Pending Invoices — " + (v ? v + " € (jāapstiprina)" : "nav"));
  }
  if (!rows.length) B.log(AG, "izmaksas: Tax center — rēķini nav atrasti; teksts: " + ((document.body && document.body.innerText) || "").replace(/\S+@\S+/g, "…").replace(/\d{6,}/g, "N").slice(0, 200));
  /* 2026-11-03: "Paid Invoices" ir lapās (1 of 2) — ja visas lapas nenolasījām, "full" izdzēstu vecos rēķinus. Tāpēc aizstājam
     tikai no vecākā nolasītā datuma (tā pazūd arī agrāk kļūdaini ierakstītais gaidošais rēķins 2026-11-01). */
  rows.sort((a, b) => (a.date < b.date ? 1 : -1));
  await sendPayouts(rows, { full: false, start: rows.length ? rows[rows.length - 1].date : undefined });
  await send("pay_checked", {});
  return { payouts: rows.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06), contributor.magnific.com:
   /files-waiting/1?sort=recent — Under revision; /files-rejected/1?sort=recent — kartītes: virsraksts, iemesls
   ("Quality standards", "Trademark/Copyright"), datums (redzamas 90 dienas); /catalog/published-files/1?sort=recent —
   pieņemtās (datums; ID saitē). Faila nosaukumu lapas nerāda — ja lapas API to dod, ņemam no turienes (subLists). */
/* test63 (lietotājs 2026-11-14, Chrome): jaunā lapa contributor.magnific.com/uploads/photo/<cilne> — API /xhr/upload/<cilne>?assetType=photo
   &sort=newest&limit=100[&cursor=…] (meta.next_cursor); vajag X-Requested-With + Content-Type json (citādi 400). Cilnes: published (virsraksts,
   bez faila nosaukuma), in-review, pending, rejected (base_path = faila nosaukums, rejections[].type). unpublished (lietotāja noņemtās) — nelasām. */
const MGH = { "X-Requested-With": "XMLHttpRequest", "Content-Type": "application/json", Accept: "application/json, text/plain, */*" };
async function mgUpload() {
  const cut = new Date(Date.now() - 400 * 864e5).toISOString().slice(0, 10);   // publicētās — tikai pēdējie ~13 mēn. (portfelī 14k+)
  const out = new Map();
  let any = false;
  for (const [tab, raw, maxp] of [["rejected", "Rejected", 20], ["in-review", "In review", 20], ["pending", "Pending", 20], ["published", "Published", 30]]) {
    let cur = "", n = 0;
    for (let pg = 0; pg < maxp; pg++) {
      const j = await sJson(`/xhr/upload/${tab}?assetType=photo&sort=newest&limit=100` + (cur ? "&cursor=" + encodeURIComponent(cur) : ""), MGH);
      if (!j || !Array.isArray(j.data)) { if (!pg) B.log(AG, `statusi: /xhr/upload/${tab} — ${j ? "atslēgas: " + Object.keys(j).slice(0, 10).join(",") : "nav JSON"}`); break; }
      any = true;
      let old = false;
      for (const o of j.data) {
        const sub = String(o.submitted_at || o.uploaded_at || o.published_at || "").slice(0, 10);
        if (tab === "published" && sub && sub < cut) { old = true; break; }
        const f = (o.base_path || (o.files && o.files[0] && o.files[0].path) || "").split("/").pop() || "";
        const why = (o.rejections || []).map((x) => String(x.type || "").replace(/_/g, " ").toLowerCase()).filter(Boolean).join(", ");
        const id = String(o.published_resource_id || o.id || "");
        if (!id) continue;
        out.set(id, { id, file: f && !/\.\w{3,4}$/.test(f) ? f + ".jpg" : f, title: (o.title || "").slice(0, 250), tags: Array.isArray(o.tags) ? o.tags.join(", ") : "",
          submitted: sub, status: raw === "Rejected" && why ? "Rejected: " + why : raw, thumb: String(o.thumbnail_url || "") });   // test65: sīktēls sasaistei
        n++;
      }
      cur = j.meta && j.meta.next_cursor;
      if (old || !cur || !j.data.length) break;
      await sleep(250);
    }
    B.log(AG, `statusi: ${tab} — ${n}`);
  }
  return any ? [...out.values()] : null;
}

async function mgStatus() {
  const rows = await mgUpload();
  if (rows) { if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 }); return; }
  /* vecā lapa (līdz 2026-11): */
  /* 2026-11-06 (žurnāls): lapa ielādē /xhr/item/list-rejected?limit=40&page=1&sort=recent — ņemam tieši no turienes */
  const XH = { "X-Requested-With": "XMLHttpRequest" };
  const got = new Map();
  /* test45: publicētās — /xhr/resource/published (id, title, date; Chrome 2026-11-11); DOM sarakstā virsraksta nebija */
  for (const [u, raw] of [["/xhr/item/list-rejected?limit=40&page=1&sort=recent", "Rejected"], ["/xhr/item/list-revision?limit=40&page=1&sort=recent", "Under revision"],
                          ["/xhr/resource/published?limit=40&page=1", "Published"], ["/xhr/resource/published?limit=40&page=2", "Published"]]) {
    const j = await sJson(u, XH);
    const a = j && (sBest(j) || (Array.isArray(j.items) ? j.items : Array.isArray(j.data) ? j.data : null));
    if (!a) { B.log(AG, `statusi: ${u.split("?")[0]} — ${j ? "atslēgas: " + Object.keys(j).slice(0, 15).join(",") : "nav JSON"}`); continue; }
    if (a[0]) B.log(AG, `statusi: ${u.split("?")[0]} — ${a.length}; lauki: ${Object.keys(a[0]).slice(0, 25).join(", ")}`);
    for (const o of a) {
      const r = { id: sVal(o, SK.id, 0), file: sVal(o, SK.file), title: (sVal(o, /^(title|name|description)$/i) || "").slice(0, 250),
        submitted: (sVal(o, /date|created|updated/i) || "").slice(0, 10), status: raw };
      const why = sVal(o, /reason|reject|motive|cause/i);
      if (why && raw === "Rejected" && !/^\d+$/.test(why)) r.status = "Rejected: " + why;
      if (r.id) got.set(r.id, r);
    }
  }
  if (got.size) await send("sub_items", { rows: [...got.values()], part: 1, parts: 1 });
  const REASONS = /^(Quality standards|Trademark\/Copyright|Similar content|Metadata|Technical issues?|Legal|Model release|Property release|Duplicated?|Not commercial|Editorial|Composition|Focus|Noise)$/i;
  const dom = async (doc, raw) => {
    const out = new Map();
    if (/Rejected/i.test(raw)) {
      for (const b of doc.querySelectorAll("a, span, div, button")) {
        const why = (b.innerText || "").trim();
        if (!REASONS.test(why) || b.children.length > 2) continue;
        let card = b; for (let i = 0; i < 6 && card.parentElement && !card.querySelector("img"); i++) card = card.parentElement;
        const ct = (card.innerText || "").split("\n").map((x) => x.trim()).filter(Boolean);
        const title = ct.find((x) => x.length > 25 && x !== why) || "";
        const date = ct.find((x) => /^[A-Z][a-z]{2} \d{1,2}, \d{4}$/.test(x)) || "";
        const img = card.querySelector("img"), src = img ? img.src || "" : "";
        const id = (src.match(/\/(\d{6,12})[._-]/) || [])[1] || ("t:" + title.slice(0, 60));
        if (!title || out.has(id)) continue;
        out.set(id, { id, file: "", title: title.slice(0, 250), submitted: pdate(date) || "", status: "Rejected: " + why });
      }
    } else {
      for (const a of doc.querySelectorAll("a[href]")) {
        const id = (a.getAttribute("href").match(/_(\d{6,12})\.htm|\/(\d{6,12})(?:[/?#]|$)/) || []).slice(1).find(Boolean);
        if (!id || out.has(id)) continue;
        let card = a; for (let i = 0; i < 5 && card.parentElement && !/\d{4}/.test(card.innerText || ""); i++) card = card.parentElement;
        const date = ((card.innerText || "").match(/[A-Z][a-z]{2} \d{1,2}, \d{4}/) || [])[0] || "";
        out.set(id, { id, file: "", title: "", submitted: pdate(date) || "", status: raw });
      }
    }
    return [...out.values()];
  };
  await subLists([...(got.size ? [] : [{ path: "/files-waiting/1?sort=recent", raw: "Under revision", max: 3 },
                  { path: "/files-rejected/1?sort=recent", raw: "Rejected", max: 3 }]),
                  ...([...got.values()].some((r) => r.status === "Published") ? [] : [{ path: "/catalog/published-files/1?sort=recent", raw: "Published", max: 2 }])], { dom });
}
