"""Produkta palaišana: žurnāls, serveris, logs (pywebview vai Edge/Chrome "lietotnes" logs, vai pārlūks).

Parametri: --browser (parastā pārlūkā), --no-window (tikai serveris).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

from . import app as _app
from . import config, server


def log_to_file() -> bool:
    """Ja nav konsoles (Windows pythonw) vai palaists no run_mac.command (<SLUG>_LOG=1) — kļūdas rakstām log.txt."""
    env = _app.current().slug.upper() + "_LOG"
    if sys.stdout is None or sys.stderr is None or os.environ.get(env) == "1":
        config.setup_log()
        return True
    return False


def mac_icon() -> None:
    """Mac: logu atver Python, tāpēc Dock rāda Python ikonu — nomainām uz produkta ikonu (<programma>/mac/<Slug>.icns).
    pywebview uz Mac jau lieto pyobjc (AppKit), papildu bibliotēkas nevajag."""
    if not config.IS_MAC:
        return
    try:
        a = _app.current()
        p = a.web_dir.resolve().parent / "mac" / f"{a.slug}.icns"
        if not p.exists():
            return
        from AppKit import NSApplication, NSImage   # type: ignore
        try:                                         # izvēlnes joslā "Analītiķis", nevis "Python"
            from Foundation import NSBundle          # type: ignore
            info = NSBundle.mainBundle().localizedInfoDictionary() or NSBundle.mainBundle().infoDictionary()
            if info is not None:
                info["CFBundleName"] = a.name
        except Exception:
            pass
        img = NSImage.alloc().initWithContentsOfFile_(str(p))
        if img is not None:
            NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception as e:  # nav AppKit u.c. — ikona paliek Python
        print("Dock ikona:", e)


def mac_dock_hidden() -> None:
    """Mac: palīgprocess (aģentūru logi) bez savas Dock ikonas — logi tik un tā parādās, kad vajag ielogoties."""
    if not config.IS_MAC:
        return
    try:
        from AppKit import NSApplication   # type: ignore
        NSApplication.sharedApplication().setActivationPolicy_(1)    # NSApplicationActivationPolicyAccessory
    except Exception as e:
        print("Dock (palīgprocess):", e)


def app_mode_browser(url: str) -> bool:
    """Mēģina atvērt Edge vai Chrome kā atsevišķu lietotnes logu (bez adreses joslas)."""
    slug = _app.current().slug
    cands = []
    if sys.platform.startswith("win"):
        pf = [os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("PROGRAMFILES", ""),
              os.environ.get("LOCALAPPDATA", "")]
        for base in pf:
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    elif sys.platform == "darwin":
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]
    else:
        for n in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge"):
            w = shutil.which(n)
            if w:
                cands.append(w)
    profile = Path.home() / (f".{slug.lower()}-browser" if not sys.platform.startswith("win")
                             else f"AppData/Local/{slug}/browser")
    for c in cands:
        if c and os.path.isfile(c):
            try:
                # ja Edge/Chrome ar šo profilu jau darbojas, process uzreiz beidzas (logu atver vecais) —
                # tad server.window_alive() ir False un paļaujamies uz lapas "ping"
                server.state["window_proc"] = subprocess.Popen(
                    [c, f"--app={url}", f"--user-data-dir={profile}",
                     "--window-size=1440,920", "--no-first-run", "--no-default-browser-check"])
                return True
            except OSError:
                continue
    return False


def run(args: list[str], logged: bool, start=None):
    """Galvenais process: serveris + logs. `logged` — vai žurnāls jau novirzīts uz failu;
    `start` — moduļa servera palaišana (reģistrē moduļa API), noklusējumā core.server.start."""
    a = _app.current()
    srv, url = (start or server.start)()            # aptur veco instanci — tagad log.txt var droši sākt no jauna
    if logged:
        config.setup_log(rotate=True)
    print(f"{a.name} {a.version} darbojas: {url}")

    if "--no-window" in args:
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            server.shutdown()
        return

    # Uz Windows galvenais logs ir Edge/Chrome lietotnes logs; uz Mac — pywebview logs, ja ir.
    use_webview = (not config.IS_WIN) or bool(a.webview_main())
    if "--browser" not in args and use_webview:
        try:
            import webview  # pywebview
            webview.create_window(a.name, url, width=1440, height=920, min_size=(1000, 680))
            mac_icon()
            try:
                webview.start(icon=str(a.icon)) if a.icon and a.icon.exists() else webview.start()
            except TypeError:
                webview.start()
            server.shutdown()
            return
        except Exception as e:  # nav pywebview vai neizdevās
            print("pywebview nav pieejams, atveru pārlūkā:", e)

    if os.environ.pop("FOTOSTOKERIS_RESTARTED", "") == "1" and config.IS_WIN and "--browser" not in args:
        # pēc atjaunināšanas: vecais Edge/Chrome logs paliek atvērts un pieslēdzas jaunajai versijai pats
        print("palaists pēc atjaunināšanas — logu neatveru no jauna")
    elif "--browser" in args or not app_mode_browser(url):
        webbrowser.open(url)
    server.idle_watch(5)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.shutdown()
