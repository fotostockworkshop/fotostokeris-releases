/* Bigstock: www.bigstockphoto.com/account/commissions/ — lejupielāžu saraksts ar lapām (tabula lapā vai apakšlapā) */
async function collect() {
  if (!/(^|\.)bigstockphoto\.com$/.test(location.hostname)) throw LOGIN;
  /* Tikai "Image Earnings" tabula (Date · Time · Description · Type · Amount). Pilnā periodā lapā virs tās ir
     vēl tabula ar izmaksām un to atgriešanām (−$156 / +$156) — tās nav pārdošanas. */
  function parse(doc) {
    for (const t of doc.querySelectorAll("table")) {
      /* tikai šīs tabulas rindas (t.rows) — pārdošanas rindā var būt iekšēja tabula (vēsture), tās rindas nav pārdošanas */
      const own = [...t.rows];
      const head = own.find((tr) => /Date/.test(txt(tr)) && /Amount/.test(txt(tr)));
      if (!head || t.parentElement && t.parentElement.closest("table")) continue;   // iekšējās tabulas izlaižam
      const h = [...head.cells].map((c) => txt(c).toLowerCase());
      const ix = (n) => h.indexOf(n);
      if (ix("time") < 0 || ix("type") < 0 || ix("description") < 0) continue;
      const out = [];
      /* Vienas dienas rindām datums (un laiks) var būt tikai pirmajā rindā (rowspan) — tad rindā ir mazāk šūnu:
         līdzinām pa labi (Amount vienmēr pēdējā) un datumu ņemam no iepriekšējās rindas. */
      /* Rinda ar mazāk šūnām ir pārdošana TIKAI tad, ja iepriekšējās rindas datuma šūna to aptver (rowspan).
         Citas īsās rindas (piem. "History" — datums | summa | …) nav pārdošanas (2026-10-29: 1756 → 1708). */
      let lastDay = "", lastTime = "", span = 0, skipped = 0, short = 0, sample = "";
      for (const tr of own) {
        if (tr === head) continue;
        let v = [...tr.cells];
        if (v.length < 2 || tr.querySelector("th")) continue;
        let day;
        if (v.length >= h.length) {
          const dc = v[ix("date")], dt = txt(dc);
          day = pdate(dt);
          if (!dt && lastDay) day = lastDay;          // tukšs datums = tās pašas dienas nākamā pārdošana (2026-10-29)
          else {
            span = day ? Math.max(0, (dc.rowSpan || 1) - 1) : 0;
            if (day) lastDay = day;
          }
          if (day && v[ix("time")] && txt(v[ix("time")])) lastTime = txt(v[ix("time")]);
        } else if (span > 0 && lastDay) {
          span--;
          day = lastDay;
          v = Array(h.length - v.length).fill(null).concat(v);
        } else {
          short++;
          if (!sample) sample = v.slice(0, 3).map(txt).join(" | ").slice(0, 80);
          continue;
        }
        if (!day) { skipped++; continue; }
        /* bildes numurs: ?id=123 vai /image-123… saitē; sīktēls — rindas attēls */
        let id = "";
        for (const a of tr.querySelectorAll("a[href]")) {
          const m = (a.getAttribute("href") || "").match(/[?&]id=(\d+)|\/image-(\d+)/);
          if (m) { id = m[1] || m[2]; break; }
        }
        const img = tr.querySelector("img");
        const th = img ? (img.getAttribute("src") || img.getAttribute("data-src") || "") : "";
        const cell = (n) => (v[ix(n)] ? txt(v[ix(n)]) : "");
        out.push({ day, ts: day + " " + lastTime, id, title: cell("description"), license: cell("type"),
          amount: money(cell("amount")), cnt: 1, kind: "sale", url: id ? `https://www.bigstockphoto.com/image-${id}` : "",
          thumb: th ? new URL(th, location.href).href : "" });
      }
      if (skipped || short) B.log(AG, `izlaistas rindas: ${short} īsās (ne pārdošanas, piem. "${sample}"), ${skipped} bez datuma`);
      return out;
    }
    return null;
  }
  /* Ielogots = pārdošanu lapa paliek /account/… (citādi Bigstock aizved uz /login vai sākumlapu, kurā ir
     paslēpta ielogošanās forma — tāpēc paroles lauku vien par pazīmi neņemam). */
  const isAcc = (doc) => /^\/account\//.test(new URL(doc.__url || location.href).pathname);
  const home = await getdoc("/account/commissions/");
  if (!isAcc(home)) { B.log(AG, "commissions → " + new URL(home.__url).pathname); throw LOGIN; }
  /* tabula var būt pašā lapā vai apakšlapā (agrāk /account/commissions/downloads/) */
  let base = "/account/commissions/", r = parse(home);
  if (!r) {
    /* sānu izvēlne: Commissions → Payment History · Image Earnings · Image Statistics · Tax Center.
       Pārdošanas = "Image Earnings" (vai vecais "Downloads"); izmaksas/nodokļus/statistiku neņemam. */
    const SKIP = /payment|payout|tax|statistic/i;
    const all = [...home.querySelectorAll("a[href]")].map((a) => ({ t: txt(a), p: new URL(a.getAttribute("href"), location.href) }))
      .filter((x) => x.p.host === location.host && /^\/account\//.test(x.p.pathname));
    const want = all.filter((x) => /image earnings|earnings|downloads/i.test(x.t) && !SKIP.test(x.t + x.p.pathname)).map((x) => x.p.pathname);
    const other = all.filter((x) => /commission/i.test(x.p.pathname) && !SKIP.test(x.t + x.p.pathname)).map((x) => x.p.pathname);
    B.log(AG, "konta izvēlne: " + all.filter((x) => /commission|earning/i.test(x.t + x.p.pathname)).slice(0, 10).map((x) => `${x.t} ${x.p.pathname}`).join(" · "));
    const cands = [...new Set([...want, "/account/commissions/downloads/", ...other])].filter((p) => p !== base).slice(0, 8);
    for (const p of cands) {
      const d = await getdoc(p);
      if (!isAcc(d)) continue;
      const x = parse(d);
      if (x) { base = new URL(d.__url).pathname; r = x; break; }
    }
  }
  if (!r) {
    const heads = [...home.querySelectorAll("table tr:first-child, thead tr")].slice(0, 3).map((tr) => txt(tr).slice(0, 80));
    B.log(AG, "tabula nav atrasta; virsraksti: " + JSON.stringify(heads));
    throw new Error("Bigstock: pārdošanu tabula nav atrasta");
  }
  B.log(AG, "pārdošanas lapā " + base);
  /* Izpētei (bez lietotāja datiem): lapas filtri un lappušu saites */
  let doc = await getdoc(base);
  const forms = [...doc.querySelectorAll("form select, form input")].filter((e) => e.name && e.type !== "hidden" && e.type !== "password")
    .map((e) => e.tagName === "SELECT" ? `${e.name}[${[...e.options].slice(0, 6).map((o) => o.value).join("|")}${e.options.length > 6 ? "|…" : ""}]` : `${e.name}=${e.type}`);
  const pager = [...doc.querySelectorAll("a[href]")].filter((a) => /^(\d+|next|›|»|>|older|nākam)/i.test(txt(a)) || a.rel === "next")
    .slice(0, 8).map((a) => `${txt(a)}→${new URL(a.getAttribute("href"), location.href).pathname}${new URL(a.getAttribute("href"), location.href).search}`);
  B.log(AG, `filtri: ${forms.join(", ") || "–"} · lappuses: ${pager.join(" ") || "–"}`);
  /* Periods: Bigstock pēc noklusējuma rāda pēdējās 30 dienas. Saitē "Last Month" (vai "This Month") ir perioda
     parametri — tajos datumus aizstājam ar vajadzīgo periodu tajā pašā formātā; "160" — rindas lappusē. */
  function rangeUrl(d) {
    const links = [...d.querySelectorAll("a[href]")];
    const lm = links.find((x) => /last\s*month/i.test(txt(x))) || links.find((x) => /this\s*month/i.test(txt(x)));
    const per = links.find((x) => txt(x) === "160") || links.find((x) => txt(x) === "80");
    if (!lm) { B.log(AG, "perioda saites nav atrastas"); return null; }
    const u = new URL(lm.getAttribute("href"), location.href);
    if (per) for (const [k, v] of new URL(per.getAttribute("href"), location.href).searchParams) if (!u.searchParams.has(k)) u.searchParams.set(k, v);
    const from = OPTS.mode === "full" ? "2005-01-01" : OPTS.since, to = today;
    const fmt = (v, iso) => {
      const [y, m, dd] = iso.split("-");
      if (/^\d{4}-\d{2}-\d{2}$/.test(v)) return iso;
      if (/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(v)) return `${m}/${dd}/${y}`;
      if (/^\d{8}$/.test(v)) return y + m + dd;
      if (/^\d{10}$/.test(v)) return String(Math.floor(new Date(iso + "T00:00:00Z").getTime() / 1000));
      return null;
    };
    const dates = [...u.searchParams].filter(([, v]) => fmt(v, "2000-01-01") !== null);
    B.log(AG, `perioda saite: ${u.pathname}?${[...u.searchParams.keys()].join("&")} (datumi: ${dates.map(([k]) => k).join(", ") || "nav"})`);
    if (dates.length < 2) return null;
    const isEnd = (k) => /end|to|until|finish|stop/i.test(k);
    const ordered = dates.some(([k]) => isEnd(k)) ? dates : dates.map((x, i) => [x[0], x[1], i]);
    ordered.forEach(([k, v], i) => u.searchParams.set(k, fmt(v, (dates.some(([kk]) => isEnd(kk)) ? isEnd(k) : i > 0) ? to : from)));
    return u.href;
  }
  /* Forma ar date[from] / date[to] / pg (Bigstock 2026-10: "Last Month" u.c. ir JavaScript saites) */
  const DF = (n) => doc.querySelector(`input[name="${n}"]`);
  let formUrl = null, total = 0;
  if (DF("date[from]") && DF("date[to]")) {
    const form = DF("date[from]").form;
    const sample = DF("date[from]").value || DF("date[to]").value || DF("date[from]").placeholder || "";
    const MONS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    const fmt = (iso) => {
      const [y, m, d] = iso.split("-");
      if (/^\d{4}-\d{2}-\d{2}$/.test(sample)) return iso;
      if (/^[A-Za-z]{3}\s+\d{1,2},\s*\d{4}$/.test(sample)) return `${MONS[+m - 1]} ${+d}, ${y}`;
      if (/^\d{1,2}\.\d{1,2}\.\d{4}$/.test(sample)) return `${d}.${m}.${y}`;
      return `${m}/${d}/${y}`;                                 // noklusējums — ASV formāts
    };
    const u = new URL((form && form.getAttribute("action")) || base, location.href);
    if (form) for (const [k, v] of new FormData(form)) if (typeof v === "string" && !/password/i.test(k)) u.searchParams.set(k, v);
    u.searchParams.set("date[from]", fmt(OPTS.mode === "full" ? "2005-01-01" : OPTS.since));
    u.searchParams.set("date[to]", fmt(today));
    formUrl = (pg) => { u.searchParams.set("pg", String(pg)); return u.href; };
    B.log(AG, `perioda forma: paraugs "${sample}" → ${u.searchParams.get("date[from]")} – ${u.searchParams.get("date[to]")}`);
    const d2 = await getdoc(formUrl(1));
    if (isAcc(d2) && parse(d2)) {
      doc = d2;
      const sh = txt(d2.body).match(/Showing\s+[\d,]+\s*-\s*[\d,]+\s+of\s+([\d,]+)/i);
      if (sh) total = +sh[1].replace(/,/g, "");
      B.log(AG, `periods: ${OPTS.mode === "full" ? "visa vēsture" : "kopš " + OPTS.since}${sh ? " · kopā " + sh[1] : ""}`);
    } else formUrl = null;
  } else {
    const ru = rangeUrl(doc);
    if (ru) {
      const d2 = await getdoc(ru);
      if (isAcc(d2) && parse(d2)) doc = d2;
    }
  }
  /* Lappuses: sekojam saitei "Next"/nākamajam numuram; ja tādas nav — mēģinām ?pg=N */
  function nextUrl(d, pg) {
    const links = [...d.querySelectorAll("a[href]")];
    const a = links.find((x) => x.rel === "next" || /^(next|›|»|>|older)/i.test(txt(x))) || links.find((x) => txt(x) === String(pg + 1));
    return a ? new URL(a.getAttribute("href"), location.href).href : null;
  }
  const since = OPTS.mode === "full" ? "0000-00-00" : OPTS.since;
  let rows = [], url = doc.__url || base;
  const seen = new Set(), visited = new Set([new URL(url, location.href).href]);
  const linked = !!nextUrl(doc, 1);            // lapā ir "Next" / numuru saites — tad ?pg= neminam
  r = parse(doc) || [];
  let raw = 0;
  for (let pg = 1; pg < 500; pg++) {
    const sig = r.slice(0, 5).map((x) => x.ts + x.id + x.amount + x.title).join() + r.length;
    if (!r.length || seen.has(sig)) {            // tukša vai jau redzēta lappuse
      B.log(AG, `lappuse ${pg}: ${r.length ? "atkārtojas" : "tukša"} — beidzu (nolasīts ${raw}${total ? " no " + total : ""})`);
      break;
    }
    if (pg % 5 === 1) B.log(AG, `lappuse ${pg}: ${r.length} rindas, ${r[0].day} … ${r[r.length - 1].day}`);
    seen.add(sig);
    raw += r.length;
    say(`lapa ${pg}`, Math.min(90, pg));
    rows = rows.concat(r.filter((x) => x.day >= since));
    if (r[r.length - 1].day < since) break;
    if (total && raw >= total) { B.log(AG, `visas ${raw} nolasītas (${pg} lappuses)`); break; }
    const nx = formUrl ? formUrl(pg + 1) : linked ? nextUrl(doc, pg)
      : new URL(`${base}${base.includes("?") ? "&" : "?"}pg=${pg + 1}`, location.href).href;
    if (!nx || visited.has(nx)) break;
    visited.add(nx);
    url = nx;
    await sleep(250);
    doc = await getdoc(url);
    r = parse(doc) || [];
  }
  B.log(AG, `nolasītas ${rows.length} pārdošanas`);
  /* Sīktēli: tabulā to nav → bildes publiskās lapas og:image (tas pats domēns), ne vairāk kā N reizē */
  /* sīktēli lēni (bilžu lapa ~1 s): tikai bildēm, kurām sīktēla vēl nav (OPTS.thumbed); pilnajā ielādē ≤400, citādi ≤40 */
  const have = new Set(OPTS.thumbed || []);
  const ids = [...new Set(rows.filter((x) => x.id && !x.thumb && !have.has(String(x.id))).map((x) => x.id))].slice(0, OPTS.mode === "full" ? 400 : 40);
  const th = [];
  for (let i = 0; i < ids.length; i++) {
    say(`sīktēli ${i + 1}/${ids.length}`, 90 + Math.round((i / ids.length) * 8));
    try {
      const d = await getdoc(`/image-${ids[i]}`);
      const m = d.querySelector('meta[property="og:image"], meta[name="twitter:image"]');
      const src = m && m.getAttribute("content");
      if (src) th.push({ id: ids[i], thumb: new URL(src, location.href).href });
    } catch (e) { if (e && e.login) { B.log(AG, "bilžu lapas uz laiku atteiktas — pārējie sīktēli nākamreiz"); break; } }
    await sleep(400);                            // Bigstock atsaka (403), ja prasa par ātru
  }
  if (th.length) await send("thumbs", { rows: th });
  B.log(AG, `sīktēli: ${th.length}/${ids.length}`);
  const start = OPTS.mode === "full" ? (rows.length ? rows.reduce((m, x) => (x.day < m ? x.day : m), today) : today) : since;
  await sendRows(rows, { start, end: today });
  /* izmaksas: galvenē "Hi, … $2.39" = neizmaksātais; vēsture — Commissions → Payment History */
  await payoutsSafe(async () => {
    const hi = txt(home.body).match(/Hi,[^$]{0,40}\$\s*([\d,.]+)/);
    if (hi) await sendPayInfo({ unpaid: money(hi[1]), currency: "USD" });
    const ph = await getdoc("/account/commissions/payment-history/");
    /* test44: kolonnas Date | Gross | … | Net | Payout Method — summa no "Net" (vecākās lapās "Amount") */
    let t = tableObjs(ph, [/date/i, /\bnet\b|amount/i]) || [];
    /* 2026-11-07 (žurnāls): virsraksti ir, rindu nav — tās ielādē lapas skripts → lasām rāmī */
    if (!t.length && ph.querySelectorAll("table").length) {
      const ft = await framed("/account/commissions/payment-history/", (_, d) => { const o = tableObjs(d, [/date/i, /\bnet\b|amount/i]); return o && o.filter((x) => pdate(pick(x, /date/))).length ? o : null; }, 25000);
      if (ft) { t = ft; B.log(AG, `izmaksas: rāmī ${ft.length} rindas`); }
    }
    if (!t.length) B.log(AG, `izmaksas: tabula nav atpazīta; tabulas ${ph.querySelectorAll("table").length}; virsraksti: ` +
      [...ph.querySelectorAll("th, thead td, table tr:first-child td")].slice(0, 12).map(txt).join(" | ") + " · teksts: " + txt(ph.body).replace(/\S+@\S+/g, "…").slice(0, 200));
    await sendPayouts(t.map((o) => ({ date: pdate(pick(o, /date/)), amount: money(pick(o, /^net$/i) || pick(o, /amount/i)), currency: "USD", status: pick(o, /status|type/) }))
      .filter((r) => !/refund|return|revers/i.test(r.status)));
  });
  await portfolioSafe([
    ["uploads", () => portPage("/account/uploads/")],
    ["uploads/status", () => portPage("/account/uploads/status/")],
  ]);
  return { rows: rows.length };
}
