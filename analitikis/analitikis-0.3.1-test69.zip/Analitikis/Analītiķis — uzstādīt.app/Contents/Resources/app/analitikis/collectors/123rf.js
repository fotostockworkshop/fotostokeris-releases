/* 123RF: www.123rf.com/apicore-contributors — dienu ienākumi pa kategorijām + mēneša CSV ar katru lejupielādi */
async function collect() {
  if (!/(^|\.)123rf\.com$/.test(location.hostname)) throw LOGIN;
  const A = (u) => getj("/apicore-contributors/" + u);
  const sum = await A("earnings");
  if (!sum || !sum.data) throw LOGIN;

  /* mēneši ar ienākumiem */
  say("mēneši", 3);
  const months = new Map();
  const addYears = (j) => {
    for (const y of (j && j.data) || [])
      for (const m of y.data_per_month || []) if (money(m.total_earnings) > 0) months.set(m.simple_date, money(m.total_earnings));
  };
  const ty = +today.slice(0, 4);
  const cur = today.slice(0, 7);
  let list;
  if (OPTS.mode === "full") {
    try { addYears(await A("earnings/report/monthly")); } catch (e) { if (e && e.login) throw e; }
    for (let y = ty; y >= 2010; y--) {
      try { addYears(await A(`earnings/report/monthly?year=${y}`)); } catch (e) { if (e && e.login) throw e; }
      if (y < ty - 1 && ![...months.keys()].some((k) => +k.slice(0, 4) <= y + 1)) break;    // agrāk nav nekā
    }
    list = [...months.keys()].sort().reverse();
    if (!list.includes(cur)) list.unshift(cur);
  } else {
    /* ikdienas atjaunošana: tikai mēneši kopš OPTS.since (bez gadu saraksta ielādes — ~6 pieprasījumi mazāk) */
    list = [];
    const [sy, sm] = [+OPTS.since.slice(0, 4), +OPTS.since.slice(5, 7)];
    for (let y = ty, m = +today.slice(5, 7); y > sy || (y === sy && m >= sm); m--) {
      if (m < 1) { m = 12; y--; continue; }
      list.push(`${y}-${pad(m)}`);
      if (list.length > 24) break;
    }
  }

  const CATS = ["credits", "subscription", "download_packs", "ai_ml_deals", "others"];
  let total = 0;
  for (let i = 0; i < list.length; i++) {
    const m = list[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(m, 5 + Math.round((i / list.length) * 90));
    const d = await A(`earnings/report/daily?date=${m}`);
    const days = [];
    for (const r of ((d && d.data) || {}).daily_datas || []) {
      const day = pdate(r.simple_date);
      if (!day) continue;
      let s = 0;
      for (const c of CATS) if (money(r[c])) { days.push({ day, cat: c, e: money(r[c]), n: 0 }); s += money(r[c]); }
      /* 0.3.1-test17 (Chrome 2026-11-08): dienas "total_earnings" ir mazāks par kategoriju summu (~2%, piem. 2026-02 6.60 → 6.45);
         123RF mēneša/gada kopsummas un izmaksas balstās uz total_earnings → starpību ieliekam kā korekciju "others" */
      const tot = money(r.total_earnings);
      if (r.total_earnings != null && Math.abs(tot - s) >= 0.005) {
        const o = days.find((x) => x.day === day && x.cat === "others");
        if (o) o.e = Math.round((o.e + tot - s) * 1e4) / 1e4; else days.push({ day, cat: "others", e: Math.round((tot - s) * 1e4) / 1e4, n: 0 });
      }
    }
    /* katra lejupielāde (ar oriģinālo faila nosaukumu) */
    const rows = [];
    try {
      const csv = await fetch(`/apicore-contributors/earnings/report/daily?file_type=csv&is_download=1&date=${m}`,
        { credentials: "include" }).then((r) => r.text());
      const lines = csv.split(/\r?\n/);
      const hi = lines.findIndex((l) => /^Date,ImageID/i.test(l));
      if (hi >= 0) {
        const head = lines[hi].split(",");
        const ix = (n) => head.indexOf(n);
        const cnt = {};
        for (const l of lines.slice(hi + 1)) {
          if (!l.trim()) continue;
          const v = l.split(",");
          const day = pdate(v[ix("Date")]);
          if (!day) continue;
          const id = v[ix("ImageID")], fn = v[ix("Filename")] || "";
          const mm = fn.match(/^(.*?)(\d{4})(\d+)$/);
          rows.push({ day, id, filename: v[ix("OriginalFilename")] || "", license: v[ix("License")] || "", amount: money(v[ix("Earnings")]),
            cnt: 1, kind: "sale", url: `https://www.123rf.com/photo_${id}.html`,
            thumb: mm ? `https://us.123rf.com/450wm/${mm[1]}/${mm[1]}${mm[2]}/${fn}/${fn}.jpg` : "" });
          cnt[day] = (cnt[day] || 0) + 1;
        }
        for (const day in cnt) days.push({ day, cat: "downloads", e: 0, n: cnt[day] });
      }
    } catch (e) { console.log("123rf csv", m, e); }
    await send("days", { start: `${m}-01`, end: monthEnd(y, mo), days });
    await sendRows(rows, { batch: "123rf-" + m, derive: false });
    total += rows.length;
    await sleep(200);
  }
  /* atlikums — test67 (Chrome 2026-11-15): līdzstrādnieka atlikums ir `earnings/report/monthly/summary` → earnings_balance "$9.84"
     (lapā "Earnings Summary"); /apicore/members/balance ir pircēja kredīti (credits, subs) — tur atlikuma nav */
  let balDone = false;
  try {
    const s = await A("earnings/report/monthly/summary");
    const d = (s && s.data) || {};
    const v = money(d.earnings_balance != null ? d.earnings_balance : d.earnings_summary);
    if (d.earnings_balance != null || d.earnings_summary != null) {
      await send("balance", { amount: v, currency: "USD" }); balDone = true;
      B.log(AG, `atlikums: $${v.toFixed(2)} (izmaksāts kopā ${d.total_lifetime_paid_out || "?"})`);
    } else B.log(AG, "atlikums: summary atslēgas: " + Object.keys(d).join(","));
  } catch (e) { if (e && e.login) throw e; B.log(AG, "atlikums: summary — " + String(e && e.message || e).slice(0, 80)); }
  if (!balDone) try {
    const b = await getj("/apicore/members/balance");
    let val = null;
    (function walk(o) { if (!o || typeof o !== "object" || val != null) return;
      for (const k in o) { if (/balance/i.test(k) && !isNaN(parseFloat(o[k]))) { val = parseFloat(o[k]); return; } walk(o[k]); } })(b);
    if (val != null) await send("balance", { amount: val, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* statusi "Manas bildes" (0.3.1-test69, Chrome 2026-11-15): Manage content → review_images.
     Gatavie periodi (last_30_days u.c.) ir neprecīzi → vienmēr tieši datumi "YYYY-MM-DD to YYYY-MM-DD".
     Lapā redzams viens licences/tipa variants → apvienojam vairākus pēc filename; vektoru lietotājam nav, AI bildes — atsevišķi. Gaida/noraidītās — viss laiks, pieņemtās — 45 d. */
  if (OPTS.sub_due) { try { await rfStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  /* izmaksas (test44): Earning details → PAYMENT HISTORY, gads "All-time" (lietotājs 2026-10-30) */
  await payoutsSafe(async () => {
    const RE = /([A-Z0-9]{8,})\s+(\d{1,2}\s+[A-Za-z]{3,9}\s+\d{4})\s+\$\s*([\d,.]+)/g;
    const rows = await framed("/contributor/earning-details", (t, d) => /payment history/i.test(t), 25000, async ({ doc, win, text }) => {
      clickText(doc, /^payment history$/i);
      await sleep(2500);
      /* gads → All-time (izvēlne: vispirms atvērt, tad izvēlēties) */
      if (clickText(doc, /^20\d\d$/, "[role=button], [role=combobox], div, span, button")) { await sleep(700); clickText(doc, /^all-?time$/i, "li, [role=option], div, span"); await sleep(2500); }
      const out = [], g = new RegExp(RE.source, "g"); let m;
      while ((m = g.exec(text()))) out.push({ date: pdate(m[2]), amount: money(m[3]), currency: "USD", ref: m[1] });
      if (!out.length) { B.log(AG, "izmaksas: Payment history — rindas nav atrastas"); apiSeen(win, /pay|earning/i); }
      return out;
    });
    /* 2026-11-08 (žurnāls): lapa neatvērās (ielogošanās) → kļūda, lai "pārbaudīts" netiek atzīmēts un nākamreiz mēģina vēlreiz */
    if (!rows) throw new Error("Payment history lapa neatvērās");
    await sendPayouts(rows.filter((r) => r.date).sort((a, b) => (a.date < b.date ? 1 : -1)));
  });
  const pn = await portfolioSafe([
    /* 0.3.1 (lietotājs 2026-11-01): kabinetā "Upload history" — tabula Draft/Pending/Rejected/Approved pa veidiem
       (Photos, Editorial, AI Images …). Portfelis = visu rindu Approved summa (AI ieskaitot — lietotājs). */
    ["upload history", async () => framed("/contributor/upload-history", (t) => /approved/i.test(t) && /\d/.test(t) ? t : null, 25000,
      async ({ text, win }) => {
        await sleep(1500);
        const t = text().replace(/\s+/g, " ");
        const ai = t.search(/approved/i), body = ai < 0 ? t : t.slice(ai + 8);
        const RE = /([A-Z][A-Za-z ]{1,24}?)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)\s+([\d,]+)(?=\s|$)/g;
        let m, sum = 0, pend = 0, rej = 0; const parts = [];
        while ((m = RE.exec(body))) {
          const [ , name, , p, r, a] = m;
          const A = numOf(a) || 0; sum += A; pend += numOf(p) || 0; rej += numOf(r) || 0;
          if (A || numOf(p)) parts.push(`${name.trim()} ${A}`);
        }
        B.log(AG, `portfelis: upload history — ${parts.join(", ") || "rindas nav atrastas"}; gaida ${pend}, noraidītas ${rej}`);
        if (!sum) apiSeen(win, /upload|history|contributor|apicore/i);
        return sum || null;
      })],
    ["publiskais profils", async () => {
      const RE = /(\d[\d,]*)\s+Royalty free/i;
      let u = hrefOf(document, /./, /\/profile_/);
      if (!u) u = await framed("/contributor/dashboard", (t, d) => hrefOf(d, /./, /\/profile_/), 15000);
      if (!u) { B.log(AG, "portfelis: profila saite nav atrasta"); return null; }
      window.__vdProf = u.replace(/\/+$/, "");
      try { await send("portfolio", { public_url: new URL(window.__vdProf, location.href).href }); } catch (_) { /* */ }   // ar "/" beigās lapa neatveras (405) — lietotāja adrese bez tā                       // getdoc dod 405 (2026-10-30) → pāriesim uz profilu pašā logā
      return null;
    }],
    ["earnings", async () => { const n = countKey(sum, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i); if (!n) B.log(AG, "portfelis: earnings atslēgas: " + keysOf(sum && sum.data)); return n; }],
    ["dashboard", async () => countKey(await A("dashboard"), /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["portfolio", () => portPage("/contributor/portfolio")],
  ]);
  /* profila lapa pašā logā prasa "confirm you are human" (2026-10-30) — tur NEejam; avots jāatrod kabinetā */
  return { months: list.length, rows: total };
}

async function rfStatus() {
  const d0 = (n) => new Date(Date.now() - n * 864e5).toISOString().slice(0, 10);
  const end = d0(-1), all = "2010-01-01 to " + end, recent = d0(45) + " to " + end;
  const RAW = { pending: "Pending", accepted: "Accepted", rejected: "Rejected" };
  const out = new Map();
  let any = false;
  for (const [st, df, combos] of [
    ["pending", all, [["plusPremium", "no"], ["image_rf", "yes"], ["ai"]]],
    ["rejected", all, [["plusPremium", "no"], ["image_rf", "yes"], ["ai"]]],
    ["accepted", recent, [["image_free", "no"], ["image_rf", "yes"], ["plusPremium", "yes"], ["ai"]]]]) {
    let n = 0;
    for (const [ty, ed] of combos) {
      /* AI bildes (lietotājs 2026-11-15): content_type=image_ai bez type/editorial (Upload history → AI Images) */
      const q = ty === "ai" ? "content_type=image_ai" : `type=${ty}&content_type=photo&editorial=${ed}`;
      for (let pg = 1; pg <= 60; pg++) {
        const j = await sJson(`/apicore-contributors/review_images?page=${pg}&limit=20&status=${st}&${q}&date_filter=${encodeURIComponent(df)}`);
        if (!j || !j.data) { if (pg === 1) B.log(AG, `statusi: ${st}/${ty}/${ed || ""} — ${j ? "atslēgas: " + Object.keys(j).slice(0, 8).join(",") : "nav JSON"}`); break; }
        any = true;
        const items = Array.isArray(j.data) ? j.data : Object.values(j.data);
        for (const o of items) {
          const id = String(o.filename || ""); if (!id || out.has(id)) continue;
          let f = String(o.oldFilenameProcess || "") || String(o.oldFilename || "").replace(/^[0-9a-f]{4}_/i, "");
          if (f && !/\.\w{3,4}$/.test(f)) f += ".jpg";
          const ap = o.approval || {}, why = String(ap.remarks || "").replace(/<[^>]+>/g, " ").trim();
          const th = o.thumbnails && (o.thumbnails.nonWatermarked168 || Object.values(o.thumbnails).find((v) => typeof v === "string")) || "";
          out.set(id, { id, file: f, title: String((o.kwDesc && o.kwDesc.description) || "").slice(0, 250),
            submitted: String(o.createdAt || "").slice(0, 10),
            status: st === "rejected" && why ? ("Rejected: " + why).slice(0, 160) : (ap.category || RAW[st]), thumb: typeof th === "string" ? th : "" });
          n++;
        }
        const tp = (j.meta && j.meta.pagination && j.meta.pagination.total_pages) || 1;
        if (pg >= tp || !items.length) break;
        await sleep(200);
      }
    }
    B.log(AG, `statusi: ${st} — ${n}`);
  }
  if (any && out.size) await send("sub_items", { rows: [...out.values()], part: 1, parts: 1 });
}
