"""Analītiķa API (/api/sales_*). HTTP serveris, logs un kopīgie API — core/server.py."""
from __future__ import annotations

import subprocess
import sys
import threading
import time

from core import server as core
from core.server import ok as _ok

from . import config
from . import db
from . import sync
from .i18n import T

state = {"installing": False, "install_msg": ""}
NOWIN = 0x08000000 if config.IS_WIN else 0


# --------------------------------------------------------------------------- API

def api_sales_state(_):
    ok, info = sync.webview_available()
    return _ok(**core.base_state(), db=str(db.db_path()), webview=ok, webview_info=info,
               installing=state["installing"], install_msg=state["install_msg"],
               agencies=[{"id": a, **db.AGENCIES[a]} for a in db.AG_ORDER])


def api_sales_overview(_):
    ok, _info = sync.webview_available()
    return _ok(**db.overview(), sync=sync.read_status(), webview=ok, enabled=config.get("sales_agencies") or [])


def api_sales_payouts(b):
    """Izmaksu lapa (3. daļa): stāvoklis, "var pieprasīt", alga, izmaksas € pa mēnešiem, gadi."""
    from . import payouts
    if b.get("rules_only"):
        return _ok(rules=payouts.rules(), defaults=payouts.PAYOUT)
    return _ok(payouts=payouts.overview(int(b.get("year") or 0) or None), rules=payouts.rules(),
               recent=payouts.recent(int(b.get("limit") or 40)))


def api_sales_payout_request(b):
    """"Pieprasīt visas" (noteikumi §2.4): lietotājs apstiprināja programmā → aģentūru logi (redzami) pieprasa izmaksu.
    Tikai aģentūras, kur izmaksa jāpieprasa un atlikums ≥ minimums (pārbauda serveris, ne saskarne)."""
    from . import payouts
    ok, _info = sync.webview_available()
    if not ok:
        return {"ok": False, "error": T("no_webview"), "need_webview": True}
    allowed = {x["agency"] for x in payouts.overview()["can_request"]}
    want = [a for a in (b.get("agencies") or []) if a in allowed]
    if not want:
        return {"ok": False, "error": "nothing"}
    sync.start([], payout=want)
    print("izmaksu pieprasīšana:", ",".join(want))
    return _ok(agencies=want, sync=sync.read_status())


def api_sales_mail_test(_):
    """Testa vēstule ar pašreizējo "var pieprasīt" sarakstu (iestatījumi jāsaglabā pirms tam)."""
    from . import reminder
    try:
        reminder.send_now()
    except Exception as e:
        return {"ok": False, "error": str(e)[:200]}
    return _ok()


def api_sales_chart(b):
    lt = time.localtime()
    return _ok(chart=db.chart(b.get("view", "month"), int(b.get("year") or lt.tm_year), int(b.get("month") or lt.tm_mon)))


def api_sales_feed(b):
    return _ok(**db.feed(b.get("agency", ""), int(b.get("offset", 0)), int(b.get("limit", 80)),
                         (b.get("search") or "").strip(), b.get("start", ""), b.get("end", ""),
                         b.get("period", ""), bool(b.get("monthly")), b.get("kind", "")))


def api_sales_explain(_):
    return _ok(**db.explain())


def api_sales_coverage(b):
    return _ok(**db.coverage(b.get("period", ""), b.get("agency", ""), bool(b.get("monthly"))))


def api_sales_best(b):
    return _ok(**db.best(b.get("period", "all"), b.get("agency", ""), bool(b.get("group", True)),
                         int(b.get("offset", 0)), int(b.get("limit", 48)), (b.get("search") or "").strip(),
                         b.get("sort", "e"), b.get("other") in (True, "with", "only"), b.get("other") == "only",
                         int(b.get("coll") or 0)))


def api_sales_item(b):
    from . import colls
    it = db.item(b["agency"], str(b["agency_item_id"]))
    if it:
        it["colls"] = colls.of_item(b["agency"], str(b["agency_item_id"]))
    return _ok(item=it)


# --------------------------------------------------------------------------- kolekcijas (4. daļa)

def api_sales_colls(_):
    from . import colls
    return _ok(colls=colls.listing(), imported=db.get_state("_import", "microstockr"))


def api_sales_coll_view(b):
    from . import colls
    return _ok(coll=colls.view(int(b.get("id") or 0), b.get("period") or "all"))


def api_sales_coll_items(b):
    from . import colls
    return _ok(**colls.items(int(b.get("id") or 0), b.get("period") or "all", b.get("sort") or "e",
                             int(b.get("offset") or 0), int(b.get("limit") or 60)))


def api_sales_coll_edit(b):
    """op: create {name, items?} | rename {id, name} | delete {id} | add {id, items} | remove {id, items}"""
    from . import colls
    op = b.get("op")
    cid = int(b.get("id") or 0)
    items = b.get("items") or []
    if op == "create":
        cid = colls.create(b.get("name") or "")
        n = colls.add(cid, items) if items else 0
        return _ok(id=cid, added=n)
    if not cid:
        return {"ok": False, "error": "id"}
    if op == "rename":
        colls.rename(cid, b.get("name") or "")
    elif op == "delete":
        colls.delete(cid)
    elif op == "add":
        return _ok(added=colls.add(cid, items))
    elif op == "remove":
        return _ok(removed=colls.remove(cid, items))
    else:
        return {"ok": False, "error": "op"}
    return _ok()


def api_sales_link(b):
    """Bilžu apvienošana ar roku: op merge (atzīmētās — viena bilde) | split (kartīte — katrs vienums atsevišķi)."""
    from . import lookalike
    items = b.get("items") or []
    if b.get("op") == "merge":
        return _ok(n=lookalike.merge(items))
    if b.get("op") == "split":
        return _ok(n=lookalike.split(items))
    return {"ok": False, "error": "op"}


def _bak(b) -> bytes:
    import base64
    data = b.get("data") or ""
    if "," in data[:100]:
        data = data.split(",", 1)[1]           # data:…;base64,
    return base64.b64decode(data)


def api_sales_mr_import(b):
    """Microstockr rezerves kopija: confirm=False — tikai pārskats; True — importē. Fails netiek saglabāts."""
    from . import colls
    try:
        data = _bak(b)
        if not b.get("confirm"):
            return _ok(plan=colls.preview(data))
        return _ok(result=colls.do_import(data))
    except ValueError as e:
        return {"ok": False, "error": T(str(e)) if str(e).startswith("bak_") else str(e)}


def api_sales_agencies(b):
    return _ok(**db.agencies_table(b.get("period", "month")))


def api_sales_portfolio(b):
    from . import portfolio
    return _ok(**portfolio.table(str(b.get("year") or "all")))


def api_sales_portfolio_import(b):
    """Portfeļa vēstures CSV: confirm=False — tikai pārskats; True — ielasa. Fails netiek saglabāts."""
    from . import portfolio
    text = b.get("text")
    if not isinstance(text, str) or not text.strip():
        return {"ok": False, "error": T("port_empty")}
    if len(text) > 5_000_000:
        return {"ok": False, "error": T("port_bad_head")}
    try:
        if not b.get("confirm"):
            return _ok(plan=portfolio.preview(text))
        return _ok(result=portfolio.do_import(text))
    except ValueError as e:
        return {"ok": False, "error": T(str(e)) if str(e).startswith("port_") else str(e)}


def api_sales_refresh_info(_):
    from . import freshness
    return _ok(**freshness.info())


def api_sales_years(_):
    rows = db.q("SELECT DISTINCT substr(month,1,4) y FROM monthly ORDER BY y DESC")
    return _ok(years=[r["y"] for r in rows])


def api_sales_sync(b):
    ags = [a for a in (b.get("agencies") or config.get("sales_agencies") or []) if a in db.AGENCIES]
    if not ags:
        return {"ok": False, "error": T("none")}
    ok, _info = sync.webview_available()
    if not ok:
        return {"ok": False, "error": T("no_webview"), "need_webview": True}
    show = b.get("show")
    full = b.get("full") or []
    # "Atjaunot visas" (vairākas reizē): aģentūras ar svaigiem datiem (Envato — reizi 24 h) izlaižam
    skipped = []
    if len(ags) > 1:
        skipped = [a for a in ags if a not in full and a != show and db.fresh_until(a)]
        ags = [a for a in ags if a not in skipped]
        if not ags:
            return _ok(sync=sync.read_status(), skipped=skipped)
    if show:
        en = list(config.get("sales_agencies") or [])
        if show not in en:
            config.update({"sales_agencies": [a for a in db.AG_ORDER if a in en + [show]]})
    try:
        sync.start(ags, show, full)
    except RuntimeError:
        return {"ok": False, "error": T("busy")}
    if skipped:
        print("izlaistas (dati svaigi): " + ", ".join(skipped))
    return _ok(sync=sync.read_status(), skipped=skipped)


def api_sales_status(_):
    return _ok(sync=sync.read_status())


def api_sales_stop(_):
    sync.stop()
    return _ok(sync=sync.read_status())


def api_sales_disconnect(b):
    ag = b["agency"]
    config.update({"sales_agencies": [a for a in (config.get("sales_agencies") or []) if a != ag]})
    return _ok(enabled=config.get("sales_agencies"))


def api_sales_match(b):
    """Integrācijai ar Vārdotāju: [{path, name, title, desc}] -> pārdošanas katram failam."""
    return _ok(match=db.match_files(b.get("items") or []))


def api_sales_install_webview(_):
    if state["installing"]:
        return _ok(installing=True)

    def run():
        state["installing"] = True
        state["install_msg"] = T("installing_webview")
        try:
            r = subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "pywebview"],
                               capture_output=True, text=True, timeout=900, creationflags=NOWIN)
            if r.returncode == 0:
                chk = subprocess.run([sys.executable, "-c", "import webview; print(webview.__version__)"],
                                     capture_output=True, text=True, timeout=120, creationflags=NOWIN)
                state["install_msg"] = (T("webview_ok") if chk.returncode == 0
                                        else T("error") + ": " + (chk.stderr or chk.stdout)[-400:])
            else:
                state["install_msg"] = T("error") + ": " + (r.stderr or r.stdout)[-600:]
        except Exception as e:
            state["install_msg"] = T("error") + ": " + str(e)
        finally:
            state["installing"] = False

    threading.Thread(target=run, daemon=True).start()
    return _ok(installing=True)


def api_sales_clear_sessions(_):
    """Izdzēš saglabātās aģentūru sesijas (webprofile/) — nākamreiz būs jāielogojas no jauna."""
    import shutil
    if sync.active():
        return {"ok": False, "error": T("busy")}
    sync.stop(wait=8)                 # dīkstāvē gaidošais process tur sesijas atvērtas
    shutil.rmtree(config.app_dir() / "webprofile", ignore_errors=True)
    try:
        from core import websession
        websession.forget()           # Mac: saglabātās (šifrētās) sesiju kopijas
    except Exception:
        pass
    return _ok()


API = {k[len("api_sales_"):]: v for k, v in dict(globals()).items() if k.startswith("api_sales_")}


def start(port: int = 0):
    try:
        db.ensure_groups()            # 0.1.0 datubāzei: bilžu apvienošana pēc jaunajiem noteikumiem
        db.fix_other()                # 0.3.0: Depositphotos RSM → citi maksājumi
        db.fix_market()               # 0.3.0: Envato Market atsevišķa aģentūra
        db.fix_month_rows()           # 0.3.0: Ingram mēneši arī pārdošanu sarakstā
        if not db.get_state("bigstock", "range_v8"):   # 0.3.0: Bigstock agrāk nolasīja tikai pēdējās 30 dienas; v5 — vienas dienas rindas bez datuma
            db.set_state("bigstock", "full_done", False)
            db.set_state("bigstock", "range_v8", True)
    except Exception as e:
        print("ensure_groups:", e)
    core.register(API)
    res = core.start(port)
    try:
        from . import lookalike
        lookalike.start()                 # bilžu apvienošana pēc sīktēla izskata (fonā)
    except Exception as e:
        print("bilžu apvienošana:", e)
    try:                                  # rezerves kopijas (core/backup.py): datubāzes aizvēršana atjaunojot, pārskats
        from core import backup
        backup.set_hooks(before_restore=lambda: (sync.stop(wait=8), db.close()), after_restore=lambda: None, info=db.backup_info)
        backup.start_scheduler(busy=sync.active)
    except Exception as e:
        print("rezerves kopijas:", e)
    try:
        from . import keepalive
        keepalive.start()                 # sesiju uzturēšana reizi dienā (ielogošanās plūsmu neaiztiek)
    except Exception as e:
        print("sesiju uzturēšana:", e)
    try:
        from . import reminder
        reminder.start()                  # e-pasta atgādinājums par izmaksām (ja ieslēgts iestatījumos)
    except Exception as e:
        print("atgādinājums:", e)
    return res


shutdown = core.shutdown
idle_watch = core.idle_watch
