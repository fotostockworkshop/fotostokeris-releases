/* Analītiķis — automātiska ielogošanās (aizpilda lietotājvārdu un paroli no datora drošās glabātuves).
   Python (sync.py: Runner.autofill) aizstāj __CR__ ar {u, p, hosts} un izpilda šo izteiksmi lapā.
   Atgriež: "pass" (parole ievadīta un nosūtīta), "user" (tikai 1. solis — e-pasts), "filled" (aizpildīts,
   bet lapā ir pārbaude "vai esi cilvēks" — to dara lietotājs), "none" (formas nav), "host" (sveša lapa).
   Nekad neko neraksta žurnālā un nesūta citur. */
(function (cr) {
  var host = location.hostname;
  if (!cr.hosts.some(function (h) { return host === h || host.slice(-h.length - 1) === "." + h; })) return "host";
  function vis(el) {
    if (!el || el.disabled || el.readOnly) return false;
    var r = el.getBoundingClientRect();
    if (!(r.width > 0 && r.height > 0)) return false;
    for (var e = el; e && e.nodeType === 1; e = e.parentElement) {
      var st = getComputedStyle(e);
      if (st.display === "none" || st.visibility === "hidden" || +st.opacity === 0 || e.getAttribute("aria-hidden") === "true") return false;
    }
    return true;
  }
  function setv(el, v) {
    try { el.focus(); } catch (e) { /* */ }
    var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    d.set.call(el, v);                                   // React/Vue lauki "redz" tikai šādu vērtību
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  /* sīkdatņu paziņojums aizsedz formu: izvēlamies "tikai nepieciešamās" / "noraidīt"; ja tādas nav — "piekrist" */
  (function () {
    var box = [].slice.call(document.querySelectorAll("[id*=cookie i],[class*=cookie i],[id*=consent i],[class*=consent i],#onetrust-banner-sdk,#didomi-host,[id*=cmp i]")).filter(vis);
    if (!box.length) return;
    var bs = [].slice.call(box[0].querySelectorAll("button,a,[role=button]")).filter(vis);
    var t = function (x) { return (x.innerText || x.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim(); };
    var b = bs.filter(function (x) { return /reject|decline|only (necessary|essential|required)|necessary only|don.?t (enable|accept)|deny|refuse/i.test(t(x)); })[0] ||
      bs.filter(function (x) { return /^(accept( all)?|agree|allow( all)?|ok|got it|i agree|enable all)$/i.test(t(x)); })[0];
    if (b) try { b.click(); } catch (e) { /* */ }
  })();
  var all = [].slice.call(document.querySelectorAll("input")).filter(vis);
  var REG = /sign ?up|register|create (an )?account|join (now|free)|reģistr/i;
  var pws = all.filter(function (i) { return i.type === "password"; });
  var ctx = function (i) { var f = i.form || i.closest("[role=dialog],section,div"); return f ? (f.innerText || "").slice(0, 400) : ""; };
  var pw = pws.filter(function (i) {
    var f = i.form;
    var n = f ? [].slice.call(f.querySelectorAll("input[type=password]")).filter(vis).length : 1;
    return n === 1 && !(REG.test(ctx(i)) && !/log ?in|sign ?in|ielogo/i.test(ctx(i)));
  })[0] || (pws.length === 1 ? pws[0] : null);
  var USER = "input[type=email],input[autocomplete~=username],input[autocomplete~=email],input[name*=user i]," +
    "input[name*=email i],input[name*=login i],input[id*=user i],input[id*=email i],input[id*=login i]";
  var skip = { password: 1, hidden: 1, checkbox: 1, radio: 1, submit: 1, button: 1, search: 1 };
  var u = all.filter(function (i) { return !skip[i.type] && i.matches(USER); })[0];
  if (!u && pw) {                                        // teksta lauks pirms paroles tajā pašā formā
    var scope = pw.form || pw.closest("div,section,main") || document;
    u = [].slice.call(scope.querySelectorAll("input")).filter(function (i) { return vis(i) && !skip[i.type]; })[0];
  }
  if (!pw && !u) {
    /* forma vēl nav atvērta (123RF — logs pēc "Log in", Magnific/Depositphotos — "Continue with email"):
       vienreiz lapā nospiežam e-pasta ielogošanās pogu (nekad Google/Facebook/Apple) */
    if ((window.__vdOpened || 0) >= 2) return "none";
    var cl = [].slice.call(document.querySelectorAll("button,a,[role=button]")).filter(vis);
    var lt = function (x) { return (x.innerText || x.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim(); };
    var social = /google|facebook|apple|microsoft|twitter|github|sso/i;
    var o = cl.filter(function (x) { var t = lt(x); return /e-?mail/i.test(t) && t.length < 45 && !social.test(t) && !REG.test(t); })[0] ||
      (!window.__vdOpened && cl.filter(function (x) { var t = lt(x); return /^(log ?-?in|sign ?-?in)\b/i.test(t) && t.length < 20 && !social.test(t); })[0]);
    /* šaurā logā "Log In" paslēpts izvēlnē (Pond5 "Mobile navigation", 2026-10-30) — vienreiz atveram izvēlni */
    if (!o && !window.__vdMenu) {
      var mb = cl.filter(function (x) { return /^(mobile navigation|menu|open menu|main menu|navigation)$/i.test(lt(x)); })[0];
      if (mb) { window.__vdMenu = 1; mb.click(); return "open"; }
    }
    if (!o) return "none:" + cl.map(lt).filter(function (t) { return t && t.length < 30; }).slice(0, 12).join(" | ");
    window.__vdOpened = (window.__vdOpened || 0) + 1;
    o.click();
    return "open";
  }
  /* logs jau pie lietotāja: aizpildām tikai TUKŠUS laukus un nespiežam pogu (lietotājs nospiež pats) */
  if (cr.onlyEmpty) {
    /* logs jau pie lietotāja: aizpildām tikai TUKŠUS laukus (rakstīto neaiztiekam); pogu spiežam vienreiz lapā */
    var did = false;
    if (u && cr.u && !u.value) { setv(u, cr.u); did = true; }
    if (pw && !pw.value) { setv(pw, cr.p); did = true; }
    /* lauki jau aizpildīti (programma aizpildīja, kamēr logs vēl nebija redzams — Pond5) → arī tad spiežam pogu */
    if (!did && pw && pw.value && (!u || !cr.u || u.value === cr.u) && !window.__vdPreSub) did = true;
    if (!did) return "none";
    if (!cr.submit || window.__vdPreSub) return "prefill";
    window.__vdPreSub = true;
  } else {
    if (u && cr.u && u.value !== cr.u) setv(u, cr.u);
    if (pw) setv(pw, cr.p);
  }
  /* "Atcerēties mani" / "Keep me signed in" / "Trust this device" — ilgāka sesija, retāk jāielogojas.
     Tikai ķeksis ar šādu tekstu (nekad "jaunumi", "noteikumi" u.c.). */
  var REM = /remember|keep me (signed|logged)|stay (signed|logged)|trust this (device|browser|computer)|don.?t ask (again|on this)|angemeldet bleiben|atcerēties|paturēt/i;
  [].slice.call(document.querySelectorAll("input[type=checkbox]")).forEach(function (c) {
    if (c.checked || c.disabled) return;
    var lab = (c.labels && c.labels[0] ? c.labels[0].innerText : "") || (c.closest("label") ? c.closest("label").innerText : "") ||
      c.getAttribute("aria-label") || c.name || c.id || "";
    if (!REM.test(lab) || /newsletter|terms|privacy|offer|subscribe/i.test(lab)) return;
    try { c.click(); } catch (e) { /* */ }
    if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); }
  });
  /* Tikai pārbaude, kas jāizpilda cilvēkam (ķeksis "I'm not a robot", hCaptcha, "Press & Hold").
     Neredzamā reCAPTCHA (v3 / size=invisible, stūra zīmīte .grecaptcha-badge) netraucē — pogu spiežam. */
  var captcha = [].slice.call(document.querySelectorAll("iframe[src*='recaptcha/api2/anchor'],iframe[src*='recaptcha/enterprise/anchor'],iframe[src*=hcaptcha],#px-captcha"))
    .some(function (el) { return vis(el) && !/size=invisible/.test(el.src || "") && !el.closest(".grecaptcha-badge"); });
  /* burtu kapča (Zoonar u.c.): attēls + teksta lauks — to raksta lietotājs: kursors laukā, pogu nespiežam */
  var capIn = [].slice.call(document.querySelectorAll("input")).filter(function (i) {
    return vis(i) && i.type !== "password" && /captcha|security.?code|verification.?code/i.test((i.name || "") + " " + (i.id || "") + " " + (i.placeholder || "") + " " + (i.getAttribute("aria-label") || ""));
  })[0];
  if (!capIn) {
    var capImg = [].slice.call(document.querySelectorAll("img[src*=captcha i],img[alt*=captcha i],canvas[id*=captcha i]")).filter(vis)[0];
    if (capImg) {
      var sc = capImg.closest("form,[role=dialog],div") || document;
      capIn = [].slice.call(sc.querySelectorAll("input")).filter(function (i) { return vis(i) && !skip[i.type] && i !== u && i !== pw && !i.value; })[0];
    }
  }
  if (!capIn) {
    var scope2 = (pw || u) && ((pw || u).form || (pw || u).closest("[role=dialog],.modal,section,main,div")) || document;
    if (/verification code|enter the characters|characters (from|in) the image|sicherheitscode|bestätigungscode/i.test((scope2.innerText || "").slice(0, 3000))) {
      capIn = [].slice.call(scope2.querySelectorAll("input")).filter(function (i) { return vis(i) && !skip[i.type] && i !== u && i !== pw; })[0] || null;
      if (!capIn) captcha = true;
    }
  }
  if (capIn) { captcha = true; if (!capIn.value) try { capIn.focus(); } catch (e) { /* */ } }
  if (captcha || cr.submit === false) return cr.onlyEmpty ? "prefill" : "filled";
  var field = pw || u;
  var box = field.form || field.closest("form,[role=dialog],section,main") || document;
  var btns = [].slice.call(box.querySelectorAll("button,input[type=submit],[role=button]")).filter(vis);
  var TXT = /sign ?in|log ?in|continue|next|submit|weiter|ielogo|turpin|ログイン|次へ/i;
  /* Vispirms poga ar uzrakstu "Log in"/"Sign in"…; nekad — bez teksta (paroles "acs"), Google/Facebook, "aizmirsu",
     reģistrācija (Pond5 2026-10-29: pirmā type=submit bija "rādīt paroli") */
  var bt = function (x) { return (x.innerText || x.value || "").replace(/\s+/g, " ").trim(); };
  var BAD = /google|facebook|apple|microsoft|forgot|reset|show|hide|sign ?up|register|join|cancel|close|atcelt|parād/i;
  var ok = btns.filter(function (x) { var t = bt(x); return t && t.length < 40 && !BAD.test(t + " " + (x.getAttribute("aria-label") || "")); });
  /* poga pēc paroles lauka (formas poga), nevis galvenes "Log In", kas tikai atver formu vēlreiz (Pond5 test44) */
  var after = ok.filter(function (x) { return field.compareDocumentPosition(x) & Node.DOCUMENT_POSITION_FOLLOWING; });
  if (after.length) ok = after;
  var b = ok.filter(function (x) { return /^(log ?in|sign ?in|login|ielogoties|anmelden|ログイン)$/i.test(bt(x)); })[0] ||
    ok.filter(function (x) { return TXT.test(bt(x)); })[0] ||
    ok.filter(function (x) { return x.type === "submit"; })[0];
  setTimeout(function () {
    if (b) b.click();
    else if (field.form) { if (field.form.requestSubmit) field.form.requestSubmit(); else field.form.submit(); }
    else field.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
  }, 500);
  return pw ? "pass" : "user";
})(__CR__)
