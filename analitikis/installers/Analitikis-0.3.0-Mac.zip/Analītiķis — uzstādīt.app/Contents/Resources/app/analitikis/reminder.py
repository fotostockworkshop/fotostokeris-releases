"""E-pasta atgādinājums "var pieprasīt izmaksu" (iestatījumi sales_mail_*; lietotāja vēlme 2026-10-29).

Kad: lastday — mēneša pēdējā dienā; day — izvēlētajā dienā (īsākā mēnesī — pēdējā); threshold — tiklīdz kādā
pieprasāmā aģentūrā atlikums sasniedz minimumu. Ne agrāk kā izvēlētajā stundā. Ja programma tajā dienā nedarbojās —
nākamajā palaišanā (ne vēlāk kā 3 dienas pēc termiņa). Darbojas galvenajā procesā, pārbauda ik 10 min.
Sūta tikai, ja ir ko pieprasīt. Saturs: aģentūras, summas, saites — bez paroļu un saņēmēja datiem.
"""
from __future__ import annotations

import calendar
import datetime as dt
import threading
import time

from . import config
from . import db
from . import payouts

CHECK_S = 600
LATE_DAYS = 3


def _target(now: dt.datetime, when: str, day: int) -> tuple[str, bool] | None:
    """(perioda atslēga, vai jau laiks) mēnešiem lastday/day: šis mēnesis vai nokavētais iepriekšējais."""
    hour = int(config.get("sales_mail_hour") or 9)
    def tday(y, m):
        last = calendar.monthrange(y, m)[1]
        return last if when == "lastday" else min(max(1, day), last)
    t = dt.date(now.year, now.month, tday(now.year, now.month))
    if now.date() > t or (now.date() == t and now.hour >= hour):
        return f"{now.year:04d}-{now.month:02d}", (now.date() - t).days <= LATE_DAYS
    prev = (now.replace(day=1) - dt.timedelta(days=1))
    tp = dt.date(prev.year, prev.month, tday(prev.year, prev.month))
    return f"{prev.year:04d}-{prev.month:02d}", (now.date() - tp).days <= LATE_DAYS


def message(items: list[dict], new: set[str] | None = None) -> tuple[str, str]:
    from .i18n import T                 # izvēlētajā valodā (noteikumi §6)
    sym = {"EUR": "€", "GBP": "£"}
    lines = []
    for x in items:
        amt = f"{sym.get(x['currency'], '$')}{x['amount']:.2f}"
        mark = T("mail_new") if new and x["agency"] in new else ""
        lines.append(f"• {db.AGENCIES[x['agency']]['name']}: {amt}{mark}\n  {x['url']}")
    last = max((db.get_state(a, "last_ok") or "" for a in db.AG_ORDER), default="")
    subj = T("mail_subj")
    body = (T("mail_head") + "\n\n" + "\n".join(lines) + "\n\n" + T("mail_how")
            + ("\n\n" + T("mail_data", t=last[:16].replace("T", " ")) if last else ""))
    return subj, body


def send_now(items: list[dict] | None = None, new: set[str] | None = None) -> None:
    from core import mailer
    items = items if items is not None else payouts.overview()["can_request"]
    subj, body = message(items, new)
    if not items:
        from .i18n import T
        body = T("mail_none")
        subj += T("mail_test")
    mailer.send(config.get("sales_smtp_host") or "smtp.gmail.com", int(config.get("sales_smtp_port") or 587),
                config.get("sales_mail_to") or "", subj, body)


def check(now: dt.datetime | None = None) -> str:
    """Viena pārbaude. Atgriež, ko izdarīja (testiem / žurnālam)."""
    if not config.get("sales_mail_on") or not config.get("sales_mail_to"):
        return "off"
    now = now or dt.datetime.now()
    when = config.get("sales_mail_when") or "lastday"
    items = payouts.overview()["can_request"]
    if when == "threshold":
        if now.hour < int(config.get("sales_mail_hour") or 9):
            return "early"
        cur = {x["agency"] for x in items}
        prev = set(db.get_state("_mail", "ready") or [])
        new = cur - prev
        if not new:
            if cur != prev:
                db.set_state("_mail", "ready", sorted(cur))      # kāda aģentūra izmaksāta — aizmirstam
            return "nothing_new"
        send_now(items, new)
        db.set_state("_mail", "ready", sorted(cur))
        return "sent:" + ",".join(sorted(new))
    tg = _target(now, when, int(config.get("sales_mail_day") or 28))
    if not tg:
        return "wait"
    period, in_time = tg
    if db.get_state("_mail", "period") == period:
        return "done"
    if now.strftime("%Y-%m") == period and not _due_today(now, when):
        return "wait"
    if not in_time:
        db.set_state("_mail", "period", period)
        return "too_late"
    if not items:
        db.set_state("_mail", "period", period)
        return "nothing"
    send_now(items)
    db.set_state("_mail", "period", period)
    return "sent"


def _due_today(now: dt.datetime, when: str) -> bool:
    """Šī mēneša periods — tikai, ja termiņš (diena + stunda) jau pienācis."""
    hour = int(config.get("sales_mail_hour") or 9)
    last = calendar.monthrange(now.year, now.month)[1]
    d = last if when == "lastday" else min(max(1, int(config.get("sales_mail_day") or 28)), last)
    return now.day > d or (now.day == d and now.hour >= hour)


def start() -> None:
    def run():
        time.sleep(60)                       # lai programma un dati paspēj ielādēties
        while True:
            try:
                r = check()
                if r.startswith("sent"):
                    print("e-pasta atgādinājums par izmaksām nosūtīts")
            except Exception as e:           # tīkls, parole — žurnālā tikai kļūdas veids
                print("e-pasta atgādinājums:", str(e)[:160])
            time.sleep(CHECK_S)
    threading.Thread(target=run, daemon=True).start()
