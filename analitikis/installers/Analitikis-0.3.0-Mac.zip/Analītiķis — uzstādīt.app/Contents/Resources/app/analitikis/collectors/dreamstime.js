/* Dreamstime: www.dreamstime.com/account/earnings-images — saraksts pa 20, ar pircēja meklēšanas vārdiem */
async function collect() {
  if (!/(^|\.)dreamstime\.com$/.test(location.hostname)) throw LOGIN;
  const U = (pg) => `/account/earnings-images?showlicense=all&pg=${pg}`;

  function parse(doc) {
    const out = [];
    let day = "";
    for (const list of doc.querySelectorAll(".account-list")) {
      for (const el of list.children) {
        if (el.classList.contains("account-list__date")) { day = pdate(txt(el)) || day; continue; }
        if (!el.classList.contains("account-list__item")) continue;
        const st = el.querySelector('a[href*="imageid="]');
        const id = st ? (st.getAttribute("href").match(/imageid=(\d+)/) || [])[1] : "";
        const tl = el.querySelector(".account-list__title");
        const img = el.querySelector("img");
        const p = el.querySelector(".account-list__text p") || el.querySelector("p");
        const ptxt = txt(p);
        const strong = p && p.querySelector("strong") ? txt(p.querySelector("strong")) : "";
        const amount = money(strong || ptxt);
        const lic = (strong ? ptxt.replace(strong, "") : ptxt.replace(/^\$?[\d.,]+/, ""))
          .replace(/^\s*\d+%\s*royalty/i, "").replace(/Buyer searched for:.*$/i, "").replace(/\s+/g, " ").trim();
        const qm = txt(el).match(/Buyer searched for:\s*(.+?)(?:\s+Share\b|\s+Stats\b|$)/i);
        if (!day || !amount) continue;
        out.push({ day, id: id || "", title: txt(tl), url: tl ? tl.href : "", thumb: img ? img.getAttribute("src") : "",
          amount, cnt: 1, kind: "sale", license: lic.slice(0, 60), raw: qm ? { q: qm[1].trim() } : null });
      }
    }
    return out;
  }

  let doc = await getdoc(U(1));
  const counter = doc.querySelector(".account-pagination__counter");
  if (!counter && !doc.querySelector(".account-list")) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Dreamstime: neparedzēta lapa");
  }
  const tm = txt(counter).match(/of\s+([\d,]+)/i);
  const pages = tm ? Math.ceil(parseInt(tm[1].replace(/[^\d]/g, ""), 10) / 20) : 1;
  const since = OPTS.mode === "full" ? "0000-00-00" : OPTS.since;
  let rows = [];
  for (let pg = 1; pg <= pages; pg++) {
    say(`${pg}/${pages}`, Math.round((pg / pages) * 90));
    if (pg > 1) { doc = await getdoc(U(pg)); await sleep(250); }
    const r = parse(doc);
    rows = rows.concat(r.filter((x) => x.day >= since));
    if (!r.length || r[r.length - 1].day < since) break;
  }
  await sendRows(rows, { start: OPTS.mode === "full" ? "2000-01-01" : since, end: today });
  try {
    const home = await getdoc("/");
    const b = txt(home.body).match(/\$\s*([\d,.]+)\s*Earnings balance/i);
    if (b) await send("balance", { amount: money(b[1]), currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: jāpieprasa (tikai LASĀM /account/request-payment — nekad nesūtām); vēsture /account/payment-requests */
  await payoutsSafe(async () => {
    const rp = txt((await getdoc("/account/request-payment")).body);
    const bal = rp.match(/current earnings balance:?\s*\$\s*([\d,.]+)/i);
    const mn = rp.match(/minimum payout balance is\s*\$\s*([\d,.]+)/i);
    await sendPayInfo({ unpaid: bal ? money(bal[1]) : null, available: bal ? money(bal[1]) : null, min: mn ? money(mn[1]) : null, currency: "USD" });
    const t = tableObjs(await getdoc("/account/payment-requests"), [/date/i, /value|amount/i]) || [];
    await sendPayouts(t.map((o) => ({ date: pdate(pick(o, /date/)), status: pick(o, /status/),
      amount: Math.round((money(pick(o, /value|amount/)) - Math.abs(money(pick(o, /withheld|tax/)))) * 100) / 100, currency: "USD" }))
      .filter((r) => !r.status || /paid|complet|sent|done/i.test(r.status)));
  });
  await portfolioSafe([
    ["sākumlapa", () => portPage("/", [/online files[^\d]{0,20}(\d[\d,]*)/i, /(\d[\d,]*)\s+online files/i, ...PORT_RE])],
    ["account", () => portPage("/account", [/online files[^\d]{0,20}(\d[\d,]*)/i, /(\d[\d,]*)\s+online files/i, ...PORT_RE])],
  ]);
  return { pages, rows: rows.length };
}
