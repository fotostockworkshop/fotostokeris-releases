/* Alamy: konta izraksts (ASP.NET lapa). Neto ienākums = pārdošana − Alamy un izplatītāja komisijas. */
async function collect() {
  if (!/(^|\.)alamy\.com$/.test(location.hostname)) throw LOGIN;
  const BASE = "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1";
  let doc = await getdoc(BASE);
  const formOf = (d) => d.querySelector("form#form1") || d.forms[0];
  if (!formOf(doc) || !doc.querySelector('[name="drpPeriod"]')) throw LOGIN;

  /* ASP.NET "postback": visi formas lauki + izmaiņas */
  async function post(d, set, base = BASE) {
    const f = formOf(d);
    const fd = new URLSearchParams();
    for (const el of f.querySelectorAll("input, select, textarea")) {
      if (!el.name || ["submit", "button", "image", "reset"].includes(el.type)) continue;
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) continue;
      fd.set(el.name, el.value || "");
    }
    for (const k in set) fd.set(k, set[k]);
    return getdoc(base, { method: "POST", body: fd, headers: { "Content-Type": "application/x-www-form-urlencoded" } });
  }
  const pageInfo = (d) => { const m = txt(d.body).match(/Page\s+(\d+)\s+of\s+(\d+)/i); return m ? [+m[1], +m[2]] : [1, 1]; };

  say("izraksts", 3);
  doc = await post(doc, { __EVENTTARGET: "drpPeriod", __EVENTARGUMENT: "", drpPeriod: OPTS.mode === "full" || OPTS.payouts_full ? "2000" : "2",
    drpPagesize: "100" });
  const body = txt(doc.body);
  const sm = body.match(/Summary for (\d{1,2} [A-Za-z]+ \d{4}) to (\d{1,2} [A-Za-z]+ \d{4})/);
  /* izmaksu vēsture vēl nav (payouts_full) — pirmo reizi lasām visu izrakstu (arī ikdienas atjaunošanā) */
  const start = sm ? pdate(sm[1]) : (OPTS.mode === "full" || OPTS.payouts_full ? "2000-01-01" : OPTS.since);
  const end = sm ? pdate(sm[2]) : today;
  const bal = body.match(/Balance carried forward:\s*\$\s*(-?[\d,.]+)/i);
  if (bal) await send("balance", { amount: money(bal[1]), currency: "USD" });

  const cleared = body.match(/Cleared balance:?\s*\$\s*(-?[\d,.]+)/i);
  const nextPay = body.match(/Next payment date:?\s*(\d{1,2}[\s/.-]+[A-Za-z0-9]+[\s/.-]+\d{4})/i);
  const pays = [];                       // izmaksas izrakstā (PayPal u.c.)
  const agg = new Map();                 // (diena|ID) -> {neto, skaits}
  let [pg, pages] = pageInfo(doc);
  for (let guard = 0; guard < 500; guard++) {
    say(`${pg}/${pages}`, Math.min(95, 5 + Math.round((pg / Math.max(1, pages)) * 90)));
    for (const tr of doc.querySelectorAll("table tr")) {
      const c = [...tr.cells].map((x) => txt(x));
      if (c.length < 7) continue;
      const day = pdate(c[0]);
      if (!day) continue;
      const desc = c[1], id = c[2];
      if (/paypal|payment|transfer|bank|cheque|withdraw|brought forward/i.test(desc)) {
        if (!/brought forward/i.test(desc)) pays.push({ date: day, amount: Math.abs(money(c[4]) || money(c[5])), currency: "USD" });
        continue;
      }
      const key = day + "|" + id;
      const a = agg.get(key) || { e: 0, n: 0 };
      a.e += money(c[5]) - money(c[4]);
      if (/^sale$/i.test(desc)) a.n += 1;
      if (/^sale refunded/i.test(desc)) a.n -= 1;
      agg.set(key, a);
    }
    if (pg >= pages) break;
    const before = pg;
    doc = await post(doc, { __EVENTTARGET: "", __EVENTARGUMENT: "", txtGotopage: String(pg + 1), btnGotopage: "Go" });
    [pg, pages] = pageInfo(doc);
    if (pg <= before) break;              // lapošana neizdevās — beidzam ar to, kas ir
    await sleep(300);
  }
  const rows = [];
  for (const [key, a] of agg) {
    const [day, id] = key.split("|");
    if (Math.abs(a.e) < 0.0001 && !a.n) continue;
    rows.push({ day, id, amount: Math.round(a.e * 10000) / 10000, cnt: a.n, kind: "sale",
      url: id ? `https://www.alamy.com/search.html?qt=${encodeURIComponent(id)}` : "" });
  }
  await sendRows(rows, { start, end });
  /* sīktēli (test48): pārdošanu vēsture Rep=0 — pie katras pārdošanas sīktēls c7.alamy.com/thumbs/…/<ID>.jpg;
     pirmo reizi visa vēsture, pēc tam reizi dienā jaunākās */
  if (OPTS.full_thumbs || OPTS.port_due) {        // port_due = pirmā atjaunošana šodien
    try {
      const B0 = BASE.replace("Rep=1", "Rep=0");
      let d0 = await getdoc(B0);
      if (formOf(d0) && d0.querySelector('[name="drpPeriod"]')) {
        d0 = await post(d0, { __EVENTTARGET: "drpPeriod", __EVENTARGUMENT: "", drpPeriod: OPTS.full_thumbs ? "2000" : "2", drpPagesize: "100" }, B0);
        const th = new Map();
        let [p0, n0] = pageInfo(d0);
        for (let g = 0; g < 80; g++) {
          for (const img of d0.querySelectorAll("img[src*='alamy.com/thumbs'], img[src*='alamy.com/comp'], img[data-src*='alamy.com/thumbs']")) {
            const src = (img.getAttribute("src") || img.getAttribute("data-src") || "").replace(/\s+/g, "");
            const m = src.match(/\/([A-Z0-9]{5,10})\.jpg/i);
            if (m && !th.has(m[1])) th.set(m[1], src.startsWith("//") ? "https:" + src : src);
          }
          if (p0 >= n0) break;
          const b = p0;
          d0 = await post(d0, { __EVENTTARGET: "", __EVENTARGUMENT: "", txtGotopage: String(p0 + 1), btnGotopage: "Go" }, B0);
          [p0, n0] = pageInfo(d0);
          if (p0 <= b) break;
          await sleep(300);
        }
        B.log(AG, `sīktēli: ${th.size}`);
        if (th.size) await send("thumbs", { rows: [...th].map(([id, thumb]) => ({ id, thumb })), all: !!OPTS.full_thumbs });
      } else B.log(AG, "sīktēli: Rep=0 forma nav atrasta");
    } catch (e) { if (e && e.login) throw e; B.log(AG, "sīktēli: " + String((e && e.message) || e).slice(0, 100)); }
  }
  /* izmaksas: automātiskas nākamajā mēnesī, ja "Cleared balance" ≥ minimums (lietotājs: $50) */
  await payoutsSafe(async () => {
    await sendPayInfo({ unpaid: bal ? money(bal[1]) : null, available: cleared ? money(cleared[1]) : null, currency: "USD",
      next_date: nextPay ? pdate(nextPay[1]) : null });
    await sendPayouts(pays, OPTS.mode === "full" || OPTS.payouts_full ? {} : { full: false, start });
  });
  const AIM = (t) => { const m = t.match(/All submissions[\s\S]{0,60}?Images:?\s*(\d[\d,]*)/i); return m ? numOf(m[1]) : null; };
  await portfolioSafe([
    ["Image Manager (All submissions)", async () => AIM(txt((await getdoc("https://www.alamy.com/myupload/Index.aspx")).body)) || framed("https://www.alamy.com/myupload/Index.aspx", AIM)],
    ["izraksts", async () => countIn(body)],
    ["dashboard", () => portPage("https://www.alamy.com/alamycontributorreports/")],
    ["contributor", () => portPage("https://www.alamy.com/contributor/dashboard/")],
  ]);
  return { rows: rows.length, start, end };
}
