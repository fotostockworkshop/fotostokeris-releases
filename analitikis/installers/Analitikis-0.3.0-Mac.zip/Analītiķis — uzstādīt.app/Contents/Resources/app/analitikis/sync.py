"""Datu savākšana no aģentūrām.

Darbojas ATSEVIŠĶĀ procesā (`Analitikis.py --sync ...`), jo pywebview logam vajag savu galveno pavedienu.
Katrai aģentūrai tiek atvērts (parasti neredzams) pārlūka logs ar saglabātu sesiju; ja aģentūra prasa
ielogoties, logs tiek parādīts, lietotājs ielogojas pats, un savākšana turpinās automātiski.
Paroles netiek glabātas — tikai pārlūka sīkdatnes programmas datu mapē (webprofile/).

Galvenais process (serveris) šo procesu palaiž ar `start()` un nolasa stāvokli no `sync.json`.
"""
from __future__ import annotations

import datetime as dt
import functools
import json
import re
import os
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path

from . import config
from . import db as sales_db

HERE = Path(__file__).resolve().parent
COLLECTORS = HERE / "collectors"
ROOT = HERE.parent

START_URL = {
    "adobe": "https://contributor.stock.adobe.com/en/insights/sales",
    "shutterstock": "https://submit.shutterstock.com/earnings",
    "envato": "https://author.envato.com/reports/earnings",
    "istock": "https://esp.gettyimages.com/ui/account_manager?path=Reports/Dashboard",
    "alamy": "https://www.alamy.com/alamycontributorreports/Reports.aspx?Rep=1",
    "123rf": "https://www.123rf.com/contributor/dashboard",
    "dreamstime": "https://www.dreamstime.com/account/earnings-images",
    "depositphotos": "https://depositphotos.com/sales.html",
    "magnific": "https://contributor.magnific.com/files-downloads",
    "pixta": "https://www.pixtastock.com/mypage/earning",
    "pond5": "https://www.pond5.com/my-recent-sales",
    "bigstock": "https://www.bigstockphoto.com/account/commissions/",
    "zoonar": "https://www.zoonar.com/user/sales",
    "ingram": "https://www.ingramportal.com/",
}
# Automātiskā ielogošanās: parole tiek ievadīta TIKAI šo domēnu lapās (nekad Google/Facebook u.c.)
LOGIN_HOSTS = {
    "adobe": ["adobe.com", "adobelogin.com"], "shutterstock": ["shutterstock.com"], "istock": ["gettyimages.com"],     # istockphoto.com — pircēju konts, tur NEielogojamies (lietotājs 2026-10-30)
    "alamy": ["alamy.com"], "123rf": ["123rf.com"], "dreamstime": ["dreamstime.com"],
    "depositphotos": ["depositphotos.com"], "magnific": ["magnific.com", "freepik.com"],
    "pixta": ["pixtastock.com", "pixta.jp"], "pond5": ["pond5.com"], "bigstock": ["bigstockphoto.com"],
    "envato": ["envato.com"], "zoonar": ["zoonar.com"], "ingram": ["ingramportal.com"],
}
# Aģentūras, kurās pogu nespiežam: pēc aizpildes logs uzreiz pāriet lietotājam (Dreamstime — "Press & Hold").
# Bigstock agrāk klusi noraidīja pieteikšanos, jo savācējs fonā sabojāja formas zīmi — tas labots (common.js).
NO_SUBMIT = {"dreamstime"}
VIA = {"envato": ("envato_market",)}       # aģentūras, kuru dati nāk cita aģentūras logā
FILL_MAX = 6                  # ielogošanās mēģinājumi vienā atjaunošanā (visi soļi kopā)
FILL_PASS_MAX = 2             # paroles nosūtīšanas vienā atjaunošanā (lai nebloķētu kontu nepareizas paroles dēļ)
FILL_REVEAL_S = 25            # pēc aizpildes tik ilgi logu nerāda — varbūt ielogošanās izdosies pati
# Mac (WKWebView): daļa portālu (Shutterstock) atraida nezināmu pārlūku — iepazīstamies kā Safari
MAC_UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) "
          "Version/18.5 Safari/605.1.15")
RETRY_S = 5                   # gaidot ielogošanos, savācēju palaiž atkārtoti ik pēc tik sekundēm
SS_DETAIL_DAYS = 365          # Shutterstock: pārdošanas pa bildēm pirmajā ielādē (dienas atpakaļ)
STUCK_SHOW_S = 45             # ja lapa nesāk darbu tik ilgi — parādām logu (piem. pārbaude "vai esi cilvēks")
MAX_RUN_S = 60 * 60
# 0.3.0: aģentūras pa kārtai (rindā), nevis visi logi uzreiz; logus, kas neatbild, aizveram
PARALLEL_DEFAULT = 2          # cik aģentūru logu vienlaikus (iestatījums sales_parallel)
FREEZE_S = 90                 # lapa neatbild uz JS tik ilgi → logs sasalis
LOAD_S = 90                   # lapa neielādējas tik ilgi → kļūda
STALL_S = 300                 # savācējs strādā, bet tik ilgi nav nekādu ziņu → kļūda
LOGIN_WAIT_S = 10 * 60        # automātiskā atjaunošana: tik ilgi gaida ielogošanos, tad turpina rindu
LOGIN_WAIT_SHOW_S = 30 * 60   # ja lietotājs pats spieda "Ielogoties"/"Pieslēgt"
TEND_S = 5                    # ne-POLL režīmā: lapas "pulss" ik pēc tik sekundēm
QUIET_S = 25                  # Mac: tik ilgi logs strādā neredzams priekšā, pirms to rāda lietotājam
LOGIN_SHOW_S = 12             # logu parāda tikai, ja "vajag ielogoties" turas tik ilgi (pāradresācijas atrisinās pašas)
IDLE_MAX_S = 8 * 3600         # dīkstāvē process gaida nākamo atjaunošanu (sesija saglabājas), bet ne ilgāk par šo
ACTIVE = ("queued", "waiting", "loading", "running", "login")   # stāvokļi, kad aģentūra vēl nav beigusi
# Mac: saziņa ar lapu bez pywebview JS tilta (to bloķē lapu drošības politika CSP, piem. Adobe)
POLL = config.IS_MAC or os.environ.get("ANALITIKIS_POLL") == "1"
POLL_S = 0.3
BRIDGE_FNS = ("begin", "put", "progress", "login", "log", "done", "fail")


def status_file() -> Path:
    return config.app_dir() / "sync.json"


def cmd_file() -> Path:
    """Galvenais process šeit ieraksta jaunas aģentūras, kamēr savākšanas process jau strādā."""
    return config.app_dir() / "sync_cmd.json"


def profile_dir() -> Path:
    d = config.app_dir() / "webprofile"
    d.mkdir(parents=True, exist_ok=True)
    return d


def webview_available() -> tuple[bool, str]:
    """Vai pywebview ir uzstādīts (bez smagās importēšanas galvenajā procesā)."""
    import importlib
    import importlib.util
    importlib.invalidate_caches()
    try:
        return (importlib.util.find_spec("webview") is not None), ""
    except (ImportError, ValueError) as e:
        return False, str(e)


# --------------------------------------------------------------------------- galvenā procesa puse

_proc: subprocess.Popen | None = None
_proc_lock = threading.Lock()


def running() -> bool:
    """Vai savākšanas process ir dzīvs (tas paliek dzīvs arī starp atjaunošanām — sesijas saglabājas)."""
    return _proc is not None and _proc.poll() is None


def _raw_status() -> dict:
    try:
        with open(status_file(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def active() -> bool:
    """Vai šobrīd notiek atjaunošana (kāda aģentūra vēl nav beigusi)."""
    return running() and any(a.get("state") in ACTIVE for a in (_raw_status().get("agencies") or {}).values())


def read_status() -> dict:
    st = _raw_status()
    alive = running()
    st["proc"] = alive
    st["running"] = alive and any(a.get("state") in ACTIVE for a in (st.get("agencies") or {}).values())
    if not alive and st.get("agencies"):
        for a in st["agencies"].values():
            if a.get("state") in ACTIVE:
                a["state"] = "stopped"
    return st


def start(agencies: list[str], show: str | None = None, full: list[str] | None = None, payout: list[str] | None = None,
          silent: bool = False) -> None:
    """Palaiž sinhronizācijas procesu. show = aģentūra, kuras logu rādīt uzreiz (pieslēgšanās).
    Ja process jau strādā — nodod tam jaunās aģentūras (tas atver vēl logus)."""
    global _proc
    with _proc_lock:
        if running():
            st = read_status()
            busy = [a for a in agencies if (st.get("agencies") or {}).get(a, {}).get("state") in ACTIVE]
            if busy and set(busy) == set(agencies) and not payout:
                raise RuntimeError("busy")
            try:
                with open(cmd_file(), encoding="utf-8") as f:
                    cmds = json.load(f)
            except (OSError, ValueError):
                cmds = []
            new = [a for a in agencies if a not in busy]
            cmds = [c for c in cmds if time.time() - c.get("id", 0) < 3600][-20:]
            cmds.append({"id": time.time(), "agencies": new, "show": show, "full": full or [], "payout": payout or [],
                         "silent": bool(silent)})
            tmp = cmd_file().with_suffix(".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(cmds, f)
            os.replace(tmp, cmd_file())
            if not any(a.get("state") in ACTIVE for a in (st.get("agencies") or {}).values()):
                # process gaida dīkstāvē — uzreiz parādām jauno rindu (process to pārrakstīs pats ≤ 1 s laikā)
                _write_status({"started": time.time(), "pid": st.get("pid"),
                               "agencies": {a: {"state": "queued", "msg": ""} for a in new + list(payout or [])}})
            return
        try:
            cmd_file().unlink()
        except OSError:
            pass
        args = [sys.executable, str(ROOT / "Analitikis.py"), "--sync", ",".join(agencies), "--parent", str(os.getpid())]
        if show:
            args += ["--show", show]
        if full:
            args += ["--full", ",".join(full)]
        if payout:
            args += ["--payout", ",".join(payout)]
        if silent:
            args += ["--silent", "1"]
        kw = {}
        if config.IS_WIN:
            kw["creationflags"] = 0x08000000      # CREATE_NO_WINDOW
        _write_status({"started": time.time(), "agencies": {a: {"state": "queued", "msg": ""} for a in list(agencies) + list(payout or [])}})
        # Žurnāls: savākšanas process vienmēr raksta log.txt pats (ANALITIKIS_LOG=1). Bez tā uz Windows
        # (galvenais process pythonw bez konsoles) bērnprocess saņem "aizbāztu" izvadi — rindas pazūd,
        # un, bufera pilnam, print() var pat izraisīt kļūdu kādā pavedienā.
        env = dict(os.environ)
        from core import app as core_app
        env[core_app.current().slug.upper() + "_LOG"] = "1"
        _proc = subprocess.Popen(args, cwd=str(ROOT), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                 stderr=subprocess.DEVNULL, env=env, **kw)


def stop(wait: float = 0) -> None:
    global _proc
    with _proc_lock:
        if running():
            _proc.terminate()
            if wait:
                try:
                    _proc.wait(wait)
                except Exception:
                    pass


def _write_status(st: dict) -> None:
    """Windows: sync.json var būt uz brīdi aizņemts (galvenais process to lasa) — mēģinām vēlreiz."""
    tmp = status_file().with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)
    for i in range(20):
        try:
            os.replace(tmp, status_file())
            return
        except PermissionError:
            time.sleep(0.05)
    print("sync.json: neizdevās ierakstīt (aizņemts)")


# --------------------------------------------------------------------------- sinhronizācijas process

def _script(agency: str, opts: dict) -> str:
    common = (COLLECTORS / "common.js").read_text(encoding="utf-8")
    # izmaksas pieprasīšana (noteikumi §2.4: tikai pēc lietotāja apstiprinājuma programmā) — cits "savācējs"
    body = (COLLECTORS / ("payout.js" if opts.get("payout") else f"{agency}.js")).read_text(encoding="utf-8")
    return (common.replace("__AG__", agency).replace("__OPTS__", json.dumps(opts))
            .replace("__COLLECT__", body))


def _opts(agency: str, force_full: bool) -> dict:
    today = dt.date.today()
    full = force_full or not sales_db.get_state(agency, "full_done")
    last = sales_db.get_state(agency, "last_ok_day")
    since = today - dt.timedelta(days=45 if agency == "envato" else 10)
    if last:
        # lietotājs 2026-10-31: tikai jaunais — no iepriekšējās ielādes dienas −1 d.; aģentūrām ar nobīdi (dati par
        # agrākām dienām parādās vēlāk: Envato, iStock, Zoonar, Ingram) — kā līdz šim, ar lielāku rezervi
        lag = sales_db.AGENCIES.get(agency, {}).get("lag")
        try:
            back = (45 if agency == "envato" else 10) if lag else 1
            since = dt.date.fromisoformat(last) - dt.timedelta(days=back)
            if lag:
                since = min(since, today - dt.timedelta(days=back))
        except ValueError:
            pass
    # pārdošanas pa bildēm (Shutterstock): tikai pēdējās dienas kopš pēdējās atjaunošanas (+2 d. rezerve)
    detail_since = since
    if last and agency == "shutterstock":
        try:
            detail_since = max(since, dt.date.fromisoformat(last) - dt.timedelta(days=2))
        except ValueError:
            pass
    if agency == "shutterstock":
        since = since.replace(day=1)          # Shutterstock dienu summas ņem pa veseliem mēnešiem
    # princips (lietotājs 2026-10-29): visa vēsture tikai pirmajā reizē vai pēc lietotāja pieprasījuma ("Visa
    # vēsture"); pārējās reizēs — tikai jaunais kopš pēdējās atjaunošanas
    o = {"mode": "full" if full else "recent", "today": today.isoformat(), "since": since.isoformat(),
         "detail_since": detail_since.isoformat(),
         "detail_from": (today - dt.timedelta(days=SS_DETAIL_DAYS)).isoformat(), "poll": POLL,
         "full_thumbs": full or not sales_db.get_state(agency, "thumbs_done"),
         # Shutterstock kopsummas visā vēsturē (≈2 min) — tikai pilnajā ielādē vai ja vēl nav; pēc tam tās
         # papildina jaunās pārdošanas (db.TOTALS_DAY)
         "totals": full or not sales_db.get_state(agency, "totals_day"),
         # izmaksu vēstures vēl nav — nolasām visu (vienreiz), citādi tikai jaunākās
         "payouts_full": full or not _has_payouts(agency) or _pay_rescan(agency),
         "market_done": bool(sales_db.get_state("envato_market", "full_done"))}
    try:
        from . import payouts
        o.update(payouts.check_opts(agency))
    except Exception:
        traceback.print_exc()
        o["pay_due"] = True
    try:                                # portfeļa lielums — reizi dienā (portfolio.py)
        from . import portfolio
        # Beta "Portfeļa analīze" izslēgta → portfeli nelasa (Envato portfeļa lapa vajadzīga sīktēliem — paliek)
        o["port_due"] = portfolio.due(agency) if (agency == "envato" or portfolio.enabled()) else False
        o["port_name"] = str((config.get("sales_portfolio_names") or {}).get(agency) or "")
    except Exception:
        traceback.print_exc()
    if agency == "istock":
        r = sales_db.q1("SELECT MAX(day) d FROM sales WHERE agency='istock'")
        o["last_sale_day"] = (r and r["d"]) or ""
    if agency == "bigstock":            # bildes, kurām sīktēls jau ir — tās vairs neprasām
        o["thumbed"] = [r["agency_item_id"] for r in sales_db.q(
            "SELECT agency_item_id FROM assets WHERE agency='bigstock' AND thumb LIKE 'http%'")]
    return o


def _pay_rescan(agency: str) -> bool:
    try:
        from . import payouts
        return payouts.rescan(agency)
    except Exception:
        return False


def _payout_opts(agency: str) -> dict:
    from . import payouts
    o = _opts(agency, False)
    r = payouts.rules().get(agency, {})
    o.update(payout=True, min=r.get("min"), url=r.get("url"))
    return o


def _has_payouts(agency: str) -> bool:
    try:
        r = sales_db.q1("SELECT 1 x FROM payouts WHERE agency=? LIMIT 1", (agency,))
        return bool(r)
    except Exception:
        return False


def _run_js(w, script):
    """Izpilda JS lapā tieši (bez pywebview eval ietinuma, ko bloķē CSP); vecākā pywebview — evaluate_js."""
    fn = getattr(w, "run_js", None)
    return fn(script) if fn else w.evaluate_js(script)


def parallel() -> int:
    try:
        return max(1, min(4, int(config.get("sales_parallel") or PARALLEL_DEFAULT)))
    except (TypeError, ValueError):
        return PARALLEL_DEFAULT


class Runner:
    """Aģentūru logi. Vienlaikus atvērti ne vairāk kā `parallel()` logi; pārējās aģentūras gaida rindā.
    Neredzams "turētāja" logs uztur pywebview darbā, kamēr rindā vēl kāds ir (pywebview beidz darbu,
    kad aizvērts pēdējais logs)."""

    def __init__(self, agencies: list[str], show: str | None, full: set[str], payout: set[str] = frozenset()):
        payout = {a for a in payout if a in START_URL and a not in agencies}
        self.payout = set(payout)   # izmaksu pieprasīšana: redzams logs, payout.js (noteikumi §2.4)
        agencies = list(agencies) + sorted(payout)
        self.agencies = agencies
        self.show = show
        self.full = full
        self.windows = {}
        now = time.time()
        self.st = {"started": now, "pid": os.getpid(),
                   "agencies": {a: {"state": "queued", "msg": "", "pct": 0, "t": now} for a in agencies}}
        self.lock = threading.RLock()
        self.opts = {a: (_payout_opts(a) if a in payout else _opts(a, a in full)) for a in agencies}
        # rinda: vispirms aģentūra, kuru lietotājs grib redzēt
        self.queue = ([show] if show in agencies else []) + [a for a in agencies if a != show]
        self.loaded_at = {}
        self.opened_at = {}
        self.alive_at = {}        # pēdējā reize, kad lapa atbildēja uz JS
        self.act_at = {}          # pēdējā ziņa no savācēja
        self.login_at = {}
        self.busy = {}            # vai savācējs šobrīd strādā lapā
        self.tried_at = {}        # pēdējā palaišana (atkārtošanai, gaidot ielogošanos)
        self.revealed = set()     # logi, kas parādīti lietotājam ielogošanās dēļ
        self.quiet = {}           # Mac: logs "priekšā, bet neredzams" (lai lapa strādā) — aģentūra -> sākuma laiks
        self.silent = set()       # sesiju uzturēšana (test48): ja vajag ielogoties — neko nedara, nākamā atjaunošana tiks galā
        self.shown = ({show} if show else set()) | set(payout)   # lietotājs pats atvēra (ilgāk gaida ielogošanos)
        self.webview = None
        self.bridge = None
        self.keeper = None
        self.cmd_seen = 0.0
        self.max = parallel()
        self.ending = 0.0
        self.parent = 0           # galvenā procesa pid: kad tas beidzas, beidzam arī mēs
        self.idle_since = 0.0
        self.had_frozen = False
        self.reloaded = set()     # aģentūras, kuru neielādēto lapu jau pārlādējām   # sasalis logs var turēt pywebview — tad pēc rindas beigām process beidzas
        self.creds = {}           # aģentūra -> (lietotājvārds, parole) | None (nolasa vienreiz)
        self.fills = {}           # aģentūra -> {"n", "pass", "t", "url", "res", "busy"}
        self.reveal_after = {}
        # "viens logs pie lietotāja vienlaikus" (lietotājs 2026-10-30: kamēr Adobe gaidīja e-pasta kodu, citi logi
        # lēca virsū): attn — aģentūra, kuras logs pašlaik pie lietotāja; nākamās gaida rindā attn_wait
        self.attn = None
        self.attn_wait = []

    # ---- stāvoklis
    def set(self, ag, **kw):
        with self.lock:
            self.st["agencies"][ag].update(kw, t=time.time())
            _write_status(self.st)
            st = self.st["agencies"][ag]["state"]
            if ag == self.attn and st != "login":
                self.attn = None                  # lietotājs pabeidza — nākamais gaidošais logs
                if self.attn_wait:
                    threading.Timer(1.0, self._next_attn).start()

    def _next_attn(self):
        with self.lock:
            while self.attn_wait:
                nxt = self.attn_wait.pop(0)
                if self.state(nxt) == "login" and nxt in self.windows:
                    break
            else:
                return
        print(f"[{nxt}] logs lietotājam (iepriekšējais pabeigts)")
        self.reveal(nxt)

    def state(self, ag):
        return self.st["agencies"][ag]["state"]

    # ---- logi
    def on_loaded(self, ag, w=None):
        if self.windows.get(ag) is not w and w is not None:
            return
        now = time.time()
        self.loaded_at[ag] = now
        self.alive_at[ag] = now
        if self.state(ag) == "waiting":
            self.set(ag, state="loading")
        self.busy[ag] = False          # jauna lapa — iepriekšējais savācējs vairs nestrādā
        self.inject(ag)

    def inject(self, ag):
        """Palaiž savācēju lapā (nebloķējoši; savācējs pats sargā no dubultas palaišanas)."""
        w = self.windows.get(ag)
        # "running" — savācējs jau sūtīja datus un pārgāja uz citu lapu (Getty: ESP → atskaites)
        if not w or self.state(ag) not in ("waiting", "loading", "login", "running") or self.busy.get(ag):
            return
        self.tried_at[ag] = time.time()

        def go():
            try:
                _run_js(w, _script(ag, self.opts[ag]) + "\n;0;")
            except Exception as e:
                print("evaluate_js", ag, str(e)[:300])
        threading.Thread(target=go, daemon=True).start()

    def tend(self, ag, w):
        """Katram logam savs pavediens: POLL režīmā savāc savācēja ziņas, citādi pārbauda, vai lapa atbild.
        Ja lapa sasalst, šis pavediens iestrēgst — to pamana watchdog (alive_at netiek atjaunots)."""
        while self.windows.get(ag) is w:
            time.sleep(POLL_S if POLL else TEND_S)
            if self.windows.get(ag) is not w or self.state(ag) not in ACTIVE:
                continue
            if not POLL:
                try:
                    _run_js(w, "1")
                    self.alive_at[ag] = time.time()
                except Exception:
                    pass
                continue
            try:
                raw = _run_js(w, "window.__vdOut ? window.__vdOut() : '[]'")
                self.alive_at[ag] = time.time()
                msgs = json.loads(raw) if isinstance(raw, str) and raw else []
            except Exception:
                continue
            for m in msgs:
                fn = m.get("fn")
                try:
                    if fn not in BRIDGE_FNS:
                        raise ValueError(f"nezināms: {fn}")
                    ok, val = True, getattr(self.bridge, fn)(*(m.get("args") or []))
                except Exception as e:
                    traceback.print_exc()
                    ok, val = False, str(e)
                try:
                    _run_js(w, f"window.__vdIn && window.__vdIn({int(m.get('id', 0))}, "
                               f"{'true' if ok else 'false'}, {json.dumps(val)});0;")
                except Exception as e:
                    print("pump", ag, str(e)[:200])

    def on_closed(self, ag, w=None):
        """Logs aizvērts (arī lietotājs to aizvēra pats)."""
        with self.lock:
            if self.windows.get(ag) is not w and w is not None:
                return                      # jau atlaists (piem. pēc taimauta)
            self.windows.pop(ag, None)
            if self.state(ag) in ACTIVE:
                self.set(ag, state="cancelled", msg="")
                sales_db.set_state(ag, "last_try", dt.datetime.now().isoformat(timespec="seconds"))
        self.fill()

    def keep_session(self, ag):
        """Mac: aģentūras īslaicīgās sīkdatnes → šifrēts sessions.bin (core/websession.py), fonā."""
        def run():
            try:
                from core import websession
                if not websession.enabled():
                    return
                cookies = websession.mac_session_cookies(LOGIN_HOSTS.get(ag) or [])
                websession.save(ag, cookies)
                print(f"[{ag}] sesija saglabāta ({len(cookies)} sīkdatnes)")
            except Exception as e:
                print(f"[{ag}] sesijas saglabāšana:", str(e)[:160])
        threading.Thread(target=run, daemon=True).start()

    def release(self, ag, delay=0.3):
        """Aģentūra beigusi (vai atteikta): vispirms atveram nākamo no rindas, tad aizveram šo logu."""
        with self.lock:
            getattr(self, "t_open", {}).pop(ag, None)
            w = self.windows.pop(ag, None)
        self.fill()
        if w:
            def kill():
                try:
                    w.destroy()
                except Exception:
                    pass
            threading.Timer(delay, lambda: threading.Thread(target=kill, daemon=True).start()).start()

    def close(self, ag):
        self.release(ag)

    def give_up(self, ag, code):
        """Logs neatbild / neielādējas / gaida pārāk ilgi — atzīmējam kļūdu un turpinām rindu."""
        print(f"[{ag}] pārtraukts: {code}")
        if code in ("frozen", "not_loaded"):
            self.had_frozen = True
        self.busy[ag] = False
        sales_db.set_state(ag, "last_err", code)
        sales_db.set_state(ag, "last_try", dt.datetime.now().isoformat(timespec="seconds"))
        self.set(ag, state="error", msg=code)
        self.release(ag, delay=0)

    # ---- automātiskā ielogošanās (paroles no datora drošās glabātuves, core/credentials.py)
    def cred(self, ag):
        if ag not in self.creds:
            try:
                from core import credentials
                c = credentials.get(ag)
                self.creds[ag] = c if c and c[1] else None
            except Exception:
                self.creds[ag] = None
        return self.creds[ag]

    def login_seen(self, ag):
        """Aģentūra prasa ielogoties: ja ir saglabāta parole — aizpildām; citādi (vai ja neizdodas) rādām logu."""
        now = time.time()
        if ag in self.silent:                  # sesiju uzturēšana: neielogojamies, logu nerādām, kļūdu nerakstām
            if self.state(ag) != "cancelled":
                print(f"[{ag}] sesiju uzturēšana: sesija beigusies — neielogojos (to izdarīs nākamā atjaunošana)")
                self.busy[ag] = False
                self.set(ag, state="cancelled", msg="")
                self.release(ag, delay=0)
            return
        f = self.fills.setdefault(ag, {"n": 0, "pass": 0, "t": 0.0, "url": "", "res": "", "busy": False})
        # Logs jau pie lietotāja: netraucējam — IZŅEMOT, ja programma vēl ne reizi nav aizpildījusi (piem. forma atvērās
        # tikai pēc pogas, vai pārbaudes lapa aizkavēja) — tad vienu reizi aizpildām (2026-10-29: 123RF, Zoonar …)
        if not f["busy"] and (ag in self.revealed or ag in self.quiet) and self.cred(ag) and now - f.get("pre_t", 0) > 3:
            # logs jau pie lietotāja: tukšos laukus aizpildām (pogu spiež lietotājs) — arī pēc "Press & Hold"
            f["pre_t"] = now - (2 if f.get("res") in ("open", "pass", "user") else 0)
            f["busy"] = True
            threading.Thread(target=self._prefill, args=(ag, f), daemon=True).start()
            return
        if f["busy"] or (ag in self.revealed and (f["n"] > 0 or ag in NO_SUBMIT)):
            return                            # logs jau pie lietotāja — netraucējam (nerakstām, nespiežam)
        if not self.cred(ag) and not f.get("nocred"):
            f["nocred"] = True
            print(f"[{ag}] automātiskā ielogošanās: parole šajā datorā nav saglabāta (vai drošā glabātuve to neatdod)")
        if self.cred(ag) and f["n"] < FILL_MAX and f["pass"] < FILL_PASS_MAX:
            wait = 2 if f["res"] == "open" else 4 if f["res"] == "user" else 5 if f["res"] in ("", "none", "host") else 30
            if now - f["t"] > wait:
                f["busy"] = True
                threading.Thread(target=self._fill_then, args=(ag, f), daemon=True).start()
                return
        self._maybe_reveal(ag, now)

    def _maybe_reveal(self, ag, now=None):
        """Logu parāda tikai, ja "vajag ielogoties" turas ≥ LOGIN_SHOW_S (pāradresācijas — Getty ESP, 123RF,
        Envato, Adobe — parasti atrisinās pašas) un nav gaidāma automātiskās ielogošanās iznākums."""
        now = now or time.time()
        if ag in self.silent:
            return
        if ag in self.revealed or now < self.reveal_after.get(ag, 0):
            return
        if ag not in self.shown and now - self.login_at.get(ag, now) < LOGIN_SHOW_S:
            return
        # test46 (lietotājs 2026-10-30: logi, kur viss aizpildās pats, nedrīkst parādīties): uz Mac paslēpta lapa
        # "guļ" (Pond5 forma neatveras, Envato/Alamy pieteikšanās neiziet), tāpēc vispirms logu noliekam priekšā
        # PILNĪGI CAURSPĪDĪGU un caurlaidīgu klikšķiem — lapa strādā, automātiskā ielogošanās pabeidz; lietotājam
        # rādām tikai, ja pēc QUIET_S vēl vajag (kods, kapča) vai programma kodu/kapču jau redz ("filled").
        if config.IS_MAC and ag not in self.shown and self.cred(ag) and (self.fills.get(ag) or {}).get("res") not in ("filled", "prefill"):
            if ag not in self.quiet:
                self.quiet[ag] = now
                self.quiet_show(ag)
                return
            if now - self.quiet[ag] < QUIET_S:
                return
        self.revealed.add(ag)
        self.reveal(ag)

    def _prefill(self, ag, f):
        try:
            # pogu spiežam ne vairāk kā 2 reizes (arī Dreamstime — pēc "Press & Hold" pārbaudes), lai nepareizas
            # paroles gadījumā konts netiktu bloķēts
            sub = f.get("presub", 0) < 2
            res = self.autofill(ag, only_empty=True, submit=sub)
            if res in ("pass", "user", "prefill", "open"):
                f["res"] = res
            if res == "prefill":
                print(f"[{ag}] automātiskā ielogošanās: lauki aizpildīti — atliek nospiest pogu")
            elif res in ("pass", "user"):
                f["presub"] = f.get("presub", 0) + 1
                print(f"[{ag}] automātiskā ielogošanās: aizpildīts un nospiests ({res})")
        finally:
            f["busy"] = False

    def _fill_then(self, ag, f):
        try:
            res = self.autofill(ag)
            f["t"] = time.time()
            f["res"] = res
            if res in ("none", "host", "open") and f.get("last_note") != res:
                f["last_note"] = res
                print(f"[{ag}] automātiskā ielogošanās: " + {"none": "lapā nav ielogošanās lauku",
                      "host": "sveša lapa — neaizpildu", "open": "atveru ielogošanās formu (poga)"}[res])
            if res == "open":
                f["t"] = time.time() - 3             # pēc ~2 s mēģinām vēlreiz (forma atvērta)
            if res in ("pass", "user", "filled"):
                f["n"] += 1
                if res == "pass":
                    f["pass"] += 1
                print(f"[{ag}] automātiskā ielogošanās: {res}")
            if res in ("pass", "user", "open"):
                self.reveal_after[ag] = time.time() + FILL_REVEAL_S
            if res == "filled" and ag not in self.revealed:
                self.revealed.add(ag)             # aizpildīts, poga (un pārbaude) lietotājam — logu rādām uzreiz
                self.reveal(ag)
        finally:
            f["busy"] = False
        if res not in ("pass", "user", "open"):
            self._maybe_reveal(ag)

    def autofill(self, ag, only_empty=False, submit=None) -> str:
        w = self.windows.get(ag)
        c = self.cred(ag)
        if not w or not c:
            return "none"
        hosts = LOGIN_HOSTS.get(ag) or []
        try:                                      # pārbaude arī Python pusē: paroli svešā lapā nesūtām
            from urllib.parse import urlparse
            h = (urlparse(w.get_current_url() or "").hostname or "").lower()
            if h and not any(h == x or h.endswith("." + x) for x in hosts):
                return "host"
        except Exception:
            pass
        js = (COLLECTORS / "autofill.js").read_text(encoding="utf-8").replace(
            "__CR__", json.dumps({"u": c[0], "p": c[1], "hosts": hosts, "submit": (ag not in NO_SUBMIT) if submit is None else submit, "onlyEmpty": only_empty}))
        try:
            res = _run_js(w, js)
        except Exception:
            print(f"[{ag}] automātiskā ielogošanās: kļūda lapā")     # bez detaļām (skripts satur paroli)
            return "err"
        if isinstance(res, str) and res.startswith("none:"):
            f = self.fills.setdefault(ag, {})
            if not f.get("nobtn"):
                f["nobtn"] = True
                print(f"[{ag}] automātiskā ielogošanās: ielogošanās poga nav atrasta; redzamās pogas: {res[5:][:300]}")
            return "none"
        return res if isinstance(res, str) else "none"

    def reveal(self, ag):
        """Parāda logu un uz brīdi novieto to virs citiem (uz Mac tas citādi paliek aiz citiem logiem).
        Vienlaikus pie lietotāja tikai viens logs: ja cits vēl gaida lietotāju — šis rindā (bez fokusa zagšanas)."""
        w = self.windows.get(ag)
        if not w:
            return
        with self.lock:
            other = self.attn
            if other and other != ag and self.state(other) == "login" and other in self.windows:
                if ag not in self.attn_wait:
                    self.attn_wait.append(ag)
                    print(f"[{ag}] vajag lietotāju — gaida, kamēr pabeigsi {other}")
                return
            self.attn = ag
        if ag in self.quiet:                  # bija neredzams priekšā — atjaunojam parastu logu
            self._alpha(ag, False)
        self.set(ag, visible=True)            # saskarne rāda "ielogojies logā" tikai tad, kad logs tiešām redzams
        threading.Timer(0.5, self.fill).start()   # gaidošais logs vairs neaizņem vietu — nākamā aģentūra var sākt
        for fn in (lambda: w.show(), lambda: w.restore()):
            try:
                fn()
            except Exception:
                pass
        try:
            w.on_top = True
            threading.Timer(1.5, lambda: setattr(w, "on_top", False)).start()
        except Exception:
            pass

    def _alpha(self, ag, quiet: bool):
        """Mac: loga caurspīdīgums un klikšķu caurlaidība (galvenajā pavedienā)."""
        w = self.windows.get(ag)
        if not w or not config.IS_MAC:
            return False
        try:
            from PyObjCTools import AppHelper   # type: ignore
        except Exception:
            return False

        def fn():
            try:
                nw = w.native                   # pywebview cocoa: NSWindow
                nw.setAlphaValue_(0.0 if quiet else 1.0)
                nw.setIgnoresMouseEvents_(bool(quiet))
                if quiet:
                    nw.orderFrontRegardless()   # priekšā, bet bez fokusa — lietotājs to neredz un nejūt
            except Exception as e:
                print(f"[{ag}] neredzamais logs:", str(e)[:120])
        AppHelper.callAfter(fn)
        return True

    def quiet_show(self, ag):
        if self._alpha(ag, True):
            print(f"[{ag}] ielogojas neredzamā logā (lietotājam rādīs tikai, ja vajadzēs kodu)")

    def hide(self, ag):
        w = self.windows.get(ag)
        if w and ag not in self.shown:
            try:
                w.hide()
            except Exception:
                pass

    def add(self, agencies, show=None, full=(), payout=(), silent=False):
        """Jaunas aģentūras no galvenā procesa (arī pēc webview.start): ieliek rindā."""
        with self.lock:
            for ag in agencies:                # sesiju uzturēšana: šīm nekad nerāda logu un neielogojas
                (self.silent.add if silent else self.silent.discard)(ag)
            if not any(a.get("state") in ACTIVE for a in self.st["agencies"].values()):
                self.new_batch()
            for ag in payout:
                if ag not in START_URL or ag in self.windows or ag in self.queue:
                    continue
                self.st["agencies"][ag] = {"state": "queued", "msg": "", "pct": 0, "t": time.time()}
                self.opts[ag] = _payout_opts(ag)
                self.payout.add(ag)
                self.shown.add(ag)
                self.queue.append(ag)
            for ag in agencies:
                if ag not in START_URL or ag in self.windows or ag in self.queue:
                    continue
                self.st["agencies"][ag] = {"state": "queued", "msg": "", "pct": 0, "t": time.time()}
                self.opts[ag] = _opts(ag, ag in set(full))
                self.queue.append(ag)
            if show and show in self.queue:
                self.queue.remove(show)
                self.queue.insert(0, show)
                self.shown.add(show)
            _write_status(self.st)
        self.fill(extra=show)

    def new_batch(self):
        """Jauna atjaunošanas reize tajā pašā procesā (sesijas saglabājušās): tīrs stāvoklis."""
        try:
            from core import config as cc
            cc._settings = None                   # iestatījumi var būt mainīti galvenajā procesā
        except Exception:
            pass
        self.max = parallel()
        self.creds = {}
        self.fills = {}
        self.revealed = set()
        self.quiet = {}
        self.shown = set()
        self.payout = set()
        self.reveal_after = {}
        self.login_at = {}
        self.ending = 0.0
        self.idle_since = 0.0
        self.reloaded = set()
        self.st = {"started": time.time(), "pid": os.getpid(), "agencies": {}}
        try:
            sales_db.clear_fresh()                # "jaunās" = tikai tās, kas atnāks šajā reizē
        except Exception:
            traceback.print_exc()

    def fill(self, extra=None):
        """Atver logus no rindas, kamēr vienlaikus atvērto ir mazāk par self.max.
        `extra` (lietotāja izvēlētā aģentūra) tiek atvērta uzreiz, pat ja vietu nav."""
        while True:
            with self.lock:
                if not self.queue:
                    break
                # logs, kas gaida, kamēr lietotājs ielogojas (2FA u.c.), neaptur pārējās aģentūras
                busy_n = sum(1 for a in self.windows if not (a in self.revealed and self.state(a) == "login"))
                if busy_n >= self.max and self.queue[0] != extra:
                    break
                ag = self.queue.pop(0)
            try:
                self.open_window(ag, hidden=(ag not in self.shown))
            except Exception as e:
                traceback.print_exc()
                self.set(ag, state="error", msg=str(e)[:200])

    def open_window(self, ag, hidden=True):
        if not hasattr(self, "t_open"):
            self.t_open = {}
        self.t_open.setdefault(ag, time.time())
        self.set(ag, state="waiting", msg="")
        url = (self.opts.get(ag) or {}).get("url") if ag in self.payout else None
        w = self.webview.create_window(f"Analītiķis — {sales_db.AGENCIES[ag]['name']}", url or START_URL[ag], js_api=self.bridge,
                                       width=1360, height=860, hidden=hidden)   # ≥1280: datora izkārtojums (Pond5 "Log In")
        now = time.time()
        with self.lock:
            self.windows[ag] = w
            self.opened_at[ag] = now
            self.alive_at[ag] = now
            self.act_at[ag] = now
            self.loaded_at.pop(ag, None)
            self.busy[ag] = False
        w.events.loaded += functools.partial(self.on_loaded, ag, w)
        w.events.closed += functools.partial(self.on_closed, ag, w)
        threading.Thread(target=self.tend, args=(ag, w), daemon=True).start()
        if not hidden:
            threading.Timer(1.0, self.reveal, args=(ag,)).start()

    def poll_commands(self):
        try:
            with open(cmd_file(), encoding="utf-8") as f:
                cmds = json.load(f)
        except (OSError, ValueError):
            return
        for c in cmds:
            if c.get("id", 0) > self.cmd_seen:
                self.cmd_seen = c["id"]
                try:
                    self.add(c.get("agencies") or [], c.get("show"), c.get("full") or [], c.get("payout") or [],
                             silent=bool(c.get("silent")))
                except Exception:
                    traceback.print_exc()

    def finished(self) -> bool:
        with self.lock:
            return not self.windows and not self.queue

    def check(self, ag, now):
        """Viena loga taimauti."""
        s = self.st["agencies"][ag]
        st = s["state"]
        loaded = self.loaded_at.get(ag)
        if not loaded:
            waited = now - self.opened_at.get(ag, now)
            if waited > LOAD_S / 2 and ag not in self.reloaded:
                # lapa "neatnāk līdz galam" (Mac: Dreamstime slēptā logā) — vienreiz pārlādējam
                self.reloaded.add(ag)
                print(f"[{ag}] lapa neielādējas — pārlādēju")
                w = self.windows.get(ag)
                if w:
                    threading.Thread(target=lambda: _safe(lambda: w.load_url(START_URL[ag])), daemon=True).start()
            if waited > LOAD_S:
                return self.give_up(ag, "not_loaded")
        elif now - self.alive_at.get(ag, now) > FREEZE_S:
            return self.give_up(ag, "frozen")
        if st in ("loading", "waiting") and loaded and now - loaded > STUCK_SHOW_S:
            self.set(ag, state="login", msg="")
            self.login_at.setdefault(ag, now)
            st = "login"
        if st == "login" and ag not in self.revealed and now >= self.reveal_after.get(ag, 0):
            self.login_seen(ag)
        if st == "login":
            wait = LOGIN_WAIT_SHOW_S if ag in self.shown else LOGIN_WAIT_S
            if now - self.login_at.get(ag, now) > wait:
                return self.give_up(ag, "login_timeout")
        # gaidot ielogošanos: lapa var ielogoties bez pārlādes (Adobe) — pārbaudām atkārtoti
        # ielogošanās gaitā (programma atver formu / aizpilda / gaida pēc pogas) — ik ~2 s, citādi ik RETRY_S
        fast = st == "login" and (self.fills.get(ag) or {}).get("res") in ("open", "pass", "user", "prefill")
        if st in ("waiting", "loading", "login") and not self.busy.get(ag) and now - self.tried_at.get(ag, 0) > (2 if fast else RETRY_S):
            self.inject(ag)
        if st == "running":
            if now - s.get("began", now) > MAX_RUN_S:
                return self.give_up(ag, "timeout")
            if now - self.act_at.get(ag, now) > STALL_S:
                return self.give_up(ag, "stalled")

    def watchdog(self):
        while True:
            time.sleep(1)
            self.poll_commands()
            now = time.time()
            for ag in list(self.windows):
                try:
                    self.check(ag, now)
                except Exception:
                    traceback.print_exc()
            if self.parent and not _alive(self.parent):
                print("galvenais process beidzies — beidzu darbu")
                self.finish_status()
                os._exit(0)
            if self.finished():
                if not self.idle_since:
                    self.idle_since = now
                    self.finish_status()
                    print("rinda tukša — gaidu nākamo atjaunošanu")
                if self.had_frozen or not self.parent or now - self.idle_since > IDLE_MAX_S:
                    # sasalis logs var bloķēt pywebview, vai nav zināms, kad galvenais process beigsies
                    if not self.ending:
                        self.ending = now
                        self.shutdown()
                    elif now - self.ending > 15:  # kāds logs neaizveras (sasalis) — beidzam procesu
                        os._exit(0)
            else:
                self.idle_since = 0.0

    def shutdown(self):
        """Visas aģentūras beigušas: aizveram turētāja logu — pywebview beidz darbu."""
        k = self.keeper
        if k:
            threading.Thread(target=lambda: _safe(k.destroy), daemon=True).start()

    def finish_status(self):
        with self.lock:
            for a in list(self.st["agencies"]):
                if self.state(a) not in ("done", "error"):
                    self.st["agencies"][a].update(state="cancelled")
            self.st["finished"] = time.time()
            _write_status(self.st)


def _alive(pid: int) -> bool:
    """Vai process ar šo pid vēl darbojas (Windows — bez os.kill, jo signāls 0 tur ir Ctrl+C)."""
    if pid <= 0:
        return True
    if config.IS_WIN:
        try:
            import ctypes
            k = ctypes.windll.kernel32
            h = k.OpenProcess(0x00100000 | 0x1000, False, pid)     # SYNCHRONIZE | QUERY_LIMITED_INFORMATION
            if not h:
                return False
            r = k.WaitForSingleObject(h, 0)
            k.CloseHandle(h)
            return r == 0x102                                        # WAIT_TIMEOUT = vēl darbojas
        except Exception:
            return True
    try:
        os.kill(pid, 0)
        return True
    except ProcessLookupError:
        return False
    except OSError:
        return True


def _is_login_url(url: str) -> bool:
    """Vai adrese ir ielogošanās lapa (nevis datu lapa ar 401 — "pusdzīva" sesija)."""
    from urllib.parse import urlparse
    u = urlparse(url or "")
    return bool(re.search(r"log-?in|sign-?in|auth|account|ims|adobelogin|session", (u.hostname or "") + u.path, re.I))


def _safe(fn):
    try:
        fn()
    except Exception:
        pass


class Bridge:
    """JS -> Python tilts (pywebview js_api). Publiskas drīkst būt tikai metodes."""

    def __init__(self, runner: Runner):
        self._r = runner

    def begin(self, ag, url=""):
        """Savācējs sāk darbu lapā. Stāvoklis vēl nemainās — tikai kad nāk pirmie dati (ielogots)."""
        r = self._r
        with r.lock:
            if ag not in r.st["agencies"] or r.state(ag) not in ACTIVE or r.busy.get(ag):
                return False
            r.busy[ag] = True
            r.act_at[ag] = time.time()
        return True

    def _running(self, ag):
        r = self._r
        r.act_at[ag] = time.time()
        with r.lock:
            if r.state(ag) != "running":
                r.st["agencies"][ag]["visible"] = False
                try:
                    sales_db.snapshot(ag)          # "jaunās pārdošanas" — salīdzinās ar šo pēc atjaunošanas
                    for sub in VIA.get(ag, ()):
                        sales_db.snapshot(sub)
                except Exception:
                    traceback.print_exc()
                r.set(ag, state="running", msg="", pct=1, began=time.time())
                sales_db.set_state(ag, "last_try", dt.datetime.now().isoformat(timespec="seconds"))
                r.hide(ag)

    def put(self, ag, kind, payload):
        self._running(ag)
        if kind == "port_nav":            # test45: pārlūks citā domēnā notīra window.name → uzdevumu glabājam šeit
            self._r.opts[ag]["port_nav"] = json.loads(payload) or None
            return True
        try:
            sales_db.ingest(ag, kind, json.loads(payload))
            return True
        except Exception as e:
            traceback.print_exc()
            return str(e)

    def progress(self, ag, msg, pct=-1):
        self._running(ag)
        kw = {"msg": msg}
        if pct is not None and pct >= 0:
            kw["pct"] = pct
        self._r.set(ag, **kw)
        return True

    def login(self, ag, url=""):
        r = self._r
        r.busy[ag] = False
        r.act_at[ag] = time.time()
        r.login_at.setdefault(ag, time.time())
        if r.state(ag) != "login":
            r.set(ag, state="login", msg="")
        # test44: atjaunotā sesija var izrādīties "pusdzīva" (Adobe 2026-10-29: lapa ielogota, API 401) — tad vienreiz
        # izmetam TIKAI atjaunotās sīkdatnes un sākam no sākuma (ilgtermiņa "uzticamās ierīces" sīkdatnes paliek)
        rs = getattr(r, "restored", {})
        if ag in rs and not _is_login_url(url):
            # izmetam tikai īslaicīgās; ilgtermiņa ("uzticamā ierīce") paliek — citādi atkal 2FA
            ck = [c for c in rs.pop(ag) if not c.get("expires")]
            print(f"[{ag}] atjaunotā sesija nederīga — izmetu ({len(ck)} īslaicīgās sīkdatnes) un ielogojos no jauna")
            def reset(w=r.windows.get(ag)):
                try:
                    from core import websession
                    websession.mac_forget(ck)
                    websession.save(ag, [])
                    if w:
                        w.load_url(START_URL[ag])
                except Exception as e:
                    print(f"[{ag}] sesijas atiestatīšana:", str(e)[:120])
            threading.Thread(target=reset, daemon=True).start()
            return True
        r.login_seen(ag)                  # aizpilda paroli vai parāda logu (vienreiz, lai netraucētu rakstīt)
        return True

    def log(self, ag, msg=""):
        print(f"[{ag}]", msg)
        return True

    def done(self, ag, info="{}"):
        now = dt.datetime.now()
        if ag in self._r.payout:                   # izmaksas pieprasījums — pārdošanu stāvokli neaiztiekam
            print(f"[{ag}] izmaksa pieprasīta: {info}")
            sales_db.set_state(ag, "payout_req", {"at": now.isoformat(timespec="seconds"), "ok": True, "info": str(info)[:300]})
            self._r.busy[ag] = False
            self._r.set(ag, state="done", msg="payout_ok", pct=100)
            self._r.release(ag, delay=4)           # lietotājs paspēj redzēt aģentūras apstiprinājumu
            return True
        t0 = getattr(self._r, "t_open", {}).pop(ag, None)
        if t0:                                     # ātruma salīdzināšanai (lietotājs 2026-10-29)
            print(f"[{ag}] gatavs {int(time.time() - t0)} s ({'visa vēsture' if self._r.opts[ag]['mode'] == 'full' else 'jaunākais'})")
        sales_db.set_state(ag, "last_ok", now.isoformat(timespec="seconds"))
        sales_db.set_state(ag, "last_ok_day", now.date().isoformat())
        sales_db.set_state(ag, "last_err", None)
        if self._r.opts[ag]["mode"] == "full":
            sales_db.set_state(ag, "full_done", True)
        for sub in VIA.get(ag, ()):                # Envato Market nāk ar Envato logu
            sales_db.set_state(sub, "last_ok", now.isoformat(timespec="seconds"))
            sales_db.set_state(sub, "last_ok_day", now.date().isoformat())
            sales_db.set_state(sub, "last_err", None)
            if self._r.opts[ag]["mode"] == "full":
                sales_db.set_state(sub, "full_done", True)
            try:
                sales_db.mark_fresh(sub)
            except Exception:
                traceback.print_exc()
        try:
            f = sales_db.mark_fresh(ag)
            if f.get("e") or f.get("n"):
                print(f"[{ag}] jaunas: ${f['e']:.2f}, {f['n']} lejupielādes")
        except Exception:
            traceback.print_exc()
        if self._r.opts[ag].get("port_due"):       # publiskais portfelis (iStock — cits domēns), fonā
            from . import portfolio
            if ag in portfolio.PUBLIC:
                threading.Thread(target=lambda: _safe(lambda: portfolio.public_fetch(ag)), daemon=True).start()
        try:
            from . import freshness
            freshness.note_sync(ag, self._r.opts[ag]["mode"] == "full")
        except Exception:
            traceback.print_exc()
        self._r.busy[ag] = False
        self._r.keep_session(ag)
        try:
            sales_db.regroup()
        except Exception:
            traceback.print_exc()
        self._r.set(ag, state="done", msg="", pct=100)
        self._r.release(ag)
        return True

    def fail(self, ag, msg=""):
        print(f"[{ag}] kļūda:", msg)
        if ag in self._r.payout:                   # nevarēja droši pieprasīt — logs paliek lietotājam
            sales_db.set_state(ag, "payout_req", {"at": dt.datetime.now().isoformat(timespec="seconds"), "ok": False, "info": msg[:300]})
            self._r.busy[ag] = False
            self._r.set(ag, state="error", msg="payout_manual")
            self._r.reveal(ag)
            return True
        self._r.busy[ag] = False
        sales_db.set_state(ag, "last_err", msg[:300])
        self._r.set(ag, state="error", msg=msg[:300])
        self._r.release(ag)
        return True


def run(agencies: list[str], show: str | None = None, full: list[str] | None = None, parent: int = 0,
        payout: list[str] | None = None, silent: bool = False) -> None:
    """Sinhronizācijas procesa ieejas punkts (izsauc Analitikis.py --sync). Process paliek dzīvs, kamēr
    darbojas galvenais process (`parent`) — nākamās atjaunošanas iet tajā pašā procesā ar tām pašām
    sesijām (Mac: sesijas sīkdatnes bez termiņa citādi pazūd, un Envato prasa paroli + 2FA katru reizi)."""
    agencies = [a for a in agencies if a in START_URL]
    r = Runner(agencies, show, set(full or []), set(payout or []))
    if silent:
        r.silent = set(agencies)
    r.parent = parent
    try:
        sales_db.clear_fresh()
    except Exception:
        traceback.print_exc()
    _write_status(r.st)
    try:
        import webview
    except Exception as e:
        print("pywebview nav pieejams:", e)
        for a in agencies:
            r.set(a, state="error", msg="pywebview: " + str(e))
        return
    print("sync:", ",".join(agencies), "pywebview", getattr(webview, "__version__", "?"), "poll" if POLL else "",
          f"vienlaikus {r.max}")
    r.bridge = Bridge(r)
    r.webview = webview
    try:
        r.cmd_seen = max([c.get("id", 0) for c in json.load(open(cmd_file(), encoding="utf-8"))] or [0])
    except (OSError, ValueError):
        pass
    # neredzams turētāja logs: pywebview nebeidz darbu, kamēr rindā vēl ir aģentūras
    r.keeper = webview.create_window("Analītiķis", html="<html><body></body></html>", hidden=True,
                                     width=200, height=100)
    try:
        from core import websession
        # 2026-10-29: atjaunotās sesijas Adobe padarīja "pusielogotu" (lapa ielogota, API 401). test44: ieslēgts pēc
        # noklusējuma ar drošības tīklu (Bridge.login: nederīgu atjaunoto sesiju izmet un ielogojas no jauna).
        keep_sessions = websession.enabled() and not config.get("sales_restore_off")
        try:
            if config.IS_MAC:
                s_, p_ = websession.mac_count(LOGIN_HOSTS["adobe"])
                print(f"Adobe sīkdatnes krātuvē: īslaicīgas {s_}, ilgtermiņa {p_}")
        except Exception as e:
            print("sīkdatņu skaits:", str(e)[:100])
    except Exception:
        keep_sessions = False

    def boot():
        """Mac: palīgprocess bez Dock ikonas, saglabātās sesijas (core/websession.py), tad aģentūru logi."""
        if config.IS_MAC:
            try:
                from PyObjCTools import AppHelper   # type: ignore
                from core.launcher import mac_dock_hidden
                AppHelper.callAfter(mac_dock_hidden)          # pywebview startā iestata "Regular" — pārrakstām pēc tam
                # test46: fona palīgprocesu macOS "iemidzina" (App Nap) — lapas taimeri palēninās; atslēdzam
                from Foundation import NSProcessInfo   # type: ignore
                r.activity = NSProcessInfo.processInfo().beginActivityWithOptions_reason_(0x00FFFFFF, "Analītiķis: datu atjaunošana")
            except Exception as e:
                print("Dock:", e)
        if keep_sessions:
            guard = config.app_dir() / "sessions.restoring"   # ja atjaunošana avarē — nākamreiz izlaižam
            if guard.exists():
                print("sesiju atjaunošana izlaista (iepriekšējā reizē neizdevās)")
                try:
                    guard.unlink()
                except OSError:
                    pass
            else:
                try:
                    guard.write_text("1")
                    saved = websession.load([a for a in r.agencies if a not in r.payout] + list(r.payout))
                    n = sum(websession.mac_restore(c) for c in saved.values())
                    r.restored = {a: c for a, c in saved.items() if c}
                    if n:
                        print(f"sesijas atjaunotas: {', '.join(sorted(saved))} ({n} sīkdatnes)")
                except Exception as e:
                    print("sesiju atjaunošana:", str(e)[:160])
                try:
                    guard.unlink()
                except OSError:
                    pass
        r.fill(extra=show)

    use_boot = keep_sessions or config.IS_MAC
    if not use_boot:
        r.fill(extra=show)
    threading.Thread(target=r.watchdog, daemon=True).start()
    kw = {"private_mode": False, "storage_path": str(profile_dir())}
    if config.IS_MAC:
        kw["user_agent"] = MAC_UA
        pass
    if use_boot:
        kw["func"] = boot
    try:
        webview.start(**kw)
    except TypeError:
        kw.pop("user_agent", None)
        try:
            webview.start(**kw)
        except TypeError:
            webview.start(boot) if use_boot else webview.start()
    r.finish_status()
