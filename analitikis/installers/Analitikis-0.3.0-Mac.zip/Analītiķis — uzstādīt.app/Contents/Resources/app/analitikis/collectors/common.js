/* Analītiķis — datu savācējs. Darbojas aģentūras lapā (ar lietotāja sesiju) un nodod datus
   programmai caur pywebview tiltu. Python šo failu apvieno ar aģentūras failu (sync.py: _script). */
(async () => {
  if (window.__vdRun) return;
  window.__vdRun = true;
  const AG = "__AG__";
  const OPTS = __OPTS__;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  let B;
  if (OPTS.poll) {
    /* Mac: pywebview tilts nestrādā lapās ar stingru drošības politiku (CSP, piem. Adobe) —
       ziņas krājas rindā, un Python tās pats savāc (Runner.pump) un atbild ar window.__vdIn */
    let n = 0;
    window.__vdQ = []; window.__vdCb = {};
    window.__vdOut = () => { const q = window.__vdQ || []; window.__vdQ = []; return JSON.stringify(q); };
    window.__vdIn = (id, ok, val) => { const c = window.__vdCb[id]; delete window.__vdCb[id]; if (c) (ok ? c[0] : c[1])(ok ? val : new Error(val)); };
    const call = (fn) => (...args) => new Promise((res, rej) => { const id = ++n; window.__vdCb[id] = [res, rej]; window.__vdQ.push({ id, fn, args }); });
    B = {};
    for (const fn of ["begin", "put", "progress", "login", "log", "done", "fail"]) B[fn] = call(fn);
  } else {
    for (let i = 0; i < 100 && !(window.pywebview && window.pywebview.api && window.pywebview.api.put); i++) await sleep(100);
    B = window.pywebview && window.pywebview.api;
    if (!B) { window.__vdRun = false; return; }
  }
  const LOGIN = { login: true };
  let curBal = null;                             // šīs atjaunošanas atlikums (izmaksu pārbaudes lēmumam)
  const send = (kind, data) => {
    if (kind === "balance" && data && data.amount != null) curBal = +data.amount;
    return B.put(AG, kind, JSON.stringify(data));
  };
  const say = (msg, pct) => B.progress(AG, String(msg), pct == null ? -1 : pct);
  const iso = (d) => d.toISOString().slice(0, 10);
  const today = OPTS.today;
  /* JSON pieprasījums; ja atbilde nav JSON (pāradresācija uz ielogošanos) — vajag ielogoties */
  async function getj(url, headers = {}) {
    let r;
    for (let a = 0; a < 3; a++) {
      try {
        r = await fetch(url, { credentials: "include", headers: Object.assign({ Accept: "application/json" }, headers) });
      } catch (e) { if (a === 2) throw e; await sleep(1500 * (a + 1)); continue; }
      if (r.status === 429 || r.status >= 500) { if (a === 2) break; await sleep(3000 * (a + 1)); continue; }
      break;
    }
    const path = new URL(url, location.href).pathname;
    if (r.status === 401 || r.status === 403) { B.log(AG, `pieprasījums ${path}: HTTP ${r.status}`); throw LOGIN; }
    const ct = r.headers.get("content-type") || "";
    if (!ct.includes("json")) {
      if (r.redirected || /<html/i.test((await r.text()).slice(0, 300))) { B.log(AG, `pieprasījums ${path}: nav JSON (${r.redirected ? "→ " + new URL(r.url).pathname : "HTML"})`); throw LOGIN; }
      throw new Error(url + ": " + r.status);
    }
    if (!r.ok) throw new Error(url + ": HTTP " + r.status);
    return r.json();
  }
  function monthsBack(fromY, fromM, toY, toM) {   // [[y,m], ...] no jaunākā uz vecāko
    const out = [];
    let y = toY, m = toM;
    while (y > fromY || (y === fromY && m >= fromM)) { out.push([y, m]); m--; if (m < 1) { m = 12; y--; } }
    return out;
  }
  function daysBetween(a, b) {               // ['YYYY-MM-DD', ...] no b uz a
    const out = [];
    const d = new Date(b + "T00:00:00Z"), s = new Date(a + "T00:00:00Z");
    while (d >= s) { out.push(iso(d)); d.setUTCDate(d.getUTCDate() - 1); }
    return out;
  }
  /* HTML lapa kā Document; ja aizveda uz ielogošanos — LOGIN */
  async function getdoc(url, init = {}, loginRe = /log-?in|sign-?in|auth/i) {
    let r;
    for (let a = 0; a < 3; a++) {
      try { r = await fetch(url, Object.assign({ credentials: "include" }, init)); }
      catch (e) { if (a === 2) throw e; await sleep(1500 * (a + 1)); continue; }
      if (r.status === 429 || r.status >= 500) { if (a === 2) break; await sleep(3000 * (a + 1)); continue; }
      break;
    }
    if (r.status === 401 || r.status === 403) { B.log(AG, `pieprasījums ${new URL(url, location.href).pathname}: HTTP ${r.status}`); throw LOGIN; }
    if (r.redirected && loginRe.test(new URL(r.url).pathname)) { B.log(AG, `pieprasījums ${new URL(url, location.href).pathname} → ${new URL(r.url).host}${new URL(r.url).pathname}`); throw LOGIN; }
    if (r.status >= 500) throw new Error(`aģentūras serveris šobrīd neatbild (HTTP ${r.status}, ${new URL(url, location.href).pathname}) — mēģini vēlāk`);
    if (!r.ok) throw new Error(url + ": HTTP " + r.status);
    const html = await r.text();
    const doc = new DOMParser().parseFromString(html, "text/html");
    doc.__url = r.url;
    return doc;
  }
  const txt = (el) => (el ? (el.innerText || el.textContent || "") : "").replace(/\s+/g, " ").trim();
  /* "$1,234.56" / "€0.27" / "0,74" / "(0.10)" -> skaitlis */
  function money(s) {
    s = String(s == null ? "" : s).replace(/\s/g, "");
    const neg = /^\(.*\)$/.test(s) || /^-/.test(s) || /^[^\d]*-/.test(s);
    s = s.replace(/[^\d.,]/g, "");
    if (/^\d{1,3}(,\d{3})+$/.test(s)) s = s.replace(/,/g, "");              // 1,535 — tūkstoši
    else if (s.includes(",") && !s.includes(".")) s = s.replace(",", ".");  // 0,74 — decimāldaļa
    else s = s.replace(/,/g, "");
    const v = parseFloat(s);
    return isNaN(v) ? 0 : (neg ? -v : v);
  }
  const MON = { jan: 1, feb: 2, mar: 3, apr: 4, may: 5, jun: 6, jul: 7, aug: 8, sep: 9, oct: 10, nov: 11, dec: 12 };
  const pad = (n) => String(n).padStart(2, "0");
  const ymd = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  const localIso = (d) => ymd(d.getFullYear(), d.getMonth() + 1, d.getDate());
  /* Datums dažādos formātos -> "YYYY-MM-DD" (vai "" ja neizdevās) */
  function pdate(s) {
    s = String(s || "").trim();
    let m;
    if ((m = s.match(/(\d{4})-(\d{2})-(\d{2})/))) return ymd(+m[1], +m[2], +m[3]);
    if ((m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/))) return ymd(+m[3], +m[1], +m[2]);           // 09/28/2026
    if ((m = s.match(/(\d{1,2})[-\s.]+([A-Za-z]{3,})[a-z]*[-\s.,]+(\d{4})/))) {                  // 02-Sep-2026, 07 October 2026
      const mo = MON[m[2].slice(0, 3).toLowerCase()]; if (mo) return ymd(+m[3], mo, +m[1]);
    }
    if ((m = s.match(/([A-Za-z]{3,})[a-z]*[\s.]+(\d{1,2}),?\s+(\d{4})/))) {                     // Oct.22, 2026, July 7, 2026
      const mo = MON[m[1].slice(0, 3).toLowerCase()]; if (mo) return ymd(+m[3], mo, +m[2]);
    }
    return "";
  }
  const monthEnd = (y, m) => ymd(y, m, new Date(y, m, 0).getDate());
  /* Pārdošanu rindas pa porcijām: o = {batch} vai {start, end}, + {currency, derive} */
  async function sendRows(rows, o = {}) {
    const N = 500;
    if (!rows.length) { await send("rows", Object.assign({}, o, { rows: [], first: true, last: true })); return; }
    for (let i = 0; i < rows.length; i += N)
      await send("rows", Object.assign({}, o, { rows: rows.slice(i, i + N), first: i === 0, last: i + N >= rows.length }));
  }
  /* ---- izmaksas (3. daļa) ----
     tableObjs: tabula, kuras virsraksta rindā ir visi `need` (regex) → [{kolonnas nosaukums: teksts}]; tikai pašas tabulas rindas.
     Saņēmēja datus (PayPal e-pasts u.c.) nesūtām: rindās tikai datums, summa, valūta, statuss. */
  function tableObjs(doc, need) {
    for (const t of doc.querySelectorAll("table")) {
      if (t.parentElement && t.parentElement.closest("table")) continue;
      const rows = [...t.rows];
      const hi = rows.findIndex((tr) => need.every((re) => re.test(txt(tr))));
      if (hi < 0) continue;
      const h = [...rows[hi].cells].map((c) => txt(c).toLowerCase());
      return rows.slice(hi + 1).map((tr) => {
        const o = {};
        [...tr.cells].forEach((c, i) => { o[h[i] || "c" + i] = txt(c); });
        return o;
      }).filter((o) => Object.keys(o).length >= 2);
    }
    return null;
  }
  const pick = (o, re) => { for (const k in o) if (re.test(k)) return o[k]; return ""; };
  const curOf = (s, dflt = "USD") => (/€|eur/i.test(s) ? "EUR" : /£|gbp/i.test(s) ? "GBP" : /\$|usd/i.test(s) ? "USD" : dflt);
  /* izmaksu nolasīšana nekad neaptur pārdošanu savākšanu: kļūda → žurnālā */
  async function payoutsSafe(fn) {
    /* izmaksas lasām tikai, ja: vēstures vēl nav / pilnā ielāde (payouts_full), atlikums kopš pēdējās pārbaudes
       samazinājies (= bijusi izmaksa) vai pagājusi nedēļa (pay_due). Citādi — izlaižam (ātrumam). */
    const drop = curBal != null && OPTS.pay_bal != null && curBal < +OPTS.pay_bal - 0.01;
    if (!(OPTS.payouts_full || OPTS.pay_due || drop)) return;
    if (drop) B.log(AG, `izmaksas: atlikums samazinājies (${OPTS.pay_bal} → ${curBal}) — pārbaudu`);
    try { say("izmaksas", 97); await fn(); await send("pay_checked", {}); }
    catch (e) { if (e && e.login) { B.log(AG, "izmaksas: vajag ielogoties (izlaižu)"); return; } B.log(AG, "izmaksas: " + ((e && e.message) || e)); }
  }
  async function sendPayouts(rows, o = {}) {
    rows = rows.filter((r) => r.date && r.amount);
    B.log(AG, `izmaksas: ${rows.length}${rows.length ? ` (${rows[rows.length - 1].date} … ${rows[0].date})` : ""}`);
    if (rows.length) await send("payouts", Object.assign({ full: true }, o, { rows }));
  }
  const sendPayInfo = (o) => send("payout_info", o);
  /* ---- portfelis (test42): cik failu aģentūrā ir pārdošanā; reizi dienā (OPTS.port_due). Nekad neaptur pārdošanu
     savākšanu. tries = [[avots, async () => skaitlis | null], …] — pirmais, kas atrod; katrs mēģinājums žurnālā. ---- */
  const numOf = (s) => { const v = parseInt(String(s == null ? "" : s).replace(/[^\d]/g, ""), 10); return isNaN(v) ? null : v; };
  const PORT_RE = [
    /(?:online|approved|accepted|active|live|published)\s+(?:files|images|photos|items|assets|content)\b[^\d]{0,20}(\d[\d,.  ]{0,9}\d|\d)/i,
    /(?:files|images|photos|items|assets)\s+(?:online|on sale|for sale|in sale|approved|accepted|live|published)\b[^\d]{0,20}(\d[\d,.  ]{0,9}\d|\d)/i,
    /active in sale[^\d]{0,20}(\d[\d,.  ]{0,9}\d|\d)/i,
    /(\d[\d,. ]{0,9}\d)\s+(?:files|images|photos|items)\s+(?:online|on sale|for sale|in sale|approved|live)\b/i,
    /(?:portfolio|total files|total images|my files)\s*(?:size)?\s*[:(]\s*(\d[\d,. ]{0,9}\d|\d)/i,
  ];
  function countIn(text, res = PORT_RE) {
    for (const re of res) { const m = String(text || "").match(re); if (m) { const n = numOf(m[1]); if (n) return n; } }
    return null;
  }
  /* pirmā skaitliskā vērtība zem atslēgas, kas atbilst re (līdz 6 līmeņiem dziļi) */
  function countKey(obj, re) {
    let out = null;
    (function walk(o, d) {
      if (out != null || !o || typeof o !== "object" || d > 6) return;
      for (const k in o) {
        const v = o[k];
        if (re.test(k) && (typeof v === "number" || /^\d[\d,]*$/.test(String(v))) && numOf(v) > 0) { out = numOf(v); return; }
      }
      for (const k in o) walk(o[k], d + 1);
    })(obj, 0);
    return out;
  }
  const keysOf = (o) => (o && typeof o === "object" ? Object.keys(o).slice(0, 30).join(",") : typeof o);
  /* nav atrasts → žurnālā īsi teksta fragmenti ar skaitļiem pie vārdiem images/files/portfolio… (avotu labošanai) */
  function portHint(src, text) {
    const out = [];
    const re = /[^\n.|]{0,40}\b(images?|files?|photos?|items?|assets?|portfolio|approved|online|uploads?|content|in sale|on sale)\b[^\n.|]{0,40}/gi;
    let m;
    while ((m = re.exec(String(text || ""))) && out.length < 5) {
      const s = m[0].replace(/\S+@\S+/g, "…").replace(/\s+/g, " ").trim();
      if (/\d/.test(s) && !out.includes(s)) out.push(s.slice(0, 90));
    }
    B.log(AG, `portfelis: ${src} — mājieni: ${out.length ? out.join(" ‖ ") : "nav; teksta sākums: " + String(text || "").replace(/\S+@\S+/g, "…").replace(/\s+/g, " ").slice(0, 160)}`);
  }
  const portPage = async (url, res) => { const t = txt((await getdoc(url)).body); const n = countIn(t, res); if (!n) portHint(url, t); return n; };
  const PKEY = /^(approved|accepted|online|active|live|published|total)(_?(files|images|items|content|assets|count|total|resources|media))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources|media|items)_?(count|total|size)$|^portfolio(_?size)?$|^(count|total_?count)$/i;
  async function portJson(url, H = {}, re = PKEY) {
    const j = await getj(url, H);
    const n = countKey(j, re);
    if (!n) B.log(AG, `portfelis: ${new URL(url, location.href).pathname} atslēgas: ${keysOf(j && (j.data || j))}`);
    return n;
  }
  /* ---- test44: JS lapas (SPA), kuru skaitļi parādās tikai pēc zīmēšanas. Atveram tās pašas vietnes lapu neredzamā
     rāmī (sandbox — nedrīkst pārvietot galveno logu), gaidām, kamēr test(teksts, doc) atgriež vērtību. use(fr) — darbs
     ar atvērto lapu (klikšķi u.c.), pirms rāmis tiek noņemts. Cits domēns / aizliegts rāmī → kļūda žurnālā. ---- */
  async function framed(url, test, ms = 25000, use = null) {
    const f = document.createElement("iframe");
    f.setAttribute("sandbox", "allow-scripts allow-same-origin allow-forms");
    f.style.cssText = "position:fixed;left:-6000px;top:0;width:1400px;height:1000px;opacity:0;pointer-events:none;border:0";
    f.src = url;
    (document.body || document.documentElement).appendChild(f);
    let last = "";
    try {
      const t0 = Date.now();
      while (Date.now() - t0 < ms) {
        await sleep(700);
        let d = null;
        try { d = f.contentDocument; } catch (_) { throw new Error("rāmī cits domēns"); }
        if (!d || !d.body) continue;
        last = d.body.innerText || "";
        const v = test(last, d);
        if (v != null && v !== false) return use ? await use({ doc: d, win: f.contentWindow, val: v, text: () => (d.body.innerText || "") }) : v;
      }
      portHint(new URL(url, location.href).pathname + " (rāmī)", last);
      return null;
    } finally { f.remove(); }
  }
  /* API adreses, ko lapa izsauc (bez parametriem) — avotu atklāšanai nākamajām versijām */
  function apiSeen(win, re = /api|ajax|xhr|graphql|json/i, n = 12) {
    try {
      const out = [...new Set(win.performance.getEntriesByType("resource").map((e) => { const u = new URL(e.name); return u.host + u.pathname; })
        .filter((s) => re.test(s)))].slice(0, n);
      B.log(AG, "lapas API: " + (out.join(" · ") || "nav"));
    } catch (_) { /* */ }
  }
  const sumAll = (text, re) => { let s = 0, m; const g = new RegExp(re.source, re.flags.includes("g") ? re.flags : re.flags + "g"); while ((m = g.exec(text))) s += numOf(m[1]) || 0; return s || null; };
  const clickText = (doc, re, sel = "a, button, [role=tab], [role=button], [role=option], li, span, div") => {
    const el = [...doc.querySelectorAll(sel)].filter((e) => re.test((e.innerText || e.textContent || "").trim()) && (e.innerText || "").length < 60)
      .sort((a, b) => (a.innerText || "").length - (b.innerText || "").length)[0];
    if (el) el.click();
    return !!el;
  };
  /* saite pēc teksta (piem. "My storefront") — lapā vai dokumentā; atgriež pilnu adresi */
  const hrefOf = (root, re, hre = null) => { const a = [...root.querySelectorAll("a[href]")].find((x) => (re.test(txt(x)) || re.test(x.getAttribute("aria-label") || "")) && (!hre || hre.test(x.getAttribute("href"))));
    return a ? new URL(a.getAttribute("href"), location.href).href : null; };
  /* ---- test44: rāmī daļa lapu netiek rādītas (Adobe, Zoonar) un publiskās lapas ir citā domēnā (iStock) → pats aģentūras
     logs pāriet uz lapu, kur skaitlis redzams; tur skripts to nolasa (window.name saglabājas arī citā domēnā). ---- */
  async function portNav(url, reSrc, src, sum = false) {
    if (!OPTS.port_due) return null;
    const task = { re: reSrc, src, sum, t: Date.now(), host: new URL(url, location.href).hostname, url: new URL(url, location.href).href };
    window.name = "__vdPort:" + JSON.stringify(task);
    try { await send("port_nav", task); } catch (_) { /* */ }      // citā domēnā window.name pazūd (Safari)
    B.log(AG, "portfelis: atveru " + String(url).replace(/\?.*$/, ""));
    location.href = url;
    return { navigated: true };
  }
  async function portNavDone() {
    let o = null;
    if (String(window.name || "").startsWith("__vdPort:")) { try { o = JSON.parse(window.name.slice(9)); } catch (_) { /* */ } }
    if (!o && OPTS.port_nav && OPTS.port_nav.host === location.hostname) o = OPTS.port_nav;
    if (!o) return false;
    /* lapa pāradresēja citur (Envato → "/") — vienreiz atveram mērķa adresi vēlreiz */
    if (o.url && location.pathname !== new URL(o.url).pathname && !o.again && Date.now() - o.t < 180000) {
      o.again = 1;
      window.name = "__vdPort:" + JSON.stringify(o);
      try { await send("port_nav", o); } catch (_) { /* */ }
      await sleep(3000);
      if (location.pathname !== new URL(o.url).pathname) { location.href = o.url; return "nav"; }
    }
    window.name = "";
    try { await send("port_nav", null); } catch (_) { /* */ }
    if (Date.now() - o.t > 180000) return false;
    const re = new RegExp(o.re, "i");
    let n = null, t = "";
    /* sīkdatņu paziņojums var aizsegt saturu — "noraidīt"/"tikai nepieciešamās", citādi "pieņemt" */
    const cookieBtn = () => { const bs = [...document.querySelectorAll("button, a, [role=button]")];
      const b = bs.find((x) => /^(reject( all)?|only (necessary|essential)|necessary only|decline)$/i.test((x.innerText || "").trim())) ||
        bs.find((x) => /^(accept( all)?|agree|allow all|got it)$/i.test((x.innerText || "").trim())); if (b) b.click(); };
    for (let i = 0; i < 60 && !n; i++) {
      if (i === 4) cookieBtn();
      t = (document.body && document.body.innerText) || "";
      n = o.sum ? sumAll(t, re) : numOf((t.match(re) || [])[1]);
      if (!n) await sleep(500);
    }
    if (n) await send("portfolio", { files: n, src: o.src });
    else portHint(location.pathname + " (lapā)", t);
    if (typeof portPageExtra === "function") {        // aģentūras papildu darbs portfeļa lapā (Envato — sīktēli)
      try { await portPageExtra(); } catch (e) { B.log(AG, "portfeļa lapa: " + String((e && e.message) || e).slice(0, 120)); }
    }
    return true;
  }
  async function portfolioSafe(tries) {
    if (!OPTS.port_due) return;
    for (const [src, fn] of tries) {
      try {
        const n = await fn();
        if (n && n > 0) { await send("portfolio", { files: n, src }); return n; }
        B.log(AG, `portfelis: ${src} — nav atrasts`);
      } catch (e) {
        if (e && e.login) { B.log(AG, `portfelis: ${src} — lapa prasa ielogoties (izlaižu)`); continue; }
        B.log(AG, `portfelis: ${src} — ${String((e && e.message) || e).slice(0, 120)}`);
      }
    }
  }
  /* ---- aģentūras kods ---- */
  __COLLECT__
  /* ------------------------ */
  /* Ielogošanās lapā fonā neko nepieprasām: aģentūras katrā pāradresācijā uz /login izsniedz jaunu formas
     zīmi (CSRF), un lietotāja atvērtā forma tad tiek klusi noraidīta (Bigstock 2026-10-29). */
  /* "Atcerēties mani" / "Trust this device" ķeksis (arī 2FA lapā, kur paroles lauka nav) — sesija pārdzīvo programmas
     restartu. Tikai ķeksis ar šādu tekstu, vienreiz lapā; neko nespiež un nesūta. */
  function tickRemember() {
    if (window.__vdRem) return;
    const REM = /remember|keep me (signed|logged)|stay (signed|logged)|trust this (device|browser|computer)|don.?t ask (again|on this)|angemeldet bleiben|atcerēties|paturēt/i;
    for (const c of document.querySelectorAll("input[type=checkbox]")) {
      if (c.checked || c.disabled) continue;
      const lab = (c.labels && c.labels[0] ? c.labels[0].innerText : "") || (c.closest("label") ? c.closest("label").innerText : "") ||
        c.getAttribute("aria-label") || c.name || c.id || "";
      if (!REM.test(lab) || /newsletter|terms|privacy|offer|subscribe/i.test(lab)) continue;
      try { c.click(); } catch (_) { /* */ }
      if (!c.checked) { c.checked = true; c.dispatchEvent(new Event("change", { bubbles: true })); }
      window.__vdRem = true;
      B.log(AG, "atzīmēts: " + lab.trim().slice(0, 40));
    }
  }
  function onLoginPage() {
    try { tickRemember(); } catch (_) { /* */ }
    if (/(^|\/)(log-?in|sign-?in|sign_in|signin)(\/|$|\.)/i.test(location.pathname)) return true;
    /* "cilvēka" pārbaude (HUMAN/PerimeterX "Press & Hold", Cloudflare u.c.) — lapa pati ir pārbaude: neko nepieprasām */
    if (document.querySelector("#px-captcha, #challenge-form") ||
        /press\s*&\s*hold|access to this page has been denied|verify you are (a )?human|checking your browser/i.test(document.title + " " + txt(document.body).slice(0, 1500))) {
      B.log(AG, "lapā cilvēka pārbaude — gaidu (fonā nekas netiek pieprasīts)");
      return true;
    }
    /* tikai tiešām redzams paroles lauks: ekrānā, ne caurspīdīgs, ne paslēptā (aizvērtā) logā */
    const vw = innerWidth, vh = innerHeight;
    const seen = (el) => {
      const r = el.getBoundingClientRect();
      if (!(r.width > 0 && r.height > 0) || r.right <= 0 || r.bottom <= 0 || r.left >= vw || r.top >= vh) return false;
      for (let e = el; e && e.nodeType === 1; e = e.parentElement) {
        const st = getComputedStyle(e);
        if (st.display === "none" || st.visibility === "hidden" || +st.opacity === 0 || e.getAttribute("aria-hidden") === "true") return false;
      }
      return true;
    };
    const pw = [...document.querySelectorAll('input[type="password"]')];
    const hit = pw.find(seen);
    if (pw.length) B.log(AG, `paroles lauki lapā: ${pw.length}, redzams: ${hit ? "jā" : "nē"}`);
    return !!hit;
  }
  try {
    const ok = await B.begin(AG, location.href);
    if (!ok) return;
    const pd = await portNavDone();
    if (pd === "nav") return;
    if (pd) { await B.done(AG, "{}"); return; }
    if (onLoginPage()) throw LOGIN;
    const res = await collect();
    if (res && res.navigated) return;
    await B.done(AG, JSON.stringify(res || {}));
  } catch (e) {
    if (e && e.login) {
      B.log(AG, "vajag ielogoties? lapa: " + location.host + location.pathname);   // bez parametriem (tajos var būt žetoni)
      await B.login(AG, location.href);
    }
    else await B.fail(AG, String((e && (e.message || e)) || "?"));
  } finally {
    window.__vdRun = false;
  }
})();
