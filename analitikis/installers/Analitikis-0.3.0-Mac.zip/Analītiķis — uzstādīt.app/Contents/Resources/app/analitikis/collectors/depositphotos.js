/* Depositphotos: depositphotos.com/sales.html — tabula ar katru pārdošanu un oriģinālo faila nosaukumu */
async function collect() {
  if (!/(^|\.)depositphotos\.com$/.test(location.hostname)) throw LOGIN;

  function parse(doc) {
    for (const t of doc.querySelectorAll("table")) {
      const head = [...t.querySelectorAll("tr")].find((tr) => /File ID/i.test(txt(tr)) && /Net/i.test(txt(tr)));
      if (!head) continue;
      const h = [...head.cells].map((c) => txt(c).toLowerCase());
      const ix = (re) => h.findIndex((x) => re.test(x));
      const c = { id: ix(/file id/), fn: ix(/filename/), date: ix(/^date/), size: ix(/size/), method: ix(/method/), net: ix(/net/) };
      const out = [];
      for (const tr of t.querySelectorAll("tr")) {
        if (tr === head) continue;
        const v = [...tr.cells];
        if (v.length < 5) continue;
        const day = pdate(txt(v[c.date]));
        if (!day) continue;
        const img = tr.querySelector("img");
        const id = txt(v[c.id]);
        const fn = txt(v[c.fn]);
        /* "RSM Subscription" — Revenue Share Program: abonementu ieņēmumu daļa (mēneša maksājums, nevis bilde) */
        if (/^RSM\b/i.test(fn) || (/subscription/i.test(fn) && !/\.\w{3,4}$/.test(fn))) {
          out.push({ day, id: "other-rsm", title: "Depositphotos — RSM (abonementu ieņēmumu daļa)", amount: money(txt(v[c.net])),
            cnt: 0, kind: "other", license: fn });
          continue;
        }
        out.push({ day, id, filename: fn, amount: money(txt(v[c.net])), cnt: 1, kind: "sale",
          license: [txt(v[c.method]), txt(v[c.size])].filter(Boolean).join(" · "),
          thumb: img ? (img.getAttribute("src") || img.getAttribute("data-src") || "").replace(/^\/\//, "https://").replace("/i/110/", "/i/450/") : "",
          url: id ? `https://depositphotos.com/${id}/stock-photo.html` : "" });
      }
      return out;
    }
    return null;
  }

  const doc = await getdoc("/sales.html");
  let first = parse(doc);
  if (!first) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Depositphotos: pārdošanu tabula nav atrasta");
  }
  const bm = txt(doc.body).match(/Balance:\s*\$\s*([\d.,]+)/i);
  if (bm) await send("balance", { amount: money(bm[1]), currency: "USD" });

  /* lapas: /sales/page2.html … /sales/pageN.html (pēdējā numurs — no lappušu saitēm) */
  const sig = (r) => r.slice(0, 3).map((x) => x.id + x.day).join(",");
  let pages = 1;
  for (const a of doc.querySelectorAll('a[href*="/sales/page"]')) {
    const m = (a.getAttribute("href") || "").match(/\/sales\/page(\d+)\.html/);
    if (m) pages = Math.max(pages, +m[1]);
  }
  const since = OPTS.mode === "full" ? "0000-00-00" : OPTS.since;
  let rows = first.filter((x) => x.day >= since);
  if (first.length && first[first.length - 1].day >= since) {
    let prev = sig(first);
    for (let pg = 2; pg <= pages; pg++) {
      say(`${pg}/${pages}`, Math.round((pg / pages) * 90));
      const r = parse(await getdoc(`/sales/page${pg}.html`)) || [];
      if (!r.length || sig(r) === prev) break;
      prev = sig(r);
      rows = rows.concat(r.filter((x) => x.day >= since));
      if (r[r.length - 1].day < since) break;
      await sleep(250);
    }
  }
  const start = OPTS.mode === "full" ? (rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today) : since;
  await sendRows(rows, { start, end: today });
  /* izmaksas: jāpieprasa (tikai LASĀM /request-earnings.html); vēsture /sales/payout.html (maksājuma datums) */
  await payoutsSafe(async () => {
    const rq = txt((await getdoc("/request-earnings.html")).body);
    const av = rq.match(/Available to withdraw:?\s*\$\s*([\d,.]+)/i);
    const mn = rq.match(/minimum withdrawal amount is\s*\$\s*([\d,.]+)/i);
    await sendPayInfo({ available: av ? money(av[1]) : null, min: mn ? money(mn[1]) : null, currency: "USD" });
    const t = tableObjs(await getdoc("/sales/payout.html"), [/date/i, /amount/i]) || [];
    await sendPayouts(t.map((o) => ({ date: pdate(pick(o, /payment date/)) || pdate(pick(o, /date/)), amount: money(pick(o, /amount/)),
      currency: "USD", status: pick(o, /status/), ref: pick(o, /^id$/) })).filter((r) => !r.status || /process|paid|complet/i.test(r.status)));
  });
  const ONL = [/\bonline[:\s]{1,3}(\d[\d,]*)/i, /(\d[\d,]*)\s+online\b/i, ...PORT_RE];
  await portfolioSafe([
    ["sales", async () => countIn(txt(doc.body), ONL)],
    ["sākumlapa", () => portPage("/", ONL)],
    ["files", () => portPage("/files.html", ONL)],
  ]);
  return { rows: rows.length, pages };
}
