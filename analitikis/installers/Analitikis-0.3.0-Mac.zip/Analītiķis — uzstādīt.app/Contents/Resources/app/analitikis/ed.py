"""RF / ED (redakcionāla) pazīme katrai bildei — Beta funkcija "RF/ED šķirošana" (lietotājs 2026-10-31).

Avoti pēc ticamības (pirmais, kas der, nosaka visu bilžu grupu — visas tās pašas bildes kopijas):
  user    — lietotājs pats atzīmēja (ed_user; saglabājas, ir rezerves kopijā);
  noed    — bilde ir aģentūrā, kas ED nepieņem (iestatījums sales_no_ed) → droši RF;
  title   — nosaukums sākas ar "Vieta, Valsts - datums:" (redakcionālo bilžu paraugs) → ED, minējums;
  default — nekas no augšējā → RF (pieņemts).
Rezultāts — tabula ed_cls (pārrēķina, kad mainās bildes, lietotāja atzīmes vai iestatījums)."""
from __future__ import annotations

import datetime as dt
import re

from . import config, db

NO_ED_DEFAULT = ["envato", "envato_market", "magnific", "pixta", "zoonar", "ingram"]

SCHEMA = """
CREATE TABLE IF NOT EXISTS ed_user(agency TEXT, agency_item_id TEXT, ed INTEGER, at TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE TABLE IF NOT EXISTS ed_cls(agency TEXT, agency_item_id TEXT, ed INTEGER, src TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE INDEX IF NOT EXISTS ed_cls_ed ON ed_cls(ed);
"""

_MON = r"(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?"
TITLE_RE = re.compile(
    r"^\s*[A-Z][\w .'’()/-]{1,60},\s*[A-Z][\w .'’()-]{1,40}\s*[-–—]\s*"
    r"(?:" + _MON + r"\s+\d{1,2},?\s+\d{4}|\d{1,2}\s+" + _MON + r",?\s+\d{4}|\d{1,2}[./-]\d{1,2}[./-]\d{2,4}|\d{4}-\d{2}-\d{2}|"
    + _MON + r"\s+\d{4}|\d{4})\s*[:.]", re.I)


def enabled() -> bool:
    return not config.get("sales_beta_off") and bool(config.get("sales_beta_ed"))


def no_ed() -> list[str]:
    v = config.get("sales_no_ed")
    return list(v) if isinstance(v, list) else list(NO_ED_DEFAULT)


def _ensure(c) -> None:
    c.executescript(SCHEMA)


def _sig(c) -> str:
    a = c.execute("SELECT COUNT(*), MAX(rowid) FROM assets").fetchone()
    u = c.execute("SELECT COUNT(*), MAX(at) FROM ed_user").fetchone()
    return f"{a[0]}|{a[1]}|{u[0]}|{u[1]}|{','.join(sorted(no_ed()))}"


def refresh(force: bool = False) -> None:
    """Pārrēķina ed_cls, ja kaut kas mainījies (lēti pārbaudīt — katrā pieprasījumā)."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        _ensure(c)
        sig = _sig(c)
        if not force and db.get_state("_ed", "sig") == sig:
            return
        user = {(r[0], r[1]): r[2] for r in c.execute("SELECT agency, agency_item_id, ed FROM ed_user WHERE ed IS NOT NULL")}
        noed = set(no_ed())
        groups: dict = {}
        for ag, iid, gid, title in c.execute(
                "SELECT agency, agency_item_id, gid, title FROM assets WHERE COALESCE(media,'')!='other'"):
            groups.setdefault(gid or f"{ag}|{iid}", []).append((ag, iid, title or ""))
        out = []
        for mem in groups.values():
            u = [user[(a, i)] for a, i, _ in mem if (a, i) in user]
            if u:
                ed, src = int(u[-1]), "user"
            elif any(a in noed for a, _, _ in mem):
                ed, src = 0, "noed"
            elif any(TITLE_RE.match(t) for _, _, t in mem):
                ed, src = 1, "title"
            else:
                ed, src = 0, "default"
            out.extend((a, i, ed, src) for a, i, _ in mem)
        c.execute("DELETE FROM ed_cls")
        c.executemany("INSERT OR REPLACE INTO ed_cls VALUES(?,?,?,?)", out)
        c.commit()
    db.set_state("_ed", "sig", sig)


def mark(items: list[dict], ed) -> int:
    """Lietotāja atzīme: ed 1 = ED, 0 = RF, None = noņemt manu atzīmi (atpakaļ uz automātisko)."""
    now = dt.datetime.now().isoformat(timespec="seconds")
    n = 0
    with db._lock:
        c = db.conn()
        _ensure(c)
        for it in items or []:
            ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
            if not ag or not iid:
                continue
            # visa grupa — lai vecas pretrunīgas atzīmes kopijām netraucē
            g = c.execute("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
            mem = c.execute("SELECT agency, agency_item_id FROM assets WHERE gid=?", (g[0],)).fetchall() if g and g[0] else [(ag, iid)]
            for a, i in mem:
                c.execute("DELETE FROM ed_user WHERE agency=? AND agency_item_id=?", (a, i))
            if ed is not None:
                c.execute("INSERT OR REPLACE INTO ed_user VALUES(?,?,?,?)", (ag, iid, int(ed), now))
            n += 1
        c.commit()
    refresh(force=True)
    return n


def info(agency: str, agency_item_id: str) -> dict | None:
    refresh()
    r = db.q1("SELECT ed, src FROM ed_cls WHERE agency=? AND agency_item_id=?", (agency, str(agency_item_id)))
    return {"ed": r["ed"], "src": r["src"]} if r else None


def decorate(rows: list[dict], key=lambda r: (r.get("agency"), r.get("agency_item_id"))) -> None:
    """Pievieno rindām ed/ed_src (tikai, ja funkcija ieslēgta)."""
    if not rows:
        return
    refresh()
    ks = [key(r) for r in rows]
    m = {}
    for a, i in set(ks):
        if a and i:
            x = db.q1("SELECT ed, src FROM ed_cls WHERE agency=? AND agency_item_id=?", (a, str(i)))
            if x:
                m[(a, i)] = (x["ed"], x["src"])
    for r, k in zip(rows, ks):
        if k in m:
            r["ed"], r["ed_src"] = m[k]
