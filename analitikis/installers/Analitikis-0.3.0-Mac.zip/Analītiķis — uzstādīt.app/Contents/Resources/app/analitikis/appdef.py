"""Analītiķa apraksts kopīgajam kodam core/ (noteikumi §10, §12)."""
from __future__ import annotations

from pathlib import Path

from core import app as core_app

from . import APP_NAME, VERSION
from .i18n import MSG

ROOT = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "sales_agencies": [],               # pieslēgtās aģentūras (§4 identifikatori)
    "sales_autosync_hours": 6,          # atverot programmu, atjaunot, ja dati vecāki (0 = nekad)
    "sales_webview_main": False,        # Windows: galvenais logs pywebview (nevis Edge/Chrome)
    "sales_parallel": 2,                # cik aģentūras atjaunot vienlaikus (pārējās gaida rindā)
    # izmaksas (3. daļa): {aģentūra: {mode: auto|request|"", min: skaitlis|""}} — maina noklusējumu (payouts.PAYOUT)
    "sales_payout": {},
    "sales_keepalive": True,            # sesiju uzturēšana reizi dienā (keepalive.py; ja vajag ielogoties — neko nedara)
    "sales_restore_off": False,
    # Beta funkcijas (noteikumi §5): sales_beta_off — neizmantot nevienu (un atjauninājumi tikai stabilās versijas)
    "sales_beta_off": False,
    "sales_beta_ed": False,             # RF/ED šķirošana Pārdošanās
    "sales_beta_portfolio": True,       # portfeļa lielums un analīze (Aģentūras)
    "sales_no_ed": ["envato", "envato_market", "magnific", "pixta", "zoonar", "ingram"],   # aģentūras, kas ED nepieņem (lietotājs)         # Mac: NEatjaunot saglabātās sesijas (test44: atjauno pēc noklusējuma, ar drošības tīklu)
    "sales_payout_remind": True,
    "sales_remind_when": "lastday",     # atgādinājums programmā: lastday | threshold | day (test53)
    "sales_remind_day": 28,
    # atjaunošanas biežums: {aģentūra: always | day | week}; tukšs = noklusējums (freshness.DEFAULT)
    "sales_refresh": {},
    "sales_portfolio_names": {},        # publiskā portfeļa vārds, ja aģentūra skaitu rāda tikai tur (iStock); test44        # mēneša pēdējā dienā — "var pieprasīt izmaksu" programmā
    # e-pasta atgādinājums (parole — tikai drošajā glabātuvē, ieraksts "smtp", noteikumi §3)
    "sales_mail_on": False,
    "sales_mail_to": "",
    "sales_mail_when": "lastday",       # lastday — mēneša pēdējā dienā; threshold — tiklīdz sasniegts minimums; day — izvēlētā dienā
    "sales_mail_day": 28,
    "sales_mail_hour": 9,
    "sales_smtp_host": "smtp.gmail.com",
    "sales_smtp_port": 587,
    "sales_smtp_user": "",
}


def _validate(vals: dict) -> dict:
    if "sales_remind_when" in vals and vals["sales_remind_when"] not in ("lastday", "threshold", "day"):
        vals.pop("sales_remind_when")
    if "sales_remind_day" in vals:
        try:
            vals["sales_remind_day"] = max(1, min(31, int(vals["sales_remind_day"])))
        except (TypeError, ValueError):
            vals.pop("sales_remind_day")
    for k in ("sales_beta_off", "sales_beta_ed", "sales_beta_portfolio"):
        if k in vals:
            vals[k] = bool(vals[k])
    if "sales_no_ed" in vals:
        v = vals["sales_no_ed"]
        vals["sales_no_ed"] = [str(a)[:30] for a in v if isinstance(a, str)] if isinstance(v, list) else None
        if vals["sales_no_ed"] is None:
            vals.pop("sales_no_ed")
    if vals.get("sales_beta_off"):              # "Neizmantot Beta funkcijas" → tikai stabilās versijas (§5, §9a)
        vals["update_channel"] = "stable"
    if "sales_autosync_hours" in vals:
        try:
            vals["sales_autosync_hours"] = max(0, int(vals["sales_autosync_hours"]))
        except (TypeError, ValueError):
            vals.pop("sales_autosync_hours")
    if "sales_parallel" in vals:
        try:
            vals["sales_parallel"] = max(1, min(4, int(vals["sales_parallel"])))
        except (TypeError, ValueError):
            vals.pop("sales_parallel")
    if "sales_payout" in vals:
        clean = {}
        for ag, v in (vals["sales_payout"] or {}).items() if isinstance(vals["sales_payout"], dict) else []:
            if not isinstance(v, dict):
                continue
            o = {}
            if v.get("mode") in ("auto", "request", ""):
                o["mode"] = v["mode"]
            if v.get("min") not in (None, ""):
                try:
                    o["min"] = max(0.0, float(v["min"]))
                except (TypeError, ValueError):
                    pass
            if o:
                clean[str(ag)[:30]] = o
        vals["sales_payout"] = clean
    if "sales_refresh" in vals:
        v = vals["sales_refresh"]
        from .freshness import valid
        vals["sales_refresh"] = {str(k)[:30]: m for k, m in (v.items() if isinstance(v, dict) else []) if valid(m)}
    if "sales_portfolio_names" in vals:
        v = vals["sales_portfolio_names"]
        vals["sales_portfolio_names"] = {str(k)[:30]: str(n).strip()[:80] for k, n in (v.items() if isinstance(v, dict) else []) if str(n).strip()}
    for k, lo, hi in (("sales_mail_day", 1, 31), ("sales_mail_hour", 0, 23), ("sales_smtp_port", 1, 65535)):
        if k in vals:
            try:
                vals[k] = max(lo, min(hi, int(vals[k])))
            except (TypeError, ValueError):
                vals.pop(k)
    if "sales_mail_when" in vals and vals["sales_mail_when"] not in ("lastday", "threshold", "day"):
        vals.pop("sales_mail_when")
    for k in ("sales_mail_to", "sales_smtp_host", "sales_smtp_user"):
        if k in vals:
            vals[k] = str(vals[k] or "").strip()[:200]
    return vals


def _busy() -> bool:
    from . import sync
    return sync.active()


def _webview_main() -> bool:
    from core import config
    return bool(config.get("sales_webview_main"))


APP = core_app.init(core_app.App(
    name=APP_NAME, slug="Analitikis", version=VERSION, ports=(47625, 47626, 47627), api_prefix="sales_",
    web_dir=ROOT / "web", defaults=DEFAULTS, msgs=MSG, busy=_busy, webview_main=_webview_main,
    validate_settings=_validate, icon=ROOT / "assets" / "icon.png"))
