"""Servera ziņojumu tulkojumi: kopīgie (šeit) + moduļa (App.msgs). Saskarnes teksti — web/ i18n failos."""
from __future__ import annotations

from . import app as _app
from . import config

MSG = {
    "error": {"lv": "Kļūda", "en": "Error", "de": "Fehler", "es": "Error", "uk": "Помилка"},
    "forbidden": {"lv": "Nav atļauts", "en": "Forbidden", "de": "Nicht erlaubt", "es": "No permitido", "uk": "Заборонено"},
    "bk_bad": {"lv": "Fails nav šīs programmas rezerves kopija vai ir bojāts.", "en": "The file is not a backup of this program or is damaged.",
               "de": "Die Datei ist keine Sicherung dieses Programms oder ist beschädigt.", "es": "El archivo no es una copia de seguridad de este programa o está dañado.",
               "uk": "Файл не є резервною копією цієї програми або пошкоджений."},
    "bk_other": {"lv": "Šī ir citas programmas rezerves kopija.", "en": "This is a backup of a different program.",
                 "de": "Das ist eine Sicherung eines anderen Programms.", "es": "Es una copia de seguridad de otro programa.", "uk": "Це резервна копія іншої програми."},
}


def T(key: str, **kw) -> str:
    lang = config.get("lang") or "lv"
    m = _app.current().msgs.get(key) or MSG.get(key) or {}
    s = m.get(lang) or (m.get("en") if lang != "lv" else None) or m.get("lv") or key
    try:
        return s.format(**kw)
    except (KeyError, IndexError):
        return s
