"use strict";
/* Kopīgais sākuma banneris (docs/sakuma-banneris.md) — 0.3.1 no analitikis/dev/banner/banner.html (apstiprināts 2026-10-31);
   maģija "trade" (Tirgotājs, §2b) — no tirgotajs/dev/banner/banner.html (apstiprināts 2026-11-16).
   Modulis pirms core.js definē window.BANNER = { img, l10n: {lang: {title, steps[6]}}, face, title, nodes, hubs, wave, titlePos?,
   magic?: "digital"|"trade", wins?, from?, box?, handPlane?, handTail? }.
   CoreBanner.start(lang, version) — rāda; klikšķis aizver; pēc ~6,5 s aizveras pats; drošībai — 15 s. */
window.CoreBanner = (function () {
  const B = window.BANNER || {};
  const CSS = `
  /* Izmēri — tieši kā Vārdotāja banerim (vardotajs/web/app.css "sākuma banneris"): 16:9, ≤800 px, attēls 1600×900 */
    .bn-wrap { position: fixed; inset: 0; z-index: 120; display: grid; place-items: center;
    background: radial-gradient(ellipse at 30% 20%, #23303d, #0f1318 70%); transition: opacity .7s ease; }
  .bn-wrap.hide { opacity: 0; pointer-events: none; }
  .bn { position: relative; width: min(800px, 92vw); aspect-ratio: 16 / 9; border-radius: 14px; overflow: hidden; cursor: pointer;
    box-shadow: 0 30px 80px rgba(0,0,0,.65), 0 0 0 1px rgba(255,255,255,.06); background: #000;
    opacity: 0; transform: scale(.96); transition: opacity .6s ease, transform .8s cubic-bezier(.2,.8,.2,1); }
  .bn-wrap.show .bn { opacity: 1; transform: scale(1); }
  .bn-wrap.hide .bn { transform: scale(1.03); }
  .bn img { position: absolute; inset: 0; width: 100%; height: 100%; object-fit: cover; display: block; }
  .bn canvas { position: absolute; inset: 0; width: 100%; height: 100%; pointer-events: none; }
  .bn-foot { position: absolute; left: 0; right: 0; bottom: 0; padding: 0 14px 9px; pointer-events: none;
    background: linear-gradient(to top, rgba(0,0,0,.72), rgba(0,0,0,0)); }
  .bn-row { display: flex; justify-content: space-between; align-items: flex-end; padding-top: 26px; margin-bottom: 6px;
    font-size: 11.5px; color: #d6f4ff; }
  #bnStep { opacity: .9; letter-spacing: .2px; }
  #bnVer { opacity: .6; font-size: 11px; letter-spacing: .6px; }
  .bn-bar { height: 3px; border-radius: 3px; background: rgba(255,255,255,.14); overflow: hidden; }
  .bn-bar i { display: block; height: 100%; width: 0; border-radius: 3px; transition: width .35s ease;
    background: linear-gradient(90deg, #2bb3ff, #6fe3ff, #b8ffd9); box-shadow: 0 0 8px #6fe3ff; }
  /* Tirgotājs (§2b): zaļa josla */
  .bn-wrap.trade .bn-row { color: #dfffe9; }
  .bn-wrap.trade .bn-bar i { background: linear-gradient(90deg, #1fae5c, #5fe89a, #e2ffe9); box-shadow: 0 0 8px #5fe89a; }
  @font-face { font-family: "BannerTitle"; src: url("/core/fonts/BannerSerif-Bold.ttf") format("truetype"); font-weight: 700; }
  @font-face { font-family: "BannerTitleCyr"; src: url("/core/fonts/BannerSerifCyr-Bold.ttf") format("truetype"); font-weight: 700; }
`;
  let LANG = "lv", STEPS = [], L10N = B.l10n || {};
  const FACE = B.face || { x: 0.5, y: 0.3, rx: 0.08, ry: 0.15 };
  const TITLE = B.title || { x0: 0.3, x1: 0.7, y0: 0.74, y1: 0.93 };
  const NODES = B.nodes || [], HUBS = B.hubs || [[0.6, 0.4]], WAVE = B.wave || [0.6, 0.4];
  const MAGIC = B.magic || "digital";   // "digital" — Analītiķis, "trade" — Tirgotājs (§2b)
  const WINS = B.wins || [], FROM = B.from || [[0.6, 0.4]];
  const AT = [0, 0.14, 0.34, 0.54, 0.74, 0.93];
  const DUR = 6500;
  
  /* vietas attēlā (daļas no platuma/augstuma) — šim foto */
  
  const $ = (s) => document.querySelector(s);
  const S = { raf: 0, closing: false, t0: 0, last: 0, rain: [], cards: [], huds: [], pulses: [], flash: 0, wave: -1 };
  let W = 0, H = 0, cx;
  
  function size() {
    const card = $("#bnCard"), cv = $("#bnFx"), r = card.getBoundingClientRect(), d = window.devicePixelRatio || 1;
    W = r.width; H = r.height; cv.width = W * d; cv.height = H * d; cx = cv.getContext("2d"); cx.setTransform(d, 0, 0, d, 0, 0);
    if (MAGIC === "trade") { tInitRain(); initDust(); } else initRain();
    drawTitle();
  }
  /* cik spilgti drīkst zīmēt šajā vietā (0..1): seja, nosaukums, apakšējā josla — klusāk */
  function mask(x, y) {
    const fx = (x / W - FACE.x) / FACE.rx, fy = (y / H - FACE.y) / FACE.ry;
    let m = 1;
    const fd = fx * fx + fy * fy; if (fd < 1) m *= 0.15 + 0.85 * fd;
    const tx = x / W, ty = y / H;
    if (tx > TITLE.x0 && tx < TITLE.x1 && ty > TITLE.y0 - 0.06) m *= Math.max(0, (TITLE.y0 - ty) / 0.06);
    if (ty > 0.86) m *= Math.max(0, (0.93 - ty) / 0.07);
    return Math.max(0, m);
  }
  
  /* ---- 1. "Matrix" lietus: 0 un 1, retumis $ € % un cipari */
  const GLYPH = () => { const r = Math.random(); return r < 0.86 ? (Math.random() < 0.5 ? "0" : "1") : "$€%23456789"[Math.floor(Math.random() * 11)]; };
  function initRain() {
    const fs = Math.max(24, Math.round(W / 24)),   /* 22:03 lietotājs: 2,5× lielāks */ cols = Math.ceil(W / (fs * 1.15));
    S.fs = fs;
    /* 21:58 lietotājs: lietus nebija redzams → visas kolonnas, jau no sākuma pa visu banneri, garākas virknes */
    S.rain = Array.from({ length: cols }, (_, i) => ({ x: i * fs * 1.15 + fs * 0.3, y: Math.random() * H * 1.3, v: 0.045 + Math.random() * 0.08,
      len: 12 + Math.floor(Math.random() * 18), g: Array.from({ length: 30 }, GLYPH), on: Math.random() < 0.9 }));
  }
  function drawRain(dt) {
    const fs = S.fs; cx.font = `${fs}px ui-monospace, Menlo, Consolas, monospace`; cx.textAlign = "center";
    for (const c of S.rain) {
      if (!c.on) { if (Math.random() < 0.01 * dt / 16) { c.on = true; c.y = -c.len * fs; } continue; }
      c.y += c.v * dt;
      if (Math.random() < 0.05) c.g[Math.floor(Math.random() * c.g.length)] = GLYPH();
      for (let i = 0; i < c.len; i++) {
        const y = c.y - i * fs; if (y < -fs || y > H) continue;
        const m = mask(c.x, y); if (m <= 0.01) continue;
        const head = i === 0, a = (head ? 0.6 : 0.3 * (1 - i / c.len) + 0.04) * m;   /* 22:09: caurspīdīgāki */
        cx.fillStyle = head ? `rgba(255,255,255,${a})` : `rgba(205,255,232,${a})`;   /* 22:09: baltāki */
        if (head) { cx.shadowColor = "#e6fff4"; cx.shadowBlur = 6; }
        cx.fillText(c.g[i % c.g.length], c.x, y);
        if (head) cx.shadowBlur = 0;
      }
      if (c.y - c.len * fs > H) { c.on = Math.random() < 0.9; c.y = -Math.random() * H * 0.5; c.v = 0.035 + Math.random() * 0.07; }
    }
  }
  
  /* ---- 2. lidojošas bildes (programmā — lietotāja labāko bilžu sīktēli; šeit — zīmētas ainavas) */
  const SKIES = [["#ffb36b", "#6a4cc2"], ["#7fd3ff", "#2a5fb0"], ["#ffd27a", "#d0577a"], ["#a6f0c6", "#2f7d6b"], ["#c7a6ff", "#3d3a8f"]];
  function spawnCard() {
    const w = W * (0.055 + Math.random() * 0.035), side = Math.random();
    const x = side < 0.55 ? W * (0.02 + Math.random() * 0.22) : W * (0.70 + Math.random() * 0.26);
    return { x, y: H * (0.45 + Math.random() * 0.35), w, h: w * 0.66, vx: (Math.random() - 0.5) * 0.012, vy: -(0.012 + Math.random() * 0.02),
      rot: (Math.random() - 0.5) * 0.5, vr: (Math.random() - 0.5) * 0.00025, life: 0, max: 3800 + Math.random() * 2600,
      sky: SKIES[Math.floor(Math.random() * SKIES.length)], amt: (0.25 + Math.random() * 4.5).toFixed(2), sun: Math.random() };
  }
  function drawCard(q, dt) {
    q.life += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.rot += q.vr * dt;
    const f = q.life / q.max, al = Math.sin(Math.PI * Math.min(1, f)) * mask(q.x, q.y);
    if (al <= 0.01) return;
    cx.save(); cx.translate(q.x, q.y); cx.rotate(q.rot); cx.globalAlpha = 0.42 * al;
    const g = cx.createLinearGradient(0, -q.h / 2, 0, q.h / 2); g.addColorStop(0, q.sky[0]); g.addColorStop(1, q.sky[1]);
    cx.fillStyle = g; cx.fillRect(-q.w / 2, -q.h / 2, q.w, q.h);
    cx.fillStyle = "rgba(255,240,200,.9)"; cx.beginPath(); cx.arc(-q.w * 0.2 + q.sun * q.w * 0.4, -q.h * 0.12, q.h * 0.11, 0, 7); cx.fill();
    cx.fillStyle = "rgba(20,30,50,.75)"; cx.beginPath(); cx.moveTo(-q.w / 2, q.h / 2); cx.lineTo(-q.w * 0.18, -q.h * 0.02); cx.lineTo(q.w * 0.05, q.h * 0.2);
    cx.lineTo(q.w * 0.28, -q.h * 0.1); cx.lineTo(q.w / 2, q.h * 0.18); cx.lineTo(q.w / 2, q.h / 2); cx.fill();
    cx.globalAlpha = 0.85 * al; cx.strokeStyle = "rgba(120,220,255,.9)"; cx.lineWidth = 1; cx.shadowColor = "#6fe3ff"; cx.shadowBlur = 8;
    cx.strokeRect(-q.w / 2, -q.h / 2, q.w, q.h); cx.shadowBlur = 0;
    cx.font = `600 ${Math.max(8, q.h * 0.26)}px system-ui, sans-serif`; cx.textAlign = "left";
    cx.fillStyle = `rgba(110,231,168,${0.95 * al})`; cx.fillText("+$" + q.amt, -q.w / 2, -q.h / 2 - 4);
    cx.restore();
  }
  
  /* ---- 3. caurspīdīgas diagrammas (hologrammas) */
  function spawnHud() {
    /* 22:09 lietotājs: vairāk un lielākas (≈2×) */
    const kind = ["bars", "line", "pie", "bars", "line"][Math.floor(Math.random() * 5)], w = W * (0.14 + Math.random() * 0.08);
    const x = W * (0.01 + Math.random() * 0.80);
    return { kind, x, y: H * (0.30 + Math.random() * 0.40), w, h: w * 0.62, vy: -(0.008 + Math.random() * 0.012), vx: (Math.random() - 0.5) * 0.008,
      life: 0, max: 4200 + Math.random() * 2000, d: Array.from({ length: 7 }, (_, i) => 0.25 + Math.random() * 0.4 + i * 0.05), spin: Math.random() * 6 };
  }
  function drawHud(q, dt) {
    q.life += dt; q.x += q.vx * dt; q.y += q.vy * dt; q.spin += 0.0012 * dt;
    const f = q.life / q.max, al = Math.sin(Math.PI * Math.min(1, f)) * mask(q.x + q.w / 2, q.y + q.h / 2), grow = Math.min(1, q.life / 1400);
    if (al <= 0.01) return;
    cx.save(); cx.translate(q.x, q.y);
    cx.fillStyle = `rgba(40,120,170,${0.14 * al})`; cx.strokeStyle = `rgba(120,220,255,${0.55 * al})`; cx.lineWidth = 1.2;
    cx.beginPath(); cx.roundRect ? cx.roundRect(0, 0, q.w, q.h, 5) : cx.rect(0, 0, q.w, q.h); cx.fill(); cx.stroke();
    const p = q.w * 0.1, bw = (q.w - 2 * p) / q.d.length;
    if (q.kind === "bars") {
      q.d.forEach((v, i) => { const h = (q.h - 2 * p) * v * grow; cx.fillStyle = `rgba(${i > 4 ? "110,231,168" : "111,227,255"},${0.5 * al})`;
        cx.fillRect(p + i * bw + bw * 0.15, q.h - p - h, bw * 0.7, h); });
    } else if (q.kind === "line") {
      cx.strokeStyle = `rgba(111,227,255,${0.8 * al})`; cx.lineWidth = 2.2; cx.beginPath();
      const n = Math.max(2, Math.ceil(q.d.length * grow));
      for (let i = 0; i < n; i++) { const x = p + i * (q.w - 2 * p) / (q.d.length - 1), y = q.h - p - (q.h - 2 * p) * q.d[i]; i ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      cx.stroke();
      for (let i = 0; i < n; i++) { const x = p + i * (q.w - 2 * p) / (q.d.length - 1), y = q.h - p - (q.h - 2 * p) * q.d[i];
        cx.fillStyle = `rgba(210,255,240,${0.9 * al})`; cx.beginPath(); cx.arc(x, y, 2.6, 0, 7); cx.fill(); }
    } else {
      const r = q.h * 0.36, c = [q.w / 2, q.h / 2]; let a0 = q.spin;
      [["111,227,255", 0.4], ["110,231,168", 0.25], ["199,166,255", 0.2], ["255,210,122", 0.15]].forEach(([col, part]) => {
        const a1 = a0 + part * Math.PI * 2 * grow; cx.strokeStyle = `rgba(${col},${0.7 * al})`; cx.lineWidth = r * 0.38;
        cx.beginPath(); cx.arc(c[0], c[1], r, a0, a1); cx.stroke(); a0 = a1; });
    }
    cx.restore();
  }
  
  /* ---- 4. datu tīkls: impulsi no ikonām/malām uz hologrammām */
  function curve(a, b, t) {
    const mx = (a[0] + b[0]) / 2, my = Math.min(a[1], b[1]) - 0.08, u = 1 - t;
    return [(u * u * a[0] + 2 * u * t * mx + t * t * b[0]) * W, (u * u * a[1] + 2 * u * t * my + t * t * b[1]) * H];
  }
  function spawnPulse() {
    const a = NODES[Math.floor(Math.random() * NODES.length)], b = HUBS[Math.floor(Math.random() * HUBS.length)];
    return { a, b, t: 0, v: 0.00045 + Math.random() * 0.0004, money: Math.random() < 0.22 };
  }
  function drawNet(now, dt, p) {
    /* tievas līnijas, kas "elpo" */
    cx.lineWidth = 0.8;
    NODES.forEach((a, i) => {
      const b = HUBS[i % HUBS.length], al = (0.05 + 0.05 * Math.sin(now / 900 + i)) * Math.min(1, p * 4);
      cx.strokeStyle = `rgba(111,227,255,${al})`; cx.beginPath();
      for (let k = 0; k <= 24; k++) { const [x, y] = curve(a, b, k / 24); k ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      cx.stroke();
      const [nx, ny] = [a[0] * W, a[1] * H], fl = S.flash > 0 ? S.flash : 0;
      const g = cx.createRadialGradient(nx, ny, 0, nx, ny, 9 + fl * 14);
      g.addColorStop(0, `rgba(200,250,255,${0.55 + fl * 0.45})`); g.addColorStop(1, "rgba(111,227,255,0)");
      cx.fillStyle = g; cx.beginPath(); cx.arc(nx, ny, 9 + fl * 14, 0, 7); cx.fill();
    });
    /* impulsi */
    S.pulses = S.pulses.filter((q) => (q.t += q.v * dt) < 1);
    for (const q of S.pulses) {
      for (let k = 0; k < 6; k++) {
        const t = q.t - k * 0.018; if (t < 0) continue;
        const [x, y] = curve(q.a, q.b, t), al = (1 - k / 6) * Math.sin(Math.PI * q.t);
        cx.fillStyle = q.money ? `rgba(110,231,168,${al})` : `rgba(190,245,255,${al})`;
        cx.beginPath(); cx.arc(x, y, (q.money ? 2.4 : 1.8) * (1 - k / 8), 0, 7); cx.fill();
      }
      if (q.money && q.t > 0.75) { const [x, y] = curve(q.a, q.b, q.t);
        cx.font = `600 ${Math.max(9, W / 80)}px system-ui, sans-serif`; cx.fillStyle = `rgba(110,231,168,${(1 - q.t) * 3})`; cx.fillText("+$", x + 6, y - 6); }
    }
  }
  
  /* ---- 5. "Gatavs": gaismas vilnis */
  function drawWave(dt) {
    if (S.wave < 0) return;
    S.wave += dt / 1100; if (S.wave > 1) { S.wave = -1; return; }
    const R = S.wave * W * 0.9, al = (1 - S.wave) * 0.5;
    cx.strokeStyle = `rgba(150,240,255,${al})`; cx.lineWidth = 2 + 6 * (1 - S.wave);
    cx.beginPath(); cx.arc(WAVE[0] * W, WAVE[1] * H, R, 0, 7); cx.stroke();
  }
  
  /* ======== Tirgotāja maģija "trade" (docs/sakuma-banneris.md §2b; avots tirgotajs/dev/banner/banner.html) ======== */
  const ctr = (w) => [(w.r[0] + w.r[2]) / 2, (w.r[1] + w.r[3]) / 2];

  /* ---- 0. valūtu lietus (kā Analītiķa 0/1 lietus): $ € £ ¥ … caurspīdīgi līst pāri bildei */
  const CUR = "$$$$$$€€€€€££¥¥₹₩₴₺₣¢฿₪";
  const T_GLYPH = () => CUR[Math.floor(Math.random() * CUR.length)];
  function tInitRain() {
    const fs = Math.max(22, Math.round(W / 26)), cols = Math.ceil(W / (fs * 2.1));   /* lietotājs 16:16: retāks */
    S.fs = fs;
    S.rain = Array.from({ length: cols }, (_, i) => ({ x: i * fs * 2.1 + fs * (0.3 + Math.random() * 0.8), y: Math.random() * H * 1.3, v: 0.04 + Math.random() * 0.07,
      len: 8 + Math.floor(Math.random() * 14), g: Array.from({ length: 24 }, T_GLYPH), on: Math.random() < 0.6 }));
  }
  function tDrawRain(dt) {
    const fs = S.fs; cx.font = `600 ${fs}px ui-monospace, Menlo, Consolas, monospace`; cx.textAlign = "center";
    for (const c of S.rain) {
      if (!c.on) { if (Math.random() < 0.01 * dt / 16) { c.on = true; c.y = -c.len * fs; } continue; }
      c.y += c.v * dt;
      if (Math.random() < 0.04) c.g[Math.floor(Math.random() * c.g.length)] = T_GLYPH();
      for (let i = 0; i < c.len; i++) {
        const y = c.y - i * fs; if (y < -fs || y > H) continue;
        const m = mask(c.x, y); if (m <= 0.01) continue;
        const head = i === 0, a = (head ? 0.3 : 0.14 * (1 - i / c.len) + 0.02) * m;   /* 16:21: neuzbāzīgs */
        cx.fillStyle = head ? `rgba(255,252,240,${a})` : `rgba(255,240,210,${a})`;   /* mazāk zaļš */
        if (head) { cx.shadowColor = "#fff3d6"; cx.shadowBlur = 5; }
        cx.fillText(c.g[i % c.g.length], c.x, y);
        if (head) cx.shadowBlur = 0;
      }
      if (c.y - c.len * fs > H) { c.on = Math.random() < 0.6; c.y = -Math.random() * H * 0.5; c.v = 0.035 + Math.random() * 0.06; }
    }
  }
  /* ---- 0b. bildes lidmašīna rokā "dzīva": mirdzums pulsē, gaisma skrien pa tās asti */
  const HANDPLANE = B.handPlane || [0.535, 0.37], HANDTAIL = B.handTail || [0.47, 0.42];
  function drawHandPlane(now) {
    const [px, py] = [HANDPLANE[0] * W, HANDPLANE[1] * H], a = 0.35 + 0.25 * Math.sin(now / 300);
    const g = cx.createRadialGradient(px, py, 0, px, py, W * 0.05); g.addColorStop(0, `rgba(255,250,230,${a})`); g.addColorStop(1, "rgba(255,230,180,0)");
    cx.fillStyle = g; cx.beginPath(); cx.arc(px, py, W * 0.05, 0, 7); cx.fill();
    const t = (now % 900) / 900, [tx, ty] = [(HANDTAIL[0] + (HANDPLANE[0] - HANDTAIL[0]) * t) * W, (HANDTAIL[1] + (HANDPLANE[1] - HANDTAIL[1]) * t) * H];
    const g2 = cx.createRadialGradient(tx, ty, 0, tx, ty, W * 0.012); g2.addColorStop(0, `rgba(255,220,140,${0.8 * Math.sin(Math.PI * t)})`); g2.addColorStop(1, "rgba(255,200,100,0)");
    cx.fillStyle = g2; cx.beginPath(); cx.arc(tx, ty, W * 0.012, 0, 7); cx.fill();
  }

  /* ---- 1. zaļgani putekļi gaisā */
  function initDust() {
    S.dust = Array.from({ length: 70 }, () => ({ x: Math.random() * W, y: Math.random() * H, r: 0.6 + Math.random() * 1.6,
      vy: -(0.004 + Math.random() * 0.012), vx: (Math.random() - 0.5) * 0.006, ph: Math.random() * 7 }));
  }
  function drawDust(now, dt) {
    for (const q of S.dust) {
      q.x += q.vx * dt; q.y += q.vy * dt; if (q.y < -5) { q.y = H + 5; q.x = Math.random() * W; }
      const m = mask(q.x, q.y) * (q.x / W > 0.42 ? 1 : 0.4); if (m < 0.02) continue;
      const a = (0.25 + 0.35 * Math.sin(now / 500 + q.ph)) * m; if (a <= 0) continue;
      cx.fillStyle = `rgba(170,255,200,${a})`; cx.beginPath(); cx.arc(q.x, q.y, q.r, 0, 7); cx.fill();
    }
  }

  /* ---- 2. papīra lidmašīnas: no rokas / klēpjdatora pa līkni uz aģentūras logu */
  function spawnPlane() {
    const a = Math.random() < 0.5 ? FROM[0] : FROM[1 + Math.floor(Math.random() * (FROM.length - 1))], wi = Math.floor(Math.random() * WINS.length), b = ctr(WINS[wi]);
    const bend = 0.10 + Math.random() * 0.12, side = Math.random() < 0.5 ? -1 : 1;
    const c = [(a[0] + b[0]) / 2 + side * 0.06 * Math.random(), Math.min(a[1], b[1]) - bend];
    return { a, b, c, wi, t: 0, v: 1 / (1100 + Math.random() * 700), trail: [], s: 0.85 + Math.random() * 0.4 };
  }
  function bez(q, t) {
    const u = 1 - t;
    return [(u * u * q.a[0] + 2 * u * t * q.c[0] + t * t * q.b[0]) * W, (u * u * q.a[1] + 2 * u * t * q.c[1] + t * t * q.b[1]) * H];
  }
  function drawPlane(q, dt) {
    q.t = Math.min(1, q.t + q.v * dt);
    const e = q.t < 0.5 ? 2 * q.t * q.t : 1 - Math.pow(-2 * q.t + 2, 2) / 2;   // lēni → ātri → lēni
    const [x, y] = bez(q, e), [x2, y2] = bez(q, Math.min(1, e + 0.01));
    q.trail.push([x, y]); if (q.trail.length > 26) q.trail.shift();
    const fade = Math.min(1, q.t * 6) * (q.t > 0.88 ? (1 - q.t) / 0.12 : 1);
    /* aste */
    cx.save(); cx.globalCompositeOperation = "lighter"; cx.lineCap = "round";
    for (let i = 1; i < q.trail.length; i++) {
      const k = i / q.trail.length, [px, py] = q.trail[i - 1], [nx, ny] = q.trail[i];
      cx.strokeStyle = `rgba(120,255,170,${0.45 * k * fade * mask(nx, ny)})`; cx.lineWidth = 0.6 + 2.4 * k;
      cx.beginPath(); cx.moveTo(px, py); cx.lineTo(nx, ny); cx.stroke();
    }
    cx.restore();
    /* lidmašīna: tālāk — mazāka */
    const m = mask(x, y) * fade; if (m <= 0.02) return;
    const L = W * 0.034 * q.s * (1 - 0.45 * e), ang = Math.atan2(y2 - y, x2 - x);
    cx.save(); cx.translate(x, y); cx.rotate(ang); cx.globalAlpha = m;
    cx.shadowColor = "rgba(120,255,170,.9)"; cx.shadowBlur = 10;
    cx.fillStyle = "rgba(250,255,250,.95)";
    cx.beginPath(); cx.moveTo(L * 0.55, 0); cx.lineTo(-L * 0.45, -L * 0.42); cx.lineTo(-L * 0.18, 0); cx.closePath(); cx.fill();
    cx.fillStyle = "rgba(205,235,215,.95)";
    cx.beginPath(); cx.moveTo(L * 0.55, 0); cx.lineTo(-L * 0.45, L * 0.30); cx.lineTo(-L * 0.18, 0); cx.closePath(); cx.fill();
    cx.shadowBlur = 0; cx.strokeStyle = "rgba(60,120,80,.5)"; cx.lineWidth = 0.6;
    cx.beginPath(); cx.moveTo(L * 0.55, 0); cx.lineTo(-L * 0.18, 0); cx.stroke();
    cx.restore();
    if (q.t >= 1) arrive(q.wi);
  }
  function arrive(wi) {
    const w = WINS[wi]; w.flash = 1;
    const [x, y] = [w.r[2] - 0.012, w.r[1] + 0.01];
    S.pops.push({ x: x * W, y: y * H, life: 0 });
  }

  /* ---- 3. logu uzplaiksnījumi, "+1", pulkstenis → ✓ */
  function rr(x, y, w, h, r) { cx.beginPath(); cx.roundRect ? cx.roundRect(x, y, w, h, r) : cx.rect(x, y, w, h); }
  function drawCheck(px, py, r, a) {
    cx.save(); cx.translate(px, py);
    const g = cx.createRadialGradient(0, 0, 0, 0, 0, r * 2.2); g.addColorStop(0, `rgba(120,255,160,${0.55 * a})`); g.addColorStop(1, "rgba(120,255,160,0)");
    cx.fillStyle = g; cx.beginPath(); cx.arc(0, 0, r * 2.2, 0, 7); cx.fill();
    cx.strokeStyle = `rgba(210,255,220,${a})`; cx.lineWidth = r * 0.22; cx.lineCap = "round"; cx.lineJoin = "round";
    cx.beginPath(); cx.arc(0, 0, r, 0, 7); cx.stroke();
    cx.beginPath(); cx.moveTo(-r * 0.45, 0); cx.lineTo(-r * 0.1, r * 0.35); cx.lineTo(r * 0.5, -r * 0.35); cx.stroke();
    cx.restore();
  }
  function drawWins(now, dt) {
    for (const w of WINS) {
      const fl = Math.max(w.flash || 0, S.flash);
      const [x0, y0, x1, y1] = [w.r[0] * W, w.r[1] * H, w.r[2] * W, w.r[3] * H];
      if (fl > 0.01) {
        cx.save(); cx.globalCompositeOperation = "lighter";
        cx.strokeStyle = `rgba(140,255,180,${0.8 * fl})`; cx.lineWidth = 1.5 + 2 * fl; cx.shadowColor = "#7dffb0"; cx.shadowBlur = 18 * fl;
        rr(x0, y0, x1 - x0, y1 - y0, H * 0.012); cx.stroke();
        cx.fillStyle = `rgba(90,230,140,${0.10 * fl})`; cx.fill();
        cx.restore();
        if (w.ok) { cx.save(); cx.globalCompositeOperation = "lighter"; drawCheck(w.ok[0] * W, w.ok[1] * H, H * 0.022, 0.7 * fl); cx.restore(); }
      }
      if (w.flash) w.flash = Math.max(0, w.flash - dt / 650);
      /* pulkstenis: kamēr gaida — viegli mirgo dzeltens; pie "Gatavs" — kļūst par zaļu ✓ */
      if (w.clock) {
        const [px, py] = [w.clock[0] * W, w.clock[1] * H], r = H * 0.03;
        if (S.done > 0) {
          const k = Math.min(1, S.done);
          cx.fillStyle = `rgba(14,40,24,${0.95 * k})`; cx.beginPath(); cx.arc(px, py, r * 1.25, 0, 7); cx.fill();
          cx.save(); cx.globalCompositeOperation = "lighter"; drawCheck(px, py, r * 0.95, k); cx.restore();
        } else {
          const a = 0.18 + 0.18 * Math.sin(now / 260);
          const g = cx.createRadialGradient(px, py, 0, px, py, r * 2); g.addColorStop(0, `rgba(255,190,80,${a})`); g.addColorStop(1, "rgba(255,190,80,0)");
          cx.save(); cx.globalCompositeOperation = "lighter"; cx.fillStyle = g; cx.beginPath(); cx.arc(px, py, r * 2, 0, 7); cx.fill(); cx.restore();
        }
      }
    }
    if (S.done > 0 && S.done < 1) S.done = Math.min(1, S.done + dt / 450);
    /* "+1" */
    S.pops = S.pops.filter((p) => (p.life += dt) < 1100);
    cx.font = `700 ${Math.max(10, W / 62)}px system-ui, sans-serif`; cx.textAlign = "center";
    for (const p of S.pops) {
      const f = p.life / 1100, a = f < 0.15 ? f / 0.15 : 1 - (f - 0.15) / 0.85;
      cx.fillStyle = `rgba(150,255,185,${a})`; cx.shadowColor = "rgba(80,230,130,.9)"; cx.shadowBlur = 8;
      cx.fillText("+1", p.x, p.y - f * H * 0.05); cx.shadowBlur = 0;
    }
  }

  /* ---- 4. vājas līnijas no klēpjdatora uz logiem, kas "elpo" */
  function drawLinks(now, p) {
    cx.lineWidth = 0.9;
    WINS.forEach((w, i) => {
      const q = { a: FROM[1 + (i % 3)], b: ctr(w), c: [0, 0] }; q.c = [(q.a[0] + q.b[0]) / 2, Math.min(q.a[1], q.b[1]) - 0.1];
      const al = (0.05 + 0.05 * Math.sin(now / 900 + i)) * Math.min(1, p * 4) + S.flash * 0.25;
      cx.strokeStyle = `rgba(120,255,170,${al})`; cx.beginPath();
      for (let k = 0; k <= 24; k++) { const [x, y] = bez(q, k / 24); k ? cx.lineTo(x, y) : cx.moveTo(x, y); }
      cx.stroke();
    });
  }

  /* ---- 5. "Gatavs": zaļš gaismas vilnis no klēpjdatora */
  function tDrawWave(dt) {
    if (S.wave < 0) return;
    S.wave += dt / 1100; if (S.wave > 1) { S.wave = -1; return; }
    const R = S.wave * W * 0.9, al = (1 - S.wave) * 0.5;
    cx.strokeStyle = `rgba(150,255,190,${al})`; cx.lineWidth = 2 + 6 * (1 - S.wave);
    cx.beginPath(); cx.arc(WAVE[0] * W, WAVE[1] * H, R, 0, 7); cx.stroke();
  }

  /* ---- 6. pārdošana: no loga izripo ratiņi ar bildi, "+$", zelta monētas aizlido uz kasti */
  const BOX = B.box || [0.845, 0.68];   // kartona kaste (kur krāj naudu)
  const PRICES = ["0.25", "0.35", "0.38", "0.99", "1.20", "2.50", "0.33", "0.10"];
  function sell(wi) {
    const w = WINS[wi], x = (w.r[0] + w.r[2]) / 2 + (Math.random() - 0.5) * 0.03, y = w.r[3] + 0.045;
    S.carts.push({ x, y, life: 0, max: 1500, price: PRICES[Math.floor(Math.random() * PRICES.length)], sky: Math.random(), coins: 2 + Math.floor(Math.random() * 3) });
  }
  function drawCart(q, dt) {
    q.life += dt; const f = q.life / q.max;
    const a = (f < 0.15 ? f / 0.15 : f > 0.75 ? (1 - f) / 0.25 : 1) * mask(q.x * W, q.y * H);
    const x = (q.x + 0.012 * Math.min(1, f * 2)) * W, y = (q.y + 0.03 * Math.min(1, f * 1.6)) * H, s = H * 0.045;
    if (a > 0.01) {
      cx.save(); cx.translate(x, y); cx.globalAlpha = a;
      cx.shadowColor = "rgba(255,200,90,.9)"; cx.shadowBlur = 10;
      /* bildīte ratiņos */
      const g = cx.createLinearGradient(0, -s * 0.9, 0, -s * 0.2); g.addColorStop(0, q.sky < 0.5 ? "#ffb36b" : "#7fd3ff"); g.addColorStop(1, q.sky < 0.5 ? "#6a4cc2" : "#2f7d6b");
      cx.fillStyle = g; cx.fillRect(-s * 0.55, -s * 0.95, s * 1.0, s * 0.7);
      cx.strokeStyle = "rgba(255,226,150,.95)"; cx.lineWidth = Math.max(1.2, s * 0.09); cx.lineJoin = "round"; cx.lineCap = "round";
      cx.beginPath(); cx.moveTo(-s * 1.05, -s * 0.55); cx.lineTo(-s * 0.75, -s * 0.55); cx.lineTo(-s * 0.55, s * 0.15); cx.lineTo(s * 0.6, s * 0.15);
      cx.lineTo(s * 0.75, -s * 0.35); cx.lineTo(-s * 0.65, -s * 0.35); cx.stroke();
      cx.beginPath(); cx.arc(-s * 0.4, s * 0.38, s * 0.12, 0, 7); cx.arc(s * 0.45, s * 0.38, s * 0.12, 0, 7); cx.stroke();
      cx.shadowBlur = 0;
      cx.font = `700 ${Math.max(10, W / 64)}px system-ui, sans-serif`; cx.textAlign = "center";
      cx.fillStyle = "rgba(255,222,140,1)"; cx.shadowColor = "rgba(255,180,60,.9)"; cx.shadowBlur = 8;
      cx.textAlign = "left"; cx.fillText("+$" + q.price, s * 1.0, -s * 0.15 - f * H * 0.015);
      cx.restore();
    }
    if (!q.sent && f > 0.45) { q.sent = true; for (let i = 0; i < q.coins; i++) S.coins.push(spawnCoin(x / W, y / H, i * 90)); }
  }
  function spawnCoin(x, y, delay) {
    const a = [x, y], b = [BOX[0] + (Math.random() - 0.5) * 0.04, BOX[1]];
    return { a, b, c: [(a[0] + b[0]) / 2 + 0.06 + Math.random() * 0.05, Math.min(a[1], b[1]) - 0.06], t: -delay / 1000, v: 1 / (800 + Math.random() * 400), spin: Math.random() * 6, trail: [] };
  }
  function drawCoin(q, dt) {
    q.t += q.v * dt; q.spin += dt / 120; if (q.t < 0) return;
    const t = Math.min(1, q.t), [x, y] = bez(q, t * t * (3 - 2 * t));
    q.trail.push([x, y]); if (q.trail.length > 10) q.trail.shift();
    const r = H * 0.016 * (1 - 0.3 * t), m = mask(x, y);
    cx.save(); cx.globalCompositeOperation = "lighter";
    for (let i = 1; i < q.trail.length; i++) { const k = i / q.trail.length;
      cx.strokeStyle = `rgba(255,200,90,${0.3 * k * m})`; cx.lineWidth = r * k; cx.beginPath(); cx.moveTo(...q.trail[i - 1]); cx.lineTo(...q.trail[i]); cx.stroke(); }
    cx.restore();
    cx.save(); cx.translate(x, y); cx.scale(Math.max(0.2, Math.abs(Math.cos(q.spin))), 1); cx.globalAlpha = m;
    const g = cx.createRadialGradient(-r * 0.3, -r * 0.3, 0, 0, 0, r); g.addColorStop(0, "#fff3c4"); g.addColorStop(0.5, "#f6c650"); g.addColorStop(1, "#b9781c");
    cx.fillStyle = g; cx.shadowColor = "rgba(255,190,70,.9)"; cx.shadowBlur = 8; cx.beginPath(); cx.arc(0, 0, r, 0, 7); cx.fill();
    cx.restore();
    if (q.t >= 1) S.boxGlow = Math.min(1, S.boxGlow + 0.35);
  }
  function drawBox(dt) {
    if (S.boxGlow <= 0.01) return;
    const [x, y] = [BOX[0] * W, BOX[1] * H], R = W * 0.07;
    const g = cx.createRadialGradient(x, y, 0, x, y, R); g.addColorStop(0, `rgba(255,214,120,${0.45 * S.boxGlow})`); g.addColorStop(1, "rgba(255,190,80,0)");
    cx.save(); cx.globalCompositeOperation = "lighter"; cx.fillStyle = g; cx.beginPath(); cx.arc(x, y, R, 0, 7); cx.fill(); cx.restore();
    S.boxGlow = Math.max(0, S.boxGlow - dt / 700);
  }


  /* ---- nosaukums: zelta burti ar mirdzumu (kā oriģinālajā attēlā) */
  const TITLE_POS = B.titlePos || { x: 0.497, base: 0.885, maxW: 0.46, size: 0.135 };   // daļas no platuma/augstuma
  function drawTitle() {
    const cv = $("#bnTitle"), d = window.devicePixelRatio || 1;
    cv.width = W * d; cv.height = H * d; const t = cv.getContext("2d"); t.setTransform(d, 0, 0, d, 0, 0); t.clearRect(0, 0, W, H);
    const txt = L10N[LANG].title, fam = LANG === "uk" ? '"BannerTitleCyr", serif' : '"BannerTitle", serif';
    let fs = H * TITLE_POS.size; t.font = `700 ${fs}px ${fam}`;
    const w = t.measureText(txt).width; if (w > W * TITLE_POS.maxW) { fs *= W * TITLE_POS.maxW / w; t.font = `700 ${fs}px ${fam}`; }
    t.textAlign = "center"; t.textBaseline = "alphabetic";
    const x = W * TITLE_POS.x, y = H * TITLE_POS.base;
    /* 22:36: jaunajā bildē zem nosaukuma gaiši papīri — mīksts tumšs "mākonis" aiz uzraksta */
    { const tw0 = Math.min(t.measureText(txt).width, W * TITLE_POS.maxW), cy = y - fs * 0.3;
      t.save(); t.translate(x, cy); t.scale(1, 0.42);
      const rg = t.createRadialGradient(0, 0, 0, 0, 0, tw0 * 0.72);
      rg.addColorStop(0, "rgba(8,5,2,.88)"); rg.addColorStop(0.55, "rgba(8,5,2,.6)"); rg.addColorStop(1, "rgba(10,6,2,0)");
      t.fillStyle = rg; t.beginPath(); t.arc(0, 0, tw0 * 0.72, 0, 7); t.fill(); t.restore(); }
    /* tumša pamatne, lai burti atdalās no fona */
    t.save(); t.shadowColor = "rgba(0,0,0,.85)"; t.shadowBlur = fs * 0.35; t.fillStyle = "rgba(0,0,0,.55)"; t.fillText(txt, x, y); t.restore();
    /* zelta mirdzums */
    t.save(); t.shadowColor = "rgba(255,170,60,.9)"; t.shadowBlur = fs * 0.3; t.fillStyle = "rgba(120,60,10,.9)"; t.fillText(txt, x, y); t.restore();
    /* burti: gaiši krēmkrāsas augšā → zelts → silti oranžs apakšā */
    const g = t.createLinearGradient(0, y - fs * 0.78, 0, y + fs * 0.05);
    g.addColorStop(0, "#fff4d2"); g.addColorStop(0.35, "#fbdc8e"); g.addColorStop(0.68, "#f0b04a"); g.addColorStop(1, "#c46e1c");
    t.fillStyle = g; t.fillText(txt, x, y);
    t.lineWidth = Math.max(0.8, fs * 0.016); t.strokeStyle = "rgba(80,38,8,.75)"; t.strokeText(txt, x, y);
    /* 22:36: jaunajā bildē nav zelta svītras — zīmējam pašu (kā Vārdotāja/iepriekšējā bannerī) */
    const tw = Math.min(t.measureText(txt).width, W * TITLE_POS.maxW), sy = y + fs * 0.24;
    t.save(); t.globalCompositeOperation = "lighter"; t.lineCap = "round";
    const sg = t.createLinearGradient(x - tw * 0.75, 0, x + tw * 0.75, 0);
    sg.addColorStop(0, "rgba(255,170,60,0)"); sg.addColorStop(0.3, "rgba(255,200,110,.9)"); sg.addColorStop(0.6, "rgba(255,236,190,1)"); sg.addColorStop(1, "rgba(255,170,60,0)");
    t.strokeStyle = sg; t.shadowColor = "rgba(255,190,90,.9)"; t.shadowBlur = fs * 0.2; t.lineWidth = Math.max(1.6, fs * 0.05);
    t.beginPath(); t.moveTo(x - tw * 0.75, sy + fs * 0.06); t.bezierCurveTo(x - tw * 0.3, sy - fs * 0.12, x + tw * 0.25, sy + fs * 0.12, x + tw * 0.75, sy - fs * 0.05); t.stroke();
    t.restore();
  }
  
  function frame(now) {
    const dt = Math.min(50, now - (S.last || now)); S.last = now;
    const p = Math.min(1, (now - S.t0) / DUR);
    cx.clearRect(0, 0, W, H);
    if (MAGIC === "trade") {
      cx.globalCompositeOperation = "lighter"; tDrawRain(dt); drawDust(now, dt); drawLinks(now, p); drawHandPlane(now); cx.globalCompositeOperation = "source-over";
      drawWins(now, dt);
      /* plūsma: 3–5 vienlaikus, nākamā ik ~0,3–0,6 s */
      if (!S.closing && now > S.next && S.planes.length < 5) { S.planes.push(spawnPlane()); S.next = now + 300 + Math.random() * 330; }
      S.planes.forEach((q) => drawPlane(q, dt)); S.planes = S.planes.filter((q) => q.t < 1);
      /* pārdošanas: ik ~0,8–1,4 s kāds logs "pārdod" */
      if (!S.closing && now > S.nextSale && now - S.t0 > 900) { S.nextSale = now + 800 + Math.random() * 600; sell(Math.floor(Math.random() * WINS.length)); }
      S.carts = S.carts.filter((q) => q.life < q.max); S.carts.forEach((q) => drawCart(q, dt));
      S.coins = S.coins.filter((q) => q.t < 1); S.coins.forEach((q) => drawCoin(q, dt)); drawBox(dt);
      cx.globalCompositeOperation = "lighter"; tDrawWave(dt); cx.globalCompositeOperation = "source-over";
    } else {
      cx.globalCompositeOperation = "lighter";   // 21:58: lietus pieskaitās gaismai — redzams arī uz bildes
      drawRain(dt);
      drawNet(now, dt, p);
      /* 22:03 lietotājs: bez "krītošajām zvaigznēm" (impulsiem) */
      cx.globalCompositeOperation = "source-over";
      if (!S.closing && S.cards.length < 6 && Math.random() < 0.02 * dt / 16) S.cards.push(spawnCard());
      if (!S.closing && S.huds.length < 6 && Math.random() < 0.03 * dt / 16) S.huds.push(spawnHud());   /* 22:09: atpakaļ, vairāk */
      S.huds = S.huds.filter((q) => q.life < q.max); S.huds.forEach((q) => drawHud(q, dt));
      S.cards = S.cards.filter((q) => q.life < q.max); S.cards.forEach((q) => drawCard(q, dt));
      cx.globalCompositeOperation = "lighter"; drawWave(dt); cx.globalCompositeOperation = "source-over";
    }
    if (S.flash > 0) S.flash = Math.max(0, S.flash - dt / 900);
    if (!S.closing) {
      $("#bnBar").style.width = (p * 100).toFixed(1) + "%";
      let txt = STEPS[0]; AT.forEach((a, i) => { if (p >= a) txt = STEPS[i]; });
      if ($("#bnStep").textContent !== txt) {
        $("#bnStep").textContent = txt;
        if (txt === STEPS[STEPS.length - 1]) { S.wave = 0; S.flash = 1;
          if (MAGIC === "trade") { S.done = 0.01; WINS.forEach((w, i) => { const [x] = ctr(w); for (let k = 0; k < 2; k++) S.coins.push(spawnCoin(x, w.r[3], i * 60 + k * 120)); }); }   /* "alga" */
        }
      }
      if (p >= 1 && !S.doneAt) S.doneAt = now;
      if (S.doneAt && now - S.doneAt > 700) close();
    }
    S.raf = requestAnimationFrame(frame);
  }
  function start() {
    cancelAnimationFrame(S.raf);
    Object.assign(S, { closing: false, last: 0, cards: [], huds: [], pulses: [], flash: 0, wave: -1, doneAt: 0,
      planes: [], pops: [], carts: [], coins: [], boxGlow: 0, nextSale: 0, done: 0, next: 0 });
    WINS.forEach((w) => (w.flash = 0));

    const wrap = $("#bnWrap"); wrap.classList.remove("hide"); wrap.classList.add("show");
    size(); S.t0 = performance.now();
    if (MAGIC === "trade") { for (let i = 0; i < 2; i++) S.planes.push(Object.assign(spawnPlane(), { t: 0.2 + i * 0.3 })); }
    else {
      for (let i = 0; i < 3; i++) S.cards.push(Object.assign(spawnCard(), { life: Math.random() * 1500 }));
      for (let i = 0; i < 3; i++) S.huds.push(Object.assign(spawnHud(), { life: 200 + Math.random() * 1200 }));
    }
    S.raf = requestAnimationFrame(frame);
  }
  function close() {
    if (S.closing || !$("#bnWrap")) return; S.closing = true; $("#bnBar").style.width = "100%";
    $("#bnWrap").classList.add("hide");
    setTimeout(() => { cancelAnimationFrame(S.raf); const w = $("#bnWrap"); if (w) w.remove(); }, 750);
  }
  
  function mount(ver) {
    if (document.getElementById("bnWrap")) return;
    const st = document.createElement("style"); st.textContent = CSS; document.head.appendChild(st);
    const w = document.createElement("div"); w.id = "bnWrap"; w.className = "bn-wrap" + (MAGIC === "trade" ? " trade" : "");
    w.innerHTML = `<div class="bn" id="bnCard"><img id="bnImg" alt=""><canvas id="bnTitle"></canvas><canvas id="bnFx"></canvas>
      <div class="bn-foot"><div class="bn-row"><span id="bnStep"></span><span id="bnVer"></span></div><div class="bn-bar"><i id="bnBar"></i></div></div></div>`;
    document.body.appendChild(w);
    $("#bnVer").textContent = "v" + ver;
    $("#bnCard").addEventListener("click", close);
    window.addEventListener("resize", () => { if (!S.closing) size(); });
  }
  function startBanner(lang, ver) {
    if (!B.img) return false;
    LANG = L10N[lang] ? lang : "en"; STEPS = (L10N[LANG] || L10N.en || { steps: [""] }).steps;
    mount(ver);
    const img = $("#bnImg");
    const go = () => Promise.all([document.fonts.load('700 40px "BannerTitle"'), document.fonts.load('700 40px "BannerTitleCyr"', (L10N.uk && L10N.uk.title) || "Аналітик")])
      .catch(() => {}).then(() => requestAnimationFrame(start));
    img.onload = go; img.onerror = () => { const w = $("#bnWrap"); if (w) w.remove(); };
    img.src = B.img;
    setTimeout(close, 15000);
    return true;
  }
  return { start: startBanner, close };
})();
