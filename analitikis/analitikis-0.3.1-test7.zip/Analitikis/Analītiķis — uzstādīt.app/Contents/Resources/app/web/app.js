"use strict";
/* Analītiķis — saskarne. Viss modulis vienā failā ar skaidru inicializāciju (init()), lai vēlāk to
   varētu ielādēt kā sadaļu kopējā programmā kopā ar Vārdotāju. */

/* $, $$, esc, api, toast, uiDialog, uiConfirm, t — /core/core.js */

/* --- formāti --- */
let AG = [];            // aģentūru secība no servera (state.agencies)
const S = {
  settings: {}, agencies: {}, ov: null, page: "overview",
  chart: { view: "month", year: 0, month: 0, data: null, table: false },
  feed: { offset: 0, rows: [] }, best: { offset: 0, rows: [] }, years: [],
  sync: null, pollTimer: null, wasRunning: false,
  sel: new Map(), colls: [],
};
const loc = () => window.langLocale();
const usd = (v, d = 2) => "$" + (+v || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const usd0 = (v) => usd(v, Math.abs(v) >= 1000 ? 0 : 2);
const int = (v) => (+v || 0).toLocaleString(loc());
const agName = (a) => (S.agencies[a] && S.agencies[a].name) || a;
const dot = (a) => `<i class="dot" style="background:var(--ag-${esc(a)}, var(--ag-other))"></i>`;
const hasCounts = (a) => !(S.agencies[a] && S.agencies[a].counts === false);
/* summa oriģinālajā valūtā (pārdošanu rindām) */
const amt = (r) => (r.currency && r.currency !== "USD" ? (r.currency === "EUR" ? "€" : r.currency === "GBP" ? "£" : r.currency + " ") +
  (+r.amount || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : usd(r.amount));
const dlTxt = (n, counts = true) => (counts && n ? `↓ ${int(n)}` : "");
/* 0.3.1-test3 (lietotājs 2026-11-01): "↓ N" ar paskaidrojošu mākonīti — tās ir lejupielādes */
const dlS = (n, sp = " ") => `<span class="dl" title="${esc(t("dl_tip"))}">↓${sp}${n}</span>`;
const DL_TH = () => `<th title="${esc(t("dl_tip"))}">↓</th>`;
const cap = (x) => x.charAt(0).toUpperCase() + x.slice(1);
/* savākšanas kļūdu kodi (sync.py) → saprotams teksts */
const errText = (m) => (m && /^[a-z_]+$/.test(m) && t("err_" + m) !== "err_" + m ? t("err_" + m) : m || "");
const ACTIVE = ["queued", "waiting", "loading", "running", "login"];
const MONTHLY = new Set(["envato", "envato_market", "ingram"]);   // vienumu ienākumi pa mēnešiem (bez pārdošanas dienas)
/* bildes nosaukums; ja aģentūra to nedod (Alamy, Pixta) — aģentūra un bildes numurs */
const label = (r, ag, id) => r.title || r.filename || (ag ? `${agName(ag)} · ${id || ""}` : "");
function fmtDate(s, opts = null) {
  if (!s) return "";
  const d = new Date(s.length <= 10 ? s + "T12:00:00" : s);
  if (isNaN(d)) return s;
  if (opts) return d.toLocaleDateString(loc(), opts);
  const mon = d.toLocaleDateString(loc(), { month: "short" });
  const y = d.getFullYear() !== new Date().getFullYear() ? " " + d.getFullYear() : "";
  return window.LANG === "lv" || window.LANG === "de" ? `${d.getDate()}. ${mon}${y}` : `${d.getDate()} ${mon}${y}`;
}
function fmtMonth(y, m) {
  return cap(new Date(y, m - 1, 15).toLocaleDateString(loc(), { month: "long" })) + " " + y;
}
function ago(iso) {
  if (!iso) return t("never");
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 90) return t("just_now");
  if (s < 3600) return t("min_ago", { n: Math.round(s / 60) });
  if (s < 86400 * 2) return t("h_ago", { n: Math.round(s / 3600) });
  return fmtDate(iso);
}
const thumb = (u, size = 240) => (u ? u.replace("/110_F_", `/${size}_F_`) : "");
const bg = (u) => (u ? `style="background-image:url('${esc(u)}')"` : "");
/* Sīktēls ar rezervēm: ja adrese neielādējas (piem. daļai Shutterstock jaunāko pārdošanu), mēģina tās pašas
   bildes sīktēlu citā aģentūrā, tad Shutterstock publisko priekšskatījumu, un beigās rāda nosaukumu. */
const ssThumb = (id) => (/^\d+$/.test(String(id || "")) ? `https://www.shutterstock.com/image-photo/photo-260nw-${id}.jpg` : "");
/* Beta funkcijas (noteikumi §5): portfeļa analīze, RF/ED šķirošana */
const BETA_OFF = () => !!(S.settings && S.settings.sales_beta_off);
const PORT_ON = () => !BETA_OFF() && !(S.settings && S.settings.sales_beta_portfolio === false);
const ED_ON = () => !BETA_OFF() && !!(S.settings && S.settings.sales_beta_ed);
/* uznirstošais teksts: nosaukums + kolekcijas (test52) */
/* savs uznirstošais lodziņš (title krāsu neatbalsta; lietotājs: kolekcijas zaļā krāsā, test53) */
const tipAttr = (r) => `data-tt="${esc(r.title || "")}" data-tc="${esc((r.colls || []).join(", "))}"`;
(() => {
  const box = document.createElement("div"); box.id = "tipBox"; box.className = "tipbox hidden"; document.body.appendChild(box);
  let timer = null, cur = null;
  const hide = () => { clearTimeout(timer); timer = null; cur = null; box.classList.add("hidden"); };
  document.addEventListener("mouseover", (e) => {
    const el = e.target.closest && e.target.closest("[data-tt]");
    if (el === cur) return;
    hide();
    if (!el || (!el.dataset.tt && !el.dataset.tc)) return;
    cur = el;
    const x = e.clientX, y = e.clientY;
    timer = setTimeout(() => {
      box.innerHTML = (el.dataset.tt ? `<div>${esc(el.dataset.tt)}</div>` : "") + (el.dataset.tc ? `<div class="tc">${esc(t("coll_in"))} ${esc(el.dataset.tc)}</div>` : "");
      box.classList.remove("hidden");
      box.style.left = Math.min(x + 12, innerWidth - box.offsetWidth - 8) + "px";
      box.style.top = Math.min(y + 16, innerHeight - box.offsetHeight - 8) + "px";
    }, 500);
  });
  document.addEventListener("scroll", hide, true); document.addEventListener("mousedown", hide);
})();
const edBadge = (r) => ED_ON() && r.ed != null ? `<span class="edb ${r.ed ? "ed" : "rf"}${r.ed_src === "title" ? " guess" : ""}" title="${esc(t("ed_src_" + r.ed_src))}">${r.ed ? "ED" : "RF"}${r.ed_src === "title" ? "?" : ""}</span>` : "";
/* Shutterstock sīktēli ir 250 px (…-250nw-ID.jpg) → kartītēs miglaini; vispirms mēģina 600 px variantu (test52) */
const ssBig = (u) => (u && /shutterstock\.com\/image-[a-z-]+\/.+-\d+nw-\d+\.jpg/.test(u) ? u.replace(/-\d+nw-(\d+\.jpg)/, "-600w-$1").replace("//image.shutterstock.com/", "//www.shutterstock.com/") : "");
function thList(r, size, members) {
  const ss = r.agency === "shutterstock" ? r.agency_item_id : ((members || r.members || []).find((m) => m.agency === "shutterstock") || {}).agency_item_id;
  const extra = (members || r.members || []).map((m) => thumb(m.thumb, size));
  return [...new Set([ssBig(r.thumb), thumb(r.thumb, size), ssBig(r.alt), thumb(r.alt, size), ...extra, r.thumb || r.alt || extra.length ? ssThumb(ss) : ""].filter(Boolean))];
}
/* lielais skats (bildes kartīte): mēģina lielākus variantus un ņem platāko, kas ielādējas (test53) */
const bigVar = (u) => {
  if (!u) return [];
  const out = [];
  const ss = ssBig(u); if (ss) out.push(ss);
  if (/thumbs\.dreamstime\.com\/[a-z]\//.test(u)) out.push(u.replace(/(thumbs\.dreamstime\.com\/)[a-z]\//, "$1z/"), u.replace(/(thumbs\.dreamstime\.com\/)[a-z]\//, "$1b/"));
  if (/\/\d+_[^/?#]+$/.test(u) && /zoonar/.test(u)) out.push(u.replace(/\/\d+_([^/?#]+)$/, "/10_$1"));
  return out;
};
function probeBest(el, list) {
  let best = 0, done = 0;
  list.forEach((u) => {
    const im = new Image();
    im.onload = () => { if (im.naturalWidth > best) { best = im.naturalWidth; el.style.backgroundImage = `url('${u}')`; } if (++done === list.length && !best) el.classList.add("noimg"); };
    im.onerror = () => { if (++done === list.length && !best) el.classList.add("noimg"); };
    im.src = u;
  });
}
function thAttr(r, size = 240, nt = "") {
  const list = thList(r, size);
  if (!list.length) return "";
  return `${bg(list[0])} data-th="${esc(JSON.stringify(list))}" data-nt="${esc(nt)}"`;
}
function probeThumb(el, list, i) {
  if (i >= list.length) {
    el.style.backgroundImage = "";
    if (el.classList.contains("img")) {
      el.classList.add("noimg");
      if (el.dataset.nt && !el.querySelector(".nt")) el.insertAdjacentHTML("afterbegin", `<span class="nt">${esc(el.dataset.nt)}</span>`);
      const ttl = el.parentElement && el.parentElement.querySelector(".ttl:not(.q)");
      if (ttl) ttl.remove();
    }
    return;
  }
  const im = new Image();
  im.onload = () => { if (im.naturalWidth > 2) { if (i) el.style.backgroundImage = `url('${list[i]}')`; } else probeThumb(el, list, i + 1); };
  im.onerror = () => probeThumb(el, list, i + 1);
  im.src = list[i];
}
function fixThumbs(root) {
  $$("[data-th]", root).forEach((el) => {
    if (el.dataset.probed) return;
    el.dataset.probed = "1";
    try { probeThumb(el, JSON.parse(el.dataset.th), 0); } catch (_) { /* */ }
  });
}

/* ============================================================ lapas */
function showPage(name) {
  S.page = name;
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "overview") loadOverview();
  if (name === "sales") loadFeed(true);
  if (name === "best") loadBest(true);
  if (name === "colls") loadColls();
  if (name === "payouts") loadPayouts();
  if (name === "agencies") loadAgencies();
  if (name === "settings") loadSettings();
}
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));
$$("[data-goto]").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.goto)));

/* ============================================================ pārskats */
async function loadOverview() {
  try {
    const d = await api("overview");
    S.ov = d;
    renderCards(d);
    renderFresh(d);
    renderEmptyHint(d);
    applySync(d.sync);
  } catch (e) { toast(e.message, "err"); }
  loadChart();
}
function byRows(by, keyFilter) {
  const rows = AG.filter((a) => by && by[a] && (by[a].e || by[a].n) && (!keyFilter || keyFilter(a)));
  if (!rows.length) return "";
  return `<div class="by">${rows.map((a) => `<div class="agrow">${dot(a)}<span class="nm">${esc(agName(a))}</span><span class="val">${usd(by[a].e)}</span></div>`).join("")}</div>`;
}
function renderCards(d) {
  const c = d.cards;
  const dl = (n) => (n ? dlS(int(n)) : "&nbsp;");
  const cmp = c.prev_month_same.e;
  const cards = [
    { k: t("c_today"), v: c.today.e, n: c.today.n, sub: `${t("yesterday")}: <b>${usd(c.yesterday.e)}</b>`, by: c.today.by },
    { k: t("c_week"), v: c.week.e, n: c.week.n, sub: "", by: c.week.by },
    { k: t("c_month"), v: c.month.e, n: c.month.n,
      sub: `${t("prev_same")}: <b>${usd(cmp)}</b>`, by: c.month.by },   // lietotājs 2026-11-01: Pārskatā tīra statistika, bez prognozes
    { k: t("c_year"), v: c.year.e, n: c.year.n, sub: `${t("all_time")}: <b>${usd0(c.all.e)}</b>`, by: c.year.by },
    { k: t("c_balance"), v: d.balance_total, n: 0, cls: "balance", sub: t("balance_note"),
      by: Object.fromEntries((d.balance || []).map((b) => [b.agency, { e: b.amount, n: 0 }])) },
  ];
  $("#cards").innerHTML = cards.map((x) => `<div class="card ${x.cls || ""}"><div class="k">${esc(x.k)}</div>
      <div class="v">${usd(x.v)}</div><div class="n">${dl(x.n)}</div>
      ${x.sub ? `<div class="sub">${x.sub}</div>` : ""}${byRows(x.by)}</div>`).join("");
}
/* jaunās pārdošanas kopš iepriekšējās atjaunošanas — līdz nākamajai atjaunošanai */
function renderFresh(d) {
  const f = d.fresh || { e: 0, n: 0, by: {} };
  const el = $("#freshNote");
  /* lietotājs 2026-11-04 22:29: bez naudas ($0.00, piem. Magnific lejupielādes, kuru summa nāk vēlāk) jaunumus nerādām */
  const ags = AG.filter((a) => f.by[a] && f.by[a].e >= 0.005);
  el.classList.toggle("hidden", !ags.length);
  if (!ags.length) return;
  const fn = ags.reduce((x, a) => x + (f.by[a].n || 0), 0);      // lejupielādes tikai no rādītajām aģentūrām
  el.innerHTML = `<span>${esc(t("fresh_h"))}</span><span class="big">+${usd(f.e)}</span>${fn ? dlS(int(fn)) : ""}` +
    ags.map((a) => `<span class="fag" title="${esc(t("fresh_at", { t: ago(f.by[a].at) }))}">${dot(a)}${esc(agName(a))} <b>+${usd(f.by[a].e)}</b>${f.by[a].n ? " " + dlS(int(f.by[a].n), "") : ""}</span>`).join("");
}
function renderEmptyHint(d) {
  const has = d.agencies.some((a) => a.last_ok);
  const el = $("#emptyHint");
  el.classList.toggle("hidden", has);
  if (!has) el.innerHTML = `<h3>${esc(t("welcome_h"))}</h3><div>${t("welcome_txt")}</div>
     <div class="row-btns"><button class="primary" id="welcomeGo">${esc(t("welcome_btn"))}</button></div>`;
  if (!has) $("#welcomeGo").addEventListener("click", () => showPage("agencies"));
}

/* --- grafiks --- */
$$("#chartView button").forEach((b) => b.addEventListener("click", () => { S.chart.view = b.dataset.v; loadChart(); }));
$("#chartPrev").addEventListener("click", () => shiftChart(-1));
$("#chartNext").addEventListener("click", () => shiftChart(1));
$("#chartTableBtn").addEventListener("click", () => { S.chart.table = !S.chart.table; renderChart(); });
function shiftChart(dir) {
  const c = S.chart;
  if (c.view === "month") { c.month += dir; if (c.month < 1) { c.month = 12; c.year--; } if (c.month > 12) { c.month = 1; c.year++; } }
  else if (c.view === "year") c.year += dir;
  loadChart();
}
async function loadChart() {
  const c = S.chart;
  if (!c.year) { const n = new Date(); c.year = n.getFullYear(); c.month = n.getMonth() + 1; }
  $$("#chartView button").forEach((b) => b.classList.toggle("on", b.dataset.v === c.view));
  $(".period-nav").classList.toggle("hidden", c.view === "all");
  $("#chartLabel").textContent = c.view === "month" ? fmtMonth(c.year, c.month) : String(c.year);
  $("#chartTitle").textContent = t(c.view === "month" ? "ch_month" : c.view === "year" ? "ch_year" : "ch_all");
  try {
    const d = await api("chart", { view: c.view, year: c.year, month: c.month });
    c.data = d.chart;
    renderChart();
  } catch (e) { toast(e.message, "err"); }
  loadOvLists();
}
function keyLabel(k, view, short = true) {
  if (view === "month") return String(+k.slice(8, 10));
  if (view === "year") return new Date(+k.slice(0, 4), +k.slice(5, 7) - 1, 15).toLocaleDateString(loc(), { month: short ? "short" : "long" });
  return k;
}
function keyLong(k, view) {
  if (view === "month") return cap(new Date(k + "T12:00:00").toLocaleDateString(loc(), { weekday: "long" })) + ", " + fmtDate(k);
  if (view === "year") return fmtMonth(+k.slice(0, 4), +k.slice(5, 7));
  return k;
}
function niceMax(v) {
  if (v <= 0) return 1;
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
/* Vairāk nekā 8 krāsas grafikā nav salasāmas: mazākās aģentūras apvieno "Citas" */
function foldSeries(d) {
  const tot = (a) => Object.values(d.series[a] || {}).reduce((s, v) => s + v[0], 0);
  let ags = AG.filter((a) => d.series[a]).sort((a, b) => tot(b) - tot(a));
  if (ags.length > 8) {
    const keep = ags.slice(0, 7), rest = ags.slice(7);
    const other = {};
    for (const a of rest) for (const [k, v] of Object.entries(d.series[a])) {
      const o = other[k] || [0, 0]; other[k] = [o[0] + v[0], o[1] + v[1]];
    }
    d.series._other = other;
    d._otherList = rest;
    ags = keep.concat(["_other"]);
  }
  d._ags = AG.filter((a) => ags.includes(a)).concat(ags.includes("_other") ? ["_other"] : []);
}
const agLabel = (a) => (a === "_other" ? t("others") : agName(a));
function renderChart() {
  const d = S.chart.data;
  if (!d) return;
  const view = d.view;
  foldSeries(d);
  const ags = d._ags;
  const col = (k) => ags.map((a) => ({ a, e: (d.series[a][k] || [0, 0])[0], n: (d.series[a][k] || [0, 0])[1] }));
  const totals = d.keys.map((k) => col(k).reduce((s, x) => s + x.e, 0));
  // leģenda
  $("#chartLegend").innerHTML = ags.length ? ags.map((a) => {
    const sum = Object.values(d.series[a]).reduce((s, v) => s + v[0], 0);
    return `<span class="li" ${a === "_other" ? `title="${esc((d._otherList || []).map(agName).join(", "))}"` : ""}>${dot(a)}${esc(agLabel(a))} <b>${usd(sum)}</b></span>`;
  }).join("") + Object.entries(d.monthly_only || {}).map(([a, v]) =>
    `<span class="li" title="${esc(t("monthly_only_t"))}">${dot(a)}${esc(agName(a))} <b>${usd(v[0])}</b> <span class="muted">(${esc(t("monthly_only"))})</span></span>`).join("")
    : `<span class="muted">${esc(t("no_data"))}</span>`;
  // RPD tikai no aģentūrām, kas dod lejupielāžu skaitu (Envato ienākumi to sagrozītu)
  const cntE = AG.filter((a) => hasCounts(a)).reduce((s, a) =>
    s + Object.values(d.series[a] || {}).reduce((x, v) => x + v[0], 0) + ((d.monthly_only || {})[a] || [0])[0], 0);
  const rpd = d.total.n ? cntE / d.total.n : 0;
  $("#chartSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.total.e)}</b></span><span>${esc(t("downloads"))}: <b>${int(d.total.n)}</b></span>` +
    (rpd ? `<span title="${esc(t("rpd_title"))}">RPD: <b>${usd(rpd)}</b></span>` : "");
  const envNote = (ags.includes("envato") || (d._otherList || []).includes("envato")) && view !== "all";
  $("#chartNote").textContent = envNote ? t("envato_lag") : "";
  // tabula
  $("#chart").classList.toggle("hidden", S.chart.table);
  $("#chartTable").classList.toggle("hidden", !S.chart.table);
  $("#chartTableBtn").textContent = t(S.chart.table ? "as_chart" : "as_table");
  if (S.chart.table) {
    $("#chartTable").innerHTML = `<table class="t"><thead><tr><th></th>${ags.map((a) => `<th>${esc(agLabel(a))}</th>`).join("")}<th>${esc(t("total"))}</th>${DL_TH()}</tr></thead><tbody>` +
      d.keys.map((k, i) => { const c = col(k); return `<tr><td>${esc(keyLong(k, view))}</td>${c.map((x) => `<td>${x.e ? usd(x.e) : "–"}</td>`).join("")}<td><b>${usd(totals[i])}</b></td><td>${int(c.reduce((s, x) => s + x.n, 0))}</td></tr>`; }).join("") +
      "</tbody></table>";
    return;
  }
  // SVG stabiņi (sakrauti pa aģentūrām)
  const el = $("#chart");
  const W = Math.max(320, el.clientWidth), H = el.clientHeight || 270;
  const L = 52, R = 6, T = 8, B = 24;
  const iw = W - L - R, ih = H - T - B;
  const max = niceMax(Math.max(...totals, 0));
  const n = d.keys.length;
  const step = iw / n;
  const bw = Math.max(3, Math.min(46, step * 0.66));
  const y = (v) => T + ih - (v / max) * ih;
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc($("#chartTitle").textContent)}"><g class="grid">`;
  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = (max / ticks) * i, yy = y(v);
    svg += `<line x1="${L}" x2="${W - R}" y1="${yy}" y2="${yy}"/>`;
  }
  svg += `</g><g class="axis">`;
  for (let i = 0; i <= ticks; i++) { const v = (max / ticks) * i; svg += `<text x="${L - 8}" y="${y(v) + 4}" text-anchor="end">${usd0(v)}</text>`; }
  const every = Math.ceil(n / Math.max(1, Math.floor(iw / 34)));
  d.keys.forEach((k, i) => { if (i % every === 0) svg += `<text x="${L + step * i + step / 2}" y="${H - 6}" text-anchor="middle">${esc(keyLabel(k, view))}</text>`; });
  svg += `</g>`;
  const today = new Date().toISOString().slice(0, 10);
  d.keys.forEach((k, i) => {
    const x = L + step * i + (step - bw) / 2;
    let base = T + ih;
    const parts = col(k).filter((p) => p.e > 0);
    svg += `<g class="col" data-i="${i}">`;
    parts.forEach((p, j) => {
      const h = (p.e / max) * ih;
      const top = j === parts.length - 1;
      const gap = j > 0 ? 2 : 0;                 // 2px virsmas sprauga starp segmentiem
      const hh = Math.max(0, h - gap);
      const yy = base - h;
      if (hh > 0.5) {
        if (top && hh > 4) {
          const r = Math.min(4, bw / 2, hh);
          svg += `<path class="seg-r" fill="var(--ag-${p.a}, var(--ag-other))" d="M${x},${base - gap} V${yy + r} Q${x},${yy} ${x + r},${yy} H${x + bw - r} Q${x + bw},${yy} ${x + bw},${yy + r} V${base - gap} Z"/>`;
        } else {
          svg += `<rect class="seg-r" fill="var(--ag-${p.a}, var(--ag-other))" x="${x}" y="${yy}" width="${bw}" height="${hh}"/>`;
        }
      }
      base -= h;
    });
    svg += `<rect class="hit" data-i="${i}" x="${L + step * i}" y="${T}" width="${step}" height="${ih}"/></g>`;
    if (k === today) svg += `<circle cx="${L + step * i + step / 2}" cy="${T + ih + 3}" r="2.5" fill="var(--blue)"/>`;
  });
  svg += `</svg>`;
  el.innerHTML = svg;
  $$(".hit", el).forEach((h) => {
    h.addEventListener("mousemove", (ev) => showTip(ev, +h.dataset.i));
    h.addEventListener("mouseleave", hideTip);
    h.addEventListener("click", () => drill(+h.dataset.i));
  });
}
function showTip(ev, i) {
  const d = S.chart.data, k = d.keys[i];
  const parts = (d._ags || []).map((a) => ({ a, v: (d.series[a][k] || [0, 0]) }));
  const tot = parts.reduce((s, p) => s + p.v[0], 0), n = parts.reduce((s, p) => s + p.v[1], 0);
  const tip = $("#tip");
  tip.innerHTML = `<div class="th">${esc(keyLong(k, d.view))}</div>` +
    parts.filter((p) => p.v[0] || p.v[1]).map((p) => `<div class="tr"><span>${dot(p.a)}${esc(agLabel(p.a))}</span><span>${usd(p.v[0])}${p.v[1] ? " · " + dlS(p.v[1], "") : ""}</span></div>`).join("") +
    `<div class="tr tt"><span>${esc(t("total"))}</span><span>${usd(tot)}${n ? " · " + dlS(n, "") : ""}</span></div>` +
    (d.view !== "month" ? `<div class="muted small" style="margin-top:4px;color:#c4d0dd">${esc(t("click_drill"))}</div>` : "");
  tip.classList.remove("hidden");
  const w = tip.offsetWidth, x = ev.clientX + 14 + w > innerWidth ? ev.clientX - w - 14 : ev.clientX + 14;
  tip.style.left = x + "px";
  tip.style.top = Math.max(8, ev.clientY - tip.offsetHeight - 10) + "px";
}
function hideTip() { $("#tip").classList.add("hidden"); }
function drill(i) {
  const d = S.chart.data, k = d.keys[i];
  hideTip();
  if (d.view === "year") { S.chart.view = "month"; S.chart.year = +k.slice(0, 4); S.chart.month = +k.slice(5, 7); loadChart(); }
  else if (d.view === "all") { S.chart.view = "year"; S.chart.year = +k; loadChart(); }
}
let resizeT = null;
window.addEventListener("resize", () => { clearTimeout(resizeT); resizeT = setTimeout(() => { if (S.page === "overview") renderChart(); if (S.page === "payouts") renderPayChart(); }, 120); });

/* --- jaunākās un labākās pārskatā --- */
function mrow(r, amount, sub) {
  return `<div class="mrow${r.fresh ? " fresh" : ""}" data-ag="${esc(r.agency)}" data-id="${esc(r.agency_item_id)}">
    <div class="th" ${thAttr(r, 160)}></div>
    <div class="tx"><div title="${esc(r.title || "")}">${esc(label(r, r.agency, r.agency_item_id))}</div><div class="m">${sub}</div></div>
    <div class="am">${amount}</div></div>`;
}
function bindRows(root) {
  fixThumbs(root);
  $$(".mrow, .tile[data-ag]", root).forEach((el) => {
    if (el.dataset.bound) return;
    el.dataset.bound = "1";
    if (el.classList.contains("tile") && S.sel.has(selKey(el))) el.classList.add("sel");
    el.addEventListener("click", (e) => {
      /* atlase: stūrītis bildes augšā vai Ctrl/⌘ + klikšķis (vai jau notiek atlasīšana) */
      if (el.classList.contains("tile") && (e.target.classList.contains("selbox") || e.ctrlKey || e.metaKey || e.shiftKey || S.sel.size)) {
        e.preventDefault(); return toggleSel(el);
      }
      openItem(el.dataset.ag, el.dataset.id);
    });
    el.addEventListener("contextmenu", (e) => { e.preventDefault(); showCtx(e, el); });
  });
}
/* Saraksti zem grafika rāda to pašu periodu, kas izvēlēts grafikā (mēnesis / gads / visi gadi) */
function chartPeriod() {
  const c = S.chart;
  if (c.view === "month") return { period: `${c.year}-${String(c.month).padStart(2, "0")}`, label: fmtMonth(c.year, c.month) };
  if (c.view === "year") return { period: String(c.year), label: String(c.year) };
  return { period: "all", label: t("p_all") };
}
function feedSub(r) {
  const monthly = MONTHLY.has(r.agency);
  return `${dot(r.agency)}${esc(agName(r.agency))} · ${esc(monthly ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) + " (" + t("month_income") + ")" : fmtDate(r.day))}` +
    `${r.first ? ` · <b>${esc(t("first_sale"))}</b>` : ""}${r.q ? ` · <span title="${esc(t("buyer_q"))}">🔍 ${esc(r.q)}</span>` : ""}`;
}
async function loadOvLists() {
  const p = chartPeriod();
  $("#ovFeedTitle").textContent = S.chart.view === "all" ? t("latest") : t("sales_in", { p: p.label });
  $("#ovBestTitle").textContent = t("best_in", { p: p.label });
  try {
    const f = await api("feed", { limit: 10, period: p.period === "all" ? "" : p.period, monthly: S.chart.view === "month" });
    $("#ovFeed").innerHTML = f.rows.length ? f.rows.map((r) => mrow(r, `${amt(r)}${r.cnt > 1 ? `<small>×${r.cnt}</small>` : ""}`, feedSub(r))).join("")
      : `<div class="empty">${esc(t("no_sales"))}</div>`;
    bindRows($("#ovFeed"));
    const b = await api("best", { period: p.period, limit: 10 });
    $("#ovBest").innerHTML = b.rows.length ? b.rows.map((r) => mrow({ ...r, agency: r.members[0]?.agency, agency_item_id: r.members[0]?.agency_item_id },
      `${usd(r.e)}${r.counts && r.n ? `<small>${dlS(int(r.n))}</small>` : ""}`, r.members.map((m) => `${dot(m.agency)}${usd(m.e)}`).join(" &nbsp;"))).join("")
      : `<div class="empty">${esc(t("no_sales"))}</div>`;
    bindRows($("#ovBest"));
  } catch (e) { toast(e.message, "err"); }
}
$("#ovFeedMore").addEventListener("click", () => { PP.f.set(chartPeriod().period); showPage("sales"); });
$("#ovBestMore").addEventListener("click", () => { PP.b.set(chartPeriod().period); showPage("best"); });

/* ============================================================ perioda izvēle (kā Microstockr)
   Izvēlne: Visa vēsture · Diena · Mēnesis · Gads · Laika intervāls; bultiņas ‹ › pāršķir dienas / mēnešus / gadus.
   Vērtība serverim: "all" | "YYYY-MM-DD" | "YYYY-MM" | "YYYY" | "YYYY-MM-DD..YYYY-MM-DD". */
const isoD = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
function PeriodPicker(sel, onChange, initial = "month") {
  const root = $(sel);
  const P = { kind: "month", d: new Date(), from: "", to: "" };
  root.innerHTML = `<select class="pp-kind"></select>
    <span class="period-nav pp-nav"><button class="icon pp-prev" data-i18n-title="prev">‹</button><span class="pp-label"></span><button class="icon pp-next" data-i18n-title="next">›</button></span>
    <span class="pp-range hidden"><input type="date" class="pp-from"> – <input type="date" class="pp-to"></span>`;
  const kindSel = $(".pp-kind", root);
  function render() {
    kindSel.innerHTML = [["all", "p_all"], ["day", "pk_day"], ["month", "pk_month"], ["year", "pk_year"], ["range", "pk_range"]]
      .map(([v, k]) => `<option value="${v}">${esc(t(k))}</option>`).join("");
    kindSel.value = P.kind;
    applyI18n(root);
    $(".pp-nav", root).classList.toggle("hidden", P.kind === "all" || P.kind === "range");
    $(".pp-range", root).classList.toggle("hidden", P.kind !== "range");
    const d = P.d;
    $(".pp-label", root).textContent = P.kind === "day" ? cap(d.toLocaleDateString(loc(), { weekday: "short" })) + ", " + fmtDate(isoD(d)) + (d.getFullYear() === new Date().getFullYear() ? " " + d.getFullYear() : "")
      : P.kind === "month" ? fmtMonth(d.getFullYear(), d.getMonth() + 1) : String(d.getFullYear());
    $(".pp-next", root).disabled = !canShift(1);
    if (P.kind === "range") { $(".pp-from", root).value = P.from; $(".pp-to", root).value = P.to; }
  }
  function shifted(dir) {
    const d = new Date(P.d);
    if (P.kind === "day") d.setDate(d.getDate() + dir);
    else if (P.kind === "month") { d.setDate(1); d.setMonth(d.getMonth() + dir); }
    else d.setFullYear(d.getFullYear() + dir);
    return d;
  }
  function canShift(dir) {
    if (dir < 0) return true;
    const n = shifted(1), now = new Date();
    if (P.kind === "day") return isoD(n) <= isoD(now);
    if (P.kind === "month") return n.getFullYear() * 12 + n.getMonth() <= now.getFullYear() * 12 + now.getMonth();
    return n.getFullYear() <= now.getFullYear();
  }
  function changed() { render(); onChange(); }
  kindSel.addEventListener("change", () => {
    P.kind = kindSel.value;
    P.d = new Date();                       // jauns perioda veids — sākam no šodienas
    if (P.kind === "range" && !P.from) { const n = new Date(); P.to = isoD(n); n.setDate(n.getDate() - 29); P.from = isoD(n); }
    changed();
  });
  $(".pp-prev", root).addEventListener("click", () => { P.d = shifted(-1); changed(); });
  $(".pp-next", root).addEventListener("click", () => { if (canShift(1)) { P.d = shifted(1); changed(); } });
  [".pp-from", ".pp-to"].forEach((c) => $(c, root).addEventListener("change", () => {
    P.from = $(".pp-from", root).value; P.to = $(".pp-to", root).value;
    if (P.from && P.to) onChange();
  }));
  const api_ = {
    get value() {
      const d = P.d, y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0");
      if (P.kind === "all") return "all";
      if (P.kind === "day") return isoD(d);
      if (P.kind === "month") return `${y}-${m}`;
      if (P.kind === "year") return String(y);
      return P.from && P.to ? `${P.from}..${P.to}` : "all";
    },
    set(v, quiet = false) {
      v = String(v || "all");
      let m;
      if (v === "all") P.kind = "all";
      else if ((m = v.match(/^(\d{4})-(\d{2})-(\d{2})$/))) { P.kind = "day"; P.d = new Date(+m[1], +m[2] - 1, +m[3]); }
      else if ((m = v.match(/^(\d{4})-(\d{2})$/))) { P.kind = "month"; P.d = new Date(+m[1], +m[2] - 1, 1); }
      else if ((m = v.match(/^(\d{4})$/))) { P.kind = "year"; P.d = new Date(+m[1], 0, 1); }
      else if ((m = v.match(/^(\S+)\.\.(\S+)$/))) { P.kind = "range"; P.from = m[1]; P.to = m[2]; }
      else if (v === "month") { P.kind = "month"; P.d = new Date(); }
      else if (v === "year") { P.kind = "year"; P.d = new Date(); }
      render();
    },
    render,
  };
  api_.set(initial);
  return api_;
}
/* ============================================================ pārdošanas (plūsma) */
function agencyOptions(sel) {
  const cur = sel.value;
  sel.innerHTML = `<option value="">${esc(t("all_agencies"))}</option>` + AG.map((a) => `<option value="${a}">${esc(agName(a))}</option>`).join("");
  sel.value = cur || "";
}
let feedT = null;
["#fSearch"].forEach((s) => $(s).addEventListener("input", () => { clearTimeout(feedT); feedT = setTimeout(() => loadFeed(true), 300); }));
["#fAgency", "#fEd"].forEach((s) => $(s).addEventListener("change", () => loadFeed(true)));
$("#feedMore").addEventListener("click", () => loadFeed(false));
/* Kāpēc šī summa ≠ Pārskata summa: īsa rinda + saite uz skaidrojumu Izmaksās (lietotājs 2026-10-30) */
async function loadCov() {
  const box = $("#fCov");
  let d;
  try { d = await api("coverage", { period: PP.f.value, agency: $("#fAgency").value, monthly: MONTHLY.has($("#fAgency").value) }); } catch (_) { box.classList.add("hidden"); return; }
  const gap = Math.round((d.total - d.list) * 100) / 100;
  if (Math.abs(gap) < 1) { box.classList.add("hidden"); return; }
  box.innerHTML = `<div class="cov-line">${esc(t("cov_line", { l: usd(d.list), t: usd(d.total), g: usd(Math.abs(gap)) }))}
      <a href="#" id="fCovT">${esc(t("cov_why"))}</a></div>`;
  box.classList.remove("hidden");
  $("#fCovT").addEventListener("click", (e) => { e.preventDefault(); showPage("payouts"); setTimeout(() => $("#payExplainSec").scrollIntoView({ behavior: "smooth" }), 300); });
}
/* Izmaksas: Pārskats = par bildēm + citi ienākumi + tikai kopsumma (+ nesakrīt) — pa aģentūrām, ar summām (test51) */
async function loadExplain() {
  const box = $("#payExplain");
  let d;
  try { d = await api("explain", {}); } catch (_) { box.innerHTML = ""; return; }
  const ym = (m) => fmtMonth(+m.slice(0, 4), +m.slice(5, 7));
  const per = (a, b) => a === b ? ym(a) : `${ym(a)} – ${ym(b)}`;
  const v = (x) => Math.abs(x) >= 0.01 ? usd(x) : "";
  const why = (r) => {
    const w = [];
    if (r.t20 >= 0.01) w.push(t("ex_t20", { s: usd(r.t20), n: r.t20_n, p: per(r.t20_from, r.t20_to) }));
    if (r.only_e >= 0.01) w.push(t("ex_only_l", { s: usd(r.only_e), n: r.only_n, p: per(r.only_from, r.only_to) }));
    if (Math.abs(r.rest) >= 1) w.push(t(r.rest > 0 ? "ex_rest_more" : "ex_rest_less", { s: usd(Math.abs(r.rest)) }));
    return w;
  };
  const line = (k, x, cls) => `<span${cls ? ` class="${cls}"` : ""}>${esc(t(k))}</span><b${cls ? ` class="${cls}"` : ""}>${usd(x)}</b>`;
  /* test4: aktuālie citi ienākumi (piem. Depositphotos RSM) augšā un redzami uzreiz, garais skaidrojums apakšā */
  let recent = [];
  try { recent = (await api("feed", { kind: "other", limit: 8 })).rows || []; } catch (_) {}
  const fRow = (r) => `<tr><td>${esc(r.monthly ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) : fmtDate(r.day))}</td>
      <td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td class="ex-k">${esc(r.title || r.license || "")}</td><td>${usd(r.amount_usd)}</td></tr>`;
  const top = recent.length ? `<h3 class="ex-h" style="margin-top:0">${esc(t("ex_recent"))}</h3><table class="t small ex-t"><tbody>${recent.map(fRow).join("")}</tbody></table>` : "";
  const types = d.types.length ? `<h3 class="ex-h">${esc(t("ex_types"))}</h3><table class="t small ex-t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("ex_c_kind"))}</th><th>${esc(t("ex_c_per"))}</th><th>${esc(t("ex_c_sum"))}</th></tr></thead><tbody>` +
      d.types.map((x) => `<tr><td>${dot(x.agency)} ${esc(agName(x.agency))}</td><td class="ex-k">${esc(x.label || t("ex_other_def"))}</td><td class="muted">${esc(per(x.from, x.to))}</td><td>${usd(x.e)}</td></tr>`).join("") +
      `</tbody></table>` : "";   // lietotājs 2026-11-04: "Rādīt visus citu ienākumu maksājumus" vairs nevajag
  box.innerHTML = top + types + `<h3 class="ex-h">${esc(t("ex_long"))}</h3><div class="ex-sum">${line("ex_sale", d.sale)}${line("ex_other", d.other)}${line("ex_only", d.only)}` +
      (Math.abs(d.rest) >= 1 ? line("ex_rest", d.rest) : "") + line("ex_total", d.total, "ex-tot") + `</div>
    <p class="small"><a href="#" id="exAgT">▸ ${esc(t("ex_intro"))}</a></p>
    <table class="t small ex-t hidden" id="exAgTab"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("ex_c_total"))}</th><th>${esc(t("ex_c_sale"))}</th><th>${esc(t("ex_c_other"))}</th><th>${esc(t("ex_c_only"))}</th></tr></thead><tbody>` +
    d.rows.map((r) => { const w = why(r);
      return `<tr><td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td>${usd(r.total)}</td><td>${v(r.sale)}</td><td>${v(r.other)}</td><td>${v(r.only)}</td></tr>` +
        (w.length ? `<tr class="ex-w"><td colspan="5">${w.map((x) => `<div>${esc(x)}</div>`).join("")}</td></tr>` : ""); }).join("") + `</tbody></table>`;
  /* lietotājs 2026-11-04: tabula pa aģentūrām atveras, uzklikšķinot uz paskaidrojuma teksta */
  $("#exAgT").addEventListener("click", (e) => {
    e.preventDefault();
    const tb = $("#exAgTab"), open = tb.classList.toggle("hidden") === false;
    e.currentTarget.textContent = (open ? "▾ " : "▸ ") + t("ex_intro");
  });
}
async function loadFeed(reset) {
  if (reset) { S.feed.offset = 0; S.feed.rows = []; }
  try {
    $("#fEd").classList.toggle("hidden", !ED_ON());
    const d = await api("feed", { agency: $("#fAgency").value, period: PP.f.value, kind: "sale", search: $("#fSearch").value, offset: S.feed.offset, limit: 80,
      monthly: MONTHLY.has($("#fAgency").value), ed: ED_ON() ? $("#fEd").value : "", ed_split: ED_ON() && reset });
    S.feed.rows = S.feed.rows.concat(d.rows);
    S.feed.offset += d.rows.length;
    $("#fSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.earnings)}</b></span>${d.downloads ? `<span>${esc(t("downloads"))}: <b>${int(d.downloads)}</b></span>` : ""}<span>${esc(t("files"))}: <b>${int(d.files)}</b></span>` +
      (d.ed_split ? `<span title="${esc(t("ed_split_t"))}">RF <b>${usd(d.ed_split.rf)}</b> · ED <b>${usd(d.ed_split.ed)}</b></span>` : "");
    if (reset && !$("#fSearch").value) loadCov(); else $("#fCov").classList.add("hidden");
    const g = $("#feedGrid");
    const html = d.rows.map((r) => `<div class="tile${r.fresh ? " fresh" : ""}" data-ag="${esc(r.agency)}" data-id="${esc(r.agency_item_id)}" ${tipAttr(r)}>
      <div class="img ${r.thumb ? "" : "noimg"}" ${thAttr(r, 240, label(r, r.agency, r.agency_item_id))}><span class="selbox"></span>${r.thumb ? "" : `<span class="nt">${esc(label(r, r.agency, r.agency_item_id))}</span>`}${r.first ? `<span class="badge">${esc(t("first_sale"))}</span>` : ""}${r.cnt > 1 ? `<span class="cnt">×${r.cnt}</span>` : ""}${edBadge(r)}</div>
      <div class="body"><div class="am">${amt(r)}${r.kind === "other" ? `<small>${esc(t("other_pay"))}</small>` : ""}</div>
      <div class="meta">${dot(r.agency)}${esc(agName(r.agency))}<span class="d">${esc(MONTHLY.has(r.agency) || r.monthly ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) : fmtDate(r.day))}</span></div>
      ${r.thumb ? `<div class="ttl">${esc(r.title || r.filename || "")}</div>` : ""}
      ${r.q ? `<div class="ttl q" title="${esc(t("buyer_q"))}">🔍 ${esc(r.q)}</div>` : ""}</div></div>`).join("");
    if (reset) g.innerHTML = html || `<div class="empty">${esc(t("no_sales"))}</div>`;
    else g.insertAdjacentHTML("beforeend", html);
    bindRows(g);
    $("#feedMore").classList.toggle("hidden", S.feed.offset >= d.count);
  } catch (e) { toast(e.message, "err"); }
}

/* ============================================================ labākās */
let bestT = null;
$("#bSearch").addEventListener("input", () => { clearTimeout(bestT); bestT = setTimeout(() => loadBest(true), 300); });
["#bAgency", "#bSort", "#bGroup", "#bOther"].forEach((s) => $(s).addEventListener("change", () => loadBest(true)));
$("#bestMore").addEventListener("click", () => loadBest(false));
async function loadBest(reset) {
  if (reset) { S.best.offset = 0; S.best.rows = []; }
  try {
    const d = await api("best", { agency: $("#bAgency").value, period: PP.b.value, search: $("#bSearch").value, sort: $("#bSort").value,
      group: $("#bGroup").checked, other: $("#bOther").value, offset: S.best.offset, limit: 48 });
    const start = S.best.offset;
    S.best.rows = S.best.rows.concat(d.rows);
    S.best.offset += d.rows.length;
    $("#bSum").innerHTML = `<span>${esc(t("earnings"))}: <b>${usd(d.earnings)}</b></span>${d.downloads ? `<span>${esc(t("downloads"))}: <b>${int(d.downloads)}</b></span>` : ""}<span>${esc(t("items"))}: <b>${int(d.count)}</b></span>`;
    const ag = $("#bAgency").value;
    $("#bestNote").textContent = (!ag || ag === "envato") && d.rows.some((r) => r.members.some((m) => m.agency === "envato")) ? t("envato_best_note") : "";
    const g = $("#bestGrid");
    const html = d.rows.map((r, i) => {
      const m0 = r.members[0] || {};
      const img = thumb(r.thumb);
      return `<div class="tile" data-ag="${esc(m0.agency)}" data-id="${esc(m0.agency_item_id)}" data-parts="${r.members.length}" ${tipAttr(r)}>
        <div class="img ${img ? "" : "noimg"}" ${thAttr(r, 240, label(r, m0.agency, m0.agency_item_id))}><span class="selbox"></span>${img ? "" : `<span class="nt">${esc(label(r, m0.agency, m0.agency_item_id))}</span>`}<span class="rank">#${start + i + 1}</span>${edBadge(r)}</div>
        <div class="body"><div class="am">${usd(r.e)}${r.counts && r.n ? `<small>${dlS(int(r.n))}</small>` : ""}</div>
        <div class="mem">${r.members.map((m) => `<span title="${esc(agName(m.agency))}">${dot(m.agency)}${usd(m.e)}</span>`).join("")}</div>
        ${img ? `<div class="ttl">${esc(r.title || r.filename || "")}</div>` : ""}</div></div>`;
    }).join("");
    if (reset) g.innerHTML = html || `<div class="empty">${esc(t("no_sales"))}</div>`;
    else g.insertAdjacentHTML("beforeend", html);
    bindRows(g);
    $("#bestMore").classList.toggle("hidden", S.best.offset >= d.count);
  } catch (e) { toast(e.message, "err"); }
}

/* --- vienuma logs --- */
async function openItem(agency, id) {
  if (!agency || !id) return;
  try {
    const { item } = await api("item", { agency, agency_item_id: id });
    if (!item || !item.members) return;
    const maxY = Math.max(...item.years.map((y) => y.e), 0.01);
    const img = thumb(item.thumb, 500);
    /* lupa — meklēt bildi internetā pēc sīktēla (Shutterstock sīktēli ārpus to lapas mēdz neatvērties → cits sīktēls);
       ķēde — bilde aģentūras lapā (lietotājs 2026-10-30, kā Microstockr) */
    const ths = [item.thumb].concat(item.members.map((m) => m.thumb)).filter((u) => u && /^https?:/.test(u));
    const lensTh = ths.find((u) => !/shutterstock/.test(u)) || ths[0] || "";
    const link = (item.members.find((m) => m.url) || {}).url || "";
    const acts = (lensTh ? `<a class="ba" href="https://lens.google.com/uploadbyurl?url=${encodeURIComponent(lensTh)}" target="_blank" rel="noopener" title="${esc(t("find_web"))}">🔍</a>` : "") +
      (link ? `<a class="ba" href="${esc(link)}" target="_blank" rel="noopener" title="${esc(t("open_agency"))}">🔗</a>` : "");
    $("#itemBody").innerHTML = `<div class="item-head">
        <div class="big" id="itemBig">${acts ? `<div class="big-acts">${acts}</div>` : ""}</div>
        <div><h3>${esc(item.title || "")}</h3>
          <div class="item-tot"><div class="money"><b>${usd(item.e)}</b>${esc(t("earnings"))}</div>${item.counts && item.n ? `<div><b>${int(item.n)}</b>${esc(t("downloads"))}</div>
            <div><b>${usd(item.e / item.n)}</b>RPD</div>` : ""}</div>
          <table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("earnings"))}</th>${DL_TH()}<th>${esc(t("first_sold"))}</th><th>${esc(t("last_sold"))}</th><th></th></tr></thead><tbody>
          ${item.members.map((m) => `<tr><td>${dot(m.agency)} ${esc(agName(m.agency))}${m.filename ? `<div class="muted small">${esc(m.filename)}</div>` : ""}</td><td>${usd(m.e)}</td><td>${m.counts && m.n ? int(m.n) : "–"}</td>
            <td>${esc(fmtDate(m.first))}</td><td>${esc(fmtDate(m.last))}</td><td>${m.url ? `<a href="${esc(m.url)}" target="_blank" rel="noopener">${esc(t("open"))}</a>` : ""}</td></tr>`).join("")}
          </tbody></table>
          ${item.members.length > 1 ? `<p class="muted small">${esc(t("grouped_note"))}</p>` : ""}
          <div class="item-colls"><span class="muted">${esc(t("coll_in"))}</span>${(item.colls || []).map((c) => `<span class="chip" data-coll="${c.id}">${esc(c.name)}</span>`).join("") || "–"}
            <button class="small-btn" id="itemCollAdd">${esc(t("coll_add"))}</button></div>
          ${ED_ON() && item.ed ? `<div class="item-colls"><span class="muted">RF/ED:</span><b>${item.ed.ed ? "ED" : "RF"}</b><span class="muted small">${esc(t("ed_src_" + item.ed.src))}</span>
            <button class="small-btn" data-ed="1">${esc(t("ed_mark_ed"))}</button><button class="small-btn" data-ed="0">${esc(t("ed_mark_rf"))}</button>${item.ed.src === "user" ? `<button class="small-btn" data-ed="x">${esc(t("ed_mark_auto"))}</button>` : ""}</div>` : ""}
        </div></div>
      <div class="two">
        <div class="item-sec"><h4>${esc(t("by_year"))}</h4><div class="ybars">${item.years.map((y) => `<div class="ybar"><span>${esc(y.y)}</span><span class="b"><i style="width:${(y.e / maxY) * 100}%"></i></span><span>${usd(y.e)}</span></div>`).join("") || `<span class="muted small">–</span>`}</div></div>
        <div class="item-sec"><h4>${esc(t("recent_sales"))}</h4>
          <table class="t"><tbody>${item.recent.map((r) => `<tr><td>${dot(r.agency)} ${esc(MONTHLY.has(r.agency) ? fmtMonth(+r.day.slice(0, 4), +r.day.slice(5, 7)) : fmtDate(r.day))}</td><td class="muted">${esc(r.license || kindLabel(r.kind))}${r.q ? ` · 🔍 ${esc(r.q)}` : ""}</td><td>${r.cnt > 1 ? "×" + r.cnt : ""}</td><td>${amt(r)}</td></tr>`).join("")}</tbody></table>
          ${item.recent.length ? "" : `<span class="muted small">${esc(t("no_detail"))}</span>`}</div>
      </div>`;
    {
      const base = thList({ ...item, members: item.members }, 500, item.members);
      probeBest($("#itemBig"), [...new Set([...base.flatMap(bigVar), ...base])]);
    }
    $("#itemModal").classList.remove("hidden");
    $("#itemCollAdd").addEventListener("click", () => pickColl([{ agency, agency_item_id: id }]));
    $$("#itemBody [data-ed]").forEach((b) => b.addEventListener("click", async () => {
      await edMark([{ agency, agency_item_id: id }], b.dataset.ed === "x" ? null : +b.dataset.ed, false);
      openItem(agency, id);
    }));
    $$("#itemBody [data-coll]").forEach((c) => c.addEventListener("click", () => { $("#itemModal").classList.add("hidden"); clearSel(); openColl(+c.dataset.coll); }));
  } catch (e) { toast(e.message, "err"); }
}
function kindLabel(k) {
  const L = { "25_a_day": t("k_sub"), single_image_and_other: t("k_single"), on_demand: t("k_od"), elements: t("k_elements"), other: t("other_pay"), sale: "" };
  return k in L ? L[k] : (k || "");
}
$("#itemClose").addEventListener("click", () => $("#itemModal").classList.add("hidden"));
$("#itemModal").addEventListener("click", (e) => { if (e.target.id === "itemModal") $("#itemModal").classList.add("hidden"); });
document.addEventListener("keydown", (e) => {
  if (e.key !== "Escape") return;
  if (!$("#dlg").classList.contains("hidden")) return closeDlg(null);
  $$(".modal").forEach((m) => m.classList.add("hidden"));
});

/* ============================================================ izmaksas (3. daļa) */
/* 0.3.1: Izmaksu cilnes valūta (iestatījums sales_pay_currency; lietotājs 2026-11-01). Serveris dod EUR summas; rādām
   izvēlētajā valūtā pēc šodienas kursa (S.rates: 1 EUR = ? X). "agency" — kopsummas eiro, rindas aģentūras valūtā. */
const CSYM = { EUR: "€", USD: "$", GBP: "£", UAH: "₴" };
const fmtC = (v, c, d = 2) => (CSYM[c] || "") + (+v || 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const payCur = () => { const c = (S.settings && S.settings.sales_pay_currency) || "EUR"; return c === "agency" || !(S.rates || {})[c] ? "EUR" : c; };
const eur = (v, d = 2) => { const c = payCur(); return fmtC((+v || 0) * ((S.rates || {})[c] || 1), c, d); };
const eur0 = (v) => eur(v, Math.abs(v) >= 1000 ? 0 : 2);
const inCur = (v, cur) => (v == null ? "–" : CSYM[cur] ? fmtC(v, cur) : usd(v));
/* "$153.38 ≈ €137.29" — aģentūras valūta un izvēlētā valūta (ja atšķiras) */
const both = (amt, cur, eurV) => (amt == null ? eur(eurV) : cur === payCur() ? inCur(amt, cur) : `${inCur(amt, cur)} <span class="muted">≈ ${eur(eurV)}</span>`);
S.pay = { year: 0, data: null, table: false };
$("#payPrev").addEventListener("click", () => { S.pay.year--; loadPayouts(); });
$("#payNext").addEventListener("click", () => { S.pay.year++; loadPayouts(); });
$("#payTableBtn").addEventListener("click", () => { S.pay.table = !S.pay.table; renderPayChart(); });
async function loadPayouts() {
  if (!S.pay.year) S.pay.year = new Date().getFullYear();
  try {
    const d = await api("payouts", { year: S.pay.year });
    S.pay.data = d.payouts; S.pay.rules = d.rules; S.pay.recent = d.recent; S.rates = d.rates || S.rates;
    renderPayouts();
  } catch (e) { toast(e.message, "err"); }
}
const modeTxt = (m) => t(m === "auto" ? "pay_auto" : m === "request" ? "pay_request" : "pay_unknown");
function renderPayouts() {
  const d = S.pay.data;
  if (!d) return;
  const sal = d.salary;
  const byList = (o) => `<div class="by">${AG.filter((a) => o[a]).map((a) => `<div class="agrow">${dot(a)}<span class="nm">${esc(agName(a))}</span><span class="val">${eur(o[a])}</span></div>`).join("")}</div>`;
  const expBy = Object.fromEntries(sal.expected_by.map((x) => [x.agency, x.eur]));
  const expList = `<div class="by">${sal.expected_by.map((x) => `<div class="agrow">${dot(x.agency)}<span class="nm">${esc(agName(x.agency))}${x.req_at ? ` <span class="muted small">${esc(t("pay_req_mark", { d: fmtDate(x.req_from && x.req_from < x.req_at ? x.req_from : x.req_at) }))}</span>` : ""}${x.pay_date && !x.req_at ? ` <span class="muted small">${esc(t("pay_date_mark", { d: fmtDate(x.pay_date) }))}</span>` : ""}</span><span class="val">${both(x.amount, x.currency, x.eur)}</span></div>`).join("")}</div>`;
  const mName = (ym) => fmtMonth(+ym.slice(0, 4), +ym.slice(5, 7));
  const cards = [
    { k: t("pay_c_received", { m: mName(sal.month) }), v: eur(sal.received), sub: "", by: byList(sal.received_by) },
    { k: t("pay_c_expected", { m: mName(sal.next_month) }), v: "~" + eur(sal.expected), cls: "salary",
      sub: sal.fc_current ? t("pay_c_expected_cur", { d: sal.last_pay_day }) : t("pay_c_expected_d"), by: expList },
    { k: t("pay_c_unpaid"), v: "~" + eur(sal.unpaid_total), sub: t("pay_c_unpaid_d"), by: "" },
    { k: t("pay_c_avg", { y: d.year }), v: eur(d.avg), sub: t("pay_c_avg_d", { s: eur(d.year_tot), n: d.avg_months }), by: "" },
  ];
  $("#payCards").innerHTML = cards.map((x) => `<div class="card ${x.cls || ""}"><div class="k">${esc(x.k)}</div><div class="v">${x.v}</div>
    ${x.sub ? `<div class="sub">${esc(x.sub)}</div>` : ""}${x.by}</div>`).join("");
  // var pieprasīt
  const rq = $("#payReq");
  rq.classList.toggle("hidden", !d.can_request.length);
  rq.classList.toggle("last-day", !!d.last_day);
  if (d.can_request.length) {
    /* 0.3.1 (noteikumi §2.4): programma izmaksas nepieprasa — tikai saraksts un saites "Atvērt" */
    rq.innerHTML = `<div class="panel-head"><h2>${esc(t(d.last_day ? "pay_req_today" : "pay_req_h"))}</h2></div>
      <p class="muted small">${esc(t("pay_req_d"))}</p>
      <div class="req-list">${d.can_request.map((x) => `<div class="req">${dot(x.agency)}<b>${esc(agName(x.agency))}</b>
        <span class="amt">${both(x.amount, x.currency, x.eur)}</span>${x.validate ? `<span class="small">${esc(t("pay_validate"))}</span>` : ""}
        <a href="${esc(x.url)}" target="_blank" rel="noopener">${esc(t("pay_open"))}</a>${reqBox(x)}</div>`).join("")}</div>`;
  }
  // aģentūru tabula
  const rows = d.rows;
  $("#payTable").innerHTML = rows.length ? `<table class="t pay-t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("pay_mode"))}</th>
      <th>${esc(t("pay_unpaid"))}</th><th>${esc(t("pay_available"))}</th><th>${esc(t("pay_min"))}</th><th>${esc(t("pay_progress"))}</th>
      <th>${esc(t("pay_last"))}</th><th></th></tr></thead><tbody>` +
    rows.map((r) => `<tr class="${r.ready ? "ready" : ""}"><td>${dot(r.agency)} ${esc(agName(r.agency))}</td>
      <td><span class="mode ${r.mode || "none"}">${esc(r.mag ? t("pay_validate") : modeTxt(r.mode))}</span>${magTip(r)}</td>
      <td>${inCur(r.unpaid, r.currency)}${netTip(r, "unpaid")}</td><td>${r.available == null ? "–" : inCur(r.available, r.currency) + netTip(r, "available")}</td>
      <td>${r.min ? inCur(r.min, r.currency) : "–"}</td>
      <td>${r.pct == null ? "–" : `<span class="share"><i style="width:${r.pct}%;background:${r.ready ? "var(--ok)" : "var(--ag-" + r.agency + ")"}"></i></span> ${r.ready ? `<b class="okc">${esc(t("pay_ready"))}</b>` : r.pct + "%"}`}</td>
      <td>${r.last ? `${esc(fmtDate(r.last.paid_at))} · ${inCur(r.last.amount, r.last.currency)}` : "–"}${lastTip(r)}${reqLine(r)}${payAction(r)}</td>
      <td><a href="${esc(r.url)}" target="_blank" rel="noopener">${esc(t("pay_open"))}</a></td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // gadi
  $("#payYears").innerHTML = d.years.length ? `<table class="t"><thead><tr><th>${esc(t("pay_year"))}</th><th>${esc(t("pay_paid_eur"))}</th><th>+/-</th></tr></thead><tbody>` +
    d.years.slice().reverse().map((y) => `<tr><td>${esc(y.y)}</td><td><b>${eur(y.e)}</b></td><td>${y.d == null ? "–" : `<span class="${y.d >= 0 ? "okc" : "badc"}">${y.d >= 0 ? "+" : ""}${y.d}%</span>`}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // pēdējās izmaksas
  $("#payRecent").innerHTML = (S.pay.recent || []).length ? `<table class="t"><tbody>` + S.pay.recent.slice(0, 15).map((r) =>
    `<tr><td>${esc(fmtDate(r.paid_at))}</td><td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td>${inCur(r.amount, r.currency)}${grossNote(r)}</td><td class="muted">${r.currency !== "EUR" ? "~" + eur(r.amount_eur) : ""}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_none"))}</div>`;
  // neizmaksātais mēneša beigās
  const hAg = AG.filter((a) => d.hist[a]);
  $("#payHist").innerHTML = hAg.length ? `<table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("pay_unpaid_c"))}</th><th>${esc(t("pay_month_end"))}</th></tr></thead><tbody>` +
    hAg.map((a) => `<tr><td>${dot(a)} ${esc(agName(a))}</td><td>${inCur(d.hist[a][0], d.hist[a][1])}</td><td class="muted">${esc(fmtMonth(+d.hist[a][2].slice(0, 4), +d.hist[a][2].slice(5, 7)))}</td></tr>`).join("") + `</tbody></table>`
    : `<div class="empty">${esc(t("pay_hist_empty"))}</div>`;
  loadExplain();
  renderPayChart();
}
/* 2026-11-04: Zoonar — saņemts pēc nodokļa; aģentūras vēsturē bruto summa un pieprasījuma diena */
/* lietotājs 09:56: paskaidrojums ⓘ mākonītī, nevis atsevišķā rindiņā (tabula pārskatāmāka) */
const infoTip = (txt) => ` <span class="tip info-i" title="${esc(txt)}">ⓘ</span>`;
const grossNote = (p) => (String(p.status || "").startsWith("bruto ") ? infoTip(t("pay_gross_note", {
  v: inCur(+p.status.slice(6), p.currency), d: fmtDate(String(p.ref || "").slice(4, 14)) })) : "");
const netTip = (r, k) => (r.gross && r.gross[k] != null ? infoTip(t("pay_net_note", { v: inCur(r.gross[k], r.currency), p: r.tax_pct })) : "");
/* 2026-11-04 (lietotājs): ķeksis "Izmaksu jau pieprasīju" — šodiena = pieprasījuma datums, vairs neatgādina */
const reqBox = (x) => (x.validate ? "" : `<label class="small req-done"><input type="checkbox" data-ag="${esc(x.agency)}"> ${esc(t("pay_req_done_cb"))}</label>`);
async function markRequested(ag, on) {
  try {
    await api("payout_mark", { agency: ag, on });
    toast(t(on ? "pay_req_marked" : "pay_unmarked", { a: agName(ag) }), "ok");
  } catch (e) { toast(e.message, "err"); }
  payReminder();
  if (S.pay && S.pay.data) loadPayouts();
}
document.addEventListener("change", (e) => {
  const el = e.target;
  if (el.matches && el.matches(".req-done input") && el.checked) markRequested(el.dataset.ag, true);
});
document.addEventListener("click", (e) => {
  const el = e.target.closest && e.target.closest(".pay-unmark");
  if (el) markRequested(el.dataset.ag, false);
});
/* Izmaksu tabula (lietotājs 2026-11-04 09:59): visi paskaidrojumi — ⓘ mākonītī, ne atsevišķās rindiņās.
   Redzams paliek tikai tas, kas prasa rīcību (Magnific rēķins jāapstiprina). */
function lastTip(r) {
  const o = [];
  if (r.last && String(r.last.status || "").startsWith("bruto ")) o.push(t("pay_gross_note", { v: inCur(+r.last.status.slice(6), r.last.currency), d: fmtDate(String(r.last.ref || "").slice(4, 14)) }));
  if (r.next_date) o.push(t("pay_next", { d: fmtDate(r.next_date) }));
  if (r.mag && r.mag.pending && !r.mag.pending_ok) o.push(t("mag_pending_low", { v: inCur(r.mag.pending, "EUR"), min: inCur(r.min || 50, "EUR") }));
  if (r.pay_if_today && !r.req) o.push(t("pay_if_today", { d: fmtDate(r.pay_if_today) }));
  if (r.hold_d) o.push(t("pay_hold", { n: r.hold_d }));
  if (r.env_for) o.push(t("pay_env_for", { m: fmtMonth(+r.env_for.slice(0, 4), +r.env_for.slice(5, 7)) }));
  if (!o.length) return "";
  return infoTip(o.join("\n"));
}
/* lietotājs 10:01: pieprasījuma stāvoklis ("pieprasīts … — gaida izmaksu") paliek redzams — tas ir statuss, ne paskaidrojums */
function reqLine(r) {
  if (!r.req) return "";
  return `<div class="small ${r.req.ok ? "okc" : "badc"}" title="${esc(r.req.info || "")}">${esc(t(r.req.ok ? (r.req.auto ? (r.req.from && r.req.from < r.req.at ? "pay_req_wait2" : "pay_req_wait") : "pay_req_was") : "pay_req_failed", { d: fmtDate(r.req.at), f: fmtDate(r.req.from) }))}${r.req.manual ? ` <button class="x pay-unmark" data-ag="${esc(r.agency)}" title="${esc(t("pay_unmark"))}">×</button>` : ""}</div>`;
}
function payAction(r) {
  return r.mag && r.mag.pending && r.mag.pending_ok ? `<div class="small"><b class="okc">${esc(t("mag_pending", { v: inCur(r.mag.pending, "EUR") }))}</b></div>` : "";
}
function magTip(r) {
  if (!r.mag) return "";
  const m = r.mag, mn = (ym) => (ym ? fmtMonth(+ym.slice(0, 4), +ym.slice(5, 7)) : "");
  const parts = [t("mag_expl", { all: inCur(m.net_all != null ? m.net_all : m.gross_all, "EUR"), all_g: inCur(m.gross_all, "EUR"), to: mn(m.matured_to), gross: inCur(m.gross, "EUR"),
    net: inCur(m.net, "EUR"), tax: m.tax, pct: r.pct == null ? 0 : r.pct, min: inCur(r.min || 50, "EUR") })];
  if (!m.pending) parts.push(m.inv_month ? t("mag_inv_m", { m: mn(m.inv_month) }) : t("mag_inv_none"));
  return infoTip(parts.join("\n"));
}
/* (0.3.0 "Pieprasīt visas" — 0.3.1 vairs neizmanto, noteikumi §2.4) */
async function requestPayouts(list) {
  const lines = list.map((x) => `${agName(x.agency)}: ${inCur(x.amount, x.currency)}`);
  if (!(await uiConfirm(t("pay_req_q", { l: lines.join(" · ") }), t("pay_req_all")))) return;
  try {
    const d = await api("payout_request", { agencies: list.map((x) => x.agency) });
    S.payoutRun = new Set(d.agencies);
    applySync(d.sync);
    toast(t("pay_req_started"), "ok", 7000);
  } catch (e) {
    if (e.data && e.data.need_webview) showPage("agencies");
    toast(e.message === "nothing" ? t("pay_req_nothing") : e.message, "err");
  }
}
function renderPayChart() {
  const d = S.pay.data;
  if (!d) return;
  $("#payYear").textContent = String(d.year);
  $("#payNext").disabled = d.year >= new Date().getFullYear();
  $("#payPrev").disabled = d.year <= +d.min_year;
  $("#payChartTitle").textContent = t("pay_chart", { y: d.year });
  const ags = AG.filter((a) => d.matrix[a]);
  const mm = [...Array(12)].map((_, i) => i + 1);
  const tot = (a) => Object.values(d.matrix[a]).reduce((s, v) => s + v, 0);
  $("#payLegend").classList.toggle("hidden", !S.pay.table);     // grafikos aģentūras redzamas "pa fotobankām"
  $("#payLegend").innerHTML = ags.length ? ags.map((a) => `<span class="li">${dot(a)}${esc(agName(a))} <b>${eur(tot(a))}</b></span>`).join("") : `<span class="muted">${esc(t("pay_none"))}</span>`;
  $("#paySum").innerHTML = `<span>${esc(t("pay_year_tot"))}: <b>${eur(d.year_tot)}</b></span><span>${esc(t("pay_avg"))}: <b>${eur(d.avg)}</b></span>`;
  $("#payCharts").classList.toggle("hidden", S.pay.table);
  $("#payMatrix").classList.toggle("hidden", !S.pay.table);
  $("#payTableBtn").textContent = t(S.pay.table ? "as_chart" : "as_table");
  const mLong = (m) => cap(new Date(d.year, m - 1, 15).toLocaleDateString(loc(), { month: "long" }));
  if (S.pay.table) {
    let cum = 0;
    $("#payMatrix").innerHTML = `<table class="t"><thead><tr><th></th>${ags.map((a) => `<th>${esc(agName(a))}</th>`).join("")}<th>${esc(t("pay_month_tot"))}</th><th>${esc(t("pay_avg_cum"))}</th></tr></thead><tbody>` +
      mm.map((m) => { cum += d.month_tot[m] || 0; return `<tr><td>${esc(mLong(m))}</td>${ags.map((a) => `<td>${d.matrix[a][m] ? eur(d.matrix[a][m]) : "–"}</td>`).join("")}<td><b>${d.month_tot[m] ? eur(d.month_tot[m]) : "–"}</b></td><td class="muted">${m <= d.avg_months ? eur(cum / m) : ""}</td></tr>`; }).join("") +
      `<tr class="tot"><td><b>${esc(t("total"))}</b></td>${ags.map((a) => `<td><b>${eur(tot(a))}</b></td>`).join("")}<td><b>${eur(d.year_tot)}</b></td><td></td></tr></tbody></table>`;
    return;
  }
  /* 1) pa fotobankām: gada summa katrai aģentūrai (vairāk par 11 — mazākās apvienotas "citi") */
  let byAg = ags.map((a) => ({ a, v: tot(a) })).filter((x) => x.v > 0);
  if (byAg.length > 11) {
    const big = [...byAg].sort((x, y) => y.v - x.v).slice(0, 10).map((x) => x.a);
    const rest = byAg.filter((x) => !big.includes(x.a)).reduce((s2, x) => s2 + x.v, 0);
    byAg = byAg.filter((x) => big.includes(x.a)).concat([{ a: "_other", v: rest }]);
  }
  barChart($("#payChartAg"), byAg.map((x) => ({ label: x.a === "_other" ? t("pay_others") : agName(x.a), v: x.v,
    color: `var(--ag-${x.a === "_other" ? "other" : x.a}, var(--ag-other))`, tip: x.a === "_other" ? t("pay_others") : agName(x.a) })), true);
  /* 2) pa mēnešiem: 12 stabiņi */
  barChart($("#payChart"), mm.map((m) => ({ label: new Date(2000, m - 1, 15).toLocaleDateString(loc(), { month: "short" }), v: d.month_tot[m] || 0,
    color: "var(--money, #6aa84f)", tip: `${mLong(m)} ${d.year}`, parts: ags.map((a) => [a, d.matrix[a][m] || 0]).filter((p) => p[1]) })), false);
}
/* vienkāršs stabiņu grafiks ar summu virs stabiņa (Izmaksām) */
function barChart(el, items, rotate) {
  if (!items.length) { el.innerHTML = `<div class="empty">${esc(t("pay_none"))}</div>`; return; }
  const W = Math.max(280, el.clientWidth), H = el.clientHeight || 250;
  const L = rotate ? 34 : 8, R = 8, T = 18, B = rotate ? 62 : 24, iw = W - L - R, ih = H - T - B;
  const max = niceMax(Math.max(...items.map((x) => x.v), 0)) || 1;
  const step = iw / items.length, bw = Math.max(8, Math.min(44, step * 0.62));
  const y = (v) => T + ih - (v / max) * ih;
  let svg = `<svg viewBox="0 0 ${W} ${H}" role="img"><g class="grid">`;
  for (let i = 0; i <= 4; i++) svg += `<line x1="${L}" x2="${W - R}" y1="${y((max / 4) * i)}" y2="${y((max / 4) * i)}"/>`;
  svg += `</g>`;
  items.forEach((x, i) => {
    const cx = L + step * i + step / 2, h = (x.v / max) * ih;
    if (h > 0.5) svg += `<rect fill="${x.color}" x="${cx - bw / 2}" y="${y(x.v)}" width="${bw}" height="${h}" rx="3"/>`;
    svg += `<text class="vlab" x="${cx}" y="${y(x.v) - 4}" text-anchor="middle">${(+x.v || 0).toLocaleString(loc(), { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</text>`;
    svg += rotate ? `<text class="xlab" text-anchor="end" transform="translate(${cx + 4},${T + ih + 12}) rotate(-40)">${esc(x.label.length > 14 ? x.label.slice(0, 13) + "…" : x.label)}</text>`
      : `<text class="xlab" x="${cx}" y="${H - 6}" text-anchor="middle">${esc(x.label)}</text>`;
    svg += `<rect class="hit" data-i="${i}" x="${L + step * i}" y="${T}" width="${step}" height="${ih}" fill="transparent"/>`;
  });
  el.innerHTML = svg + `</svg>`;
  $$(".hit", el).forEach((hEl) => {
    hEl.addEventListener("mousemove", (ev) => {
      const x = items[+hEl.dataset.i], tip = $("#tip");
      tip.innerHTML = `<div class="th">${esc(x.tip || x.label)}</div>` + (x.parts || []).map(([a, v]) => `<div class="tr"><span>${dot(a)}${esc(agName(a))}</span><span>${eur(v)}</span></div>`).join("") +
        `<div class="tr tt"><span>${esc(t("total"))}</span><span>${eur(x.v)}</span></div>`;
      tip.classList.remove("hidden");
      const w = tip.offsetWidth, xx = ev.clientX + 14 + w > innerWidth ? ev.clientX - w - 14 : ev.clientX + 14;
      tip.style.left = xx + "px"; tip.style.top = Math.max(8, ev.clientY - tip.offsetHeight - 10) + "px";
    });
    hEl.addEventListener("mouseleave", hideTip);
  });
}

/* ============================================================ aģentūras */
async function loadAgencies() {
  try {
    const d = await api("overview");
    S.ov = d;
    applySync(d.sync);
    renderAgencies();
    $("#wvBox").classList.toggle("hidden", d.webview);
  } catch (e) { toast(e.message, "err"); }
  loadAgTable();
  loadPortfolio();
}
/* ---------- portfelis pa mēnešiem / gadiem (test42) ---------- */
const PORT = { mode: "month", year: null, years: [] };
async function loadPortfolio() {
  $("#portPanel").classList.toggle("hidden", !PORT_ON());
  if (!PORT_ON()) return;
  let d;
  try { d = await api("portfolio", { year: PORT.mode === "year" ? "all" : (PORT.year || String(new Date().getFullYear())) }); }
  catch (e) { return toast(e.message, "err"); }
  PORT.years = d.years || [];
  if (PORT.mode === "month" && !PORT.year) PORT.year = PORT.years[0] || String(new Date().getFullYear());
  renderPortfolio(d);
}
function renderPortfolio(d) {
  const byM = PORT.mode === "month";
  $("#portByMonth").classList.toggle("on", byM); $("#portByYear").classList.toggle("on", !byM);
  $("#portNav").classList.toggle("hidden", !byM);
  $("#portLabel").textContent = byM ? PORT.year : "";
  const yi = PORT.years.indexOf(PORT.year);
  $("#portPrev").disabled = yi < 0 || yi >= PORT.years.length - 1;
  $("#portNext").disabled = yi <= 0;
  if (!d.rows.length) {
    $("#portTable").innerHTML = `<div class="empty">${esc(t("port_empty"))}</div>`;
    return;
  }
  const head = d.keys.map((k) => k.length === 7 ? new Date(+k.slice(0, 4), +k.slice(5, 7) - 1, 1).toLocaleDateString(loc(), { month: "short" }) : k);
  const cell = (v, prev) => {
    if (v == null) return `<td class="muted">–</td>`;
    const df = prev != null ? v - prev : null;
    return `<td${df ? ` title="${df > 0 ? "+" : "−"}${int(Math.abs(df))}"` : ""}>${int(v)}</td>`;
  };
  const row = (cells) => cells.map((v, i) => cell(v, i ? cells[i - 1] : null)).join("");
  const gr = (g) => g ? `<span class="pdelta ${g > 0 ? "up" : "down"}">${g > 0 ? "+" : "−"}${int(Math.abs(g))}</span>` : "–";
  $("#portTable").innerHTML = `<table class="t"><thead><tr><th>${esc(t("agency"))}</th>${head.map((h) => `<th>${esc(h)}</th>`).join("")}<th title="${esc(t(byM ? "port_growth_y_title" : "port_growth_all_title"))}">${esc(t("port_growth"))}</th></tr></thead><tbody>` +
    d.rows.map((r) => `<tr><td>${dot(r.agency)} ${esc(agName(r.agency))}</td>${row(r.cells)}<td>${gr(r.growth)}</td></tr>`).join("") + `</tbody></table>`;
}
$("#portByMonth").addEventListener("click", () => { PORT.mode = "month"; loadPortfolio(); });
$("#portByYear").addEventListener("click", () => { PORT.mode = "year"; loadPortfolio(); });
$("#portPrev").addEventListener("click", () => { const i = PORT.years.indexOf(PORT.year); if (i < PORT.years.length - 1) { PORT.year = PORT.years[i + 1]; loadPortfolio(); } });
$("#portNext").addEventListener("click", () => { const i = PORT.years.indexOf(PORT.year); if (i > 0) { PORT.year = PORT.years[i - 1]; loadPortfolio(); } });
/* "rīt 00:08" / "šodien 18:30" */
function fmtTime(iso) {
  const d = new Date(iso), now = new Date();
  const hm = d.toLocaleTimeString(loc(), { hour: "2-digit", minute: "2-digit" });
  if (d.toDateString() === now.toDateString()) return t("today_at") + " " + hm;
  const tm = new Date(now); tm.setDate(tm.getDate() + 1);
  if (d.toDateString() === tm.toDateString()) return t("tomorrow_at") + " " + hm;
  return d.toLocaleDateString(loc(), { weekday: "long", day: "numeric", month: "long" }) + " " + hm;
}
function renderAgencies() {
  const d = S.ov;
  if (!d) return;
  const sy = S.sync || {};
  const en = new Set(d.enabled || []);
  /* Aģentūru kartītēs Envato Market neatsevišķi — tas atjaunojas Envato logā; kartīte "Envato" = Elements + Market
     (citur sarakstos abi paliek atsevišķi) */
  $("#agCards").innerHTML = d.agencies.filter((a) => !a.via && !a.archive).map((a) => {
    const live = sy.running && sy.agencies && sy.agencies[a.id];
    const st = live ? live.state : null;
    let cls = "", txt;
    if (st === "running") { cls = "run"; txt = t("st_running") + (live.msg ? ` · ${live.msg}` : ""); }
    /* aģentūra šajā reizē jau beigusi — laiks uzreiz, negaidot pārējās */
    else if (st === "done") { cls = "ok"; txt = t("st_ok", { t: ago(new Date((live.t || Date.now() / 1000) * 1000).toISOString()) }); }
    else if (st === "error") { cls = "err"; txt = t("st_error"); }
    else if (st === "login") { cls = "run"; txt = t(live.visible ? "st_login" : "st_autologin"); }
    else if (st === "loading" || st === "waiting") { cls = "run"; txt = t("st_loading"); }
    else if (st === "queued") { cls = "run"; txt = t("st_queued"); }
    else if (a.last_err && (!a.last_ok || a.last_try > a.last_ok)) { cls = "err"; txt = t("st_error"); }
    else if (a.last_ok && a.fresh_until) { cls = "ok"; txt = t("st_fresh", { t: ago(a.last_ok), n: fmtTime(a.fresh_until) }); }
    else if (a.last_ok) { cls = "ok"; txt = t("st_ok", { t: ago(a.last_ok) }); }
    else txt = en.has(a.id) ? t("st_never") : t("st_off");
    const pct = live && st === "running" ? live.pct || 0 : 0;
    const busy = !!(live && ACTIVE.includes(st));   // aizņemta tikai šī aģentūra
    return `<div class="ag" style="--c:var(--ag-${a.id})">
      <h3>${dot(a.id)}${esc(a.id === "envato" ? "Envato" : a.name)}</h3>
      <div class="st ${cls}"><i></i><span>${esc(txt)}</span></div>
      ${live && st === "running" ? `<div class="prog"><i style="width:${pct}%"></i></div>` : ""}
      <div class="info">${a.id === "envato" ? esc(t("envato_both")) + "<br>" + (S.refresh && S.refresh.envato_time ? esc(t("envato_time", { t: S.refresh.envato_time })) + "<br>" : "") : ""}${esc(t("note_" + a.id))}${a.last_ok ? `<br>${esc(t(a.full ? "hist_full" : "hist_partial"))}` : ""}${a.last_day ? `<br>${esc(t("last_data", { d: fmtDate(a.last_day) }))}` : ""}</div>
      ${a.last_err && cls === "err" ? `<div class="info err">${esc(errText(a.last_err))}</div>` : ""}
      <div class="btns">
        ${a.via ? `<span class="muted small">${esc(t("via_note", { a: agName(a.via) }))}</span>` : a.last_ok || en.has(a.id)
          ? `<button class="primary" data-act="sync" data-ag="${a.id}" ${busy ? "disabled" : ""}>${esc(t("refresh"))}</button>
             ${!a.last_ok || cls === "err" ? `<button data-act="show" data-ag="${a.id}" ${busy ? "disabled" : ""} title="${esc(t("relogin_title"))}">${esc(t("relogin"))}</button>` : ""}
             <button data-act="full" data-ag="${a.id}" ${busy ? "disabled" : ""} title="${esc(t("full_title"))}">${esc(t("full"))}</button>
             ${en.has(a.id) ? `<button class="ghost" data-act="off" data-ag="${a.id}">${esc(t("disconnect"))}</button>` : ""}`
          : `<button class="primary" data-act="show" data-ag="${a.id}" ${busy ? "disabled" : ""}>${esc(t("connect"))}</button>`}
      </div></div>`;
  }).join("");
  $$("#agCards [data-act]").forEach((b) => b.addEventListener("click", () => agAction(b.dataset.act, b.dataset.ag)));
}
async function agAction(act, ag) {
  try {
    if (act === "off") {
      if (!(await uiConfirm(t("disconnect_q", { a: agName(ag) }), t("disconnect")))) return;
      await api("disconnect", { agency: ag });
      return loadAgencies();
    }
    if (act === "full" && !(await uiConfirm(t("full_q", { a: agName(ag) }), t("full")))) return;
    if (act === "show") toast(t("connect_hint", { a: agName(ag) }), "ok", 9000);
    const d = await api("sync", { agencies: [ag], show: act === "show" ? ag : null, full: act === "full" ? [ag] : [] });
    applySync(d.sync);
    renderAgencies();
  } catch (e) {
    if (e.data && e.data.need_webview) { showPage("agencies"); $("#wvBox").classList.remove("hidden"); }
    toast(e.message, "err");
  }
}

async function loadAgTable() {
  try {
    const d = await api("agencies", { period: PP.ag.value || "month" });
    /* portfelis (test42): perioda beigās vai jaunākais; izmaiņa pret iepriekšējo mēnesi; ienākumi uz bildi portfelī */
    const pd = (r) => r.port_delta ? `<span class="pdelta ${r.port_delta > 0 ? "up" : "down"}">${r.port_delta > 0 ? "+" : "−"}${int(Math.abs(r.port_delta))}</span>` : "";
    const ptitle = (r) => r.port_month ? ` title="${esc(t("port_cell_title", { m: fmtMonth(+r.port_month.slice(0, 4), +r.port_month.slice(5, 7)) }))}"` : "";
    $("#agTable").innerHTML = d.rows.length ? `<table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("earnings"))}</th><th>${esc(t("downloads"))}</th><th>${esc(t("files_sold"))}</th><th title="${esc(t("rpd_title"))}">RPD</th>${PORT_ON() ? `<th title="${esc(t("port_col_title"))}">${esc(t("port_col"))}</th>` : ""}<th>${esc(t("share"))}</th></tr></thead><tbody>` +
      d.rows.map((r) => `<tr><td>${dot(r.agency)} ${esc(agName(r.agency))}</td><td><b>${usd(r.e)}</b></td><td>${r.n != null && r.n ? int(r.n) : "–"}</td><td>${r.files ? int(r.files) : "–"}</td><td>${r.rpd ? usd(r.rpd) : "–"}</td>
        ${PORT_ON() ? `<td${ptitle(r)}>${r.port ? int(r.port) + pd(r) : "–"}</td>` : ""}
        <td>${r.share}%<span class="share"><i style="width:${r.share}%;background:var(--ag-${r.agency})"></i></span></td></tr>`).join("") +
      `<tr><td><b>${esc(t("total"))}</b></td><td><b>${usd(d.total)}</b></td><td>${int(d.rows.reduce((s, r) => s + (r.n || 0), 0))}</td><td></td><td></td>${PORT_ON() ? "<td></td><td></td>" : ""}<td></td></tr></tbody></table>` +
      (d.rows.some((r) => r.agency === "envato") ? `<p class="muted small">${esc(t("envato_rpd"))}</p>` : "")
      : `<div class="empty">${esc(t("no_data"))}</div>`;
  } catch (e) { toast(e.message, "err"); }
}
$("#wvInstall").addEventListener("click", async () => {
  try { await api("install_webview"); $("#wvInstall").disabled = true; pollInstall(); } catch (e) { toast(e.message, "err"); }
});
async function pollInstall() {
  const d = await api("state");
  $("#wvMsg").textContent = d.install_msg || "";
  if (d.installing) return setTimeout(pollInstall, 1500);
  $("#wvInstall").disabled = false;
  if (d.webview || /pywebview/.test(d.install_msg) && !/Kļūda|Error/.test(d.install_msg)) { toast(d.install_msg, "ok"); loadAgencies(); }
  else toast(d.install_msg, "err");
}

/* ============================================================ datu savākšana (stāvoklis) */
$("#syncBtn").addEventListener("click", async () => {
  if (S.sync && S.sync.running) {
    const login = Object.entries(S.sync.agencies || {}).find(([, v]) => v.state === "login" && v.visible);
    if (login) return toast(t("login_hint", { a: agName(login[0]) }), "ok", 8000);
    if (await uiConfirm(t("stop_q"), t("stop"))) { await api("stop"); pollSync(); }
    return;
  }
  const en = (S.ov && S.ov.enabled) || S.settings.sales_agencies || [];
  if (!en.length) { showPage("agencies"); return toast(t("connect_first")); }
  startSync(en);
});
async function startSync(agencies) {
  try {
    const d = await api("sync", { agencies });
    applySync(d.sync);
    if (d.skipped && d.skipped.length) toast(t("skipped_fresh", { a: d.skipped.map((a) => (a === "envato" ? "Envato" : agName(a))).join(", ") }), "", 5000);
  }
  catch (e) {
    if (e.data && e.data.need_webview) showPage("agencies");
    toast(e.message, "err");
  }
}
function applySync(sy) {
  S.sync = sy || {};
  const running = !!S.sync.running;
  const ag = S.sync.agencies || {};
  const vals = Object.values(ag);
  /* "ielogojies logā" — tikai, ja logs tiešām parādīts; citādi programma ielogojas pati vai gaida pāradresāciju */
  const login = Object.entries(ag).filter(([, v]) => v.state === "login" && v.visible).map(([k]) => k);
  const b = $("#syncBtn");
  b.classList.toggle("busy", running && !login.length);
  b.classList.toggle("login", running && !!login.length);
  b.classList.toggle("idle", !running);
  const pct = vals.length ? vals.reduce((s, v) => s + (ACTIVE.includes(v.state) ? v.pct || 0 : 100), 0) / vals.length : 0;
  $("#syncFill").style.width = pct + "%";
  if (running) {
    const cur = Object.entries(ag).filter(([, v]) => v.state === "running").map(([k]) => agName(k));
    const left = vals.filter((v) => ACTIVE.includes(v.state)).length;
    /* 0.3.1-test2 (lietotājs 2026-11-01: Dreamstime "iestrēga" uz "Sāku…", bet gaidīja cilvēka pārbaudi aiz Adobe loga) */
    const waitU = Object.entries(ag).filter(([, v]) => (v.wait_user || v.human) && ACTIVE.includes(v.state)).map(([k]) => k);
    const opening = Object.entries(ag).filter(([, v]) => v.state === "loading" || v.state === "waiting").map(([k]) => agName(k));
    $("#syncText").textContent = waitU.length && login.every((k) => waitU.includes(k)) ? t("sync_wait_user", { a: waitU.map(agName).join(", ") })
      : login.length ? t("sync_login_short", { a: agName(login[0]) }) + (waitU.length ? " · " + t("sync_wait_user", { a: waitU.map(agName).join(", ") }) : "")
      : waitU.length ? t("sync_wait_user", { a: waitU.map(agName).join(", ") })
      : cur.length ? cur.join(", ") + (left > cur.length ? ` · ${t("sync_left", { n: left - cur.length })}` : "")
      : opening.length ? t("sync_opening", { a: opening.slice(0, 2).join(", ") }) : t("sync_starting");
  } else $("#syncText").textContent = t("sync_btn");
  const ban = $("#syncBanner");
  const show = running && login.length;
  ban.classList.toggle("hidden", !show);
  document.body.classList.toggle("has-banner", !!show);
  if (show) ban.innerHTML = `<b>${esc(login.map(agName).join(", "))}:</b> <span>${esc(t("login_banner"))}</span>`;
  if (running) { S.wasRunning = true; if (!S.pollTimer) S.pollTimer = setTimeout(pollSync, 1500); }
  else if (S.wasRunning) {
    S.wasRunning = false;
    setTimeout(payReminder, 800);          // 0.3.1: svaigas summas atgādinājumā pēc atjaunošanas
    const res = Object.entries(ag);
    const paid = res.filter(([, v]) => v.state === "done" && v.msg === "payout_ok").map(([k]) => agName(k));
    const manual = res.filter(([, v]) => v.state === "error" && /^payout_/.test(v.msg || "")).map(([k]) => agName(k));
    if (paid.length) toast(t("pay_req_done", { a: paid.join(", ") }), "ok", 9000);
    if (manual.length) toast(t("pay_req_manual", { a: manual.join(", ") }), "err", 12000);
    const ok = res.filter(([, v]) => v.state === "done" && v.msg !== "payout_ok").map(([k]) => agName(k));
    const bad = res.filter(([, v]) => v.state === "error" && !/^payout_/.test(v.msg || "")).map(([k, v]) => `${agName(k)}: ${errText(v.msg)}`);
    const cancelled = res.filter(([, v]) => v.state === "cancelled" || v.state === "stopped").map(([k]) => agName(k));
    if (ok.length) toast(t("sync_done", { a: ok.join(", ") }), "ok", 5000);
    if (bad.length) toast(bad.join(" · "), "err");
    if (cancelled.length) toast(t("sync_cancelled", { a: cancelled.join(", ") }), "", 5000);
    refreshPage();
  }
  if (S.page === "agencies" && S.ov) renderAgencies();
  updateStatus(pct);
}
/* statusu josla apakšā: atjaunošana, pieslēgtās aģentūras, kļūdas */
function updateStatus(pct = 0) {
  const sy = S.sync || {}, d = S.ov;
  if (sy.running) {
    const cur = Object.entries(sy.agencies || {}).find(([, v]) => v.state === "running" || v.state === "login");
    Core.setStatus("sync", { text: t("sb_running", { a: cur ? agName(cur[0]) : "…", p: Math.round(pct) }), cls: "run" });
  } else Core.setStatus("sync", null);
  if (!d) return;
  const en = new Set(d.enabled || []);
  const ags = d.agencies.filter((a) => en.has(a.id));
  const errs = ags.filter((a) => a.last_err && (!a.last_ok || a.last_try > a.last_ok));
  const last = ags.map((a) => a.last_ok).filter(Boolean).sort().pop();
  Core.setStatus("agencies", { text: t("sb_agencies", { n: ags.length }) + (errs.length ? " · " + t("sb_errors", { n: errs.length }) : ""),
    cls: errs.length ? "err" : ags.length ? "ok" : "", title: errs.map((a) => a.name).join(", ") });
  Core.setStatus("updated", last ? { text: t("sb_updated", { t: ago(last) }) } : null);
}
async function pollSync() {
  S.pollTimer = null;
  try { const d = await api("status"); applySync(d.sync); } catch (_) { S.pollTimer = setTimeout(pollSync, 3000); }
}
function refreshPage() {
  api("years").then((d) => { S.years = d.years; }).catch(() => {});
  if (S.page === "overview") loadOverview();
  else if (S.page === "sales") loadFeed(true);
  else if (S.page === "best") loadBest(true);
  else if (S.page === "payouts") loadPayouts();
  else if (S.page === "agencies") loadAgencies();
}


/* ============================================================ kolekcijas (4. daļa) */
const selKey = (el) => el.dataset.ag + "|" + el.dataset.id;
function toggleSel(el, on) {
  const k = selKey(el);
  const add = on ?? !S.sel.has(k);
  if (add) S.sel.set(k, { agency: el.dataset.ag, agency_item_id: el.dataset.id }); else S.sel.delete(k);
  $$(".tile[data-ag]").forEach((x) => { if (selKey(x) === k) x.classList.toggle("sel", add); });
  renderSelBar();
}
/* "Atlasīt visas" (lietotājs 2026-10-30): visas atrastās bildes šajā sarakstā — vispirms ielādē arī "Rādīt vairāk" daļas */
async function selectAll(grid) {
  if (!grid) return;
  const more = { bestGrid: ["#bestMore", () => loadBest(false)], cvGrid: ["#cvMore", () => loadCollItems(false)],
    feedGrid: ["#feedMore", () => loadFeed(false)] }[grid.id];
  for (let i = 0; more && i < 60 && !$(more[0]).classList.contains("hidden"); i++) await more[1]();
  $$(".tile[data-ag]", grid).forEach((x) => toggleSel(x, true));
}
function clearSel() {
  S.sel.clear();
  $$(".tile.sel").forEach((x) => x.classList.remove("sel"));
  renderSelBar();
}
function renderSelBar() {
  const n = S.sel.size;
  $("#selBar").classList.toggle("hidden", !n);
  document.body.classList.toggle("has-sel", n > 0);      // atstarpe apakšā — "Rādīt vairāk" nepaliek zem joslas
  $$(".tiles").forEach((g) => g.classList.toggle("selecting", n > 0));
  $("#selN").textContent = t("sel_n", { n });
  $("#selRemove").classList.toggle("hidden", !openCollId());
}
$("#selClear").addEventListener("click", clearSel);
$("#selAdd").addEventListener("click", () => pickColl([...S.sel.values()]));
$("#selRemove").addEventListener("click", async () => {
  const cid = openCollId();
  if (!cid) return;
  await collRemove(cid, [...S.sel.values()]);
  clearSel();
});
document.addEventListener("keydown", (e) => { if (e.key === "Escape" && S.sel.size && $("#collModal").classList.contains("hidden")) clearSel(); });

/* labās pogas izvēlne */
function showCtx(e, el) {
  const m = $("#ctxMenu");
  const isTile = el.classList.contains("tile");
  const k = selKey(el);
  const many = isTile && S.sel.has(k) && S.sel.size > 1;
  const items = many ? [...S.sel.values()] : [{ agency: el.dataset.ag, agency_item_id: el.dataset.id }];
  const cid = openCollId();
  const cname = cid ? (S.colls.find((c) => c.id === cid) || {}).name : "";
  m.innerHTML = (many ? "" : `<button data-a="open">${esc(t("ctx_open"))}</button>`) +
    (isTile ? `<button data-a="sel">${esc(t(S.sel.has(k) ? "ctx_unselect" : "ctx_select"))}</button><button data-a="selall">${esc(t("sel_all"))}</button>` : "") + `<hr>` +
    (many ? `<button data-a="merge">${esc(t("lk_merge", { n: items.length }))}</button>` : "") +
    (!many && +el.dataset.parts > 1 ? `<button data-a="split">${esc(t("lk_split", { n: el.dataset.parts }))}</button>` : "") +
    (many || +el.dataset.parts > 1 ? `<hr>` : "") +
    `<button data-a="add">${esc(many ? t("coll_add_t", { n: items.length }) : t("coll_add"))}…</button>` +
    `<div class="ctx-colls">` + S.colls.map((c) => `<button data-a="to" data-c="${c.id}">→ ${esc(c.name)}</button>`).join("") + `</div>` +
    (cid ? `<hr><button data-a="rm">${esc(t("coll_remove", { n: cname }))}${many ? ` (${items.length})` : ""}</button>` : "") +
    (ED_ON() ? `<hr><button data-a="ed1">${esc(t("ed_mark_ed"))}</button><button data-a="ed0">${esc(t("ed_mark_rf"))}</button><button data-a="edx">${esc(t("ed_mark_auto"))}</button>` : "");
  collMarks(m, items);
  m.classList.remove("hidden");
  const w = m.offsetWidth, h = m.offsetHeight;
  m.style.left = Math.min(e.clientX, innerWidth - w - 8) + "px";
  m.style.top = Math.min(e.clientY, innerHeight - h - 8) + "px";
  m.onclick = async (ev) => {
    const b = ev.target.closest("button");
    if (!b) return;
    hideCtx();
    const a = b.dataset.a;
    if (a === "open") openItem(el.dataset.ag, el.dataset.id);
    else if (a === "sel") toggleSel(el);
    else if (a === "selall") selectAll(el.closest(".tiles"));
    else if (a === "add") pickColl(items);
    else if (a === "ed1" || a === "ed0" || a === "edx") edMark(items, a === "edx" ? null : +a.slice(2), many);
    else if (a === "to") { await collAdd(+b.dataset.c, items); if (many) clearSel(); }
    else if (a === "rm") { await collRemove(cid, items); if (many || S.sel.has(k)) clearSel(); }
    else if (a === "merge" || a === "split") {
      if (a === "split" && !(await uiConfirm(t("lk_split_q"), t("lk_split", { n: el.dataset.parts })))) return;
      try {
        await api("link", { op: a, items });
        toast(t(a === "merge" ? "lk_merged" : "lk_splitted"), "ok");
        clearSel();
        reloadView();
      } catch (e2) { toast(e2.message, "err"); }
    }
  };
}
function reloadView() {
  if (S.page === "colls" && S.collOpen) openColl(S.collOpen, true);
  else if (S.page === "best") loadBest(true);
  else if (S.page === "sales") loadFeed(true);
  else if (S.page === "overview") loadOverview();
}
function hideCtx() { $("#ctxMenu").classList.add("hidden"); }
document.addEventListener("click", (e) => { if (!e.target.closest("#ctxMenu")) hideCtx(); });
document.addEventListener("scroll", (e) => { if (!(e.target && e.target.closest && e.target.closest("#ctxMenu"))) hideCtx(); }, true);
window.addEventListener("blur", hideCtx);

/* kolekcijas izvēle (pievienot) */
let pickItems = [];
/* kolekcijas, kurās bilde(s) jau ir — zaļā krāsā; daļēji — gaišāk (lietotājs 2026-10-31) */
async function collMarks(root, items) {
  if (!items.length) return;
  try {
    const { counts } = await api("coll_count", { items });
    $$("[data-c]", root).forEach((b) => {
      const n = counts[b.dataset.c] || 0;
      b.classList.toggle("in", n >= items.length);
      b.classList.toggle("part", n > 0 && n < items.length);
      if (n) b.title = t(n >= items.length ? "coll_has" : "coll_has_part", { n, k: items.length });
    });
  } catch (_) { /* */ }
}
async function edMark(items, ed, many) {
  try {
    await api("ed_mark", { items, ed });
    toast(t(ed == null ? "ed_marked_auto" : ed ? "ed_marked_ed" : "ed_marked_rf", { n: items.length }), "ok");
    if (many) clearSel();
    reloadView();
  } catch (e) { toast(e.message, "err"); }
}
function pickColl(items) {
  pickItems = items;
  $("#collTitle").textContent = items.length > 1 ? t("coll_add_t", { n: items.length }) : t("coll_add");
  $("#collList").innerHTML = S.colls.map((c) => `<button data-c="${c.id}"><span>${esc(c.name)}</span><span class="muted">${int(c.files)} ${esc(t("coll_files"))}</span></button>`).join("") ||
    `<span class="muted small">${esc(t("coll_none"))}</span>`;
  $("#collName").value = "";
  $("#collCreate").textContent = items.length ? t("coll_create_add") : t("coll_create");
  $("#collModal").classList.remove("hidden");
  collMarks($("#collList"), items);
  $$("#collList [data-c]").forEach((b) => b.addEventListener("click", async () => {
    $("#collModal").classList.add("hidden");
    await collAdd(+b.dataset.c, pickItems);
    if (pickItems.length > 1) clearSel();
  }));
  setTimeout(() => (S.colls.length ? null : $("#collName").focus()), 30);
}
$("#collClose").addEventListener("click", () => $("#collModal").classList.add("hidden"));
$("#collModal").addEventListener("click", (e) => { if (e.target.id === "collModal") $("#collModal").classList.add("hidden"); });
async function createFromPicker() {
  const name = $("#collName").value.trim();
  if (!name) return $("#collName").focus();
  try {
    const d = await api("coll_edit", { op: "create", name, items: pickItems });
    $("#collModal").classList.add("hidden");
    await refreshColls();
    if (pickItems.length) { tipColls(pickItems, name, true); toast(t("coll_added", { n: name, k: d.added }), "ok"); if (pickItems.length > 1) clearSel(); }
    if (S.page === "colls") loadColls();
  } catch (e) { toast(e.message, "err"); }
}
$("#collCreate").addEventListener("click", createFromPicker);
$("#collName").addEventListener("keydown", (e) => { if (e.key === "Enter") createFromPicker(); });
$("#collNew").addEventListener("click", () => pickColl([]));

/* uznirstošā teksta kolekcijas uzreiz pēc pievienošanas/izņemšanas (lietotājs 2026-10-31) */
function tipColls(items, name, add) {
  if (!name) return;
  (items || []).forEach((it) => $$(`[data-ag="${CSS.escape(String(it.agency))}"][data-id="${CSS.escape(String(it.agency_item_id))}"]`).forEach((el) => {
    const l = (el.dataset.tc || "").split(", ").filter(Boolean).filter((x) => x !== name);
    if (add) l.push(name);
    el.dataset.tc = l.sort((a, b) => a.localeCompare(b)).join(", ");
  }));
}
async function collAdd(cid, items) {
  try {
    const d = await api("coll_edit", { op: "add", id: cid, items });
    const c = S.colls.find((x) => x.id === cid) || {};
    toast(t("coll_added", { n: c.name || "", k: d.added }), "ok");
    tipColls(items, c.name, true);
    await refreshColls();
    if (openCollId() === cid) openColl(cid, true);
  } catch (e) { toast(e.message, "err"); }
}
async function collRemove(cid, items) {
  try {
    await api("coll_edit", { op: "remove", id: cid, items });
    const c = S.colls.find((x) => x.id === cid) || {};
    toast(t("coll_removed", { n: c.name || "" }), "ok");
    tipColls(items, c.name, false);
    await refreshColls();
    if (openCollId() === cid) openColl(cid, true);
  } catch (e) { toast(e.message, "err"); }
}
async function refreshColls() {
  try {
    const d = await api("colls");
    S.colls = d.colls || [];
    S.mrImported = d.imported;
  } catch (_) { S.colls = S.colls || []; }
}
/* atvērtā kolekcija (cilnē Kolekcijas) — 0, ja rāda kolekciju sarakstu */
const openCollId = () => (S.page === "colls" ? S.collOpen || 0 : 0);
S.cv = { offset: 0 };
async function openColl(cid, keep) {
  if (S.page !== "colls") { S.collOpen = cid; return showPage("colls"); }
  if (S.collOpen !== cid) { S.collOpen = cid; PP.cv.set("all"); }
  $("#collListWrap").classList.add("hidden");
  $("#collView").classList.remove("hidden");
  try {
    const { coll: c } = await api("coll_view", { id: cid, period: PP.cv.value });
    if (!c || !c.id) { closeColl(); return; }
    $("#cvName").textContent = c.name;
    $("#cvCards").innerHTML = [
      [usd(c.pe), t("earnings"), t("cv_of", { s: int(c.sold), f: int(c.files) })],
      [c.pn ? int(c.pn) : "0", t("downloads"), c.first ? t("cv_since", { d: fmtDate(c.first) }) : ""],
      [usd(c.rpi), "RPI", t("cv_rpi")],
      [usd(c.rpd), "RPD", t("cv_rpd")],
    ].map(([v, l, sub]) => `<div class="card"><div class="k">${esc(l)}</div><div class="v">${esc(v)}</div>${sub ? `<div class="sub">${esc(sub)}</div>` : ""}</div>`).join("");
    $("#cvAg").innerHTML = `<table class="cv-ag"><tbody>${c.by_agency.map((a) => `<tr class="${a.e > 0 || a.n > 0 ? "" : "zero"}">
        <td>${dot(a.agency)}${esc(agName(a.agency))} <span class="muted">(${int(a.items)})</span></td>
        <td class="r">${hasCounts(a.agency) ? dlS(int(a.n)) : ""}</td><td class="r">${usd(a.e)}</td></tr>`).join("")}
      <tr class="tot"><td>${esc(t("cv_total"))} <span class="muted">(${int(c.sold)})</span></td><td class="r">${dlS(int(c.pn))}</td><td class="r">${usd(c.pe)}</td></tr></tbody></table>`;
  } catch (e) { toast(e.message, "err"); }
  await loadCollItems(true);
  if (!keep) window.scrollTo(0, 0);
  renderSelBar();
}
async function loadCollItems(reset) {
  const cid = S.collOpen;
  if (!cid) return;
  if (reset) S.cv.offset = 0;
  try {
    const d = await api("coll_items", { id: cid, period: PP.cv.value, sort: $("#cvSort").value, offset: S.cv.offset, limit: 60 });
    S.cv.offset += d.rows.length;
    const html = d.rows.map((r) => {
      const m0 = r.members[0] || {};
      const img = thumb(r.thumb);
      return `<div class="tile${r.e || r.n ? "" : " dim"}" data-ag="${esc(m0.agency)}" data-id="${esc(m0.agency_item_id)}" data-parts="${r.members.length}" title="${esc(r.title || "")}">
        <div class="img ${img ? "" : "noimg"}" ${thAttr(r, 240, label(r, m0.agency, m0.agency_item_id))}><span class="selbox"></span>${img ? "" : `<span class="nt">${esc(label(r, m0.agency, m0.agency_item_id))}</span>`}</div>
        <div class="body"><div class="am">${usd(r.e)}${r.counts && r.n ? `<small>${dlS(int(r.n))}</small>` : ""}</div>
        <div class="mem">${r.members.map((m) => `<span title="${esc(agName(m.agency))}">${dot(m.agency)}${m.e || m.n ? usd(m.e) : esc(agName(m.agency))}</span>`).join("")}</div>
        ${img ? `<div class="ttl">${esc(r.title || r.filename || "")}</div>` : ""}</div></div>`;
    }).join("");
    const g = $("#cvGrid");
    if (reset) g.innerHTML = html || `<div class="empty">${esc(t("no_sales"))}</div>`;
    else g.insertAdjacentHTML("beforeend", html);
    bindRows(g);
    $("#cvMore").classList.toggle("hidden", S.cv.offset >= d.count);
  } catch (e) { toast(e.message, "err"); }
}
$("#cvSort").addEventListener("change", () => loadCollItems(true));
$("#cvMore").addEventListener("click", () => loadCollItems(false));
function closeColl() {
  S.collOpen = 0;
  clearSel();
  $("#collView").classList.add("hidden");
  $("#collListWrap").classList.remove("hidden");
  loadColls();
}
$("#cvClose").addEventListener("click", closeColl);
async function loadColls() {
  if (S.collOpen) return openColl(S.collOpen, true);
  $("#collView").classList.add("hidden");
  $("#collListWrap").classList.remove("hidden");
  await refreshColls();
  const g = $("#collGrid");
  const tot = S.colls.reduce((s, c) => s + c.e, 0);
  $("#collSum").innerHTML = S.colls.length ? `<span>${esc(t("tab_colls"))}: <b>${S.colls.length}</b></span><span>${esc(t("earnings"))}: <b>${usd(tot)}</b></span>` : "";
  g.innerHTML = S.colls.map((c) => {
    const th = c.thumbs || [];
    return `<div class="coll" data-c="${c.id}">
      <div class="mos ${th.length === 1 ? "one" : ""}">${(th.length ? th : [null]).slice(0, 4).map((u) => `<i ${u ? bg(thumb(u)) : ""}></i>`).join("")}</div>
      <div class="body"><h4>${esc(c.name)}${c.source === "microstockr" ? `<span class="src">${esc(t("coll_mr"))}</span>` : ""}</h4>
        <div class="st"><span><b>${usd(c.e)}</b></span><span>${int(c.files)} ${esc(t("coll_files"))}</span>${c.n ? dlS(int(c.n)) : ""}</div>
        <div class="acts"><button data-a="open" class="primary">${esc(t("coll_open"))}</button><button data-a="ren">${esc(t("coll_rename"))}</button><button data-a="del" class="ghost">${esc(t("coll_delete"))}</button></div></div></div>`;
  }).join("") || `<div class="empty">${esc(t("coll_none"))}</div>`;
  $$("#collGrid .coll").forEach((el) => el.addEventListener("click", async (e) => {
    const cid = +el.dataset.c, c = S.colls.find((x) => x.id === cid);
    const a = (e.target.closest("button") || {}).dataset?.a || "open";
    if (a === "open") return openColl(cid);
    if (a === "del") {
      if (!(await uiConfirm(t("coll_delete_q", { n: c.name }), t("coll_delete")))) return;
      await api("coll_edit", { op: "delete", id: cid });
      return loadColls();
    }
    if (a === "ren") {
      const h = el.querySelector("h4");
      h.innerHTML = `<input value="${esc(c.name)}" style="width:100%">`;
      const inp = h.querySelector("input");
      inp.focus(); inp.select();
      inp.addEventListener("click", (ev) => ev.stopPropagation());
      const done = async (save) => {
        if (save && inp.value.trim() && inp.value.trim() !== c.name) await api("coll_edit", { op: "rename", id: cid, name: inp.value.trim() });
        loadColls();
      };
      inp.addEventListener("keydown", (ev) => { if (ev.key === "Enter") done(true); if (ev.key === "Escape") { ev.stopPropagation(); done(false); } });
      inp.addEventListener("blur", () => done(true));
    }
  }));
}

/* Microstockr imports (iestatījumos) */
let mrData = null;
function mrLastText() {
  const x = S.mrImported;
  return x ? t("s_mr_last", { d: fmtDate((x.at || "").slice(0, 10)), s: int(x.sales) }) : "";
}
function bindMr() {
  $("#mrLast").textContent = mrLastText();
  $("#mrPick").addEventListener("click", () => $("#mrFile").click());
  $("#mrFile").addEventListener("change", async () => {
    const f = $("#mrFile").files[0];
    if (!f) return;
    $("#mrSt").textContent = t("s_mr_reading");
    $("#mrGo").classList.add("hidden");
    $("#mrPlan").innerHTML = "";
    try {
      mrData = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(f); });
      const d = await api("mr_import", { data: mrData });
      const p = d.plan;
      $("#mrSt").textContent = f.name;
      $("#mrPlan").innerHTML = `<div>${esc(t("s_mr_plan", { c: p.collections.length, m: int(p.media) }))}: ${p.collections.map((c) => esc(c.name)).join(", ")}</div>
        <table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("s_mr_take"))}</th><th>${esc(t("earnings"))}</th><th>${esc(t("s_mr_period"))}</th><th>${esc(t("s_mr_ours"))}</th></tr></thead><tbody>
        ${p.agencies.filter((a) => a.take).map((a) => `<tr><td>${dot(a.agency)} ${esc(agName(a.agency))}</td><td>${int(a.take)}</td><td>${usd(a.e)}</td>
          <td>${esc(fmtDate(a.from))} – ${esc(fmtDate(a.to))}</td><td class="muted">${a.ours_from ? esc(fmtDate(a.ours_from)) : "–"}</td></tr>`).join("")}</tbody></table>`;
      $("#mrGo").classList.remove("hidden");
    } catch (e) { $("#mrSt").textContent = ""; toast(e.message, "err"); mrData = null; }
    $("#mrFile").value = "";
  });
  $("#mrGo").addEventListener("click", async () => {
    if (!mrData) return;
    $("#mrGo").disabled = true;
    $("#mrSt").textContent = t("s_mr_importing");
    try {
      const d = await api("mr_import", { data: mrData, confirm: true });
      const r = d.result;
      toast(t("s_mr_done", { s: int(r.sales), m: int(r.media), c: r.collections }), "ok", 7000);
      $("#mrSt").textContent = t("s_mr_done", { s: int(r.sales), m: int(r.media), c: r.collections });
      $("#mrGo").classList.add("hidden");
      $("#mrPlan").innerHTML = "";
      mrData = null;
      await refreshColls();
      $("#mrLast").textContent = mrLastText();
    } catch (e) { $("#mrSt").textContent = ""; toast(e.message, "err"); }
    $("#mrGo").disabled = false;
  });
}

/* ============================================================ iestatījumi (rāmis — core.js) */
/* aģentūras, kurām var saglabāt paroli automātiskai ielogošanai (Envato — tikai Google/… sesija, nav vajadzīgs) */
const AG_CREDS = [["adobe", "Adobe Stock"], ["shutterstock", "Shutterstock"], ["istock", "iStock / Getty"], ["alamy", "Alamy"],
  ["123rf", "123RF"], ["dreamstime", "Dreamstime"], ["depositphotos", "Depositphotos"], ["magnific", "Magnific"],
  ["pixta", "Pixta"], ["pond5", "Pond5"], ["bigstock", "Bigstock"], ["envato", "Envato"], ["zoonar", "Zoonar"], ["ingram", "Ingram"]];
const settingsPage = Core.settingsFrame({
  root: "#page-settings",
  shared: [],          // noteikumi §5: kopīgos laukus (autors, mērķa aģentūras, pieredze) Analītiķis nelieto
  connections: { jobs: [["assistant", t("job_assistant")]] },   // §5 p.2 Pieslēgumi; AI asistents — vēlāk
  moduleHtml: `<section data-collapse="app"><h2 data-i18n="s_app"></h2>
    <div class="grid2"><label><span data-i18n="s_pay_cur"></span>
      <select id="sPayCur"><option value="EUR">€ EUR</option><option value="USD">$ USD</option><option value="GBP">£ GBP</option>
        <option value="UAH">₴ UAH</option><option value="agency" data-i18n="s_pay_cur_ag"></option></select></label></div>
    <p class="muted small" data-i18n="s_pay_cur_d"></p>
    <h3><span data-i18n="s_beta"></span> <span class="beta-tag" data-i18n="s_beta_tag"></span></h3><p class="muted small" data-i18n="s_beta_d"></p>
    <label class="chk"><input type="checkbox" id="sBetaOff"> <b data-i18n="s_beta_off"></b></label>
    <p class="muted small" data-i18n="s_beta_off_d"></p>
    <div id="sBetaList">
      <label class="chk"><input type="checkbox" id="sBetaPort"> <span data-i18n="s_beta_port"></span></label>
      <p class="muted small" data-i18n="s_beta_port_d"></p>
      <label class="chk"><input type="checkbox" id="sBetaEd"> <span data-i18n="s_beta_ed"></span></label>
      <p class="muted small" data-i18n="s_beta_ed_d"></p>
      <div id="sNoEd" class="muted small"></div></div></section>
    <section data-collapse="sales"><h2 data-i18n="s_sales"></h2>
    <div class="grid2"><label><span data-i18n="s_autosync"></span>
      <select id="sAuto"><option value="0" data-i18n="s_auto_0"></option>
        <option value="3">3 h</option><option value="6">6 h</option><option value="12">12 h</option><option value="24">24 h</option></select></label>
      <label><span data-i18n="s_parallel"></span>
      <select id="sParallel"><option value="1">1</option><option value="2">2</option><option value="3">3</option><option value="4">4</option></select></label></div>
    <p class="muted small" data-i18n="s_sales_d"></p>
    <label class="chk"><input type="checkbox" id="sKeep"> <span data-i18n="s_keepalive"></span></label>
    <p class="muted small" data-i18n="s_keepalive_d"></p>
    <h3 data-i18n="s_refresh"></h3><p class="muted small" data-i18n="s_refresh_d"></p>
    <div id="sRefresh" class="pay-rules"></div><p id="sEnvTime" class="muted small"></p>
</section>
    <section data-collapse="pay"><h2 data-i18n="s_pay"></h2>
      <p class="muted small" data-i18n="s_pay_d"></p>
      <div id="sPayRules" class="pay-rules"></div>
</section>
    <section data-collapse="mail"><h2 data-i18n="s_remind"></h2>
      <h3 data-i18n="s_rem_app"></h3>
      <label class="chk"><input type="checkbox" id="sPayRemind"> <span data-i18n="s_pay_remind2"></span></label>
      <div class="grid2" id="sRemWrap"><label><span data-i18n="s_mail_when"></span><select id="sRemWhen">
          <option value="lastday" data-i18n="s_mail_lastday"></option><option value="day" data-i18n="s_mail_day"></option>
          <option value="threshold" data-i18n="s_mail_threshold"></option></select></label>
        <label id="sRemDayL"><span data-i18n="s_mail_dayn"></span><input id="sRemDay" type="number" min="1" max="31"></label></div>
      <h3 data-i18n="s_rem_mail"></h3><p class="muted small" data-i18n="s_mail_d"></p>
      <label class="chk"><input type="checkbox" id="sMailOn"> <span data-i18n="s_mail_on"></span></label>
      <div class="grid2">
        <label><span data-i18n="s_mail_to"></span><input id="sMailTo" type="email" placeholder="vards@gmail.com"></label>
        <label><span data-i18n="s_mail_when"></span><select id="sMailWhen">
          <option value="lastday" data-i18n="s_mail_lastday"></option><option value="day" data-i18n="s_mail_day"></option>
          <option value="threshold" data-i18n="s_mail_threshold"></option></select></label>
        <label id="sMailDayL"><span data-i18n="s_mail_dayn"></span><input id="sMailDay" type="number" min="1" max="31"></label>
        <label><span data-i18n="s_mail_hour"></span><input id="sMailHour" type="number" min="0" max="23"></label>
        <label><span data-i18n="s_smtp_host"></span><input id="sSmtpHost" placeholder="smtp.gmail.com"></label>
        <label><span data-i18n="s_smtp_port"></span><input id="sSmtpPort" type="number" min="1" max="65535"></label>
        <label><span data-i18n="s_smtp_user"></span><input id="sSmtpUser" type="email" autocomplete="off"></label>
        <label><span data-i18n="s_smtp_pw"></span><input id="sSmtpPw" type="password" autocomplete="new-password"></label>
      </div>
      <div class="row-btns"><button id="sSmtpSave" data-i18n="s_smtp_save"></button><button id="sSmtpForget" class="ghost" data-i18n="s_smtp_forget"></button>
        <button id="sMailTest" data-i18n="s_mail_test"></button><span id="sSmtpSt" class="muted small"></span></div>
      <p class="muted small" data-i18n="s_smtp_d"></p></section>
    <section data-collapse="data"><h2 data-i18n="s_data"></h2>
      <h3 data-i18n="s_bk"></h3><p class="muted small" data-i18n="s_bk_d"></p>
      <div class="grid2">
        <label class="span2"><span data-i18n="s_bk_dir"></span><input id="sBkDir" spellcheck="false" autocomplete="off"></label>
        <div class="span2 row-btns" style="margin-top:-4px"><button id="bkDirPick" class="small-btn" data-i18n="bk_dir_pick"></button><button id="bkDirOd" class="small-btn hidden" data-i18n="bk_dir_od"></button><button id="bkDirDef" class="small-btn ghost" data-i18n="bk_dir_def"></button></div>
        <label><span data-i18n="s_bk_every"></span><select id="sBkEvery"><option value="never" data-i18n="bk_never"></option>
          <option value="day" data-i18n="bk_day"></option><option value="week" data-i18n="bk_week"></option><option value="month" data-i18n="bk_month"></option></select></label>
        <label><span data-i18n="s_bk_keep"></span><input id="sBkKeep" type="number" min="1" max="100"></label>
      </div>
      <div class="row-btns"><button id="bkNow" class="primary" data-i18n="bk_now"></button><button id="bkOpen" data-i18n="bk_open"></button>
        <button id="bkPick" data-i18n="bk_pick"></button><input id="bkFile" type="file" accept=".zip" class="hidden"><span id="bkSt" class="muted small"></span></div>
      <p id="bkInfo" class="muted small"></p>
      <div id="bkList" class="bk-list small"></div>
      <h3 data-i18n="s_mr"></h3><p class="muted small" data-i18n="s_mr_d"></p>
      <div class="row-btns"><button id="mrPick" data-i18n="s_mr_pick"></button><input id="mrFile" type="file" accept=".bak,.zip,.db" class="hidden">
        <button id="mrGo" class="primary hidden" data-i18n="s_mr_go"></button><span id="mrSt" class="muted small"></span></div>
      <div id="mrPlan" class="mr-plan small"></div><p id="mrLast" class="muted small"></p></section>`,
  creds: AG_CREDS,
  otherHtml: `<button id="clearSessions" data-i18n="clear_sessions" data-i18n-title="clear_sessions_title"></button>`,
  load: (s) => {
    $("#sKeep").checked = s.sales_keepalive !== false;
    $("#sBetaOff").checked = !!s.sales_beta_off; $("#sBetaPort").checked = s.sales_beta_portfolio !== false; $("#sBetaEd").checked = !!s.sales_beta_ed;
    const noEd = s.sales_no_ed || [];
    $("#sNoEd").innerHTML = `<span>${esc(t("s_no_ed"))}</span> ` + AG.filter((a) => !["eyeem", "mostphotos", "yayimages"].includes(a)).map((a) =>
      `<label class="chk inline"><input type="checkbox" data-noed="${a}"${noEd.includes(a) ? " checked" : ""}> ${esc(agName(a))}</label>`).join(" ");
    const betaSync = () => { const off = $("#sBetaOff").checked; $("#sBetaList").classList.toggle("dim", off); $$("#sBetaList input").forEach((i) => (i.disabled = off)); };
    $("#sBetaOff").onchange = betaSync; betaSync();
    $("#sAuto").value = String(s.sales_autosync_hours ?? 6); $("#sParallel").value = String(s.sales_parallel ?? 2);
    $("#sPayRemind").checked = s.sales_payout_remind !== false;
    $("#sRemWhen").value = s.sales_remind_when || "lastday"; $("#sRemDay").value = s.sales_remind_day ?? 28;
    const remSync = () => { $("#sRemDayL").classList.toggle("hidden", $("#sRemWhen").value !== "day"); $("#sRemWrap").classList.toggle("dim", !$("#sPayRemind").checked); };
    $("#sRemWhen").onchange = remSync; $("#sPayRemind").onchange = remSync; remSync();
    $("#sMailOn").checked = !!s.sales_mail_on; $("#sMailTo").value = s.sales_mail_to || "";
    $("#sMailWhen").value = s.sales_mail_when || "lastday"; $("#sMailDay").value = s.sales_mail_day ?? 28;
    $("#sMailHour").value = s.sales_mail_hour ?? 9; $("#sSmtpHost").value = s.sales_smtp_host || "smtp.gmail.com";
    $("#sSmtpPort").value = s.sales_smtp_port ?? 587;
    $("#sMailDayL").classList.toggle("hidden", $("#sMailWhen").value !== "day");
    loadSmtp();
    loadPayRules(s.sales_payout || {});
    $("#sPayCur").value = s.sales_pay_currency || "EUR";
    loadRefresh(s.sales_refresh || {});
    $("#sBkEvery").value = s.backup_every || "week"; $("#sBkKeep").value = s.backup_keep ?? 10; $("#sBkDir").value = s.backup_dir || "";
    loadBackups();
  },
  collect: () => ({ sales_beta_off: $("#sBetaOff").checked, sales_beta_portfolio: $("#sBetaPort").checked, sales_beta_ed: $("#sBetaEd").checked,
    sales_no_ed: $$("#sNoEd [data-noed]").filter((i) => i.checked).map((i) => i.dataset.noed),
    ...($("#sBetaOff").checked ? { update_channel: "stable" } : {}),
    sales_keepalive: $("#sKeep").checked, sales_autosync_hours: +$("#sAuto").value, sales_parallel: +$("#sParallel").value,
    sales_payout_remind: $("#sPayRemind").checked, sales_remind_when: $("#sRemWhen").value, sales_remind_day: +$("#sRemDay").value || 28, sales_payout: collectPayRules(), sales_pay_currency: $("#sPayCur").value, sales_refresh: collectRefresh(),
    sales_portfolio_names: Object.assign({}, S.settings.sales_portfolio_names || {}, $("#sPortIstock") ? { istock: $("#sPortIstock").value.trim() } : {}),
    backup_every: $("#sBkEvery").value, backup_keep: +$("#sBkKeep").value || 10, backup_dir: $("#sBkDir").value.trim(),
    sales_mail_on: $("#sMailOn").checked, sales_mail_to: $("#sMailTo").value.trim(), sales_mail_when: $("#sMailWhen").value,
    sales_mail_day: +$("#sMailDay").value || 28, sales_mail_hour: +$("#sMailHour").value || 0,
    sales_smtp_host: $("#sSmtpHost").value.trim() || "smtp.gmail.com", sales_smtp_port: +$("#sSmtpPort").value || 587 }),
  onSaved: (s) => { S.settings = s; loadRefreshInfo(); loadBackups(); },
});
function loadSettings() { settingsPage.load(); $("#mrLast").textContent = mrLastText(); }
bindMr();
bindBackups();
/* ---------- atjaunošanas biežums katrai aģentūrai (test42) ---------- */
async function loadRefreshInfo() { try { S.refresh = await api("refresh_info"); } catch (_) { /* */ } return S.refresh; }
async function loadRefresh(user) {
  const inf = (await loadRefreshInfo()) || { modes: {}, defaults: {} };
  const ags = Object.keys(inf.modes || {});
  const mtxt = (m) => (/^month:/.test(m || "") ? t("rf_month_n", { d: m.split(":")[1] }) : t("rf_" + (m || "always")));
  $("#sRefresh").innerHTML = `<table class="t"><thead><tr><th>${esc(t("agency"))}</th><th>${esc(t("s_refresh_col"))}</th></tr></thead><tbody>` +
    ags.map((a) => `<tr data-ag="${a}"><td>${dot(a)} ${esc(a === "envato" ? "Envato" : agName(a))}</td>
      <td><select class="rf-mode"><option value="">${esc(t("pay_default", { v: mtxt(inf.defaults[a]) }))}</option>
        <option value="always">${esc(t("rf_always"))}</option><option value="day">${esc(t("rf_day"))}</option><option value="week">${esc(t("rf_week"))}</option><option value="month">${esc(t("rf_month"))}</option></select>
        <span class="rf-dayw hidden"> ${esc(t("rf_from_day"))} <input class="rf-day" type="number" min="1" max="28" value="25">${esc(t("rf_day_suffix"))}</span>
        ${a === "istock" ? `<div class="muted" style="margin-top:4px">${esc(t("port_name"))} <input id="sPortIstock" type="text" style="width:12em" placeholder="istockphoto.com/portfolio/…" value="${esc(((S.settings && S.settings.sales_portfolio_names) || {}).istock || "")}"></div>` : ""}</td></tr>`).join("") +
    `</tbody></table>`;
  $$("#sRefresh tr[data-ag]").forEach((tr) => {
    /* noklusējums "reizi mēnesī no N." — dienu rāda uzreiz, lai to var mainīt (lietotājs 2026-10-30) */
    const u = user[tr.dataset.ag] || (/^month:/.test(inf.defaults[tr.dataset.ag] || "") ? inf.defaults[tr.dataset.ag] : ""), md = /^month:(\d+)$/.exec(u);
    $(".rf-mode", tr).value = md ? "month" : u;
    if (md) $(".rf-day", tr).value = md[1];
    const sync = () => $(".rf-dayw", tr).classList.toggle("hidden", $(".rf-mode", tr).value !== "month");
    $(".rf-mode", tr).addEventListener("change", sync); sync();
  });
  $("#sEnvTime").textContent = inf.envato_time ? t("envato_time_s", { t: inf.envato_time, n: inf.envato_obs })
    : t("envato_learning", { n: inf.envato_obs || 0 });
  const ir = inf.istock_report;
  if (ir) $("#sEnvTime").textContent += " " + t("istock_report", { d: fmtDate(ir.day), m: fmtMonth(+ir.month.slice(0, 4), +ir.month.slice(5, 7)) });
}
function collectRefresh() {
  if (!$$("#sRefresh tr[data-ag]").length) return S.settings.sales_refresh || {};
  const out = {};
  $$("#sRefresh tr[data-ag]").forEach((tr) => {
    const v = $(".rf-mode", tr).value;
    if (v === "month") out[tr.dataset.ag] = "month:" + Math.max(1, Math.min(28, +$(".rf-day", tr).value || 25));
    else if (v) out[tr.dataset.ag] = v;
  });
  return out;
}
/* ---------- rezerves kopijas (core/backup.py; test43) ---------- */
const fmtSize = (n) => n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
const fmtDT = (iso) => iso ? new Date(iso).toLocaleString(loc(), { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "–";
async function loadBackups() {
  let d;
  try { d = await api("backup_list"); } catch (_) { return; }
  $("#sBkDir").placeholder = d.default_dir;
  $("#bkInfo").textContent = t("bk_info", { dir: d.dir, last: d.last ? fmtDT(d.last) : t("never"), next: d.next ? fmtDT(d.next) : "–" });
  $("#bkList").innerHTML = d.items.length ? `<table class="t"><thead><tr><th>${esc(t("bk_copy"))}</th><th>${esc(t("bk_size"))}</th><th></th></tr></thead><tbody>` +
    d.items.map((x) => `<tr><td>${esc(fmtDT(x.mtime))}${/pirms-atjaunin/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_update"))}</span>` : /pirms-atjauno/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_restore"))}</span>` : /-auto/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_auto"))}</span>` : ""}</td>
      <td>${fmtSize(x.size)}</td><td><button class="small-btn" data-bk="${esc(x.name)}">${esc(t("bk_restore"))}</button></td></tr>`).join("") + `</tbody></table>`
    : `<span class="muted">${esc(t("bk_none"))}</span>`;
  $$("#bkList [data-bk]").forEach((b) => b.addEventListener("click", () => restoreBackup({ name: b.dataset.bk })));
}
async function restoreBackup(src) {
  let p;
  try { p = await api("backup_preview", src); } catch (e) { return toast(e.message, "err", 8000); }
  const m = p.manifest || {}, i = m.info || {};
  const q = t("bk_restore_q", { d: fmtDT(m.created), v: m.version || "?", s: int(i.sales || 0), a: int(i.assets || 0), c: int(i.collections || 0),
    p: int(i.portfolio || 0), from: i.first || "–", to: i.last || "–" });
  if (!(await uiConfirm(q, t("bk_restore")))) return;
  $("#bkSt").textContent = t("bk_restoring");
  try {
    const r = await api("backup_restore", src);
    toast(t("bk_restored", { n: r.saved_before }), "ok", 8000);
    setTimeout(() => location.reload(), 1800);
  } catch (e) { $("#bkSt").textContent = ""; toast(e.message === "busy" ? t("upd_busy") : e.message, "err", 9000); }
}
function bindBackups() {
  $("#bkNow").addEventListener("click", async () => {
    $("#settingsSave").click();                     // vispirms saglabājam mapi un biežumu
    await new Promise((r) => setTimeout(r, 600));
    $("#bkNow").disabled = true; $("#bkSt").textContent = t("bk_making");
    try { const r = await api("backup_create"); toast(t("bk_made", { n: r.name }), "ok", 6000); loadBackups(); }
    catch (e) { toast(e.message, "err", 9000); }
    $("#bkNow").disabled = false; $("#bkSt").textContent = "";
  });
  $("#bkOpen").addEventListener("click", () => api("backup_open").catch((e) => toast(e.message, "err")));
  /* test44: mapes izvēle sistēmas logā + ātrā poga OneDrive (lietotājs 2026-10-30) */
  /* test4: kamēr mapes izvēles logs atvērts — abas pogas atspējotas (otru logu neatver; core atbild pick_busy) */
  const pickBusy = (on) => ["#bkDirPick", "#bkDirOd", "#bkDirDef"].forEach((s) => { const b = $(s); if (b) b.disabled = on; });
  const pickRun = async (fn) => {
    if ($("#bkDirPick").disabled) return;
    pickBusy(true);
    try { await fn(); }
    catch (e) { if (e.message !== "pick_busy") throw e; }
    finally { pickBusy(false); }
  };
  $("#bkDirPick").addEventListener("click", () => pickRun(async () => {
    try { const r = await api("pick_folder", { start: $("#sBkDir").value.trim() || $("#sBkDir").placeholder }); if (r.path) { $("#sBkDir").value = r.path; $("#settingsSave").click(); } }
    catch (e) { if (e.message !== "pick_busy") toast(e.message, "err"); }
  }));
  $("#bkDirOd").addEventListener("click", () => pickRun(async () => {
    try { const od = await api("pick_folder", { onedrive: true });
      const r = await api("pick_folder", { start: od.path });      // izvēle OneDrive iekšā; logā var izveidot jaunu mapi
      if (r.path) { $("#sBkDir").value = r.path; $("#settingsSave").click(); } }
    catch (e) { if (e.message !== "pick_busy") toast(t("bk_no_od"), "err"); }
  }));
  $("#bkDirDef").addEventListener("click", () => { $("#sBkDir").value = ""; $("#settingsSave").click(); });
  api("onedrive").then((r) => $("#bkDirOd").classList.toggle("hidden", !(r && r.path))).catch(() => {});
  $("#bkPick").addEventListener("click", () => $("#bkFile").click());
  $("#bkFile").addEventListener("change", async () => {
    const f = $("#bkFile").files[0];
    $("#bkFile").value = "";
    if (!f) return;
    $("#bkSt").textContent = t("s_mr_reading");
    const data = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); });
    $("#bkSt").textContent = "";
    restoreBackup({ data });
  });
}
/* e-pasta pieslēgšanās dati — tikai sistēmas drošajā glabātuvē (core/credentials, ieraksts "smtp") */
async function loadSmtp() {
  try {
    const d = await api("creds", { names: ["smtp"] });
    const c = (d.creds || {}).smtp || {};
    $("#sSmtpUser").value = c.user || ""; $("#sSmtpPw").value = "";
    $("#sSmtpPw").placeholder = c.saved ? t("s_smtp_saved") : "";
    $("#sSmtpSt").textContent = !d.available ? t("s_smtp_nokr") : c.saved ? t("s_smtp_saved") : "";
  } catch (_) { /* */ }
}
$("#sMailWhen").addEventListener("change", () => $("#sMailDayL").classList.toggle("hidden", $("#sMailWhen").value !== "day"));
$("#sSmtpSave").addEventListener("click", async () => {
  try { await api("cred_save", { name: "smtp", user: $("#sSmtpUser").value.trim(), password: $("#sSmtpPw").value || null }); toast(t("saved"), "ok"); loadSmtp(); }
  catch (e) { toast(e.message, "err"); }
});
$("#sSmtpForget").addEventListener("click", async () => { try { await api("cred_forget", { name: "smtp" }); loadSmtp(); } catch (e) { toast(e.message, "err"); } });
$("#sMailTest").addEventListener("click", async () => {
  $("#settingsSave").click();                     // vispirms saglabājam adresi un serveri
  await new Promise((r) => setTimeout(r, 700));
  try { await api("mail_test"); toast(t("s_mail_sent", { to: $("#sMailTo").value }), "ok", 6000); }
  catch (e) { toast(t("err_" + e.message) !== "err_" + e.message ? t("err_" + e.message) : e.message, "err", 9000); }
});
/* izmaksu veids un minimums pa aģentūrām: tukšs = noklusējums (aģentūras lapā nolasītais vai izpētītais) */
async function loadPayRules(user) {
  let defs = {};
  try { defs = (await api("payouts", { rules_only: true })).defaults || {}; } catch (_) { /* */ }
  const curSym = (a) => ({ EUR: "€", GBP: "£" }[(S.agencies[a] || {}).currency] || "$");
  $("#sPayRules").innerHTML = `<table class="t"><thead><tr><th>${esc(t("agency"))}</th>
      <th title="${esc(t("pay_tax_tip") + t("pay_tax_tip_z"))}" class="tip">${esc(t("pay_tax"))} ⓘ</th><th>${esc(t("pay_mode"))}</th><th>${esc(t("pay_min"))}</th></tr></thead><tbody>` +
    AG.map((a) => {
      const u = user[a] || {}, df = defs[a] || {};
      return `<tr data-ag="${a}"><td>${dot(a)} ${esc(agName(a))}</td>
        <td><input class="pr-tax" type="number" min="0" max="60" step="any" placeholder="${df.tax_pct != null ? esc(String(df.tax_pct)) : "0"}" value="${u.tax_pct != null ? esc(String(u.tax_pct)) : df.tax_pct ? esc(String(df.tax_pct)) : ""}"><span class="cur">%</span></td>
        <td><select class="pr-mode"><option value="">${esc(t("pay_default", { v: modeTxt(df.mode) }))}</option>
          <option value="auto">${esc(t("pay_auto"))}</option><option value="request">${esc(t("pay_request"))}</option></select></td>
        <td><span class="cur">${curSym(a)}</span><input class="pr-min" type="number" min="0" step="1" placeholder="${df.min != null ? esc(String(df.min)) : "–"}" value="${u.min != null ? esc(String(u.min)) : ""}"></td></tr>`;
    }).join("") + `</tbody></table>`;
  $$("#sPayRules tr[data-ag]").forEach((tr) => { const u = user[tr.dataset.ag] || {}; $(".pr-mode", tr).value = u.mode || ""; });
}
function collectPayRules() {
  if (!$$("#sPayRules tr[data-ag]").length) return S.settings.sales_payout || {};    // tabula vēl nav ielādēta
  const out = {};
  $$("#sPayRules tr[data-ag]").forEach((tr) => {
    const mode = $(".pr-mode", tr).value, min = $(".pr-min", tr).value, tax = $(".pr-tax", tr).value;
    if (mode || min !== "" || tax !== "") out[tr.dataset.ag] = Object.assign({}, mode ? { mode } : {}, min !== "" ? { min: +min } : {}, tax !== "" ? { tax_pct: +tax } : {});
  });
  return out;
}
$("#clearSessions").addEventListener("click", async () => {
  if (!(await uiConfirm(t("clear_sessions_q"), t("clear_sessions")))) return;
  try { await api("clear_sessions"); toast(t("sessions_cleared"), "ok", 5000); } catch (e) { toast(e.message, "err"); }
});

/* ============================================================ valoda */
function onLang() {
  renderPayBanner();
  PP.f.render(); PP.b.render(); PP.ag.render(); PP.cv.render();
  agencyOptions($("#fAgency")); agencyOptions($("#bAgency"));
  refreshColls();
  applySync(S.sync);
  showPage(S.page);
}
const PP = {
  f: PeriodPicker("#fPeriod", () => loadFeed(true), "month"),
  b: PeriodPicker("#bPeriod", () => loadBest(true), "all"),
  cv: PeriodPicker("#cvPeriod", () => { if (S.collOpen) openColl(S.collOpen, true); }, "all"),
  ag: PeriodPicker("#agPeriod", () => loadAgTable(), "month"),
};
Core.init({
  onLang,
  onTheme: () => { if (S.chart.data) renderChart(); if (S.pay && S.pay.data) renderPayChart(); },
  busyOnQuit: () => !!(S.sync && S.sync.running),
  quitQ: () => t("quit_running_q"),
});

/* ============================================================ sākums */
async function init() {
  let st;
  try { st = await api("state"); } catch (e) { toast(e.message, "err"); return; }
  Core.boot(st);
  S.settings = st.settings;
  S.appDir = st.app_dir;
  st.agencies.forEach((a) => (S.agencies[a.id] = a));
  AG = st.agencies.map((a) => a.id);
  try { S.years = (await api("years")).years; } catch (_) {}
  applyI18n();
  PP.f.render(); PP.b.render(); PP.ag.render(); PP.cv.render();
  agencyOptions($("#fAgency")); agencyOptions($("#bAgency"));
  await refreshColls();
  loadRefreshInfo();
  await loadOverview();
  autoSync();
  payReminder();
}
/* Izmaksu atgādinājuma josla (0.3.1, lietotājs 2026-10-31): paliek, līdz aizver ar × (tikai × = "šodien vairs nerādīt");
   "Uz izmaksām" joslu neaizver; pārrēķinās arī pēc katras atjaunošanas; ja vairs nav ko pieprasīt — pazūd pati. */
async function payReminder() {
  const ban = $("#payBanner");
  if (S.settings.sales_payout_remind === false) { ban.classList.add("hidden"); return; }
  try {
    const r = await api("payouts", {});
    const d = r.payouts; S.rates = r.rates || S.rates;
    const when = S.settings.sales_remind_when || "lastday";
    const today = new Date(d.today + "T12:00:00"), last = new Date(today.getFullYear(), today.getMonth() + 1, 0).getDate();
    const dayOk = when === "threshold" || (when === "lastday" ? d.last_day : today.getDate() >= Math.min(+S.settings.sales_remind_day || 28, last));
    /* Magnific rēķins (4.–9.) atgādinām neatkarīgi no "kad" iestatījuma */
    const list = d.can_request.filter((x) => x.validate || dayOk);
    let closed = null;
    try { closed = localStorage.getItem("payRemindClosed"); } catch (_) { /* */ }
    if (!list.length || closed === d.today) { S.payBan = null; ban.classList.add("hidden"); return; }
    S.payBan = Object.assign({}, d, { can_request: list });
    renderPayBanner();
  } catch (_) { /* */ }
}
/* josla tiek pārzīmēta arī, mainot valodu (test53: palika latviski) */
function renderPayBanner() {
  const d = S.payBan, ban = $("#payBanner");
  if (!d) { ban.classList.add("hidden"); return; }
  ban.innerHTML = `<b>${esc(t(d.last_day ? "pay_req_today" : "pay_req_h"))}:</b> ${d.can_request.map((x) =>
      x.validate ? esc(t("pay_req_validate")) + " " + both(x.amount, x.currency, x.eur) : `${esc(agName(x.agency))} ${both(x.amount, x.currency, x.eur)}${reqBox(x)}`).join(" · ")}
    <button class="small-btn" id="payBannerGo">${esc(t("pay_go"))}</button><button class="x" id="payBannerX">×</button>`;
  ban.classList.remove("hidden");
  $("#payBannerGo").addEventListener("click", () => showPage("payouts"));
  $("#payBannerX").addEventListener("click", () => {
    ban.classList.add("hidden"); S.payBan = null;
    try { localStorage.setItem("payRemindClosed", d.today); } catch (_) { /* */ }
  });
}
function autoSync() {
  const d = S.ov;
  const h = +(S.settings.sales_autosync_hours ?? 6);
  if (!d || !h || !d.webview || (d.sync && d.sync.running)) return;
  const en = d.enabled || [];
  const stale = en.filter((a) => {
    const x = d.agencies.find((y) => y.id === a);
    return x && x.last_ok && !x.fresh_until && Date.now() - new Date(x.last_try || x.last_ok).getTime() > h * 3600e3;
  });
  if (stale.length) { toast(t("autosync", { a: stale.map(agName).join(", ") }), "", 4000); startSync(stale); }
}
init();
