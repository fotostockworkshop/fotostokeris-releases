"""Produkta palaišana: žurnāls, serveris, logs (pywebview vai Edge/Chrome "lietotnes" logs, vai pārlūks).

Parametri: --browser (parastā pārlūkā), --no-window (tikai serveris).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import time
import webbrowser
from pathlib import Path

from . import app as _app
from . import config, server


def log_to_file() -> bool:
    """Ja nav konsoles (Windows pythonw) vai palaists no run_mac.command (<SLUG>_LOG=1) — kļūdas rakstām log.txt."""
    env = _app.current().slug.upper() + "_LOG"
    if sys.stdout is None or sys.stderr is None or os.environ.get(env) == "1":
        config.setup_log()
        return True
    return False


def mac_icon() -> None:
    """Mac: logu atver Python, tāpēc Dock rāda Python ikonu — nomainām uz produkta ikonu (<programma>/mac/<Slug>.icns).
    pywebview uz Mac jau lieto pyobjc (AppKit), papildu bibliotēkas nevajag."""
    if not config.IS_MAC:
        return
    try:
        a = _app.current()
        p = a.web_dir.resolve().parent / "mac" / f"{a.slug}.icns"
        if not p.exists():
            return
        from AppKit import NSApplication, NSImage   # type: ignore
        try:                                         # izvēlnes joslā "Analītiķis", nevis "Python"
            from Foundation import NSBundle          # type: ignore
            info = NSBundle.mainBundle().localizedInfoDictionary() or NSBundle.mainBundle().infoDictionary()
            if info is not None:
                info["CFBundleName"] = a.name
        except Exception:
            pass
        img = NSImage.alloc().initWithContentsOfFile_(str(p))
        if img is not None:
            NSApplication.sharedApplication().setApplicationIconImage_(img)
    except Exception as e:  # nav AppKit u.c. — ikona paliek Python
        print("Dock ikona:", e)


def mac_bundle_icon() -> None:
    """2026-11-05 (lietotājs: Analītiķis.app Finder/Launchpad rāda veco ikonu): atjauninājums maina tikai programmas failus
    (<X>.app/Contents/Resources/app/…), bet ne lietotnes ikonu. Ja <Slug>.icns atšķiras no AppIcon.icns — nokopējam un
    liekam Finder ikonu atjaunot (NSWorkspace.setIcon). Tikai, ja programma tiešām darbojas no .app."""
    if not config.IS_MAC:
        return
    try:
        a = _app.current()
        src = a.web_dir.resolve().parent / "mac" / f"{a.slug}.icns"
        app = next((q for q in src.parents if q.suffix == ".app"), None)
        if not app or not src.exists():
            return
        dst = app / "Contents" / "Resources" / "AppIcon.icns"
        if dst.exists() and dst.read_bytes() == src.read_bytes():
            return
        shutil.copyfile(src, dst)
        os.utime(app, None)
        try:
            from AppKit import NSImage, NSWorkspace   # type: ignore
            img = NSImage.alloc().initWithContentsOfFile_(str(src))
            if img is not None:
                NSWorkspace.sharedWorkspace().setIcon_forFile_options_(img, str(app), 0)
        except Exception:
            pass
        print("mac: lietotnes ikona atjaunota", app)
    except Exception as e:
        print("mac: lietotnes ikona:", e)


def mac_dock_hidden() -> None:
    """Mac: palīgprocess (aģentūru logi) bez savas Dock ikonas — logi tik un tā parādās, kad vajag ielogoties."""
    if not config.IS_MAC:
        return
    try:
        from AppKit import NSApplication   # type: ignore
        NSApplication.sharedApplication().setActivationPolicy_(1)    # NSApplicationActivationPolicyAccessory
    except Exception as e:
        print("Dock (palīgprocess):", e)


def _drop_old_favicons(profile: Path) -> None:
    """Edge/Chrome profils glabā vecās ikonas kešu (Favicons) — uzdevumjoslā paliek vecā ikona.
    Pēc katras jaunas versijas kešu izdzēšam vienreiz (atzīme profila mapē)."""
    try:
        ver = _app.current().version
        mark = profile / "fotostokeris-icon-ver.txt"
        if mark.is_file() and mark.read_text(encoding="utf-8").strip() == ver:
            return
        for sub in ("Default", ""):
            d = profile / sub if sub else profile
            for n in ("Favicons", "Favicons-journal"):
                f = d / n
                if f.is_file():
                    try:
                        f.unlink()
                    except OSError:
                        pass          # profils aizņemts (logs jau vaļā) — mēģinās nākamreiz
        profile.mkdir(parents=True, exist_ok=True)
        if not (profile / "Default" / "Favicons").exists():
            mark.write_text(ver, encoding="utf-8")
    except Exception as e:
        print("ikonu kešs:", e)


def app_mode_browser(url: str) -> bool:
    """Mēģina atvērt Edge vai Chrome kā atsevišķu lietotnes logu (bez adreses joslas)."""
    slug = _app.current().slug
    cands = []
    if sys.platform.startswith("win"):
        pf = [os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("PROGRAMFILES", ""),
              os.environ.get("LOCALAPPDATA", "")]
        for base in pf:
            if base:
                cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                          os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    elif sys.platform == "darwin":
        cands += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                  "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                  "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser"]
    else:
        for n in ("google-chrome", "chromium", "chromium-browser", "microsoft-edge"):
            w = shutil.which(n)
            if w:
                cands.append(w)
    profile = Path.home() / (f".{slug.lower()}-browser" if not sys.platform.startswith("win")
                             else f"AppData/Local/{slug}/browser")
    url = url.rstrip("/") + "/" + slug.lower()     # savs ceļš katram modulim — atsevišķa poga Windows uzdevumjoslā
    _drop_old_favicons(profile)
    _prefs_maximized(profile)
    for c in cands:
        if c and os.path.isfile(c):
            try:
                # ja Edge/Chrome ar šo profilu jau darbojas, process uzreiz beidzas (logu atver vecais) —
                # tad server.window_alive() ir False un paļaujamies uz lapas "ping"
                server.state["window_profile"] = str(profile)
                server.state["window_proc"] = subprocess.Popen(
                    [c, f"--app={url}", f"--user-data-dir={profile}",
                     "--start-maximized", "--no-first-run", "--no-default-browser-check"])   # 2026-11-05: bez --window-size (tas atcēla maksimizēšanu)
                return True
            except OSError:
                continue
    return False


def _prefs_maximized(profile: Path) -> None:
    """2026-11-05 (lietotājs: Windows logs neatvērās pa visu ekrānu): Edge/Chrome atceras iepriekšējā loga izmēru profilā
    (Default/Preferences → browser.app_window_placement / window_placement) un to ņem priekšā --start-maximized.
    Pirms palaišanas atzīmējam "maximized": true visām saglabātajām vietām."""
    import json
    p = profile / "Default" / "Preferences"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    b = d.get("browser") if isinstance(d.get("browser"), dict) else None
    if not b:
        return
    changed = False
    places = [b.get("window_placement")] + list((b.get("app_window_placement") or {}).values())
    for w in places:
        if isinstance(w, dict) and not w.get("maximized"):
            w["maximized"] = True
            changed = True
    if changed:
        try:
            p.write_text(json.dumps(d), encoding="utf-8")
        except OSError:
            pass


def run(args: list[str], logged: bool, start=None):
    """Galvenais process: serveris + logs. `logged` — vai žurnāls jau novirzīts uz failu;
    `start` — moduļa servera palaišana (reģistrē moduļa API), noklusējumā core.server.start."""
    a = _app.current()
    srv, url = (start or server.start)()            # aptur veco instanci — tagad log.txt var droši sākt no jauna
    if logged:
        config.setup_log(rotate=True)
    print(f"{a.name} {a.version} darbojas: {url}")
    if config.IS_MAC:                      # Dock ikonu izpētei: kurš Python un vai process pieder lietotnei
        try:
            from Foundation import NSBundle   # type: ignore
            import platform
            import subprocess
            tr = subprocess.run(["sysctl", "-n", "sysctl.proc_translated"], capture_output=True, text=True).stdout.strip()
            # "Support Ending for Intel-Based Apps" (2026-10-30 atkal pēc atjaunināšanas): vai process iet caur Rosetta
            print("mac: python", sys.executable, "· lietotne", NSBundle.mainBundle().bundlePath(),
                  "· arhitektūra", platform.machine(), "· Rosetta" if tr == "1" else "· bez Rosetta",
                  "· pēc atjaunināšanas" if os.environ.get("FOTOSTOKERIS_RESTARTED") else "")
        except Exception as e:
            print("mac: python", sys.executable, "·", e)

    if "--no-window" in args:
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            server.shutdown()
        return

    # Uz Windows galvenais logs ir Edge/Chrome lietotnes logs; uz Mac — pywebview logs, ja ir.
    use_webview = (not config.IS_WIN) or bool(a.webview_main())
    if "--browser" not in args and use_webview:
        try:
            import webview  # pywebview
            webview.create_window(a.name, url, width=1440, height=920, min_size=(1000, 680),
                                  maximized=True)   # lietotājs 2026-11-04: startē pa visu ekrānu
            mac_icon()
            mac_bundle_icon()
            try:
                webview.start(icon=str(a.icon)) if a.icon and a.icon.exists() else webview.start()
            except TypeError:
                webview.start()
            server.shutdown()
            return
        except Exception as e:  # nav pywebview vai neizdevās
            print("pywebview nav pieejams, atveru pārlūkā:", e)

    if os.environ.pop("FOTOSTOKERIS_RESTARTED", "") == "1" and config.IS_WIN and "--browser" not in args:
        # pēc atjaunināšanas: vecais Edge/Chrome logs paliek atvērts un pieslēdzas jaunajai versijai pats
        print("palaists pēc atjaunināšanas — logu neatveru no jauna")
    elif "--browser" in args or not app_mode_browser(url):
        webbrowser.open(url)
    server.idle_watch(5)
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        server.shutdown()
