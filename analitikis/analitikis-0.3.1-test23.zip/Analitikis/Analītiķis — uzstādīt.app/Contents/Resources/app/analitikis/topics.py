"""Pārdošanas kopsavilkums pa tēmām Tirgotājam (vēlme 2026-11-05 16:39; apmaiņa — lēmums 10:02: kopīgs fails / Google Drive).

Fails `sales_topics.json` — Analītiķa datu mapē un (ja pieslēgts Google konts) Drive `Fotostokeris/Kopigi/sales_topics.json`.
Tikai kopsavilkums: bez pircējiem, valstīm un atsevišķām pārdošanām. Formāts (dati §8b):
  {format: 1, updated, computer, currency: "USD", period: {from, to},
   terms: [{t, images, sales, usd, usd_12m, last, agencies: {ag: usd}, ed}],      — vārds vai divu vārdu frāze no virsrakstiem
   images: [{title, sales, usd, usd_12m, last, agencies: [ag], ed, files: [faila nosaukumi]}]}  — top bildes
"""
from __future__ import annotations

import datetime as dt
import json
import re
import threading
import time

from . import db

STOP = set("""a an the and or of in on at to for with by from as is are be into over under near off up down out about between
behind beside above below across along around through during against without within upon onto its it this that these those his her
their our your my some any very more most many much few other another each every both all no not only own same so than too can
will just one two three four five six seven eight nine ten view top side close shot image photo picture stock background""".split())
WORD = re.compile(r"[a-zà-žāčēģīķļņšūž][a-zà-žāčēģīķļņšūž'\-]+", re.I)
FILE = "sales_topics.json"


def _words(title: str) -> list[str]:
    return [w.strip("'-") for w in WORD.findall((title or "").lower()) if len(w) >= 3 and w not in STOP]


def build() -> dict:
    today = dt.date.today()
    y1 = (today - dt.timedelta(days=365)).isoformat()
    # bildes: aģentūras vienums → grupa (viena bilde vairākās aģentūrās); virsraksts — garākais grupā
    gk = {(r["agency"], r["agency_item_id"]): r["key"] for r in db.q("SELECT agency, agency_item_id, key FROM img_link")}
    ed = {(r["agency"], r["agency_item_id"]): r["ed"] for r in db.q(
        "SELECT agency, agency_item_id, ed FROM ed_cls UNION ALL SELECT agency, agency_item_id, ed FROM ed_user")} if _has("ed_cls") else {}
    meta = {(r["agency"], r["agency_item_id"]): (r["title"] or "", r["filename"] or "") for r in db.q(
        "SELECT agency, agency_item_id, title, filename FROM assets")}
    img: dict = {}
    first = last_all = None
    for r in db.q("""SELECT agency, agency_item_id i, SUM(amount_usd) e, SUM(cnt) n, MAX(day) last, MIN(day) first,
                     SUM(CASE WHEN day >= ? THEN amount_usd ELSE 0 END) e12
                     FROM sales WHERE kind='sale' AND agency_item_id != '' GROUP BY agency, agency_item_id""", (y1,)):
        k = (r["agency"], r["i"])
        g = gk.get(k) or f"{k[0]}|{k[1]}"
        x = img.setdefault(g, {"title": "", "sales": 0, "usd": 0.0, "usd_12m": 0.0, "last": "", "agencies": set(), "ed": 0, "files": set()})
        t, fn = meta.get(k, ("", ""))
        if len(t) > len(x["title"]):
            x["title"] = t
        if fn:
            x["files"].add(fn)
        x["sales"] += int(r["n"] or 0)
        x["usd"] += r["e"] or 0
        x["usd_12m"] += r["e12"] or 0
        x["last"] = max(x["last"], r["last"] or "")
        x["agencies"].add(k[0])
        x["ed"] = max(x["ed"], int(ed.get(k) or 0))
        first = min(first or r["first"], r["first"] or first or "")
        last_all = max(last_all or "", r["last"] or "")
    terms: dict = {}
    for x in img.values():
        ws = _words(x["title"])
        keys = set(ws) | {f"{a} {b}" for a, b in zip(ws, ws[1:])}
        for t in keys:
            s = terms.setdefault(t, {"t": t, "images": 0, "sales": 0, "usd": 0.0, "usd_12m": 0.0, "last": "", "agencies": {}, "ed": 0})
            s["images"] += 1
            s["sales"] += x["sales"]
            s["usd"] += x["usd"]
            s["usd_12m"] += x["usd_12m"]
            s["last"] = max(s["last"], x["last"])
            s["ed"] += x["ed"]
            share = x["usd"] / max(1, len(x["agencies"]))
            for a in x["agencies"]:
                s["agencies"][a] = s["agencies"].get(a, 0.0) + share
    tl = [s for s in terms.values() if s["images"] >= 2]
    tl.sort(key=lambda s: -s["usd"])
    for s in tl:
        s["usd"], s["usd_12m"] = round(s["usd"], 2), round(s["usd_12m"], 2)
        s["agencies"] = {a: round(v, 2) for a, v in sorted(s["agencies"].items(), key=lambda kv: -kv[1])}
    il = sorted(img.values(), key=lambda x: -x["usd"])[:300]
    for x in il:
        x["usd"], x["usd_12m"] = round(x["usd"], 2), round(x["usd_12m"], 2)
        x["agencies"], x["files"] = sorted(x["agencies"]), sorted(x["files"])[:5]
    from core import sync as _sync
    return {"format": 1, "updated": dt.datetime.now().isoformat(timespec="seconds"), "computer": _sync.computer(),
            "currency": "USD", "period": {"from": first, "to": last_all}, "images_total": len(img),
            "terms": tl[:1500], "images": il}


def _has(t: str) -> bool:
    return bool(db.q1("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (t,)))


def write() -> dict:
    from core import config
    d = build()
    data = json.dumps(d, ensure_ascii=False).encode("utf-8")
    (config.app_dir() / FILE).write_bytes(data)
    where = "datu mapē"
    try:
        from core import google
        if google.connected():
            fid = google.folder("Kopigi")
            old = next((f["id"] for f in google.list_files(fid) if f["name"] == FILE), None)
            google.put_bytes(fid, FILE, data, old)
            where += " un Google Drive Fotostokeris/Kopigi"
    except Exception as e:
        print("pārdošanas tēmas: Google Drive —", str(e)[:120])
    db.set_state("_topics", "written", d["updated"])
    print(f"pārdošanas tēmas: {len(d['terms'])} tēmas, {len(d['images'])} bildes — {where}")
    return {"terms": len(d["terms"]), "images": len(d["images"]), "where": where}


def start() -> None:
    """Fonā: ~10 min pēc palaišanas un tad reizi 12 h (vai biežāk nevajag — Tirgotājam pietiek ar dienas datiem)."""
    def loop():
        time.sleep(600)
        while True:
            try:
                w = db.get_state("_topics", "written") or ""
                if not w or (dt.datetime.now() - dt.datetime.fromisoformat(w)).total_seconds() > 12 * 3600:
                    write()
            except Exception as e:
                print("pārdošanas tēmas:", str(e)[:160])
            time.sleep(1800)
    threading.Thread(target=loop, daemon=True, name="topics").start()
