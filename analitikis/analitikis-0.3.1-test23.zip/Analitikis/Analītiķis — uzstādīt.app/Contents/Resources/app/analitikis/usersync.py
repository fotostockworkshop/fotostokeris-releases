"""Analītiķa lietotāja darbs sinhronizācijai starp datoriem (core/sync.py, noteikumi dati §7a).

Sinhronizējas tikai tas, ko lietotājs izdarījis ar roku vai ko no aģentūrām vairs nevar ielādēt:
kolekcijas (+ bildes tajās), bilžu apvienošana ar roku (img_link src='man'), RF/ED atzīmes (ed_user),
Microstockr sasaistes (mr_link), portfeļa vēsture no CSV (portfolio source='import').
Aģentūru dati (pārdošanas, izmaksas, portfelis) — katrs dators ielādē pats; jaunam datoram — pilna kopija (db_snapshot).
Kolekciju ID dažādos datoros atšķiras, tāpēc atslēga = izveides laiks + nosaukums.
"""
from __future__ import annotations

import json

import gzip
import shutil
import sqlite3
from pathlib import Path

from . import db

NAME = "user_data.json"


def _ckey(created, name) -> str:
    return f"{created or ''}|{name or ''}"


def export() -> dict:
    c = db.conn()
    with db._lock:
        cols = {}
        ids = {}
        for r in c.execute("SELECT id, name, created_at, source FROM collections"):
            k = _ckey(r[2], r[1])
            ids[r[0]] = k
            cols[k] = {"name": r[1], "created_at": r[2], "source": r[3] or "user", "items": {}}
        for r in c.execute("SELECT collection_id, agency, agency_item_id, added_at FROM collection_items"):
            k = ids.get(r[0])
            if k:
                cols[k]["items"][f"{r[1]}|{r[2]}"] = r[3] or ""
        out = {"collections": cols,
               "img_man": {f"{r[0]}|{r[1]}": r[2] for r in c.execute("SELECT agency, agency_item_id, key FROM img_link WHERE src='man'")},
               "ed_user": {f"{r[0]}|{r[1]}": {"ed": r[2], "at": r[3]} for r in c.execute("SELECT agency, agency_item_id, ed, at FROM ed_user")}
               if _has(c, "ed_user") else {},
               "mr_link": {f"{r[0]}|{r[1]}": r[2] for r in c.execute("SELECT agency, agency_item_id, tag FROM mr_link")},
               "portfolio_import": {f"{r[0]}|{r[1]}": {"files": r[2], "updated": r[3]}
                                    for r in c.execute("SELECT agency, month, files, updated FROM portfolio WHERE source='import'")},
               # 2026-11-04 (lietotājs: oktobris tukšs, iStock novembris pazudis): arī aģentūru nolasītās vērtības — tās
               # nolasa tas dators, kurā atjauno aģentūru; bez šī citā datorā mēneši palika tukši
               "portfolio_agency": {f"{r[0]}|{r[1]}": {"files": r[2], "updated": r[3]}
                                    for r in c.execute("SELECT agency, month, files, updated FROM portfolio WHERE source='agency'")},
               # 2026-11-06 (lietotājs: Mac nerāda pieprasīto Adobe izmaksu): pieprasījumu atzīmes (`payout_req`) — tās
               # atpazīst tas dators, kurš redzēja atlikuma kritumu vai kurā ielikts ķeksis
               "payout_req": {r[0]: r[1] for r in c.execute("SELECT agency, value FROM state WHERE key='payout_req' AND value IS NOT NULL AND value!='null'")}}
    return out


def _has(c, table) -> bool:
    return bool(c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone())


def _split(k: str):
    a, _, b = k.partition("|")
    return a, b


def import_(data: dict) -> None:
    c = db.conn()
    regroup = False
    with db._lock:
        cols = data.get("collections") or {}
        old = {_ckey(r[2], r[1]): r[0] for r in c.execute("SELECT id, name, created_at FROM collections")}
        for k, cid in old.items():
            if k not in cols:
                c.execute("DELETE FROM collection_items WHERE collection_id=?", (cid,))
                c.execute("DELETE FROM collections WHERE id=?", (cid,))
        for k, v in cols.items():
            cid = old.get(k)
            if cid is None:
                cid = c.execute("INSERT INTO collections(name, created_at, source) VALUES(?,?,?)",
                                (v.get("name"), v.get("created_at"), v.get("source") or "user")).lastrowid
            else:
                c.execute("UPDATE collections SET source=? WHERE id=?", (v.get("source") or "user", cid))
            want = v.get("items") or {}
            have = {f"{r[0]}|{r[1]}" for r in c.execute("SELECT agency, agency_item_id FROM collection_items WHERE collection_id=?", (cid,))}
            for it in have - set(want):
                a, b = _split(it)
                c.execute("DELETE FROM collection_items WHERE collection_id=? AND agency=? AND agency_item_id=?", (cid, a, b))
            for it, at in want.items():
                if it not in have:
                    a, b = _split(it)
                    c.execute("INSERT OR IGNORE INTO collection_items VALUES(?,?,?,?)", (cid, a, b, at))
        man = data.get("img_man") or {}
        cur = {f"{r[0]}|{r[1]}": r[2] for r in c.execute("SELECT agency, agency_item_id, key FROM img_link WHERE src='man'")}
        if cur != man:
            regroup = True
            for k in set(cur) - set(man):
                a, b = _split(k)
                c.execute("DELETE FROM img_link WHERE agency=? AND agency_item_id=? AND src='man'", (a, b))
            for k, key in man.items():
                a, b = _split(k)
                c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (a, b, key, "man"))
        if _has(c, "ed_user") and "ed_user" in data:
            c.execute("DELETE FROM ed_user")
            for k, v in (data.get("ed_user") or {}).items():
                a, b = _split(k)
                c.execute("INSERT OR REPLACE INTO ed_user VALUES(?,?,?,?)", (a, b, v.get("ed"), v.get("at")))
        mr = data.get("mr_link") or {}
        cur = {f"{r[0]}|{r[1]}": r[2] for r in c.execute("SELECT agency, agency_item_id, tag FROM mr_link")}
        if cur != mr:
            regroup = True
            c.execute("DELETE FROM mr_link")
            for k, tag in mr.items():
                a, b = _split(k)
                c.execute("INSERT OR REPLACE INTO mr_link VALUES(?,?,?)", (a, b, tag))
        for k, v in (data.get("portfolio_import") or {}).items():
            a, m = _split(k)
            c.execute("INSERT OR IGNORE INTO portfolio VALUES(?,?,?,?,?)", (a, m, v.get("files"), "import", v.get("updated")))
        for k, v in (data.get("portfolio_agency") or {}).items():
            a, m = _split(k)
            if not v.get("files"):
                continue
            # mēnesī paliek jaunākais aģentūras nolasījums (no jebkura datora); importu aizstāj
            c.execute("""INSERT INTO portfolio VALUES(?,?,?,'agency',?)
                         ON CONFLICT(agency, month) DO UPDATE SET files=excluded.files, source='agency', updated=excluded.updated
                         WHERE portfolio.source!='agency' OR COALESCE(portfolio.updated,'') < COALESCE(excluded.updated,'')""",
                      (a, m, int(v["files"]), v.get("updated")))
        for a, v in (data.get("payout_req") or {}).items():     # jaunākā atzīme (pēc `at`) uzvar
            try:
                nv = json.loads(v) if isinstance(v, str) else v
                ov = c.execute("SELECT value FROM state WHERE agency=? AND key='payout_req'", (a,)).fetchone()
                ov = json.loads(ov[0]) if ov and ov[0] else None
                if isinstance(nv, dict) and (not isinstance(ov, dict) or str(nv.get("at") or "") > str(ov.get("at") or "")):
                    c.execute("INSERT OR REPLACE INTO state VALUES(?,?,?)", (a, "payout_req", json.dumps(nv)))
            except (ValueError, TypeError):
                pass
        c.commit()
    if regroup:
        try:
            db.regroup()
        except Exception as e:
            print("sinhronizācija: bilžu grupas:", e)


# --------------------------------------------------------------------------- pilna datubāzes kopija (jaunam datoram)

def snapshot(dst: Path) -> None:
    """Saskaņota catalog.db kopija (SQLite backup), saspiesta gzip."""
    tmp = dst.with_suffix(".tmpdb")
    src = db.conn()
    out = sqlite3.connect(str(tmp))
    try:
        with db._lock:
            src.backup(out)
    finally:
        out.close()
    with open(tmp, "rb") as f, gzip.open(dst, "wb", compresslevel=6) as g:
        shutil.copyfileobj(f, g)
    tmp.unlink(missing_ok=True)


def is_empty() -> bool:
    try:
        r = db.q1("SELECT COUNT(*) FROM sales")
        return not (r and r[0])
    except Exception:
        return True


def restore(gz: Path) -> None:
    """Jauns dators: Drive kopija kļūst par vietējo datubāzi (pirms tam — rezerves kopija, kā atjaunojot)."""
    from . import sync as agsync
    tmp = db.db_path().with_suffix(".fromdrive")
    with gzip.open(gz, "rb") as g, open(tmp, "wb") as f:
        shutil.copyfileobj(g, f)
    try:
        from core import backup
        backup.create(tag="pirms-sinhronizacijas")
    except Exception as e:
        print("sinhronizācija: kopija pirms ielādes:", e)
    agsync.stop(wait=8)
    db.close()
    p = db.db_path()
    for ext in ("-wal", "-shm"):
        Path(str(p) + ext).unlink(missing_ok=True)
    tmp.replace(p)
    db.conn()


def replace_from(gz: Path, data_at: str) -> None:
    """2026-11-06 (lietotājs: abos datoros jābūt vienam skatam): cits dators aģentūras atjaunojis vēlāk — ņemam tā
    datubāzi. Savas ar roku veiktās izmaiņas (kolekcijas, apvienošana, RF/ED, pieprasījumu atzīmes, portfelis) saglabājam:
    pirms nomaiņas eksportējam, pēc — ieliekam atpakaļ. Iepriekšējā datubāze paliek kā `catalog.db.prev` (viena)."""
    from . import sync as agsync
    mine = export()
    tmp = db.db_path().with_suffix(".fromdrive")
    with gzip.open(gz, "rb") as g, open(tmp, "wb") as f:
        shutil.copyfileobj(g, f)
    agsync.stop(wait=8)
    db.close()
    p = db.db_path()
    for ext in ("-wal", "-shm"):
        Path(str(p) + ext).unlink(missing_ok=True)
    prev = p.with_suffix(".db.prev")
    try:
        prev.unlink(missing_ok=True)
        p.replace(prev)
    except OSError:
        pass
    tmp.replace(p)
    db.conn()
    try:
        import_(mine)
    except Exception as e:
        print("sinhronizācija: savu izmaiņu atjaunošana:", e)
    db.set_data_at(data_at)
