"""Vecais nosaukums → izmaksu modulis (analitikis/izmaksas/aprekins.py). Tas pats modulis, ne kopija."""
import sys

from . import db  # noqa: F401  — db pirmā (db ↔ izmaksas cikls, kā agrāk)
from .izmaksas import aprekins as _m

sys.modules[__name__] = _m
