/* Zoonar: www.zoonar.com — /api/user/profile/user_sales/<lapa> (pārdošanas un izmaksas, EUR, neto).
   Personas datus (payout_user: adrese, tālrunis) NEŅEMAM — tikai vajadzīgos laukus. */
async function collect() {
  if (!/(^|\.)zoonar\.com$/.test(location.hostname)) throw LOGIN;
  /* Zoonar (Vue lietotne) API prasa ieejas žetonu no pārlūka atmiņas (localStorage), ne tikai sīkdatnes.
     Žetonu tikai pievienojam pieprasījumam — nekur nesaglabājam un žurnālā nerakstām. */
  function token() {
    for (const st of [localStorage, sessionStorage]) {
      for (let i = 0; i < st.length; i++) {
        const k = st.key(i);
        if (!/token|auth|jwt|user/i.test(k)) continue;
        let v = st.getItem(k) || "";
        try { const o = JSON.parse(v); v = (o && (o.access_token || o.token || o.accessToken || (o.auth && o.auth.token) || (o.user && o.user.token))) || (typeof o === "string" ? o : ""); } catch (_) { /* vienkārša virkne */ }
        if (/^[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+$/.test(v) || (/token/i.test(k) && v.length > 20 && !/\s/.test(v))) return { k, v };
      }
    }
    return null;
  }
  const tk = token();
  B.log(AG, "ieejas žetons: " + (tk ? `atrasts (${tk.k})` : "nav"));
  const H = Object.assign({ "X-Requested-With": "XMLHttpRequest" }, tk ? { Authorization: `Bearer ${tk.v}` } : {});
  /* atbilde var būt ietīta: {response: {balance_rows, …}} (Zoonar 2026-10) */
  const unwrap = (j) => {
    for (let i = 0; i < 3 && j && typeof j === "object" && !Array.isArray(j.balance_rows); i++) {
      const inner = j.response || j.data || j.result;
      if (!inner || typeof inner !== "object") break;
      j = inner;
    }
    return j;
  };
  const P = async (n) => unwrap(await getj(`/api/user/profile/user_sales/${n}`, H));
  const first = await P(0);
  if (!first || !Array.isArray(first.balance_rows)) {
    const raw = first && typeof first === "object" ? first : {};
    const r0 = raw.response;
    B.log(AG, "atbildē nav balance_rows: " + Object.keys(raw).slice(0, 10).join(",")
      + (r0 != null && typeof r0 !== "object" ? ` (response: ${String(r0).slice(0, 60)})` : ""));
    throw LOGIN;
  }
  const pages = Math.max(1, +first.total_pages || 1);
  let all = first.balance_rows.slice();
  for (let n = 1; n < pages && n < 200; n++) {
    say(`${n + 1}/${pages}`, Math.round((n / pages) * 80));
    const j = await P(n);
    const br = (j && j.balance_rows) || [];
    all = all.concat(br);
    /* lietotājs 2026-11-01: tikai kopš pēdējās atjaunošanas — rindas jaunākās augšā; tālāk vecākas */
    if (OPTS.mode !== "full" && !OPTS.payouts_full && br.length && (pdate(br[br.length - 1].date) || "9") < OPTS.since) { all.__part = 1; B.log(AG, `lapas līdz ${n + 1}/${pages} (no ${OPTS.since})`); break; }
    await sleep(200);
  }
  /* virsraksts no adreses: …/photo/riga-old-town_123456.html → "riga old town" */
  const slug = (u) => {
    const m = String(u || "").match(/\/([^/?#]+?)\/?(?:[?#].*)?$/);
    if (!m) return "";
    return decodeURIComponent(m[1]).replace(/\.html?$/i, "").replace(/[-_]?\d{3,}$/, "").replace(/[-_]+/g, " ").trim();
  };
  const big = await biggerThumb(all.filter((r) => !r.is_payout && r.img_url));
  const rows = [];
  for (const r of all) {
    if (r.is_payout) continue;                          // izmaksas — 3. daļā (izmaksu vēsture)
    const day = pdate(r.date);
    const amount = money(r.value);
    if (!day || !amount) continue;
    const id = String(r.res_id || "");
    rows.push({ day, id, title: slug(r.res_url), thumb: big(r) || r.img_url || "", url: r.res_url || "", amount, cnt: 1, kind: "sale",
      license: [r.partner || "Zoonar", r.license || ""].filter(Boolean).join(" · ") });
  }
  B.log(AG, `pārdošanas: ${rows.length} (rindas kopā ${all.length}, lapas ${pages})`);
  let start = rows.length ? rows.reduce((m, x) => (x.day < m ? x.day : m), today) : today;
  if (all.__part) { start = OPTS.since; rows.splice(0, rows.length, ...rows.filter((x) => x.day >= start)); }   // robežas diena var būt nepilna
  await sendRows(rows, { start, end: today, currency: "EUR" });
  if (first.current_balance != null) await send("balance", { amount: money(first.current_balance), currency: "EUR" });
  /* izmaksas: jāpieprasa ("Payout balance"); vēsture — balance_rows ar is_payout (negatīvas summas) */
  await payoutsSafe(async () => {
    await sendPayInfo({ unpaid: money(first.current_balance), available: money(first.current_balance),
      min: first.payout_limit != null ? money(first.payout_limit) : null, currency: "EUR" });
    await sendPayouts(all.filter((r) => r.is_payout).map((r) => ({ date: pdate(r.date), amount: Math.abs(money(r.value)), currency: "EUR" })));
  });
  if (OPTS.sub_due) { try { await znStatus(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  const pn = await portfolioSafe([
    ["dashboard (Active in Sale)", () => framed("/user/dashboard", (t) => { const m = t.match(ACTIVE_RE); return m ? numOf(m[1].replace(/[.\s]/g, "")) : null; })],
    ["user_sales", async () => countKey(first, /active_?in_?sale|in_?sale|online|^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["profile", async () => { const j = unwrap(await getj("/api/user/profile", H)); const n = countKey(j, /active_?in_?sale|in_?sale|online|approved/i);
      if (!n) B.log(AG, "portfelis: profile atslēgas: " + keysOf(j)); return n; }],
  ]);
  if (!pn) { const r = await portNav("/user/dashboard", ACTIVE_RE.source, "dashboard (Active in Sale)"); if (r) return r; }
  return { rows: rows.length };
}

/* "Active in Sale" — Zoonar lapa bieži atveras vāciski (lietotājs 2026-10-31): meklējam abās valodās */
const ACTIVE_RE = /(?:Active in Sale|Aktiv im Verkauf|Im Verkauf aktiv|Im Verkauf|Aktiv(?:e)? (?:Dateien|Bilder))\s*:?\s*(\d[\d.,\s]*\d|\d)/i;

/* Zoonar dod ļoti mazu sīktēlu (img_url) — kartītēs izstiepts un miglains (lietotājs 2026-10-30). Atrodam lielāku tās
   pašas bildes priekšskatījumu: 1) bildes lapas og:image, no tā veidne ar bildes ID; 2) izmēra vārdi adresē
   (thumb/small/…). Katru variantu pārbaudām, vai tas tiešām ielādējas un ir lielāks. Rezultāts — funkcija rinda → adrese. */
async function biggerThumb(list) {
  const none = () => "";
  if (!list.length) return none;
  const load = (u) => new Promise((res) => {
    const im = new Image();
    const t = setTimeout(() => res(0), 8000);
    im.onload = () => { clearTimeout(t); res(im.naturalWidth || 0); };
    im.onerror = () => { clearTimeout(t); res(0); };
    im.src = u;
  });
  const shape = (u) => { try { const x = new URL(u, location.href); return x.host + x.pathname.replace(/\d{3,}/g, "N").slice(0, 70); } catch (_) { return "?"; } };
  const s0 = list[0], s1 = list.find((r) => String(r.res_id) !== String(s0.res_id)) || s0;
  const w0 = await load(s0.img_url);
  B.log(AG, `sīktēls: ${shape(s0.img_url)} — ${w0}px`);
  if (w0 >= 400) return none;
  const abs = (u) => { try { return new URL(u, location.href).href; } catch (_) { return ""; } };
  /* 1) og:image bildes lapā → veidne ar {id} */
  try {
    if (s0.res_url && s0.res_id) {
      const d = await getdoc(s0.res_url);
      const og = abs((d.querySelector('meta[property="og:image"]') || d.querySelector('meta[name="twitter:image"]') || {}).content || "");
      const id = String(s0.res_id);
      if (og && og.includes(id)) {
        const tpl = og.split(id).join("{id}");
        const test = tpl.split("{id}").join(String(s1.res_id));
        const w = await load(test);
        B.log(AG, `sīktēls: og:image ${shape(og)} — ${w}px`);
        if (w > w0) return (r) => (r.res_id ? tpl.split("{id}").join(String(r.res_id)) : "");
      } else {
        B.log(AG, "sīktēls: og:image " + (og ? "bez bildes ID — " + shape(og) : "nav"));
        /* og:image ar to pašu nosaukumu, cits cipars priekšā (7_abc.jpg → 3_abc.jpg) → tas pats cipars visām */
        const tail = (u) => (String(u).match(/\/(\d+)_([^/?#]+)$/) || []);
        const a = tail(s0.img_url), b = tail(og);
        if (a[2] && b[2] && a[2] === b[2] && a[1] !== b[1]) {
          const f = (u) => String(u || "").replace(/\/\d+_([^/?#]+)$/, `/${b[1]}_$1`);
          const w = await load(f(s1.img_url));
          B.log(AG, `sīktēls: og cipars ${b[1]}_ — ${w}px`);
          if (w > w0) return (r) => f(r.img_url);
        }
      }
    }
  } catch (e) { if (e && e.login) throw e; B.log(AG, "sīktēls: bildes lapa — " + ((e && e.message) || e)); }
  /* 2) cipars nosaukuma priekšā (…/7_hash.jpg) — izmēģinām citus, ņemam lielāko (lietotājs 2026-10-31: 45 px) */
  if (/\/\d+_[^/?#]+$/.test(s0.img_url)) {
    let best = 0, bp = null;
    for (let p = 0; p <= 12; p++) {
      const w = await load(String(s1.img_url).replace(/\/\d+_([^/?#]+)$/, `/${p}_$1`));
      if (w > best) { best = w; bp = p; }
    }
    B.log(AG, `sīktēls: labākais cipars ${bp}_ — ${best}px`);
    if (bp != null && best > w0 && best >= 120) return (r) => String(r.img_url || "").replace(/\/\d+_([^/?#]+)$/, `/${bp}_$1`);
  }
  /* 3) izmēra vārdi adresē */
  const SW = [[/\/thumbs?\//i, "/preview/"], [/\/thumbs?\//i, "/medium/"], [/\/small\//i, "/medium/"], [/\/small\//i, "/large/"],
    [/_thumb(\.\w+)$/i, "_preview$1"], [/_s(\.\w+)$/i, "_m$1"], [/([?&](?:w|width|size|s)=)\d{2,3}/i, "$1450"],
    [/\/thumbnail\//i, "/preview/"], [/\/t\//, "/m/"]];
  for (const [re, to] of SW) {
    if (!re.test(s0.img_url)) continue;
    const f = (u) => String(u || "").replace(re, to);
    const w = await load(f(s1.img_url));
    if (w > w0 && w >= 200) { B.log(AG, `sīktēls: ${shape(f(s0.img_url))} — ${w}px`); return (r) => f(r.img_url); }
  }
  B.log(AG, "sīktēls: lielāks variants nav atrasts");
  return none;
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /user/dashboard — "Active in Sale: N", "Under Review: N",
   "Missing Metadata: N" (tikai skaiti); /user/manage_images — jaunākās augšā: "#25936388", virsraksts, partneru zīmes
   ("Alamy · In review", "IMAGO · In sale", …). Noraidītās lapā nav (tikai e-pastā) — nelasām. */
async function znStatus() {
  try {
    const t = (await framed("/user/dashboard", (x) => (/Active in Sale/i.test(x) ? x : null), 25000)) || "";
    const n = (re) => (t.match(re) || [])[1];
    B.log(AG, `statusi: dashboard — pārdošanā ${n(/Active in Sale:\s*(\d[\d,]*)/i) || "?"}, pārbaudē ${n(/Under Review:\s*(\d+)/i) || "?"}, bez metadatiem ${n(/Missing Metadata:\s*(\d+)/i) || "?"}`);
  } catch (e) { if (e && e.login) throw e; }
  const parse = (doc) => {
    const out = new Map();
    for (const a of doc.querySelectorAll("a, span, div")) {
      const m = (a.innerText || a.textContent || "").trim().match(/^#(\d{6,10})$/); if (!m || out.has(m[1])) continue;
      const tr = a.closest("tr") || a.closest("[class*=row]") || a.parentElement.parentElement;
      const tt = (tr && (tr.innerText || tr.textContent) || "");
      const parts = [...tt.matchAll(/([A-Za-z][A-Za-z .]{1,30}?)\s*·\s*(In sale|In review|Rejected|Declined|Pending)/g)].map((x) => `${x[1].trim()}: ${x[2]}`);
      const title = (tt.split("\n").map((x) => x.trim()).find((x) => x.length > 25 && !/^#/.test(x)) || "").slice(0, 250);
      const st = parts.length ? (parts.some((x) => /In sale/.test(x)) ? "In sale" : "In review") + " (" + parts.join(", ") + ")" : "Uploaded";
      out.set(m[1], { id: m[1], file: "", title, submitted: "", status: st.slice(0, 160) });
    }
    return [...out.values()];
  };
  /* 2026-11-06 (žurnāls): bez rāmja partneru zīmes nav — lasām tikai rāmī, gaidām zīmes "· In sale/In review" */
  let rows = (await framed("/user/manage_images", (x) => (/·\s*In (sale|review)/.test(x) ? true : null), 40000, async ({ doc }) => { await sleep(1000); return parse(doc); }).catch(() => null)) || [];
  if (!rows.length) rows = (await framed("/user/manage_images", (x) => (/#\d{6,}/.test(x) ? true : null), 30000, async ({ doc }) => parse(doc)).catch(() => null)) || [];
  const f = rows[0];
  B.log(AG, `statusi: ${rows.length} bildes` + (f ? `; paraugs: #${f.id}, ${f.status.slice(0, 80)}` : ""));
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
