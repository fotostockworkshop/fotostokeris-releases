"""Vecais nosaukums → izmaksu modulis (analitikis/izmaksas/vesture.py). Tas pats modulis, ne kopija."""
import sys

from . import db  # noqa: F401
from .izmaksas import vesture as _m

sys.modules[__name__] = _m
