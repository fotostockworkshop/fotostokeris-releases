"""Iesniegumu statusi aģentūrās (lēmums 2026-11-05, noteikumi §7: statusus nolasa Analītiķis).

Tabula `sub_status` — aģentūras pašas saraksts ar katras bildes stāvokli (piem. Envato Portfolio Manager "Download CSV"):
  agency, item_id (aģentūras ID), file_name (iesniegtā faila nosaukums — `<kods>_<oriģinālais>`, ja iesniegts caur
  Vārdotāju/Tirgotāju), title, tags, status (normalizēts: review | accepted | changes | rejected | other), raw_status,
  submitted_at, changed_at (kad statuss mainījās), seen_at (pēdējo reizi redzēts sarakstā).
Tirgotājam statusi tiks nodoti vēlāk (formāts — dati §8, saskaņot ar Tirgotāja uzskaiti).
"""
from __future__ import annotations

import datetime as dt

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS sub_status(agency TEXT, item_id TEXT, file_name TEXT, title TEXT, tags TEXT,
  status TEXT, raw_status TEXT, submitted_at TEXT, changed_at TEXT, seen_at TEXT, PRIMARY KEY(agency, item_id));
"""

NORM = [("changes", ("changes required", "soft reject", "needs changes", "correction needed", "need revisions", "returned", "needs edits")),
        ("rejected", ("unavailable", "rejected", "declined", "refused", "not accepted", "hard reject", "failed qc", "qc fail")),   # pirms "review"/"accepted":
        ("review", ("in review", "pending", "review", "waiting", "queue", "in qc", "not on sale", "processing", "under revision", "awaiting", "submitted")),                                # "Not accepted: …" satur abus
        ("accepted", ("approved", "accepted", "for sale", "on sale", "in sale", "online", "active", "published"))]


def norm(raw: str) -> str:
    r = (raw or "").strip().lower().split(" (")[0]      # iekavās — papildu sīkumi (Zoonar partneri, Alamy atrodamība)
    for k, keys in NORM:
        if any(x in r for x in keys):
            return k
    return "other"


def ingest(agency: str, d: dict) -> None:
    """d = {rows: [{id, file, title, tags, status, submitted}], part: i, parts: n}"""
    now = dt.datetime.now().isoformat(timespec="seconds")
    rows = d.get("rows") or []
    # 2026-11-06 (test8 žurnāls): Adobe/Shutterstock/Magnific saglabāja nepareizus sarakstus (kategorijas, profilu, "Downloads 34k")
    # — vienreiz izdzēšam šo aģentūru statusus un lasām no jauna
    if agency in ("adobe", "shutterstock", "magnific") and not db.get_state(agency, "sub_clean_v1"):
        with db._lock:
            c = db.conn(); c.executescript(SCHEMA)
            c.execute("DELETE FROM sub_status WHERE agency=?", (agency,)); c.commit()
        db.set_state(agency, "sub_clean_v1", "1")
        db.set_state(agency, "sub_full", "")
    with db._lock:
        c = db.conn()
        c.executescript(SCHEMA)
        changed = 0
        for r in rows:
            iid = str(r.get("id") or "")[:80]
            if not iid:
                continue
            st = norm(r.get("status"))
            old = c.execute("SELECT status, raw_status FROM sub_status WHERE agency=? AND item_id=?", (agency, iid)).fetchone()
            if st == "other" and old and old["status"] != "other":
                st, r = old["status"], dict(r, status=old["raw_status"])   # "tikai augšupielādēts" nenoņem zināmu statusu
            ch = now if not old or old["status"] != st else None
            if old and ch:
                changed += 1
            c.execute("""INSERT INTO sub_status VALUES(?,?,?,?,?,?,?,?,?,?)
                         ON CONFLICT(agency, item_id) DO UPDATE SET file_name=COALESCE(NULLIF(excluded.file_name,''), sub_status.file_name),
                           title=excluded.title, tags=excluded.tags, status=excluded.status, raw_status=excluded.raw_status,
                           submitted_at=excluded.submitted_at, changed_at=COALESCE(?, sub_status.changed_at), seen_at=excluded.seen_at""",
                      (agency, iid, str(r.get("file") or "")[:200], str(r.get("title") or "")[:300], str(r.get("tags") or "")[:2000],
                       st, str(r.get("status") or "")[:160], str(r.get("submitted") or "")[:25], ch or now, now, ch))
        c.commit()
    if d.get("part") == d.get("parts"):
        cnt = {x["status"]: x["n"] for x in db.q("SELECT status, COUNT(*) n FROM sub_status WHERE agency=? GROUP BY status", (agency,))}
        print(f"[{agency}] iesniegumu statusi: {cnt}" + (f"; mainījušies {changed}" if changed else ""))


def summary(agency: str | None = None) -> list[dict]:
    q = "SELECT agency, status, COUNT(*) n FROM sub_status" + (" WHERE agency=?" if agency else "") + " GROUP BY agency, status"
    return [dict(r) for r in db.q(q, (agency,) if agency else ())]
