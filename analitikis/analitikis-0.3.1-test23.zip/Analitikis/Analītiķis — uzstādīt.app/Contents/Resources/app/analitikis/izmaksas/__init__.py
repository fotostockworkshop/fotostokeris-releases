"""IZMAKSU MODULIS (aizsargāts) — aģentūru izmaksu nolasīšana, saņemtā summa un datums, vēsturiskās izmaksas,
minimumi, neizmaksātais, izmaksu prognoze un pārskats.

Pārbaudīts pret PayPal un aģentūru datiem 2026-11-08 (0.3.1-test17; atskaites zars `izmaksas-ok-test17`).
NEMAINĪT garāmejot: katra izmaiņa — atsevišķā versijā, ar lietotāja pārbaudi; pēc tam `dev/izmaksas_check.py --apstiprinu`.
Apraksts: docs/izmaksu-modulis.md (arī Claude projektā claude/izmaksu-modulis.md).

Sastāvs: aprekins.py (bij. payouts.py) — aprēķins un ievade no savācējiem; vesture.py (bij. payouts_hist.py) — vienreizējās
vēsturiskās izmaksas. Savācēju izmaksu daļas (collectors/*.js `payoutsSafe` bloki, Magnific `taxcenter`, common.js palīgi,
payout.js) — arī aizsargātas (kontrolsummas dev/izmaksas.lock).
Vecie nosaukumi `analitikis.payouts` / `analitikis.payouts_hist` paliek kā tie paši moduļi (citām programmas daļām nekas nemainās)."""

from .. import db  # noqa: F401,E402  — db pirmā: db ielādē izmaksas.aprekins un reģistrē ievadi (cikls db ↔ aprekins, kā agrāk)
