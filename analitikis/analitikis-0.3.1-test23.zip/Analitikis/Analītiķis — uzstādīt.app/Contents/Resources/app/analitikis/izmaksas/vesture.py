"""Vēsturiskās izmaksas (2026-11-08, lietotājs): vienreiz ielasa failu <datu mape>/vesturiskas_izmaksas.json —
izmaksas, ko aģentūras vairs nerāda (apstiprinātas PayPal) vai aģentūras, kuru vairs nav (lietotāja grāmatvedība).
Bez saskarnes un bez manuālas ievades programmā. Pēc ielasīšanas fails pārdēvēts par *.ielasits.json.

Formāts: {"rows": [{"agency", "date": "YYYY-MM-DD", "amount", "currency", "note"?, "replaces"?: "YYYY-MM-DD"}]}
  replaces — aģentūras dotā izmaksa ap šo datumu (±6 d.) nav pareiza; to aizstāj šī rinda (ref "hist-fix:<datums>").
Rindas ar ref "hist…" aģentūru atjaunošana nedzēš (payouts._payouts)."""
from __future__ import annotations

import json

from .. import config
from .. import db
from . import aprekins as payouts

FILE = "vesturiskas_izmaksas.json"


def load_once() -> int:
    p = config.app_dir() / FILE
    if not p.exists():
        return 0
    data = json.loads(p.read_text(encoding="utf-8"))
    rows = data.get("rows") or []
    n = 0
    with db._lock:
        c = db.conn()
        payouts.ensure(c)
        c.execute("DELETE FROM payouts WHERE ref LIKE 'hist%'")      # atkārtota ielasīšana aizstāj iepriekšējo
        for i, r in enumerate(rows):
            ag = str(r.get("agency") or "")
            day = str(r.get("date") or "")[:10]
            amt = abs(float(r.get("amount") or 0))
            if not ag or len(day) != 10 or not amt:
                continue
            cur = (r.get("currency") or db.AGENCIES.get(ag, {}).get("currency") or "USD").upper()
            rep = str(r.get("replaces") or "")[:10]
            if rep:
                c.execute("""DELETE FROM payouts WHERE agency=? AND ref NOT LIKE 'hist%'
                             AND ABS(julianday(paid_at)-julianday(?))<=6""", (ag, rep))
                ref = f"hist-fix:{rep}"
            else:
                ref = f"hist:{i}"
            usd = payouts.to_usd(c, ag, amt, cur, day)
            eur = amt if cur == "EUR" else payouts.usd_to_eur(usd, day)
            c.execute("INSERT OR REPLACE INTO payouts VALUES(?,?,?,?,?,?,?,?)",
                      (ag, day, amt, cur, usd, eur, ("vēsturisks: " + str(r.get("note") or ""))[:40], ref))
            n += 1
        c.commit()
    p.rename(p.with_name(FILE.replace(".json", ".ielasits.json")))
    print(f"vēsturiskās izmaksas: ielasītas {n} rindas no {FILE}", flush=True)
    return n
