/* Pond5: www.pond5.com — pēdējās pārdošanas (JSON ar X-Access-Token no lapas) un atlikums */
async function collect() {
  if (!/(^|\.)pond5\.com$/.test(location.hostname)) throw LOGIN;
  for (let i = 0; i < 50 && !window.token_header; i++) await sleep(200);
  if (!window.token_header) throw LOGIN;
  const H = Object.assign({}, window.token_header);
  const sales = await getj("/ajax/dashboard/sales", H);
  const items = (sales && sales.items) || [];
  const rows = items.map((x) => ({
    day: String(x.createdAt || "").slice(0, 10), ts: String(x.createdAt || "").replace(" ", "T").slice(0, 19),
    id: String(x.itemId || ""), title: x.isOneOff ? (x.oneOffTitle || "Additional revenue") + " " + (x.name || "") : x.name,
    thumb: x.isOneOff ? "" : x.previewUrl, url: x.link, amount: +x.amount || 0, cnt: x.isOneOff ? 0 : 1,
    kind: x.isOneOff ? "other" : "sale" })).filter((r) => r.day);
  const start = rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today;
  await sendRows(rows, { start, end: today });
  try {
    const b = await getj("/ajax/user/balance", H);
    const t = ((b && b.info) || []).find((x) => x.id === "total");
    if (t) await send("balance", { amount: +t.amount || 0, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  /* izmaksas: automātiskas ~15. datumā; financials/<gads>/<mēn> → lastPayoutDate/Amount, accountBalance */
  await payoutsSafe(async () => {
    const ty = +today.slice(0, 4), tm = +today.slice(5, 7);
    const pfull = !!OPTS.payouts_full;
    const from = pfull ? new Date(2018, 0, 1) : new Date(ty, tm - 1 - 3, 1);
    /* financials katrā mēnesī rāda to pašu "pēdējo izmaksu" (2026-10-29: cikls līdz 2012 deva 1 izmaksu, 1 min) —
       tāpēc tikai pēdējie mēneši; vēsture krājas pamazām. Pilnai vēsturei jāatrod cits avots. */
    const months = monthsBack(from.getFullYear(), from.getMonth() + 1, ty, tm);
    const seen = new Map();
    let empty = 0, first = true;
    for (const [y, m] of months) {
      let j;
      try { j = await getj(`/ajax/user-account/financials/${y}/${pad(m)}`, H); } catch (e) { if (e && e.login) throw e; break; }
      const sm = (j && j.financials && j.financials.summary) || {};
      if (first) { first = false; if (sm.accountBalance != null) await sendPayInfo({ unpaid: +sm.accountBalance || 0, currency: "USD" }); }
      const d = pdate(sm.lastPayoutDate || "");
      if (d && sm.lastPayoutAmount) seen.set(d, Math.abs(+sm.lastPayoutAmount));
      /* test44: mēneša "Total Payout Activity" (lietotājs 2026-10-30) — izmaksa šajā mēnesī (~15. datumā) */
      let act = null;
      for (const k in sm) if (/payout/i.test(k) && !/last|date/i.test(k) && !isNaN(parseFloat(sm[k])) && Math.abs(parseFloat(sm[k])) > 0.004) { act = Math.abs(parseFloat(sm[k])); break; }
      if (y === ty && m === tm && !OPTS.__p5keys) { OPTS.__p5keys = 1; B.log(AG, "izmaksas: financials summary atslēgas: " + keysOf(sm)); }
      /* 2026-11-08 (pārbaudīts ar PayPal): summary.totalPayout < 0 = izmaksa (accountEarnings datums), > 0 = ienākums
         (abonements u.c., NAV izmaksa). Visa vēsture: 10 izmaksas 2020-12…2025-12 sakrīt ar PayPal. */
      void act;
      if (+sm.totalPayout < 0) {
        const ae = ((j.financials.accountEarnings || []).find((a) => +a.profit < 0) || {});
        const dd = pdate(ae.createdAt || "") || `${y}-${pad(m)}-15`;
        seen.set(dd, Math.abs(+sm.totalPayout));
      }
      if (!(j && j.financials && ((j.financials.clipSales || []).length || sm.totalEarnings))) { if (!pfull && ++empty >= 18) break; } else empty = 0;
      await sleep(200);
    }
    /* pilnai vēsturei — izpēte (žurnālā atslēgas): citi iespējamie avoti */
    if (OPTS.payouts_full || seen.size < 2) {
      for (const u of ["/ajax/user-account/payouts", "/ajax/user/payouts", "/ajax/user-account/payout-history"]) {
        try { const j = await getj(u, H); B.log(AG, `izmaksas: ${u} atslēgas: ${keysOf(j)}`); }
        catch (e) { if (e && e.login) { B.log(AG, `izmaksas: ${u} — nav`); continue; } B.log(AG, `izmaksas: ${u} — ${((e && e.message) || e).toString().slice(0, 80)}`); }
      }
    }
    const rows = [...seen].map(([date, amount]) => ({ date, amount, currency: "USD" })).sort((a, b) => (a.date < b.date ? 1 : -1));
    /* aizstāj no vecākās redzētās izmaksas (pēdējās zināmās) — tā izzūd agrāk kļūdaini ierakstītās "izmaksas" */
    const st = rows.length ? rows[rows.length - 1].date : null;
    await sendPayouts(rows, pfull && rows.length > 1 ? { full: true } : (st ? { full: false, start: st } : { full: false }));
  });
  if (OPTS.sub_due) { try { await p5Status(); } catch (e) { if (e && e.login) throw e; B.log(AG, "statusi: " + String((e && e.message) || e).slice(0, 120)); } }
  await portfolioSafe([
    ["storefront (Photos+Illustrations+Videos)", async () => {
      /* paša autora veikals pond5.com/artist/<vārds> — vārdu ņemam no lapas saites, kodā to nerakstām */
      const RE = /(\d[\d,]*)\s+(?:Photos|Illustrations|Videos|Music|Sound Effects|3D Models|After Effects)\b/i;
      let u = hrefOf(document, /storefront|my profile|view profile|portfolio/i, /\/artist\//) || hrefOf(document, /./, /\/artist\//);
      if (!u) { const d = await getdoc("/my-recent-sales"); u = hrefOf(d, /storefront|my profile|portfolio/i, /\/artist\//) || hrefOf(d, /./, /\/artist\//); }
      if (!u) { B.log(AG, "portfelis: veikala (artist) saite nav atrasta"); return null; }
      return sumAll(txt((await getdoc(u)).body), RE) || framed(u, (t) => sumAll(t, RE));
    }],
    ["dashboard", async () => countKey(sales, /^(approved|accepted|online|active|live|published)(_?(files|images|items|content|assets|count|total))*$|^(total_?)?(approved|online|portfolio|files|images|assets|content|resources)_?(count|total|size)$|^portfolio(_?size)?$/i)],
    ["user/portfolio", () => portJson("/ajax/user/portfolio", H)],
    ["dashboard/stats", () => portJson("/ajax/dashboard/stats", H)],
  ]);
  return { rows: rows.length };
}

/* Iesniegumu statusi (lietotāja ekrānuzņēmumi 2026-11-06): /index.php?page=my_uploads — filtrs STATUS (Processing, Needs Edits,
   Pending, Online, Rejected, Returned), TYPE (Photo), MAX PER PAGE 100; tabula ID | TITLE | DESCRIPTION | … | STATUS
   ("PENDING REVIEW", "ONLINE", "REJECTED", "RETURNED"). Faila nosaukuma sarakstā nav — sasaiste pēc virsraksta.
   Online — tikai 1. lapa (jaunākās). Filtru maina rāmī (izvēlne + Search), jo adrese nemainās. */
async function p5Status() {
  const WANT = [["Needs Edits", 1], ["Pending", 2], ["Processing", 1], ["Rejected", 2], ["Returned", 3], ["Online", 1]];
  const all = new Map();
  let note = "";
  const parse = (doc, raw) => {
    let n = 0;
    for (const tr of doc.querySelectorAll("tr")) {
      const cells = [...tr.cells].map((c) => (c.innerText || "").replace(/\s+/g, " ").trim());
      const id = cells.find((c) => /^\d{8,10}$/.test(c));
      if (!id || all.has(id)) continue;
      const st = (cells.find((c) => /^(PENDING REVIEW|ONLINE|REJECTED|RETURNED|PROCESSING|NEEDS EDITS|PENDING)$/i.test(c)) || raw);
      const ti = cells[cells.indexOf(id) + 1] || "";
      all.set(id, { id, file: "", title: ti.replace(/\.\.$/, "").slice(0, 250), submitted: "", status: st.replace(/^RETURNED$/i, "Returned (jālabo)") }); n++;
    }
    return n;
  };
  /* 2026-11-06 (lietotājs): cilnē TECH DATA — ID | ORIGINAL FILENAME | FILE SIZE | … | DATE UPLOADED */
  const parseTech = (doc) => {
    let n = 0;
    for (const tr of doc.querySelectorAll("tr")) {
      const cells = [...tr.cells].map((c) => (c.innerText || "").replace(/\s+/g, " ").trim());
      const id = cells.find((c) => /^\d{8,10}$/.test(c)); if (!id || !all.has(id)) continue;
      const fn = cells.find((c) => /\.(jpe?g|tiff?|png|eps|mp4|mov)$/i.test(c));
      const du = cells.find((c) => /^\d{1,2} [A-Za-z]{3} \d{4}$/.test(c));
      const r = all.get(id);
      if (fn) { r.file = fn; n++; }
      if (du) r.submitted = pdate(du) || r.submitted;
    }
    return n;
  };
  const tab = async (doc, re) => {
    const t = [...doc.querySelectorAll("a, button, li, span, div")].filter((e) => re.test((e.innerText || "").trim()) && (e.innerText || "").trim().length < 20).pop();
    if (!t) return false;
    const b = (doc.body.innerText || "").length; t.click();
    for (let i = 0; i < 12; i++) { await sleep(400); if ((doc.body.innerText || "").length !== b) break; }
    await sleep(500); return true;
  };
  let techN = 0;
  await framed("/index.php?page=my_uploads", (t) => (/STATUS/i.test(t) && /Search/i.test(t) ? true : null), 30000, async ({ win }) => {
    /* 2026-11-06 (žurnāls): "Search" pārlādē lapu rāmī — dokumentu ņemam no jauna katru reizi */
    let doc = win.document;
    const fresh = async (before) => { for (let i = 0; i < 40; i++) { await sleep(500); try { const d = win.document; if (d && d.body && d.readyState === "complete" && (d !== before || (d.body.innerText || "").length !== beforeLen)) { doc = d; return; } } catch (_) { /* */ } } doc = win.document; };
    let beforeLen = 0;
    const sels = [...doc.querySelectorAll("select")];
    let stSel = sels.find((s) => [...s.options].some((o) => /^\s*Returned\s*$/i.test(o.text)));
    let tySel = sels.find((s) => [...s.options].some((o) => /^\s*Photo\s*$/i.test(o.text)));
    let ppSel = sels.find((s) => [...s.options].some((o) => /^\s*100\s*$/.test(o.text)));
    const set = (sel, re) => { if (!sel) return; const o = [...sel.options].find((x) => re.test(x.text.trim())); if (o) { sel.value = o.value; sel.dispatchEvent(new Event("change", { bubbles: true })); } };
    if (!stSel) { note = "statusa izvēlne nav atrasta; izvēlnes: " + sels.map((s) => [...s.options].slice(0, 4).map((o) => o.text.trim()).join("/")).join(" | ").slice(0, 200); return true; }
    for (const [label, maxP] of WANT) {
      set(stSel, new RegExp("^" + label + "$", "i")); set(tySel, /^Photo$/i); set(ppSel, /^100$/);
      const btn = [...doc.querySelectorAll("button, input[type=submit], a")].find((b) => /^\s*Search\s*$/i.test(b.innerText || b.value || ""));
      const bd = doc; beforeLen = (doc.body.innerText || "").length;
      if (btn) btn.click(); else (stSel.form && stSel.form.submit());
      await fresh(bd); await sleep(800);
      const S2 = [...doc.querySelectorAll("select")];
      stSel = S2.find((x) => [...x.options].some((o) => /^\s*Returned\s*$/i.test(o.text))) || stSel;
      tySel = S2.find((x) => [...x.options].some((o) => /^\s*Photo\s*$/i.test(o.text))) || tySel;
      ppSel = S2.find((x) => [...x.options].some((o) => /^\s*100\s*$/.test(o.text))) || ppSel;
      await tab(doc, /^CLIP DETAILS$/i); await sleep(300); doc = win.document;
      let got = parse(doc, label);
      B.log(AG, `statusi: ${label} — ${got} rindas; izvēlne: ${stSel ? stSel.options[stSel.selectedIndex].text.trim() : "?"}; tabulas rindas ${doc.querySelectorAll("tr").length}`);
      const techNow = async () => { if (await tab(doc, /^TECH DATA$/i)) { await sleep(300); doc = win.document; techN += parseTech(doc); await tab(doc, /^CLIP DETAILS$/i); await sleep(300); doc = win.document; } };
      if (got) await techNow();
      for (let p = 2; p <= maxP && got; p++) {
        const nx = [...doc.querySelectorAll("a, button")].find((e) => /^\s*Next\s*>?\s*$/i.test(e.innerText || ""));
        if (!nx) break;
        const bd2 = doc; beforeLen = (doc.body.innerText || "").length; nx.click();
        await fresh(bd2);
        await sleep(600); got = parse(doc, label);
        if (got) await techNow();
      }
    }
    return true;
  }, true);
  const rows = [...all.values()], cnt = {};
  for (const r of rows) cnt[r.status] = (cnt[r.status] || 0) + 1;
  B.log(AG, `statusi: ${rows.length} bildes ${JSON.stringify(cnt)}; faila nosaukumi (TECH DATA): ${techN}` + (note ? "; " + note : ""));
  if (rows.length) await send("sub_items", { rows, part: 1, parts: 1 });
  await send("sub_done", { full: false });
}
