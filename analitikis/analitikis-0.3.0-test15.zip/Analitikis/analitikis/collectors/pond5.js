/* Pond5: www.pond5.com — pēdējās pārdošanas (JSON ar X-Access-Token no lapas) un atlikums */
async function collect() {
  if (!/(^|\.)pond5\.com$/.test(location.hostname)) throw LOGIN;
  for (let i = 0; i < 50 && !window.token_header; i++) await sleep(200);
  if (!window.token_header) throw LOGIN;
  const H = Object.assign({}, window.token_header);
  const sales = await getj("/ajax/dashboard/sales", H);
  const items = (sales && sales.items) || [];
  const rows = items.map((x) => ({
    day: String(x.createdAt || "").slice(0, 10), ts: String(x.createdAt || "").replace(" ", "T").slice(0, 19),
    id: String(x.itemId || ""), title: x.isOneOff ? (x.oneOffTitle || "Additional revenue") + " " + (x.name || "") : x.name,
    thumb: x.isOneOff ? "" : x.previewUrl, url: x.link, amount: +x.amount || 0, cnt: x.isOneOff ? 0 : 1,
    kind: x.isOneOff ? "other" : "sale" })).filter((r) => r.day);
  const start = rows.length ? rows.reduce((m, r) => (r.day < m ? r.day : m), today) : today;
  await sendRows(rows, { start, end: today });
  try {
    const b = await getj("/ajax/user/balance", H);
    const t = ((b && b.info) || []).find((x) => x.id === "total");
    if (t) await send("balance", { amount: +t.amount || 0, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  return { rows: rows.length };
}
