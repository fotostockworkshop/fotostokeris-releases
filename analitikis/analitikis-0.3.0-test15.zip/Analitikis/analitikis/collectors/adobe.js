/* Adobe Stock Contributor: contributor.stock.adobe.com */
async function collect() {
  if (!/(^|\.)contributor\.stock\.adobe\.com$/.test(location.hostname)) throw LOGIN;
  const lang = (location.pathname.match(/^\/([a-z]{2}(?:[-_][A-Za-z]{2})?)\//) || [])[1] || "en";
  const H = { "X-Requested-With": "XMLHttpRequest" };
  const ov = await getj(`/${lang}/user/statistics/overview?time_range=year`, H);
  if (!ov || !ov.sales) throw LOGIN;

  const year = +today.slice(0, 4);
  let ranges = [];
  if (OPTS.mode === "full") {
    for (let y = year; y >= 2005; y--) ranges.push([`${y}-01-01`, y === year ? today : `${y}-12-31`, y]);
  } else {
    ranges.push([OPTS.since, today, null]);
  }
  let total = 0, empty = 0, found = false, balance = null;
  for (let i = 0; i < ranges.length; i++) {
    const [s, e, y] = ranges[i];
    let page = 1, pages = 1, n = 0;
    do {
      say(`${y || s} · ${page}/${pages}`, OPTS.mode === "full" ? Math.min(90, i * 8) : 30);
      const j = await getj(`/${lang}/insights/sales-earnings?start_date=${s}&end_date=${e}&page=${page}`, H);
      const pg = (j.view && j.view.pagination) || {};
      pages = Math.max(1, pg.pages || 1);
      const rows = (j.sales && j.sales.history) || [];
      if (j.sales && j.sales.earnings && j.sales.earnings.available) balance = j.sales.earnings.available;
      n += rows.length;
      await send("sales", { start: s, end: e, page, pages, rows, last: page >= pages });
      page++;
    } while (page <= pages);
    total += n;
    if (OPTS.mode === "full") {
      if (n) { found = true; empty = 0; } else empty++;
      if ((found && empty >= 2) || (!found && empty >= 4)) break;
    }
  }
  if (balance) await send("balance", { amount: balance.amount, currency: balance.currencyCode || "USD" });

  say("Other payments", 95);
  let rows = [], page = 1, pages = 1;
  do {
    const j = await getj(`/${lang}/insights/other-payments?start_date=2005-01-01&end_date=${today}&page=${page}`, H);
    rows = rows.concat((j.insights && j.insights.creditTransactions) || []);
    pages = Math.max(1, ((j.view && j.view.pagination) || {}).pages || 1);
    page++;
  } while (page <= pages && page < 50);
  await send("other", { rows });
  return { sales: total, other: rows.length };
}
