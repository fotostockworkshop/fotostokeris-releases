/* Pixta: www.pixtastock.com/mypage/earning — pārdošanas pa gadiem un pārdošanas veidiem */
async function collect() {
  if (!/(^|\.)pixtastock\.com$/.test(location.hostname)) throw LOGIN;
  const doc = await getdoc("/mypage/earning");
  const ysel = doc.querySelector('select[name="year"]');
  if (!ysel) {
    if (doc.querySelector('input[type="password"]') || /login/i.test(doc.__url)) throw LOGIN;
    throw new Error("Pixta: ienākumu lapa nav atrasta");
  }
  const bm = txt(doc.body).match(/Account Balance\s*:\s*([\d.,]+)/i);
  if (bm) await send("balance", { amount: money(bm[1]), currency: "USD" });

  /* pārdošanas veidi (earned_from) no saitēm "Sales: All / Single Purchase / Subscription / Other" */
  const srcs = new Set();
  for (const a of doc.querySelectorAll('a[href*="earned_from="]')) {
    const m = (a.getAttribute("href") || "").match(/earned_from=([^&]+)/);
    if (m) srcs.add(decodeURIComponent(m[1]));
  }
  let sources = srcs.has("all") ? ["all"] : [...srcs];
  if (!sources.length) sources = ["pixta", "subscription", "other"];

  function parse(d) {
    const out = [];
    for (const tr of d.querySelectorAll("table tr")) {
      const v = [...tr.cells].map((c) => txt(c));
      if (v.length < 4) continue;
      const day = v.map(pdate).find(Boolean);
      const id = v.find((x) => /^\d{6,}$/.test(x));
      if (!day || !id) continue;
      const img = tr.querySelector("img");
      out.push({ day, ts: (v.find((x) => /\d{1,2}\/\d{1,2}\/\d{4}/.test(x)) || ""), id, amount: money(v[v.length - 1]), cnt: 1, kind: "sale",
        thumb: img ? img.getAttribute("src") : "", url: `https://www.pixtastock.com/photo/${id}` });
    }
    return out;
  }

  const years = [...ysel.options].map((o) => o.value).filter((v) => /^\d{4}$/.test(v)).sort().reverse();
  const minY = OPTS.mode === "full" ? "0000" : OPTS.since.slice(0, 4);
  let total = 0, found = false, empty = 0;
  for (let i = 0; i < years.length; i++) {
    const y = years[i];
    if (y < minY) break;
    let yearRows = 0;
    for (const src of sources) {
      say(`${y} · ${src}`, Math.min(95, Math.round((i / years.length) * 95)));
      const rows = [];
      let prev = "";
      for (let page = 1; page < 50; page++) {
        const u = `/mypage/earning?content_type=0%2C1&earned_from=${encodeURIComponent(src)}&year=${y}&month=&per_page=200` +
          (page > 1 ? `&page=${page}` : "");
        const r = parse(await getdoc(u)).filter((x) => x.day.startsWith(y));
        const s = r.slice(0, 2).map((x) => x.id + x.ts).join();
        if (!r.length || s === prev) break;
        prev = s;
        rows.push(...r);
        if (r.length < 200) break;
        await sleep(250);
      }
      yearRows += rows.length;
      await sendRows(rows, { batch: `pixta-${src}-${y}` });
    }
    total += yearRows;
    if (yearRows) { found = true; empty = 0; } else if (++empty >= (found ? 2 : 4)) break;
  }
  return { rows: total, sources };
}
