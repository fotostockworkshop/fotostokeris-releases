/* 123RF: www.123rf.com/apicore-contributors — dienu ienākumi pa kategorijām + mēneša CSV ar katru lejupielādi */
async function collect() {
  if (!/(^|\.)123rf\.com$/.test(location.hostname)) throw LOGIN;
  const A = (u) => getj("/apicore-contributors/" + u);
  const sum = await A("earnings");
  if (!sum || !sum.data) throw LOGIN;

  /* mēneši ar ienākumiem */
  say("mēneši", 3);
  const months = new Map();
  const addYears = (j) => {
    for (const y of (j && j.data) || [])
      for (const m of y.data_per_month || []) if (money(m.total_earnings) > 0) months.set(m.simple_date, money(m.total_earnings));
  };
  try { addYears(await A("earnings/report/monthly")); } catch (e) { if (e && e.login) throw e; }
  const ty = +today.slice(0, 4);
  for (let y = ty; y >= 2010; y--) {
    try { addYears(await A(`earnings/report/monthly?year=${y}`)); } catch (e) { if (e && e.login) throw e; }
    if (y < ty - 1 && ![...months.keys()].some((k) => +k.slice(0, 4) <= y + 1)) break;    // agrāk nav nekā
  }
  let list = [...months.keys()].sort().reverse();
  const cur = today.slice(0, 7);
  if (!list.includes(cur)) list.unshift(cur);
  if (OPTS.mode !== "full") list = list.filter((m) => m >= OPTS.since.slice(0, 7));

  const CATS = ["credits", "subscription", "download_packs", "ai_ml_deals", "others"];
  let total = 0;
  for (let i = 0; i < list.length; i++) {
    const m = list[i], y = +m.slice(0, 4), mo = +m.slice(5, 7);
    say(m, 5 + Math.round((i / list.length) * 90));
    const d = await A(`earnings/report/daily?date=${m}`);
    const days = [];
    for (const r of ((d && d.data) || {}).daily_datas || []) {
      const day = pdate(r.simple_date);
      if (!day) continue;
      for (const c of CATS) if (money(r[c])) days.push({ day, cat: c, e: money(r[c]), n: 0 });
    }
    /* katra lejupielāde (ar oriģinālo faila nosaukumu) */
    const rows = [];
    try {
      const csv = await fetch(`/apicore-contributors/earnings/report/daily?file_type=csv&is_download=1&date=${m}`,
        { credentials: "include" }).then((r) => r.text());
      const lines = csv.split(/\r?\n/);
      const hi = lines.findIndex((l) => /^Date,ImageID/i.test(l));
      if (hi >= 0) {
        const head = lines[hi].split(",");
        const ix = (n) => head.indexOf(n);
        const cnt = {};
        for (const l of lines.slice(hi + 1)) {
          if (!l.trim()) continue;
          const v = l.split(",");
          const day = pdate(v[ix("Date")]);
          if (!day) continue;
          const id = v[ix("ImageID")], fn = v[ix("Filename")] || "";
          const mm = fn.match(/^(.*?)(\d{4})(\d+)$/);
          rows.push({ day, id, filename: v[ix("OriginalFilename")] || "", license: v[ix("License")] || "", amount: money(v[ix("Earnings")]),
            cnt: 1, kind: "sale", url: `https://www.123rf.com/photo_${id}.html`,
            thumb: mm ? `https://us.123rf.com/450wm/${mm[1]}/${mm[1]}${mm[2]}/${fn}/${fn}.jpg` : "" });
          cnt[day] = (cnt[day] || 0) + 1;
        }
        for (const day in cnt) days.push({ day, cat: "downloads", e: 0, n: cnt[day] });
      }
    } catch (e) { console.log("123rf csv", m, e); }
    await send("days", { start: `${m}-01`, end: monthEnd(y, mo), days });
    await sendRows(rows, { batch: "123rf-" + m, derive: false });
    total += rows.length;
    await sleep(200);
  }
  /* atlikums (ja portāls to dod) */
  try {
    const b = await getj("/apicore/members/balance");
    let val = null;
    (function walk(o) { if (!o || typeof o !== "object" || val != null) return;
      for (const k in o) { if (/balance/i.test(k) && !isNaN(parseFloat(o[k]))) { val = parseFloat(o[k]); return; } walk(o[k]); } })(b);
    if (val != null) await send("balance", { amount: val, currency: "USD" });
  } catch (e) { if (e && e.login) throw e; }
  return { months: list.length, rows: total };
}
