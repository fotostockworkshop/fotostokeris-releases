/* Analītiķis — automātiska ielogošanās (aizpilda lietotājvārdu un paroli no datora drošās glabātuves).
   Python (sync.py: Runner.autofill) aizstāj __CR__ ar {u, p, hosts} un izpilda šo izteiksmi lapā.
   Atgriež: "pass" (parole ievadīta un nosūtīta), "user" (tikai 1. solis — e-pasts), "filled" (aizpildīts,
   bet lapā ir pārbaude "vai esi cilvēks" — to dara lietotājs), "none" (formas nav), "host" (sveša lapa).
   Nekad neko neraksta žurnālā un nesūta citur. */
(function (cr) {
  var host = location.hostname;
  if (!cr.hosts.some(function (h) { return host === h || host.slice(-h.length - 1) === "." + h; })) return "host";
  function vis(el) {
    if (!el || el.disabled || el.readOnly) return false;
    var r = el.getBoundingClientRect(), st = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && st.visibility !== "hidden" && st.display !== "none";
  }
  function setv(el, v) {
    try { el.focus(); } catch (e) { /* */ }
    var d = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
    d.set.call(el, v);                                   // React/Vue lauki "redz" tikai šādu vērtību
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  var all = [].slice.call(document.querySelectorAll("input")).filter(vis);
  var pw = all.filter(function (i) { return i.type === "password"; })[0];
  var USER = "input[type=email],input[autocomplete~=username],input[autocomplete~=email],input[name*=user i]," +
    "input[name*=email i],input[name*=login i],input[id*=user i],input[id*=email i],input[id*=login i]";
  var skip = { password: 1, hidden: 1, checkbox: 1, radio: 1, submit: 1, button: 1, search: 1 };
  var u = all.filter(function (i) { return !skip[i.type] && i.matches(USER); })[0];
  if (!u && pw) {                                        // teksta lauks pirms paroles tajā pašā formā
    var scope = pw.form || pw.closest("div,section,main") || document;
    u = [].slice.call(scope.querySelectorAll("input")).filter(function (i) { return vis(i) && !skip[i.type]; })[0];
  }
  if (!pw && !u) return "none";
  if (u && cr.u && u.value !== cr.u) setv(u, cr.u);
  if (pw) setv(pw, cr.p);
  /* Tikai pārbaude, kas jāizpilda cilvēkam (ķeksis "I'm not a robot", hCaptcha, "Press & Hold").
     Neredzamā reCAPTCHA (v3 / size=invisible, stūra zīmīte .grecaptcha-badge) netraucē — pogu spiežam. */
  var captcha = [].slice.call(document.querySelectorAll("iframe[src*='recaptcha/api2/anchor'],iframe[src*='recaptcha/enterprise/anchor'],iframe[src*=hcaptcha],#px-captcha"))
    .some(function (el) { return vis(el) && !/size=invisible/.test(el.src || "") && !el.closest(".grecaptcha-badge"); });
  if (captcha || cr.submit === false) return "filled";
  var field = pw || u;
  var box = field.form || field.closest("form,[role=dialog],section,main") || document;
  var btns = [].slice.call(box.querySelectorAll("button,input[type=submit],[role=button]")).filter(vis);
  var TXT = /sign ?in|log ?in|continue|next|submit|weiter|ielogo|turpin|ログイン|次へ/i;
  var b = btns.filter(function (x) { return x.type === "submit"; })[0] ||
    btns.filter(function (x) { return TXT.test((x.innerText || x.value || x.getAttribute("aria-label") || "").trim()); })[0];
  setTimeout(function () {
    if (b) b.click();
    else if (field.form) { if (field.form.requestSubmit) field.form.requestSubmit(); else field.form.submit(); }
    else field.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", keyCode: 13, bubbles: true }));
  }, 500);
  return pw ? "pass" : "user";
})(__CR__)
