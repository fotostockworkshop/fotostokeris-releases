"""Analītiķa iestatījumi un datu mape — no kopīgā koda core/ (noteikumi §5, §10)."""
from __future__ import annotations

from . import appdef  # noqa: F401  — reģistrē Analītiķi core/ pirms core.config lietošanas
from core.config import (IS_MAC, IS_WIN, JsonStore, app_dir, defaults, get, settings,  # noqa: F401
                         setup_log, update)
