"""Servera ziņojumu tulkojumi (saskarnes teksti ir web/i18n.js)."""
from __future__ import annotations

MSG = {
    "none": {"lv": "Nav pieslēgtu aģentūru. Pieslēdz vismaz vienu cilnē “Aģentūras”.",
             "en": "No agencies connected. Connect at least one on the “Agencies” tab."},
    "busy": {"lv": "Atjaunošana jau notiek.", "en": "A refresh is already running."},
    "no_webview": {"lv": "Datu savākšanai vajag bibliotēku pywebview. Cilnē “Aģentūras” spied “Uzstādīt”.",
                   "en": "Collecting data needs the pywebview library. Click “Install” on the “Agencies” tab."},
    "installing_webview": {"lv": "Uzstādu pywebview… (var aizņemt pāris minūtes)", "en": "Installing pywebview… (may take a few minutes)"},
    "webview_ok": {"lv": "pywebview uzstādīts. Var pieslēgt aģentūras.", "en": "pywebview installed. You can connect agencies."},
    }



def T(key: str, **kw) -> str:
    from core.i18n import T as _T
    return _T(key, **kw)
