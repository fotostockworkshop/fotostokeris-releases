"""Analītiķa apraksts kopīgajam kodam core/ (noteikumi §10, §12)."""
from __future__ import annotations

from pathlib import Path

from core import app as core_app

from . import APP_NAME, VERSION
from .i18n import MSG

ROOT = Path(__file__).resolve().parent.parent

DEFAULTS = {
    "sales_agencies": [],               # pieslēgtās aģentūras (§4 identifikatori)
    "sales_autosync_hours": 6,          # atverot programmu, atjaunot, ja dati vecāki (0 = nekad)
    "sales_webview_main": False,        # Windows: galvenais logs pywebview (nevis Edge/Chrome)
    "sales_parallel": 2,                # cik aģentūras atjaunot vienlaikus (pārējās gaida rindā)
}


def _validate(vals: dict) -> dict:
    if "sales_autosync_hours" in vals:
        try:
            vals["sales_autosync_hours"] = max(0, int(vals["sales_autosync_hours"]))
        except (TypeError, ValueError):
            vals.pop("sales_autosync_hours")
    if "sales_parallel" in vals:
        try:
            vals["sales_parallel"] = max(1, min(4, int(vals["sales_parallel"])))
        except (TypeError, ValueError):
            vals.pop("sales_parallel")
    return vals


def _busy() -> bool:
    from . import sync
    return sync.active()


def _webview_main() -> bool:
    from core import config
    return bool(config.get("sales_webview_main"))


APP = core_app.init(core_app.App(
    name=APP_NAME, slug="Analitikis", version=VERSION, ports=(47625, 47626, 47627), api_prefix="sales_",
    web_dir=ROOT / "web", defaults=DEFAULTS, msgs=MSG, busy=_busy, webview_main=_webview_main,
    validate_settings=_validate, icon=ROOT / "assets" / "icon.png"))
