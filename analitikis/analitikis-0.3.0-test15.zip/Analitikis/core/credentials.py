"""Pieslēgšanās dati (aģentūru lietotājvārdi un paroles) — tikai operētājsistēmas drošajā glabātuvē
(Windows Credential Manager / macOS Keychain) caur bibliotēku `keyring` (noteikumi §3, lēmums 2026-10-28).

  servisa nosaukums: SUITE_NAME ("Fotostokeris")
  ieraksta nosaukums: "<aģentūras id>" vai "<aģentūras id>:ftp"
  vērtība: JSON {"u": lietotājvārds, "p": parole}

Nekad: catalog.db, settings.json, žurnālā, OneDrive/NAS, repozitorijā. Saskarnei paroli neatgriež —
tikai to, vai tā ir saglabāta. Ja `keyring` nav pieejams, viss strādā kā agrāk (lietotājs ielogojas pats).
"""
from __future__ import annotations

import json
import re

from . import SUITE_NAME

_NAME = re.compile(r"^[a-z0-9_]+(:[a-z0-9_]+)?$")


def _kr():
    try:
        import keyring  # noqa: WPS433
        from keyring.backends import fail
    except Exception:
        return None
    try:
        if isinstance(keyring.get_keyring(), fail.Keyring):
            return None
    except Exception:
        return None
    return keyring


def available() -> bool:
    return _kr() is not None


def backend_name() -> str:
    kr = _kr()
    if not kr:
        return ""
    try:
        return type(kr.get_keyring()).__name__
    except Exception:
        return ""


def _check(name: str) -> str:
    name = (name or "").strip().lower()
    if not _NAME.match(name):
        raise ValueError("bad credential name")
    return name


def get(name: str) -> tuple[str, str] | None:
    """(lietotājvārds, parole) vai None. Tikai programmas iekšienei (aģentūras logā aizpildei)."""
    kr = _kr()
    if not kr:
        return None
    try:
        v = kr.get_password(SUITE_NAME, _check(name))
    except Exception:
        return None
    if not v:
        return None
    try:
        d = json.loads(v)
        return str(d.get("u") or ""), str(d.get("p") or "")
    except (TypeError, ValueError):
        return "", v


def save(name: str, user: str, password: str | None) -> None:
    """Saglabā. Ja password ir None vai tukšs — patur iepriekšējo paroli (maina tikai lietotājvārdu)."""
    kr = _kr()
    if not kr:
        raise RuntimeError("keyring")
    name = _check(name)
    if not password:
        old = get(name)
        if not old or not old[1]:
            raise ValueError("password")
        password = old[1]
    kr.set_password(SUITE_NAME, name, json.dumps({"u": (user or "").strip(), "p": password}))


def forget(name: str) -> None:
    kr = _kr()
    if not kr:
        return
    name = _check(name)
    try:
        kr.delete_password(SUITE_NAME, name)
    except Exception:
        pass


def summary(names: list[str]) -> dict:
    """Saskarnei: {name: {"user": "...", "saved": True}} — bez parolēm."""
    out = {}
    for n in names:
        c = get(n)
        if c and c[1]:
            out[n] = {"user": c[0], "saved": True}
    return out
