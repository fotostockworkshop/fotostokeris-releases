"""Fotostokeris — kopīgais kods visiem produktiem (noteikumi §10).

core/ neko nezina par moduļiem: modulis sevi apraksta ar core.app.App un reģistrē savu API.
"""
SUITE_NAME = "Fotostokeris"     # komplekta (darba) nosaukums — tikai šeit
