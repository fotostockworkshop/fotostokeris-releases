#!/bin/bash
# Fotostokera produkta uzstādīšana uz Mac kā parasta lietotne (noteikumi §3 "Palaišana").
#   bash core/mac/install_app.sh <Slug> "<Nosaukums>" <bundle id> [ikona.icns]
# Programmas mape (ar core/, web/, run_mac.command) tiek nokopēta lietotnes iekšienē:
#   /Applications/<Nosaukums>.app/Contents/Resources/app   (ja nav rakstāms — ~/Applications)
# Lietotni izveido šis dators pats, tāpēc tai nav "lejupielādēts no interneta" atzīmes un macOS to vairs
# neprasa apstiprināt. Datu mape (~/Library/Application Support/<Slug>) netiek aiztikta.
set -e
SLUG="$1"; NAME="$2"; BID="$3"; ICNS="$4"
SRC="$(cd "$(dirname "$0")/../.." && pwd)"                 # izpakotā programmas mape
[ -f "$SRC/$SLUG.py" ] || { echo "Nav atrasts $SLUG.py mapē $SRC"; exit 1; }

echo "== $NAME — uzstādīšana =="
xattr -dr com.apple.quarantine "$SRC" 2>/dev/null || true

# Python izvēle: Apple procesorā (M1…) — tāds, kas strādā bez Rosetta (python.org "universal2" vai Homebrew
# /opt/homebrew). Intel Python (piem. vecais Homebrew /usr/local) macOS drīz vairs neatbalstīs.
ARM=0; [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ] && ARM=1
native() {   # vai Python $1 ir ≥3.10 un (Apple procesorā) darbojas bez Rosetta
  local run=("$1"); [ $ARM = 1 ] && run=(arch -arm64 "$1")
  "${run[@]}" -c 'import sys,platform; sys.exit(0 if sys.version_info>=(3,10) and (platform.machine()=="arm64" or not '"$ARM"') else 1)' >/dev/null 2>&1
}
PY=""; FALLBACK=""
for c in /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
         /Library/Frameworks/Python.framework/Versions/3.1[0-9]/bin/python3 \
         /opt/homebrew/bin/python3 $(which -a python3 2>/dev/null) /usr/local/bin/python3; do
  [ -x "$c" ] || continue
  if native "$c"; then PY="$c"; break; fi
  [ -z "$FALLBACK" ] && "$c" -c 'import sys; sys.exit(0 if sys.version_info>=(3,10) else 1)' 2>/dev/null && FALLBACK="$c"
done
if [ -z "$PY" ]; then
  if [ -z "$FALLBACK" ]; then
    echo "Python 3.10+ nav atrasts. Uzstādi to no https://www.python.org/downloads/ (macOS 64-bit universal2) un palaid šo failu vēlreiz."
    exit 1
  fi
  PY="$FALLBACK"
  echo "⚠ Atrasts tikai Intel Python ($PY) — tas strādā caur Rosetta, un macOS drīz to vairs neatbalstīs."
  echo "  Ieteikums: uzstādi Python no https://www.python.org/downloads/ (macOS 64-bit universal2) un palaid šo failu vēlreiz."
fi
echo "Python: $PY"

DEST_DIR="/Applications"
[ -w "$DEST_DIR" ] || { DEST_DIR="$HOME/Applications"; mkdir -p "$DEST_DIR"; }
APP="$DEST_DIR/$NAME.app"
RES="$APP/Contents/Resources/app"

# programma jau darbojas? — aptur (tā pati darbība kā palaižot jaunu versiju)
pkill -f "$SLUG.py" 2>/dev/null || true
sleep 1

echo "Lietotne: $APP"
mkdir -p "$APP/Contents/MacOS" "$RES"
# programmas faili (vecie tiek aizstāti; .venv paliek, ja jau ir)
( cd "$SRC" && find . -mindepth 1 -maxdepth 1 ! -name .venv ! -name '*.command' -exec cp -R {} "$RES/" \; )
cp "$SRC/run_mac.command" "$RES/run_mac.command"           # vajadzīgs automātiskajai atjaunināšanai
chmod +x "$RES/run_mac.command"
[ -n "$ICNS" ] && [ -f "$SRC/$ICNS" ] && cp "$SRC/$ICNS" "$APP/Contents/Resources/AppIcon.icns"

VER=$(sed -n 's/^VERSION = "\(.*\)"/\1/p' "$RES/$(echo "$SLUG" | tr '[:upper:]' '[:lower:]')/__init__.py" 2>/dev/null | head -1)
cat > "$APP/Contents/Info.plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
  <key>CFBundleName</key><string>$NAME</string>
  <key>CFBundleDisplayName</key><string>$NAME</string>
  <key>CFBundleIdentifier</key><string>$BID</string>
  <key>CFBundleExecutable</key><string>$SLUG</string>
  <key>CFBundleIconFile</key><string>AppIcon</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>CFBundleShortVersionString</key><string>${VER:-0}</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <!-- palaidējs ir skripts: bez šī macOS to var palaist caur Rosetta (Intel), un Python to pārmanto -->
  <key>LSArchitecturePriority</key><array><string>arm64</string><string>x86_64</string></array>
  <key>LSRequiresNativeExecution</key><true/>
</dict></plist>
PLIST

# lietotnes palaidējs: tas pats, ko dara run_mac.command, tikai bez termināļa loga
cat > "$APP/Contents/MacOS/$SLUG" <<SH
#!/bin/bash
cd "\$(dirname "\$0")/../Resources/app" || exit 1
LOGDIR="\$HOME/Library/Application Support/$SLUG"
mkdir -p "\$LOGDIR"
# Python, ko izvēlējās uzstādītājs (no Finder palaistai lietotnei PATH ir īss)
PY=\$(cat .python 2>/dev/null)
[ -x "\$PY" ] || PY=\$(command -v python3)
if [ ! -x .venv/bin/python ]; then
  osascript -e 'display notification "Pirmā palaišana — sagatavoju vidi (~1 min)…" with title "$NAME"' 2>/dev/null
  "\$PY" -m venv .venv >> "\$LOGDIR/log-start.txt" 2>&1
fi
if ! cmp -s requirements.txt .venv/req.txt; then
  osascript -e 'display notification "Uzstādu jaunās bibliotēkas…" with title "$NAME"' 2>/dev/null
  .venv/bin/python -m pip install --upgrade pip >> "\$LOGDIR/log-start.txt" 2>&1
  .venv/bin/python -m pip install -r requirements.txt >> "\$LOGDIR/log-start.txt" 2>&1 && cp requirements.txt .venv/req.txt
fi
export $(echo "$SLUG" | tr '[:lower:]' '[:upper:]')_LOG=1
# Apple procesorā palaižam bez Rosetta (ja Python to atbalsta)
if [ "\$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ] && arch -arm64 .venv/bin/python -c "" 2>/dev/null; then
  exec arch -arm64 .venv/bin/python -u $SLUG.py > "\$LOGDIR/log-start.txt" 2>&1
fi
exec .venv/bin/python -u $SLUG.py > "\$LOGDIR/log-start.txt" 2>&1
SH
chmod +x "$APP/Contents/MacOS/$SLUG"

# vide un bibliotēkas — tagad (terminālī redzams), lai pirmā palaišana būtu ātra
cd "$RES"
if [ -x .venv/bin/python ] && ! native .venv/bin/python && native "$PY"; then
  echo "Esošā vide ir Intel (Rosetta) — veidoju no jauna…"
  rm -rf .venv
fi
if [ ! -x .venv/bin/python ]; then
  echo "Sagatavoju vidi (minūte)…"
  "$PY" -m venv .venv
fi
echo "$PY" > .python                                      # palaidējam, ja vidi vajadzēs veidot no jauna
if ! cmp -s requirements.txt .venv/req.txt; then
  echo "Uzstādu bibliotēkas (pywebview, keyring)…"
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  if .venv/bin/python -m pip install -r requirements.txt; then
    cp requirements.txt .venv/req.txt
  else
    echo "Bibliotēkas neizdevās uzstādīt (vai ir internets?). Programma mēģinās vēlreiz, kad to palaidīsi."
  fi
fi

xattr -dr com.apple.quarantine "$APP" 2>/dev/null || true
touch "$APP"                                              # Finder/Launchpad ikonas atjaunošanai
/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister -f "$APP" 2>/dev/null || true

echo
echo "Gatavs! $NAME ir uzstādīts: $APP"
echo "Turpmāk palaid to no Launchpad, Spotlight vai mapes Programmas (Applications)."
echo "Ieteikums: kad programma atvērta, Dock ikonai labais klikšķis → Opcijas → Paturēt Dock."
echo "Šo mapi ($SRC) tagad var izdzēst. Tavi dati un paroles paliek savā vietā."
open "$APP" 2>/dev/null || true
