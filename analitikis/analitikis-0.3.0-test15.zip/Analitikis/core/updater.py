"""Automātiska atjaunināšana no publiskā izlaidumu repozitorija (noteikumi §9a).

  manifests: https://raw.githubusercontent.com/<RELEASES_REPO>/main/<modulis>/latest.json
             {"stable": {...}, "test": {...}}, katrs {version, url, sha256, size, date, notes: {lv, en}}

Uzstāda tikai pēc lietotāja apstiprinājuma un tikai, kad nenotiek darbs: lejupielāde → SHA-256 →
iepriekšējā versija uz <datu mape>/updates/previous/ → faili pāri programmas mapei (.venv un datu mape
netiek aiztikti) → palaidējs (run_windows.bat / run_mac.command) palaiž programmu no jauna.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import ssl
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile
from pathlib import Path

from . import app as _app
from . import config

RELEASES_REPO = "fotostockworkshop/fotostokeris-releases"   # GitHub organizācija (projekta e-pasts fotostockworkshop@gmail.com)
MANIFEST_URL = "https://raw.githubusercontent.com/{repo}/main/{mod}/latest.json"
CHECK_EVERY_S = 6 * 3600
KEEP = {".venv", "__pycache__", ".git"}          # programmas mapē netiek aiztikts

state = {"status": "idle", "msg": "", "pct": 0, "last": None, "checked_at": 0.0}
_lock = threading.Lock()


# --------------------------------------------------------------------------- versijas

def parse_version(v: str) -> tuple:
    """'0.3.0' > '0.3.0-test10' > '0.3.0-test9' > '0.2.1'."""
    m = re.match(r"^\s*v?(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z]+)(\d*))?", str(v or ""))
    if not m:
        return (0, 0, 0, 0, 0)
    major, minor, patch = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if m.group(4) is None:
        return (major, minor, patch, 1, 0)            # gatavā versija — pēc visām testa versijām
    return (major, minor, patch, 0, int(m.group(5) or 0))


def is_test(v: str) -> bool:
    return parse_version(v)[3] == 0 and bool(re.search(r"-", str(v or "")))


def channel() -> str:
    ch = config.get("update_channel") or "auto"
    if ch == "auto":
        return "test" if is_test(_app.current().version) else "stable"
    return ch if ch in ("stable", "test", "off") else "stable"


# --------------------------------------------------------------------------- programmas mape

def program_dir() -> Path:
    """Mape ar palaidēju (Analitikis.py, run_windows.bat …) — web/ vecākā mape."""
    return _app.current().web_dir.resolve().parent


def can_install() -> tuple[bool, str]:
    root = program_dir()
    if not (root / "core").is_dir():
        return False, "dev"                            # izstrādes režīms (core/ ir repozitorija saknē)
    if not os.access(root, os.W_OK):
        return False, "readonly"
    return True, ""


def updates_dir() -> Path:
    d = config.app_dir() / "updates"
    d.mkdir(parents=True, exist_ok=True)
    return d


# --------------------------------------------------------------------------- tīkls

def _ssl_ctx():
    """python.org Python uz Mac nezina sistēmas sertifikātus — tad lietojam macOS /etc/ssl/cert.pem."""
    ctx = ssl.create_default_context()
    if not ctx.get_ca_certs() and os.path.exists("/etc/ssl/cert.pem"):
        ctx = ssl.create_default_context(cafile="/etc/ssl/cert.pem")
    return ctx


def _get(url: str, timeout: int = 20) -> bytes:
    a = _app.current()
    req = urllib.request.Request(url, headers={"User-Agent": f"{a.slug}/{a.version} (Fotostock Workshop)",
                                               "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=timeout, context=_ssl_ctx()) as r:
        return r.read()


def manifest_url() -> str:
    # FOTOSTOKERIS_UPDATE_MANIFEST — tikai testiem (cits manifests, piem. lokāls serveris)
    return os.environ.get("FOTOSTOKERIS_UPDATE_MANIFEST") or MANIFEST_URL.format(repo=RELEASES_REPO, mod=_app.current().slug.lower())


# --------------------------------------------------------------------------- pārbaude

def check(force: bool = False) -> dict:
    """{available, current, channel, latest: {...} | None, error}. Kešē CHECK_EVERY_S."""
    a = _app.current()
    ch = channel()
    out = {"current": a.version, "channel": ch, "available": False, "latest": None, "error": "",
           "can_install": can_install()[0]}
    if ch == "off" and not force:
        return out
    with _lock:
        if not force and state["last"] is not None and time.time() - state["checked_at"] < CHECK_EVERY_S:
            man = state["last"]
        else:
            try:
                u = manifest_url()
                man = json.loads(_get(u + ("&" if "?" in u else "?") + f"t={int(time.time())}").decode("utf-8"))
            except Exception as e:
                out["error"] = str(e)[:200]
                print("atjauninājumi:", out["error"])
                return out
            state["last"], state["checked_at"] = man, time.time()
    cands = [man.get("stable")] + ([man.get("test")] if ch == "test" else [])
    cands = [c for c in cands if isinstance(c, dict) and c.get("version") and c.get("url") and c.get("sha256")]
    if not cands:
        return out
    best = max(cands, key=lambda c: parse_version(c["version"]))
    out["latest"] = best
    out["available"] = parse_version(best["version"]) > parse_version(a.version)
    return out


# --------------------------------------------------------------------------- uzstādīšana

def _set(**kw):
    state.update(kw)


def install(info: dict | None = None) -> dict:
    """Sāk uzstādīšanu fonā. info — check() rezultāta 'latest' (ja nav — pārbauda no jauna)."""
    ok, why = can_install()
    if not ok:
        return {"ok": False, "error": why}
    if _app.current().busy():
        return {"ok": False, "error": "busy"}
    if state["status"] in ("download", "install", "restart"):
        return {"ok": True}
    if not info:
        c = check(force=True)
        if not c["available"]:
            return {"ok": False, "error": c["error"] or "no_update"}
        info = c["latest"]
    _set(status="download", msg="", pct=0)
    threading.Thread(target=_install, args=(dict(info),), daemon=True).start()
    return {"ok": True}


def _install(info: dict):
    try:
        ver = info["version"]
        up = updates_dir()
        zpath = up / f"{_app.current().slug.lower()}-{ver}.zip"
        print(f"atjauninājumi: lejupielādēju {ver}")
        data = _download(info["url"])
        if hashlib.sha256(data).hexdigest().lower() != str(info["sha256"]).lower():
            raise RuntimeError("sha256")
        zpath.write_bytes(data)
        _set(status="install", pct=100)
        tmp = up / "new"
        shutil.rmtree(tmp, ignore_errors=True)
        with zipfile.ZipFile(zpath) as z:
            for n in z.namelist():                     # drošība: nekādu ../ ceļu
                if n.startswith("/") or ".." in Path(n).parts:
                    raise RuntimeError("zip")
            z.extractall(tmp)
        launcher = _app.current().slug + ".py"
        src = next((p.parent for p in tmp.rglob(launcher)), None)
        if not src or not (src / "core").is_dir():
            raise RuntimeError("zip saturs")
        root = program_dir()
        prev = up / "previous"
        shutil.rmtree(prev, ignore_errors=True)
        _copy_tree(root, prev)                         # iepriekšējā versija (atgriešanai)
        _copy_tree(src, root)
        shutil.rmtree(tmp, ignore_errors=True)
        print(f"atjauninājumi: {ver} uzstādīta, palaižu no jauna")
        _set(status="restart", msg=ver)
        threading.Thread(target=_restart, daemon=True).start()
    except Exception as e:
        print("atjauninājumi: kļūda:", e)
        _set(status="error", msg=str(e)[:200])


def _download(url: str) -> bytes:
    a = _app.current()
    req = urllib.request.Request(url, headers={"User-Agent": f"{a.slug}/{a.version} (Fotostock Workshop)"})
    with urllib.request.urlopen(req, timeout=60, context=_ssl_ctx()) as r:
        total = int(r.headers.get("Content-Length") or 0)
        buf = bytearray()
        while True:
            chunk = r.read(65536)
            if not chunk:
                break
            buf += chunk
            if total:
                _set(pct=int(len(buf) * 100 / total))
    return bytes(buf)


def _copy_tree(src: Path, dst: Path):
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        if rel.parts and rel.parts[0] in KEEP or "__pycache__" in rel.parts:
            continue
        t = dst / rel
        if p.is_dir():
            t.mkdir(parents=True, exist_ok=True)
        else:
            t.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, t)


def _restart():
    """Palaidējs uzstāda jaunās bibliotēkas (ja mainījies requirements.txt) un palaiž programmu; jaunā instance
    aptur šo (core.server.stop_previous). Uz Windows lapa (Edge logs) paliek atvērta un pieslēdzas pati."""
    time.sleep(1.0)
    root = program_dir()
    env = dict(os.environ, FOTOSTOKERIS_RESTARTED="1")
    try:
        if config.IS_WIN:
            bat = root / "run_windows.bat"
            subprocess.Popen(["cmd", "/c", "start", "", "/min", str(bat)], cwd=str(root), env=env,
                             creationflags=0x00000008 | 0x00000200)        # DETACHED_PROCESS | NEW_PROCESS_GROUP
        elif config.IS_MAC:
            subprocess.Popen(["/bin/bash", str(root / "run_mac.command")], cwd=str(root), env=env,
                             stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                             start_new_session=True)
        else:
            subprocess.Popen([sys.executable, str(root / (_app.current().slug + ".py"))], cwd=str(root), env=env,
                             start_new_session=True)
    except Exception as e:
        print("atjauninājumi: palaišana neizdevās:", e)
        _set(status="error", msg="restart: " + str(e)[:150])
        return
    time.sleep(90)                                     # ja jaunā instance mūs neapturēja — beidzam paši
    from . import server
    server.shutdown()


def status() -> dict:
    return {"status": state["status"], "msg": state["msg"], "pct": state["pct"]}
