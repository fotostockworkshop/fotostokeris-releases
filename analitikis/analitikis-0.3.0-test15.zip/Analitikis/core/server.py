"""Lokālais HTTP serveris visiem produktiem (noteikumi §3).

  GET  /            → moduļa web/index.html ({{TOKEN}} aizstāts)
  GET  /static/…    → moduļa web/
  GET  /core/…      → core/web/ (kopīgais stils, dialogi, iestatījumu rāmis)
  POST /api/<prefikss><nosaukums>  ar galveni X-Token → JSON

Kopīgie API (ar moduļa prefiksu): ping, quit, reveal, settings. Pārējos reģistrē modulis: register({...}).
"""
from __future__ import annotations

import json
import mimetypes
import os
import secrets
import subprocess
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse

from . import app as _app
from . import config

CORE_WEB = Path(__file__).resolve().parent / "web"
TOKEN = secrets.token_urlsafe(16)
BOOT = secrets.token_hex(6)

state = {"last_ping": time.time(), "server": None, "window_proc": None}
API: dict = {}


def ok(**kw):
    kw.setdefault("ok", True)
    return kw


def register(funcs: dict):
    """Moduļa API: {"overview": fn, …} → /api/<prefikss>overview."""
    p = _app.current().api_prefix
    for name, fn in funcs.items():
        API[p + name] = fn


def base_state() -> dict:
    """Kopīgā daļa moduļa "state" atbildei."""
    a = _app.current()
    return dict(version=a.version, boot=BOOT, settings=config.settings().data, platform=sys.platform,
                app_dir=str(config.app_dir()), app=a.name)


# --------------------------------------------------------------------------- kopīgie API

def _api_ping(_):
    state["last_ping"] = time.time()
    return ok()


def _api_quit(_):
    def bye():
        time.sleep(0.3)
        shutdown()
    threading.Thread(target=bye, daemon=True).start()
    return ok()


def _api_reveal(_):
    p = str(config.app_dir())
    try:
        if config.IS_WIN:
            subprocess.Popen(["explorer", os.path.normpath(p)])
        elif config.IS_MAC:
            subprocess.Popen(["open", p])
        else:
            subprocess.Popen(["xdg-open", p])
    except Exception as e:
        return {"ok": False, "error": str(e)}
    return ok()


def _api_settings(b):
    vals = dict(b.get("settings") or {})
    if "theme" in vals and vals["theme"] not in ("auto", "light", "dark"):
        vals.pop("theme")
    if "lang" in vals and vals["lang"] not in ("lv", "en"):
        vals.pop("lang")
    if "update_channel" in vals and vals["update_channel"] not in ("auto", "stable", "test", "off"):
        vals.pop("update_channel")
    if "target_agencies" in vals and not isinstance(vals["target_agencies"], list):
        vals.pop("target_agencies")
    vals = _app.current().validate_settings(vals)
    config.update(vals)
    return ok(settings=config.settings().data)


def _api_creds(b):
    """Saglabātie pieslēgšanās dati (bez parolēm!): {name: {user, saved}}."""
    from . import credentials
    names = [str(n) for n in (b.get("names") or [])]
    return ok(available=credentials.available(), backend=credentials.backend_name(),
              creds=credentials.summary(names))


def _api_cred_save(b):
    from . import credentials
    if not credentials.available():
        return {"ok": False, "error": "keyring"}
    try:
        credentials.save(str(b.get("name") or ""), str(b.get("user") or ""), b.get("password") or None)
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return ok(creds=credentials.summary([str(b.get("name"))]))


def _api_cred_forget(b):
    from . import credentials
    credentials.forget(str(b.get("name") or ""))
    return ok()


def _api_update_check(b):
    from . import updater
    return ok(**updater.check(force=bool(b.get("force"))), state=updater.status())


def _api_update_install(b):
    from . import updater
    r = updater.install(b.get("latest") if isinstance(b.get("latest"), dict) else None)
    return r if not r.get("ok") else ok(state=updater.status())


def _api_update_status(_):
    from . import updater
    return ok(state=updater.status())


def _register_core():
    register({"ping": _api_ping, "quit": _api_quit, "reveal": _api_reveal, "settings": _api_settings,
              "creds": _api_creds, "cred_save": _api_cred_save, "cred_forget": _api_cred_forget,
              "update_check": _api_update_check, "update_install": _api_update_install,
              "update_status": _api_update_status})


# --------------------------------------------------------------------------- HTTP

class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code: int, body: bytes, ctype: str, extra: dict | None = None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        for k, v in (extra or {}).items():
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"),
                   "application/json; charset=utf-8", {"Cache-Control": "no-store"})

    def _file(self, root: Path, rel: str):
        f = (root / rel).resolve()
        if root.resolve() in f.parents and f.is_file():
            ctype = mimetypes.guess_type(str(f))[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            return self._send(200, f.read_bytes(), ctype, {"Cache-Control": "no-cache"})
        return self._send(404, b"not found", "text/plain")

    def do_GET(self):
        u = urlparse(self.path)
        web = _app.current().web_dir
        if u.path in ("/", "/index.html"):
            html = (web / "index.html").read_text(encoding="utf-8").replace("{{TOKEN}}", TOKEN) \
                .replace("{{V}}", f"{_app.current().version}-{BOOT}")   # pēc atjaunināšanas — svaigi faili
            return self._send(200, html.encode("utf-8"), "text/html; charset=utf-8", {"Cache-Control": "no-store"})
        if u.path.startswith("/static/"):
            return self._file(web, u.path[len("/static/"):])
        if u.path.startswith("/core/"):
            return self._file(CORE_WEB, u.path[len("/core/"):])
        return self._send(404, b"not found", "text/plain")

    def do_POST(self):
        u = urlparse(self.path)
        if not u.path.startswith("/api/"):
            return self._send(404, b"not found", "text/plain")
        if self.headers.get("X-Token") != TOKEN:
            return self._json({"ok": False, "error": "forbidden"}, 403)
        fn = API.get(u.path[5:])
        if not fn:
            return self._json({"ok": False, "error": "unknown api " + u.path[5:]}, 404)
        n = int(self.headers.get("Content-Length") or 0)
        try:
            body = json.loads(self.rfile.read(n) or b"{}") if n else {}
        except json.JSONDecodeError:
            return self._json({"ok": False, "error": "bad JSON"}, 400)
        state["last_ping"] = time.time()
        try:
            return self._json(fn(body))
        except Exception as e:
            traceback.print_exc()
            return self._json({"ok": False, "error": str(e)}, 200)


class Server(ThreadingHTTPServer):
    daemon_threads = True

    def handle_error(self, request, client_address):
        """Logs aizvērts / lapa pārlādēta pieprasījuma laikā — tā nav kļūda (žurnālā nerakstām)."""
        if isinstance(sys.exc_info()[1], (ConnectionResetError, BrokenPipeError, ConnectionAbortedError)):
            return
        super().handle_error(request, client_address)


def stop_previous() -> int:
    """Aptur iepriekš palaistu šī produkta instanci (arī vecāku versiju)."""
    import re as _re
    import urllib.request as _ur
    a = _app.current()
    opener = _ur.build_opener(_ur.ProxyHandler({}))
    stopped = 0
    for port in a.ports:
        base = f"http://127.0.0.1:{port}/"
        try:
            html = opener.open(base, timeout=1.5).read().decode("utf-8", "replace")
        except Exception:
            continue
        if a.name not in html and a.slug not in html:
            continue
        m = _re.search(r'window\.TOKEN\s*=\s*"([^"]+)"', html)
        if not m:
            continue
        try:
            req = _ur.Request(base + "api/" + a.api_prefix + "quit", data=b"{}", method="POST",
                              headers={"X-Token": m.group(1), "Content-Type": "application/json"})
            opener.open(req, timeout=3).read()
            stopped += 1
        except Exception:
            pass
        for _ in range(30):
            try:
                opener.open(base, timeout=0.5)
                time.sleep(0.2)
            except Exception:
                break
    return stopped


def start(port: int = 0) -> tuple[ThreadingHTTPServer, str]:
    _register_core()
    try:
        stop_previous()
    except Exception as e:
        print("stop_previous:", e)
    srv = None
    for p in ([port] if port else list(_app.current().ports) + [0]):
        try:
            srv = Server(("127.0.0.1", p), Handler)
            break
        except OSError:
            continue
    if srv is None:
        srv = Server(("127.0.0.1", 0), Handler)
    srv.daemon_threads = True
    state["server"] = srv
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, f"http://127.0.0.1:{srv.server_address[1]}/"


def shutdown():
    srv = state.get("server")
    if srv:
        threading.Thread(target=srv.shutdown, daemon=True).start()
    os._exit(0)


def window_alive() -> bool:
    """Vai mūsu atvērtais Edge/Chrome lietotnes logs vēl ir atvērts (ja to izdevās izsekot)."""
    p = state.get("window_proc")
    try:
        return p is not None and p.poll() is None
    except Exception:
        return False


def idle_watch(minutes: int = 5):
    """Pārlūka režīmā: ja logs aizvērts (nav 'ping') un darbs nenotiek — beidzam darbu.

    Datora miegs: kamēr dators guļ, ne lapa, ne serveris nestrādā; pamostoties pulkstenis ir "pārlēcis"
    uz priekšu, un bez šīs pārbaudes serveris uzreiz izslēgtos (lapā "Failed to fetch"). Tāpēc, ja starp
    pārbaudēm pagājis daudz vairāk laika nekā gaidīts, uzskatām, ka dators gulēja, un sākam skaitīt no jauna.
    Kamēr mūsu logs (Edge/Chrome process) vēl ir atvērts, neizslēdzamies nekad."""
    step = 20

    def run():
        prev = time.time()
        while True:
            time.sleep(step)
            now = time.time()
            if now - prev > step * 3:                     # dators gulēja (vai pulkstenis pārlēca)
                print(f"pamodos pēc {int(now - prev)} s pārtraukuma — gaidu lapu no jauna")
                state["last_ping"] = now
            prev = now
            if window_alive() or _app.current().busy():
                continue
            if now - state["last_ping"] > minutes * 60:
                print("logs aizvērts (nav ziņu no lapas) — beidzu darbu")
                shutdown()
    threading.Thread(target=run, daemon=True).start()
