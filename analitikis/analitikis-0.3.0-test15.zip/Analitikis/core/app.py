"""Produkta apraksts: ko core/ zina par moduli, kas to palaiž (nosaukums, versija, porti, web mape …)."""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable


@dataclass
class App:
    name: str                               # "Analītiķis" — rāda saskarnē
    slug: str                               # "Analitikis" — datu mape, žurnāla mainīgais
    version: str
    ports: tuple                            # (47625, 47626, 47627)
    api_prefix: str                         # "sales_" — API nosaukumu priekšā (§3)
    web_dir: Path                           # moduļa web/ (index.html, app.js …)
    defaults: dict = field(default_factory=dict)        # moduļa iestatījumi ar noklusējumu
    msgs: dict = field(default_factory=dict)            # servera tulkojumi {atslēga: {lv, en}}
    busy: Callable[[], bool] = lambda: False            # vai notiek darbs (tad neizslēgties)
    webview_main: Callable[[], bool] = lambda: False    # Windows: galvenais logs pywebview
    validate_settings: Callable[[dict], dict] = lambda v: v
    icon: Path | None = None


_current: App | None = None


def init(app: App) -> App:
    global _current
    _current = app
    return app


def current() -> App:
    if _current is None:
        raise RuntimeError("core.app.init() nav izsaukts")
    return _current
