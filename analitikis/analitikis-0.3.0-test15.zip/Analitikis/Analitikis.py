#!/usr/bin/env python3
"""Analītiķis — palaišana.

Atver lietotni atsevišķā logā (ja uzstādīts pywebview), citādi Edge/Chrome "lietotnes" logā
vai parastā pārlūkā.  Parametri:
  --browser    atvērt parastā pārlūkā
  --no-window  tikai serveris (adrese tiek izdrukāta)
  --sync a,b   (iekšēji) datu savākšanas process; --show a, --full a,b
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
if not (ROOT / "core").is_dir():                 # izstrādē core/ ir repozitorija saknē
    sys.path.insert(0, str(ROOT.parent))

from analitikis import config  # noqa: E402,F401  — reģistrē Analītiķi core/
from core import launcher  # noqa: E402


def _sync_main(args):
    from analitikis import sync

    def opt(name):
        return args[args.index(name) + 1] if name in args and args.index(name) + 1 < len(args) else ""
    try:
        parent = int(opt("--parent") or 0)
    except ValueError:
        parent = 0
    sync.run([a for a in opt("--sync").split(",") if a], opt("--show") or None,
             [a for a in opt("--full").split(",") if a], parent)


def main():
    logged = launcher.log_to_file()
    args = sys.argv[1:]
    if "--sync" in args:
        return _sync_main(args)
    from analitikis import server
    launcher.run(args, logged, server.start)


if __name__ == "__main__":
    main()
