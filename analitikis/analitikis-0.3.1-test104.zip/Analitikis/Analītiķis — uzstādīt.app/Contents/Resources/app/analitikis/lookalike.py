"""Vienas bildes kopiju apvienošana starp aģentūrām: ar roku un pēc sīktēla izskata (lietotājs 2026-10-30).

Problēma: sērijā vairākām bildēm vienāds virsraksts katrā aģentūrā → pēc virsraksta nevar zināt, kura Shutterstock
bilde atbilst kurai Adobe bildei (db.regroup tās neapvieno), un viena bilde izskatās kā vairākas kartītes.

1) Ar roku: lietotājs atzīmē kartītes → "Apvienot: tā pati bilde" (visi vienumi vienā grupā) vai "Atdalīt" (katrs
   vienums atsevišķi). Glabājas img_link (src='man'); šie vienumi pārējās automātiskajās sasaistēs nepiedalās.
2) Automātiski: vienumiem, kuru virsraksts aģentūrā atkārtojas (un tas pats virsraksts ir citās aģentūrās), programma
   lejupielādē sīktēlu, aprēķina dHash (8×8, noteikumi §8 phash) un sasaista līdzīgākos dažādu aģentūru vienumus
   (attālums ≤ MAX_DIST, katra aģentūra grupā vienreiz). img_link src='auto'.
"""
from __future__ import annotations

import hashlib
import io
import threading
import time
import urllib.request
import uuid

from . import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS img_link(agency TEXT, agency_item_id TEXT, key TEXT, src TEXT, PRIMARY KEY(agency, agency_item_id));
CREATE INDEX IF NOT EXISTS img_link_key ON img_link(key);
CREATE TABLE IF NOT EXISTS thumb_hash(agency TEXT, agency_item_id TEXT, thumb TEXT, h TEXT, PRIMARY KEY(agency, agency_item_id));
"""
MAX_DIST = 10            # dHash attālums (no 64 bitiem), līdz kuram uzskata par to pašu bildi
PER_RUN = 300            # cik sīktēlus lejupielādēt vienā reizē (pārējos — nākamreiz)
UA = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"

_run_lock = threading.Lock()


def ensure(c=None) -> None:
    (c or db.conn()).executescript(SCHEMA)


# --------------------------------------------------------------------------- ar roku

def _members(c, items: list[dict]) -> list[tuple[str, str]]:
    out = []
    for it in items:
        ag, iid = str(it.get("agency") or ""), str(it.get("agency_item_id") or "")
        if not ag or not iid:
            continue
        a = c.execute("SELECT gid FROM assets WHERE agency=? AND agency_item_id=?", (ag, iid)).fetchone()
        if a and a["gid"]:
            out += [(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM assets WHERE gid=?", (a["gid"],))]
        out.append((ag, iid))
    return sorted(set(out))


def merge(items: list[dict]) -> int:
    """Atzīmētās kartītes (ar visām to kopijām) — viena bilde."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        mem = _members(c, items)
        key = "m:" + uuid.uuid4().hex[:12]
        for ag, iid in mem:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (ag, iid, key, "man"))
        c.commit()
    db.regroup()
    return len(mem)


def split(items: list[dict]) -> int:
    """Kartīte(s) — katrs aģentūras vienums atsevišķi (automātika tos vairs neapvieno)."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        mem = _members(c, items)
        for ag, iid in mem:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (ag, iid, f"s:{ag}|{iid}", "man"))
        c.commit()
    db.regroup()
    return len(mem)


def detach(agency: str, agency_item_id: str) -> int:
    """test103: tikai šo vienu vienumu izņem no apvienojuma (pārējie paliek kopā); automātika to vairs neapvieno."""
    db.ensure_groups()
    with db._lock:
        c = db.conn()
        ensure(c)
        c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (agency, agency_item_id, f"s:{agency}|{agency_item_id}", "man"))
        c.commit()
    db.regroup()
    return 1


# --------------------------------------------------------------------------- automātiski (sīktēla līdzība)

def _bits(px: list[int]) -> str:
    bits = 0
    for y in range(8):
        for x in range(8):
            bits = (bits << 1) | (1 if px[y * 9 + x] > px[y * 9 + x + 1] else 0)
    return f"{bits:016x}"


def _dhash_sips(data: bytes) -> str | None:
    """test26: Mac rezerve bez Pillow / formātiem, ko Pillow nenolasa (AVIF, HEIC): sips → 9×8 BMP → pelēktoņi."""
    import os, shutil, subprocess, tempfile, struct
    if not shutil.which("sips"):
        return None
    d = tempfile.mkdtemp(prefix="ah_")
    try:
        src, out = os.path.join(d, "in"), os.path.join(d, "out.bmp")
        with open(src, "wb") as f:
            f.write(data)
        subprocess.run(["sips", "-s", "format", "bmp", "-z", "8", "9", src, "--out", out], capture_output=True, timeout=20)
        b = open(out, "rb").read()
        off, w, h, bpp = struct.unpack_from("<I", b, 10)[0], struct.unpack_from("<i", b, 18)[0], struct.unpack_from("<i", b, 22)[0], struct.unpack_from("<H", b, 28)[0]
        if w != 9 or abs(h) != 8 or bpp not in (24, 32):
            return None
        step, row = bpp // 8, ((9 * (bpp // 8) + 3) // 4) * 4
        px = []
        for y in range(8):
            ry = (7 - y) if h > 0 else y                 # BMP parasti no apakšas
            for x in range(9):
                i = off + ry * row + x * step
                bl, g, r = b[i], b[i + 1], b[i + 2]
                px.append(int(0.299 * r + 0.587 * g + 0.114 * bl))
        return _bits(px)
    except Exception:
        return None
    finally:
        shutil.rmtree(d, ignore_errors=True)


_DH_LOGGED = []


def dhash(data: bytes) -> str | None:
    """dHash 8×8 (64 biti, 16 hex) no attēla baitiem; None, ja attēls bojāts. Bez Pillow vai nezināms formāts → sips (Mac)."""
    try:
        from PIL import Image  # type: ignore
    except ImportError:
        Image = None
    if Image is None:
        h = _dhash_sips(data)
        if not h and not _DH_LOGGED:
            _DH_LOGGED.append(1); print("sīktēls salīdzināšanai: Pillow nav un sips neizdevās")
        return h
    try:
        im = Image.open(io.BytesIO(data)).convert("L")
        w, h = im.size
        if w > 40 and h > 40:                 # ūdenszīmes/rāmji malās — nedaudz apgriežam
            im = im.crop((int(w * .04), int(h * .04), int(w * .96), int(h * .96)))
        im = im.resize((9, 8), Image.LANCZOS)
        return _bits(list(im.getdata()))
    except Exception as e:
        h = _dhash_sips(data)
        if not h and not _DH_LOGGED:
            _DH_LOGGED.append(1); print(f"sīktēls salīdzināšanai: neizdevās nolasīt ({str(e)[:80]}; sākums {data[:12]!r})")
        return h


def dist(a: str, b: str) -> int:
    return bin(int(a, 16) ^ int(b, 16)).count("1")


_ERR_LOGGED = set()


def _fetch_curl(url: str, hd: dict) -> bytes | None:
    """test28: Envato CDN Python pieprasījumam atdod aizstājējattēlu — Mac sistēmas curl (cits savienojuma "nospiedums")."""
    import os, shutil, subprocess
    cu = shutil.which("curl")
    if not cu:
        return None
    args = [cu, "-sSL", "--max-time", "15", "--compressed"]
    for k, v in hd.items():
        args += ["-H", f"{k}: {v}"]
    try:
        # test33: Windows — bez melnā konsoles loga katram sīktēlam (CREATE_NO_WINDOW)
        r = subprocess.run(args + [url], capture_output=True, timeout=20,
                           creationflags=0x08000000 if os.name == "nt" else 0)
        return r.stdout if r.returncode == 0 and r.stdout else None
    except Exception:
        return None


def _fetch(url: str) -> bytes | None:
    """test25: python.org Python uz Mac bez sistēmas sertifikātiem → HTTPS neizdevās klusi (tāpat kā fx.py — /etc/ssl/cert.pem)."""
    try:
        from .fx import _ssl_ctx
        hd = {"User-Agent": UA, "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8"}   # test27: kā pārlūks (AVIF → sips)
        if "envatousercontent.com" in url:
            hd["Referer"] = "https://portfolio.envato.com/"       # bez Referer Envato atdeva vienu un to pašu attēlu visām bildēm
        if "envatousercontent.com" in url:
            b = _fetch_curl(url, hd)
            if b:
                return b
        req = urllib.request.Request(url, headers=hd)
        with urllib.request.urlopen(req, timeout=12, context=_ssl_ctx()) as r:
            return r.read(2_000_000)
    except Exception as e:
        host = url.split("/")[2] if "//" in url else url[:30]
        if host not in _ERR_LOGGED:                    # viena rinda katram serverim
            _ERR_LOGGED.add(host)
            print(f"sīktēls salīdzināšanai: {host} — {str(e)[:120]}")
        return None


def bucket(mk: str | None) -> str | None:
    """Virsraksta sākums (5 vārdi): aģentūras virsrakstus saīsina dažādi (iStock ~50 zīmes), tāpēc salīdzina sākumu."""
    w = (mk or "").split()
    return " ".join(w[:5]) if len(w) >= 5 else None


def _candidates(c) -> list:
    """Vienumi, kuru virsraksta sākums vienā aģentūrā atkārtojas un ir arī citā aģentūrā (tur virsraksts nepalīdz)."""
    rows = c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, a.thumb, th.thumb hthumb, th.h FROM assets a
                        LEFT JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id
                        WHERE a.mkey IS NOT NULL AND a.thumb LIKE 'http%'""").fetchall()
    by = {}
    for r in rows:
        b = bucket(r["mkey"])
        if b:
            by.setdefault(b, []).append(r)
    out = []
    for b, items in by.items():
        ags = [i["agency"] for i in items]
        if len(set(ags)) > 1 and len(ags) > len(set(ags)):
            out += items
    return out


MAX_DIST_ALL = 5        # test103: visu bilžu salīdzināšanā stingrāk (nav virsraksta pierādījuma)


def all_on() -> bool:
    return bool(db.get_state("", "match_all"))


def _candidates_all(c) -> list:
    """test103: visas pārdotās bildes ar sīktēlu (lietotājs: "Apvienot visas", kā Microstockr Match All)."""
    return c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, a.thumb, th.thumb hthumb, th.h FROM assets a
                        LEFT JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id
                        WHERE a.thumb LIKE 'http%' AND EXISTS (SELECT 1 FROM sales s WHERE s.agency=a.agency
                          AND s.agency_item_id=a.agency_item_id)""").fetchall()


def progress() -> dict:
    with db._lock:
        c = db.conn()
        ensure(c)
        rows = _candidates_all(c)
        auto = c.execute("SELECT COUNT(*) FROM img_link WHERE src='auto'").fetchone()[0]
        man = c.execute("SELECT COUNT(*) FROM img_link WHERE src='man' AND key LIKE 'm:%'").fetchone()[0]
        det = c.execute("SELECT COUNT(*) FROM img_link WHERE src='man' AND key LIKE 's:%'").fetchone()[0]
    done = sum(1 for r in rows if r["h"] is not None and r["hthumb"] == r["thumb"])
    return {"on": all_on(), "off": bool(db.get_state("", "match_off")), "total": len(rows), "hashed": done,
            "auto": auto, "manual": man, "detached": det, "busy": _run_lock.locked(), "mr": db.get_state("", "mr_compat")}


# test104 (lietotājs 2026-11-21): vai Microstockr nospiedumi (mr_hash) ir tie paši, kas mūsu dHash? Pārbauda bildēm,
# kurām ir abi; ja sakrīt (arī ar bitu secības variantiem) — Microstockr nospiedumus lieto kopā ar mūsējiem.
def _mr_variants(h: str) -> dict:
    x = int(h, 16)
    rev = int(f"{x:064b}"[::-1], 2)
    bsw = int.from_bytes(x.to_bytes(8, "big")[::-1], "big")
    m = (1 << 64) - 1
    return {"id": x, "inv": x ^ m, "rev": rev, "revinv": rev ^ m, "bswap": bsw}


def mr_conv(h: str, v: str) -> str:
    return f"{_mr_variants(h)[v]:016x}"


def mr_check(log: bool = True) -> dict | None:
    with db._lock:
        c = db.conn()
        ensure(c)
        try:
            rows = c.execute("""SELECT th.h a, m.h b FROM thumb_hash th JOIN mr_hash m ON m.agency=th.agency AND m.agency_item_id=th.agency_item_id
                                WHERE th.h != ''""").fetchall()
        except Exception:
            return None
    if len(rows) < 30:
        return None
    best = None
    for v in ("id", "inv", "rev", "revinv", "bswap"):
        ds = sorted(bin(int(r["a"], 16) ^ _mr_variants(r["b"])[v]).count("1") for r in rows)
        med = ds[len(ds) // 2]
        close = round(100 * sum(1 for d in ds if d <= MAX_DIST_ALL) / len(ds))
        if best is None or med < best["med"]:
            best = {"v": v, "med": med, "close": close, "n": len(rows)}
    best["ok"] = best["med"] <= 6 and best["close"] >= 70
    db.set_state("", "mr_compat", best)
    if log:
        print(f"Microstockr nospiedumi pret mūsējiem: {best['n']} bildes, sakrīt {best['close']}% (mediāna {best['med']} biti no 64, "
              f"variants {best['v']}) — {'lietoju kopā ar mūsējiem' if best['ok'] else 'citāds paņēmiens, nelietoju'}")
    return best


def _mr_extra(c, have: set) -> list[dict]:
    """Ja Microstockr nospiedumi saderīgi — vienumi bez mūsu nospieduma, bet ar Microstockr nospiedumu."""
    st = db.get_state("", "mr_compat") or {}
    if not st.get("ok"):
        return []
    out = []
    for r in c.execute("""SELECT m.agency, m.agency_item_id, m.h FROM mr_hash m JOIN assets a ON a.agency=m.agency AND a.agency_item_id=m.agency_item_id
                          WHERE EXISTS (SELECT 1 FROM sales s WHERE s.agency=m.agency AND s.agency_item_id=m.agency_item_id)"""):
        k = (r["agency"], r["agency_item_id"])
        if k not in have:
            out.append({"agency": k[0], "agency_item_id": k[1], "h": mr_conv(r["h"], st["v"])})
    return out


def match_all() -> None:
    """Poga "Apvienot visas": ieslēdz visu bilžu salīdzināšanu un palaiž to fonā līdz galam."""
    db.set_state("", "match_all", True)
    db.set_state("", "match_off", False)

    def go():
        for _ in range(500):
            r = run()
            if r.get("busy"):
                time.sleep(5)
                continue
            if r.get("hashed") or r.get("linked"):
                print(f"apvienot visas: sīktēli +{r.get('hashed', 0)}, sasaistīti {r.get('linked', 0)}, atlicis {r.get('left', 0)}")
            if not r.get("left"):
                break
        try:
            if (mr_check() or {}).get("ok"):
                n = _link()
                db.regroup()
                print(f"apvienot visas: ar Microstockr nospiedumiem sasaistīti {n}")
        except Exception as e:
            print("Microstockr nospiedumu pārbaude:", str(e)[:160])
    threading.Thread(target=go, daemon=True).start()


def unmatch_all() -> int:
    """Poga "Atcelt automātiskās apvienošanas": dzēš tikai programmas sasaistes (src=auto); lietotāja lēmumi paliek."""
    db.set_state("", "match_all", False)
    db.set_state("", "match_off", True)
    with db._lock:
        c = db.conn()
        ensure(c)
        n = c.execute("DELETE FROM img_link WHERE src='auto'").rowcount
        c.commit()
    db.regroup()
    return n


def find(agency: str, agency_item_id: str, limit: int = 24) -> dict:
    """Poga "Atrast tādu pašu": citu aģentūru vienumi ar līdzīgāko sīktēlu (vēl nav šajā grupā)."""
    with db._lock:
        c = db.conn()
        ensure(c)
        a = c.execute("SELECT gid, thumb FROM assets WHERE agency=? AND agency_item_id=?", (agency, agency_item_id)).fetchone()
        if not a:
            return {"items": []}
        grp = [dict(r) for r in c.execute("""SELECT a.agency, a.agency_item_id, a.thumb, th.h FROM assets a
                 LEFT JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id AND th.thumb=a.thumb
                 WHERE a.gid=?""", (a["gid"],))] if a["gid"] else []
    hs = []
    for g in grp or [{"agency": agency, "agency_item_id": agency_item_id, "thumb": a["thumb"], "h": None}]:
        h = g.get("h")
        if not h and (g.get("thumb") or "").startswith("http"):
            data = _fetch(g["thumb"])
            h = dhash(data) if data else None
            with db._lock:
                c = db.conn()
                c.execute("INSERT OR REPLACE INTO thumb_hash VALUES(?,?,?,?)", (g["agency"], g["agency_item_id"], g["thumb"], h or ""))
                c.commit()
        if h:
            hs.append(h)
    if not hs:
        return {"items": [], "no_hash": True}
    mine = {(g["agency"], g["agency_item_id"]) for g in grp} | {(agency, agency_item_id)}
    with db._lock:
        c = db.conn()
        rows = c.execute("""SELECT a.agency, a.agency_item_id, a.title, a.thumb, th.h FROM assets a
                 JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id AND th.thumb=a.thumb
                 WHERE th.h != ''""").fetchall()
        total = c.execute("SELECT COUNT(*) FROM thumb_hash WHERE h != ''").fetchone()[0]
        extra = _mr_extra(c, {(r["agency"], r["agency_item_id"]) for r in rows})
        if extra:
            info = {(r["agency"], r["agency_item_id"]): r for r in c.execute(
                "SELECT agency, agency_item_id, title, thumb FROM assets")}
            rows = [dict(r) for r in rows] + [{**e, "title": (info.get((e["agency"], e["agency_item_id"])) or {"title": ""})["title"],
                                               "thumb": (info.get((e["agency"], e["agency_item_id"])) or {"thumb": ""})["thumb"]} for e in extra]
            total += len(extra)
    out = []
    for r in rows:
        if (r["agency"], r["agency_item_id"]) in mine:
            continue
        d = min(dist(h, r["h"]) for h in hs)
        if d <= 14:
            out.append({"agency": r["agency"], "agency_item_id": r["agency_item_id"], "title": r["title"], "thumb": r["thumb"],
                        "sim": round(100 - d * 100 / 64)})
    out.sort(key=lambda x: -x["sim"])
    return {"items": out[:limit], "hashed": total}


def run() -> dict:
    """Viena kārta: lejupielādē trūkstošos sīktēlus (≤ PER_RUN), aprēķina dHash, sasaista. Drošs atkārtot."""
    if not _run_lock.acquire(blocking=False):
        return {"busy": True}
    try:
        try:
            from PIL import Image  # noqa: F401
        except ImportError:
            return {"no_pillow": True}
        with db._lock:
            c = db.conn()
            ensure(c)
            rows = [dict(r) for r in (_candidates_all(c) if all_on() else _candidates(c))]
        todo = [r for r in rows if r["h"] is None or r["hthumb"] != r["thumb"]][:PER_RUN]
        got = 0
        for r in todo:
            data = _fetch(r["thumb"])
            h = dhash(data) if data else None
            with db._lock:
                c = db.conn()
                c.execute("INSERT OR REPLACE INTO thumb_hash VALUES(?,?,?,?)", (r["agency"], r["agency_item_id"], r["thumb"], h or ""))
                c.commit()
            r["h"] = h or ""
            got += 1 if h else 0
            time.sleep(0.05)
        linked = _link()
        if got or linked:
            db.regroup()
        return {"candidates": len(rows), "hashed": got, "linked": linked, "left": len([r for r in rows if r["h"] is None])}
    finally:
        _run_lock.release()


def _cluster(items: list[dict], key_prefix: str, c) -> int:
    """Dažādu aģentūru vienumi ar līdzīgu nospiedumu (h) → viena grupa; līdzīgākie pāri pirmie, aģentūra grupā vienreiz."""
    if len({i["agency"] for i in items}) < 2:
        return 0
    pairs = sorted(((dist(a["h"], b["h"]), ia, ib) for ia, a in enumerate(items) for ib, b in enumerate(items)
                    if ia < ib and a["agency"] != b["agency"]), key=lambda x: x[0])
    parent = list(range(len(items)))
    ags = [{i["agency"]} for i in items]

    def find(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for d, ia, ib in pairs:
        if d > MAX_DIST:
            break
        ra, rb = find(ia), find(ib)
        if ra != rb and not (ags[ra] & ags[rb]):
            parent[rb] = ra
            ags[ra] |= ags[rb]
    groups = {}
    for i in range(len(items)):
        groups.setdefault(find(i), []).append(items[i])
    n = 0
    for g in groups.values():
        if len(g) < 2:
            continue
        g.sort(key=lambda x: (x["agency"], x["agency_item_id"]))
        key = key_prefix + hashlib.sha1((g[0]["agency"] + "|" + g[0]["agency_item_id"]).encode()).hexdigest()[:12]
        for it in g:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (it["agency"], it["agency_item_id"], key, "auto"))
            n += 1
    return n


def _link() -> int:
    """Automātiskās sasaistes no jauna: (1) Microstockr grupās — pēc Microstockr nospieduma; (2) pārējās — pēc mūsu
    dHash vienumiem ar līdzīgu virsraksta sākumu. Lietotāja lēmumi (man) netiek aiztikti."""
    with db._lock:
        c = db.conn()
        ensure(c)
        manual = {(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM img_link WHERE src='man'")}
        c.execute("DELETE FROM img_link WHERE src='auto'")
        if db.get_state("", "match_off"):          # test103: lietotājs atcēla automātiskās apvienošanas
            c.commit()
            return 0
        n, done = 0, set()
        # (1) Microstockr: tag grupā (sērija var būt vienā grupā) — nospiedums izšķir kadrus
        mr = c.execute("""SELECT l.agency, l.agency_item_id, l.tag, h.h FROM mr_link l JOIN mr_hash h
                          ON h.agency=l.agency AND h.agency_item_id=l.agency_item_id""").fetchall()
        by = {}
        for r in mr:
            if (r["agency"], r["agency_item_id"]) not in manual:
                by.setdefault(r["tag"], []).append(dict(r))
        for tag, items in by.items():
            k = _cluster(items, "r:", c)
            n += k
            done |= {(i["agency"], i["agency_item_id"]) for i in items}
        # (2) mūsu dHash pēc virsraksta sākuma
        rows = c.execute("""SELECT a.agency, a.agency_item_id, a.mkey, th.h FROM assets a
                            JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id AND th.thumb=a.thumb
                            WHERE th.h != '' AND a.mkey IS NOT NULL""").fetchall()
        by = {}
        for r in rows:
            b = bucket(r["mkey"])
            k = (r["agency"], r["agency_item_id"])
            if b and k not in manual and k not in done:
                by.setdefault(b, []).append(dict(r))
        for b, items in by.items():
            k = _cluster(items, "h:", c)
            n += k
        # (3) test103: visas pārdotās bildes pēc izskata (tikai pēc "Apvienot visas")
        if all_on():
            linked = {(r[0], r[1]) for r in c.execute("SELECT agency, agency_item_id FROM img_link")}
            allr = c.execute("""SELECT a.agency, a.agency_item_id, th.h FROM assets a
                                JOIN thumb_hash th ON th.agency=a.agency AND th.agency_item_id=a.agency_item_id AND th.thumb=a.thumb
                                WHERE th.h != ''""").fetchall()
            its = [dict(r) for r in allr if (r["agency"], r["agency_item_id"]) not in linked and
                   (r["agency"], r["agency_item_id"]) not in done]
            have = {(i["agency"], i["agency_item_id"]) for i in allr}
            its += [i for i in _mr_extra(c, have) if (i["agency"], i["agency_item_id"]) not in linked
                    and (i["agency"], i["agency_item_id"]) not in done and (i["agency"], i["agency_item_id"]) not in manual]
            n += _link_all(its, c)
        c.commit()
        return n


def _link_all(items: list[dict], c) -> int:
    """Visu bilžu sasaiste: kandidātu pāri caur 4 joslām (ja attālums ≤ 5, vismaz viena 16 bitu josla sakrīt), tad
    tuvākie pāri pirmie, aģentūra grupā vienreiz (pret sērijām). Vienkrāsaini / bieži nospiedumi (balts fons) — izlaiž."""
    from collections import Counter
    freq = Counter(i["h"] for i in items)
    items = [i for i in items if freq[i["h"]] <= 4 and 10 <= bin(int(i["h"], 16)).count("1") <= 54]
    bands = {}
    for idx, it in enumerate(items):
        for b in range(4):
            bands.setdefault((b, it["h"][b * 4:(b + 1) * 4]), []).append(idx)
    pairs = set()
    for lst in bands.values():
        if 1 < len(lst) <= 60:
            for i in range(len(lst)):
                for j in range(i + 1, len(lst)):
                    a, bb = items[lst[i]], items[lst[j]]
                    if a["agency"] != bb["agency"]:
                        d = dist(a["h"], bb["h"])
                        if d <= MAX_DIST_ALL:
                            pairs.add((d, lst[i], lst[j]))
    parent = list(range(len(items)))
    ags = [{i["agency"]} for i in items]

    def fnd(x):
        while parent[x] != x:
            parent[x] = parent[parent[x]]
            x = parent[x]
        return x
    for d, ia, ib in sorted(pairs):
        ra, rb = fnd(ia), fnd(ib)
        if ra != rb and not (ags[ra] & ags[rb]):
            parent[rb] = ra
            ags[ra] |= ags[rb]
    groups = {}
    for i in range(len(items)):
        groups.setdefault(fnd(i), []).append(items[i])
    n = 0
    for g in groups.values():
        if len(g) < 2:
            continue
        g.sort(key=lambda x: (x["agency"], x["agency_item_id"]))
        key = "x:" + hashlib.sha1((g[0]["agency"] + "|" + g[0]["agency_item_id"]).encode()).hexdigest()[:12]
        for it in g:
            c.execute("INSERT OR REPLACE INTO img_link VALUES(?,?,?,?)", (it["agency"], it["agency_item_id"], key, "auto"))
            n += 1
    return n


def start() -> None:
    """Fonā: pēc palaišanas un tad ik 30 min (jaunām bildēm)."""
    def loop():
        time.sleep(45)
        while True:
            try:
                r = run()
                if r.get("hashed") or r.get("linked"):
                    print(f"bilžu apvienošana pēc izskata: sīktēli {r.get('hashed', 0)}, sasaistīti {r.get('linked', 0)}")
                if r.get("left"):
                    time.sleep(60)
                    continue
            except Exception as e:
                print("bilžu apvienošana:", str(e)[:160])
            time.sleep(1800)
    threading.Thread(target=loop, daemon=True).start()
