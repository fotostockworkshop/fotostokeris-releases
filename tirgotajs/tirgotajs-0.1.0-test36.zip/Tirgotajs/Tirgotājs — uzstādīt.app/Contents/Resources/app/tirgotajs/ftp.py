"""Aģentūru FTP pieslēgumi (iestatījumi → "Aģentūru pieslēgumi"). Parole — tikai drošajā glabātuvē
(core/credentials, nosaukums ftp:<aģentūra>). FTP un FTPS — Python ftplib; SFTP — bibliotēka paramiko (ja uzstādīta).
upload_set(): komplekta bildes, kas aģentūrai der un vēl nav atzīmētas, augšupielādē fonā (progress — status());
pēc katra faila atzīme "uploaded" — portālā vēl jāspiež "Submit" (to dara lietotājs)."""
from __future__ import annotations

import ftplib
import json
import os
import socket
import threading
import time

from core import config, credentials

from . import stock

TIMEOUT = 20


def cred_name(ag: str) -> str:
    return "ftp:" + ag


def _login(ag: str, c: dict):
    cr = credentials.get(cred_name(ag))
    if not cr or not cr[0] or not cr[1]:
        raise RuntimeError("no_creds")
    user, pw = cr
    host, port, proto = stock.clean_host(c.get("host")), int(c.get("port") or 0), c.get("proto") or "ftp"
    if not host:
        raise RuntimeError("no_host")
    if proto == "sftp":
        try:
            import paramiko
        except ImportError:
            raise RuntimeError("no_paramiko")
        # 2026-11-05: Magnific — "Authentication timeout" (serveris lēni atbild uz pieteikšanos) — ilgāks gaidīšanas
        # laiks un līdz 3 mēģinājumiem ar pauzi
        last = None
        for attempt in range(3):
            t = paramiko.Transport((host, port or 22))
            t.banner_timeout = 40
            t.auth_timeout = 90
            try:
                t.connect(username=user, password=pw)
                return ("sftp", t, paramiko.SFTPClient.from_transport(t))
            except paramiko.AuthenticationException as e:
                t.close()
                last = e
                if "timeout" not in str(e).lower():
                    raise                                   # nepareiza parole — atkārtot nav jēgas
                print(f"FTP {ag}: pieteikšanās noildze ({attempt + 1}/3), mēģinu vēlreiz")
                time.sleep(5 * (attempt + 1))
            except Exception as e:
                t.close()
                last = e
                print(f"FTP {ag}: savienojums neizdevās ({attempt + 1}/3): {type(e).__name__}: {e}"[:300])
                time.sleep(5 * (attempt + 1))
        raise last
    f = _TLS(timeout=TIMEOUT) if proto == "ftps" else ftplib.FTP(timeout=TIMEOUT)
    f.connect(host, port or 21)
    f.login(user, pw)
    if proto == "ftps":
        f.prot_p()
    return ("ftp", f, None)


class _TLS(ftplib.FTP_TLS):
    """FTPS ar TLS sesijas atkārtošanu datu savienojumā — daži serveri (Envato AWS, vsftpd) to prasa (522)."""
    def ntransfercmd(self, cmd, rest=None):
        conn, size = ftplib.FTP.ntransfercmd(self, cmd, rest)
        if self._prot_p:
            conn = self.context.wrap_socket(conn, server_hostname=self.host, session=self.sock.session)
        return conn, size


def _close(h):
    try:
        if h[0] == "sftp":
            h[2].close()
            h[1].close()
        else:
            h[1].quit()
    except Exception:
        pass


def _why(e: Exception) -> str:
    n = type(e).__name__
    if isinstance(e, ftplib.error_perm) or "Authentication" in n or "BadAuthentication" in n:
        return "auth"
    if isinstance(e, (socket.timeout, TimeoutError)):
        return "timeout"
    if isinstance(e, socket.gaierror):
        return "host"
    return "connect"


def test(ag: str, override: dict | None = None) -> dict:
    if ag not in stock.FTP_DEF:
        return {"ok": False, "error": "no_ftp"}
    c = stock.conn(ag)
    if override:
        c.update({k: override[k] for k in ("proto", "host", "port", "dir") if override.get(k)})
    where = f"{c.get('proto')}://{stock.clean_host(c.get('host'))}:{c.get('port')}"
    try:
        h = _login(ag, c)
    except RuntimeError as e:
        print(f"FTP pārbaude {ag} ({where}): {e}")
        return {"ok": False, "error": str(e)}
    except Exception as e:
        why = _why(e)
        print(f"FTP pārbaude {ag} ({where}): {why} — {type(e).__name__}: {e}"[:300])
        return {"ok": False, "error": why, "detail": f"{type(e).__name__}: {e}"[:200]}
    try:
        _enter(h, c.get("dir") or "")
        listing = h[2].listdir(c.get("dir") or ".")[:20] if h[0] == "sftp" else h[1].nlst()[:20]
    except Exception as e:
        _close(h)
        print(f"FTP pārbaude {ag} ({where}): mape '{c.get('dir')}' — {type(e).__name__}: {e}"[:300])
        return {"ok": False, "error": "dir", "detail": f"{type(e).__name__}: {e}"[:200]}
    _close(h)
    print(f"FTP pārbaude {ag} ({where}): savienojums izdevās")
    return {"ok": True, "listing": listing}


def remote_name(ag: str, name: str) -> str:
    """Aģentūrām, kas neielādē failus ar atstarpēm (Ingram — agency_specs filename.no_spaces), atstarpes → "_"."""
    fn = (stock.specs().get(ag) or {}).get("filename") or {}
    return name.replace(" ", "_") if fn.get("no_spaces") else name


_job: dict = {"running": False}
_jlock = threading.Lock()


def status() -> dict:
    return dict(_job)


def _put(h, local: str, name: str, remote_dir: str):
    if h[0] == "sftp":
        h[2].put(local, (remote_dir.rstrip("/") + "/" if remote_dir else "") + name)
    else:
        with open(local, "rb") as f:
            h[1].storbinary("STOR " + name, f, blocksize=256 * 1024)


def _enter(h, remote_dir: str):
    if remote_dir and h[0] == "ftp":
        h[1].cwd(remote_dir)


ENVATO_BAD = set("!#$%()*<=>?@{}[]^~")


def envato_csv(items: list, sid: str = "") -> str | None:
    """Envato Portfolio Manager "Photo CSV" (lietotājs 2026-11-12): File name, Item Title, Tags, Description, Location —
    teksti no komplekta manifesta. Envato tos ņem arī no faila metadatiem; CSV — drošībai. Atgriež faila ceļu."""
    import csv
    recs = {}
    for jp in {it.get("jpath") for it in items if it.get("jpath")}:
        try:
            with open(jp, encoding="utf-8") as f:
                for r in json.load(f).get("images") or []:
                    recs[r.get("stem")] = r
        except Exception:
            continue
    rows = []
    for it in items:
        r = recs.get(it["stem"]) or {}
        tags, seen, total = [], set(), 0
        for k in r.get("keywords") or []:
            k = " ".join("".join(ch for ch in str(k).lower() if ch not in ENVATO_BAD).split()).strip(".&_+-")
            if not k or k.isdigit() or k in seen or len(k) > 100 or total + len(k) + 2 > 2048:
                continue
            seen.add(k)
            tags.append(k)
            total += len(k) + 2
            if len(tags) >= 50:
                break
        rows.append([remote_name("envato", it["file"]), str(r.get("title") or it.get("title") or "")[:100],
                     ", ".join(tags), str(r.get("description") or ""), ""])
    if not rows:
        return None
    x = stock.sets_store().data.get(sid) or {}
    name = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in (x.get("name") or sid or "envato")) + ".csv"
    d = config.app_dir() / "envato-csv"
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    with open(p, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["File name", "Item Title", "Tags", "Description", "Location"])
        w.writerows(rows)
    try:                                            # kopija komplekta mapē (OneDrive) — ja jāieliek portālā ar roku
        sp = stock.set_path(x) if x.get("rel") else ""
        if sp and os.path.isdir(sp):
            import shutil
            os.makedirs(os.path.join(sp, "_fotostokeris"), exist_ok=True)
            shutil.copyfile(p, os.path.join(sp, "_fotostokeris", name[:-4] + "-envato.csv"))
    except Exception as e:
        print("Envato CSV kopija:", e)
    return str(p)


def _run(ag: str, items: list, c: dict, sid: str = "", final: bool = True):
    errors, done = [], 0
    h = None
    try:
        h = _login(ag, c)
        _enter(h, c.get("dir") or "")
        for it in items:
            _job.update(current=it["file"])
            for attempt in (1, 2):                 # savienojums pārtrūka — pieslēdzas no jauna un mēģina vēlreiz
                try:
                    _put(h, it["path"], remote_name(ag, it["file"]), c.get("dir") or "")
                    stock.mark([it["stem"]], ag, "uploaded", set_id=sid)
                    done += 1
                    break
                except Exception as e:
                    if attempt == 2:
                        errors.append(f"{it['file']}: {type(e).__name__}: {e}"[:200])
                        print(f"FTP {ag}: {it['file']} neizdevās — {type(e).__name__}: {e}"[:300])
                    else:
                        _close(h)
                        h = _login(ag, c)
                        _enter(h, c.get("dir") or "")
            _job.update(done=done, errors=errors[-5:], nerr=len(errors))
        if ag == "envato" and done:                 # metadatu CSV blakus bildēm (photos/)
            try:
                cp = envato_csv([it for it in items], sid)
                if cp:
                    _put(h, cp, os.path.basename(cp), c.get("dir") or "")
                    print(f"FTP envato: metadatu CSV augšupielādēts ({os.path.basename(cp)})")
            except Exception as e:
                print(f"FTP envato: CSV neizdevās — {type(e).__name__}: {e}"[:300])
    except Exception as e:
        errors.append(f"{type(e).__name__}: {e}"[:200] if not isinstance(e, RuntimeError) else str(e))
        print(f"FTP {ag}: pieslēgšanās neizdevās — {type(e).__name__}: {e}"[:300])
    finally:
        print(f"FTP {ag}: augšupielādētas {done} no {len(items)}" + (f", kļūdas {len(errors)}" if errors else ""))
        if h:
            _close(h)
        res = {"agency": ag, "done": done, "total": len(items), "nerr": len(errors), "error": errors[0] if errors else ""}
        _job.setdefault("results", []).append(res)
        if final:
            _job.update(running=False, finished=True, done=done, errors=errors[-5:], nerr=len(errors), current="")
    return done


def _items(x: dict, ag: str, by: dict) -> list:
    """Komplekta bildes, kas aģentūrai der un vēl nav atzīmētas."""
    items = []
    for st in x.get("stems") or []:
        it = by.get(st)
        if it:
            rec = (stock.ledger().data.get(st) or {}).get(ag) or {}
            if (not rec.get("state") and not stock.check(it, ag) and not ((it.get("cells") or {}).get(ag) or {}).get("ext")
                    and it["path"] and os.path.isfile(it["path"])):
                items.append(it)
    return items


def plan_all(sid: str) -> dict:
    """"Visām aģentūrām": kurām sūtīs (FTP pieslēgts, ir parole, ir ko sūtīt) un kuras izlaiž ar iemeslu."""
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    by = {it["stem"]: it for it in stock.listing()["items"]}
    go, skip = [], []
    for a in stock.agencies():
        ag = a["id"]
        c = stock.conn(ag)
        if ag not in stock.FTP_DEF or c.get("mode") != "ftp":
            continue                                       # portāla aģentūras — nerāda
        cr = credentials.get(cred_name(ag))
        if not cr or not cr[1]:
            skip.append({"agency": ag, "why": "no_creds"})
            continue
        items = _items(x, ag, by)
        if not items:
            skip.append({"agency": ag, "why": "nothing"})
            continue
        go.append({"agency": ag, "n": len(items), "items": items, "conn": c})
    return {"ok": True, "go": go, "skip": skip, "name": x.get("name")}


def upload_all(sid: str) -> dict:
    """Visām piemērotajām FTP aģentūrām pēc kārtas — nākamā sākas tikai, kad iepriekšējā beigusies (viens pavediens)."""
    p = plan_all(sid)
    if not p.get("ok"):
        return p
    go = p["go"]
    if not go:
        return {"ok": False, "error": "nothing_all", "skip": p["skip"]}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        _job.clear()
        _job.update(running=True, finished=False, agency=go[0]["agency"], set=sid, total=go[0]["n"], done=0, errors=[],
                    nerr=0, current="", url="", queue=[g["agency"] for g in go], step=1, steps=len(go), results=[], all=True)

    def worker():
        for i, g in enumerate(go):
            _job.update(agency=g["agency"], total=g["n"], done=0, errors=[], nerr=0, step=i + 1, current="")
            try:
                _run(g["agency"], g["items"], g["conn"], sid, final=False)
            except Exception as e:                      # viena aģentūra nedrīkst apturēt pārējās
                print(f"FTP {g['agency']}: {e}"[:300])
        # aģentūras, kurām nekas neaizgāja (piem. pieslēgšanās noildze) — vēl viens mēģinājums beigās
        failed = [g for g in go if any(r["agency"] == g["agency"] and r["done"] == 0 and r["nerr"] for r in _job.get("results") or [])]
        for g in failed:
            print(f"FTP {g['agency']}: vēl viens mēģinājums beigās")
            _job["results"] = [r for r in _job["results"] if r["agency"] != g["agency"]]
            _job.update(agency=g["agency"], total=g["n"], done=0, errors=[], nerr=0, current="")
            try:
                _run(g["agency"], g["items"], g["conn"], sid, final=False)
            except Exception as e:
                print(f"FTP {g['agency']}: {e}"[:300])
        _job.update(running=False, finished=True, current="")
    threading.Thread(target=worker, daemon=True).start()
    return {"ok": True, "agencies": [g["agency"] for g in go], "total": sum(g["n"] for g in go)}


def upload_set(sid: str, ag: str) -> dict:
    if ag not in stock.FTP_DEF:
        return {"ok": False, "error": "no_ftp"}
    c = stock.conn(ag)
    if c.get("mode") != "ftp":
        return {"ok": False, "error": "not_ftp"}
    cr = credentials.get(cred_name(ag))
    if not cr or not cr[1]:
        return {"ok": False, "error": "no_creds"}
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    by = {it["stem"]: it for it in stock.listing()["items"]}
    items = _items(x, ag, by)
    if not items:
        return {"ok": False, "error": "nothing"}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        _job.clear()
        _job.update(running=True, finished=False, agency=ag, set=sid, total=len(items), done=0, errors=[], nerr=0,
                    current="", url=c.get("url"), results=[])
    threading.Thread(target=_run, args=(ag, items, c, sid), daemon=True).start()
    return {"ok": True, "total": len(items)}


PER_AGENCY = 240        # aptuvens vienas aģentūras augšupielādes laiks (s) pauzu saspiešanai


def _pause(pause: tuple, deadline: float | None, left: int) -> int:
    """Nejauša pauze; ja ir loga beigas (`deadline`, 9:00) — tā, lai atlikušās `left` aģentūras paspētu līdz tām;
    pēc loga beigām — īsa (30–90 s)."""
    import random
    lo, hi = pause
    if deadline:
        room = (deadline - time.time() - left * PER_AGENCY) / max(left, 1)
        if room <= 30:
            return random.randint(30, 90)
        hi = min(hi, int(room))
        lo = min(lo, hi)
    return random.randint(lo, hi)


def upload_auto(sid: str, pause: tuple = (60, 1200), done_cb=None, deadline: float | None = None) -> dict:
    """Automātiskā nakts iesniegšana (dati §7a ceļš 4.): aģentūras nejaušā secībā, starp tām nejauša pauze 1–20 min.
    `done_cb(results, skip)` — pēc beigām (plānā atzīme + žurnāls)."""
    import random
    p = plan_all(sid)
    if not p.get("ok"):
        return p
    go = list(p["go"])
    random.shuffle(go)
    if not go:
        if done_cb:
            done_cb([], p["skip"])
        return {"ok": False, "error": "nothing_all", "skip": p["skip"]}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        _job.clear()
        _job.update(running=True, finished=False, agency=go[0]["agency"], set=sid, total=go[0]["n"], done=0, errors=[],
                    nerr=0, current="", url="", queue=[g["agency"] for g in go], step=1, steps=len(go), results=[], all=True,
                    auto=True)

    def worker():
        try:
            for i, g in enumerate(go):
                if i:
                    w = _pause(pause, deadline, len(go) - i)
                    _job.update(current="", wait_until=time.time() + w, next=g["agency"], step=i + 1)
                    print(f"FTP automātiski: pauze {w // 60} min {w % 60} s pirms {g['agency']}")
                    time.sleep(w)
                _job.update(agency=g["agency"], total=g["n"], done=0, errors=[], nerr=0, step=i + 1, current="", wait_until=0, next="")
                try:
                    _run(g["agency"], g["items"], g["conn"], sid, final=False)
                except Exception as e:
                    print(f"FTP {g['agency']}: {e}"[:300])
            failed = [g for g in go if any(r["agency"] == g["agency"] and r["done"] == 0 and r["nerr"] for r in _job.get("results") or [])]
            for g in failed:
                time.sleep(random.randint(30, 120))
                print(f"FTP {g['agency']}: vēl viens mēģinājums beigās")
                _job["results"] = [r for r in _job["results"] if r["agency"] != g["agency"]]
                _job.update(agency=g["agency"], total=g["n"], done=0, errors=[], nerr=0, current="")
                try:
                    _run(g["agency"], g["items"], g["conn"], sid, final=False)
                except Exception as e:
                    print(f"FTP {g['agency']}: {e}"[:300])
        finally:
            _job.update(running=False, finished=True, current="", wait_until=0)
            if done_cb:
                try:
                    done_cb(list(_job.get("results") or []), p["skip"])
                except Exception as e:
                    print("FTP automātiski: atzīme plānā neizdevās:", e)
    threading.Thread(target=worker, daemon=True, name="ftp-auto").start()
    return {"ok": True, "agencies": [g["agency"] for g in go]}
