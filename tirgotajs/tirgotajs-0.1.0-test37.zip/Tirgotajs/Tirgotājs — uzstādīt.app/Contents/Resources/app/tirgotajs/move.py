"""Komplekta pārvietošana uz komplektu mapi (OneDrive) — kopsavilkums §10 p.3, §11 (2026-11-04), dati §7a.

Galamērķis: <komplektu mape>/<gads>/<MM-mēn>/<nedēļa>/<KAT-tēma-N> (piem. STOCK/2026/11-nov/45/RF-Bali-1); viena mape
visām aģentūrām. Drošā pārvietošana kā Vārdotājā: kopē uz .part → salīdzina izmēru un MD5 → pārdēvē → tikai tad dzēš
oriģinālu. Pēc katra faila: komplekta manifestā (_fotostokeris/<komplekts>.json + -sikteli.zip) ieraksts klāt, avota
manifestā status "moved" + moved_to. Avota mapei bez bildēm manifesta mapi dzēš (lēmums 2026-11-03 15:51).
Pārvieto tikai bildes failu; RAW un citi pavadoņi paliek avota mapē.
"""
from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import shutil
import threading
import zipfile
from collections import Counter
from datetime import date

from . import stock

MON = ["jan", "feb", "mar", "apr", "mai", "jun", "jul", "aug", "sep", "okt", "nov", "dec"]
IMG = (".jpg", ".jpeg", ".tif", ".tiff", ".png", ".heic", ".webp")

_job: dict = {}
_jlock = threading.Lock()


def status() -> dict:
    return dict(_job)


def _md5(p: str) -> str:
    h = hashlib.md5()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _safe_move(src: str, dst: str) -> None:
    part = dst + ".part"
    try:
        shutil.copy2(src, part)
        if os.path.getsize(part) != os.path.getsize(src) or _md5(part) != _md5(src):
            raise RuntimeError("check")
        os.replace(part, dst)
    except Exception:
        try:
            os.remove(part)
        except OSError:
            pass
        raise
    os.remove(src)


def _write_json(p: str, data: dict) -> None:
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _theme(x: dict, items: list) -> str:
    """Tēma mapes nosaukumam: komplekta nosaukums bez kategorijas un datuma; ja paliek tukšs — biežākā sērija."""
    cat = x.get("cat") or "RF"
    n = str(x.get("name") or "")
    n = re.sub(r"^\s*(RF|ED|EDI|RFR)\b[\s_-]*", "", n, flags=re.I)
    n = re.sub(r"[\s_-]*\b(RF|ED|EDI|RFR)\s*$", "", n, flags=re.I)
    n = re.sub(r"\d{4}-\d{2}-\d{2}(-\d+)?", "", n).strip(" -_")
    if not n and items:
        s = Counter(it.get("src_name") or "" for it in items).most_common(1)[0][0]
        s = re.sub(r"^\d{4}[-._]\d{2}([-._]\d{2})?[_\s-]*", "", s)          # 2026-09_Bali_a3f2 → Bali_a3f2
        s = re.sub(r"[_-][0-9a-f]{4,6}$", "", s)                             # bez sērijas koda
        n = re.sub(r"[_-](RF|ED|EDI)$", "", s, flags=re.I)
    n = re.sub(r"[^\w]+", "-", n, flags=re.UNICODE).strip("-")[:40]
    return f"{cat}-{n or 'komplekts'}"


def target(x: dict, items: list, today: date | None = None) -> str:
    """Mape pēc plānotās dienas (Plāns), citādi — pēc šodienas."""
    d = today
    if d is None and x.get("planned"):
        try:
            d = date.fromisoformat(str(x["planned"])[:10])
        except ValueError:
            d = None
    d = d or date.today()
    week = os.path.join(stock.set_dir(), str(d.year), f"{d.month:02d}-{MON[d.month - 1]}", f"{d.isocalendar()[1]:02d}")
    name = str(x.get("name") or "")
    if stock.NAME_RE.match(name):                           # test37: mape = nosaukums `<datums>-<veids>-<kods>`, bez -N
        base = os.path.join(week, name)
        n = 2
        p = base
        while os.path.exists(p):                            # gandrīz neiespējami (kods unikāls) — drošībai
            p, n = f"{base}-{n}", n + 1
        return p
    base = _theme(x, items)                                 # vecs nosaukums (nevajadzētu būt)
    n = 1
    while os.path.exists(os.path.join(week, f"{base}-{n}")):
        n += 1
    return os.path.join(week, f"{base}-{n}")


def _set_manifest(folder: str, x: dict) -> tuple[str, str, dict]:
    d = os.path.join(folder, stock.SUB)
    name = os.path.basename(folder)
    old = os.path.join(folder, ".fotostokeris")             # komplekti no test10/11 — pārceļ uz _fotostokeris
    if os.path.isdir(old) and not os.path.isdir(d):
        try:
            os.rename(old, d)
        except OSError:
            pass
    os.makedirs(d, exist_ok=True)
    jp, zp = os.path.join(d, name + ".json"), os.path.join(d, name + "-sikteli.zip")
    try:
        with open(jp, encoding="utf-8") as f:
            data = json.load(f)
    except Exception:
        data = {"format": 1, "kind": "set", "set_id": x["id"], "series_id": x["id"], "name": name, "folder": folder,
                "category": x.get("cat") or "RF", "created": stock._now(), "thumbs": os.path.basename(zp), "images": []}
    return jp, zp, data


def _add_thumb(zp: str, stem: str, src_zip: str, path: str = "") -> None:
    try:
        with zipfile.ZipFile(src_zip) as z:
            b = z.read(stem + ".jpg")
    except Exception:
        b = stock.make_thumb(stem, path)               # zip nav — no pašas bildes
    if not b:
        return
    have = {}
    if os.path.isfile(zp):
        try:
            with zipfile.ZipFile(zp) as z:
                have = {n: z.read(n) for n in z.namelist()}
        except Exception:
            have = {}
    have[stem + ".jpg"] = b
    tmp = zp + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
        for k, v in have.items():
            z.writestr(k, v)
    os.replace(tmp, zp)


def _cleanup(folder: str, own: bool = False) -> None:
    """Tukša mape → dzēš. Tikai Tirgotāja paša mapēm (komplekts); NAS sūtījumu mapes un Vārdotāja manifestus neaiztiek
    (dati §7a vienkāršotā kārtība 7, 12)."""
    if not own:
        return
    try:
        left = [f for f in os.listdir(folder) if not f.startswith(".") and os.path.isfile(os.path.join(folder, f))
                and f.lower().endswith(IMG)]
        if left:
            return
        for sub in stock.SUBS:
            shutil.rmtree(os.path.join(folder, sub), ignore_errors=True)
        if not [f for f in os.listdir(folder) if not f.startswith(".")]:
            for f in os.listdir(folder):
                try:
                    os.remove(os.path.join(folder, f))
                except OSError:
                    pass
            os.rmdir(folder)
    except OSError:
        pass


def _run(sid: str, items: list, dst: str, final: bool = True, done0: int = 0):
    errors, done = [], done0
    try:
        x = stock.sets_store().data.get(sid) or {}
        jp, zp, data = _set_manifest(dst, x)
        srcs = set()
        for it in items:
            _job.update(current=it["file"])
            try:
                with open(it["jpath"], encoding="utf-8") as f:
                    src = json.load(f)
                rec = next((r for r in src.get("images") or [] if (r.get("stem") or os.path.splitext(r.get("file") or "")[0]) == it["stem"]), None) or {}
                newp = os.path.join(dst, it["file"])
                if os.path.exists(newp):
                    raise RuntimeError("exists")
                _safe_move(it["path"], newp)
                done += 1
                e = {k: v for k, v in rec.items() if k not in ("moved_to", "returned")}
                e.update(stem=it["stem"], file=it["file"], path=newp, from_folder=it["folder"],
                         series_name=src.get("name") or "", series_id=src.get("series_id") or "",
                         **({"series_code": src["series_code"]} if src.get("series_code") else {}))
                data["images"] = [r for r in data["images"] if r.get("stem") != it["stem"]] + [e]
                data.update(count=len(data["images"]), ready=sum(1 for r in data["images"] if r.get("status") == "ready"),
                            updated=stock._now())
                _write_json(jp, data)
                zsrc = it.get("zpath") or (os.path.join(os.path.dirname(it["jpath"]), src["thumbs"]) if src.get("thumbs") else "")
                _add_thumb(zp, it["stem"], zsrc, newp)
                stock.nas_mark([it["stem"]], "moved", newp)   # tikai savā uzskaitē (Vārdotāja manifestu nemaina)
                srcs.add(it["folder"])
            except Exception as e:
                errors.append(f"{it['file']}: {e}"[:200])
            _job.update(done=done, errors=errors[-5:], nerr=len(errors))
        from . import drive                          # komplekta manifests → Google `Komplekti`
        drive.queue(jp, zp)
        st = stock.sets_store()
        with st.lock:
            if sid in st.data:
                st.data[sid].update(rel=os.path.relpath(dst, stock.set_dir()).replace(os.sep, "/"), moved_at=stock._now())
                st.save()
    except Exception as e:
        errors.append(f"{type(e).__name__}: {e}"[:200])
    finally:
        if final:
            _job.update(running=False, finished=True, done=done, errors=errors[-5:], nerr=len(errors), current="", dir=dst)
        else:
            _job.update(done=done, errors=(_job.get("errors") or [])[-5:] + errors[-5:], nerr=(_job.get("nerr") or 0) + len(errors))
    return done


def _prepare(sid: str, by: dict) -> tuple[list, str] | dict:
    root = stock.set_dir()
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    have = stock.set_path(x)
    rem = [by[s] for s in x.get("stems") or [] if s in by and by[s].get("remote")]
    items = [by[s] for s in x.get("stems") or [] if s in by and by[s]["path"] and os.path.dirname(by[s]["path"]) != have]
    if rem:                                        # bildes tikai NAS (Drive manifests) — pārvieto dators, kas redz NAS
        return {"ok": False, "error": "remote", "n": len(rem)}
    if not items:
        return {"ok": False, "error": "nothing"}
    dst = have if have and os.path.isdir(have) else target(x, items)
    os.makedirs(dst, exist_ok=True)
    st = stock.sets_store()
    with st.lock:                                  # ceļu pieraksta uzreiz — pārtraukumā turpinās tajā pašā mapē
        st.data[sid]["rel"] = os.path.relpath(dst, root).replace(os.sep, "/")
        st.save()
    return items, dst


def _check_root() -> dict | None:
    root = stock.set_dir()
    if not root:
        return {"ok": False, "error": "no_set_dir"}
    if not os.path.isdir(root):
        return {"ok": False, "error": "set_dir_missing"}
    return None


def move_set(sid: str) -> dict:
    bad = _check_root()
    if bad:
        return bad
    by = {it["stem"]: it for it in stock.listing()["items"]}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        if not (stock.sets_store().data.get(sid) or {}).get("planned"):
            return {"ok": False, "error": "not_planned"}       # uz OneDrive tikai plānotos (lēmums 2026-11-05 22:04)
        p = _prepare(sid, by)
        if isinstance(p, dict):
            return p
        items, dst = p
        x = stock.sets_store().data.get(sid) or {}
        _job.clear()
        _job.update(running=True, finished=False, set=sid, name=x.get("name"), total=len(items), done=0, errors=[],
                    nerr=0, current="", dir=dst)
    threading.Thread(target=_run, args=(sid, items, dst), daemon=True).start()
    return {"ok": True, "total": len(items), "dir": dst}


def move_many(ids: list) -> dict:
    """Vairāki komplekti pēc kārtas vienā darbā (Plāns → "Sagatavot nākamo nedēļu")."""
    bad = _check_root()
    if bad:
        return bad
    by = {it["stem"]: it for it in stock.listing()["items"]}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        jobs = []
        for sid in ids:
            p = _prepare(sid, by)
            if not isinstance(p, dict):
                jobs.append((sid, *p))
        if not jobs:
            return {"ok": False, "error": "nothing"}
        total = sum(len(j[1]) for j in jobs)
        _job.clear()
        _job.update(running=True, finished=False, set=jobs[0][0], name="", total=total, done=0, errors=[], nerr=0,
                    current="", dir=os.path.dirname(jobs[0][2]), sets=len(jobs))

    def go():
        done = 0
        for i, (sid, items, dst) in enumerate(jobs):
            done = _run(sid, items, dst, final=i == len(jobs) - 1, done0=done)
    threading.Thread(target=go, daemon=True).start()
    return {"ok": True, "total": total, "sets": len(jobs), "dir": os.path.dirname(jobs[0][2])}


# --------------------------------------------------------------------------- atpakaļ uz NAS (lietotājs 2026-11-11 10:56–10:57)
SET_KEYS = ("from_folder", "series_name", "series_id", "series_code")


def _series_manifest(folder: str, rec: dict) -> tuple[str, str, dict]:
    """Sērijas manifests NAS mapē (atrod pēc series_id; ja mape tukšojoties dzēsta — izveido no jauna)."""
    sid = str(rec.get("series_id") or "")
    for sub in stock.SUBS:
        d = os.path.join(folder, sub)
        for jp in sorted(glob.glob(os.path.join(glob.escape(d), "*.json"))):
            try:
                with open(jp, encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            if not sid or str(data.get("series_id") or "") == sid:
                zp = os.path.join(d, data.get("thumbs") or (os.path.basename(jp)[:-5] + "-sikteli.zip"))
                return jp, zp, None                      # Vārdotāja manifests — nemaina
    name = rec.get("series_name") or os.path.basename(folder)
    d = os.path.join(folder, stock.SUB)
    os.makedirs(d, exist_ok=True)
    data = {"format": 1, "kind": "series", "app": "Tirgotajs", "series_id": sid or f"t{int(stock.datetime.now().timestamp())}",
            "name": name, "folder": folder, **({"series_code": rec["series_code"]} if rec.get("series_code") else {}),
            "created": stock._now(), "updated": stock._now(), "thumbs": name + "-sikteli.zip", "images": []}
    return os.path.join(d, name + ".json"), os.path.join(d, name + "-sikteli.zip"), data


def _unrun(sid: str, folder: str, recs: list) -> None:
    errors, done = [], 0
    touched: dict[str, tuple] = {}
    _, szp, _ = _set_manifest(folder, stock.sets_store().data.get(sid) or {"id": sid})
    try:
        for rec in recs:
            _job.update(current=rec["file"])
            try:
                dst_dir = rec["from_folder"]
                os.makedirs(dst_dir, exist_ok=True)
                src, dst = os.path.join(folder, rec["file"]), os.path.join(dst_dir, rec["file"])
                if os.path.exists(dst):
                    raise RuntimeError("exists")
                _safe_move(src, dst)
                done += 1
                stock.nas_mark([rec["stem"]], "back")
                jp, zp, data = touched.get(dst_dir) or _series_manifest(dst_dir, rec)
                if data is None:                          # sūtījuma manifests ir — bilde tajā jau ir (nemainām)
                    touched[dst_dir] = (jp, zp, None)
                    continue
                e = {k: v for k, v in rec.items() if k not in SET_KEYS + ("moved_to",)}
                e.update(path=dst, status="ready", returned=stock._now(), updated=stock._now())
                imgs = [r for r in data.get("images") or [] if (r.get("stem") or "") != rec["stem"]]
                data["images"] = imgs + [e]
                data.update(count=sum(1 for r in data["images"] if r.get("status") != "moved"),
                            ready=sum(1 for r in data["images"] if r.get("status") == "ready"), updated=stock._now())
                _write_json(jp, data)
                _add_thumb(zp, rec["stem"], szp, dst)
                touched[dst_dir] = (jp, zp, data)
            except Exception as ex:
                errors.append(f"{rec.get('file')}: {ex}"[:200])
            _job.update(done=done, errors=errors[-5:], nerr=len(errors))
        if not errors:
            _cleanup(folder, own=True)
            stock.set_delete(sid)
            from . import plan
            plan.forget(sid)
        else:
            ss = stock.sets_store()
            with ss.lock:
                if sid in ss.data:
                    ss.data[sid].pop("want_back", None)
                    ss.data[sid]["back_err"] = errors[0]
                    ss.save()
        print(f"atpakaļ uz NAS: {done} no {len(recs)}" + (f", kļūdas {len(errors)}: {errors[0]}" if errors else ""))
    finally:
        _job.update(running=False, finished=True, done=done, errors=errors[-5:], nerr=len(errors), current="", back=True)


def unmove(sid: str) -> dict:
    """Atceltu komplektu no OneDrive atpakaļ uz NAS sēriju mapēm (ED/RF pēc `from_folder` komplekta manifestā); avota
    manifestā bilde atkal "ready"; komplekts izjaukts. Tikai datorā, kas redz NAS (dežūras dators)."""
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    folder = stock.set_path(x)
    if not folder or not os.path.isdir(folder):
        return {"ok": False, "error": "set_dir_missing"}
    jp, _zp, data = _set_manifest(folder, x)
    recs = [r for r in data.get("images") or [] if r.get("from_folder") and os.path.isfile(os.path.join(folder, r.get("file") or ""))]
    if not recs:
        return {"ok": False, "error": "nothing"}
    roots = {os.path.splitdrive(r["from_folder"])[0] or os.path.dirname(os.path.dirname(r["from_folder"])) for r in recs}
    if not all(os.path.isdir(os.path.dirname(r["from_folder"])) or os.path.isdir(r["from_folder"]) for r in recs):
        return {"ok": False, "error": "nas_missing", "roots": sorted(roots)}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        _job.clear()
        _job.update(running=True, finished=False, set=sid, name=x.get("name"), total=len(recs), done=0, errors=[], nerr=0,
                    current="", dir=folder, back=True)
    threading.Thread(target=_unrun, args=(sid, folder, recs), daemon=True).start()
    return {"ok": True, "total": len(recs)}


# --------------------------------------------------------------------------- dzēšana no NAS (2026-11-11)

def _zip_drop(zp: str, stems: set) -> None:
    """Sīktēlu zip bez šīm bildēm."""
    if not zp or not os.path.isfile(zp):
        return
    names = {s + ".jpg" for s in stems}
    try:
        with zipfile.ZipFile(zp) as z:
            infos = z.infolist()
            keep = [(i, z.read(i)) for i in infos if i.filename not in names]
    except (OSError, zipfile.BadZipFile):
        return
    if len(keep) == len(infos):
        return
    tmp = zp + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_STORED) as z:
        for i, b in keep:
            z.writestr(i, b)
    os.replace(tmp, zp)


def nas_delete(stems: list) -> dict:
    """Bildes (+ RAW/xmp ar to pašu nosaukumu) no gatavo mapes → `<gatavo>/_Izdzestas/<datums>/<sūtījuma mape>/`;
    "izdzēsta" — tikai Tirgotāja uzskaitē (Vārdotāja manifestu nemaina; dati §7a vienkāršotā kārtība 7); izņem no
    nepārvietotiem komplektiem."""
    ready = str(stock.config.get("sub_ready_dir") or "").strip()
    if not ready or not os.path.isdir(ready):
        return {"ok": False, "error": "no_nas"}
    want = {str(s) for s in stems or [] if s}
    if not want:
        return {"ok": False, "error": "empty"}
    items = {it["stem"]: it for it in stock.scan().get("items") or [] if it["stem"] in want}
    rr = os.path.normcase(os.path.realpath(ready)) + os.sep
    sd = stock.set_dir()
    sdr = os.path.normcase(os.path.realpath(sd)) + os.sep if sd else None
    trash = os.path.join(ready, stock.TRASH, date.today().isoformat())
    errors, done = [], set()
    for stem in want:
        it = items.get(stem)
        if not it:
            errors.append(f"{stem}: nav atrasta")
            continue
        p = it.get("path") or ""
        rp = os.path.normcase(os.path.realpath(p)) if p else ""
        if it.get("remote") or not p or not os.path.isfile(p):
            errors.append(f"{it['file']}: remote")
            continue
        if not rp.startswith(rr) or (sdr and rp.startswith(sdr)):
            errors.append(f"{it['file']}: not_nas")
            continue
        folder = os.path.dirname(p)
        dst = os.path.join(trash, os.path.relpath(folder, ready))
        try:
            os.makedirs(dst, exist_ok=True)
            base = os.path.splitext(it["file"])[0]
            for f in os.listdir(folder):
                fp = os.path.join(folder, f)
                if os.path.isfile(fp) and (os.path.splitext(f)[0] == base or f.startswith(it["file"] + ".")):
                    t = os.path.join(dst, f)
                    if os.path.exists(t):
                        t = os.path.join(dst, f"{os.path.splitext(f)[0]}_{stock._now()[11:19].replace(':', '')}{os.path.splitext(f)[1]}")
                    shutil.move(fp, t)
            done.add(stem)
        except Exception as e:
            errors.append(f"{it['file']}: {type(e).__name__}: {e}"[:200])
    if done:
        stock.nas_mark(done, "deleted", trash)
    st = stock.sets_store()
    with st.lock:
        ch = False
        for x in st.data.values():
            if x.get("rel") or not x.get("stems"):
                continue
            left = [s for s in x["stems"] if s not in done]
            if len(left) != len(x["stems"]):
                x["stems"], ch = left, True
        if ch:
            st.save()
    if done:
        print(f"izdzēstas no NAS: {len(done)} bildes → {trash}")
    return {"ok": True, "done": len(done), "errors": errors[:10], "nerr": len(errors), "dir": trash}


def purge_trash() -> int:
    """`_Izdzestas/<datums>` mapes, vecākas par 30 dienām — dzēš pavisam."""
    ready = str(stock.config.get("sub_ready_dir") or "").strip()
    d = os.path.join(ready, stock.TRASH) if ready else ""
    if not d or not os.path.isdir(d):
        return 0
    n = 0
    for name in os.listdir(d):
        try:
            if (date.today() - date.fromisoformat(name)).days > stock.TRASH_DAYS:
                shutil.rmtree(os.path.join(d, name), ignore_errors=True)
                n += 1
        except ValueError:
            continue
    try:
        if not os.listdir(d):
            os.rmdir(d)
    except OSError:
        pass
    if n:
        print(f"_Izdzestas: {n} mapes vecākas par {stock.TRASH_DAYS} dienām — dzēstas pavisam")
    return n
