"""Krājums: gatavās bildes (no Vārdotāja manifestiem) × aģentūras, prasību pārbaude un iesniegumu uzskaite.

Avots — iesniegšanai gatavo bilžu mape (Vārdotājs 0.9.0-test9+: <gads>/<YYYY-MM>_<Sērija>_<kods>/RF|ED/), katrā bilžu
mapē .fotostokeris/<sērija>.json (+ -sikteli.zip). Moduļi viens otru neimportē — tikai dati (noteikumi §10, dati §7a).
Komplekti pēc pārvietošanas (move.py) dzīvo komplektu mapē (OneDrive `STOCK/<gads>/<MM-mēn>/<nedēļa>/<KAT-tēma-N>`) ar savu
.fotostokeris/<komplekts>.json — scan() lasa abas mapes.
Uzskaite — ledger.json Tirgotāja datu mapē: {stem: {aģentūra: {"state", "at", "reason", "set", "hist": [...]}}}; stem = faila nosaukums bez
paplašinājuma (pēc Vārdotāja pārdēvēšanas tas ir unikāls: <kods>_<oriģinālais>).
"""
from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import config

SUB = "_fotostokeris"                 # lēmums 2026-11-05: bez punkta (Synology Drive u.c. mapes ar punktu nesinhronizē)
SUBS = ("_fotostokeris", ".fotostokeris")   # lasa abas (vecās — ar punktu)
TRASH = "_Izdzestas"                          # no NAS izdzēstās bildes (30 dienas, tad pavisam; 2026-11-11)
TRASH_DAYS = 30
STATES = ("uploaded", "submitted", "accepted", "rejected", "skip")   # uploaded = augšupielādēts ar FTP, portālā vēl jāspiež "Submit"     # "" = vēl nav iesniegts; "skip" = lietotājs: neder šai aģentūrai

# Aģentūras, kurās Tirgotājs palīdz iesniegt (Bigstock jaunu saturu vairs nepieņem — docs/tirgotajs-iesniegsana.md)
AGENCIES = [
    {"id": "adobe", "name": "Adobe Stock", "url": "https://contributor.stock.adobe.com/", "ftp": "SFTP*"},
    {"id": "shutterstock", "name": "Shutterstock", "url": "https://submit.shutterstock.com/", "ftp": "FTPS", "limit": [500, 7]},
    {"id": "istock", "name": "iStock / Getty", "url": "https://esp.gettyimages.com/", "ftp": ""},
    {"id": "alamy", "name": "Alamy", "url": "https://www.alamy.com/myupload/Index.aspx", "ftp": "FTP"},
    {"id": "dreamstime", "name": "Dreamstime", "url": "https://www.dreamstime.com/upload", "ftp": "FTP"},
    {"id": "depositphotos", "name": "Depositphotos", "url": "https://depositphotos.com/", "ftp": "FTP"},
    {"id": "123rf", "name": "123RF", "url": "https://www.123rf.com/contributor/", "ftp": "FTP"},
    {"id": "pond5", "name": "Pond5", "url": "https://www.pond5.com/", "ftp": "FTP"},
    {"id": "envato", "name": "Envato", "url": "https://portfolio.author.envato.com/", "ftp": "FTPS"},
    {"id": "magnific", "name": "Magnific", "url": "https://contributor.magnific.com/dashboard", "ftp": "FTP*"},   # 200 mēnesī — kalendārais mēnesis (LIMIT_DEF), ne 30 dienas
    {"id": "pixta", "name": "PIXTA", "url": "https://pixtastock.com/", "ftp": ""},
    # 2026-11-04 (lietotājs): arī Zoonar un Ingram (Analītiķa aģentūras); FTP adrese — no konta, kad lietotājs to atsūtīs
    {"id": "zoonar", "name": "Zoonar", "url": "https://www.zoonar.com/", "ftp": "FTPS"},
    {"id": "ingram", "name": "Ingram", "url": "https://www.ingramportal.com/", "ftp": "FTP*"},
]
AG_IDS = [a["id"] for a in AGENCIES]

# FTP noklusējumi no izpētes (docs/tirgotajs-iesniegsana.md); host "" — adrese jāņem no aģentūras konta
FTP_DEF = {
    "adobe": {"proto": "sftp", "host": "sftp.contributor.adobestock.com", "port": 22, "note": "ftp_n_adobe"},
    "shutterstock": {"proto": "ftps", "host": "ftps.shutterstock.com", "port": 21, "note": "ftp_n_login"},
    "alamy": {"proto": "ftp", "host": "upload.alamy.com", "port": 21, "note": "ftp_n_login", "dir": "Stock"},
    "dreamstime": {"proto": "ftp", "host": "upload.dreamstime.com", "port": 21, "note": "ftp_n_dreamstime"},
    "depositphotos": {"proto": "ftp", "host": "ftp.depositphotos.com", "port": 21, "note": "ftp_n_account"},
    "123rf": {"proto": "ftp", "host": "ftp.123rf.com", "port": 21, "note": "ftp_n_login"},
    "pond5": {"proto": "ftp", "host": "ftp.pond5.com", "port": 21, "note": "ftp_n_pond5"},
    "zoonar": {"proto": "ftps", "host": "ftp.zoonar.com", "port": 21, "note": "ftp_n_zoonar"},   # lietotājs 2026-11-04: explicit TLS, passive
    "ingram": {"proto": "ftp", "host": "", "port": 21, "note": "ftp_n_ingram"},   # pieejas dati — jāprasa Ingram; mape Contributor_Folder_XXXXXX
    # lietotājs 2026-11-12: Envato portālā "Upload via FTP"; parole = Envato API tokens; bildes tikai mapē photos/
    "envato": {"proto": "ftps", "host": "ftp.aws.portfolio.envato.com", "port": 21, "dir": "photos", "note": "ftp_n_envato"},
    "magnific": {"proto": "sftp", "host": "uploads.magnific.com", "port": 60022, "dir": "photo", "note": "ftp_n_magnific"},   # lietotājs 2026-11-13 (viens SFTP visiem resursiem; bija contributor-ftp)
}


def conn(ag: str) -> dict:
    """Aģentūras pieslēgums (iestatījums sub_conn): {mode: portal|ftp, url, proto, host, port}."""
    c = dict(((config.get("sub_conn") or {}).get(ag)) or {})
    base = next((a for a in AGENCIES if a["id"] == ag), {})
    d = FTP_DEF.get(ag) or {}
    c["mode"] = c.get("mode") if c.get("mode") in ("portal", "ftp") and (c.get("mode") != "ftp" or d) else "portal"
    url = str(c.get("url") or "").strip()
    c["url"] = url if re.match(r"^https?://", url) else base.get("url", "")
    for k in ("proto", "host", "port", "dir"):
        if not c.get(k) and d.get(k):
            c[k] = d[k]
    try:
        c["limit"] = max(0, int(c["limit"])) if str(c.get("limit", "")).strip() != "" else LIMIT_DEF.get(ag, 0)
    except (TypeError, ValueError):
        c["limit"] = LIMIT_DEF.get(ag, 0)
    c["host"] = clean_host(c.get("host"))
    if c["host"] in OLD_HOSTS:                       # aģentūra nomainījusi serveri — vecais saglabātais vairs nestrādā
        c["host"] = OLD_HOSTS[c["host"]]
    return c


LIMIT_DEF = {"magnific": 200}   # mēneša augšupielāžu norma (lietotājs 2026-11-19); iestatījumos maināms, 0 — nav
SENT = ("uploaded", "submitted", "accepted", "rejected")
_mcache: dict = {"t": 0.0, "month": "", "used": {}}


def _month(at: str) -> str:
    try:
        return datetime.fromisoformat(str(at)).astimezone().strftime("%Y-%m")
    except ValueError:
        return str(at)[:7]


def month_used(month: str = "") -> dict:
    """Cik bilžu katrai aģentūrai šajā kalendārajā mēnesī nosūtīts pirmo reizi (lietotājs 2026-11-19): katrai bildei
    agrākais `uploaded/submitted/accepted/rejected` laiks (arī vēsturē) — skaitās tajā mēnesī. Atkārtota sūtīšana
    neskaitās otrreiz; iepriekšējā mēneša komplekts, iesniegts tagad — skaitās tagad. Kešs ~20 s."""
    import time
    month = month or datetime.now().strftime("%Y-%m")
    if _mcache["month"] == month and time.time() - _mcache["t"] < 20:
        return _mcache["used"]
    used: dict = {}
    for rec in ledger().data.values():
        for ag, c in rec.items():
            if not isinstance(c, dict):
                continue
            ats = [str(e.get("at") or "") for e in [c] + list(c.get("hist") or []) if e.get("state") in SENT and e.get("at")]
            if ats and _month(min(ats)) == month:
                used[ag] = used.get(ag, 0) + 1
    _mcache.update(t=time.time(), month=month, used=used)
    return used


def month_left(ag: str):
    """Atlikušais šomēnes vai None (limita nav)."""
    lim = conn(ag).get("limit") or 0
    return max(0, lim - month_used().get(ag, 0)) if lim else None


def limits() -> dict:
    u = month_used()
    return {a["id"]: {"used": u.get(a["id"], 0), "limit": conn(a["id"]).get("limit") or 0} for a in AGENCIES}


OLD_HOSTS = {"contributor-ftp.magnific.com": "uploads.magnific.com"}   # Magnific 2026-11-13: vecais SFTP vairs netiek atbalstīts


def clean_host(h) -> str:
    """Aģentūru lapās adrese mēdz būt ar priedēkli (sftp://contributor-ftp.magnific.com) — atstāj tikai servera vārdu."""
    h = re.sub(r"^[a-z]+://", "", str(h or "").strip(), flags=re.I)
    return h.split("/")[0].strip()


def portal_urls() -> set:
    return {a["url"] for a in AGENCIES} | {conn(a)["url"] for a in AG_IDS}

_lock = threading.RLock()
_ledger: config.JsonStore | None = None
_specs: dict | None = None
_zips: dict[str, str] = {}            # sērijas atslēga → sīktēlu zip ceļš (sīktēlu GET adresei)
_alt: dict[str, str] = {}             # stem → cits zip (Google kopija), ja sūtījuma zip šīs bildes nav
_paths: dict[str, str] = {}           # stem → bildes ceļš (lielajam skatam GET /full)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ledger() -> config.JsonStore:
    global _ledger
    if _ledger is None:
        _ledger = config.JsonStore(config.app_dir() / "ledger.json", {})
    return _ledger


def specs() -> dict:
    global _specs
    if _specs is None:
        p = Path(__file__).resolve().parent.parent / "core" / "agency_specs.json"
        if not p.is_file():
            p = Path(__file__).resolve().parent.parent.parent / "core" / "agency_specs.json"   # izstrādē
        try:
            _specs = json.loads(p.read_text(encoding="utf-8")).get("agencies") or {}
        except Exception:
            _specs = {}
    return _specs


def agencies() -> list[dict]:
    """Aģentūras, ko rādīt: Tirgotāja izvēle → kopīgās mērķa aģentūras → visas."""
    sel = config.get("sub_agencies") or []
    if not sel:
        tgt = config.get("target_agencies") or []
        sel = [a for a in tgt if a in AG_IDS]
    ids = [a for a in AG_IDS if a in sel] if sel else AG_IDS
    out = []
    for a in AGENCIES:
        if a["id"] in ids:
            c = conn(a["id"])
            ml = {"used": month_used().get(a["id"], 0), "limit": c["limit"]} if c.get("limit") else None
            out.append({**a, "url": c["url"], "mode": c["mode"], **({"mlim": ml} if ml else {})})
    return out


# --------------------------------------------------------------------------- bilžu saraksts no manifestiem

IMG_EXT = (".jpg", ".jpeg", ".tif", ".tiff", ".png")


def _manifests(root: str, files: dict | None = None):
    """Sērijas manifesti `.fotostokeris/*.json`; files — {faila nosaukums: ceļš} visām bildēm (rezerves meklēšanai)."""
    for d, dirs, fl in os.walk(root):
        base = os.path.basename(d)
        if base in SUBS:
            dirs[:] = []
            for f in sorted(fl):
                if f.endswith(".json") and not f.endswith(".tmp"):
                    yield os.path.dirname(d), os.path.join(d, f)
            continue
        if files is not None:
            for f in fl:
                if f.lower().endswith(IMG_EXT):
                    files.setdefault(f, os.path.join(d, f))
        dirs[:] = [x for x in dirs if x in SUBS or (not x.startswith(".") and x.lower() not in ("manifesti", "original", TRASH.lower()))]


_said: set[str] = set()


def _say(m: str) -> None:
    """Žurnālā katru skenēšanas piezīmi vienreiz (ne pie katra "Atjaunot")."""
    if m not in _said:
        _said.add(m)
        print("skenēšana:", m)


def _roots() -> list[str]:
    """Gatavo bilžu mape + komplektu mape (ja nav viena otrā)."""
    out = []
    for r in (str(config.get("sub_ready_dir") or "").strip(), set_dir()):
        if not r or not os.path.isdir(r):
            continue
        rr = os.path.realpath(r)
        if any(rr == x or rr.startswith(x + os.sep) for x in map(os.path.realpath, out)):
            continue
        out = [x for x in out if not os.path.realpath(x).startswith(rr + os.sep)] + [r]
    return out


def _drive_manifests() -> list[str]:
    """Vārdotāja sūtījumi no Google `Fotostokeris/Sutijumi` (drive.py lejupielādē datu mapē `Sutijumi-drive/`)."""
    d = Path(config.app_dir()) / "Sutijumi-drive"
    try:
        return [str(d / f) for f in sorted(os.listdir(d)) if f.endswith(".json") and not f.startswith("_")]
    except OSError:
        return []


_ED_RE = re.compile(r"^[^:\n]{3,90}\b(19|20)\d{2}\s*:")


def ed_text(desc, prefix=None) -> bool:
    """Apraksts sākas kā ED paraksts ("RIGA, LATVIA – MAY 4, 2024: …", "OCTOBER 4, 2025: …") — RF bildei tas nozīmē, ka
    Vārdotājs kategoriju noteica pēc mapes, lai gan bilde aprakstīta kā ED (lietotājs 2026-11-10; NODOSANA 6g)."""
    d = str(desc or "").strip()
    if not d:
        return False
    if prefix and d.startswith(str(prefix).strip()):
        return True
    return bool(_ED_RE.match(d))


def scan() -> dict:
    root = str(config.get("sub_ready_dir") or "").strip()
    drv = _drive_manifests()
    if not root and not drv:
        return {"ok": True, "items": [], "series": [], "no_dir": True}
    if root and not os.path.isdir(root):
        if not drv:
            return {"ok": False, "error": "dir_missing", "dir": root, "items": [], "series": []}
        _say(f"gatavo mape {root} nav pieejama — rāda tikai Google Drive manifestus")
        root = ""
    items, series = [], []
    seen: set[str] = set()
    seen_at: dict[str, str] = {}
    seen_orig: set[str] = set()
    seen_ph: set[tuple] = set()
    sids: set[str] = set()
    files: dict[str, str] = {}
    _zips.clear()
    _alt.clear()
    # komplektu mape (OneDrive) PIRMĀ: ja tā pati bilde vēl ir arī gatavo mapē (piem. Mac Synology kopija vēl nav
    # izdzēsta, 2026-11-05), noteicošā ir komplekta mape — citādi komplekts rādās "vēl gatavo mapē"
    sd = set_dir()
    roots = sorted(_roots(), key=lambda r: 0 if sd and os.path.realpath(r) == os.path.realpath(sd) else 1)
    found = [m for r in roots for m in _manifests(r, files)]
    nas = nas_store().data
    skipped = []
    mnames: set[str] = set()
    mupd: dict[str, str] = {}               # Drive manifesta sērija → `updated` (pārbaudei "NAS nav")

    def take(folder, jpath, data, zpath, remote_ok=False):
        key = f"s{len(series)}"
        if zpath and os.path.isfile(zpath):
            _zips[key] = zpath
        n = 0
        own = bool(data.get("set_id") or data.get("kind") == "set")      # komplekts — mūsu pašu manifests
        for it in data.get("images") or []:
            if not it.get("file"):
                continue
            mnames.add(it["file"].lower())
            if not own:
                st0 = it.get("stem") or os.path.splitext(it["file"])[0]
                r = (nas.get(st0) or {}).get("st")
                if r in ("moved", "deleted") or (it.get("status") in ("moved", "deleted") and r != "back"):
                    continue
            p = os.path.join(folder, it["file"]) if folder else ""
            if not (p and os.path.isfile(p)):
                p = it.get("path") if it.get("path") and os.path.isfile(it.get("path")) else files.get(it["file"], "")
            remote = False
            if not p or not os.path.isfile(p):
                if not remote_ok:
                    continue
                p, remote = "", True                      # Drive manifests: bilde ir NAS, šajā datorā nav (test21)
            stem = it.get("stem") or os.path.splitext(it["file"])[0]
            okey = str(it.get("orig_file") or it["file"]).lower()
            if remote and (okey in seen_orig or (it.get("phash") and (it["phash"], it.get("taken_at")) in seen_ph)):
                continue                    # tā pati bilde ar citu nosaukumu (Vārdotāja darba mapes manifests; test22)
            if stem in seen:
                if p and os.path.normcase(p) != os.path.normcase(seen_at.get(stem, p) or p):
                    _say(f"bilde {it['file']} ir divās vietās — ņemta {os.path.dirname(seen_at[stem])}, otra {os.path.dirname(p)}")
                continue
            seen_at[stem] = p
            seen.add(stem)
            seen_orig.add(okey)
            if it.get("phash"):
                seen_ph.add((it["phash"], it.get("taken_at")))
            try:
                size = os.path.getsize(p) if p else int(it.get("bytes") or 0)
            except (OSError, ValueError, TypeError):
                size = 0
            n += 1
            if remote and zpath and os.path.isfile(zpath):
                _alt.setdefault(stem, zpath)
            cat = it.get("category") or "RF"
            edw = cat == "RF" and ed_text(it.get("description"), it.get("ed_prefix"))
            items.append({
                **({"remote": True} if remote else {}),
                **({"edwarn": True} if edw else {}),
                **({"edp": True} if cat == "RF" and it.get("ed_prefix") else {}),
                "stem": stem, "file": it["file"], "orig": it.get("orig_file") or it["file"], "path": p,
                "folder": os.path.dirname(p) if p else "", "series": key, "cat": cat, "ready": it.get("status") == "ready",
                "title": it.get("title") or "", "kw": len(it.get("keywords") or []), "hint": str(it.get("hint") or "")[:80],
                "w": int(it.get("width") or 0), "h": int(it.get("height") or 0), "size": size,
                "ext": os.path.splitext(it["file"])[1].lower().lstrip("."), "taken": it.get("taken_at") or "",
                "thumb": True, "phash": it.get("phash") or "", "jpath": jpath, "zpath": _zips.get(key) or _alt.get(stem, ""),
                "src_name": it.get("series_name") or data.get("name") or "",
                "kwtext": "|".join(str(k).lower() for k in it.get("keywords") or [])})
        if n:
            f0 = folder or os.path.dirname(next((i["path"] for i in items if i["series"] == key and i["path"]), "") or "")
            series.append({"key": key, "name": data.get("name") or os.path.basename(f0),
                           "code": data.get("series_code") or "", "folder": f0, "count": n,
                           **({"set": data["set_id"]} if data.get("set_id") else {}),
                           **({"remote": True} if not f0 else {})})
        return n

    for folder, jpath in found:
        try:
            data = json.loads(Path(jpath).read_text(encoding="utf-8"))
        except Exception as e:
            skipped.append(f"{jpath}: nevar nolasīt ({type(e).__name__})")
            continue
        sid = str(data.get("series_id") or "")
        if sid:
            sids.add(sid)
        z = os.path.join(os.path.dirname(jpath), data.get("thumbs") or "") if data.get("thumbs") else ""
        if not take(folder, jpath, data, z):
            skipped.append(f"{jpath}: nav atrastu bilžu")
    # Google `Sutijumi` (Vārdotāja sūtījumi; dati §7a vienkāršotā kārtība 7): bildes, kas vēl nav redzētas — arī tās,
    # kuru šajā datorā nav ("uz NAS")
    nrem = 0
    for jp in drv:
        try:
            data = json.loads(Path(jp).read_text(encoding="utf-8"))
        except Exception:
            continue
        if data.get("kind") == "set" or data.get("set_id"):
            continue
        if sid := str(data.get("series_id") or ""):
            if sid in sids:
                continue
        before = len(items)
        take(None, jp, data, jp[:-5] + "-sikteli.zip", remote_ok=True)
        if len(items) > before:
            mupd[items[before]["series"]] = str(data.get("updated") or data.get("created") or "")
        nrem += sum(1 for it in items[before:] if it.get("remote"))
    if nrem:
        _say(f"{nrem} bildes no Google Drive manifestiem šajā datorā nav (uz NAS)")
    for m in skipped[:20]:
        _say(m)
    _paths.clear()
    _paths.update({it["stem"]: it["path"] for it in items if it["path"]})
    out = {"ok": True, "items": items, "series": series}
    if root:
        try:
            out["nascheck"] = _nas_check(root, files, mnames, items, series, mupd)
        except Exception as e:
            print("NAS pārbaude neizdevās:", e)
    return out


def _ship(root: str, p: str) -> str:
    """Sūtījuma mape (relatīvi pret gatavo mapi): `2026/2026-09_Bali_949f` (RF/ED apakšmape — nē)."""
    rel = os.path.relpath(os.path.dirname(p), root).replace("\\", "/")
    parts = [x for x in rel.split("/") if x and x != "."]
    if parts and parts[-1].upper() in ("RF", "ED", "EDI"):
        parts = parts[:-1]
    return "/".join(parts[:2]) or "."


def _nas_check(root: str, files: dict, mnames: set, items: list, series: list, mupd: dict) -> dict:
    """NAS ⇄ manifestu pārbaude (lietotājs 2026-11-24: "tikai pārbaude un brīdinājums, labotu visu Vārdotājs").
    Tirgotājs neko nemaina: (a) bildes NAS bez manifesta; (b) bilde RF/ED mapē, kas nesakrīt ar manifesta kategoriju;
    (c) Drive manifestā ir (vecāks par 6 h), NAS faila nav. Atgriež {nomani|cat|missing: {mape: skaits}}."""
    # NE realpath katram failam: Windows to dara, atverot failu — uz NAS (tīkls) simtiem failu = ļoti lēni
    # (2026-11-26: Tirgotājs "bremzējās" pēc katra klikšķa). Pietiek ar teksta salīdzinājumu.
    rr = os.path.normcase(os.path.abspath(root)).rstrip("\\/") + os.sep
    under = lambda p: bool(p) and os.path.normcase(os.path.abspath(p)).startswith(rr)
    res = {"nomani": {}, "cat": {}, "missing": {}}
    for name, p in files.items():
        if under(p) and name.lower() not in mnames and f"{os.sep}{TRASH}{os.sep}" not in p:
            k = _ship(root, p)
            res["nomani"][k] = res["nomani"].get(k, 0) + 1
    for it in items:
        p = it.get("path")
        if under(p):
            sub = os.path.basename(os.path.dirname(p)).upper()
            if sub in ("RF", "ED") and sub != ("ED" if it.get("cat") in ("ED", "EDI") else "RF"):
                k = _ship(root, p)
                res["cat"][k] = res["cat"].get(k, 0) + 1
    from datetime import datetime, timedelta, timezone
    old = (datetime.now(timezone.utc) - timedelta(hours=6)).isoformat()
    names = {x["key"]: x["name"] for x in series}
    for it in items:
        if it.get("remote") and (mupd.get(it["series"]) or "9") < old:
            k = names.get(it["series"]) or it["series"]
            res["missing"][k] = res["missing"].get(k, 0) + 1
    res = {k: v for k, v in res.items() if v}
    if res:
        _say("NAS pārbaude: " + "; ".join(f"{k}: " + ", ".join(f"{a} {b}" for a, b in v.items()) for k, v in res.items())[:600])
    return res


# --------------------------------------------------------------------------- prasību pārbaude (core/agency_specs.json)

def check(it: dict, ag: str) -> list[list]:
    """Iemesli, kāpēc bilde neder aģentūrai: [[atslēga, {vērtības}], …] (teksti — saskarnē)."""
    out = []
    cat = it.get("cat") or "RF"
    if cat in ("ED", "EDI"):
        ed = config.get("sub_ed_agencies")
        ed = ed if isinstance(ed, list) else []
        edi = config.get("sub_edi_agencies")
        edi = edi if isinstance(edi, list) else []
        if cat == "ED" and ag not in ed:                       # parasts ED — tikai, kur atzīmēts ED
            out.append(["r_ed", {}])
        elif cat == "EDI" and ag not in ed and ag not in edi:  # EDI — kur atzīmēts ED vai EDI
            out.append(["r_edi", {}])
    s = specs().get(ag) or {}
    if cat in ("ED", "EDI") and s.get(cat.lower()) is False and not out:    # aģentūra pati nepieņem (piem. Ingram)
        out.append(["r_ed_ag", {}])
    ext = {"jpeg": "jpg", "tiff": "tif"}.get(it["ext"], it["ext"])
    fm = s.get("formats")
    if fm and ext not in fm:
        out.append(["r_fmt", {"f": ext.upper(), "ok": ", ".join(x.upper() for x in fm)}])
    mb = it["size"] / 1048576                                  # 0 = nezināms (Drive manifests bez `bytes`)
    if s.get("max_mb") and mb > s["max_mb"]:
        out.append(["r_big", {"mb": round(mb, 1), "max": s["max_mb"]}])
    if s.get("min_mb") and it["size"] and mb < s["min_mb"]:
        out.append(["r_small_mb", {"mb": round(mb, 1), "min": s["min_mb"]}])
    w, h = it["w"], it["h"]
    if w and h:
        mp = w * h / 1e6
        if s.get("min_mp") and mp < s["min_mp"]:
            out.append(["r_min_mp", {"mp": round(mp, 1), "min": s["min_mp"]}])
        if s.get("max_mp") and mp > s["max_mp"]:
            out.append(["r_max_mp", {"mp": round(mp, 1), "max": s["max_mp"]}])
        if s.get("min_side_px") and min(w, h) < s["min_side_px"]:
            out.append(["r_side", {"px": min(w, h), "min": s["min_side_px"]}])
        if s.get("min_long_px") and max(w, h) < s["min_long_px"]:
            out.append(["r_long_min", {"px": max(w, h), "min": s["min_long_px"]}])
        if s.get("max_long_px") and max(w, h) > s["max_long_px"]:
            out.append(["r_long_max", {"px": max(w, h), "max": s["max_long_px"]}])
    return out


def listing() -> dict:
    r = scan()
    led = ledger().data
    ags = agencies()
    mem: dict[str, list] = {}
    for x in sets_store().data.values():
        for st in x.get("stems") or []:
            mem.setdefault(st, []).append(x.get("id"))
    r["sets"] = [{"id": x.get("id"), "name": x.get("name"), "stems": list(x.get("stems") or [])} for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True)]
    plan = {st: x["planned"] for x in sets_store().data.values() if x.get("planned") for st in x.get("stems") or []}
    from . import drive
    ext_s, ext_o = drive.ext_index()
    for it in r["items"]:
        it["in_sets"] = mem.get(it["stem"], [])
        if it["stem"] in plan:
            it["planned"] = plan[it["stem"]]
        rec = led.get(it["stem"]) or {}
        ext = ext_s.get(it["stem"]) or ext_o.get(str(it.get("orig") or "").lower()) or {}
        cells = {}
        for a in ags:
            c = dict(rec.get(a["id"]) or {})
            bad = check(it, a["id"])
            if bad:
                c["bad"] = bad
            if ext.get(a["id"]) and not c.get("state") and c.get("as") != "ED":   # ED kopiju var sūtīt arī pēc RF noraidījuma
                c["ext"] = ext[a["id"]]                   # jau aģentūrā (Analītiķis, dati §8c) — nepiedāvā
            if ext.get(a["id"]):                          # Analītiķa statuss vienmēr (test45) — skaitīšanai/rādīšanai
                c["ag_st"] = ext[a["id"]].get("status") or ""
                c["ag_seen"] = ext[a["id"]].get("seen") or ""
            cells[a["id"]] = c
        it["cells"] = cells
    # ierakstiem uzskaitē, kuru bilžu mapē vairs nav (pārvietotas / dzēstas) — tikai skaits
    have = {it["stem"] for it in r["items"]}
    r["gone"] = sum(1 for s in led if s not in have)
    r["agencies"] = ags
    return r


HIST = 30


def _set_of(stem: str) -> str:
    """Jaunākais komplekts, kurā ir bilde."""
    best = ("", "")
    for x in sets_store().data.values():
        if stem in (x.get("stems") or []) and x.get("created", "") >= best[0]:
            best = (x.get("created", ""), x.get("id", ""))
    return best[1]


def mark(stems: list, ag: str, state: str, reason: str = "", set_id: str = "") -> int:
    """Atzīme ar vēsturi: iepriekšējais stāvoklis pāriet uz "hist" (kas, kad, kurā komplektā)."""
    if ag not in AG_IDS or (state and state not in STATES):
        raise ValueError("bad state")
    st = ledger()
    n = 0
    with st.lock:
        for s in stems:
            rec = st.data.setdefault(str(s), {})
            old = rec.get(ag) or {}
            hist = list(old.get("hist") or [])
            if old.get("state"):
                hist.append({k: v for k, v in old.items() if k != "hist"})
            if state:
                sid = set_id or _set_of(str(s))
                rec[ag] = {"state": state, "at": _now(), **({"reason": reason} if reason else {}),
                           **({"set": sid} if sid else {}), **({"as": old["as"]} if old.get("as") else {}),
                           **({"hist": hist[-HIST:]} if hist else {})}
            elif hist:
                rec[ag] = {"state": "", "at": _now(), "hist": hist[-HIST:]}     # atzīme noņemta — vēsture paliek
            else:
                rec.pop(ag, None)
            if not rec:
                st.data.pop(str(s), None)
            n += 1
        st.save()
    return n


def ed_ok(ag: str) -> bool:
    """Aģentūra pieņem ED — lietotāja iestatījumos atzīmēta ED aģentūrām (`sub_ed_agencies`) un pati nav pret."""
    ed = config.get("sub_ed_agencies")
    return ag in (ed if isinstance(ed, list) else []) and (specs().get(ag) or {}).get("ed") is not False


def as_ed(stems: list, ag: str, on: bool = True) -> int:
    """RF ar ED rezervi (6a, dati §7a; lietotājs 2026-11-13 15:06 "jā, ir bijuši"): bildei ar `ed_prefix` šai
    aģentūrai sūtīt kopiju kā ED. Atzīme `as: "ED"` šūnā; iepriekšējais stāvoklis (piem. "noraidīts") → vēsturē,
    šūna atkal brīva sūtīšanai. `on=False` — atpakaļ uz RF."""
    if ag not in AG_IDS:
        raise ValueError("bad agency")
    if on and not ed_ok(ag):
        raise ValueError("no_ed")
    st = ledger()
    n = 0
    with st.lock:
        for s in stems:
            rec = st.data.setdefault(str(s), {})
            old = rec.get(ag) or {}
            hist = list(old.get("hist") or [])
            if old.get("state"):
                hist.append({k: v for k, v in old.items() if k != "hist"})
            rec[ag] = {"state": "", "at": _now(), **({"as": "ED"} if on else {}), **({"hist": hist[-HIST:]} if hist else {})}
            n += 1
        st.save()
    return n


def ledger_merge(base, local, remote):
    """Sinhronizācija (lēmums 2026-11-05): katrai bildei × aģentūrai uzvar jaunākā atzīme (`at`); otras puses atzīme
    pāriet vēsturē — nekas svaigāks netiek pārrakstīts. Ja atzīme vienā pusē izdzēsta (pārējā nemainīta) — dzēsta."""
    base, local, remote = base or {}, local or {}, remote or {}
    out = {}
    for stem in set(local) | set(remote):
        l, r, b = local.get(stem) or {}, remote.get(stem) or {}, base.get(stem) or {}
        rec = {}
        for ag in set(l) | set(r):
            x, y, z = l.get(ag), r.get(ag), b.get(ag)
            if x is None or y is None:
                one = x if y is None else y
                if z is not None and one == z:
                    continue                              # otrā datorā noņemta
                rec[ag] = one
                continue
            win, lose = (x, y) if str(x.get("at") or "") >= str(y.get("at") or "") else (y, x)
            hist, seen = [], set()
            for h in (win.get("hist") or []) + (lose.get("hist") or []) + ([{k: v for k, v in lose.items() if k != "hist"}] if lose.get("state") else []):
                key = (h.get("state"), h.get("at"))
                if key in seen or key == (win.get("state"), win.get("at")):
                    continue
                seen.add(key)
                hist.append(h)
            hist.sort(key=lambda h: str(h.get("at") or ""))
            w = {k: v for k, v in win.items() if k != "hist"}
            if hist:
                w["hist"] = hist[-HIST:]
            rec[ag] = w
        if rec:
            out[stem] = rec
    return out


# --------------------------------------------------------------------------- komplekti (kopsavilkums §3 "Komplekts")
# Komplekts = vienas kategorijas bilžu kopa iesniegšanai visās piemērotajās aģentūrās vienā reizē. Gandrīz vienādas bildes
# (phash attālums ≤ 6, kā Vārdotājā) vienā komplektā nekad; vienas sērijas dažādi kadri — drīkst.
SIMILAR = 6
_sets: config.JsonStore | None = None


def sets_store() -> config.JsonStore:
    global _sets
    if _sets is None:
        _sets = config.JsonStore(config.app_dir() / "sets.json", {})   # {id: komplekts} — vārdnīca, lai sinhronizācija apvieno pa ierakstiem
        ch = False                                                       # vecie nosaukumi → ar licenci priekšā (mapes neaiztiek)
        for x in _sets.data.values():
            cat = x.get("cat") or "RF"
            if not x.get("rel") and not NAME_RE.match(str(x.get("name") or "")):   # test37: vēl nav OneDrive → jaunais nosaukums
                x["name"] = auto_name(x)
                ch = True
            elif not str(x.get("name") or "").upper().startswith(cat + "-") and not NAME_RE.match(str(x.get("name") or "")):
                x["name"] = set_name(x.get("name") or "", cat) or f"{cat}-{str(x.get('created', ''))[:10]}"
                ch = True
        if ch:
            _sets.save()
    return _sets


# Tirgotāja uzskaite par sūtījumu bildēm (dati §7a "vienkāršotā kārtība" 7: Vārdotāja manifestus nemaina — "pārvietota" /
# "izdzēsta" tikai šeit). {stem: {"st": "moved"|"deleted"|"back", "at": ISO, "to": ceļš}}; "back" = atpakaļ uz NAS —
# pārspēj veco manifesta `status: moved` (līdz test30 Tirgotājs to rakstīja Vārdotāja manifestos).
_nas: config.JsonStore | None = None


def nas_store() -> config.JsonStore:
    global _nas
    if _nas is None:
        _nas = config.JsonStore(config.app_dir() / "nas.json", {})
    return _nas


def nas_mark(stems, st: str, to: str = "") -> None:
    s = nas_store()
    with s.lock:
        for stem in stems:
            s.data[stem] = {"st": st, "at": _now(), **({"to": to} if to else {})}
        s.save()


def nas_init() -> int:
    """Vienreiz / katrā startā: pārvietoto komplektu bildes uzskaitē (lai pēc pārejas neatgriežas Krājumā)."""
    s, n = nas_store(), 0
    with s.lock:
        for x in list(sets_store().data.values()):
            if not x.get("rel"):
                continue
            for stem in x.get("stems") or []:
                if stem not in s.data:
                    s.data[stem] = {"st": "moved", "at": x.get("moved_at") or _now(), "to": x["rel"]}
                    n += 1
        if n:
            s.save()
    if n:
        print(f"uzskaite: {n} pārvietotas bildes no komplektu saraksta")
    return n


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _todo(it: dict, ags: list) -> bool:
    """Vai bilde vēl jāiesniedz vismaz vienā aģentūrā (nav atzīmes un der pēc prasībām)."""
    return any(not (c := it["cells"].get(a) or {}).get("state") and not c.get("bad") and not c.get("ext") for a in ags)


def _cat_ok(it: dict, cat: str) -> bool:
    return (it.get("cat") or "RF") == (cat if cat in ("RF", "ED", "EDI") else "RF")     # komplektā viena kategorija


def _matcher(match: str, r: dict):
    """Meklēšana (AI asistents): vārdi sērijas nosaukumā, mapē, virsrakstā, atslēgvārdos, faila nosaukumā."""
    words = [w for w in re.findall(r"[\wāčēģīķļņšūž]+", (match or "").lower()) if len(w) > 1]
    if not words:
        return None
    names = {s["key"]: (s["name"] + " " + s.get("code", "")).lower() for s in r["series"]}

    def text(it):
        return " ".join([names.get(it["series"], ""), it["folder"].lower(), it["title"].lower(), it.get("kwtext", ""),
                         it["file"].lower(), it["orig"].lower()])
    return words, text


GAP_S = 1800      # jauns laika klasteris, ja starp kadriem > 30 min


def _ts(it: dict) -> float:
    try:
        return datetime.fromisoformat(str(it.get("taken") or "")[:19]).timestamp()
    except ValueError:
        return 0.0


def clusters(items: list) -> dict:
    """Bilžu grupas "viena vieta un laiks" (dažādai atlasei, lēmums 2026-11-05 16:27): sērija + vieta (`hint`) +
    laika klasteris (> 30 min starpība = jauns). {stem: klastera id}."""
    out, last = {}, {}
    for it in sorted(items, key=lambda i: (i["series"], i.get("hint") or "", _ts(i), i["file"])):
        k = (it["series"], (it.get("hint") or "").lower())
        t = _ts(it)
        prev = last.get(k)
        if prev is None or (t and prev[1] and t - prev[1] > GAP_S):
            prev = (f"{k[0]}|{k[1]}|{len(out)}", t)
        last[k] = (prev[0], t or prev[1])
        out[it["stem"]] = prev[0]
    return out


def _candidates(r: dict, cat: str, excl: set, only: set | None = None) -> list:
    ags = [a["id"] for a in r["agencies"]]
    in_sets = {st for x in sets_store().data.values() for st in x.get("stems") or []}
    return [it for it in r["items"] if _cat_ok(it, cat) and it["stem"] not in in_sets and it["stem"] not in excl
            and (only is None or it["stem"] in only) and _todo(it, ags)
            and not it.get("edwarn")]                      # "RF ar ED aprakstu" — automātiski RF komplektos neliek (6g)


def _filter(cand: list, match: str, r: dict) -> list:
    m = _matcher(match, r)
    if not m:
        return cand
    words, text = m
    allw = [it for it in cand if all(w in text(it) for w in words)]
    return allw or [it for it in cand if any(w in text(it) for w in words)]


def _ph(it: dict) -> int | None:
    try:
        return int(str(it.get("phash") or ""), 16)
    except ValueError:
        return None


def _spread(g: list) -> list:
    """Vienas vietas/laika grupas secība (lietotājs 2026-11-12 16:40: "bildes pēc kārtas … ļoti līdzīgas"): ne pēc laika,
    bet nejaušs sākums un katra nākamā — visatšķirīgākā no jau paņemtajām (phash attālums + laika attālums)."""
    import random
    if len(g) < 3:
        return list(g)
    left = list(g)
    out = [left.pop(random.randrange(len(left)))]
    span = max(1.0, abs(_ts(g[-1]) - _ts(g[0])) or 1.0) if _ts(g[0]) and _ts(g[-1]) else 1.0
    while left:
        def score(it):
            ph, t = _ph(it), _ts(it)
            d = []
            for o in out:
                po, to = _ph(o), _ts(o)
                v = bin(ph ^ po).count("1") / 64 if ph is not None and po is not None else 0.5
                v += min(1.0, abs(t - to) / span) if t and to else 0.25
                d.append(v)
            return min(d) + random.random() * 0.05
        best = max(range(len(left)), key=lambda i: score(left[i]))
        out.append(left.pop(best))
    return out


def _round_robin(cand: list) -> list:
    """Pa vienai bildei no katras grupas (vieta + laiks) pēc kārtas — komplektā dažādas vietas, ne viss no vienas."""
    cl = clusters(cand)
    groups: dict[str, list] = {}
    for it in sorted(cand, key=lambda i: (_ts(i), i["file"])):
        groups.setdefault(cl[it["stem"]], []).append(it)
    order = sorted((_spread(g) for g in groups.values()), key=lambda g: (-len(g), _ts(g[0])))
    out, i = [], 0
    while any(order):
        for g in order:
            if i < len(g):
                out.append(g[i])
        i += 1
        if all(i >= len(g) for g in order):
            break
    return out


def pretty(name: str) -> str:
    """Sērijas nosaukums cilvēkam: "2026-09_Bali_a1b2" → "Bali"."""
    s = re.sub(r"^\d{4}[-._]\d{2}([-._]\d{2})?[_\s-]*", "", str(name or ""))
    s = re.sub(r"[_-][0-9a-f]{4,6}$", "", s)
    s = re.sub(r"[_-](RF|ED|EDI)$", "", s, flags=re.I)
    return s.replace("_", " ").strip() or str(name or "")


def pool(cat: str, match: str = "", topics: list | None = None, limit: int = 120, exclude: list | None = None,
         r: dict | None = None) -> list:
    """Kandidāti AI redaktoram: dažāda secība (pa vienai no katras vietas/laika grupas), no katras līdzīgo grupas tikai
    viena, ne vairāk par `limit`."""
    from . import similar
    r = r or listing()
    base = _candidates(r, cat, set(exclude or []))
    topics = [t for t in (topics or []) if str(t).strip()][:8]
    lists = [_round_robin(_filter(base, t, r)) for t in topics] if topics else [_round_robin(_filter(base, match, r))]
    out, got = [], set()
    i = 0
    while len(out) < limit and any(i < len(l) for l in lists):
        for l in lists:
            if i < len(l) and l[i]["stem"] not in got:
                it = l[i]
                got.add(it["stem"])
                if not any(similar.similar(it, c, _zips) for c in out if c["series"] == it["series"]):
                    out.append(it)
        i += 1
    return out[:limit]


def themes(cat: str = "", r: dict | None = None) -> list:
    """Neiesniegto, komplektos vēl neiekļauto bilžu tēmas (sērija + vieta) — Plānam un asistentam."""
    r = r or listing()
    names = {s["key"]: s["name"] for s in r["series"]}
    cand = [it for c in ([cat] if cat else ["RF", "ED", "EDI"]) for it in _candidates(r, c, set())]
    out: dict[tuple, dict] = {}
    for it in cand:
        k = (it["series"], (it.get("hint") or "").strip().lower(), it.get("cat") or "RF")
        x = out.setdefault(k, {"key": "|".join(k), "series": it["series"], "name": names.get(it["series"], ""),
                               "hint": (it.get("hint") or "").strip(), "cat": k[2], "stems": [], "newest": ""})
        x["stems"].append(it["stem"])
        x["newest"] = max(x["newest"], it.get("taken") or "")
    lst = list(out.values())
    for x in lst:
        x["n"] = len(x["stems"])
        x["thumb"] = x["stems"][0]
        x["title"] = x["hint"] or pretty(x["name"])
    lst.sort(key=lambda x: -x["n"])
    return lst


def suggest(cat: str = "RF", size: int = 0, exclude: list | None = None, match: str = "", have: list | None = None,
            topics: list | None = None, only: list | None = None, r: dict | None = None) -> dict:
    """Ieteikums: neiesniegtās bildes, viena kategorija; dažāda atlase — pa vienai no katras vietas/laika grupas pēc
    kārtas; `topics` — vairākas tēmas ar vienādu kvotu (trūkumu piepilda citas). Līdzīgās (similar.py) vienā komplektā
    nekad — no grupas paliek pirmā, pārējās atliktas (groups). have — jau komplektā esošās (pievienojot "vēl")."""
    from . import similar
    r = r or listing()
    excl = set(exclude or []) | set(have or [])
    by = {it["stem"]: it for it in r["items"]}
    base = _candidates(r, cat, excl, set(only) if only is not None else None)
    topics = [t for t in (topics or []) if str(t).strip()][:8]
    if topics:
        lists = [_round_robin(_filter(base, t, r)) for t in topics]
        cand_all = {it["stem"] for l in lists for it in l}
    else:
        lists = [_round_robin(_filter(base, match, r))]
        cand_all = {it["stem"] for it in lists[0]}
    todo = len(cand_all)
    auto = max(10, min(50, -(-todo // 20))) if todo else 0      # vienmērīga plūsma: ~20 darba dienās (1 mēnesis)
    size = int(size or 0) or auto
    seed = [by[s] for s in (have or []) if s in by]
    chosen, groups, nsim, got = [], {}, 0, set()
    counts = [0] * len(lists)
    quota = [size // len(lists) + (1 if i < size % len(lists) else 0) for i in range(len(lists))]

    def take(it, ti):
        nonlocal nsim
        if it["stem"] in got:
            return False
        like = next((c for c in seed + chosen if similar.similar(it, c, _zips)), None)
        got.add(it["stem"])
        if like:
            nsim += 1
            groups.setdefault(like["stem"], []).append({k: it[k] for k in ("stem", "file", "series", "thumb", "title")})
            return False
        chosen.append(it)
        counts[ti] += 1
        return True
    for ti, l in enumerate(lists):                       # katrai tēmai sava kvota
        for it in l:
            if counts[ti] >= quota[ti] or len(chosen) >= size:
                break
            take(it, ti)
    if len(chosen) < size:                               # trūkumu piepilda citas tēmas
        for ti, l in enumerate(lists):
            for it in l:
                if len(chosen) >= size:
                    break
                take(it, ti)
    out = [dict(it) for it in chosen]
    for it in out:
        it.pop("kwtext", None)
    import random                                        # komplektā jaukta secība (ne pēc failu nosaukumiem)
    random.shuffle(out)
    return {"ok": True, "items": out, "similar": nsim, "groups": groups, "todo": todo, "auto": auto, "size": size,
            "agencies": r["agencies"], "match": match, "topics": topics,
            "topic_counts": dict(zip(topics, counts)) if topics else {}}


NAME_RE = re.compile(r"^\d{4}-\d{2}-\d{2}-(RF|ED|EDI)-[0-9a-f]{4}$")


def set_code(sid: str) -> str:
    """Komplekta 4 zīmju kods nosaukumā (tie paši pirmie burti kā Google `Komplekti` faila `__<md5[:8]>`)."""
    return hashlib.md5(str(sid).encode("utf-8")).hexdigest()[:4]


def auto_name(x: dict, day: str = "") -> str:
    """Komplekta nosaukums kā Vārdotāja sūtījumam (lēmums 2026-11-12 15:49, dati §7a p.9): `<YYYY-MM-DD>-<VEIDS>-<kods>`;
    datums — iesniegšanas (plāna) diena, bez plāna — izveides diena; tēmas nav."""
    cat = x.get("cat") if x.get("cat") in ("RF", "ED", "EDI") else "RF"
    d = str(day or x.get("planned") or x.get("created") or _now())[:10]
    return f"{d}-{cat}-{set_code(x.get('id') or '')}"


def rename_for_day(x: dict, day: str = "") -> bool:
    """Nosaukums seko plāna dienai, kamēr komplekts nav OneDrive (`rel`); pēc pārvietošanas nemainās."""
    if x.get("rel"):
        return False
    n = auto_name(x, day)
    if x.get("name") == n:
        return False
    x["name"] = n
    return True


def set_name(name: str, cat: str) -> str:
    """Komplekta nosaukums ar licenci priekšā (lēmums 2026-11-04 20:23): "Bali" / "Bali RF" → "RF-Bali"."""
    cat = cat if cat in ("RF", "ED", "EDI") else "RF"
    n = re.sub(r"^\s*(RF|ED|EDI|RFR)\b[\s_-]*", "", str(name or ""), flags=re.I)
    n = re.sub(r"[\s_-]*\b(RF|ED|EDI|RFR)\s*$", "", n, flags=re.I).strip(" -_")
    return f"{cat}-{n}" if n else ""


def set_save(name: str, cat: str, stems: list) -> dict:
    st = sets_store()
    with st.lock:
        sid = f"k{int(datetime.now().timestamp() * 1000)}"
        rec = {"id": sid, "cat": cat, "created": _now(), "stems": list(stems)}
        rec["name"] = auto_name(rec)                       # `name` (tēma) vairs netiek lietots (lēmums 2026-11-12 15:49)
        st.data[sid] = rec
        st.save()
    return rec


def set_add(sid: str, stems: list) -> dict:
    """Atlasītās bildes pievieno esošam komplektam (tikai tās pašas kategorijas, ne jau citā komplektā)."""
    st = sets_store()
    r = listing()
    by = {it["stem"]: it for it in r["items"]}
    with st.lock:
        x = st.data.get(sid)
        if not x:
            raise ValueError("no_set")
        have = set(x.get("stems") or [])
        in_other = {s for k, y in st.data.items() if k != sid for s in y.get("stems") or []}
        add, skipped = [], 0
        for s in stems:
            it = by.get(s)
            if not it or s in have or s in in_other or (it.get("cat") or "RF") != (x.get("cat") or "RF"):
                skipped += 1
                continue
            add.append(s)
        x["stems"] = list(x.get("stems") or []) + add
        st.save()
    return {"ok": True, "added": len(add), "skipped": skipped, "name": x.get("name"), "moved": bool(x.get("rel"))}


def set_remove(sid: str, stems: list) -> dict:
    """Izņem bildes no komplekta (Atlasīt pašam). Jau OneDrive pārvietotam komplektam — nē (faili ir tā mapē)."""
    st = sets_store()
    with st.lock:
        x = st.data.get(sid)
        if not x:
            raise ValueError("no_set")
        if x.get("rel"):
            raise ValueError("moved")
        rm = set(stems)
        before = len(x.get("stems") or [])
        x["stems"] = [s for s in x.get("stems") or [] if s not in rm]
        st.save()
    return {"ok": True, "removed": before - len(x["stems"]), "name": x.get("name"), "left": len(x["stems"])}


def sim_check(stems: list) -> dict:
    """Atlasīto bilžu savstarpēja līdzība (Atlasīt pašam): {stem: [līdzīgie]}."""
    from . import similar
    by = {it["stem"]: it for it in scan()["items"]}
    its = [by[s] for s in stems if s in by][:200]
    out: dict[str, list] = {}
    for i, a in enumerate(its):
        for b in its[i + 1:]:
            if similar.similar(a, b, _zips):
                out.setdefault(a["stem"], []).append(b["stem"])
                out.setdefault(b["stem"], []).append(a["stem"])
    return out


def full_image(stem: str, size: int = 1800) -> bytes | None:
    """Lielais skats: oriģināls samazināts līdz `size` px (garākā mala), JPEG. Kešs ~40 bildes."""
    if stem in _full:
        return _full[stem]
    p = _paths.get(stem)
    if not p or not os.path.isfile(p):
        scan()
        p = _paths.get(stem)
    if not p or not os.path.isfile(p):
        return None
    try:
        import io
        from PIL import Image, ImageOps
        with Image.open(p) as im:
            im.draft("RGB", (size, size))
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((size, size))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=85)
        data = buf.getvalue()
    except Exception:
        return None
    _full[stem] = data
    while len(_full) > 40:
        _full.pop(next(iter(_full)))
    return data


_full: dict[str, bytes] = {}


def set_delete(sid: str) -> None:
    st = sets_store()
    with st.lock:
        x = st.data.pop(sid, None)
        st.save()
    if x and x.get("rel"):                     # mape OneDrive paliek — atceras, lai restore_sets to neliek atpakaļ
        from . import plan
        ps = plan.store()
        with ps.lock:
            ps.data.setdefault("gone", {})[sid] = _now()
            ps.save()


def set_manifests():
    """Komplektu manifesti komplektu mapē `<gads>/<mēn>/<ned>/<komplekts>/_fotostokeris/*.json` → (ceļš, dati, set_id)."""
    base = set_dir()
    if not base or not os.path.isdir(base):
        return
    # 2026-11-11 16:55: ne tikai tieši 4 līmeņos — "Komplektu mape" var būt arī OneDrive (ne OneDrive/stock)
    found = []
    top = base.rstrip("\\/").count(os.sep)
    for d, dirs, _files in os.walk(base):
        if d.count(os.sep) - top >= 6:
            dirs[:] = []
            continue
        subs = [x for x in dirs if x in SUBS]
        for sub in subs:
            found += glob.glob(os.path.join(glob.escape(os.path.join(d, sub)), "*.json"))
        dirs[:] = [] if subs else [x for x in dirs if not x.startswith((".", "_")) and x.lower() != "manifesti"]
    for jp in found:
        try:
            with open(jp, encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue
        sid = str(data.get("set_id") or (data.get("series_id") if data.get("kind") == "set" else "") or "")
        if sid:
            yield jp, data, sid


def restore_sets() -> int:
    """Komplekti, kuru mape ar manifestu ir komplektu mapē (OneDrive), bet ieraksta sarakstā nav (dzēsts, sinhronizācijas
    konflikts, cits dators) → atjauno no manifesta (lietotājs 2026-11-11 15:01). Apzināti izņemtos (plan.json `gone`) neliek."""
    base = set_dir()
    if not base or not os.path.isdir(base):
        return 0
    from . import plan
    gone = plan.store().data.get("gone") or {}
    st = sets_store()
    have = set(st.data)
    n = 0
    for jp, data, sid in set_manifests():
        folder = os.path.dirname(os.path.dirname(jp))
        rel = os.path.relpath(folder, base).replace(os.sep, "/")
        if sid in gone:
            print(f"komplekts '{data.get('name')}' ir OneDrive mapē, bet apzināti izņemts no saraksta — neatjaunoju")
            continue
        if sid in have:
            x = st.data.get(sid) or {}
            if x.get("rel") != rel and not (x.get("rel") and os.path.isdir(set_path(x))):
                with st.lock:                       # ieraksts bez mapes (cits dators / sinhronizācija) — mape ir šeit
                    x["rel"] = rel
                    x.setdefault("moved_at", data.get("created") or _now())
                    st.save()
                print(f"komplektam '{x.get('name')}' atjaunota mape: {rel}")
                n += 1
            continue
        stems = [i.get("stem") for i in data.get("images") or [] if i.get("stem") and i.get("file")
                 and os.path.isfile(os.path.join(folder, i["file"]))]
        if not stems:
            continue
        cat = data.get("category") or "RF"
        rec = {"id": sid, "name": data.get("name") or os.path.basename(folder), "cat": cat,
               "created": data.get("created") or _now(), "stems": stems,
               "rel": os.path.relpath(folder, base).replace(os.sep, "/"), "moved_at": data.get("created") or _now(),
               "restored": _now()}
        with st.lock:
            st.data[sid] = rec
            st.save()
        have.add(sid)
        n += 1
        print(f"atjaunots komplekts '{rec['name']}' no OneDrive mapes ({len(stems)} bildes; sarakstā tā nebija)")
    return n


DONE = ("submitted", "accepted", "rejected")


def eff_state(c: dict) -> str:
    """Šūnas stāvoklis skaitīšanai (lietotājs 2026-11-19 11:41): lietotāja atzīme pieņemts/noraidīts/neder — tā;
    citādi Analītiķa statuss no aģentūras (accepted → pieņemts, rejected → noraidīts, review/changes/other → iesniegts,
    ja Tirgotājā tikai augšupielādēts vai nekas); ED kopijai pēc RF noraidījuma — Tirgotāja atzīme."""
    st = c.get("state") or ""
    a = c.get("ag_st") or ""
    if st in ("accepted", "rejected", "skip") or not a or (c.get("as") == "ED" and st):
        return st
    if a in ("accepted", "rejected"):
        return a
    return "submitted" if st in ("", "uploaded") else st


def set_status(x: dict, by: dict, ag: str) -> dict:
    """Komplekta stāvoklis aģentūrā: st = done (viss, kas der, iesniegts) | part | up (tikai augšupielādēts) | none |
    bad (nekas neder / lietotājs atzīmējis "neder"); skaitļi un pirmās iesniegšanas datums."""
    n = sub = acc = rej = up = bad = ext = skp = 0
    date = ""
    for s in x.get("stems") or []:
        it = by.get(s)
        c = (it or {}).get("cells", {}).get(ag) or {}
        stt = eff_state(c)                               # ar Analītiķa statusu (test45)
        if stt == "skip" or (not stt and c.get("bad")):
            bad += 1
            skp += stt == "skip"
            continue
        n += 1
        if stt in DONE:
            sub += 1
            acc += stt == "accepted"
            rej += stt == "rejected"
            d = next((h.get("at") for h in (c.get("hist") or []) + [c] if h.get("state") == "submitted"), c.get("at") or "")
            date = min(date, d) if date and d else (d or date)
        elif stt == "uploaded":
            up += 1
    st = ("done" if ext else "bad") if not n else "done" if sub >= n else "part" if sub else "up" if up else "none"
    if (x.get("part") or {}).get(ag) and st not in ("done", "bad"):
        st = "part"                                        # lietotājs: "daļēji" visam komplektam (labais klikšķis, 6j)
    todo = n - sub - up if st not in ("bad", "done") else 0
    left = month_left(ag) if todo > 0 else None
    return {"st": st, "n": n, "sub": sub, "acc": acc, "rej": rej, "wait": sub - acc - rej, "up": up, "bad": bad,
            "ext": ext, "date": date, **({"skip": True} if st == "bad" and skp else {}),   # lietotājs: "neder šai aģentūrai"
            **({"month": True, "left": left} if left is not None and todo > left else {})}   # mēneša limits — gaida nākamo mēnesi


SET_MARKS = ("uploaded", "submitted", "part", "skip", "")   # skip — "Neder šai aģentūrai" (lietotājs 2026-11-15)


def set_mark(sid: str, ag: str, state: str) -> dict:
    """Labais klikšķis uz komplekta punktiņa (lietotājs 2026-11-11 11:20–11:26): augšupielādēts / daļēji / iesniegts /
    noņemt. Bildes, kas aģentūrai neder, jau ir tur vai ir pieņemtas/noraidītas (automātiski), neaiztiek."""
    if ag not in AG_IDS or state not in SET_MARKS:
        return {"ok": False, "error": "bad_state"}
    ss = sets_store()
    x = ss.data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    with ss.lock:
        part = dict(x.get("part") or {})
        if state == "part":
            part[ag] = _now()
        else:
            part.pop(ag, None)
        if part:
            x["part"] = part
        else:
            x.pop("part", None)
        ss.save()
    if state == "part":
        return {"ok": True, "n": 0}
    by = {it["stem"]: it for it in listing()["items"]}
    stems = []
    for s in x.get("stems") or []:
        c = ((by.get(s) or {}).get("cells") or {}).get(ag) or {}
        cur = c.get("state") or ""
        if cur in ("accepted", "rejected") or (not cur and (c.get("bad") or c.get("ext"))):
            continue
        if cur == "skip" and state not in ("", "skip"):         # "neder" noņem tikai ar "Noņemt atzīmi"
            continue
        if state == "skip" and cur == "submitted":               # jau iesniegto neaiztiek
            continue
        if state == "" and cur not in ("uploaded", "submitted", "skip"):
            continue
        if cur != state:
            stems.append(s)
    n = mark(stems, ag, state, set_id=sid) if stems else 0
    return {"ok": True, "n": n}


def set_path(x: dict, series: list | None = None) -> str:
    """Komplekta mape šajā datorā (sets.json sinhronizējas — glabā ceļu attiecībā pret komplektu mapi).
    2026-11-05: ja otrā datorā "Komplektu mape" iestatīta citādi (piem. OneDrive, nevis OneDrive/stock), mapi atrod
    pēc komplekta manifesta (`set_id`) skenētajās mapēs — citādi rādītu "vēl gatavo mapē" un pārvietotu vēlreiz."""
    rel = x.get("rel") or ""
    p = os.path.join(set_dir(), *rel.split("/")) if rel and set_dir() else ""
    if p and os.path.isdir(p):
        return p
    if rel:
        for sr in (series if series is not None else scan()["series"]):
            if sr.get("set") == x.get("id") and os.path.isdir(sr.get("folder") or ""):
                if p:
                    _say(f"komplekts '{x.get('name')}' atrasts {sr['folder']} (iestatījumos komplektu mape: {set_dir()})")
                return sr["folder"]
    return p


def sets_list() -> list:
    r = listing()
    by = {it["stem"]: it for it in r["items"]}
    ags = [a["id"] for a in r["agencies"]]
    out = []
    for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True):
        stems = x.get("stems") or []
        p = set_path(x, r["series"])
        moved = sum(1 for s in stems if s in by and p and by[s]["path"] and os.path.dirname(by[s]["path"]) == p)
        missing = sum(1 for s in stems if s not in by)
        here = bool(p and os.path.isdir(p))
        ready = bool(x.get("rel")) and here and stems and moved >= len(stems) - missing   # "Gatavs iesniegšanai" (test21)
        stt = {a: set_status(x, by, a) for a in ags}
        if not ready:                                       # vēl nav pārvietots: neiesniegts = ⚪ "plānots" (ne 🔴)
            for z in stt.values():
                if z["st"] == "none":
                    z["st"] = "plan"
        out.append({**x, "count": len(stems), "status": stt, "dir": p, "moved": moved, "here": here, "ready": ready,
                    "missing": missing, "remote": sum(1 for s in stems if s in by and by[s].get("remote"))})
    return out


def set_dir() -> str:
    """Komplektu mape (OneDrive STOCK; datora iestatījums). Tukšs — pārvietot nevar."""
    return str(config.get("sub_set_dir") or "").strip()


def _safe(n: str) -> str:
    return "".join(c if c.isalnum() or c in "-_ ." else "_" for c in n).strip() or "komplekts"


def thumb(series: str, stem: str) -> bytes | None:
    for z in (_zips.get(series), _alt.get(stem)):     # sūtījuma/komplekta zip, tad Google kopija (ja tur sīktēla nav)
        if not z:
            continue
        try:
            with zipfile.ZipFile(z) as f:
                return f.read(stem + ".jpg")
        except (KeyError, OSError, zipfile.BadZipFile):
            continue
    return make_thumb(stem)


def make_thumb(stem: str, path: str = "") -> bytes | None:
    """Ja sīktēla nav nevienā zip (2026-11-05: sērijas no Mac — zip nebija ne sērijas mapē, ne Manifesti), to izveido no
    pašas bildes (256 px) un glabā datu mapē thumbs/ — nākamreiz ātri."""
    d = config.app_dir() / "thumbs"
    f = d / (re.sub(r"[^\w.-]", "_", stem) + ".jpg")
    try:
        if f.is_file():
            return f.read_bytes()
    except OSError:
        pass
    p = path or _paths.get(stem)
    if not p or not os.path.isfile(p):
        return None
    try:
        import io
        from PIL import Image, ImageOps
        with Image.open(p) as im:
            im.draft("RGB", (512, 512))
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((256, 256))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=82)
        data = buf.getvalue()
        d.mkdir(exist_ok=True)
        f.write_bytes(data)
        return data
    except Exception:
        return None
