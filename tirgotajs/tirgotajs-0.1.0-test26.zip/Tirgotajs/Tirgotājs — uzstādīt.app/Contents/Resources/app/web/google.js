"use strict";
/* Tirgotājs 0.3.1-test4 — Google konts: "Pieslēgumi" rinda "Google konts" un rezerves kopijas arī uz Google Drive
   (core/google.py, API "google"; noteikumi §5 p.2, dati §7a). Paraugs — vardotajs/web/google.js. Atļauja tikai
   drive.file — programma redz tikai pašas izveidotos failus. Lieto app.js palīgus ($, $$, api, t, esc, toast,
   uiConfirm, S, restoreBackup, fmtDT, fmtSize, loadSettings, loadBackups). */

const G_I18N = {
 "lv": {
  "cn_google": "Google konts",
  "cn_google_d": "Google Drive — rezerves kopijas ārpus datora (vēlāk arī darbs no vairākiem datoriem). Programma Drive redz tikai pašas izveidotos failus (mape Fotostokeris), ne tavas bildes un citus dokumentus.",
  "g_connect": "Pieslēgt",
  "g_disconnect": "Atslēgt",
  "g_on": "pieslēgts",
  "g_off": "nav pieslēgts",
  "g_wait": "gaidu pieslēgšanos pārlūkā…",
  "g_opened": "Pārlūkā atvērta Google lapa — izvēlies kontu un spied \"Atļaut\" (Allow). Rinda kļūs zaļa pati. Ja pārlūka logu neredzi — paskaties uzdevumjoslā.",
  "g_ok": "Google konts pieslēgts: {e}",
  "g_dis_q": "Atslēgt Google kontu? Rezerves kopijas Google Drive paliks, bet jaunas tur vairs netiks kopētas.",
  "g_nocfg": "šajā versijā nav Google pieslēguma datu",
  "g_expired": "pieslēgums beidzies — pieslēdz no jauna",
  "g_offline": "nav interneta — pārbaudīšu vēlāk",
  "g_timeout": "pieslēgšanās netika pabeigta — mēģini vēlreiz",
  "g_denied": "pārlūkā netika atļauts",
  "g_nokeyring": "datorā nav drošās glabātuves — Google kontu nevar saglabāt",
  "bk_g": "Kopēt arī uz Google Drive",
  "bk_g_need": "Vispirms pieslēdz Google kontu (Iestatījumi → Pieslēgumi).",
  "bk_g_info": "Google Drive mapē Fotostokeris/Analitikis/backups glabājas tikpat kopiju, cik iestatīts \"Cik kopijas paturēt\". Pēdējā augšupielāde: {d}.",
  "bk_g_err": "Pēdējā augšupielāde neizdevās: {e}",
  "bk_g_never": "vēl nav",
  "bk_g_list": "Google Drive kopijas",
  "bk_g_none": "Google Drive vēl nav nevienas kopijas.",
  "bk_g_loading": "Ielādēju sarakstu no Google Drive…"
 },
 "en": {
  "cn_google": "Google account",
  "cn_google_d": "Google Drive — backups outside the computer (later also working from several computers). In Drive the program sees only the files it created itself (folder Fotostokeris), not your photos or other documents.",
  "g_connect": "Connect",
  "g_disconnect": "Disconnect",
  "g_on": "connected",
  "g_off": "not connected",
  "g_wait": "waiting for sign-in in the browser…",
  "g_opened": "A Google page opened in the browser — choose the account and click \"Allow\". The row will turn green by itself. If you do not see the browser window — look in the taskbar.",
  "g_ok": "Google account connected: {e}",
  "g_dis_q": "Disconnect the Google account? Backups in Google Drive stay, but new ones will no longer be copied there.",
  "g_nocfg": "this version has no Google connection data",
  "g_expired": "the connection expired — connect again",
  "g_offline": "no internet — will check later",
  "g_timeout": "sign-in was not finished — try again",
  "g_denied": "not allowed in the browser",
  "g_nokeyring": "no secure storage on this computer — the Google account cannot be saved",
  "bk_g": "Also copy to Google Drive",
  "bk_g_need": "Connect the Google account first (Settings → Connections).",
  "bk_g_info": "The Google Drive folder Fotostokeris/Analitikis/backups keeps as many copies as set in \"Copies to keep\". Last upload: {d}.",
  "bk_g_err": "The last upload failed: {e}",
  "bk_g_never": "none yet",
  "bk_g_list": "Google Drive backups",
  "bk_g_none": "No backups in Google Drive yet.",
  "bk_g_loading": "Loading the list from Google Drive…"
 },
 "de": {
  "cn_google": "Google-Konto",
  "cn_google_d": "Google Drive — Sicherungen außerhalb des Computers (später auch Arbeit von mehreren Computern). In Drive sieht das Programm nur die selbst erstellten Dateien (Ordner Fotostokeris), nicht deine Bilder oder andere Dokumente.",
  "g_connect": "Verbinden",
  "g_disconnect": "Trennen",
  "g_on": "verbunden",
  "g_off": "nicht verbunden",
  "g_wait": "warte auf Anmeldung im Browser…",
  "g_opened": "Im Browser ist eine Google-Seite geöffnet — wähle das Konto und klicke „Zulassen“ (Allow). Die Zeile wird von selbst grün. Siehst du das Browserfenster nicht — schau in die Taskleiste.",
  "g_ok": "Google-Konto verbunden: {e}",
  "g_dis_q": "Google-Konto trennen? Die Sicherungen in Google Drive bleiben, aber neue werden dort nicht mehr gespeichert.",
  "g_nocfg": "diese Version hat keine Google-Verbindungsdaten",
  "g_expired": "Verbindung abgelaufen — neu verbinden",
  "g_offline": "kein Internet — ich prüfe später",
  "g_timeout": "Anmeldung nicht abgeschlossen — versuche es erneut",
  "g_denied": "im Browser nicht zugelassen",
  "g_nokeyring": "kein sicherer Speicher auf diesem Computer — das Google-Konto kann nicht gespeichert werden",
  "bk_g": "Auch in Google Drive kopieren",
  "bk_g_need": "Verbinde zuerst das Google-Konto (Einstellungen → Verbindungen).",
  "bk_g_info": "Im Google-Drive-Ordner Fotostokeris/Analitikis/backups werden so viele Kopien behalten wie bei „Kopien behalten“ eingestellt. Letzter Upload: {d}.",
  "bk_g_err": "Der letzte Upload ist fehlgeschlagen: {e}",
  "bk_g_never": "noch keiner",
  "bk_g_list": "Sicherungen in Google Drive",
  "bk_g_none": "In Google Drive gibt es noch keine Sicherung.",
  "bk_g_loading": "Lade die Liste aus Google Drive…"
 },
 "es": {
  "cn_google": "Cuenta de Google",
  "cn_google_d": "Google Drive — copias de seguridad fuera del ordenador (más adelante también trabajo desde varios ordenadores). En Drive el programa solo ve los archivos que él mismo creó (carpeta Fotostokeris), no tus fotos ni otros documentos.",
  "g_connect": "Conectar",
  "g_disconnect": "Desconectar",
  "g_on": "conectada",
  "g_off": "no conectada",
  "g_wait": "esperando el inicio de sesión en el navegador…",
  "g_opened": "Se abrió una página de Google en el navegador: elige la cuenta y pulsa «Permitir» (Allow). La fila se pondrá verde sola. Si no ves la ventana del navegador, mira en la barra de tareas.",
  "g_ok": "Cuenta de Google conectada: {e}",
  "g_dis_q": "¿Desconectar la cuenta de Google? Las copias en Google Drive se quedan, pero las nuevas ya no se copiarán allí.",
  "g_nocfg": "esta versión no tiene datos de conexión de Google",
  "g_expired": "la conexión caducó — conecta de nuevo",
  "g_offline": "sin internet — lo comprobaré más tarde",
  "g_timeout": "no se terminó el inicio de sesión — inténtalo de nuevo",
  "g_denied": "no se permitió en el navegador",
  "g_nokeyring": "no hay almacén seguro en este ordenador — no se puede guardar la cuenta de Google",
  "bk_g": "Copiar también a Google Drive",
  "bk_g_need": "Primero conecta la cuenta de Google (Ajustes → Conexiones).",
  "bk_g_info": "La carpeta de Google Drive Fotostokeris/Analitikis/backups guarda tantas copias como se indica en «Copias a conservar». Última subida: {d}.",
  "bk_g_err": "La última subida falló: {e}",
  "bk_g_never": "aún ninguna",
  "bk_g_list": "Copias en Google Drive",
  "bk_g_none": "Aún no hay copias en Google Drive.",
  "bk_g_loading": "Cargando la lista de Google Drive…"
 },
 "uk": {
  "cn_google": "Обліковий запис Google",
  "cn_google_d": "Google Drive — резервні копії поза комп’ютером (пізніше також робота з кількох комп’ютерів). У Drive програма бачить лише власноруч створені файли (папка Fotostokeris), а не твої фото чи інші документи.",
  "g_connect": "Під’єднати",
  "g_disconnect": "Від’єднати",
  "g_on": "під’єднано",
  "g_off": "не під’єднано",
  "g_wait": "чекаю на вхід у браузері…",
  "g_opened": "У браузері відкрито сторінку Google — вибери обліковий запис і натисни «Дозволити» (Allow). Рядок стане зеленим сам. Якщо не бачиш вікна браузера — подивись на панелі завдань.",
  "g_ok": "Обліковий запис Google під’єднано: {e}",
  "g_dis_q": "Від’єднати обліковий запис Google? Резервні копії в Google Drive залишаться, але нові туди більше не копіюватимуться.",
  "g_nocfg": "у цій версії немає даних для під’єднання Google",
  "g_expired": "під’єднання закінчилося — під’єднай знову",
  "g_offline": "немає інтернету — перевірю пізніше",
  "g_timeout": "вхід не завершено — спробуй ще раз",
  "g_denied": "у браузері не дозволено",
  "g_nokeyring": "на комп’ютері немає захищеного сховища — обліковий запис Google не можна зберегти",
  "bk_g": "Копіювати також у Google Drive",
  "bk_g_need": "Спершу під’єднай обліковий запис Google (Налаштування → Під’єднання).",
  "bk_g_info": "У папці Google Drive Fotostokeris/Analitikis/backups зберігається стільки копій, скільки задано в «Скільки копій зберігати». Останнє завантаження: {d}.",
  "bk_g_err": "Останнє завантаження не вдалося: {e}",
  "bk_g_never": "ще немає",
  "bk_g_list": "Копії в Google Drive",
  "bk_g_none": "У Google Drive ще немає жодної копії.",
  "bk_g_loading": "Завантажую список із Google Drive…"
 }
};
for (const l of Object.keys(G_I18N)) window.I18N[l] = Object.assign(window.I18N[l] || {}, G_I18N[l]);

const GG = { st: null, poll: null };
const gWhy = (e) => ({ not_configured: "g_nocfg", expired: "g_expired", offline: "g_offline", timeout: "g_timeout", access_denied: "g_denied", no_keyring: "g_nokeyring" }[e]);

/* ---------- Pieslēgumi: rinda "Google konts" (aiz OneDrive) ---------- */
function gRow() {
  let row = $('.conn[data-p="google"]');
  if (row) return row;
  const box = $("#connList"); if (!box || !$('.conn[data-p="onedrive"]', box)) return null;
  box.insertAdjacentHTML("beforeend", `<div class="conn" data-p="google"><span class="dot cn-dot"></span>
    <div class="cn-main"><b data-i18n="cn_google"></b> <span class="cn-st muted small"></span>
      <div class="muted small" data-i18n="cn_google_d"></div><div class="cn-info small"></div></div>
    <div class="cn-act"><button class="small-btn primary g-connect" data-i18n="g_connect"></button>
      <button class="small-btn ghost g-disconnect hidden" data-i18n="g_disconnect"></button></div></div>`);
  row = $('.conn[data-p="google"]');
  const od = $('.conn[data-p="onedrive"]');
  if (od) od.after(row);
  applyI18n(row);
  $(".g-connect", row).addEventListener("click", gConnect);
  $(".g-disconnect", row).addEventListener("click", gDisconnect);
  return row;
}
function gPaint(s) {
  const row = gRow(); if (!row) return;
  GG.st = s;
  const on = !!(s && s.connected);
  let ok = on ? true : false, txt = on ? t("g_on") + (s.email ? " · " + s.email : "") : t("g_off");
  if (s && !s.configured) txt = t("g_nocfg");
  else if (s && s.keyring === false) txt = t("g_nokeyring");
  else if (s && s.waiting && !on) { ok = null; txt = t("g_wait"); }
  else if (s && s.error) txt = (on ? txt + " · " : "") + (gWhy(s.error) ? t(gWhy(s.error)) : s.error);
  $(".cn-dot", row).className = "dot cn-dot " + (ok === true ? "ok" : ok === false ? "off" : "");
  $(".cn-st", row).textContent = txt;
  $(".g-connect", row).classList.toggle("hidden", on);
  $(".g-connect", row).disabled = !(s && s.configured && s.keyring !== false);
  $(".g-disconnect", row).classList.toggle("hidden", !on);
  bkGPaint();
}
async function gLoad(check = true) {
  try { gPaint(await api("google", { do: "status", check })); } catch (_) { /* */ }
}
async function gConnect() {
  try {
    await api("google", { do: "connect" });
    toast(t("g_opened"), "ok", 9000);
    gPaint(Object.assign({}, GG.st || {}, { waiting: true, connected: false, error: "" }));
    clearInterval(GG.poll);
    const t0 = Date.now();
    GG.poll = setInterval(async () => {
      let s; try { s = await api("google", { do: "status" }); } catch (_) { return; }
      if (s.connected || !s.waiting || Date.now() - t0 > 310e3) {
        clearInterval(GG.poll); gPaint(s);
        if (s.connected) { toast(t("g_ok", { e: s.email || "" }), "ok", 6000); gLoad(true); }
      }
    }, 2500);
  } catch (e) { toast(gWhy(e.message) ? t(gWhy(e.message)) : e.message, "err", 8000); }
}
async function gDisconnect() {
  if (!(await uiConfirm(t("g_dis_q")))) return;
  try { gPaint(await api("google", { do: "disconnect" })); } catch (e) { toast(e.message, "err"); }
}

/* ---------- Rezerves kopijas: "Kopēt arī uz Google Drive" + saraksts ---------- */
function bkGBox() {
  let box = $("#bkGoogle");
  if (box) return box;
  const list = $("#bkList"); if (!list) return null;
  list.insertAdjacentHTML("afterend", `<div id="bkGoogle" class="bk-g">
    <label class="chk"><input type="checkbox" class="sw" id="sBkGoogle"> <span data-i18n="bk_g"></span></label>
    <div id="bkGInfo" class="muted small"></div>
    <details id="bkGDet"><summary data-i18n="bk_g_list"></summary><div id="bkGList" class="muted small"></div></details></div>`);
  box = $("#bkGoogle");
  applyI18n(box);
  $("#sBkGoogle").addEventListener("change", async (e) => {
    try { S.settings = (await api("settings", { settings: { backup_google: e.target.checked } })).settings; } catch (err) { toast(err.message, "err"); }
    bkGPaint();
  });
  $("#bkGDet").addEventListener("toggle", () => { if ($("#bkGDet").open) bkGList(); });
  return box;
}
function bkGPaint() {
  const box = bkGBox(); if (!box) return;
  const on = !!(GG.st && GG.st.connected);
  const chk = $("#sBkGoogle");
  chk.disabled = !on;
  chk.checked = on && !!(S.settings && S.settings.backup_google);
  $("#bkGoogle label.chk").title = on ? "" : t("bk_g_need");
  const s = S.settings || {};
  $("#bkGInfo").textContent = !on ? t("bk_g_need")
    : s.backup_google ? (s.backup_google_err ? t("bk_g_err", { e: s.backup_google_err }) : t("bk_g_info", { d: s.backup_google_last ? fmtDT(s.backup_google_last) : t("bk_g_never") })) : "";
  $("#bkGDet").classList.toggle("hidden", !on);
}
async function bkGList() {
  const el = $("#bkGList");
  el.textContent = t("bk_g_loading");
  let d;
  try { d = await api("google", { do: "backups" }); } catch (e) { el.textContent = gWhy(e.message) ? t(gWhy(e.message)) : e.message; return; }
  el.innerHTML = d.items.length ? `<table class="bk-t"><tbody>` + d.items.slice(0, 12).map((x) =>
    `<tr><td>${esc(fmtDT(x.mtime))}</td><td class="muted">${fmtSize(x.size)}</td><td><button data-gid="${esc(x.id)}">${esc(t("bk_restore"))}</button></td></tr>`).join("") + `</tbody></table>`
    : esc(t("bk_g_none"));
  $$("#bkGList [data-gid]").forEach((b) => b.addEventListener("click", () => restoreBackup({ gdrive_id: b.dataset.gid })));
}

/* ---------- app.js funkcijas papildinām ---------- */
/* Pieslēgumu saraksts ir core.js (settingsFrame) — rindu pieliekam, kad OneDrive rinda jau uzzīmēta */
const _gLoadSettings = loadSettings;
loadSettings = function () {                        // eslint-disable-line no-func-assign
  _gLoadSettings();
  let n = 0;
  const tick = () => { if (gRow()) gLoad(true); else if (++n < 20) setTimeout(tick, 150); };
  setTimeout(tick, 0);
};
const _gLoadBackups = loadBackups;
loadBackups = async function () {                   // eslint-disable-line no-func-assign
  await _gLoadBackups();
  bkGBox();
  if (!GG.st) await gLoad(false); else bkGPaint();
  if ($("#bkGDet") && $("#bkGDet").open) bkGList();
};
// pēc "Izveidot tagad" — Google Drive augšupielāde notiek fonā; pēc brīža atjaunojam informāciju
$("#bkNow").addEventListener("click", () => setTimeout(async () => {
  try { S.settings = (await api("state")).settings; } catch (_) { /* */ }
  bkGPaint();
}, 8000));
