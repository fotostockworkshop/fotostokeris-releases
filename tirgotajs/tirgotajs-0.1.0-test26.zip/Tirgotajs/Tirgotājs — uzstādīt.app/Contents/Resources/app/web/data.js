"use strict";
/* Tirgotājs — rezerves kopijas iestatījumos (core/backup.py). Kods un teksti no Analītiķa (analitikis/web/app.js, i18n.js);
   google.js / gsync.js lieto loadBackups, restoreBackup, fmtDT, fmtSize. */
const BK_I18N = {
 "lv": {
  "s_data": "Darbs ar datiem",
  "s_bk": "Rezerves kopijas",
  "s_bk_dir": "Mape (tukšs — noklusējums)",
  "bk_dir_pick": "Izvēlēties mapi…",
  "bk_dir_od": "OneDrive",
  "bk_dir_def": "Noklusējuma mape",
  "bk_no_od": "OneDrive mape šajā datorā nav atrasta.",
  "s_bk_every": "Automātiski",
  "s_bk_keep": "Cik pēdējās paturēt",
  "bk_never": "netaisīt",
  "bk_day": "katru dienu",
  "bk_week": "reizi nedēļā",
  "bk_month": "reizi mēnesī",
  "bk_now": "Izveidot tagad",
  "bk_open": "Atvērt mapi",
  "bk_pick": "Atjaunot no faila…",
  "bk_info": "Mape: {dir} · pēdējā kopija: {last} · nākamā automātiskā: {next}",
  "bk_copy": "Kopija",
  "bk_size": "Izmērs",
  "bk_restore": "Atjaunot",
  "bk_none": "Kopiju šajā mapē vēl nav.",
  "bk_tag_update": "pirms atjaunināšanas",
  "bk_tag_restore": "pirms atjaunošanas",
  "bk_tag_auto": "automātiski",
  "bk_restoring": "Atjaunoju…",
  "bk_restored": "Dati atjaunoti. Iepriekšējie dati saglabāti: {n}",
  "bk_making": "Veidoju kopiju…",
  "bk_made": "Kopija izveidota: {n}",
  "never": "nekad",
  "s_mr_reading": "Lasu failu…",
  "s_bk_d": "Rezerves kopijā ir visas Tirgotāja atzīmes (kur kas iesniegts), komplekti un iestatījumi — bez parolēm. Bildes kopijā netiek liktas. Kopija tiek izveidota arī automātiski pirms katras programmas atjaunināšanas.",
  "bk_restore_q": "Atjaunot rezerves kopiju no {d} (versija {v})? Pašreizējie dati vispirms tiks saglabāti atsevišķā kopijā."
 },
 "en": {
  "s_data": "Working with data",
  "s_bk": "Backups",
  "s_bk_dir": "Folder (empty — default)",
  "bk_dir_pick": "Choose folder…",
  "bk_dir_od": "OneDrive",
  "bk_dir_def": "Default folder",
  "bk_no_od": "No OneDrive folder found on this computer.",
  "s_bk_every": "Automatically",
  "s_bk_keep": "How many to keep",
  "bk_never": "never",
  "bk_day": "every day",
  "bk_week": "once a week",
  "bk_month": "once a month",
  "bk_now": "Back up now",
  "bk_open": "Open folder",
  "bk_pick": "Restore from file…",
  "bk_info": "Folder: {dir} · last backup: {last} · next automatic: {next}",
  "bk_copy": "Backup",
  "bk_size": "Size",
  "bk_restore": "Restore",
  "bk_none": "No backups in this folder yet.",
  "bk_tag_update": "before update",
  "bk_tag_restore": "before restore",
  "bk_tag_auto": "automatic",
  "bk_restoring": "Restoring…",
  "bk_restored": "Data restored. Previous data saved: {n}",
  "bk_making": "Making a backup…",
  "bk_made": "Backup made: {n}",
  "never": "never",
  "s_mr_reading": "Reading file…",
  "s_bk_d": "The backup holds all Tirgotājs marks (what was submitted where), sets and settings — no passwords. Photos are not included. A backup is also made automatically before every program update.",
  "bk_restore_q": "Restore the backup from {d} (version {v})? The current data will be saved in a separate copy first."
 },
 "de": {
  "s_data": "Arbeit mit Daten",
  "s_bk": "Sicherungen",
  "s_bk_dir": "Ordner (leer — Standard)",
  "bk_dir_pick": "Ordner wählen…",
  "bk_dir_od": "OneDrive",
  "bk_dir_def": "Standardordner",
  "bk_no_od": "Auf diesem Computer wurde kein OneDrive-Ordner gefunden.",
  "s_bk_every": "Automatisch",
  "s_bk_keep": "Wie viele behalten",
  "bk_never": "nie",
  "bk_day": "jeden Tag",
  "bk_week": "einmal pro Woche",
  "bk_month": "einmal pro Monat",
  "bk_now": "Jetzt sichern",
  "bk_open": "Ordner öffnen",
  "bk_pick": "Aus Datei wiederherstellen…",
  "bk_info": "Ordner: {dir} · letzte Sicherung: {last} · nächste automatische: {next}",
  "bk_copy": "Sicherung",
  "bk_size": "Größe",
  "bk_restore": "Wiederherstellen",
  "bk_none": "In diesem Ordner gibt es noch keine Sicherungen.",
  "bk_tag_update": "vor der Aktualisierung",
  "bk_tag_restore": "vor der Wiederherstellung",
  "bk_tag_auto": "automatisch",
  "bk_restoring": "Stelle wieder her…",
  "bk_restored": "Daten wiederhergestellt. Vorherige Daten gesichert: {n}",
  "bk_making": "Erstelle Sicherung…",
  "bk_made": "Sicherung erstellt: {n}",
  "never": "nie",
  "s_mr_reading": "Lese Datei…"
 },
 "es": {
  "s_data": "Trabajo con datos",
  "s_bk": "Copias de seguridad",
  "s_bk_dir": "Carpeta (vacía — predeterminada)",
  "bk_dir_pick": "Elegir carpeta…",
  "bk_dir_od": "OneDrive",
  "bk_dir_def": "Carpeta predeterminada",
  "bk_no_od": "No se encontró ninguna carpeta de OneDrive en este ordenador.",
  "s_bk_every": "Automáticamente",
  "s_bk_keep": "Cuántas conservar",
  "bk_never": "nunca",
  "bk_day": "cada día",
  "bk_week": "una vez por semana",
  "bk_month": "una vez al mes",
  "bk_now": "Hacer copia ahora",
  "bk_open": "Abrir carpeta",
  "bk_pick": "Restaurar desde archivo…",
  "bk_info": "Carpeta: {dir} · última copia: {last} · próxima automática: {next}",
  "bk_copy": "Copia",
  "bk_size": "Tamaño",
  "bk_restore": "Restaurar",
  "bk_none": "Todavía no hay copias en esta carpeta.",
  "bk_tag_update": "antes de actualizar",
  "bk_tag_restore": "antes de restaurar",
  "bk_tag_auto": "automática",
  "bk_restoring": "Restaurando…",
  "bk_restored": "Datos restaurados. Datos anteriores guardados: {n}",
  "bk_making": "Haciendo la copia…",
  "bk_made": "Copia hecha: {n}",
  "never": "nunca",
  "s_mr_reading": "Leyendo el archivo…"
 },
 "uk": {
  "s_data": "Робота з даними",
  "s_bk": "Резервні копії",
  "s_bk_dir": "Папка (порожньо — за замовчуванням)",
  "bk_dir_pick": "Вибрати папку…",
  "bk_dir_od": "OneDrive",
  "bk_dir_def": "Папка за замовчуванням",
  "bk_no_od": "На цьому комп'ютері не знайдено папки OneDrive.",
  "s_bk_every": "Автоматично",
  "s_bk_keep": "Скільки зберігати",
  "bk_never": "ніколи",
  "bk_day": "щодня",
  "bk_week": "раз на тиждень",
  "bk_month": "раз на місяць",
  "bk_now": "Зробити копію зараз",
  "bk_open": "Відкрити папку",
  "bk_pick": "Відновити з файлу…",
  "bk_info": "Папка: {dir} · остання копія: {last} · наступна автоматична: {next}",
  "bk_copy": "Копія",
  "bk_size": "Розмір",
  "bk_restore": "Відновити",
  "bk_none": "У цій папці ще немає копій.",
  "bk_tag_update": "перед оновленням",
  "bk_tag_restore": "перед відновленням",
  "bk_tag_auto": "автоматична",
  "bk_restoring": "Відновлюю…",
  "bk_restored": "Дані відновлено. Попередні дані збережено: {n}",
  "bk_making": "Роблю копію…",
  "bk_made": "Копію зроблено: {n}",
  "never": "ніколи",
  "s_mr_reading": "Читаю файл…"
 }
};
for (const l of Object.keys(BK_I18N)) window.I18N[l] = Object.assign(window.I18N[l] || {}, BK_I18N[l]);
window.BACKUP_HTML = `    <section data-collapse="data"><h2 data-i18n="s_data"></h2>
      <h3 data-i18n="s_bk"></h3><p class="muted small" data-i18n="s_bk_d"></p>
      <div class="grid2">
        <label class="span2"><span data-i18n="s_bk_dir"></span><input id="sBkDir" spellcheck="false" autocomplete="off"></label>
        <div class="span2 row-btns" style="margin-top:-4px"><button id="bkDirPick" class="small-btn" data-i18n="bk_dir_pick"></button><button id="bkDirOd" class="small-btn hidden" data-i18n="bk_dir_od"></button><button id="bkDirDef" class="small-btn ghost" data-i18n="bk_dir_def"></button></div>
        <label><span data-i18n="s_bk_every"></span><select id="sBkEvery"><option value="never" data-i18n="bk_never"></option>
          <option value="day" data-i18n="bk_day"></option><option value="week" data-i18n="bk_week"></option><option value="month" data-i18n="bk_month"></option></select></label>
        <label><span data-i18n="s_bk_keep"></span><input id="sBkKeep" type="number" min="1" max="100"></label>
      </div>
      <div class="row-btns"><button id="bkNow" class="primary" data-i18n="bk_now"></button><button id="bkOpen" data-i18n="bk_open"></button>
        <button id="bkPick" data-i18n="bk_pick"></button><input id="bkFile" type="file" accept=".zip" class="hidden"><span id="bkSt" class="muted small"></span></div>
      <p id="bkInfo" class="muted small"></p>
      <div id="bkList" class="bk-list small"></div>
    </section>`;
const fmtSize = (n) => n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
const fmtDT = (iso) => iso ? new Date(iso).toLocaleString(window.langLocale(), { day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" }) : "–";
async function loadBackups() {
  let d;
  try { d = await api("backup_list"); } catch (_) { return; }
  $("#sBkDir").placeholder = d.default_dir;
  $("#bkInfo").textContent = t("bk_info", { dir: d.dir, last: d.last ? fmtDT(d.last) : t("never"), next: d.next ? fmtDT(d.next) : "–" });
  $("#bkList").innerHTML = d.items.length ? `<table class="t"><thead><tr><th>${esc(t("bk_copy"))}</th><th>${esc(t("bk_size"))}</th><th></th></tr></thead><tbody>` +
    d.items.map((x) => `<tr><td>${esc(fmtDT(x.mtime))}${/pirms-atjaunin/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_update"))}</span>` : /pirms-atjauno/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_restore"))}</span>` : /-auto/.test(x.name) ? ` <span class="muted">· ${esc(t("bk_tag_auto"))}</span>` : ""}</td>
      <td>${fmtSize(x.size)}</td><td><button class="small-btn" data-bk="${esc(x.name)}">${esc(t("bk_restore"))}</button></td></tr>`).join("") + `</tbody></table>`
    : `<span class="muted">${esc(t("bk_none"))}</span>`;
  $$("#bkList [data-bk]").forEach((b) => b.addEventListener("click", () => restoreBackup({ name: b.dataset.bk })));
}
async function restoreBackup(src) {
  let p;
  try { p = await api("backup_preview", src); } catch (e) { return toast(e.message, "err", 8000); }
  const m = p.manifest || {}, i = m.info || {};
  const q = t("bk_restore_q", { d: fmtDT(m.created), v: m.version || "?" });
  if (!(await uiConfirm(q, t("bk_restore")))) return;
  $("#bkSt").textContent = t("bk_restoring");
  try {
    const r = await api("backup_restore", src);
    toast(t("bk_restored", { n: r.saved_before }), "ok", 8000);
    setTimeout(() => location.reload(), 1800);
  } catch (e) { $("#bkSt").textContent = ""; toast(e.message === "busy" ? t("upd_busy") : e.message, "err", 9000); }
}
function bindBackups() {
  $("#bkNow").addEventListener("click", async () => {
    $("#settingsSave").click();                     // vispirms saglabājam mapi un biežumu
    await new Promise((r) => setTimeout(r, 600));
    $("#bkNow").disabled = true; $("#bkSt").textContent = t("bk_making");
    try { const r = await api("backup_create"); toast(t("bk_made", { n: r.name }), "ok", 6000); loadBackups(); }
    catch (e) { toast(e.message, "err", 9000); }
    $("#bkNow").disabled = false; $("#bkSt").textContent = "";
  });
  $("#bkOpen").addEventListener("click", () => api("backup_open").catch((e) => toast(e.message, "err")));
  /* test44: mapes izvēle sistēmas logā + ātrā poga OneDrive (lietotājs 2026-10-30) */
  /* test4: kamēr mapes izvēles logs atvērts — abas pogas atspējotas (otru logu neatver; core atbild pick_busy) */
  const pickBusy = (on) => ["#bkDirPick", "#bkDirOd", "#bkDirDef"].forEach((s) => { const b = $(s); if (b) b.disabled = on; });
  const pickRun = async (fn) => {
    if ($("#bkDirPick").disabled) return;
    pickBusy(true);
    try { await fn(); }
    catch (e) { if (e.message !== "pick_busy") throw e; }
    finally { pickBusy(false); }
  };
  $("#bkDirPick").addEventListener("click", () => pickRun(async () => {
    try { const r = await api("pick_folder", { start: $("#sBkDir").value.trim() || $("#sBkDir").placeholder }); if (r.path) { $("#sBkDir").value = r.path; $("#settingsSave").click(); } }
    catch (e) { if (e.message !== "pick_busy") toast(e.message, "err"); }
  }));
  $("#bkDirOd").addEventListener("click", () => pickRun(async () => {
    try { const od = await api("pick_folder", { onedrive: true });
      const r = await api("pick_folder", { start: od.path });      // izvēle OneDrive iekšā; logā var izveidot jaunu mapi
      if (r.path) { $("#sBkDir").value = r.path; $("#settingsSave").click(); } }
    catch (e) { if (e.message !== "pick_busy") toast(t("bk_no_od"), "err"); }
  }));
  $("#bkDirDef").addEventListener("click", () => { $("#sBkDir").value = ""; $("#settingsSave").click(); });
  api("onedrive").then((r) => $("#bkDirOd").classList.toggle("hidden", !(r && r.path))).catch(() => {});
  $("#bkPick").addEventListener("click", () => $("#bkFile").click());
  $("#bkFile").addEventListener("change", async () => {
    const f = $("#bkFile").files[0];
    $("#bkFile").value = "";
    if (!f) return;
    $("#bkSt").textContent = t("s_mr_reading");
    const data = await new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = no; r.readAsDataURL(f); });
    $("#bkSt").textContent = "";
    restoreBackup({ data });
  });
}

let bkBound = false;
window.bkLoad = function (s) {
  if (!$("#bkNow")) return;
  if (!bkBound) { bkBound = true; bindBackups(); }
  $("#sBkEvery").value = s.backup_every || "week"; $("#sBkKeep").value = s.backup_keep ?? 10; $("#sBkDir").value = s.backup_dir || "";
  loadBackups();
};
window.bkCollect = () => ($("#sBkEvery") ? { backup_every: $("#sBkEvery").value, backup_keep: +$("#sBkKeep").value || 10, backup_dir: $("#sBkDir").value.trim() } : {});
