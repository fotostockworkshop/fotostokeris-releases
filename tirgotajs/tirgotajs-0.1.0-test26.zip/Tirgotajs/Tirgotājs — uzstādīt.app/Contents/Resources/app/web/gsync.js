"use strict";
/* Tirgotājs (no Analītiķa) — sinhronizācija ar citiem datoriem caur Google Drive (core/sync.py; noteikumi dati §7a).
   Rinda "Google konts": ķeksis, "Sinhronizēt tagad", "Pilnā kopija uz Drive", stāvoklis, paziņojumi.
   Sinhronizējas: iestatījumi (bez šī datora vērtībām), kolekcijas, bilžu apvienošana ar roku, RF/ED atzīmes,
   Microstockr sasaistes, portfeļa vēsture no CSV; jaunam datoram — pilna datubāzes kopija. Lieto google.js (gRow, GG, gWhy). */
const GS_I18N = {
  lv: { sy_chk: "Sinhronizēt ar citiem datoriem", sy_d: "Atzīmes (kur kas iesniegts), komplekti un iestatījumi — caur Google Drive, lai tos redzētu arī citā datorā. Bildes netiek sūtītas. Ieslēdz katrā datorā.",
    sy_now: "Sinhronizēt tagad", sy_db: "", sy_last: "Sinhronizēts: {d}", sy_never: "vēl nav sinhronizēts", sy_err: "Sinhronizācijas kļūda: {e}",
    sy_busy: "Sinhronizēju…", sy_done: "Sinhronizēts.", sy_db_done: "", sy_db_skip: "",
    sy_got: "Dati atjaunoti no datora {c}: {f}", sy_other: "Tirgotājs nesen ({d}) lietots arī datorā {c} — nestrādā abos datoros vienlaikus.",
    sy_f_settings: "iestatījumi", sy_f_ledger: "atzīmes", sy_f_sets: "komplekti", sy_f_plan: "plāns", sy_f_notsimilar: "“nav līdzīgas”",
    sy_bar: "Sinhronizēts {t}", sy_bar_err: "Sinhronizācijas kļūda", sy_bar_tip: "Klikšķis — sinhronizēt tagad. Aizverot Tirgotāju, neaizsūtītās izmaiņas tiek nosūtītas automātiski." },
  en: { sy_chk: "Sync with other computers", sy_d: "Marks (what was submitted where), sets and settings — via Google Drive, so another computer sees them too. Photos are not sent. Turn it on on every computer.",
    sy_now: "Sync now", sy_db: "", sy_last: "Synced: {d}", sy_never: "not synced yet", sy_err: "Sync error: {e}",
    sy_busy: "Syncing…", sy_done: "Synced.", sy_db_done: "", sy_db_skip: "",
    sy_got: "Data updated from computer {c}: {f}", sy_other: "Tirgotājs was recently ({d}) used on computer {c} too — do not work on both computers at the same time.",
    sy_f_settings: "settings", sy_f_ledger: "marks", sy_f_sets: "sets", sy_f_plan: "plan", sy_f_notsimilar: "“not similar”",
    sy_bar: "Synced {t}", sy_bar_err: "Sync error", sy_bar_tip: "Click — sync now. When Tirgotājs closes, unsent changes are sent automatically." },
};
for (const l of Object.keys(GS_I18N)) window.I18N[l] = Object.assign(window.I18N[l] || {}, GS_I18N[l]);

const syFiles = (f) => (f || []).map((n) => t("sy_f_" + n.replace(/\.json$/, "").replace(/\./g, "_"))).join(", ");
const syErr = (e) => (gWhy(e) ? t(gWhy(e)) : e);
function syBox() {
  const row = $('.conn[data-p="google"]'); if (!row) return null;
  let b = $(".g-sync", row);
  if (b) return b;
  $(".cn-main", row).insertAdjacentHTML("beforeend", `<div class="g-sync hidden"><label class="chk"><input type="checkbox" class="g-sync-chk"> <span data-i18n="sy_chk"></span></label>
    <div class="muted small" data-i18n="sy_d"></div><div class="row"><button class="small-btn g-sync-now" data-i18n="sy_now"></button>
<span class="g-sync-st muted small"></span></div></div>`);
  b = $(".g-sync", row); applyI18n(b);
  $(".g-sync-chk", b).addEventListener("change", async (e) => {
    try { syPaint(await api("google", { do: "sync_set", on: e.target.checked })); S.settings.google_sync = e.target.checked; setTimeout(syPoll, 8000); }
    catch (err) { toast(err.message, "err"); }
  });
  $(".g-sync-now", b).addEventListener("click", async (e) => {
    const btn = e.target; btn.disabled = true; $(".g-sync-st", b).textContent = t("sy_busy");
    try { const d = await api("google", { do: "sync_now" }); syPaint(d); syGot(d); toast(t("sy_done"), "ok", 3000); }
    catch (err) { toast(t("sy_err", { e: syErr(err.message) }), "err", 9000); syLoad(); }
    finally { btn.disabled = false; }
  });
  if ($(".g-sync-db", b)) $(".g-sync-db", b).addEventListener("click", async (e) => {
    const btn = e.target; btn.disabled = true; $(".g-sync-st", b).textContent = t("sy_busy");
    try { const d = await api("google", { do: "sync_db_now" }); toast(t(d.sent && d.sent.length ? "sy_db_done" : "sy_db_skip"), d.sent && d.sent.length ? "ok" : "err", 6000); }
    catch (err) { toast(t("sy_err", { e: syErr(err.message) }), "err", 9000); }
    finally { btn.disabled = false; syLoad(); }
  });
  return b;
}
/* apakšējā joslā: "☁ Sinhronizēts HH:MM" — klikšķis sinhronizē tagad (2026-11-05) */
function syBar(d) {
  if (!d || !d.enabled) { Core.setStatus("sync", null); return; }
  const hm = d.last ? new Date(d.last).toLocaleTimeString(window.langLocale(), { hour: "2-digit", minute: "2-digit" }) : "—";
  Core.setStatus("sync", d.err ? { text: "☁ " + t("sy_bar_err"), cls: "err", title: t("sy_err", { e: syErr(d.err) }) + "\n" + t("sy_bar_tip") }
    : { text: "☁ " + t("sy_bar", { t: hm }), cls: "ok", title: t("sy_bar_tip") });
}
document.addEventListener("click", async (e) => {
  const el = e.target.closest('#statusLeft [data-id="sync"]'); if (!el || GG.syncing) return;
  GG.syncing = true; Core.setStatus("sync", { text: "☁ " + t("sy_busy"), cls: "run" });
  try { const d = await api("google", { do: "sync_now" }); syPaint(d); syGot(d); toast(t("sy_done"), "ok", 2500); }
  catch (err) { toast(t("sy_err", { e: syErr(err.message) }), "err", 9000); }
  finally { GG.syncing = false; syLoad(); }
});
function syPaint(d) {
  syBar(d);
  const b = syBox(); if (!b || !d) return;
  $(".g-sync-chk", b).checked = !!d.enabled;
  $(".g-sync-now", b).disabled = !d.enabled;
  $(".g-sync-st", b).textContent = !d.enabled ? "" : d.err ? t("sy_err", { e: syErr(d.err) }) : t("sy_last", { d: d.last ? fmtDT(d.last) : t("sy_never") });
}
async function syLoad() { try { syPaint(await api("google", { do: "sync_status" })); } catch (_) { /* */ } }
async function syGot(d) {
  if (d.other && GG.other !== d.other.computer) { GG.other = d.other.computer; toast(t("sy_other", { c: d.other.computer, d: fmtDT(d.other.last) }), "err sticky", 15000); }
  if (!d.got_at || d.got_at === GG.gotAt) return;
  GG.gotAt = d.got_at;
  toast(t("sy_got", { c: d.got_from || "?", f: syFiles(d.got) }), "ok sticky", 10000);
  try { S.settings = (await api("state")).settings; } catch (_) { /* */ }
  if ((d.got || []).some((n) => n !== "settings.json")) {
    try { if (typeof refreshColls === "function") await refreshColls(); if (typeof reloadView === "function") reloadView(); } catch (_) { /* */ }
  }
}
async function syPoll() {
  try { const d = await api("google", { do: "sync_status" }); syBar(d); if (d.enabled) { syGot(d); syPaint(d); } } catch (_) { /* */ }
}
const _syPaint0 = gPaint;
gPaint = function (s) {                              // eslint-disable-line no-func-assign
  _syPaint0(s);
  const b = syBox(); if (!b) return;
  const on = !!(s && s.connected);
  b.classList.toggle("hidden", !on);
  if (on) syLoad();
};
setInterval(syPoll, 60000);
setTimeout(syPoll, 15000);
