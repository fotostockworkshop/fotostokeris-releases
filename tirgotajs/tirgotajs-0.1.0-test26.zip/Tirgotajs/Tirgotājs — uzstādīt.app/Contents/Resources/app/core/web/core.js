"use strict";
/* Fotostokeris — kopīgā saskarne visiem produktiem (core/web/core.js, noteikumi §5, §6).
   Dod: $, $$, esc, t, applyI18n, api, toast, uiDialog, uiConfirm un window.Core
   (tēma, statusu josla, iestatījumu rāmis, labojumu vēsture, sākuma banneris, aizvēršana).
   Modulis pirms šī faila iestata window.API_PREFIX un window.I18N (savi teksti). */

window.CORE_I18N = {
  lv: {
    cl_tests: "pirms tās {n} testa versijas", cl_now_test: "Tagad darbojas testa versija {v} — {n}. testa versija pēc {prev} ceļā uz {next}.",
    quit: "Aizvērt", quit_title: "Aizvērt programmu", cancel: "Atcelt", saved: "Saglabāts", close: "Aizvērt",
    s_lang: "Valoda", s_theme: "Izskats", theme: "Tēma",
    theme_auto: "Kā sistēmā", theme_light: "Gaišā", theme_dark: "Tumšā", theme_forest: "Meža zaļais", theme_forest_d: "Tumša tēma ar laima zaļu akcentu — dabiska, mierīga, ērta ilgākam darbam",
    s_shared: "Kopīgie dati", s_author: "Noklusējuma autors",
    s_agencies: "Mērķa aģentūras (kopīgas visiem Fotostokera moduļiem):",
    s_myrules: "Mana pieredze ar aģentūrām",
    s_myrules_ph: "Piem.: Getty noraida auto izstāžu bildes. Adobe pieņem auto ielu bildes kā illustrative editorial.",
    s_other: "Cits", s_splash: "Rādīt sākuma banneri",
    app_info: "{app} v{v} · lietotnes datu mape:",
    open_folder: "Atvērt mapi", changelog: "Labojumu vēsture", settings_save: "Saglabāt iestatījumus",
    closed: "Programma aizvērta. Šo logu var aizvērt.",
    conn_lost: "Savienojums ar programmu pārtrūka (piemēram, dators gulēja). Mēģinu atjaunot…",
    conn_dead: "Programma neatbild. Ja dators gulēja, tā varēja aizvērties — palaid to vēlreiz; šī lapa atjaunosies pati.",
    conn_retry: "Mēģināt vēlreiz",
    upd_avail: "Pieejama jauna versija {v} (tev ir {cur}).", upd_install: "Uzstādīt", upd_whats: "Kas jauns", upd_later: "Vēlāk",
    upd_q: "Uzstādīt versiju {v}? Programma lejupielādēs jauno versiju, saglabās pašreizējo (atgriešanai) un palaidīsies no jauna. Tavi dati, paroles un sesijas netiek aiztikti.",
    upd_download: "Lejupielādēju versiju {v}… {p}%", upd_installing: "Uzstādu versiju {v}…", upd_restart: "Versija {v} uzstādīta — programma palaižas no jauna…",
    upd_error: "Atjaunināšana neizdevās: {e}", upd_busy: "Pagaidi, kamēr beidzas datu atjaunošana, un mēģini vēlreiz.",
    upd_dev: "Izstrādes režīmā programma sevi neatjaunina.",
    wn_title: "Kas jauns versijā {v}", wn_since: "Izmaiņas kopš tavas iepriekšējās versijas {v}", wn_none: "Uzstādīta versija {v}.",
    sec_expand: "Izvērst sadaļu", sec_collapse: "Sakļaut sadaļu",
    s_updates: "Atjauninājumi", upd_channel: "Kuras versijas saņemt",
    upd_ch_auto: "Automātiski (testa versijas, ja tagad ir testa versija)", upd_ch_stable: "Tikai gatavās versijas", upd_ch_test: "Arī testa versijas", upd_ch_off: "Nepārbaudīt",
    upd_check: "Pārbaudīt tagad", upd_none: "Tev ir jaunākā versija ({v}).", upd_fail: "Neizdevās pārbaudīt: {e}",
    s_conn: "Pieslēgumi",
    s_conn_d: "Programma paroli neprasa: abonementiem pieslēdzies pakalpojuma oficiālajā lapā (atveras pārlūkā), API atslēgas glabājas tikai šī datora drošajā glabātuvē. Limitu programma neuzstāda — tā rāda, cik iztērēts, un atlikumu, ja to zina.",
    cn_onedrive: "OneDrive", cn_onedrive_d: "Datorā sinhronizētā mape — piem., rezerves kopijām.",
    cn_claude_sub: "Claude abonements", cn_claude_sub_d: "Claude Pro/Max caur Claude Code — bez papildu maksas, tērē abonementa limitus.",
    cn_chatgpt_sub: "ChatGPT abonements", cn_chatgpt_sub_d: "ChatGPT Plus/Pro caur Codex — bez papildu maksas, tērē abonementa limitus.",
    cn_claude_api: "Claude API", cn_claude_api_d: "Anthropic atslēga — maksā par katru pieprasījumu.",
    cn_openai_api: "OpenAI API", cn_openai_api_d: "OpenAI atslēga — maksā par katru pieprasījumu.",
    cn_gemini_api: "Gemini API", cn_gemini_api_d: "Google AI Studio atslēga — ir bezmaksas līmenis ar dienas limitu (Google var izmantot datus apmācībai — tikai nekonfidenciāliem darbiem).",
    cn_ollama: "Ollama (datorā)", cn_ollama_d: "Bez maksas un bez interneta, dati paliek datorā. Der: vienkārši jautājumi, jaudīgs dators (Mac M sērija). Neder: vājš dators, maz vietas (modeļi vairāki GB), sarežģīti jautājumi, latviešu valoda.",
    cn_on: "pieslēgts", cn_off: "nav pieslēgts", cn_checking: "pārbaudu…", cn_not_installed: "nav uzstādīts", cn_no_key: "nav atslēgas", cn_not_logged_in: "nav pieslēdzies",
    cn_not_running: "nedarbojas", cn_no_models: "nav neviena modeļa", cn_err: "kļūda: {e}", cn_found: "atrasta: {p}", cn_nf: "nav atrasta",
    cn_install: "Uzstādīt", cn_login: "Pieslēgties", cn_connect: "Pieslēgt", cn_switch: "Mainīt kontu", cn_wait: "gaidu pieslēgšanos…", cn_ok: "{a}: pieslēgts", cn_switch_q: "Mainīt kontu? Vispirms pārlūkā atver claude.ai / chatgpt.com un pārliecinies, ka tur esi ielogojies ar vajadzīgo kontu — pieslēgšanās lapa ņems to.", cn_check: "Pārbaudīt", cn_logout: "Atslēgties", cn_getkey: "Iegūt atslēgu", cn_download: "Lejupielādēt Ollama",
    cn_key_ph: "ielīmē atslēgu", cn_key_saved_ph: "•••••• (saglabāta)", cn_save: "Saglabāt", cn_forget: "Aizmirst", cn_use_backup: "Izvēlēties mapi rezerves kopijām…", cn_bk_set: "Rezerves kopijas tagad: {p}",
    cn_term: "Atvērts Terminal logs — tur viss notiks pats; pārlūkā ielogojies un apstiprini. Rinda kļūs zaļa pati.",
    cn_spent: "Šomēnes: {n} piepras. · {tok} tokenu", cn_usd: " · ~${u}", cn_bal_ph: "atlikums $", cn_bal_left: "Atlikums: ~${l} (ievadīts {d})", cn_bal_save: "Saglabāt atlikumu",
    cn_limit: "Limits sasniegts {at}{r}", cn_models: "Modeļi: {m}",
    cn_roles: "Kurš AI ko dara", cn_roles_d: "Katram darbam — secība. Ja pirmajam beidzas limits vai ir kļūda, darbu turpina nākamais.", cn_none: "—", cn_first: "1.", cn_second: "2.", cn_third: "3.",
    s_creds: "Pieslēgšanās dati aģentūrām",
    s_creds_d: "Lietotājvārds un parole glabājas tikai šī datora drošajā glabātuvē (Windows — Credential Manager, Mac — Keychain), nevis programmas failos vai mākonī. Kad aģentūra prasa ielogoties, programma pati ieraksta lietotājvārdu un paroli. 2FA kodu, “vai esi cilvēks” pārbaudi un Google/Facebook pieteikšanos dari pats. Katrā datorā paroles jāievada atsevišķi.",
    s_creds_na: "Drošā glabātuve nav pieejama (nav uzstādīta bibliotēka keyring) — palaid programmu no jauna ar palaidēju, tas to uzstādīs. Līdz tam ielogojies aģentūru logos pats.",
    cr_user: "Lietotājvārds / e-pasts", cr_pass: "Parole", cr_saved_ph: "•••••• (saglabāta)",
    cr_save: "Saglabāt", cr_forget: "Aizmirst", cr_saved: "saglabāta ✓", cr_none: "nav saglabāta",
    cr_need_pass: "Ievadi paroli.", cr_forget_q: "Aizmirst {a} lietotājvārdu un paroli šajā datorā?", cr_ok: "{a}: saglabāts drošajā glabātuvē",
    ver_mismatch: "Darbojas cita programmas versija ({server}), bet saskarne ir {page}. Spied “Aizvērt” un palaid programmu no jauna.",
  },
  en: {
    cl_tests: "{n} test versions before it", cl_now_test: "Running test version {v} — test version {n} after {prev} on the way to {next}.",
    quit: "Close", quit_title: "Close the program", cancel: "Cancel", saved: "Saved", close: "Close",
    s_lang: "Language", s_theme: "Appearance", theme: "Theme",
    theme_auto: "As system", theme_light: "Light", theme_dark: "Dark", theme_forest: "Forest green", theme_forest_d: "Dark theme with a lime green accent — natural, calm, comfortable for long sessions",
    s_shared: "Shared data", s_author: "Default author",
    s_agencies: "Target agencies (shared by all Fotostokeris modules):",
    s_myrules: "My experience with agencies",
    s_myrules_ph: "E.g.: Getty rejects auto show photos. Adobe accepts street car photos as illustrative editorial.",
    s_other: "Other", s_splash: "Show the start banner",
    app_info: "{app} v{v} · app data folder:",
    open_folder: "Open folder", changelog: "Changelog", settings_save: "Save settings",
    closed: "The program is closed. You can close this window.",
    conn_lost: "Connection to the program was lost (e.g. the computer was asleep). Reconnecting…",
    conn_dead: "The program does not respond. If the computer was asleep it may have closed — start it again; this page will reload by itself.",
    conn_retry: "Try again",
    upd_avail: "A new version {v} is available (you have {cur}).", upd_install: "Install", upd_whats: "What's new", upd_later: "Later",
    upd_q: "Install version {v}? The program will download it, keep the current version (to go back) and restart. Your data, passwords and sessions are not touched.",
    upd_download: "Downloading version {v}… {p}%", upd_installing: "Installing version {v}…", upd_restart: "Version {v} installed — the program is restarting…",
    upd_error: "Update failed: {e}", upd_busy: "Wait until the data refresh finishes and try again.",
    upd_dev: "In development mode the program does not update itself.",
    wn_title: "What's new in {v}", wn_since: "Changes since your previous version {v}", wn_none: "Version {v} installed.",
    sec_expand: "Expand section", sec_collapse: "Collapse section",
    s_updates: "Updates", upd_channel: "Which versions to receive",
    upd_ch_auto: "Automatic (test versions if a test version is running now)", upd_ch_stable: "Released versions only", upd_ch_test: "Test versions too", upd_ch_off: "Do not check",
    upd_check: "Check now", upd_none: "You have the latest version ({v}).", upd_fail: "Could not check: {e}",
    s_conn: "Connections",
    s_conn_d: "The program never asks for passwords: subscriptions are connected on the provider's official page (opens in the browser), API keys are kept only in this computer's secure store. The program sets no limits — it shows what has been spent and the balance, if known.",
    cn_onedrive: "OneDrive", cn_onedrive_d: "The folder synced on this computer — e.g. for backups.",
    cn_claude_sub: "Claude subscription", cn_claude_sub_d: "Claude Pro/Max via Claude Code — no extra cost, uses the subscription limits.",
    cn_chatgpt_sub: "ChatGPT subscription", cn_chatgpt_sub_d: "ChatGPT Plus/Pro via Codex — no extra cost, uses the subscription limits.",
    cn_claude_api: "Claude API", cn_claude_api_d: "Anthropic key — paid per request.",
    cn_openai_api: "OpenAI API", cn_openai_api_d: "OpenAI key — paid per request.",
    cn_gemini_api: "Gemini API", cn_gemini_api_d: "Google AI Studio key — has a free tier with a daily limit (Google may use the data for training — non-confidential work only).",
    cn_ollama: "Ollama (on this computer)", cn_ollama_d: "Free and offline, data stays on the computer. Good for: simple questions, a powerful computer (Mac M series). Not for: a weak computer, little disk space (models are several GB), complex questions, Latvian.",
    cn_on: "connected", cn_off: "not connected", cn_checking: "checking…", cn_not_installed: "not installed", cn_no_key: "no key", cn_not_logged_in: "not signed in",
    cn_not_running: "not running", cn_no_models: "no models", cn_err: "error: {e}", cn_found: "found: {p}", cn_nf: "not found",
    cn_install: "Install", cn_login: "Sign in", cn_connect: "Connect", cn_switch: "Change account", cn_wait: "waiting for sign-in…", cn_ok: "{a}: connected", cn_switch_q: "Change account? First open claude.ai / chatgpt.com in the browser and make sure you are signed in with the account you want — the sign-in page will use it.", cn_check: "Check", cn_logout: "Disconnect", cn_getkey: "Get a key", cn_download: "Download Ollama",
    cn_key_ph: "paste the key", cn_key_saved_ph: "•••••• (saved)", cn_save: "Save", cn_forget: "Forget", cn_use_backup: "Choose a folder for backups…", cn_bk_set: "Backups now go to: {p}",
    cn_term: "A Terminal window opened — everything runs by itself there; sign in and confirm in the browser. The row will turn green by itself.",
    cn_spent: "This month: {n} requests · {tok} tokens", cn_usd: " · ~${u}", cn_bal_ph: "balance $", cn_bal_left: "Balance: ~${l} (entered {d})", cn_bal_save: "Save balance",
    cn_limit: "Limit reached {at}{r}", cn_models: "Models: {m}",
    cn_roles: "Which AI does what", cn_roles_d: "For each job — an order. If the first one hits its limit or fails, the next one continues.", cn_none: "—", cn_first: "1.", cn_second: "2.", cn_third: "3.",
    s_creds: "Agency sign-in details",
    s_creds_d: "The user name and password are kept only in this computer's secure store (Windows — Credential Manager, Mac — Keychain), not in program files or the cloud. When an agency asks you to sign in, the program fills in the user name and password itself. 2FA codes, “are you human” checks and Google/Facebook sign-in are up to you. Passwords are entered separately on each computer.",
    s_creds_na: "The secure store is not available (the keyring library is not installed) — start the program again with its launcher, it will install it. Until then, sign in to the agency windows yourself.",
    cr_user: "User name / e-mail", cr_pass: "Password", cr_saved_ph: "•••••• (saved)",
    cr_save: "Save", cr_forget: "Forget", cr_saved: "saved ✓", cr_none: "not saved",
    cr_need_pass: "Enter the password.", cr_forget_q: "Forget the {a} user name and password on this computer?", cr_ok: "{a}: saved in the secure store",
    ver_mismatch: "A different program version ({server}) is running, but the page is {page}. Click “Close” and start the program again.",
  },
};

/* §4 aģentūru identifikatori (kopīgo datu ķekšiem) */
const CORE_AGENCIES = [["adobe", "Adobe Stock"], ["shutterstock", "Shutterstock"], ["istock", "iStock / Getty"],
  ["alamy", "Alamy"], ["dreamstime", "Dreamstime"], ["depositphotos", "Depositphotos"], ["123rf", "123RF"],
  ["pond5", "Pond5"], ["envato", "Envato"], ["bigstock", "Bigstock"], ["pixta", "Pixta"], ["canva", "Canva"],
  ["magnific", "Magnific"], ["zoonar", "Zoonar"], ["ingram", "Ingram"]];

window.LANG = window.LANG || "lv";
/* saskarnes valodas (noteikumi §6; test52: + vācu, spāņu, ukraiņu). Kods → nosaukums šajā valodā, datumu lokāle. */
window.LANGS = [["lv", "Latviešu", "lv-LV"], ["en", "English", "en-GB"], ["de", "Deutsch", "de-DE"], ["es", "Español", "es-ES"], ["uk", "Українська", "uk-UA"]];
/* 0.3.1 (lietotājs 2026-11-01): saskarnē ukraiņu valoda — "UA" (lai nejauc ar Lielbritāniju); iekšējais kods paliek "uk" */
window.langCode = (l) => (l === "uk" ? "UA" : String(l || "").toUpperCase());
window.langOk = (l) => (window.LANGS.some((x) => x[0] === l) ? l : "lv");
window.langLocale = () => (window.LANGS.find((x) => x[0] === window.LANG) || window.LANGS[0])[2];
window.t = function (key, vars) {
  const L = window.LANG;
  const m = window.I18N || {}, c = window.CORE_I18N;
  const F = L === "lv" ? "lv" : "en";               // trūkstošs tulkojums → angļu (latviešu — tikai LV)
  let s = (m[L] && m[L][key]) ?? (c[L] && c[L][key]) ?? (m[F] && m[F][key]) ?? (c[F] && c[F][key]) ?? (m.lv && m.lv[key]) ?? c.lv[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = String(s).split("{" + k + "}").join(String(v));
  return s;
};
window.applyI18n = function (root = document) {
  document.documentElement.lang = window.LANG;
  root.querySelectorAll("[data-i18n]").forEach((el) => { el.textContent = t(el.dataset.i18n); });
  root.querySelectorAll("[data-i18n-ph]").forEach((el) => { el.placeholder = t(el.dataset.i18nPh); });
  root.querySelectorAll("[data-i18n-title]").forEach((el) => { el.title = t(el.dataset.i18nTitle); });
};

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => Array.from(el.querySelectorAll(s));
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

/* 2026-11-05 (lietotājs: aizvērts Mac somā "lietots pirms dažām minūtēm"): serverim sakām, cik sekundes lietotājs
   nav kustinājis peli / spiedis taustiņus — sinhronizācijas atzīme "aizņemts" balstās uz īstu darbu, ne uz to,
   ka programma vienkārši ir atvērta (macOS miegā ik pa laikam pamostas uz brīdi). */
window.__lastInput = Date.now();
["mousemove", "mousedown", "keydown", "wheel", "touchstart"].forEach((ev) =>
  window.addEventListener(ev, () => { window.__lastInput = Date.now(); }, { passive: true, capture: true }));
async function api(name, body = {}) {
  let r;
  try {
    r = await fetch("/api/" + (window.API_PREFIX || "") + name, {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Token": window.TOKEN,
        "X-Idle": String(Math.round((Date.now() - window.__lastInput) / 1000)) },
      body: JSON.stringify(body),
    });
  } catch (e) {                       // serveris neatbild (piem. pēc datora miega) — "Failed to fetch"
    if (window.Core) Core.lost();
    const err = new Error(t("conn_lost")); err.lost = true; throw err;
  }
  if (r.status === 403 && window.Core) Core.lost(true);   // programma palaista no jauna (cits žetons)
  const d = await r.json();
  if (!d.ok) { const e = new Error(d.error || "Error"); e.data = d; throw e; }
  return d;
}

function toast(msg, kind = "", ms = 3500) {
  if (msg === t("conn_lost")) return;  // savienojums pārtrūcis — to jau rāda viena josla (Core.lost), ne paziņojums katram pieprasījumam
  const el = document.createElement("div");
  el.className = "toast " + kind;
  const sticky = kind.includes("err") || kind.includes("sticky");
  el.innerHTML = `<span>${esc(msg)}</span>` + (sticky ? `<button class="tclose">×</button>` : "");
  if (sticky) $(".tclose", el).addEventListener("click", () => el.remove());
  $("#toasts").appendChild(el);
  setTimeout(() => el.remove(), sticky ? Math.max(ms, 30000) : ms);
}

/* --- dialogi (bez pārlūka confirm) --- */
let dlgResolve = null;
function uiDialog(msg, buttons) {
  return new Promise((resolve) => {
    if (dlgResolve) dlgResolve(null);
    dlgResolve = resolve;
    $("#dlgMsg").textContent = msg;
    const box = $("#dlgBtns");
    box.innerHTML = "";
    buttons.forEach((b) => {
      const el = document.createElement("button");
      el.textContent = b.label;
      if (b.cls) el.className = b.cls;
      el.addEventListener("click", () => closeDlg(b.v));
      box.appendChild(el);
    });
    $("#dlg").classList.remove("hidden");
    setTimeout(() => box.querySelector("button")?.focus(), 30);
  });
}
function closeDlg(v) {
  $("#dlg").classList.add("hidden");
  const r = dlgResolve; dlgResolve = null;
  if (r) r(v);
}
const uiConfirm = async (msg, ok = "OK") => (await uiDialog(msg, [{ v: true, label: ok, cls: "primary" }, { v: false, label: t("cancel") }])) === true;

window.Core = (function () {
  const C = { settings: {}, state: null, opts: {}, status: {} };

  /* ---------- kopīgie DOM elementi (dialogi, paziņojumi, statusu josla …) ---------- */
  function mountShell() {
    const icon = C.opts.icon || "/static/icon.svg";
    document.body.insertAdjacentHTML("beforeend", `
<footer id="statusbar" class="statusbar">
  <span id="statusLeft" class="row" style="gap:16px;flex-wrap:nowrap;min-width:0"></span>
  <span class="spacer"></span>
  <span class="si" data-i18n="theme"></span>
  <span class="theme-sw" id="themeSw">
    <button data-th="light" data-i18n="theme_light"></button><button data-th="dark" data-i18n="theme_dark"></button><button data-th="auto" data-i18n="theme_auto"></button><button data-th="forest" data-i18n="theme_forest" data-i18n-title="theme_forest_d"></button>
  </span>
</footer>
<div id="changelogModal" class="modal hidden"><div class="modal-box wide">
  <button class="x" id="changelogClose" data-i18n-title="close">×</button>
  <h3 data-i18n="changelog"></h3><div id="changelogBody" class="changelog"></div></div></div>
<div id="dlg" class="modal dlg hidden"><div class="modal-box"><div id="dlgMsg" class="dlg-msg"></div><div id="dlgBtns" class="row-btns end"></div></div></div>
<div id="tip" class="tip hidden"></div>
<div id="splash" class="splash hidden"><div class="splash-card"><img src="${esc(icon)}" alt=""><div class="splash-name" id="splashName"></div><div id="splashVer" class="muted"></div></div></div>
<div id="toasts" class="toasts"></div>
<div id="updBar" class="upd-bar hidden"><span id="updMsg"></span><span id="updBtns" class="row" style="gap:8px">
  <button id="updNotes" class="ghost" data-i18n="upd_whats"></button><button id="updGo" class="primary" data-i18n="upd_install"></button>
  <button id="updLater" class="ghost" data-i18n="upd_later"></button></span></div>
<div id="wnCloud" class="wn-cloud hidden" role="status"><button class="x" id="wnClose" data-i18n-title="close">×</button><div id="wnBody"></div></div>
<div id="connLost" class="conn-lost hidden"><span id="connLostMsg"></span><button id="connRetry" data-i18n="conn_retry"></button></div>`);
    $("#connRetry").addEventListener("click", reconnect);
    $("#updGo").addEventListener("click", installUpdate);
    $("#updNotes").addEventListener("click", showUpdNotes);
    $("#updLater").addEventListener("click", () => {
      $("#updBar").classList.add("hidden");
      try { sessionStorage.setItem("updLater", upd && upd.latest ? upd.latest.version : ""); } catch (_) {}
    });
    $$("#themeSw button").forEach((b) => b.addEventListener("click", () => setTheme(b.dataset.th, true)));
    $("#changelogClose").addEventListener("click", () => $("#changelogModal").classList.add("hidden"));
    $("#wnClose").addEventListener("click", (e) => { e.stopPropagation(); hideWhatsNew(); });
    $("#wnCloud").addEventListener("click", hideWhatsNew);
    $("#wnCloud").addEventListener("mouseenter", () => { clearTimeout(wnTimer); });
    $("#wnCloud").addEventListener("mouseleave", () => { clearTimeout(wnTimer); wnTimer = setTimeout(hideWhatsNew, 8000); });
  }

  /* ---------- tēma ---------- */
  const mq = window.matchMedia ? window.matchMedia("(prefers-color-scheme: dark)") : null;
  function applyTheme() {
    const pref = C.settings.theme || "auto";
    // "Meža zaļais" (kā Vārdotājā 0.9.0-test8) = tumšā tēma + sava palete (core.css [data-palette="forest"])
    const dark = pref === "dark" || pref === "forest" || (pref === "auto" && mq && mq.matches);
    document.documentElement.dataset.theme = dark ? "dark" : "light";
    if (pref === "forest") document.documentElement.dataset.palette = "forest"; else delete document.documentElement.dataset.palette;
    $$("#themeSw button").forEach((b) => b.classList.toggle("on", b.dataset.th === pref));
    if (C.opts.onTheme) C.opts.onTheme(dark);
  }
  if (mq && mq.addEventListener) mq.addEventListener("change", applyTheme);
  async function setTheme(v, persist) {
    C.settings.theme = v;
    applyTheme();
    if (persist) await save({ theme: v });
  }

  /* ---------- statusu josla: modulis iestata savus vienumus ---------- */
  function setStatus(id, item) {           // item: {text, cls: ok|run|err, title} vai null
    if (item) C.status[id] = item; else delete C.status[id];
    $("#statusLeft").innerHTML = Object.values(C.status).map((s) =>
      `<span class="si ${esc(s.cls || "")}" title="${esc(s.title || s.text)}"><i></i>${esc(s.text)}</span>`).join("");
    Object.keys(C.status).forEach((k, i) => { const el = $("#statusLeft").children[i]; if (el) el.dataset.id = k; });
  }

  /* ---------- iestatījumi ---------- */
  async function save(vals) {
    try {
      const d = await api("settings", { settings: vals });
      C.settings = d.settings;
      return d.settings;
    } catch (e) { toast(e.message, "err"); throw e; }
  }

  /* Iestatījumu lapa (§5): Valoda · Izskats · [Kopīgie dati] · moduļa sadaļas · Cits.
     o = {root, shared: ["author","agencies","my_rules"], moduleHtml, otherHtml, load(s), collect(), onSaved(s)} */
  function settingsFrame(o) {
    const root = $(o.root);
    const sh = new Set(o.shared || []);
    root.innerHTML = `<div class="settings">
  <section><h2 data-i18n="s_lang"></h2>
    <select id="sLang">${window.LANGS.map((x) => `<option value="${x[0]}">${window.langCode(x[0])} — ${x[1]}</option>`).join("")}</select></section>
  <section><h2 data-i18n="s_theme"></h2>
    <div class="card-radio">
      <label><input type="radio" name="sTheme" value="light"> <span data-i18n="theme_light"></span></label>
      <label><input type="radio" name="sTheme" value="dark"> <span data-i18n="theme_dark"></span></label>
      <label><input type="radio" name="sTheme" value="auto"> <span data-i18n="theme_auto"></span></label>
      <label data-i18n-title="theme_forest_d"><input type="radio" name="sTheme" value="forest"> <span data-i18n="theme_forest"></span></label>
    </div></section>
  ${o.connections ? `<section id="connSec" data-collapse="conn"><h2 data-i18n="s_conn"></h2>
    <p class="muted small" data-i18n="s_conn_d"></p><div id="connList" class="conns"></div>
    ${(o.connections.jobs || []).length ? `<h3 data-i18n="cn_roles"></h3><p class="muted small" data-i18n="cn_roles_d"></p><div id="connRoles"></div>` : ""}</section>` : ""}
  ${sh.size ? `<section><h2 data-i18n="s_shared"></h2>
    ${sh.has("author") ? `<div class="grid2"><label><span data-i18n="s_author"></span><input id="sAuthor" spellcheck="false"></label></div>` : ""}
    ${sh.has("agencies") ? `<div class="agencies"><span class="small muted" data-i18n="s_agencies"></span>
      ${CORE_AGENCIES.map(([id, n]) => `<label class="chk"><input type="checkbox" class="sAg" value="${id}"> ${esc(n)}</label>`).join("")}</div>` : ""}
    ${sh.has("my_rules") ? `<label><span data-i18n="s_myrules"></span><textarea id="sMyRules" rows="4" spellcheck="false" data-i18n-ph="s_myrules_ph"></textarea></label>` : ""}
  </section>` : ""}
  ${o.moduleHtml || ""}
  ${o.creds && o.creds.length ? `<section id="credsSec" data-collapse="creds"><h2 data-i18n="s_creds"></h2>
    <p class="muted small" data-i18n="s_creds_d"></p><div id="credsNa" class="note warn hidden" data-i18n="s_creds_na"></div>
    <div class="creds">${o.creds.map(([id, n]) => `<div class="cred" data-id="${esc(id)}">
      <span class="cred-n">${esc(n)}</span>
      <input class="cr-u" autocomplete="off" spellcheck="false" data-i18n-ph="cr_user">
      <input class="cr-p" type="password" autocomplete="new-password" data-i18n-ph="cr_pass">
      <button class="cr-save" data-i18n="cr_save"></button>
      <span class="cr-st muted small"></span>
      <button class="ghost cr-forget hidden" data-i18n="cr_forget"></button></div>`).join("")}</div></section>` : ""}
  <section><h2 data-i18n="s_updates"></h2>
    <div class="grid2"><label><span data-i18n="upd_channel"></span>
      <select id="sUpdCh"><option value="auto" data-i18n="upd_ch_auto"></option><option value="stable" data-i18n="upd_ch_stable"></option>
        <option value="test" data-i18n="upd_ch_test"></option><option value="off" data-i18n="upd_ch_off"></option></select></label></div>
    <div class="row"><button id="sUpdCheck" data-i18n="upd_check"></button><span id="sUpdMsg" class="muted small"></span></div>
  </section>
  <section><h2 data-i18n="s_other"></h2>
    <label class="chk"><input type="checkbox" class="sw" id="sSplash"> <span data-i18n="s_splash"></span></label>
    <div id="appInfo" class="muted small app-info"></div>
    <div class="row"><button id="sOpenDir" data-i18n="open_folder"></button>${o.otherHtml || ""}<button id="changelogBtn" data-i18n="changelog"></button></div>
  </section>
  <div class="save-row sticky"><button id="settingsSave" class="primary" data-i18n="settings_save"></button><span id="settingsMsg" class="muted"></span></div>
</div>`;
    applyI18n(root);
    makeCollapsible(root);
    $("#sLang").addEventListener("change", (e) => setLang(e.target.value));
    $$("input[name=sTheme]", root).forEach((r) => r.addEventListener("change", () => setTheme(r.value, true)));
    $("#sOpenDir").addEventListener("click", () => api("reveal").catch((e) => toast(e.message, "err")));
    $("#changelogBtn").addEventListener("click", showChangelog);
    $("#sUpdCh").addEventListener("change", () => save({ update_channel: $("#sUpdCh").value }).catch(() => {}));
    $("#sUpdCheck").addEventListener("click", async () => {
      $("#sUpdMsg").textContent = "…";
      const d = await checkUpdate(true);
      $("#sUpdMsg").textContent = !d ? "" : d.error ? t("upd_fail", { e: d.error }) : d.available ? t("upd_avail", { v: d.latest.version, cur: d.current }) : t("upd_none", { v: d.current });
    });
    const credName = (id) => ((o.creds || []).find((c) => c[0] === id) || [id, id])[1];
    async function loadCreds() {
      if (!$("#credsSec")) return;
      try {
        const d = await api("creds", { names: o.creds.map((c) => c[0]) });
        $("#credsNa").classList.toggle("hidden", d.available);
        $$(".cred", root).forEach((row) => {
          const c = d.creds[row.dataset.id];
          $(".cr-u", row).value = c ? c.user : "";
          $(".cr-p", row).value = "";
          $(".cr-p", row).placeholder = t(c ? "cr_saved_ph" : "cr_pass");
          $(".cr-st", row).textContent = t(c ? "cr_saved" : "cr_none");
          $(".cr-st", row).classList.toggle("ok", !!c);
          $(".cr-forget", row).classList.toggle("hidden", !c);
          $$("input,button", row).forEach((x) => (x.disabled = !d.available));
        });
      } catch (_) { /* toast jau parādīts */ }
    }
    $$(".cred", root).forEach((row) => {
      const id = row.dataset.id;
      $(".cr-save", row).addEventListener("click", async () => {
        const user = $(".cr-u", row).value.trim(), password = $(".cr-p", row).value;
        if (!password && $(".cr-forget", row).classList.contains("hidden")) { toast(t("cr_need_pass"), "err"); return; }
        try {
          await api("cred_save", { name: id, user, password });
          $(".cr-p", row).value = "";
          toast(t("cr_ok", { a: credName(id) }), "ok", 2500);
        } catch (e) { toast(e.message, "err"); }
        loadCreds();
      });
      $(".cr-p", row).addEventListener("keydown", (e) => { if (e.key === "Enter") $(".cr-save", row).click(); });
      $(".cr-forget", row).addEventListener("click", async () => {
        if (!(await uiConfirm(t("cr_forget_q", { a: credName(id) }), t("cr_forget")))) return;
        try { await api("cred_forget", { name: id }); } catch (e) { toast(e.message, "err"); }
        loadCreds();
      });
    });
    /* ---- Pieslēgumi (noteikumi §5 p.2, core/ai.py) ---- */
    const CONN = ["onedrive", "claude_sub", "chatgpt_sub", "claude_api", "openai_api", "gemini_api", "ollama"];
    const AIP = CONN.slice(1);
    const fmtN = (n) => (n || 0).toLocaleString(window.langLocale());
    let connSt = null, connPages = {};
    function connRow(p) {
      const keyed = /_api$/.test(p), sub = /_sub$/.test(p);
      return `<div class="conn" data-p="${p}"><span class="dot cn-dot"></span>
        <div class="cn-main"><b>${esc(t("cn_" + p))}</b> <span class="cn-st muted small"></span>
          <div class="muted small">${esc(t("cn_" + p + "_d"))}</div><div class="cn-info small"></div></div>
        <div class="cn-act">
          ${sub ? `<button class="small-btn primary cn-connect">${esc(t("cn_connect"))}</button><button class="small-btn cn-switch hidden">${esc(t("cn_switch"))}</button>` : ""}
          ${keyed ? `<input class="cn-key" type="password" autocomplete="new-password" placeholder="${esc(t("cn_key_ph"))}"><button class="small-btn cn-ksave">${esc(t("cn_save"))}</button><button class="small-btn ghost cn-getkey">${esc(t("cn_getkey"))}</button>` : ""}
          ${p === "ollama" ? `<button class="small-btn ghost cn-getkey">${esc(t("cn_download"))}</button>` : ""}
          ${p === "onedrive" ? `<button class="small-btn cn-od hidden">${esc(t("cn_use_backup"))}</button>` : sub ? "" : `<button class="small-btn cn-check">${esc(t("cn_check"))}</button>`}
          ${sub || keyed ? `<button class="small-btn ghost cn-logout hidden">${esc(sub ? t("cn_logout") : t("cn_forget"))}</button>` : ""}
          ${keyed ? `<span class="cn-bal"><input class="cn-balv" type="number" step="0.01" min="0" placeholder="${esc(t("cn_bal_ph"))}"><button class="small-btn ghost cn-bsave">${esc(t("cn_bal_save"))}</button></span>` : ""}
        </div></div>`;
    }
    function setRow(p, ok, txt) {
      const row = $(`.conn[data-p="${p}"]`, root);
      if (!row) return;
      $(".cn-dot", row).className = "dot cn-dot " + (ok === true ? "ok" : ok === false ? "off" : "");
      $(".cn-st", row).textContent = txt || "";
    }
    function why(r) { return r.why ? t("cn_" + r.why) !== "cn_" + r.why ? t("cn_" + r.why) : t("cn_err", { e: r.detail || r.why }) : ""; }
    async function loadConn() {
      if (!$("#connList")) return;
      if (!$(".conn", root)) $("#connList").innerHTML = CONN.map(connRow).join("");
      try { const d = await api("ai_status"); connSt = d.status; connPages = d.pages || {}; } catch (_) { return; }
      CONN.forEach((p) => {
        const s = connSt[p] || {}, row = $(`.conn[data-p="${p}"]`, root);
        const info = [];
        if (p === "onedrive") { setRow(p, !!s.path, s.path ? t("cn_found", { p: s.path }) : t("cn_nf")); $(".cn-od", row).classList.toggle("hidden", !s.path); return; }
        if (/_sub$/.test(p)) { subUi(p, false); setRow(p, s.installed ? null : false, s.installed ? t("cn_checking") : t("cn_off"));
          if (s.installed) checkConn(p); }
        if (/_api$/.test(p)) { setRow(p, s.key ? null : false, s.key ? "" : t("cn_no_key")); $(".cn-key", row).placeholder = t(s.key ? "cn_key_saved_ph" : "cn_key_ph"); $(".cn-logout", row).classList.toggle("hidden", !s.key);
          const b = (C.settings.ai_balance || {})[p]; $(".cn-balv", row).value = b ? b.amount : ""; }
        if (p === "ollama") { setRow(p, s.running ? (s.models.length ? true : null) : false, s.running ? (s.models.length ? t("cn_on") : t("cn_no_models")) : t("cn_not_running")); if (s.models.length) info.push(t("cn_models", { m: s.models.slice(0, 6).join(", ") })); }
        const sp = s.spent || {};
        if (sp.n) info.push(t("cn_spent", { n: fmtN(sp.n), tok: fmtN((sp.tin || 0) + (sp.tout || 0)) }) + (sp.usd ? t("cn_usd", { u: sp.usd.toFixed(2) }) : ""));
        if (s.balance) info.push(t("cn_bal_left", { l: Number(s.balance.left).toFixed(2), d: s.balance.at }));
        if (s.limit) info.push(t("cn_limit", { at: s.limit.at.replace("T", " "), r: s.limit.reset ? " · " + s.limit.reset : "" }));
        $(".cn-info", row).textContent = info.join(" · ");
      });
      renderRoles();
    }
    /* abonements: pieslēgts → "Mainīt kontu" + "Atslēgties"; nav → "Pieslēgt" (test48) */
    function subUi(p, on) {
      const row = $(`.conn[data-p="${p}"]`, root); if (!row) return;
      $(".cn-connect", row).classList.toggle("hidden", on);
      $(".cn-switch", row).classList.toggle("hidden", !on);
      $(".cn-logout", row).classList.toggle("hidden", !on);
    }
    const polls = {};
    function pollConn(p) {             // pēc "Pieslēgt": ik 3 s pārbauda (līdz 5 min) — rinda kļūst zaļa pati
      clearInterval(polls[p]);
      const t0 = Date.now();
      polls[p] = setInterval(async () => {
        if (Date.now() - t0 > 300e3 || !$("#connList")) { clearInterval(polls[p]); return; }
        try { const d = await api("ai_check", { p }); if (d.res && d.res.ok) { clearInterval(polls[p]); await checkConn(p); toast(t("cn_ok", { a: t("cn_" + p) }), "ok", 4000); } } catch (_) { /* */ }
      }, 3000);
    }
    async function checkConn(p) {
      if (!/_sub$/.test(p)) setRow(p, null, t("cn_checking"));
      try { const d = await api("ai_check", { p }); const r = d.res || {};
        if (/_sub$/.test(p)) subUi(p, !!r.ok);
        setRow(p, !!r.ok, r.ok ? t("cn_on") + (r.who ? " · " + r.who : "") + (r.plan ? " · " + r.plan : "") : (r.why === "not_installed" || r.why === "not_logged_in" ? t("cn_off") : why(r)));
        if (r.ok && r.models && r.models.length) $(`.conn[data-p="${p}"] .cn-info`, root).textContent = t("cn_models", { m: r.models.slice(0, 6).join(", ") });
      } catch (e) { setRow(p, false, e.message); }
    }
    $("#connList") && $("#connList").addEventListener("click", async (e) => {
      const b = e.target.closest("button"); if (!b) return;
      const row = b.closest(".conn"), p = row.dataset.p;
      try {
        if (b.classList.contains("cn-check")) return checkConn(p);
        if (b.classList.contains("cn-connect")) { await api("ai_connect", { p }); setRow(p, null, t("cn_wait")); toast(t("cn_term"), "ok", 9000); pollConn(p); return; }
        if (b.classList.contains("cn-switch")) { if (!(await uiConfirm(t("cn_switch_q"), t("cn_switch")))) return; await api("ai_switch", { p }); subUi(p, false); setRow(p, null, t("cn_wait")); toast(t("cn_term"), "ok", 9000); pollConn(p); return; }
        if (b.classList.contains("cn-getkey")) { await api("open_url", { url: connPages[p] }); return; }
        if (b.classList.contains("cn-logout")) { if (!(await uiConfirm((/_sub$/.test(p) ? t("cn_logout") : t("cn_forget")) + " — " + t("cn_" + p) + "?", t("cn_logout")))) return; await api(/_api$/.test(p) ? "ai_key" : "ai_logout", { p, forget: true }); return loadConn(); }
        if (b.classList.contains("cn-ksave")) { const k = $(".cn-key", row).value.trim(); if (!k) return; const d = await api("ai_key", { p, key: k }); $(".cn-key", row).value = ""; await loadConn(); const r = d.res || {}; setRow(p, !!r.ok, r.ok ? t("cn_on") : why(r)); return; }
        if (b.classList.contains("cn-bsave")) { const v = $(".cn-balv", row).value; const bal = Object.assign({}, C.settings.ai_balance || {});
          if (v === "") delete bal[p]; else bal[p] = { amount: +v, at: new Date().toISOString().slice(0, 10) };
          await save({ ai_balance: bal }); toast(t("saved"), "ok", 1500); return loadConn(); }
        if (b.classList.contains("cn-od")) {   /* mapes izvēle, sākot OneDrive; logā var arī izveidot jaunu mapi (lietotājs 2026-10-30) */
          const r = await api("pick_folder", { start: connSt.onedrive.path });
          if (!r.path) return;
          await save({ backup_dir: r.path });
          toast(t("cn_bk_set", { p: r.path }), "ok", 4000); if (o.onSaved) o.onSaved(C.settings); return; }
      } catch (err) { toast(err.message, "err"); }
    });
    function renderRoles() {
      const box = $("#connRoles"); if (!box) return;
      const roles = C.settings.ai_roles || {};
      const opts = (sel) => `<option value="">${esc(t("cn_none"))}</option>` + AIP.map((p) => `<option value="${p}"${p === sel ? " selected" : ""}>${esc(t("cn_" + p))}</option>`).join("");
      box.innerHTML = `<table class="t"><tbody>` + o.connections.jobs.map(([j, name]) => `<tr data-job="${esc(j)}"><td>${esc(name)}</td>` +
        [0, 1, 2].map((i) => `<td>${esc(t(["cn_first", "cn_second", "cn_third"][i]))} <select class="cn-role">${opts((roles[j] || [])[i] || "")}</select></td>`).join("") + `</tr>`).join("") + `</tbody></table>`;
    }
    function collectRoles() {
      const out = {};
      $$("#connRoles tr[data-job]", root).forEach((tr) => { const v = $$(".cn-role", tr).map((s) => s.value).filter(Boolean); if (v.length) out[tr.dataset.job] = [...new Set(v)]; });
      return out;
    }
    $("#settingsSave").addEventListener("click", async () => {
      const s = C.settings;
      const vals = { lang: $("#sLang").value, show_splash: $("#sSplash").checked, update_channel: $("#sUpdCh").value };
      if ($("#sAuthor")) vals.author = $("#sAuthor").value.trim();
      if ($(".sAg")) vals.target_agencies = $$(".sAg").filter((c) => c.checked).map((c) => c.value);
      if ($("#sMyRules")) vals.my_rules = $("#sMyRules").value;
      if ($("#connRoles")) vals.ai_roles = collectRoles();
      Object.assign(vals, o.collect ? o.collect(s) : {});
      try {
        const ns = await save(vals);
        $("#settingsMsg").textContent = t("saved");
        toast(t("saved"), "ok", 1500);
        if (o.onSaved) o.onSaved(ns);
      } catch (_) { /* toast jau parādīts */ }
    });
    return {
      load() {
        const s = C.settings;
        $("#sLang").value = window.LANG;
        $$("input[name=sTheme]", root).forEach((r) => (r.checked = r.value === (s.theme || "auto")));
        if ($("#sAuthor")) $("#sAuthor").value = s.author || "";
        $$(".sAg").forEach((c) => (c.checked = (s.target_agencies || []).includes(c.value)));
        if ($("#sMyRules")) $("#sMyRules").value = s.my_rules || "";
        $("#sSplash").checked = s.show_splash !== false;
        $("#sUpdCh").value = s.update_channel || "auto";
        const st = C.state || {};
        $("#appInfo").innerHTML = esc(t("app_info", { app: st.app || "", v: window.PAGE_VERSION })) + `<br><code>${esc(st.app_dir || "")}</code>`;
        $("#settingsMsg").textContent = "";
        loadCreds();
        loadConn();
        if (o.load) o.load(s);
      },
    };
  }

  /* ---------- sakļaujamas iestatījumu sadaļas (lietotājs 2026-10-30; noteikumi §5) ----------
     <section data-collapse="id">: klikšķis uz virsraksta sakļauj/atver; bulta (dubults ševrons) uz leju = var izvērst,
     uz augšu = var sakļaut; paskaidrojums uzbraucot. Noklusējumā sakļauta; stāvoklis atcerēts (localStorage). */
  const CHEV = `<svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path class="c1" d="M4 3h5l7 7-7 7H4l7-7z" transform="translate(0 -1) rotate(90 12 12)"/><path class="c2" d="M4 3h5l7 7-7 7H4l7-7z" transform="translate(0 5) rotate(90 12 12)"/></svg>`;
  function makeCollapsible(root) {
    $$("section[data-collapse]", root).forEach((sec) => {
      const h = $("h2", sec);
      if (!h || sec.querySelector(":scope > .sec-body")) return;
      const body = document.createElement("div");
      body.className = "sec-body";
      while (h.nextSibling) body.appendChild(h.nextSibling);
      sec.appendChild(body);
      if (h.dataset.i18n) {                    // applyI18n pārraksta virsraksta tekstu — tekstam savs elements
        const sp = document.createElement("span");
        sp.dataset.i18n = h.dataset.i18n; sp.textContent = h.textContent;
        h.removeAttribute("data-i18n"); h.textContent = ""; h.appendChild(sp);
      }
      const b = document.createElement("button");
      b.type = "button"; b.className = "sec-tog"; b.innerHTML = CHEV;
      h.appendChild(b);
      h.classList.add("sec-h");
      const key = "sec:" + sec.dataset.collapse;      // localStorage ir atsevišķs katram modulim (savs ports)
      const set = (open, save) => {
        sec.classList.toggle("collapsed", !open);
        b.title = t(open ? "sec_collapse" : "sec_expand");
        b.setAttribute("aria-label", b.title); b.setAttribute("aria-expanded", String(open));
        if (save) try { localStorage.setItem(key, open ? "1" : "0"); } catch (_) {}
      };
      let open = false;
      try { open = localStorage.getItem(key) === "1"; } catch (_) {}
      set(open, false);
      h.addEventListener("click", () => set(sec.classList.contains("collapsed"), true));
    });
  }

  function showChangelog() {
    /* testa versiju skaits (lietotājs 2026-10-30): ierakstā `tests: N` — cik testa versiju bija pirms šīs versijas;
       ja pašlaik darbojas testa versija — augšā rinda "testa versija N pēc X" */
    const cl = window.CHANGELOG || [];
    const tv = String(window.PAGE_VERSION || "").match(/^(.+)-test(\d+)$/);
    const head = tv ? `<p class="muted small">${esc(t("cl_now_test", { v: window.PAGE_VERSION, n: tv[2], prev: (cl[0] || {}).v || "–", next: tv[1] }))}</p>` : "";
    $("#changelogBody").innerHTML = head + cl.map((c) => `<h4>${esc(c.v)} <span class="muted small">${esc(c.d)}${c.tests ? " · " + esc(t("cl_tests", { n: c.tests })) : ""}</span></h4><ul>${(c[window.LANG] || c.lv).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`).join("");
    $("#changelogModal").classList.remove("hidden");
  }

  /* ---------- atjauninājumi (noteikumi §9a) ---------- */
  let upd = null;
  async function checkUpdate(force = false) {
    let d;
    try { d = await api("update_check", { force }); } catch (_) { return null; }
    upd = d;
    const bar = $("#updBar");
    if (d.available && d.latest) {
      let dismissed = null;
      try { dismissed = sessionStorage.getItem("updLater"); } catch (_) {}
      if (force || dismissed !== d.latest.version) {
        $("#updMsg").textContent = t("upd_avail", { v: d.latest.version, cur: d.current });
        bar.classList.remove("hidden");
      }
    } else bar.classList.add("hidden");
    return d;
  }
  async function installUpdate() {
    if (!upd || !upd.latest) return;
    const v = upd.latest.version;
    if (!upd.can_install) { toast(t("upd_dev"), "err"); return; }
    if (!(await uiConfirm(t("upd_q", { v }), t("upd_install")))) return;
    try { await api("update_install", { latest: upd.latest }); }
    catch (e) { toast(e.message === "busy" ? t("upd_busy") : t("upd_error", { e: e.message }), "err"); return; }
    $("#updBtns").classList.add("hidden");
    const poll = async () => {
      let s;
      try { s = (await api("update_status")).state; } catch (_) { return setTimeout(poll, 1500); }   // pārstartējas
      if (s.status === "download") $("#updMsg").textContent = t("upd_download", { v, p: s.pct || 0 });
      else if (s.status === "install") $("#updMsg").textContent = t("upd_installing", { v });
      else if (s.status === "restart") { $("#updMsg").textContent = t("upd_restart", { v }); quitting = false; }
      else if (s.status === "error") { $("#updMsg").textContent = t("upd_error", { e: s.msg }); $("#updBtns").classList.remove("hidden"); return; }
      setTimeout(poll, 800);
    };
    poll();
  }
  function showUpdNotes() {
    const n = (upd && upd.latest && upd.latest.notes) || {};
    const list = n[window.LANG] || (window.LANG !== "lv" && n.en) || n.lv || [];
    $("#changelogBody").innerHTML = `<h4>${esc(upd.latest.version)} <span class="muted small">${esc(upd.latest.date || "")}</span></h4>` +
      (Array.isArray(list) ? `<ul>${list.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>` : `<p>${esc(list)}</p>`);
    $("#changelogModal").classList.remove("hidden");
  }

  /* ---------- "Kas jauns" pēc atjaunināšanas (lietotājs 2026-10-30; noteikumi §9a) ----------
     Nedaudz caurspīdīgs zaļš mākonītis ar izmaiņām kopš iepriekšējās uzstādītās versijas (ja izlaistas vairākas —
     visas, jaunākā augšā). Avoti: izlaidumu manifesta vēsture (arī testa versijas) + labojumu vēsture (changelog.js).
     Aizver ar × vai klikšķi; pazūd pats pēc ~20 s (kamēr pele virs tā — negaida). */
  let wnTimer = null;
  function verKey(v) {
    const m = String(v || "").match(/^\s*v?(\d+)\.(\d+)\.(\d+)(?:-([A-Za-z]+)(\d*))?/);
    if (!m) return [0, 0, 0, 0, 0];
    return [+m[1], +m[2], +m[3], m[4] == null ? 1 : 0, m[4] == null ? 0 : +(m[5] || 0)];
  }
  function verCmp(a, b) {
    const x = verKey(a), y = verKey(b);
    for (let i = 0; i < 5; i++) if (x[i] !== y[i]) return x[i] < y[i] ? -1 : 1;
    return 0;
  }
  function hideWhatsNew() {
    clearTimeout(wnTimer);
    const c = $("#wnCloud");
    if (!c || c.classList.contains("hidden")) return;
    c.classList.add("fade");
    setTimeout(() => { c.classList.add("hidden"); c.classList.remove("fade"); }, 400);
  }
  async function whatsNew() {
    let d;
    try { d = await api("whatsnew"); } catch (_) { return; }
    if (!d || !d.show) return;
    const lang = window.LANG;
    const ent = {};
    for (const e of d.entries || []) {
      const n = e.notes || {};
      ent[e.version] = { v: e.version, d: e.date || "", items: Array.isArray(n[lang]) ? n[lang] : (lang !== "lv" && Array.isArray(n.en)) ? n.en : Array.isArray(n.lv) ? n.lv : [] };
    }
    for (const c of window.CHANGELOG || []) {         // gatavās versijas no labojumu vēstures
      if (verCmp(c.v, d.from) > 0 && verCmp(c.v, d.to) <= 0) ent[c.v] = { v: c.v, d: c.d || "", items: c[lang] || (lang !== "lv" && c.en) || c.lv || [] };
    }
    const list = Object.values(ent).filter((e) => e.items.length).sort((a, b) => verCmp(b.v, a.v));
    $("#wnBody").innerHTML = `<h4>${esc(t("wn_title", { v: d.to }))}</h4>` +
      (list.length > 1 || (list[0] && list[0].v !== d.to) ? `<p class="small">${esc(t("wn_since", { v: d.from }))}</p>` : "") +
      (list.length ? list.map((e) => (list.length > 1 ? `<h5>${esc(e.v)} <span class="small">${esc(e.d)}</span></h5>` : "") +
        `<ul>${e.items.map((x) => `<li>${esc(x)}</li>`).join("")}</ul>`).join("") : `<p>${esc(t("wn_none", { v: d.to }))}</p>`);
    const c = $("#wnCloud");
    c.classList.remove("hidden");
    clearTimeout(wnTimer);
    wnTimer = setTimeout(hideWhatsNew, 20000);
    api("whatsnew_seen").catch(() => {});
  }

  /* ---------- savienojums ar serveri (miegs, pārstartēšana) ---------- */
  let lostTimer = null, lostSince = 0, quitting = false;
  function lost(restarted = false) {
    if (quitting) return;
    if (!lostSince) lostSince = Date.now();
    const box = $("#connLost");
    if (box) {
      box.classList.remove("hidden");
      $("#connLostMsg").textContent = t(Date.now() - lostSince > 15000 ? "conn_dead" : "conn_lost");
    }
    if (restarted) return reconnect();
    if (!lostTimer) lostTimer = setTimeout(reconnect, 3000);
  }
  /* Ja serveris atbild — pārlādējam lapu (jauns žetons, ja programma palaista no jauna). */
  async function reconnect() {
    lostTimer = null;
    try {
      const r = await fetch("/", { cache: "no-store" });
      // jaunā programma var atbildēt uz "/" jau palaišanās laikā — pārlādējam tikai, kad atdod arī stila failu
      const c = r.ok && await fetch("/core/core.css?t=" + Date.now(), { cache: "no-store" });
      if (r.ok && c && c.ok) { await new Promise((ok) => setTimeout(ok, 500)); location.reload(); return; }
    } catch (_) { /* vēl neatbild */ }
    lost();
  }

  /* ---------- valoda ---------- */
  function setLang(lang, persist = true) {
    window.LANG = window.langOk(lang);
    applyI18n();
    document.title = t("app_name");
    if ($("#langQuick")) $("#langQuick").value = window.LANG;
    if ($("#sLang")) $("#sLang").value = window.LANG;
    langMenu();
    if (persist) save({ lang: window.LANG }).catch(() => {});
    if (C.opts.onLang) C.opts.onLang(window.LANG);
  }

  /* 0.3.1: valodu izvēlne galvenē — sakļauta kā agrāk ("LV ⌃⌄"), atvērtā sarakstā karodziņš + kods + nosaukums
     (Windows karodziņu emocijzīmes nerāda → SVG /core/flags/<lang>.svg). Pārlūka <select> paliek paslēpts (vērtībai). */
  function langMenu() {
    const sel = $("#langQuick");
    if (!sel || $("#langMenuBtn")) { if ($("#langMenuBtn")) $("#langMenuBtn").firstChild.textContent = window.langCode(window.LANG) + " "; return; }
    sel.style.display = "none";
    const wrap = document.createElement("div"); wrap.className = "lang-menu";
    wrap.innerHTML = `<button type="button" id="langMenuBtn" class="lang-quick" aria-haspopup="listbox">${window.langCode(window.LANG)} <span class="lm-caret">⌃⌄</span></button>
      <div class="lm-list hidden" role="listbox">${window.LANGS.map((x) => `<button type="button" role="option" data-l="${x[0]}">
        <img src="/core/flags/${x[0]}.svg" alt=""><b>${window.langCode(x[0])}</b><span>${esc(x[1])}</span></button>`).join("")}</div>`;
    sel.after(wrap);
    const btn = $("#langMenuBtn"), list = wrap.querySelector(".lm-list");
    const close = () => list.classList.add("hidden");
    const open = () => { list.classList.remove("hidden"); [...list.children].forEach((b) => b.classList.toggle("on", b.dataset.l === window.LANG));
      (list.querySelector(".on") || list.firstElementChild).focus(); };
    btn.addEventListener("click", (e) => { e.stopPropagation(); list.classList.contains("hidden") ? open() : close(); });
    list.addEventListener("click", (e) => { const b = e.target.closest("[data-l]"); if (!b) return; close(); setLang(b.dataset.l); });
    list.addEventListener("keydown", (e) => {
      const items = [...list.children], i = items.indexOf(document.activeElement);
      if (e.key === "ArrowDown") { e.preventDefault(); items[(i + 1) % items.length].focus(); }
      else if (e.key === "ArrowUp") { e.preventDefault(); items[(i - 1 + items.length) % items.length].focus(); }
      else if (e.key === "Escape") { close(); btn.focus(); }
    });
    document.addEventListener("click", (e) => { if (!wrap.contains(e.target)) close(); });
  }

  /* ---------- sākums: o = {icon, onLang, onTheme, busyOnQuit(): bool, quitQ} ---------- */
  function init(o = {}) {
    C.opts = o;
    mountShell();
    applyI18n();
    if ($("#langQuick")) $("#langQuick").addEventListener("change", (e) => setLang(e.target.value));
    if ($("#quitBtn")) $("#quitBtn").addEventListener("click", async () => {
      if (o.busyOnQuit && o.busyOnQuit() && !(await uiConfirm(o.quitQ ? o.quitQ() : t("quit_title"), t("quit")))) return;
      quitting = true;
      try { await api("quit"); } catch (_) {}
      document.body.innerHTML = `<div style="padding:60px;text-align:center;color:#6f778b;font:15px sans-serif">${esc(t("closed"))}</div>`;
      setTimeout(() => window.close(), 300);
    });
    setInterval(() => api("ping").catch(() => {}), 60000);
    // pēc datora miega / loga atgriešanās — uzreiz pārbaudām savienojumu
    document.addEventListener("visibilitychange", () => { if (!document.hidden) api("ping").catch(() => {}); });
    window.addEventListener("focus", () => api("ping").catch(() => {}));
  }

  /* Stila faili neielādējās (piem. lapa pārlādējās, kamēr programma pēc atjaunināšanas vēl palaidās) —
     pārlādējam vēlreiz (ne vairāk kā 3 reizes pēc kārtas). */
  function checkStyles() {
    let n = 0;
    try { n = +sessionStorage.getItem("css_retry") || 0; } catch (_) {}
    const okCss = !!getComputedStyle(document.documentElement).getPropertyValue("--accent").trim();
    if (okCss) { try { sessionStorage.removeItem("css_retry"); } catch (_) {} return; }
    if (n >= 3) return;
    try { sessionStorage.setItem("css_retry", String(n + 1)); } catch (_) {}
    setTimeout(() => location.reload(), 1500);
  }
  if (document.readyState === "complete") checkStyles(); else window.addEventListener("load", checkStyles);

  /* pēc servera "state": iestatījumi, valoda, tēma, versija, banneris */
  function boot(st) {
    C.state = st;
    C.settings = st.settings || {};
    window.LANG = window.langOk(C.settings.lang);
    if ($("#langQuick")) $("#langQuick").innerHTML = window.LANGS.map((x) => `<option value="${x[0]}">${window.langCode(x[0])}</option>`).join("");
    langMenu();
    applyTheme();
    applyI18n();
    document.title = t("app_name");
    if ($("#langQuick")) $("#langQuick").value = window.LANG;
    if ($("#appVer")) $("#appVer").textContent = "v" + st.version;
    $("#splashName").textContent = t("app_name");
    $("#splashVer").textContent = "v" + st.version;
    if (window.PAGE_VERSION && st.version !== window.PAGE_VERSION) toast(t("ver_mismatch", { server: st.version, page: window.PAGE_VERSION }), "err");
    setTimeout(() => checkUpdate(false), 3000);
    setTimeout(whatsNew, 2200);
    setInterval(() => checkUpdate(false), 6 * 3600e3);
    let seen = null;
    try { seen = sessionStorage.getItem("boot"); } catch (_) {}
    if (C.settings.show_splash !== false && seen !== st.boot) {
      try { sessionStorage.setItem("boot", st.boot); } catch (_) {}
      /* 0.3.1: modulim ir savs sākuma banneris (window.BANNER, core/web/banner.js; docs/sakuma-banneris.md) */
      if (window.CoreBanner && window.BANNER && window.CoreBanner.start(window.LANG, st.version)) return;
      const sp = $("#splash");
      sp.classList.remove("hidden");
      setTimeout(() => { sp.classList.add("fade"); setTimeout(() => sp.classList.add("hidden"), 500); }, 1400);
    }
  }

  return {
    init, boot, save, setLang, setTheme, setStatus, settingsFrame, showChangelog, lost, checkUpdate, whatsNew, verCmp,
    get settings() { return C.settings; }, set settings(v) { C.settings = v; },
    get state() { return C.state; },
  };
})();
