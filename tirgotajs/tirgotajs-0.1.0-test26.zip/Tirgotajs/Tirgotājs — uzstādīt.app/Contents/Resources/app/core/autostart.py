"""Palaist kopā ar datoru (lēmums 2026-11-10 13:58; noteikumi §6 — pārslēdzējs). Datora iestatījums, nesinhronizē.

Windows: HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\<Slug> = "<pythonw.exe>" "<Slug>.py" --no-window
Mac: ~/Library/LaunchAgents/com.fotostockworkshop.<slug>.plist (RunAtLoad) ar to pašu komandu.
Palaiž bez loga (tikai serveris fonā); lietotājs logu atver kā parasti (palaidējs aptur fona instanci un atver logu).
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from . import app as _app
from . import config


def _cmd() -> list[str]:
    a = _app.current()
    exe = sys.executable
    if config.IS_WIN and exe.lower().endswith("python.exe"):
        w = exe[:-len("python.exe")] + "pythonw.exe"
        if os.path.isfile(w):
            exe = w
    script = Path(sys.argv[0]).resolve() if sys.argv and sys.argv[0].endswith(".py") else \
        Path(a.web_dir).resolve().parent / f"{a.slug}.py"
    return [exe, str(script), "--no-window"]


def _plist() -> Path:
    return Path.home() / "Library" / "LaunchAgents" / f"com.fotostockworkshop.{_app.current().slug.lower()}.plist"


def enabled() -> bool:
    slug = _app.current().slug
    try:
        if config.IS_WIN:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as k:
                winreg.QueryValueEx(k, slug)
                return True
        if config.IS_MAC:
            return _plist().is_file()
    except OSError:
        return False
    return False


def set_enabled(on: bool) -> dict:
    """Ieslēdz / izslēdz; atgriež {"ok", "on", "error"}. Linux — nav atbalstīts."""
    slug = _app.current().slug
    cmd = _cmd()
    try:
        if config.IS_WIN:
            import subprocess
            import winreg
            line = subprocess.list2cmdline(cmd)
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0,
                                winreg.KEY_SET_VALUE) as k:
                if on:
                    winreg.SetValueEx(k, slug, 0, winreg.REG_SZ, line)
                else:
                    try:
                        winreg.DeleteValue(k, slug)
                    except FileNotFoundError:
                        pass
        elif config.IS_MAC:
            p = _plist()
            if on:
                from xml.sax.saxutils import escape
                p.parent.mkdir(parents=True, exist_ok=True)
                args = "".join(f"<string>{escape(c)}</string>" for c in cmd)
                p.write_text('<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" '
                             '"http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n<plist version="1.0"><dict>'
                             f"<key>Label</key><string>{escape(p.stem)}</string>"
                             f"<key>ProgramArguments</key><array>{args}</array>"
                             "<key>RunAtLoad</key><true/></dict></plist>\n", encoding="utf-8")
            elif p.is_file():
                p.unlink()
        else:
            return {"ok": False, "on": False, "error": "unsupported"}
    except OSError as e:
        print("palaist kopā ar datoru:", e)
        return {"ok": False, "on": enabled(), "error": str(e)[:200]}
    print(f"palaist kopā ar datoru: {'ieslēgts' if on else 'izslēgts'} ({' '.join(cmd)})")
    return {"ok": True, "on": enabled()}
