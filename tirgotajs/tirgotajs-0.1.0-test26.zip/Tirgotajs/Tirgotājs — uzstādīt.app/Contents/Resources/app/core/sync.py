"""Sinhronizācija starp datoriem caur Google Drive — 2. daļa, 1. posms (noteikumi docs/fotostokeris-dati.md §7a).

Drive: Fotostokeris/<Slug>/sync/  settings.json (kopīgie iestatījumi), App.sync_files, sync.json (rev katram failam), lock.json.
Vietēji: <datu mape>/sync_state.json — katram failam pēdējā sinhronizētā versija (bāze trīspusējai apvienošanai).
Konfliktā (viena atslēga mainīta abos datoros atšķirīgi) uzvar šis dators. "Aizņemts" — pagaidām tikai brīdinājums.
"""
from __future__ import annotations

import hashlib
import json
import os
import platform
import threading
import time
from datetime import datetime, timezone

from . import app as _app
from . import config

LOCAL_SYNC = {"google_sync", "sync_last", "sync_err", "last_folder", "window", "seen_version"}
CHECK_S = 120                 # vietējo izmaiņu pārbaude
REMOTE_S = 600                # Drive pārbaude
FRESH_S = 15 * 60             # cita datora atzīme "aizņemts" svaiga
_lock = threading.RLock()
_st = {"ready": False, "thread": None, "last_remote": 0.0, "running": False, "got": [], "got_at": "", "got_from": "", "other": None,
       "sent": [], "boot": time.time()}
_MISSING = object()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def clean_name(n: str | None) -> str | None:
    """Datora nosaukums bez tehniskās astes ".local" (Mac) — lietotājs 2026-11-04. Lieto arī vecajiem ierakstiem Drive."""
    if not n:
        return n
    return n[:-6] if n.lower().endswith(".local") else n


def computer() -> str:
    return clean_name(platform.node()) or "?"


def enabled() -> bool:
    if not config.get("google_sync"):
        return False
    try:
        from . import google
        return google.connected()
    except Exception:
        return False


def _local_keys() -> set:
    from .backup import LOCAL_KEYS
    return set(LOCAL_KEYS) | LOCAL_SYNC | set(getattr(_app.current(), "local_keys", ()) or ())


def _virtual() -> dict:
    return getattr(_app.current(), "sync_virtual", None) or {}


def files() -> list[str]:
    return ["settings.json"] + list(getattr(_app.current(), "sync_files", ()) or ()) + list(_virtual())


def _canon(d) -> str:
    return json.dumps(d, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def _md5(d) -> str | None:
    return None if d is None else hashlib.md5(_canon(d).encode("utf-8")).hexdigest()


# --------------------------------------------------------------------------- vietējie faili

def _read(name: str):
    if name in _virtual():
        try:
            return _virtual()[name][0]()
        except Exception as e:
            print("sinhronizācija: nolasīt", name, e)
            return None
    if name == "settings.json":
        lk = _local_keys()
        return {k: v for k, v in config.settings().data.items() if k not in lk}
    p = config.app_dir() / name
    try:
        with open(p, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _write(name: str, data) -> None:
    if name in _virtual():
        _virtual()[name][1](data)
        return
    if name == "settings.json":
        s = config.settings()
        lk = _local_keys()
        with s.lock:
            for k in [k for k in s.data if k not in lk and k not in data]:
                s.data.pop(k, None)
            for k, v in data.items():
                if k not in lk:
                    s.data[k] = v
            s.save()
        return
    p = config.app_dir() / name
    tmp = p.with_name(p.name + ".synctmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


def _state_path():
    return config.app_dir() / "sync_state.json"


def _state_load() -> dict:
    try:
        with open(_state_path(), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def _state_save(st: dict) -> None:
    tmp = _state_path().with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(st, f, ensure_ascii=False)
    os.replace(tmp, _state_path())


# --------------------------------------------------------------------------- trīspusēja apvienošana

def _byid(v) -> bool:
    return isinstance(v, list) and bool(v) and all(isinstance(x, dict) and "id" in x for x in v)


def _norm(d):
    """Saraksts ar ierakstiem, kam ir "id" (prepared.json items, templates.json) → vārdnīca pēc id (apvieno pa ierakstiem)."""
    if _byid(d):
        return {"__by_id__": {str(x["id"]): x for x in d}}
    if isinstance(d, dict):
        out = {}
        for k, v in d.items():
            if isinstance(v, list) and v and all(isinstance(x, dict) and "id" in x for x in v):
                out[k] = {"__by_id__": {str(x["id"]): x for x in v}}
            else:
                out[k] = v
        return out
    return d


def _denorm(d):
    if isinstance(d, dict) and set(d) == {"__by_id__"}:
        return list(d["__by_id__"].values())
    if isinstance(d, dict):
        return {k: (list(v["__by_id__"].values()) if isinstance(v, dict) and "__by_id__" in v else v) for k, v in d.items()}
    return d


def merge3(base, local, remote, prefer_remote: bool = False):
    """prefer_remote — dators pievienojas pirmo reizi (bāzes nav): konfliktā uzvar Drive (konta dati), ne noklusējumi."""
    if local == remote:
        return local
    if base is not _MISSING and local == base:
        return remote
    if base is not _MISSING and remote == base:
        return local
    if isinstance(local, dict) and isinstance(remote, dict):
        b = base if isinstance(base, dict) else {}
        out = {}
        for k in set(local) | set(remote) | set(b):
            v = merge3(b.get(k, _MISSING), local.get(k, _MISSING), remote.get(k, _MISSING), prefer_remote)
            if v is not _MISSING:
                out[k] = v
        return out
    if prefer_remote:
        return remote if remote is not _MISSING else local
    return local if local is not _MISSING else remote      # īsts konflikts — uzvar šis dators


# --------------------------------------------------------------------------- viena sinhronizācija

def sync_once() -> dict:
    from . import google
    with _lock:
        slug = _app.current().slug
        fid = google.folder(slug, "sync")
        remote = {f["name"]: f for f in google.list_files(fid)}
        info = {"format": 1, "files": {}}
        if "sync.json" in remote:
            try:
                info = json.loads(google.download(remote["sync.json"]["id"]).decode("utf-8"))
            except ValueError:
                pass
        info.setdefault("files", {})
        # dežūras dators (dati §7a, 2026-11-11) — tikai informācijai, "aizņemts" nav
        if "duty.json" in remote:
            try:
                _st["duty"] = json.loads(google.download(remote["duty.json"]["id"]).decode("utf-8"))
            except (ValueError, TypeError):
                pass
        # cita datora atzīme "aizņemts"
        other = None
        if "lock.json" in remote:
            try:
                lk = json.loads(google.download(remote["lock.json"]["id"]).decode("utf-8"))
                last = datetime.fromisoformat(lk.get("last")).timestamp() if lk.get("last") else 0
                seen = datetime.fromisoformat(lk.get("seen")).timestamp() if lk.get("seen") else last
                theirs = lk.get("computer") and clean_name(lk["computer"]) != computer()
                # 2026-11-06: "busy" — tur pašlaik notiek fona darbs (aģentūru atjaunošana); svaigs, ja redzēts ≤ 5 min
                obusy = bool(lk.get("busy")) and time.time() - seen < 300
                if theirs and (time.time() - last < FRESH_S or obusy):
                    other = {"computer": clean_name(lk["computer"]), "last": lk.get("last"), "busy": obusy}
            except (ValueError, TypeError):
                pass
        st = _state_load()
        got, sent = [], []
        for name in files():
            local = _read(name)
            s = st.get(name) or {}
            base = s["base"] if s.get("base") is not None else _MISSING
            r = info["files"].get(name)
            merged, newbase, rev = local, (None if base is _MISSING else base), int(s.get("rev") or 0)
            if r and int(r.get("rev") or 0) > rev and name in remote:
                try:
                    rd = json.loads(google.download(remote[name]["id"]).decode("utf-8"))
                except ValueError:
                    rd = None
                if rd is not None:
                    if local is None or _md5(local) == s.get("md5"):
                        merged = rd
                    elif (getattr(_app.current(), "sync_merge", None) or {}).get(name):
                        merged = _app.current().sync_merge[name](None if base is _MISSING else base, local, rd)
                    else:
                        merged = _denorm(merge3(_norm(base) if base is not _MISSING else _MISSING, _norm(local), _norm(rd),
                                                prefer_remote=base is _MISSING))
                    if _md5(merged) != _md5(local):
                        _write(name, merged)
                        got.append(name)
                    newbase, rev = rd, int(r["rev"])
            if merged is not None and _md5(merged) != (r or {}).get("md5"):
                if r and int(r.get("rev") or 0) > rev:
                    continue                                   # Drive jaunāks, bet nenolasījās — nākamreiz
                data = json.dumps(merged, ensure_ascii=False).encode("utf-8")
                google.put_bytes(fid, name, data, (remote.get(name) or {}).get("id"))
                rev = max(rev, int((r or {}).get("rev") or 0)) + 1
                info["files"][name] = {"rev": rev, "md5": _md5(merged), "at": _now(), "computer": computer()}
                newbase = merged
                sent.append(name)
            st[name] = {"rev": rev, "md5": _md5(merged), "base": newbase}
        dbx = getattr(_app.current(), "sync_db", None) or {}
        if dbx:
            try:
                _db_step(google, fid, remote, info, dbx, got, sent)
            except Exception as e:
                print("sinhronizācija: datubāzes kopija:", e)
        if sent:
            google.put_bytes(fid, "sync.json", json.dumps(info, ensure_ascii=False).encode("utf-8"),
                             (remote.get("sync.json") or {}).get("id"))
        # "last" = lietotāja pēdējā darbība (ne sinhronizācijas brīdis): atvērta, bet nelietota programma (piem. aizvērts
        # Mac, kas miegā uz brīdi pamostas) citam datoram "aizņemts" vairs neliekas pēc FRESH_S (2026-11-05)
        from . import server as _srv
        act = _srv.state.get("last_active") if _srv.state.get("active_hdr") else None
        lock = {"computer": computer(), "started": datetime.fromtimestamp(_st["boot"], timezone.utc).isoformat(timespec="seconds"),
                "last": datetime.fromtimestamp(act, timezone.utc).isoformat(timespec="seconds") if act else _now(), "seen": _now(),
                "busy": bool(_mod_busy())}
        duty = _is_duty()
        if duty:
            d = {"computer": computer(), "seen": _now()}
            google.put_bytes(fid, "duty.json", json.dumps(d).encode("utf-8"), (remote.get("duty.json") or {}).get("id"))
            _st["duty"] = d
        # dežūras dators "aizņemts" neliek, ja pie tā neviens nestrādā (citādi Mac/mājas dators visu laiku redzētu brīdinājumu)
        if not duty or (act and time.time() - act < FRESH_S):
            google.put_bytes(fid, "lock.json", json.dumps(lock).encode("utf-8"), (remote.get("lock.json") or {}).get("id"))
        _state_save(st)
        if got:
            src = {clean_name(info["files"].get(n, {}).get("computer")) for n in got} - {None}
            _st.update(got=got, got_at=_now(), got_from=", ".join(sorted(src)))
            if [n for n in got if n != "settings.json"]:
                try:
                    from . import backup
                    if backup._hooks.get("after_restore"):
                        backup._hooks["after_restore"]()            # moduļa krātuves — ielasīt no jauna
                except Exception as e:
                    print("sinhronizācija: krātuvju pārlāde:", e)
        _st.update(other=other, sent=sent, last_remote=time.time())
        config.update({"sync_last": _now(), "sync_err": ""})
        if got or sent:
            print(f"sinhronizācija: saņemts {got or '-'}, nosūtīts {sent or '-'}" + (f"; aizņemts datorā {other['computer']}" if other else ""))
        return status()


DB_NAME = "catalog.db.gz"
DB_EVERY = 24 * 3600            # pilnā kopija Drive — ~reizi dienā (to raksta dators, kurš strādā)


def _db_step(google, fid, remote, info, dbx, got, sent) -> None:
    """Pilna datubāzes kopija: jauns (tukšs) dators to ielādē; strādājošais dators to atjauno ~reizi dienā."""
    r = info["files"].get(DB_NAME)
    busy = dbx.get("busy") or (lambda: False)
    if busy():
        return
    tmp = config.app_dir() / ("sync-" + DB_NAME)
    if r and DB_NAME in remote and clean_name(r.get("computer")) != computer() and dbx["is_empty"]():
        tmp.write_bytes(google.download(remote[DB_NAME]["id"]))
        try:
            dbx["restore"](tmp)
        finally:
            tmp.unlink(missing_ok=True)
        got.append(DB_NAME)
        return
    mine_at = dbx["data_at"]() if dbx.get("data_at") else ""
    if dbx.get("data_at"):
        # 2026-11-06 (lietotājs: Win un Mac rāda dažādu informāciju): pilnā sinhronizācija pēc datu svaiguma —
        # dators, kurš aģentūras atjaunojis vēlāk, aizsūta savu datubāzi; otrs to paņem (savas ar roku veiktās izmaiņas saglabā)
        theirs = str((r or {}).get("data_at") or "")
        if r and DB_NAME in remote and clean_name(r.get("computer")) != computer() and theirs > mine_at and dbx.get("replace"):
            tmp.write_bytes(google.download(remote[DB_NAME]["id"]))
            try:
                dbx["replace"](tmp, theirs)
            finally:
                tmp.unlink(missing_ok=True)
            got.append(DB_NAME)
            return
        quiet = mine_at and (time.time() - datetime.fromisoformat(mine_at).timestamp()) > 180   # atjaunošana beigusies
        if dbx["is_empty"]() or not quiet or (mine_at <= theirs):
            return
    else:
        age = time.time() - (datetime.fromisoformat(r["at"]).timestamp() if r and r.get("at") else 0)
        if dbx["is_empty"]() or age < DB_EVERY:
            return
    dbx["snapshot"](tmp)
    try:
        new = google.upload(tmp, fid, DB_NAME, mime="application/gzip")
        old = (remote.get(DB_NAME) or {}).get("id")
        if old and old != new.get("id"):
            try:
                google.delete(old)
            except Exception:
                pass
        info["files"][DB_NAME] = {"rev": int((r or {}).get("rev") or 0) + 1, "at": _now(), "computer": computer(),
                                  "size": tmp.stat().st_size, "data_at": mine_at}
        sent.append(DB_NAME)
    finally:
        tmp.unlink(missing_ok=True)


def db_upload_now() -> dict:
    """Poga: pilnā kopija uz Drive tagad (neatkarīgi no ~24 h)."""
    from . import google
    with _lock:
        fid = google.folder(_app.current().slug, "sync")
        remote = {f["name"]: f for f in google.list_files(fid)}
        info = json.loads(google.download(remote["sync.json"]["id"]).decode("utf-8")) if "sync.json" in remote else {"format": 1, "files": {}}
        info.setdefault("files", {})
        r = info["files"].get(DB_NAME)
        if r:
            r["at"] = "2000-01-01T00:00:00+00:00"            # piespiedu kārtā — vecs
            r["data_at"] = ""
        sent = []
        _db_step(google, fid, remote, info, getattr(_app.current(), "sync_db", None) or {}, [], sent)
        if sent:
            google.put_bytes(fid, "sync.json", json.dumps(info, ensure_ascii=False).encode("utf-8"), (remote.get("sync.json") or {}).get("id"))
        return {"sent": sent}


def _local_changed() -> bool:
    st = _state_load()
    return any(_md5(_read(n)) != (st.get(n) or {}).get("md5") for n in files())


def run_now() -> dict:
    try:
        return sync_once()
    except Exception as e:
        msg = str(e)[:200] or e.__class__.__name__
        config.update({"sync_err": msg})
        print("sinhronizācija: kļūda:", msg)
        raise


def on_close(limit: float = 10) -> None:
    """Sinhronizē, aizverot programmu (ja ieslēgts un ir neaizsūtītas izmaiņas) — ne ilgāk par `limit` sekundēm."""
    if not enabled():
        return
    try:
        if not _local_changed():
            return
    except Exception:
        return
    t = threading.Thread(target=lambda: _safe_run(), daemon=True, name="sync-close")
    t.start()
    t.join(limit)


def _safe_run() -> None:
    try:
        run_now()
    except Exception:
        pass


def _is_duty() -> bool:
    try:
        f = getattr(_app.current(), "duty", None)
        return bool(f()) if f else False
    except Exception:
        return False


def _every() -> tuple:
    e = tuple(getattr(_app.current(), "sync_every", ()) or ())
    return (e[0], e[1]) if len(e) == 2 else (CHECK_S, REMOTE_S)


def _mod_busy() -> bool:
    try:
        b = getattr(_app.current(), "busy", None)
        return bool(b()) if b else False
    except Exception:
        return False


def _loop() -> None:
    """2026-11-06 (lietotājs: "kas notiek palaižot — Google vai aģentūras?"): palaižot VISPIRMS sinhronizācija ar Google
    (jaunāki dati no cita datora, cita datora "aizņemts"); tikai pēc tam `ready` = True un modulis drīkst sākt
    automātisko aģentūru atjaunošanu (saskarne gaida `ready`, maks. ~90 s)."""
    time.sleep(1)
    try:
        if enabled():
            run_now()
    except Exception:
        pass
    finally:
        _st["ready"] = True
    while True:
        chk, rem = _every()
        try:
            if enabled() and (time.time() - _st["last_remote"] > rem or _local_changed()):
                run_now()
        except Exception:
            pass
        time.sleep(chk)


def start() -> None:
    if _st["thread"] and _st["thread"].is_alive():
        return
    _st["thread"] = threading.Thread(target=_loop, daemon=True, name="sync")
    _st["thread"].start()


def status() -> dict:
    return {"ready": bool(_st["ready"] or not config.get("google_sync")), "enabled": bool(config.get("google_sync")), "last": config.get("sync_last") or "", "err": config.get("sync_err") or "",
            "got": _st["got"], "got_at": _st["got_at"], "got_from": _st["got_from"], "other": _st["other"], "duty": _st.get("duty"),
            "computer": computer(), "files": files()}
