"""Līdzīgo bilžu noteikšana komplektiem (lēmums 2026-11-04 17:06: stingri — labāk sadalīt par daudz).

Avots — Vārdotāja sīktēli (manifesta -sikteli.zip, 256 px). Katrai bildei 32×32 pelēktoņu "nospiedums", normalizēts
(vidējais/izkliede), un salīdzinājums ar nobīdi ±5 px (kadrs nedaudz pabīdīts). Mērs = vidējā absolūtā starpība
(0 — vienādi). Līdzīgas, ja mērs < LIMIT (0.35) vai dHash attālums ≤ HASH. Salīdzina tikai bildes no vienas sērijas vai
uzņemtas ≤ 30 min viena no otras (citādi par lēnu un nevajag). Lietotāja izņēmumi "Nav līdzīgas" — notsimilar.json.
Mērījumi (lietotāja drona komplekts, ekrānuzņēmums): līdzīgie 0.27–0.33, tā pati vieta cits leņķis 0.32–0.36, nelīdzīgie ≥ 0.41.
"""
from __future__ import annotations

import io
import zipfile
from datetime import datetime

from . import config

N = 32
SHIFT = 5
LIMIT = 0.35
HASH = 10
NEAR_S = 30 * 60

_cache: dict[str, list | None] = {}
_pairs = None


def _pil():
    try:
        from PIL import Image
        return Image
    except Exception:
        return None


def pairs_store() -> config.JsonStore:
    global _pairs
    if _pairs is None:
        _pairs = config.JsonStore(config.app_dir() / "notsimilar.json", {})   # {"a|b": laiks} — lietotājs: nav līdzīgas
    return _pairs


def key(a: str, b: str) -> str:
    return "|".join(sorted((a, b)))


def not_similar(a: str, b: str) -> bool:
    return key(a, b) in pairs_store().data


def mark_not_similar(stems: list) -> int:
    st = pairs_store()
    n = 0
    with st.lock:
        for i, a in enumerate(stems):
            for b in stems[i + 1:]:
                if a != b:
                    st.data[key(a, b)] = datetime.now().isoformat(timespec="seconds")
                    n += 1
        st.save()
    return n


def _norm(im):
    """Pelēktoņi 32×32, normalizēti: vidējais → 128, izkliede → 40 (lai gaišums/kontrasts netraucē)."""
    from PIL import ImageStat
    st = ImageStat.Stat(im)
    m, sd = st.mean[0], (st.stddev[0] or 1.0)
    return im.point(lambda p: max(0, min(255, int(128 + (p - m) * 40 / sd))))


def _feat(zpath: str, stem: str):
    ck = zpath + "|" + stem
    if ck in _cache:
        return _cache[ck]
    Image = _pil()
    f = None
    if Image and zpath:
        try:
            with zipfile.ZipFile(zpath) as z:
                im = Image.open(io.BytesIO(z.read(stem + ".jpg")))
                im.load()
            f = _norm(im.convert("L").resize((N, N), Image.LANCZOS))
        except Exception:
            f = None
    _cache[ck] = f
    return f


def _score(a, b) -> float:
    """Vidējā starpība (0…~2, kā normalizētās vērtībās) labākajā nobīdē ±SHIFT px."""
    from PIL import ImageChops, ImageStat
    best = 9.0
    for dy in range(-SHIFT, SHIFT + 1):
        for dx in range(-SHIFT, SHIFT + 1):
            w, h = N - abs(dx), N - abs(dy)
            ca = a.crop((max(0, dx), max(0, dy), max(0, dx) + w, max(0, dy) + h))
            cb = b.crop((max(0, -dx), max(0, -dy), max(0, -dx) + w, max(0, -dy) + h))
            v = ImageStat.Stat(ImageChops.difference(ca, cb)).mean[0] / 40.0
            if v < best:
                best = v
    return best


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _ts(s: str):
    try:
        return datetime.fromisoformat(str(s).replace("Z", "+00:00").replace(" ", "T")[:19]).timestamp()
    except Exception:
        return None


def _near(a: dict, b: dict) -> bool:
    if a.get("series") and a.get("series") == b.get("series"):
        return True
    ta, tb = _ts(a.get("taken") or ""), _ts(b.get("taken") or "")
    return ta is not None and tb is not None and abs(ta - tb) <= NEAR_S


def similar(a: dict, b: dict, zips: dict) -> bool:
    """a, b — krājuma ieraksti (stock.scan): stem, series, taken, phash."""
    if not_similar(a["stem"], b["stem"]):
        return False
    if a.get("phash") and b.get("phash") and _ham(a["phash"], b["phash"]) <= HASH:
        return True
    if not _near(a, b):
        return False
    fa, fb = _feat(zips.get(a.get("series"), ""), a["stem"]), _feat(zips.get(b.get("series"), ""), b["stem"])
    if not fa or not fb:
        return False
    return _score(fa, fb) < LIMIT
