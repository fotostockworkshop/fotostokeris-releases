"""AI asistents Tirgotājā (lietotājs 2026-11-03: "sagatavo iesniegšanai Bali RF bilžu kolekciju").

AI saņem tikai kopsavilkumu (sērijas, kategorijas, atslēgvārdu paraugs, kas kur iesniegts) — ne bildes — un atbild ar
darbību JSON. Bildes atlasa pats Tirgotājs (stock.suggest — tie paši noteikumi), lietotājs pārskata un saglabā.
AI pats neko neatzīmē un neiesniedz. Pieslēgumi — kopīgie (core/ai.py, darbs "assistant"; noteikumi §5 p.2).
Bez AI (vai ja neizdodas) — vienkārša vārdu nolasīšana no teikuma (local_parse).
"""
from __future__ import annotations

import base64
import io
import json
import os
import re
import subprocess
import tempfile
import urllib.error
import urllib.request
from collections import Counter

from core import ai as cai

from . import config, stock

SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": ["make_set", "show", "answer"]},
        "match": {"type": "string", "description": "search words (place/topic) to find photos; empty = all"},
        "topics": {"type": "array", "items": {"type": "string"},
                   "description": "for make_set: several places/topics to mix in one set (e.g. ['Ubud', 'temple', 'rice terraces']); empty = use match"},
        "cat": {"type": "string", "enum": ["RF", "ED", "EDI", ""]},
        "size": {"type": "integer", "description": "number of photos for a set; 0 = automatic"},
        "agency": {"type": "string", "description": "agency id or empty"},
        "show": {"type": "string", "enum": ["todo", "rejected", "bad", ""]},
        "reply": {"type": "string", "description": "short answer to the user in the user's language"},
    },
    "required": ["action", "match", "topics", "cat", "size", "agency", "show", "reply"],
    "additionalProperties": False,
}

STOP = set("""sagatavo sagatavot iesniegšanai iesniegt bilžu bildes bildi kolekciju kolekcija komplektu komplekts komplektā
parādi parādīt rādīt kas kur vēl nav cik un ar no par uz man lūdzu please prepare make set collection photos photo images
show submit submission for the of to with and from rf ed edi iesniegts iesniegtas iesniegtās pieņemts pieņemtas noraidīts
noraidītas neder bilde komplektam aģentūrā aģentūrai agency""".split())


def summary() -> dict:
    r = stock.listing()
    ags = [a["id"] for a in r["agencies"]]
    ser = {s["key"]: {"name": s["name"], "code": s["code"], "n": 0, "cat": Counter(), "kw": Counter(), "pl": Counter(),
                      "todo": Counter(), "sub": Counter(), "acc": Counter(), "rej": Counter()} for s in r["series"]}
    for it in r["items"]:
        x = ser.get(it["series"])
        if not x:
            continue
        x["n"] += 1
        x["cat"][it["cat"]] += 1
        if it.get("hint"):
            x["pl"][it["hint"]] += 1
        for w in (it.get("kwtext") or "").split("|")[:25]:
            if w:
                x["kw"][w] += 1
        for a in ags:
            c = it["cells"].get(a) or {}
            stt = c.get("state") or ("bad" if c.get("bad") else "")
            key = {"": "todo", "submitted": "sub", "accepted": "acc", "rejected": "rej"}.get(stt)
            if key:
                x[key][a] += 1
    out = []
    for x in list(ser.values())[:300]:
        out.append({"series": x["name"], "code": x["code"], "photos": x["n"], "categories": dict(x["cat"]),
                    "keywords": [w for w, _ in x["kw"].most_common(12)], "places": dict(x["pl"].most_common(15)),
                    "not_submitted": dict(x["todo"]), "submitted": dict(x["sub"]), "accepted": dict(x["acc"]),
                    "rejected": dict(x["rej"])})
    return {"agencies": {a["id"]: a["name"] for a in r["agencies"]}, "series": out, "sets": r.get("sets") or []}


def local_parse(text: str) -> dict:
    low = text.lower()
    words = re.findall(r"[\wāčēģīķļņšūž]+", low)
    cat = "EDI" if "edi" in words or "illustrative" in words else ("ED" if "ed" in words or "editorial" in words else ("RF" if "rf" in words else ""))
    nums = [int(w) for w in words if w.isdigit()]
    ag = next((a for a in stock.AG_IDS if a in words or a in low), "")
    match = " ".join(w for w in words if w not in STOP and not w.isdigit() and len(w) > 2 and w != ag)
    make = bool(re.search(r"sagatav|komplekt|kolekcij|prepare|\bset\b|collection", low))
    show = "rejected" if re.search(r"noraid|reject", low) else ("todo" if re.search(r"nav iesniegt|neiesniegt|not submitted", low) else "")
    return {"action": "make_set" if make else "show", "match": match, "cat": cat, "size": nums[0] if nums else 0,
            "agency": ag, "show": show, "reply": "", "by": "local"}


def _prompt(text: str) -> str:
    return ("You are the assistant inside 'Tirgotājs', a desktop tool that helps a stock photographer submit finished "
            "photos to stock agencies. The user writes a request (usually in Latvian). Decide ONE action:\n"
            "- make_set: prepare a submission set (komplekts/kolekcija) — fill match (place/topic words that occur in series "
            "names, places or keywords, e.g. 'Bali'); if the user names several places/topics (e.g. 'Ubud, temples, rice "
            "terraces'), put each into topics (short words as they would appear in places/keywords, English or as in data), cat (RF, ED = editorial, EDI = illustrative editorial: brands without people; or empty), size (0 = automatic) and agency if named;\n"
            "- show: show photos in the table — fill match/agency/show (todo = not submitted yet, rejected, bad = unsuitable);\n"
            "- answer: answer a question (counts etc.) from the data below in 'reply'.\n"
            "Always write a short 'reply' in the user's language explaining what you did. Use agency ids from the data. "
            "Never claim photos were submitted — the user submits and marks them.\n\n"
            "DATA (JSON):\n" + json.dumps(summary(), ensure_ascii=False) + "\n\nUSER REQUEST:\n" + text +
            "\n\nAnswer with JSON only, matching this schema:\n" + json.dumps(SCHEMA))


def _json(text: str) -> dict:
    text = (text or "").strip()
    try:
        d = json.loads(text)
        if isinstance(d, dict):
            return d
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        return json.loads(m.group(0))
    raise RuntimeError("AI: " + text[:200])


def _claude(prompt: str, schema: dict = SCHEMA, image: bytes | None = None) -> dict:
    cmd = cai.find_claude()
    if not cmd:
        raise RuntimeError("Claude Code nav uzstādīts")
    args = cmd + ["-p", "--output-format", "json", "--model", (config.get("model") or "sonnet").strip()]
    with tempfile.TemporaryDirectory() as wd:
        if image:                                   # kontaktlapa — Claude Code to nolasa ar Read
            open(os.path.join(wd, "sheet.jpg"), "wb").write(image)
            args += ["--allowedTools", "Read"]
            prompt = "First read the image file sheet.jpg in the current directory (contact sheet, numbers = photo ids).\n\n" + prompt
        r = subprocess.run(args, input=prompt.encode("utf-8"), capture_output=True, cwd=wd, timeout=240,
                           env=cai._env(cai.CLAUDE_ENV), creationflags=cai.NO_WINDOW)
    out = r.stdout.decode("utf-8", "replace").strip()
    data = None
    for chunk in [out] + out.splitlines()[::-1]:
        if chunk.strip().startswith("{"):
            try:
                data = json.loads(chunk.strip())
                break
            except json.JSONDecodeError:
                continue
    if not data or data.get("is_error"):
        raise RuntimeError(str((data or {}).get("result") or out or r.stderr.decode("utf-8", "replace"))[:300])
    u = data.get("usage") or {}
    cai.record("claude_sub", "", int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0))
    so = data.get("structured_output")
    return so if isinstance(so, dict) else _json(str(data.get("result", "")))


def _codex(prompt: str, schema: dict = SCHEMA, image: bytes | None = None) -> dict:
    cmd = cai.find_codex()
    if not cmd:
        raise RuntimeError("Codex nav uzstādīts")
    with tempfile.TemporaryDirectory() as wd:
        sf, of = os.path.join(wd, "schema.json"), os.path.join(wd, "answer.json")
        json.dump(schema, open(sf, "w", encoding="utf-8"))
        args = cmd + ["exec", "--skip-git-repo-check", "--sandbox", "read-only", "--cd", wd,
                      "--output-schema", sf, "--output-last-message", of]
        if image:
            open(os.path.join(wd, "sheet.jpg"), "wb").write(image)
            args += ["--image", os.path.join(wd, "sheet.jpg")]
        m = (config.get("codex_model") or "").strip()
        if m:
            args += ["--model", m]
        r = subprocess.run(args + ["-"], input=("Do not run commands. " + prompt).encode("utf-8"), capture_output=True,
                           cwd=wd, timeout=240, env=cai._env(cai.CODEX_ENV), creationflags=cai.NO_WINDOW)
        text = open(of, encoding="utf-8", errors="replace").read() if os.path.isfile(of) else ""
    if not text:
        raise RuntimeError(((r.stdout + r.stderr).decode("utf-8", "replace") or f"exit {r.returncode}")[-300:])
    cai.record("chatgpt_sub", m)
    return _json(text)


def _post(url: str, body: dict, headers: dict) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"content-type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"API {e.code}: {e.read().decode('utf-8', 'replace')[:200]}")


def _claude_api(prompt: str, schema: dict = SCHEMA, image: bytes | None = None) -> dict:
    k = cai.key("claude_api")
    if not k:
        raise RuntimeError("nav Claude API atslēgas")
    m = (config.get("model") or "sonnet").strip()
    model = {"sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5", "haiku": "claude-haiku-5-5"}.get(m, m)
    content = ([{"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                             "data": base64.b64encode(image).decode()}}] if image else []) + [{"type": "text", "text": prompt}]
    d = _post("https://api.anthropic.com/v1/messages", {"model": model, "max_tokens": 4000,
              "messages": [{"role": "user", "content": content}]}, {"x-api-key": k, "anthropic-version": "2023-06-01"})
    u = d.get("usage") or {}
    cai.record("claude_api", model, int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0))
    return _json("".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text"))


def _openai_api(prompt: str, schema: dict = SCHEMA, image: bytes | None = None) -> dict:
    k = cai.key("openai_api")
    if not k:
        raise RuntimeError("nav OpenAI API atslēgas")
    model = (config.get("openai_model") or "gpt-5-mini").strip()
    content = [{"type": "text", "text": prompt}] + ([{"type": "image_url", "image_url": {
        "url": "data:image/jpeg;base64," + base64.b64encode(image).decode()}}] if image else [])
    d = _post("https://api.openai.com/v1/chat/completions", {"model": model, "messages": [{"role": "user", "content": content}],
              "response_format": {"type": "json_object"}}, {"Authorization": "Bearer " + k})
    u = d.get("usage") or {}
    cai.record("openai_api", model, int(u.get("prompt_tokens") or 0), int(u.get("completion_tokens") or 0))
    return _json(((d.get("choices") or [{}])[0].get("message") or {}).get("content") or "")


RUN = {"claude_sub": _claude, "chatgpt_sub": _codex, "claude_api": _claude_api, "openai_api": _openai_api}


def providers() -> list[str]:
    lst = [p for p in cai.order("assistant") if p in RUN]
    if not lst:                                   # noklusējums: kas šajā datorā ir pieejams
        if cai.find_claude():
            lst.append("claude_sub")
        if cai.find_codex():
            lst.append("chatgpt_sub")
        lst += [p for p in ("claude_api", "openai_api") if cai.key(p)]
    return lst


PICK = {
    "type": "object",
    "properties": {
        "items": {"type": "array", "items": {"type": "object", "properties": {
            "id": {"type": "string"}, "why": {"type": "string", "description": "short reason in the user's language"}},
            "required": ["id", "why"], "additionalProperties": False}},
        "reply": {"type": "string", "description": "2-3 sentences to the user in the user's language: how the set is built"},
    },
    "required": ["items", "reply"],
    "additionalProperties": False,
}
SHEET_N, SHEET_PX = 60, 150


def _sheet(cands: list) -> bytes | None:
    """Kontaktlapa AI: līdz 60 sīktēliem ar numuriem (id) vienā bildē — lētāk nekā katrs atsevišķi."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    its = [c for c in cands if c.get("thumb")][:SHEET_N]
    if not its:
        return None
    cols = 10
    rows = -(-len(its) // cols)
    W, H = SHEET_PX, int(SHEET_PX * 0.75)
    sheet = Image.new("RGB", (cols * W, rows * H), (30, 30, 30))
    dr = ImageDraw.Draw(sheet)
    try:
        from PIL import ImageFont
        font = ImageFont.load_default(size=16)
    except Exception:
        font = None
    for i, it in enumerate(its):
        b = stock.thumb(it["series"], it["stem"])
        x, y = (i % cols) * W, (i // cols) * H
        if b:
            try:
                im = Image.open(io.BytesIO(b)).convert("RGB")
                im.thumbnail((W - 4, H - 4))
                sheet.paste(im, (x + 2, y + 2))
            except Exception:
                pass
        dr.rectangle([x + 2, y + 2, x + 38, y + 22], fill=(0, 0, 0))
        dr.text((x + 5, y + 3), it["_id"], fill=(255, 255, 0), font=font)
    buf = io.BytesIO()
    sheet.save(buf, "JPEG", quality=80)
    return buf.getvalue()


def _pick_prompt(text: str, cands: list, size: int, cat: str, with_sheet: bool) -> str:
    rows = [{"id": c["_id"], "title": c.get("title") or "", "kw": (c.get("kwtext") or "").split("|")[:12],
             "place": c.get("hint") or "", "date": (c.get("taken") or "")[:16], "series": stock.pretty(c.get("src_name") or "")}
            for c in cands]
    return ("You are the photo editor inside 'Tirgotājs' (a stock photographer's submission tool). Build ONE submission set "
            f"of about {size} photos (category {cat}) from the CANDIDATES for the user's request. Think like a stock editor: "
            "the set must sell — choose variety (different places, subjects, angles, times of day, close-ups and wide views), "
            "skip near-duplicates and weak/repetitive frames, prefer clear commercial subjects, cover all topics the user "
            "asked for in balanced amounts. Never pick more than 2-3 photos of the same scene. If there are not enough good "
            "different photos, pick fewer rather than duplicates and say so in reply."
            + (" A contact sheet image is attached: each tile shows the photo id in the corner — use it to judge the "
               "pictures (quality, sameness, variety)." if with_sheet else "") +
            "\nFor each picked photo give a very short 'why' (a few words, user's language). Write 'reply' in the user's "
            "language (Latvian if the request is Latvian).\n\nUSER REQUEST:\n" + text +
            "\n\nCANDIDATES (JSON):\n" + json.dumps(rows, ensure_ascii=False) +
            "\n\nAnswer with JSON only, matching this schema:\n" + json.dumps(PICK))


def _ai_pick(p: str, text: str, d: dict, exclude: list) -> dict | None:
    """AI redaktors (lēmums 2026-11-05 16:27): Tirgotājs sagatavo kandidātus (dažāda secība, bez līdzīgajiem, ≤ 120),
    AI izvēlas ar "kāpēc"; Tirgotājs vēlreiz pārbauda (līdzīgās, kategorija) — stock.suggest(only=…)."""
    cat = d["cat"] or "RF"
    r = stock.listing()
    cands = stock.pool(cat, d.get("match") or "", d.get("topics") or [], 120, exclude, r)
    if not cands:
        return None
    for i, c in enumerate(cands):
        c["_id"] = str(i + 1)
    auto = stock.suggest(cat, 0, exclude, d.get("match") or "", topics=d.get("topics") or [], r=r)
    size = int(d.get("size") or 0) or auto["size"]
    img = _sheet(cands) if config.get("sub_ai_thumbs") else None
    ans = RUN[p](_pick_prompt(text, cands, size, cat, bool(img)), PICK, img)
    by = {c["_id"]: c for c in cands}
    why, order = {}, []
    for x in ans.get("items") or []:
        c = by.get(str(x.get("id") or "").strip())
        if c and c["stem"] not in why:
            why[c["stem"]] = str(x.get("why") or "")[:120]
            order.append(c["stem"])
    if not order:
        return None
    res = stock.suggest(cat, len(order), exclude, only=order, r=r)       # tie paši noteikumi (līdzīgās vienā komplektā nekad)
    pos = {s: i for i, s in enumerate(order)}
    res["items"].sort(key=lambda it: pos.get(it["stem"], 999))
    for it in res["items"]:
        it["why"] = why.get(it["stem"], "")
    res["auto"], res["todo"] = auto["auto"], auto["todo"]
    res["ai_reply"] = str(ans.get("reply") or "")
    res["ai"] = True
    res["sheet"] = bool(img)
    return res


def replace(text: str, cat: str, match: str, topics: list, have: list, exclude: list) -> dict:
    """↻ pie bildes AI ieteikumā: AI izvēlas VIENU aizstājēju, zinot, kas komplektā jau ir (lai neatkārtotos).
    Ja AI nav vai neizdodas — stock.suggest (tie paši noteikumi)."""
    cat = cat if cat in ("RF", "ED", "EDI") else "RF"
    r = stock.listing()
    by = {it["stem"]: it for it in r["items"]}
    cands = stock.pool(cat, match, topics, 60, list(have) + list(exclude), r)
    from . import similar
    cands = [c for c in cands if not any(similar.similar(c, by[h], stock._zips) for h in have if h in by)]
    for i, c in enumerate(cands):
        c["_id"] = str(i + 1)
    cur = [{"title": by[h].get("title") or "", "place": by[h].get("hint") or ""} for h in have if h in by]
    if cands and config.get("sub_ai_pick") is not False:
        for p in providers():
            try:
                prompt = ("You are the photo editor inside 'Tirgotājs'. The user removed one photo from a stock submission "
                          "set and wants ONE replacement. Pick exactly one candidate that adds variety to the set (a place, "
                          "subject or view the set lacks) and sells well; give a short 'why' in the user's language "
                          "(Latvian if the request is Latvian).\nUSER REQUEST WAS:\n" + (text or "") +
                          "\n\nPHOTOS ALREADY IN THE SET:\n" + json.dumps(cur, ensure_ascii=False) +
                          "\n\nCANDIDATES (JSON):\n" + json.dumps([{"id": c["_id"], "title": c.get("title") or "",
                              "kw": (c.get("kwtext") or "").split("|")[:12], "place": c.get("hint") or "",
                              "date": (c.get("taken") or "")[:16]} for c in cands], ensure_ascii=False) +
                          "\n\nAnswer with JSON only, matching this schema:\n" + json.dumps(PICK))
                ans = RUN[p](prompt, PICK, None)
                ids = {c["_id"]: c for c in cands}
                for x in ans.get("items") or []:
                    c = ids.get(str(x.get("id") or "").strip())
                    if c:
                        it = {k: v for k, v in c.items() if k not in ("kwtext", "_id")}
                        it["why"] = str(x.get("why") or "")[:120]
                        return {"ok": True, "items": [it], "by": p}
            except Exception as e:
                print("AI aizstāšana:", str(e)[:300])
    res = stock.suggest(cat, 1, exclude, match, have, topics=topics, r=r)
    return {"ok": True, "items": res["items"], "by": "local"}


def ask(text: str, exclude: list | None = None) -> dict:
    text = (text or "").strip()[:1000]
    if not text:
        raise ValueError("empty")
    errs = []
    prompt = None
    used = ""
    for p in providers():
        try:
            prompt = prompt or _prompt(text)
            d = RUN[p](prompt)
            d["by"] = used = p
            break
        except Exception as e:                    # nākamais pieslēgums; beigās — bez AI
            errs.append(f"{p}: {e}")
    else:
        d = local_parse(text)
        d["errors"] = errs
    d.setdefault("match", "")
    d["topics"] = [str(x)[:40] for x in (d.get("topics") or []) if str(x).strip()][:8]
    d["cat"] = d.get("cat") if d.get("cat") in ("RF", "ED", "EDI") else ""
    if d.get("agency") not in stock.AG_IDS:
        d["agency"] = ""
    if d.get("action") == "make_set":
        res = None
        if used and config.get("sub_ai_pick") is not False:
            try:
                res = _ai_pick(used, text, d, exclude or [])
            except Exception as e:
                errs.append(f"{used} (atlase): {e}")
                print("AI redaktors:", str(e)[:300])
        if res is None:
            res = stock.suggest(d["cat"] or "RF", int(d.get("size") or 0), exclude or [], match=d["match"], topics=d["topics"])
        d["set"] = res
        if errs:
            d["errors"] = errs
    return {"ok": True, **d}
