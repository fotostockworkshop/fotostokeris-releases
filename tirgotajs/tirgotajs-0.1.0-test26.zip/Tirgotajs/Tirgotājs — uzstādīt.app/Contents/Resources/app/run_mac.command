#!/bin/bash
# Tirgotājs — palaišana uz Mac. Pirmajā reizē: labais klikšķis -> Open.
cd "$(dirname "$0")" || exit 1

if ! command -v python3 >/dev/null 2>&1; then
  echo "Python 3 nav atrasts. Uzstādi to no https://www.python.org/downloads/"
  read -r -p "Spied Enter, lai aizvērtu..."
  exit 1
fi

if [ ! -x .venv/bin/python ]; then
  echo "Pirmā palaišana: sagatavoju vidi, tas aizņems minūti..."
  python3 -m venv .venv || { read -r -p "Kļūda. Spied Enter..."; exit 1; }
fi

if ! cmp -s requirements.txt .venv/req.txt; then
  echo "Uzstādu nepieciešamās bibliotēkas (pywebview, keyring)..."
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  if .venv/bin/python -m pip install -r requirements.txt; then
    cp requirements.txt .venv/req.txt
  else
    echo "Neizdevās uzstādīt pywebview — programma tik un tā tiks palaista pārlūka logā."
    sleep 5
  fi
fi

LOGDIR="$HOME/Library/Application Support/Tirgotajs"
mkdir -p "$LOGDIR"
# programma pati raksta log.txt (ar iepriekšējiem log-1…log-3.txt); šeit tikai palaišanas kļūdas
TIRGOTAJS_LOG=1 nohup .venv/bin/python -u Tirgotajs.py > "$LOGDIR/log-start.txt" 2>&1 &
echo "Tirgotājs palaists. Šo termināļa logu var aizvērt."
