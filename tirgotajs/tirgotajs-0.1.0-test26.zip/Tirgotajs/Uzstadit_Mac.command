#!/bin/bash
# Tirgotājs — uzstādīšana uz Mac kā parasta lietotne (vienreiz).
# Pirmajā reizē macOS šo failu bloķē: System Settings → Privacy & Security → "Open Anyway"
# (vai labais klikšķis → Open). Pēc tam programmu palaiž no Launchpad / Programmas — bez apstiprināšanas.
cd "$(dirname "$0")" || exit 1
bash core/mac/install_app.sh Tirgotajs "Tirgotājs" com.fotostockworkshop.tirgotajs mac/Tirgotajs.icns
echo
read -r -p "Spied Enter, lai aizvērtu šo logu..."
