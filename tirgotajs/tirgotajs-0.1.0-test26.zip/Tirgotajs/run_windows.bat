@echo off
chcp 65001 >nul
title Tirgotajs
cd /d "%~dp0"

set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (
  where python >nul 2>nul && set "PY=python"
)
if not defined PY (
  echo Python nav atrasts. Uzstadi to no https://www.python.org/downloads/ ^(atzime "Add python.exe to PATH"^).
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Pirma palaisana: sagatavoju vidi, tas aiznems minuti...
  %PY% -m venv .venv
  if errorlevel 1 ( pause & exit /b 1 )
)

fc /b requirements.txt .venv\req.txt >nul 2>nul
if errorlevel 1 (
  echo Uzstadu nepieciesamas bibliotekas ^(pywebview, keyring^)...
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
  ".venv\Scripts\python.exe" -m pip install -r requirements.txt
  if errorlevel 1 (
    echo.
    echo Neizdevas uzstadit pywebview. Programma tik un ta tiks palaista parluka loga.
    timeout /t 8 >nul
  ) else (
    copy /y requirements.txt .venv\req.txt >nul
  )
)

start "" ".venv\Scripts\pythonw.exe" Tirgotajs.py
rem atjauninasana palaiz so failu ar "start" (cmd /k) - bez exit konsoles logs paliktu atverts
exit
