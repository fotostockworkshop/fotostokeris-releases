#!/usr/bin/env python3
"""Tirgotājs — palaišana.

Atver lietotni atsevišķā logā (ja uzstādīts pywebview), citādi Edge/Chrome "lietotnes" logā
vai parastā pārlūkā.  Parametri:
  --browser    atvērt parastā pārlūkā
  --no-window  tikai serveris (adrese tiek izdrukāta)
"""
from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
if not (ROOT / "core").is_dir():                 # izstrādē core/ ir repozitorija saknē
    sys.path.insert(0, str(ROOT.parent))

from tirgotajs import config  # noqa: E402,F401  — reģistrē Tirgotāju core/
from core import launcher  # noqa: E402


def main():
    logged = launcher.log_to_file()
    from tirgotajs import server
    launcher.run(sys.argv[1:], logged, server.start)


if __name__ == "__main__":
    main()
