"""Automātika dežūras datorā (dati §7a ceļš 4. un "dežūras dators + pults", lēmumi 2026-11-10 13:51–13:58, 2026-11-11 10:52–11:09).

Ik pēc TICK sekundēm (tikai dežūras datorā — iestatījums `sub_duty`; bez Google sinhronizācijas — vienmēr):
1. "Atcelt komplektu" → atpakaļ uz NAS, ja pults to palūdza (`sets.json` `want_back`).
2. Apstiprinātos komplektus pārvieto NAS → OneDrive: iepriekšējā vakarā `sub_move_at` (19:00) vai uzreiz pēc
   apstiprināšanas (`sub_move_mode`), vai tūlīt, ja palūgts ("Uz OneDrive tagad") vai diena jau pienākusi.
3. Ja ieslēgts `sub_auto_ftp`: apstiprinātos un OneDrive esošos komplektus sūta ar FTP naktī pirms plāna dienas
   (`sub_ftp_from`–`sub_ftp_to`, 20:00–9:00) nejaušā laikā; komplektiem vienā naktī ≥ 1 h atstarpe; aģentūras nejaušā
   secībā ar 1–20 min pauzēm (ftp.upload_auto). Dators bija izslēgts → jauns nejaušs laiks atlikušajā logā; logs beidzies →
   "nokavēts" (nesūta; lietotājs var "Iesniegt tagad").
Pirms katras darbības — jaunākais plāns no Google (core/sync.run_now).
"""
from __future__ import annotations

import random
import threading
import time as _time
from datetime import date, datetime, time, timedelta

from . import config, plan, stock

TICK = 30
SPACING = 3600                    # komplektiem vienā naktī ≥ 1 h atstarpe
_st: dict = {"thread": None, "last_sync": 0.0, "kick": threading.Event(), "last_tick": "", "err": ""}


def duty() -> bool:
    """Dežūras dators: ieslēgts iestatījumos vai Google sinhronizācija izslēgta (viens dators)."""
    return bool(config.get("sub_duty")) or not bool(config.get("google_sync"))


def _hm(v, dflt: tuple) -> time:
    try:
        h, m = str(v or "").strip().split(":")[:2]
        return time(max(0, min(23, int(h))), max(0, min(59, int(m))))
    except (ValueError, TypeError):
        return time(*dflt)


def window(d: str) -> tuple[datetime, datetime]:
    """FTP logs plāna dienai: no `sub_ftp_from` (iepriekšējā vakarā, ja sākums vēlāks par beigām) līdz `sub_ftp_to`."""
    D = date.fromisoformat(d)
    a, b = _hm(config.get("sub_ftp_from"), (20, 0)), _hm(config.get("sub_ftp_to"), (9, 0))
    start = datetime.combine(D - timedelta(days=1) if a >= b else D, a)
    return start, datetime.combine(D, b)


def move_time(d: str) -> datetime | None:
    """Kad apstiprināto komplektu pārvieto uz OneDrive (None = uzreiz pēc apstiprināšanas)."""
    if config.get("sub_move_mode") == "approve":
        return None
    try:
        D = date.fromisoformat(d)
    except ValueError:
        return None
    t = datetime.combine(D - timedelta(days=1), _hm(config.get("sub_move_at"), (19, 0)))
    return min(t, window(d)[0] - timedelta(minutes=15))


def info() -> dict:
    from core import sync
    s = sync.status()
    return {"duty": duty(), "duty_set": bool(config.get("sub_duty")), "duty_pc": (s.get("duty") or {}).get("computer") or "",
            "duty_seen": (s.get("duty") or {}).get("seen") or "", "auto_ftp": bool(config.get("sub_auto_ftp")),
            "ftp_from": config.get("sub_ftp_from") or "20:00", "ftp_to": config.get("sub_ftp_to") or "09:00",
            "move_mode": config.get("sub_move_mode") or "evening", "move_at": config.get("sub_move_at") or "19:00",
            "sync": bool(config.get("google_sync")), "last_tick": _st["last_tick"], "err": _st["err"]}


def kick() -> None:
    _st["kick"].set()


def _sync(force: bool = False) -> None:
    if not config.get("google_sync"):
        return
    if not force and _time.time() - _st["last_sync"] < 45:
        return
    try:
        from core import sync
        sync.run_now()
    except Exception as e:
        print("automātika: Google sinhronizācija neizdevās —", str(e)[:200])
    _st["last_sync"] = _time.time()


def _busy() -> bool:
    from . import ftp, move
    return bool(ftp.status().get("running") or move.status().get("running"))


# --------------------------------------------------------------------------- 1.–2. pārvietošana


def _back_todo() -> list[str]:
    return [sid for sid, x in stock.sets_store().data.items() if x.get("want_back") and x.get("rel")]


def _move_todo(now: datetime) -> list[str]:
    sets = stock.sets_store().data
    out = []
    for sid, e in sorted(plan.items().items(), key=lambda z: z[1].get("date") or ""):
        x = sets.get(sid)
        if not x or x.get("rel") or e.get("status") != "approved" or not e.get("date") or e.get("move_err"):
            continue
        mt = move_time(e["date"])
        if e.get("want_move") or mt is None or now >= mt or e["date"] <= now.date().isoformat():
            out.append(sid)
    return out


NAS_WAIT_H = 6


def _do_moves(ids: list[str]) -> None:
    from . import move
    by = {it["stem"]: it for it in stock.listing()["items"]}
    ok = []
    for sid in ids:
        x = stock.sets_store().data.get(sid) or {}
        rem = [s for s in x.get("stems") or [] if s in by and by[s].get("remote")]
        if rem:
            # bildes vēl nav NAS (Synology no Mac vēl augšupielādē) — gaida un mēģina katrā cilpā; kļūda tikai pēc 6 h
            # (lietotājs 2026-11-15: sūtījums no Mac un tajā pašā dienā plānā)
            e = plan.items().get(sid) or {}
            w = e.get("nas_wait") or {}
            since = w.get("since") or datetime.now().isoformat(timespec="seconds")
            n, tot = len(x.get("stems") or []) - len(rem), len(x.get("stems") or [])
            try:
                old = (datetime.now() - datetime.fromisoformat(since)).total_seconds() > NAS_WAIT_H * 3600
            except ValueError:
                old = False
            if old:
                plan.upd(sid, move_err="remote", want_move=None, nas_wait=None)
                print(f"automātika: '{x.get('name')}' — {len(rem)} bildes {NAS_WAIT_H} h nav nonākušas NAS, nepārvietoju")
            elif w.get("n") != n or not w.get("since"):
                plan.upd(sid, nas_wait={"since": since, "n": n, "total": tot})
                print(f"automātika: '{x.get('name')}' — gaida NAS: {n}/{tot} bildes")
            continue
        if (plan.items().get(sid) or {}).get("nas_wait"):
            plan.upd(sid, nas_wait=None)
        ok.append(sid)
    if not ok:
        return
    r = move.move_many(ok)
    _st["moving"] = ok if r.get("ok") else []
    if r.get("ok"):
        threading.Thread(target=_move_progress, args=(ok,), daemon=True, name="move-progress").start()
        print(f"automātika: uz OneDrive — {r.get('sets')} komplekti, {r.get('total')} bildes")
        for sid in ok:
            plan.upd(sid, want_move=None)
    elif r.get("error") not in ("busy",):
        for sid in ok:
            plan.upd(sid, move_err=r.get("error") or "move", want_move=None)
        print("automātika: pārvietošana neizdevās —", r.get("error"))


# --------------------------------------------------------------------------- 3. FTP


def _pick_time(sid: str, start: datetime, end: datetime, now: datetime) -> datetime | None:
    lo = max(start, now + timedelta(minutes=2))
    hi = end - timedelta(minutes=120)                    # 2026-11-12: 08:11 sākums ar 7 aģentūrām un 1–20 min pauzēm
    if hi <= lo:                                         # nepaspēja līdz 9:00 — sākam ne vēlāk kā 2 h pirms beigām
        hi = end - timedelta(minutes=20)
    if hi <= lo:
        return None
    others = []
    for k, e in plan.items().items():
        if k != sid and e.get("ftp_at") and not e.get("ftp_done"):
            try:
                others.append(datetime.fromisoformat(e["ftp_at"]))
            except ValueError:
                pass
    best, best_gap = None, -1.0
    for _ in range(40):
        t = lo + timedelta(seconds=random.randint(0, int((hi - lo).total_seconds())))
        gap = min((abs((t - o).total_seconds()) for o in others), default=10 ** 9)
        if gap >= SPACING:
            return t.replace(microsecond=0)
        if gap > best_gap:
            best, best_gap = t, gap
    return best.replace(microsecond=0) if best else None


def _ftp_due(now: datetime) -> str | None:
    """Atzīmē laikus / nokavētos; atgriež komplektu, ko sūtīt tagad (vienu vienlaikus)."""
    sets = stock.sets_store().data
    due = None
    for sid, e in sorted(plan.items().items(), key=lambda z: z[1].get("date") or ""):
        x = sets.get(sid)
        mw = e.get("month_wait") or {}
        if x and x.get("rel") and mw.get("month") and mw["month"] < now.strftime("%Y-%m"):
            # mēneša limita dēļ atlikts — jauns mēnesis: sūta atlikušajām aģentūrām (pārējām nav ko sūtīt)
            plan.upd(sid, ftp_done=None, month_wait=None, want_ftp=now.isoformat(timespec="seconds"))
            print(f"automātika: '{x.get('name')}' — jauns mēnesis, sūtu atliktās: {', '.join(mw.get('ags') or [])}")
            due = due or sid
            continue
        if not x or not x.get("rel") or e.get("status") != "approved" or e.get("ftp_done") or not e.get("date"):
            continue
        if e.get("want_ftp"):
            due = due or sid
            continue
        if e.get("ftp_skip") or not config.get("sub_auto_ftp"):
            continue
        start, end = window(e["date"])
        if now < start:
            continue
        if now > end:
            if not e.get("ftp_late"):
                plan.upd(sid, ftp_late=True)
                print(f"automātika: '{x.get('name')}' — FTP logs beidzies, nav nosūtīts (nokavēts)")
            continue
        at = None
        try:
            at = datetime.fromisoformat(e["ftp_at"]) if e.get("ftp_at") else None
        except ValueError:
            at = None
        if at is None or (at < now - timedelta(minutes=10)):     # nav laika / dators bija izslēgts — jauns laiks
            nt = _pick_time(sid, start, end, now)
            if nt is None:
                due = due or sid                                 # logā palikušas tikai dažas minūtes — sūta tagad
                continue
            plan.upd(sid, ftp_at=nt.isoformat(timespec="minutes"))
            print(f"automātika: '{x.get('name')}' — FTP ap {nt:%d.%m. %H:%M}")
            continue
        if at <= now:
            due = due or sid
    return due


def _ftp_go(sid: str) -> None:
    from . import ftp
    x = stock.sets_store().data.get(sid) or {}

    def done(res: list, skip: list) -> None:
        now = datetime.now().isoformat(timespec="minutes")
        short = [{"agency": r["agency"], "done": r["done"], "total": r["total"], "error": r.get("error") or ""} for r in res]
        lim = [z["agency"] for z in skip if z.get("why") == "limit"]
        plan.upd(sid, ftp_done=now, ftp_res=short, want_ftp=None, ftp_late=None, ftp_run=None,
                 month_wait={"month": datetime.now().strftime("%Y-%m"), "ags": lim} if lim else None)
        if not short:                                    # nav ko sūtīt ar FTP (viss jau aizgājis / tikai portāla aģentūras)
            print(f"automātika: '{x.get('name')}' — ar FTP nav ko sūtīt")
            return
        plan.log_add({"at": now, "set": sid, "name": x.get("name") or "", "res": short,
                      "skip": [{"agency": z["agency"], "why": z["why"]} for z in skip if z.get("why") != "nothing"]})
        print(f"automātika: '{x.get('name')}' nosūtīts ar FTP — " + ", ".join(f"{r['agency']} {r['done']}/{r['total']}" for r in short))
        _sync(force=True)
    dl = None                                            # loga beigas (9:00) — pauzes saspiež, lai paspētu
    try:
        dl = window((plan.items().get(sid) or {}).get("date") or "")[1].timestamp()
    except ValueError:
        pass
    r = ftp.upload_auto(sid, done_cb=done, deadline=dl)
    if not r.get("ok") and r.get("error") == "busy":
        return
    if r.get("ok"):
        print(f"automātika: '{x.get('name')}' — sāku FTP ({', '.join(r.get('agencies') or [])})")
        threading.Thread(target=_progress, args=(sid,), daemon=True, name="ftp-progress").start()


def _progress(sid: str) -> None:
    """Sūtīšanas gaita plāna ierakstā `ftp_run` (ik ~30 s) — pults datoram (Mac) redzama caur sinhronizāciju (test25)."""
    from . import ftp
    last = None
    while True:
        j = ftp.status()
        if not j.get("running") or j.get("set") != sid:
            break
        cur = {"agency": j.get("agency"), "done": j.get("done") or 0, "total": j.get("total") or 0, "step": j.get("step") or 1,
               "steps": j.get("steps") or 1, "wait_until": j.get("wait_until") or 0}
        if cur != last:
            plan.upd(sid, ftp_run=dict(cur, at=datetime.now().isoformat(timespec="seconds"), pc=_pc()))
            last = cur
        _time.sleep(30)


def _move_progress(ids: list) -> None:
    """Pārvietošanas gaita plāna ierakstā `move_run` (ik ~30 s) — pults datoram statusa joslā (test40)."""
    from . import move
    last = None
    while True:
        j = move.status()
        if not j.get("running"):
            break
        cur = {"set": j.get("set"), "name": j.get("name") or "", "done": j.get("done") or 0, "total": j.get("total") or 0,
               "current": j.get("current") or ""}
        if cur != last:
            for sid in ids:
                plan.upd(sid, move_run=dict(cur, at=datetime.now().isoformat(timespec="seconds"), pc=_pc()))
            last = cur
        _time.sleep(30)
    for sid in ids:
        plan.upd(sid, move_run=None)


def next_info() -> dict:
    """Nākamais plānotais darbs (statusa joslai, kad nekas nenotiek): pārvietošana uz OneDrive un FTP."""
    sets = stock.sets_store().data
    mv, ft = None, None
    for sid, e in plan.items().items():
        x = sets.get(sid)
        if not x or e.get("status") != "approved" or not e.get("date"):
            continue
        if not x.get("rel") and not e.get("move_err"):
            mt = move_time(e["date"])
            if mt and (mv is None or mt < mv[0]):
                mv = (mt, x.get("name") or "")
        elif x.get("rel") and e.get("ftp_at") and not e.get("ftp_done") and not e.get("ftp_late") and config.get("sub_auto_ftp"):
            try:
                at = datetime.fromisoformat(e["ftp_at"])
            except ValueError:
                continue
            if ft is None or at < ft[0]:
                ft = (at, x.get("name") or "")
    return {"move_at": mv[0].isoformat(timespec="minutes") if mv else "", "move_name": mv[1] if mv else "",
            "ftp_at": ft[0].isoformat(timespec="minutes") if ft else "", "ftp_name": ft[1] if ft else ""}


def _pc() -> str:
    try:
        from core import sync
        return sync.computer()
    except Exception:
        return ""


# --------------------------------------------------------------------------- cilpa


def tick() -> None:
    if not duty():
        return
    now = datetime.now()
    _st["last_tick"] = now.isoformat(timespec="seconds")
    from . import nasrecv                                # NAS saņemšanas atskaite ik ~30 min (dati §7a 17)
    nasrecv.maybe()
    if _busy():
        return
    for sid in _st.pop("moving", None) or []:             # pārvietošana beigusies, bet komplekts nav OneDrive — vairs nemēģina
        if not (stock.sets_store().data.get(sid) or {}).get("rel"):
            plan.upd(sid, move_err="move")
    # vispirms lēti (bez NAS skenēšanas) — vai vispār ir ko darīt
    if not (_back_todo() or _move_todo(now) or _ftp_due(now)):
        return
    _sync()
    now = datetime.now()
    back = _back_todo()
    if back:
        from . import move
        r = move.unmove(back[0])
        if not r.get("ok"):
            ss = stock.sets_store()
            with ss.lock:
                if back[0] in ss.data:
                    ss.data[back[0]].pop("want_back", None)
                    ss.data[back[0]]["back_err"] = r.get("error") or "back"
                    ss.save()
        return
    mv = _move_todo(now)
    if mv:
        _do_moves(mv)
        nasrecv.maybe(force=True)
        return
    sid = _ftp_due(now)
    if sid:
        _ftp_go(sid)


def _loop() -> None:
    _time.sleep(20)                                      # vispirms Google sinhronizācija (core/sync palaišana)
    while True:
        try:
            tick()
            _st["err"] = ""
        except Exception as e:
            _st["err"] = f"{type(e).__name__}: {e}"[:200]
            print("automātika: kļūda —", _st["err"])
        _st["kick"].wait(TICK)
        _st["kick"].clear()


def start() -> None:
    if _st["thread"] and _st["thread"].is_alive():
        return
    _st["thread"] = threading.Thread(target=_loop, daemon=True, name="auto")
    _st["thread"].start()
