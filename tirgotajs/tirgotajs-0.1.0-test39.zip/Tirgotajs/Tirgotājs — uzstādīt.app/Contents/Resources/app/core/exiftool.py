"""Kopīgs ExifTool (noteikumi §3: ExifTool — `core/`). Pirmais lieto Tirgotājs (0.1.0-test38): bilžu teksti tikai ar
angļu burtiem (lēmums 2026-11-12 10:18 + lietotājs 16:14 "tekstiem jābūt 100% ar angliskajām rakstzīmēm").
Vārdotājam vēl savs `vardotajs/exif.py` — pāriet uz šo vēlāk (tie paši lauki un `to_english`).

Lauki (kā Vārdotājā): virsraksts XMP-dc:Title, IPTC:ObjectName, XMP-photoshop:Headline, IPTC:Headline;
apraksts XMP-dc:Description, IPTC:Caption-Abstract, EXIF:ImageDescription; atslēgvārdi XMP-dc:Subject, IPTC:Keywords.
"""
from __future__ import annotations

import io
import json
import os
import shutil
import subprocess
import tarfile
import unicodedata
import urllib.request
import zipfile
from pathlib import Path

from . import config

IS_WIN = config.IS_WIN
NO_WINDOW = 0x08000000 if IS_WIN else 0

TITLE = ("XMP-dc:Title", "IPTC:ObjectName", "XMP-photoshop:Headline", "IPTC:Headline")
DESC = ("XMP-dc:Description", "IPTC:Caption-Abstract", "EXIF:ImageDescription")
KW = ("XMP-dc:Subject", "IPTC:Keywords")

_FOLD = {"ł": "l", "Ł": "L", "ø": "o", "Ø": "O", "đ": "d", "Đ": "D", "ß": "ss", "æ": "ae", "Æ": "AE",
         "œ": "oe", "Œ": "OE", "þ": "th", "Þ": "TH", "ð": "d", "Ð": "D", "ı": "i", "ħ": "h", "Ħ": "H",
         "‘": "'", "’": "'", "‚": "'", "“": '"', "”": '"', "„": '"', "«": '"', "»": '"', "…": "...",
         "—": "-", "‐": "-", "‑": "-", " ": " "}


def to_english(s) -> str:
    """Tikai angļu burti: "Rīga" → "Riga", "Kraków" → "Krakow". ED paraksta domuzīme "–" paliek (kā Vārdotājā)."""
    s = "".join(_FOLD.get(c, c) for c in str(s or ""))
    s = unicodedata.normalize("NFKD", s)
    return "".join(c for c in s if not unicodedata.combining(c) and (ord(c) < 128 or c == "–"))


def is_english(s) -> bool:
    return all(ord(c) < 128 or c == "–" for c in str(s or ""))


# --------------------------------------------------------------------------- atrašana / uzstādīšana

def _install_dir() -> Path:
    return config.app_dir() / "exiftool"


def _dirs() -> list[Path]:
    """Sava datu mape, tad citu Fotostokera moduļu (Vārdotājs ExifTool jau ir uzstādījis — lietotājs 2026-11-12 16:21;
    tas ir rīks, ne moduļa dati)."""
    own = _install_dir()
    return [own] + [own.parent.parent / s / "exiftool" for s in ("Vardotajs", "Fotostokeris", "Analitikis", "Tirgotajs")]


def find() -> list[str] | None:
    for base in _dirs():
        c = base / ("exiftool.exe" if IS_WIN else "exiftool")
        if c.is_file():
            return [str(c)] if IS_WIN else [shutil.which("perl") or "/usr/bin/perl", str(c)]
    w = shutil.which("exiftool")
    if w:
        return [w]
    for p in ("/opt/homebrew/bin/exiftool", "/usr/local/bin/exiftool", "/usr/bin/exiftool"):
        if os.path.isfile(p):
            return [p]
    return None


def _download(url: str, timeout: int = 120) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "Fotostokeris/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.read()
    except Exception:
        curl = shutil.which("curl")
        if not curl:
            raise
        out = subprocess.run([curl, "-fsSL", url], capture_output=True, timeout=timeout, creationflags=NO_WINDOW,
                             check=True)
        return out.stdout


def _unpack(data: bytes, is_zip: bool) -> None:
    target, tmp = _install_dir(), config.app_dir() / "exiftool_tmp"
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir(parents=True)
    if is_zip:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            z.extractall(tmp)
    else:
        with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as t:
            t.extractall(tmp)
    shutil.rmtree(target, ignore_errors=True)
    target.mkdir(parents=True)
    if IS_WIN:
        exe = next((p for p in tmp.rglob("*.exe") if p.name.lower() in ("exiftool(-k).exe", "exiftool.exe")
                    and (p.parent / "exiftool_files").is_dir()), None)
        if not exe:
            raise RuntimeError("no exiftool.exe")
        shutil.move(str(exe), str(target / "exiftool.exe"))
        shutil.move(str(exe.parent / "exiftool_files"), str(target / "exiftool_files"))
    else:
        src = next((p.parent for p in tmp.rglob("exiftool") if p.is_file()
                    and (p.parent / "lib" / "Image" / "ExifTool.pm").is_file()), None)
        if not src:
            raise RuntimeError("no exiftool")
        shutil.copy2(src / "exiftool", target / "exiftool")
        shutil.copytree(src / "lib", target / "lib")
        os.chmod(target / "exiftool", 0o755)
    shutil.rmtree(tmp, ignore_errors=True)


def ensure() -> list[str]:
    """ExifTool komanda; ja nav — lejupielādē moduļa datu mapē (kā Vārdotājs)."""
    cmd = find()
    if cmd:
        return cmd
    errors = []
    tries = ([("https://exiftool.org/exiftool-{v}_64.zip", True),
              ("https://codeload.github.com/photostructure/exiftool-vendored.exe/zip/refs/heads/main", True)] if IS_WIN else
             [("https://codeload.github.com/exiftool/exiftool/zip/refs/heads/master", True),
              ("https://exiftool.org/Image-ExifTool-{v}.tar.gz", False)])
    for url, is_zip in tries:
        try:
            if "{v}" in url:
                url = url.format(v=_download("https://exiftool.org/ver.txt", 30).decode().strip())
            _unpack(_download(url), is_zip)
            cmd = find()
            if cmd:
                print("ExifTool uzstādīts:", url)
                return cmd
        except Exception as e:
            errors.append(f"{url}: {e}")
    raise RuntimeError("ExifTool nav: " + " | ".join(errors))


# --------------------------------------------------------------------------- lasīšana / rakstīšana

def _run(args: list[str], timeout: int = 300) -> subprocess.CompletedProcess:
    """Argumenti caur UTF-8 failu (-@): Windows komandrindā "–" un burti ar garumzīmēm ceļos citādi sabojājas."""
    import tempfile
    fd, af = tempfile.mkstemp(suffix=".args")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write("\n".join(a.replace("\n", " ") for a in args) + "\n")
        return subprocess.run(ensure() + ["-charset", "filename=utf8", "-@", af], capture_output=True, timeout=timeout,
                              creationflags=NO_WINDOW)
    finally:
        try:
            os.remove(af)
        except OSError:
            pass


def _list(v) -> list[str]:
    if v is None:
        return []
    return [str(x) for x in v] if isinstance(v, list) else [str(v)]


def read_texts(paths: list[str]) -> dict[str, dict]:
    """{ceļš: {tag: vērtība | [saraksts]}} — tikai teksta lauki (virsraksts, apraksts, atslēgvārdi)."""
    out: dict[str, dict] = {}
    for i in range(0, len(paths), 50):
        part = paths[i:i + 50]
        r = _run(["-j", "-G1", "-charset", "utf8", "-charset", "iptc=utf8", "-struct"]
                 + [f"-{t}" for t in TITLE + DESC + KW] + part)
        try:
            data = json.loads(r.stdout.decode("utf-8", "replace") or "[]")
        except ValueError:
            data = []
        for d in data:
            src = d.get("SourceFile") or ""
            out[os.path.normcase(os.path.abspath(src))] = {k: v for k, v in d.items() if k != "SourceFile"}
    return out


def fix_english(paths: list[str]) -> dict:
    """Bildēm, kuru virsrakstā / aprakstā / atslēgvārdos ir ne-angļu burti, ieraksta tos pašus tekstus ar angļu
    burtiem (failu pārraksta vietā). Atgriež {fixed: [faili], errors: [..]}."""
    paths = [p for p in paths if os.path.isfile(p)]
    if not paths:
        return {"fixed": [], "errors": []}
    meta = read_texts(paths)
    fixed, errors = [], []
    for p in paths:
        m = meta.get(os.path.normcase(os.path.abspath(p))) or {}
        bad = {k: v for k, v in m.items() if not all(is_english(x) for x in _list(v))}
        if not bad:
            continue
        args = ["-overwrite_original", "-m", "-codedcharacterset=utf8", "-charset", "iptc=utf8"]
        for k, v in bad.items():
            if isinstance(v, list):
                vals = [to_english(x).strip() for x in v]
                vals = [x for i, x in enumerate(vals) if x and x.lower() not in {y.lower() for y in vals[:i]}]
                args += [f"-{k}={x}" for x in vals] or [f"-{k}="]   # vairāki "=" vienā komandā = jauns saraksts
            else:
                args.append(f"-{k}={to_english(v)}")
        r = _run(args + [p], timeout=120)
        if r.returncode != 0:
            errors.append(f"{os.path.basename(p)}: {r.stderr.decode('utf-8', 'replace').strip()[:150]}")
        else:
            fixed.append(p)
    return {"fixed": fixed, "errors": errors}
