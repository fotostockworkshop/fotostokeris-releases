"""Krājums: gatavās bildes (no Vārdotāja manifestiem) × aģentūras, prasību pārbaude un iesniegumu uzskaite.

Avots — iesniegšanai gatavo bilžu mape (Vārdotājs 0.9.0-test9+: <gads>/<YYYY-MM>_<Sērija>_<kods>/RF|ED/), katrā bilžu
mapē .fotostokeris/<sērija>.json (+ -sikteli.zip). Moduļi viens otru neimportē — tikai dati (noteikumi §10, dati §7a).
Uzskaite — ledger.json Tirgotāja datu mapē: {stem: {aģentūra: {"state", "at", "reason"}}}; stem = faila nosaukums bez
paplašinājuma (pēc Vārdotāja pārdēvēšanas tas ir unikāls: <kods>_<oriģinālais>).
"""
from __future__ import annotations

import json
import os
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import config

SUB = ".fotostokeris"
STATES = ("submitted", "accepted", "rejected", "skip")     # "" = vēl nav iesniegts; "skip" = lietotājs: neder šai aģentūrai

# Aģentūras, kurās Tirgotājs palīdz iesniegt (Bigstock jaunu saturu vairs nepieņem — docs/tirgotajs-iesniegsana.md)
AGENCIES = [
    {"id": "adobe", "name": "Adobe Stock", "url": "https://contributor.stock.adobe.com/", "ftp": "SFTP*"},
    {"id": "shutterstock", "name": "Shutterstock", "url": "https://submit.shutterstock.com/", "ftp": "FTPS", "limit": [500, 7]},
    {"id": "istock", "name": "iStock / Getty", "url": "https://esp.gettyimages.com/", "ftp": ""},
    {"id": "alamy", "name": "Alamy", "url": "https://www.alamy.com/myupload/Index.aspx", "ftp": "FTP"},
    {"id": "dreamstime", "name": "Dreamstime", "url": "https://www.dreamstime.com/upload", "ftp": "FTP"},
    {"id": "depositphotos", "name": "Depositphotos", "url": "https://depositphotos.com/", "ftp": "FTP"},
    {"id": "123rf", "name": "123RF", "url": "https://www.123rf.com/contributor/", "ftp": "FTP"},
    {"id": "pond5", "name": "Pond5", "url": "https://www.pond5.com/", "ftp": "FTP"},
    {"id": "envato", "name": "Envato", "url": "https://portfolio.author.envato.com/", "ftp": ""},
    {"id": "magnific", "name": "Magnific", "url": "https://www.magnific.com/", "ftp": "FTP*", "limit": [200, 30]},
    {"id": "pixta", "name": "PIXTA", "url": "https://pixtastock.com/", "ftp": ""},
]
AG_IDS = [a["id"] for a in AGENCIES]

_lock = threading.RLock()
_ledger: config.JsonStore | None = None
_specs: dict | None = None
_zips: dict[str, str] = {}            # sērijas atslēga → sīktēlu zip ceļš (sīktēlu GET adresei)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ledger() -> config.JsonStore:
    global _ledger
    if _ledger is None:
        _ledger = config.JsonStore(config.app_dir() / "ledger.json", {})
    return _ledger


def specs() -> dict:
    global _specs
    if _specs is None:
        p = Path(__file__).resolve().parent.parent / "core" / "agency_specs.json"
        if not p.is_file():
            p = Path(__file__).resolve().parent.parent.parent / "core" / "agency_specs.json"   # izstrādē
        try:
            _specs = json.loads(p.read_text(encoding="utf-8")).get("agencies") or {}
        except Exception:
            _specs = {}
    return _specs


def agencies() -> list[dict]:
    """Aģentūras, ko rādīt: Tirgotāja izvēle → kopīgās mērķa aģentūras → visas."""
    sel = config.get("sub_agencies") or []
    if not sel:
        tgt = config.get("target_agencies") or []
        sel = [a for a in tgt if a in AG_IDS]
    ids = [a for a in AG_IDS if a in sel] if sel else AG_IDS
    return [a for a in AGENCIES if a["id"] in ids]


# --------------------------------------------------------------------------- bilžu saraksts no manifestiem

def _manifests(root: str):
    for d, dirs, fl in os.walk(root):
        base = os.path.basename(d)
        if base == SUB:
            dirs[:] = []
            for f in sorted(fl):
                if f.endswith(".json") and not f.endswith(".tmp"):
                    yield os.path.dirname(d), os.path.join(d, f)
            continue
        dirs[:] = [x for x in dirs if x == SUB or (not x.startswith(".") and x.lower() != "manifesti")]


def scan() -> dict:
    root = str(config.get("sub_ready_dir") or "").strip()
    if not root:
        return {"ok": True, "items": [], "series": [], "no_dir": True}
    if not os.path.isdir(root):
        return {"ok": False, "error": "dir_missing", "dir": root, "items": [], "series": []}
    items, series = [], []
    seen: set[str] = set()
    _zips.clear()
    for folder, jpath in _manifests(root):
        try:
            data = json.loads(Path(jpath).read_text(encoding="utf-8"))
        except Exception:
            continue
        key = f"s{len(series)}"
        z = os.path.join(os.path.dirname(jpath), data.get("thumbs") or "")
        if data.get("thumbs") and os.path.isfile(z):
            _zips[key] = z
        n = 0
        for it in data.get("images") or []:
            if it.get("status") == "moved" or not it.get("file"):
                continue
            p = os.path.join(folder, it["file"])
            if not os.path.isfile(p):
                continue
            stem = it.get("stem") or os.path.splitext(it["file"])[0]
            if stem in seen:
                continue
            seen.add(stem)
            try:
                size = os.path.getsize(p)
            except OSError:
                size = 0
            n += 1
            items.append({
                "stem": stem, "file": it["file"], "orig": it.get("orig_file") or it["file"], "path": p,
                "folder": folder, "series": key, "cat": it.get("category") or "RF", "ready": it.get("status") == "ready",
                "title": it.get("title") or "", "kw": len(it.get("keywords") or []),
                "w": int(it.get("width") or 0), "h": int(it.get("height") or 0), "size": size,
                "ext": os.path.splitext(it["file"])[1].lower().lstrip("."), "taken": it.get("taken_at") or "",
                "thumb": bool(key in _zips), "phash": it.get("phash") or ""})
        if n:
            series.append({"key": key, "name": data.get("name") or os.path.basename(folder),
                           "code": data.get("series_code") or "", "folder": folder, "count": n})
    return {"ok": True, "items": items, "series": series}


# --------------------------------------------------------------------------- prasību pārbaude (core/agency_specs.json)

def check(it: dict, ag: str) -> list[list]:
    """Iemesli, kāpēc bilde neder aģentūrai: [[atslēga, {vērtības}], …] (teksti — saskarnē)."""
    out = []
    cat = it.get("cat") or "RF"
    if cat in ("ED", "EDI"):
        ed = config.get("sub_ed_agencies")
        ed = ed if isinstance(ed, list) else []
        if ag not in ed and not (cat == "EDI" and ag == "adobe"):
            out.append(["r_ed", {}])
    s = specs().get(ag) or {}
    ext = {"jpeg": "jpg", "tiff": "tif"}.get(it["ext"], it["ext"])
    fm = s.get("formats")
    if fm and ext not in fm:
        out.append(["r_fmt", {"f": ext.upper(), "ok": ", ".join(x.upper() for x in fm)}])
    mb = it["size"] / 1048576
    if s.get("max_mb") and mb > s["max_mb"]:
        out.append(["r_big", {"mb": round(mb, 1), "max": s["max_mb"]}])
    if s.get("min_mb") and mb < s["min_mb"]:
        out.append(["r_small_mb", {"mb": round(mb, 1), "min": s["min_mb"]}])
    w, h = it["w"], it["h"]
    if w and h:
        mp = w * h / 1e6
        if s.get("min_mp") and mp < s["min_mp"]:
            out.append(["r_min_mp", {"mp": round(mp, 1), "min": s["min_mp"]}])
        if s.get("max_mp") and mp > s["max_mp"]:
            out.append(["r_max_mp", {"mp": round(mp, 1), "max": s["max_mp"]}])
        if s.get("min_side_px") and min(w, h) < s["min_side_px"]:
            out.append(["r_side", {"px": min(w, h), "min": s["min_side_px"]}])
        if s.get("min_long_px") and max(w, h) < s["min_long_px"]:
            out.append(["r_long_min", {"px": max(w, h), "min": s["min_long_px"]}])
        if s.get("max_long_px") and max(w, h) > s["max_long_px"]:
            out.append(["r_long_max", {"px": max(w, h), "max": s["max_long_px"]}])
    return out


def listing() -> dict:
    r = scan()
    led = ledger().data
    ags = agencies()
    mem: dict[str, list] = {}
    for x in sets_store().data.values():
        for st in x.get("stems") or []:
            mem.setdefault(st, []).append(x.get("id"))
    r["sets"] = [{"id": x.get("id"), "name": x.get("name")} for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True)]
    for it in r["items"]:
        it["in_sets"] = mem.get(it["stem"], [])
        rec = led.get(it["stem"]) or {}
        cells = {}
        for a in ags:
            c = dict(rec.get(a["id"]) or {})
            bad = check(it, a["id"])
            if bad:
                c["bad"] = bad
            cells[a["id"]] = c
        it["cells"] = cells
    # ierakstiem uzskaitē, kuru bilžu mapē vairs nav (pārvietotas / dzēstas) — tikai skaits
    have = {it["stem"] for it in r["items"]}
    r["gone"] = sum(1 for s in led if s not in have)
    r["agencies"] = ags
    return r


def mark(stems: list, ag: str, state: str, reason: str = "") -> int:
    if ag not in AG_IDS or (state and state not in STATES):
        raise ValueError("bad state")
    st = ledger()
    n = 0
    with st.lock:
        for s in stems:
            rec = st.data.setdefault(str(s), {})
            if state:
                rec[ag] = {"state": state, "at": _now(), **({"reason": reason} if reason else {})}
            else:
                rec.pop(ag, None)
            if not rec:
                st.data.pop(str(s), None)
            n += 1
        st.save()
    return n


# --------------------------------------------------------------------------- komplekti (kopsavilkums §3 "Komplekts")
# Komplekts = vienas kategorijas bilžu kopa iesniegšanai visās piemērotajās aģentūrās vienā reizē. Gandrīz vienādas bildes
# (phash attālums ≤ 6, kā Vārdotājā) vienā komplektā nekad; vienas sērijas dažādi kadri — drīkst.
SIMILAR = 6
_sets: config.JsonStore | None = None


def sets_store() -> config.JsonStore:
    global _sets
    if _sets is None:
        _sets = config.JsonStore(config.app_dir() / "sets.json", {})   # {id: komplekts} — vārdnīca, lai sinhronizācija apvieno pa ierakstiem
    return _sets


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _todo(it: dict, ags: list) -> bool:
    """Vai bilde vēl jāiesniedz vismaz vienā aģentūrā (nav atzīmes un der pēc prasībām)."""
    return any(not (it["cells"].get(a) or {}).get("state") and not (it["cells"].get(a) or {}).get("bad") for a in ags)


def _cat_ok(it: dict, cat: str) -> bool:
    return (it.get("cat") or "RF").startswith("ED") if cat == "ED" else (it.get("cat") or "RF") == "RF"


def suggest(cat: str = "RF", size: int = 0, exclude: list | None = None) -> dict:
    r = listing()
    ags = [a["id"] for a in r["agencies"]]
    in_sets = {st for x in sets_store().data.values() for st in x.get("stems") or []}
    excl = set(exclude or [])
    cand = [it for it in r["items"] if _cat_ok(it, cat) and it["stem"] not in in_sets and it["stem"] not in excl and _todo(it, ags)]
    cand.sort(key=lambda it: (it.get("taken") or "", it["series"], it["file"]))
    auto = max(10, min(50, -(-len(cand) // 20))) if cand else 0      # vienmērīga plūsma: ~20 darba dienās (1 mēnesis)
    size = int(size or 0) or auto
    chosen, similar = [], 0
    for it in cand:
        if len(chosen) >= size:
            break
        if it.get("phash") and any(_ham(it["phash"], c.get("phash")) <= SIMILAR for c in chosen if c.get("phash")):
            similar += 1
            continue
        chosen.append(it)
    return {"ok": True, "items": chosen, "similar": similar, "todo": len(cand), "auto": auto, "size": size,
            "agencies": r["agencies"]}


def set_save(name: str, cat: str, stems: list) -> dict:
    st = sets_store()
    with st.lock:
        sid = f"k{int(datetime.now().timestamp() * 1000)}"
        n = sum(1 for x in st.data.values() if x.get("created", "")[:10] == _now()[:10] and x.get("cat") == cat) + 1
        rec = {"id": sid, "name": name or f"{cat}-{_now()[:10]}-{n}", "cat": cat, "created": _now(), "stems": list(stems)}
        st.data[sid] = rec
        st.save()
    return rec


def set_delete(sid: str) -> None:
    st = sets_store()
    with st.lock:
        st.data.pop(sid, None)
        st.save()


def sets_list() -> list:
    led = ledger().data
    ags = [a["id"] for a in agencies()]
    out = []
    for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True):
        prog = {}
        for a in ags:
            prog[a] = sum(1 for s in x.get("stems") or [] if ((led.get(s) or {}).get(a) or {}).get("state"))
        out.append({**x, "count": len(x.get("stems") or []), "progress": prog})
    return out


def set_dir() -> str:
    d = str(config.get("sub_set_dir") or "").strip()
    return d or str(Path.home() / "Fotostokeris komplekti")


def _safe(n: str) -> str:
    return "".join(c if c.isalnum() or c in "-_ ." else "_" for c in n).strip() or "komplekts"


def set_export(sid: str, ag: str) -> dict:
    """Komplekta bildes, kas aģentūrai der un vēl nav atzīmētas, nokopē mapē <komplektu mape>/<komplekts>/<aģentūra>/
    (oriģināli paliek vietā; ievilkt aģentūras lapā vai FTP programmā)."""
    x = sets_store().data.get(sid)
    if not x or ag not in AG_IDS:
        raise ValueError("bad set")
    r = listing()
    by = {it["stem"]: it for it in r["items"]}
    dst = os.path.join(set_dir(), _safe(x.get("name") or sid), ag)
    os.makedirs(dst, exist_ok=True)
    done, skipped, missing = 0, 0, 0
    import shutil
    for st in x.get("stems") or []:
        it = by.get(st)
        if not it:
            missing += 1
            continue
        c = it["cells"].get(ag) or {}
        if c.get("state") or c.get("bad"):
            skipped += 1
            continue
        out = os.path.join(dst, it["file"])
        if not (os.path.isfile(out) and os.path.getsize(out) == it["size"]):
            shutil.copy2(it["path"], out + ".part")
            os.replace(out + ".part", out)
        done += 1
    return {"ok": True, "dir": dst, "copied": done, "skipped": skipped, "missing": missing}


def thumb(series: str, stem: str) -> bytes | None:
    z = _zips.get(series)
    if not z:
        return None
    try:
        with zipfile.ZipFile(z) as f:
            return f.read(stem + ".jpg")
    except (KeyError, OSError, zipfile.BadZipFile):
        return None
