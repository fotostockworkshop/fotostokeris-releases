"use strict";
/* Tirgotājs 0.1.0 — krājums "bilde × aģentūra" (docs/tirgotajs-kopsavilkums.md §3, §11; docs/tirgotajs-iesniegsana.md).
   Kopīgais (tēma, valoda, iestatījumu rāmis, atjauninājumi) — /core/core.js. */

const S = { items: [], series: [], agencies: [], sets: [], sel: new Set(), shown: 300, page: "stock", data: null, ns: null };
Object.defineProperty(S, "settings", { get: () => Core.settings, set: (v) => { Core.settings = v; } });   // google.js / gsync.js lieto S.settings
const STATES = ["uploaded", "submitted", "accepted", "rejected", "skip"];

function showPage(name) {
  if (name === "sets" && typeof loadThemes === "function") setTimeout(loadThemes, 0);
  S.page = name;
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "settings") loadSettings();
  if (name === "sets") loadSets();
  if (name === "plan" && window.planLoad) planLoad();
  if (name === "sets" && typeof fillDay === "function") fillDay("#nsDate");
  if (name === "pick" && typeof fillDay === "function") fillDay("#pDate");
}
function loadSettings() { settingsPage.load(); }      // google.js papildina (Google konta rinda)
function reloadView() { load(); if (S.page === "sets") loadSets(); if (S.page === "plan" && window.planLoad) planLoad(); }   // gsync.js — pēc datu saņemšanas no cita datora
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));

/* ---------- šūnas stāvoklis ---------- */
function cellState(it, ag) {
  const c = (it.cells || {})[ag] || {};
  if (c.state) return c.state;                     // lietotāja atzīme ir svarīgāka par pārbaudi
  if (c.bad) return "bad";
  if (c.ext) return c.ext.status === "rejected" ? "extrej" : "ext";   // jau aģentūrā (Analītiķis, test21)
  return "";
}
function reasonText(r) { return t(r[0], r[1] || {}); }
function cellTitle(it, ag) {
  const c = (it.cells || {})[ag] || {}, st = cellState(it, ag);
  const parts = [agName(ag) + ": " + t("st_" + st)];
  if (c.at) parts.push(new Date(c.at).toLocaleDateString(window.langLocale()));
  if (c.reason) parts.push(c.reason);
  if (c.bad) parts.push(...c.bad.map(reasonText));
  if (c.ext) parts.push(t("ext_tip", { s: t("exs_" + (c.ext.status || "other")), d: c.ext.seen || "?" }));
  return parts.join("\n");
}
function agName(id) { const a = S.agencies.find((x) => x.id === id); return a ? a.name : id; }

/* ---------- ielāde ---------- */
async function load() {
  let d;
  try { d = await api("list"); } catch (e) { toast(e.message, "err"); return; }
  S.data = d; S.loadedAt = Date.now();
  S.items = d.items || []; S.series = d.series || []; S.agencies = d.agencies || []; S.sets = d.sets || [];
  const have = new Set(S.items.map((i) => i.stem));
  S.sel.forEach((s) => { if (!have.has(s)) S.sel.delete(s); });
  $("#noDir").classList.toggle("hidden", !d.no_dir && d.error !== "dir_missing");
  if (d.error === "dir_missing") $("#noDir p").textContent = t("dir_missing", { p: d.dir || "" });
  else $("#noDir p").textContent = t("no_dir");
  const dir = (Core.settings || {}).sub_ready_dir || "";
  $("#dirLine").classList.toggle("hidden", !dir || d.error === "dir_missing");
  $("#dirPath").textContent = dir;
  drvLine(d.drive || {});
  fillFilters();
  renderCards();
  render();
  Core.setStatus("count", { text: t("sb_count", { n: S.items.length, s: S.series.length }) });
}

/* Google Drive manifesti un agenturas_bildes.json (test21) */
function drvLine(g) {
  const nas = S.items.filter((i) => i.remote).length;
  $("#drvLine").classList.toggle("hidden", !g.google);
  $("#drvText").textContent = !g.google ? "" : (g.at ? t("drv_line", { m: g.manifests || 0, n: nas, e: g.ext || 0, at: g.at }) : t("drv_wait")) + (g.error ? " ⚠ " + g.error : "");
}
$("#drvRefresh").addEventListener("click", async (e) => {
  e.target.disabled = true;
  try { const r = await api("drive", { do: "refresh" }); if (r.error) toast(r.error, "err"); await load(); }
  catch (err) { toast(err.message, "err"); }
  e.target.disabled = false;
});

function fillFilters() {
  const fs = $("#fSeries"), cur = fs.value;
  fs.innerHTML = `<option value="">${esc(t("all"))}</option>` + S.series.map((s) => `<option value="${esc(s.key)}">${esc(s.name)} (${s.count})</option>`).join("");
  fs.value = S.series.some((s) => s.key === cur) ? cur : "";
  const fk = $("#fSet"), ck = fk.value;
  fk.innerHTML = `<option value="">${esc(t("all"))}</option><option value="-">${esc(t("f_noset"))}</option>` + S.sets.map((x) => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("");
  fk.value = ck === "-" || S.sets.some((x) => x.id === ck) ? ck : "";
  for (const sel of [$("#fAgency"), $("#selAgency")]) {
    const v = sel.value;
    sel.innerHTML = (sel.id === "fAgency" ? `<option value="">${esc(t("any_agency"))}</option>` : "") + S.agencies.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("");
    if (S.agencies.some((a) => a.id === v)) sel.value = v;
  }
}

/* ---------- kopsavilkums pa aģentūrām ---------- */
function renderCards() {
  const box = $("#agCards");
  if (!S.items.length) { box.innerHTML = ""; return; }
  box.innerHTML = S.agencies.map((a) => {
    const n = { "": 0, uploaded: 0, submitted: 0, accepted: 0, rejected: 0, skip: 0, bad: 0, ext: 0, extrej: 0 };
    S.items.forEach((it) => { n[cellState(it, a.id)]++; });
    const lim = a.limit ? `<div class="ag-lim small ${recentCount(a.id, a.limit[1]) >= a.limit[0] ? "over" : "muted"}">${esc(t("limit_line", { have: recentCount(a.id, a.limit[1]), n: a.limit[0], d: a.limit[1] }))}</div>` : "";
    const how = a.ftp ? t(a.ftp.endsWith("*") ? "how_ftp_q" : "how_ftp", { f: a.ftp.replace("*", "") }) : t("how_web");
    return `<div class="ag-card" data-ag="${a.id}">
      <div class="ag-h"><b>${esc(a.name)}</b><button class="ghost small ag-open" data-url="${esc(a.url)}" title="${esc(t("open_ag_d"))}">${esc(t("open_ag"))} ↗</button></div>
      <div class="ag-todo"><span class="big">${n[""]}</span> <span class="muted">${esc(t("c_todo"))}</span></div>
      <div class="ag-n small">${n.uploaded ? `<span class="st-uploaded-t">${n.uploaded} ${esc(t("c_upl"))}</span> · ` : ""}<span class="st-submitted-t">${n.submitted} ${esc(t("c_sub"))}</span> · <span class="st-accepted-t">${n.accepted} ${esc(t("c_acc"))}</span> ·
        <span class="st-rejected-t">${n.rejected} ${esc(t("c_rej"))}</span> · <span class="muted">${n.bad + n.skip} ${esc(t("c_bad"))}</span>${n.ext + n.extrej ? ` · <span class="st-ext-t" title="${esc(t("c_ext_tip"))}">${n.ext + n.extrej} ${esc(t("c_ext"))}</span>` : ""}</div>
      <div class="ag-how small muted">${esc(how)}</div>${lim}
      <button class="ag-todo-btn small" data-ag="${a.id}">${esc(t("show_todo"))}</button></div>`;
  }).join("");
}
$("#agCards").addEventListener("click", async (e) => {
  const o = e.target.closest(".ag-open");
  if (o) { try { await api("open_url", { url: o.dataset.url }); } catch (err) { toast(err.message, "err"); } return; }
  const b = e.target.closest(".ag-todo-btn");
  if (b) { $("#fAgency").value = b.dataset.ag; $("#fShow").value = "todo"; S.shown = 300; render(); $("#grid").scrollIntoView({ behavior: "smooth" }); }
});

/* ---------- tabula ---------- */
function filtered() {
  const set = $("#fSet").value, ser = $("#fSeries").value, cat = $("#fCat").value, show = $("#fShow").value, ag = $("#fAgency").value;
  const q = $("#fText").value.trim().toLowerCase();
  const ags = ag ? [ag] : S.agencies.map((a) => a.id);
  return S.items.filter((it) => {
    if (ser && it.series !== ser) return false;
    if (set === "-" ? (it.in_sets || []).length : set && !(it.in_sets || []).includes(set)) return false;
    if (cat && it.cat !== cat) return false;
    if (q && !(it.file + " " + it.orig + " " + it.title).toLowerCase().includes(q)) return false;
    if (show === "todo") return ags.some((a) => cellState(it, a) === "");
    if (show === "rejected") return ags.some((a) => cellState(it, a) === "rejected");
    if (show === "bad") return ags.some((a) => cellState(it, a) === "bad");
    return true;
  });
}

function render() {
  const list = filtered();
  const ags = S.agencies;
  $("#grid thead").innerHTML = `<tr><th class="ck"><input type="checkbox" id="ckAll"></th><th></th><th data-i18n="col_file">${esc(t("col_file"))}</th>
    <th>${esc(t("col_cat"))}</th><th>${esc(t("col_size"))}</th>` +
    ags.map((a) => `<th class="agh" title="${esc(a.name)}">${esc(a.name.replace(/ \/.*/, ""))}</th>`).join("") + `</tr>`;
  const rows = list.slice(0, S.shown);
  const tok = encodeURIComponent(window.TOKEN);
  $("#grid tbody").innerHTML = rows.map((it) => {
    const mb = (it.size / 1048576).toFixed(1), mp = it.w && it.h ? (it.w * it.h / 1e6).toFixed(1) + " MP" : "";
    const ser = S.series.find((s) => s.key === it.series);
    return `<tr data-stem="${esc(it.stem)}" class="${S.sel.has(it.stem) ? "sel" : ""}">
      <td class="ck"><input type="checkbox" class="ck1" ${S.sel.has(it.stem) ? "checked" : ""}></td>
      <td class="th">${it.thumb ? `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(it.series)}&n=${encodeURIComponent(it.stem)}" alt="">` : ""}</td>
      <td class="fn"><div class="f1" title="${esc(it.remote ? t("nas_tip") : it.path)}">${esc(it.file)}${it.remote ? ` <span class="nas-badge" title="${esc(t("nas_tip"))}">${esc(t("nas_badge"))}</span>` : ""}${it.planned ? ` <span class="pl-badge" title="${esc(t("planned_tip"))}">📅 ${esc(fmtDay(it.planned))}</span>` : ""}${it.edwarn ? ` <span class="edw-badge" title="${esc(t("edw_tip"))}">⚠ ${esc(t("edw_badge"))}</span>` : ""}</div><div class="f2 muted small">${esc(ser ? ser.name : "")}${it.title ? " · " + esc(it.title) : ""}</div></td>
      <td><span class="cat cat-${esc(it.cat)}">${esc(it.cat)}</span></td>
      <td class="muted small">${it.size ? mb + " MB" : "—"}<br>${mp}</td>` +
      ags.map((a) => { const st = cellState(it, a.id); return `<td class="cell st-${st}" data-ag="${a.id}" title="${esc(cellTitle(it, a.id))}">${(((it.cells || {})[a.id] || {}).as === "ED") ? '<sup class="as-ed">ED</sup>' : ""}${st === "bad" ? "!" : st === "accepted" ? "✓" : st === "rejected" ? "✕" : st === "submitted" ? "↑" : st === "uploaded" ? "⇡" : st === "skip" ? "–" : st === "ext" ? "◆" : st === "extrej" ? "◇" : ""}</td>`; }).join("") + `</tr>`;
  }).join("");
  $("#empty").classList.toggle("hidden", !!list.length || !!(S.data && S.data.no_dir));
  $("#empty").textContent = S.items.length ? t("empty_filter") : t("empty_none");
  $("#more").classList.toggle("hidden", list.length <= S.shown);
  $("#countLine").textContent = t("count_line", { n: list.length, all: S.items.length });
  /* filtrs ieslēgts — skaidri pasaka un ļauj rādīt visas (2026-11-05: "jaunās neredz" — bija atlasīta viena sērija) */
  const fl = fltNames();
  $("#fltNote").classList.toggle("hidden", !fl.length);
  $("#fltNoteT").textContent = fl.length ? t("flt_note", { f: fl.join(", "), n: S.items.length - list.length }) : "";
  $("#ckAll").checked = rows.length > 0 && rows.every((r) => S.sel.has(r.stem));
  $("#ckAll").addEventListener("change", (e) => { rows.forEach((r) => (e.target.checked ? S.sel.add(r.stem) : S.sel.delete(r.stem))); render(); });
  selBar();
}
function fmtDay(iso) { return new Date(iso + "T12:00").toLocaleDateString(window.langLocale(), { day: "2-digit", month: "2-digit" }); }
function fltNames() {
  const out = [];
  const sv = (id) => { const e = $(id); return e.value ? e.options[e.selectedIndex].textContent : ""; };
  for (const id of ["#fSeries", "#fSet", "#fCat", "#fShow", "#fAgency"]) { const v = sv(id); if (v) out.push(v); }
  if ($("#fText").value.trim()) out.push("“" + $("#fText").value.trim() + "”");
  return out;
}
$("#fltAll").addEventListener("click", () => {
  for (const id of ["#fSeries", "#fSet", "#fCat", "#fShow", "#fAgency", "#fText"]) $(id).value = "";
  S.shown = 300; render();
});
/* atgriežoties logā — pārlasa mapi (ne biežāk kā 1×/min), lai jaunas sērijas uz NAS parādās bez "Atjaunot" */
window.addEventListener("focus", () => { if (Date.now() - (S.loadedAt || 0) > 60000 && !document.querySelector(".modal:not(.hidden)")) reloadView(); });
["#fSet", "#fSeries", "#fCat", "#fShow", "#fAgency"].forEach((s) => $(s).addEventListener("change", () => { S.shown = 300; render(); }));
$("#fText").addEventListener("input", () => { S.shown = 300; render(); });
$("#more").addEventListener("click", () => { S.shown += 300; render(); });

$("#grid tbody").addEventListener("click", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr) return;
  const stem = tr.dataset.stem;
  const cell = e.target.closest("td.cell");
  if (cell) return cellMenu(cell, stem, cell.dataset.ag);
  if (e.target.closest("td.ck") || e.target.closest("td.th") || e.target.closest("td.fn")) {
    if (S.sel.has(stem)) S.sel.delete(stem); else S.sel.add(stem);
    tr.classList.toggle("sel", S.sel.has(stem));
    const ck = $(".ck1", tr); if (ck) ck.checked = S.sel.has(stem);
    selBar();
  }
});
$("#grid tbody").addEventListener("dblclick", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr || e.target.closest("td.cell")) return;
  const it = S.items.find((i) => i.stem === tr.dataset.stem);
  if (it) api("open", { path: it.path }).catch((err) => toast(err.message, "err"));
});

/* ---------- vienas šūnas izvēlne ---------- */
function cellMenu(td, stem, ag) {
  const m = $("#cellMenu");
  const it = S.items.find((i) => i.stem === stem);
  const c = (it.cells || {})[ag] || {};
  const stems = S.sel.has(stem) && S.sel.size > 1 ? [...S.sel] : [stem];
  m.innerHTML = `<div class="ctx-h">${esc(agName(ag))}${stems.length > 1 ? " · " + esc(t("n_photos", { n: stems.length })) : ""}</div>` +
    (c.bad ? `<div class="ctx-bad small">${c.bad.map((r) => "⚠ " + esc(reasonText(r))).join("<br>")}</div>` : "") +
    (c.ext && !c.state ? `<div class="ctx-ext small">${esc(t("ext_tip", { s: t("exs_" + (c.ext.status || "other")), d: c.ext.seen || "?" }))}</div>` : "") +
    STATES.map((s) => `<button data-st="${s}" class="${c.state === s ? "on" : ""}">${esc(t("mark_" + s))}</button>`).join("") +
    `<button data-st="">${esc(t("mark_clear"))}</button>` +
    /* RF ar ED rezervi (6a): bildei ar ED piebildi šai aģentūrai sūtīt ED kopiju (piem. pēc RF noraidījuma) */
    (it.edp && (it.cat || "RF") === "RF" && ((Core.settings || {}).sub_ed_agencies || []).includes(ag)
      ? `<button data-ed="${c.as === "ED" ? "0" : "1"}" class="${c.as === "ED" ? "on" : c.state === "rejected" ? "hint" : ""}">${esc(t(c.as === "ED" ? "as_rf" : "as_ed"))}</button>` : "");
  const r = td.getBoundingClientRect();
  m.style.left = Math.min(r.left, innerWidth - 230) + "px";
  m.style.top = Math.min(r.bottom + 2, innerHeight - 260) + "px";
  m.classList.remove("hidden");
  m.onclick = async (e) => {
    const be = e.target.closest("button[data-ed]");
    if (be) {
      m.classList.add("hidden");
      const on = be.dataset.ed === "1";
      if (on && !(await uiConfirm(t("as_ed_q", { n: stems.length, a: agName(ag) }), t("as_ed")))) return;
      try { await api("as_ed", { stems, agency: ag, on }); toast(t(on ? "as_ed_done" : "as_rf_done", { n: stems.length, a: agName(ag) }), "ok", 4000); await load(); }
      catch (err) { toast(err.message, "err"); }
      return;
    }
    const b = e.target.closest("button[data-st]"); if (!b) return;
    m.classList.add("hidden");
    await mark(stems, ag, b.dataset.st);
  };
}
document.addEventListener("click", (e) => { if (!e.target.closest("#cellMenu") && !e.target.closest("td.cell")) $("#cellMenu").classList.add("hidden"); });

async function mark(stems, ag, st, set) {
  let reason = "";
  if (st === "rejected") {
    reason = await askText(t("reason_q"));
    if (reason === null) return;
  }
  try {
    await api("mark", { stems, agency: ag, state: st, reason, set: set || "" });
    toast(t("marked", { n: stems.length, a: agName(ag), s: t(st ? "st_" + st : "st_") }), "ok", 2500);
    await load();
  } catch (e) { toast(e.message, "err"); }
}
/* iesniegšanas dienas izvēle (tuvākā brīvā plāna diena pēc noklusējuma) */
async function freeDay() {
  try { return ((await api("plan", { do: "free" })).free || [])[0] || ""; } catch (e) { return ""; }
}
async function fillDay(sel) {
  const el = $(sel); if (!el) return;
  el.min = new Date().toLocaleDateString("sv");
  if (!el.value || el.value < el.min) el.value = await freeDay();
}
function askDate(msg) {
  return new Promise(async (res) => {
    const m = $("#reasonModal"), inp = $("#reasonIn");
    $("#reasonQ").textContent = msg; inp.type = "date"; inp.min = new Date().toLocaleDateString("sv"); inp.value = await freeDay();
    m.classList.remove("hidden"); setTimeout(() => inp.focus(), 30);
    const done = (v) => { m.classList.add("hidden"); inp.type = "text"; inp.removeAttribute("min"); $("#reasonOk").onclick = $("#reasonNo").onclick = inp.onkeydown = null; res(v); };
    $("#reasonOk").onclick = () => done(inp.value);
    $("#reasonNo").onclick = () => done(null);
    inp.onkeydown = (e) => { if (e.key === "Enter") done(inp.value); if (e.key === "Escape") done(null); };
  });
}
function dayErr(err) {
  const k = "pl_e_" + err.message, f = err.data && err.data.free;
  toast(t(k) !== k ? t(k, { d: f ? fmtDay(f) : "" }) : err.message, "err", 8000);
}
function askText(msg) {
  return new Promise((res) => {
    const m = $("#reasonModal"), inp = $("#reasonIn");
    $("#reasonQ").textContent = msg; inp.value = ""; m.classList.remove("hidden");
    setTimeout(() => inp.focus(), 30);
    const done = (v) => { m.classList.add("hidden"); $("#reasonOk").onclick = $("#reasonNo").onclick = inp.onkeydown = null; res(v); };
    $("#reasonOk").onclick = () => done(inp.value.trim());
    $("#reasonNo").onclick = () => done(null);
    inp.onkeydown = (e) => { if (e.key === "Enter") done(inp.value.trim()); if (e.key === "Escape") done(null); };
  });
}

/* ---------- atlasīto josla ---------- */
function selBar() {
  const n = S.sel.size;
  $("#selBar").classList.toggle("hidden", !n);
  $("#selN").textContent = t("n_selected", { n });
}
$("#selBar").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-st]"); if (!b) return;
  mark([...S.sel], $("#selAgency").value, b.dataset.st);
});
$("#selClear").addEventListener("click", () => { S.sel.clear(); render(); });
// izdzēst no NAS (2026-11-11): bilde + RAW/xmp → _Izdzestas/<datums> (30 dienas), manifestā "deleted", sīktēls ārā
$("#selDel").addEventListener("click", async () => {
  const its = S.items.filter((i) => S.sel.has(i.stem));
  if (!its.length) return;
  if (its.some((i) => i.remote)) { toast(t("nasdel_remote"), "err"); return; }
  const inSet = its.filter((i) => (S.sets || []).some((x) => (x.stems || []).includes(i.stem))).length;
  const names = its.slice(0, 8).map((i) => "• " + i.file).join("\n") + (its.length > 8 ? "\n…" : "");
  if (!(await uiConfirm(t("nasdel_q", { n: its.length }) + "\n\n" + names + (inSet ? "\n\n" + t("nasdel_sets", { n: inSet }) : ""), t("nasdel")))) return;
  try {
    const r = await api("nas_delete", { stems: its.map((i) => i.stem) });
    if (!r.ok) { toast(t("nasdel_err_" + r.error) || r.error, "err"); return; }
    toast(t("nasdel_done", { n: r.done }) + (r.nerr ? " · " + t("nasdel_fail", { n: r.nerr }) + ": " + (r.errors || []).join("; ") : ""), r.nerr ? "err" : "");
    S.sel.clear();
    await load();
  } catch (e) { toast(e.message, "err"); }
});

/* ---------- mape ---------- */
async function pickDir() {
  try {
    const r = await api("pick_folder", { start: (Core.settings || {}).sub_ready_dir || "" });
    if (!r.path) return;
    await api("set_dir", { path: r.path });
    Core.settings.sub_ready_dir = r.path;
    await load();
  } catch (e) { if (!/pick_busy/.test(e.message)) toast(e.message, "err"); }
}
$("#pickDir").addEventListener("click", pickDir);
$("#changeDir").addEventListener("click", pickDir);
$("#openDir").addEventListener("click", () => api("open", { path: (Core.settings || {}).sub_ready_dir || "" }).catch((e) => toast(e.message, "err")));
$("#reloadBtn").addEventListener("click", () => reloadView());

/* ---------- komplekti ---------- */
const thumbUrl = (it) => `/thumb?t=${encodeURIComponent(window.TOKEN)}&s=${encodeURIComponent(it.series)}&n=${encodeURIComponent(it.stem)}`;
/* tēmas (vieta + sērija) — izvēlētās jauc vienā komplektā ar vienādu kvotu (stock.suggest topics) */
S.topics = new Set();
async function loadThemes() {
  let d; try { d = await api("themes", { cat: $("#nsCat").value }); } catch (_) { return; }
  const box = $("#nsThemes");
  const lst = (d.themes || []).slice(0, 40);
  S.topics.forEach((x) => { if (!lst.some((t0) => t0.title === x)) S.topics.delete(x); });
  box.innerHTML = lst.length ? `<span class="muted small">${esc(t("ns_themes"))}</span> ` + lst.map((x) => `<button class="chip ${S.topics.has(x.title) ? "on" : ""}" data-t="${esc(x.title)}" title="${esc(x.name)}">${esc(x.title)} <span class="muted">${x.n}</span></button>`).join("") : "";
}
$("#nsThemes").addEventListener("click", (e) => {
  const b = e.target.closest(".chip"); if (!b) return;
  if (S.topics.has(b.dataset.t)) S.topics.delete(b.dataset.t); else S.topics.add(b.dataset.t);
  b.classList.toggle("on");
});
$("#nsCat").addEventListener("change", () => { S.topics.clear(); loadThemes(); });
async function suggest(more = false, keep = false) {
  const cat = $("#nsCat").value, size = +$("#nsSize").value || 0, match = (S.ns && S.ns.match) || "";
  const topics = S.ns && S.ns.topics ? S.ns.topics : [...S.topics];
  const have = more && S.ns ? S.ns.items : [];
  let d;
  const removed = (more || keep) && S.ns ? S.ns.removed : [];
  try { d = await api("set_suggest", { cat, size: more ? Math.max(1, (size || S.ns.size) - have.length) || 10 : size, exclude: removed, have: have.map((i) => i.stem), match, topics }); }
  catch (e) { return toast(e.message, "err"); }
  const items = more ? have.concat(d.items.filter((i) => !have.some((h) => h.stem === i.stem))) : d.items;
  const groups = Object.assign({}, more && S.ns ? S.ns.groups : {}, d.groups || {});
  S.ns = { cat, items, size: d.size, removed, match, groups, topics, reply: more || keep ? (S.ns || {}).reply : "" };
  $("#nsSize").placeholder = t("ns_auto", { n: d.auto });
  $("#nsInfo").textContent = d.todo ? t("ns_info", { todo: d.todo, n: items.length, sim: d.similar }) + topicNote(d) : t("ns_none");
  paintNs();
}
function topicNote(d) {
  const tc = d.topic_counts || {}; const k = Object.keys(tc);
  return k.length ? " · " + k.map((x) => `${x}: ${tc[x]}`).join(", ") : "";
}
function paintNs() {
  const ns = S.ns;
  $("#nsBox").classList.toggle("hidden", !ns || !ns.items.length);
  if (!ns) return;
  $("#nsReply").classList.toggle("hidden", !ns.reply);
  $("#nsReply").textContent = ns.reply || "";
  $("#nsGrid").innerHTML = ns.items.map((it) => `<div class="ns-it" data-stem="${esc(it.stem)}" title="${esc(it.file + (it.title ? "\n" + it.title : "") + (it.hint ? "\n📍 " + it.hint : "") + (it.why ? "\n✎ " + it.why : ""))}">
    ${it.thumb ? `<img loading="lazy" src="${thumbUrl(it)}" alt="">` : `<div class="ns-noimg"></div>`}
    <div class="small ns-fn">${esc(it.why || it.hint || it.file)}</div><button class="ns-x" data-i18n-title="ns_remove" title="${esc(t("ns_remove"))}">×</button>
    <button class="ns-r" title="${esc(t("ns_replace"))}">↻</button>
    ${(ns.groups || {})[it.stem] ? `<span class="ns-sim" title="${esc(t("ns_sim_tip", { n: ns.groups[it.stem].length }))}">≈${ns.groups[it.stem].length}</span>` : ""}</div>`).join("");
  /* līdzīgās — atliktas uz nākamajiem komplektiem; "Nav līdzīgas" — lietotāja izņēmums (similar.py, notsimilar.json) */
  const gs = Object.entries(ns.groups || {}).filter(([k]) => ns.items.some((i) => i.stem === k));
  const box = $("#nsSim");
  box.classList.toggle("hidden", !gs.length);
  box.innerHTML = gs.length ? `<div class="small muted">${esc(t("ns_sim_h"))}</div>` + gs.map(([k, arr]) => {
    const keep = ns.items.find((i) => i.stem === k);
    const th = (it, cls) => `<div class="ns-it ${cls}" title="${esc(it.file)}">${it.thumb ? `<img loading="lazy" src="${thumbUrl(it)}" alt="">` : `<div class="ns-noimg"></div>`}<div class="small ns-fn">${esc(it.file)}</div></div>`;
    return `<div class="ns-grp" data-k="${esc(k)}">${th(keep, "keep")}<span class="ns-eq">≈</span>${arr.map((a) => th(a, "later")).join("")}
      <button class="small ns-notsim" title="${esc(t("ns_notsim_d"))}">${esc(t("ns_notsim"))}</button></div>`;
  }).join("") : "";
}
/* ↻ aizstāt: ja komplektu sastādīja AI redaktors — AI izvēlas vienu aizstājēju (ar "kāpēc"), citādi pēc noteikumiem */
async function replaceOne(stem) {
  const ns = S.ns; if (!ns) return;
  if (!ns.ai) return suggest(true);
  const busy = document.querySelector(`.ns-it[data-stem="${CSS.escape(stem)}"]`);
  Core.setStatus("repl", { text: t("asst_busy"), cls: "run" });
  try {
    const d = await api("ask_replace", { text: ns.text || "", cat: ns.cat, match: ns.match || "", topics: ns.topics || [], have: ns.items.map((i) => i.stem), exclude: ns.removed });
    const it = (d.items || [])[0];
    if (it && !ns.items.some((i) => i.stem === it.stem)) ns.items.push(it);
    else toast(t("ns_none"), "err", 4000);
    paintNs();
  } catch (e) { toast(e.message, "err"); }
  finally { Core.setStatus("repl", null); if (busy) busy.remove(); }
}
$("#nsSim").addEventListener("click", async (e) => {
  const b = e.target.closest(".ns-notsim"); if (!b) return;
  const k = b.closest(".ns-grp").dataset.k, arr = (S.ns.groups || {})[k] || [];
  try {
    await api("not_similar", { stems: [k, ...arr.map((a) => a.stem)] });
    delete S.ns.groups[k];
    toast(t("ns_notsim_done"), "ok", 3000);
    suggest(false, true);
  } catch (err) { toast(err.message, "err"); }
});
$("#nsGo").addEventListener("click", () => { S.ns = null; suggest(false); });
$("#nsMore").addEventListener("click", () => suggest(true));
$("#nsCancel").addEventListener("click", () => { S.ns = null; paintNs(); $("#nsInfo").textContent = ""; });
$("#nsGrid").addEventListener("click", (e) => {
  const x = e.target.closest(".ns-x, .ns-r"); if (!x) return;
  const stem = x.closest(".ns-it").dataset.stem;
  S.ns.items = S.ns.items.filter((i) => i.stem !== stem); S.ns.removed.push(stem); paintNs();
  if (x.classList.contains("ns-r")) replaceOne(stem);
});
$("#nsSave").addEventListener("click", async () => {
  if (!S.ns || !S.ns.items.length) return;
  try {
    const r = await api("set_save", { name: $("#nsName").value.trim(), cat: S.ns.cat, stems: S.ns.items.map((i) => i.stem), date: $("#nsDate").value, now: $("#nsNow").checked });
    toast(t("ns_saved", { n: r.set.name, c: S.ns.items.length }) + (r.set.planned ? " " + t("ns_saved_day", { d: fmtDay(r.set.planned) }) : "") + (r.set.want_move ? " " + t("ns_saved_now") : ""), "ok", 6000);
    S.ns = null; $("#nsName").value = ""; $("#nsDate").value = ""; $("#nsInfo").textContent = ""; paintNs(); fillDay("#nsDate");
    await load(); loadSets();
  } catch (e) { dayErr(e); }
});
/* "Visām aģentūrām (FTP)" — pēc kārtas, nākamā sākas tikai pēc iepriekšējās (ftp.upload_all, viens pavediens) */
async function ftpAll(x) {
  let p;
  try { p = await api("ftp_all", { id: x.id, check: true }); } catch (err) { toast(err.message, "err"); return; }
  const skip = (p.skip || []).map((z) => `${agName(z.agency)} — ${t("ftp_skip_" + z.why)}`);
  if (!(p.go || []).length) { toast(t("ftp_all_none") + (skip.length ? "\n• " + skip.join("\n• ") : "") + "\n" + t("ftp_all_hint"), "err sticky", 12000); return; }
  const lines = p.go.map((g, i) => `${i + 1}. ${agName(g.agency)}: ${t("n_photos", { n: g.n })}${limitNote(g.agency, g.n)}`);
  if (!(await uiConfirm(t("ftp_all_q", { s: x.name }) + "\n\n" + lines.join("\n") + (skip.length ? "\n\n" + t("ftp_all_skip") + "\n• " + skip.join("\n• ") : ""), t("set_ftp")))) return;
  try { await api("ftp_all", { id: x.id }); S.ftpShown = false; ftpPoll(); }
  catch (err) { const k = "ftp_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err", 8000); }
}

/* FTP augšupielādes progress (ftp.py — fonā; programma neaizveras, kamēr notiek) */
let ftpTimer = null;
async function ftpPoll() {
  clearTimeout(ftpTimer);
  let j;
  let d;
  try { d = await api("ftp_status"); j = d.job || {}; } catch (_) { ftpTimer = setTimeout(ftpPoll, 15000); return; }
  if (j.running) {
    S.ftpShown = false;
    const pre = (j.auto ? t("ftp_auto_pre") + " " : "") + (j.all ? `(${j.step}/${j.steps}) ` : "");
    const wait = j.wait_until ? Math.max(0, Math.round((j.wait_until * 1000 - Date.now()) / 60000)) : 0;
    const txt = j.wait_until ? t("ftp_wait", { a: agName(j.next || ""), m: wait }) : t("ftp_prog", { a: agName(j.agency), d: j.done, n: j.total, f: j.current || "" });
    Core.setStatus("ftp", { text: pre + txt, cls: "run spin" });
    ftpTimer = setTimeout(ftpPoll, j.wait_until ? 5000 : 1000);
    return;
  }
  const rr = (d.runs || [])[0];          /* pults: sūta dežūras dators */
  Core.setStatus("ftp", rr ? { text: t("ftp_remote", { c: rr.pc || "", s: rr.name, k: rr.step, n: rr.steps }) + " " +
    (rr.wait_until && rr.wait_until * 1000 > Date.now() ? t("ftp_wait", { a: "", m: Math.round((rr.wait_until * 1000 - Date.now()) / 60000) }) : t("ftp_prog", { a: agName(rr.agency), d: rr.done, n: rr.total, f: "" })), cls: "run spin" } : null);
  ftpTimer = setTimeout(ftpPoll, 15000);  /* arī tad, ja darbu sāk automātika (test25) */
  if (j.finished && !S.ftpShown) {
    S.ftpShown = true;
    if (j.all) {
      const res = j.results || [], bad = res.some((x) => x.nerr || x.done < x.total);
      toast(t("ftp_all_done") + "\n" + res.map((x) => `${x.nerr || x.done < x.total ? "⚠" : "✓"} ${agName(x.agency)}: ${x.done}/${x.total}${x.error ? " — " + x.error : ""}`).join("\n") + "\n" + t("ftp_all_submit"), bad ? "err sticky" : "ok sticky", 30000);
      await load(); if (S.page === "sets") loadSets(); if (S.page === "plan" && window.planLoad) planLoad();
      return;
    }
    const ok = j.done || 0;
    toast(t("ftp_done", { d: ok, n: j.total, a: agName(j.agency) }) + (j.nerr ? " " + t("ftp_errs", { e: j.nerr, m: (j.errors || [])[0] || "" }) : ""), j.nerr ? "err sticky" : "ok sticky", 20000);
    if (ok && j.url) api("open_url", { url: j.url }).catch(() => {});
    await load(); if (S.page === "sets") loadSets();
  }
}

/* komplekta pārvietošana uz komplektu mapi (move.py — fonā) */
let moveTimer = null;
async function movePoll() {
  clearTimeout(moveTimer);
  let j;
  try { j = (await api("move_status")).job || {}; } catch (_) { return; }
  if (j.running) {
    Core.setStatus("move", { text: t("move_prog2", { s: j.name || "", d: j.done, n: j.total, f: j.current || "" }), cls: "run spin" });
    moveTimer = setTimeout(movePoll, 1000);
    return;
  }
  Core.setStatus("move", null);
  if (j.finished && !S.moveShown) {
    S.moveShown = true;
    toast(t(j.sets > 1 ? "move_done_n" : "move_done", { d: j.done || 0, n: j.total, p: j.dir || "", k: j.sets || 1 }) + (j.nerr ? " " + t("ftp_errs", { e: j.nerr, m: (j.errors || [])[0] || "" }) : ""), j.nerr ? "err sticky" : "ok sticky", 20000);
    await load(); if (S.page === "sets") loadSets(); if (S.page === "plan" && window.planLoad) planLoad();
  }
}

/* kāpēc ne visas komplekta bildes (2026-11-04: "10 komplektā, FTP sūta 7"): neder ar iemesliem, jau atzīmētas, nav atrastas */
function skipNote(x, ag, okStates) {
  const bad = [], done = [], miss = [];
  for (const st of x.stems) {
    const it = S.items.find((i) => i.stem === st);
    if (!it) { miss.push(st); continue; }
    const c = (it.cells || {})[ag] || {};
    if (okStates.includes(c.state || "") && !c.bad) continue;
    if (c.bad && !c.state) bad.push(`${it.file}: ${c.bad.map(reasonText).join("; ")}`);
    else done.push(it.file);
  }
  const out = [];
  if (bad.length) out.push(t("skip_bad", { k: bad.length, a: agName(ag) }) + "\n• " + bad.slice(0, 8).join("\n• ") + (bad.length > 8 ? "\n…" : ""));
  if (done.length) out.push(t("skip_done", { k: done.length }));
  if (miss.length) out.push(t("skip_miss", { k: miss.length }));
  return out.length ? "\n\n" + out.join("\n") : "";
}

/* aģentūras iesniegšanas limits (docs/tirgotajs-iesniegsana.md): Shutterstock 500 / 7 dienās, Magnific 200 / mēnesī */
function recentCount(ag, days) {
  const from = Date.now() - days * 864e5;
  return S.items.filter((it) => { const c = (it.cells || {})[ag] || {}; return c.state && c.state !== "skip" && c.at && Date.parse(c.at) >= from; }).length;
}
function limitNote(ag, add) {
  const a = S.agencies.find((x) => x.id === ag); if (!a || !a.limit) return "";
  const [n, days] = a.limit, have = recentCount(ag, days);
  return have + add > n ? " ⚠ " + t("limit_over", { a: a.name, n, d: days, have, add }) : "";
}
/* ---------- AI asistents (assistant.py): AI izvēlas darbību, bildes atlasa Tirgotājs, lietotājs saglabā ---------- */
const PROV = { claude_sub: "Claude", chatgpt_sub: "ChatGPT", claude_api: "Claude API", openai_api: "OpenAI API", local: "" };
async function ask() {
  const text = $("#asIn").value.trim(); if (!text) return;
  const out = $("#asOut"), btn = $("#asGo");
  btn.disabled = true; out.classList.remove("hidden"); out.textContent = t("asst_busy");
  let d;
  try { d = await api("ask", { text }); } catch (e) { out.textContent = e.message; btn.disabled = false; return; }
  btn.disabled = false;
  const who = PROV[d.by] ? t("asst_by", { p: PROV[d.by] }) : t("asst_local");
  let msg = d.reply || "";
  if (d.action === "make_set") {
    const r = d.set || {};
    $("#nsCat").value = d.cat || "RF";
    S.ns = { cat: d.cat || "RF", items: r.items || [], size: r.size, removed: [], match: d.match || "", topics: d.topics || [], groups: r.groups || {}, reply: r.ai_reply || "", ai: !!r.ai, text };
    $("#nsSize").placeholder = t("ns_auto", { n: r.auto || 0 });
    $("#nsInfo").textContent = r.todo ? t("ns_info", { todo: r.todo, n: (r.items || []).length, sim: r.similar || 0 }) + topicNote(r) + (r.ai ? " · " + t(r.sheet ? "asst_ai_pick_img" : "asst_ai_pick") : "") : t("ns_none");
    if (!$("#nsName").value && d.match) $("#nsName").value = d.match.replace(/(^|\s)\S/g, (c) => c.toUpperCase()).trim();
    paintNs();
    msg = msg || ((r.items || []).length ? t("asst_set", { n: r.items.length, m: d.match || "—", c: d.cat || "RF" }) : t("ns_none"));
    if ((r.items || []).length) msg += " " + t("asst_review");
  } else if (d.action === "show") {
    showPage("stock");
    $("#fText").value = d.match || ""; $("#fAgency").value = d.agency || ""; $("#fShow").value = d.show || ""; S.shown = 300; render();
    msg = msg || t("asst_shown", { n: filtered().length });
  }
  out.innerHTML = `<div>${esc(msg)}</div><div class="muted small">${esc(who)}${d.errors && d.errors.length && !PROV[d.by] ? " · " + esc(t("asst_noai")) : ""}</div>`;
}
$("#asGo").addEventListener("click", ask);
$("#asIn").addEventListener("keydown", (e) => { if (e.key === "Enter") ask(); });

/* "Saglabātie komplekti" — variants A (lietotājs 2026-11-10 13:26–13:30): filtri, grupas pa dienām, krāsaina svītra,
   stāvokļa uzraksts, darbības ⋯ izvēlnē un ar labo klikšķi; KUR — tikai ikona (6f); punktiņš — labais klikšķis (6j) */
const SL = { d: null, f: "todo" };
const SVG_CLOUD = `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="#3a86d4" d="M19.4 10.1A7 7 0 0 0 6.1 8.3 5.5 5.5 0 0 0 6.5 19.3h12.4a4.6 4.6 0 0 0 .5-9.2z"/></svg>`;
const SVG_DISK = `<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><rect x="3" y="4" width="18" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><rect x="3" y="13" width="18" height="7" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.8"/><circle cx="7" cy="7.5" r="1.1" fill="currentColor"/><circle cx="7" cy="16.5" r="1.1" fill="currentColor"/></svg>`;
function slOverall(x) { return window.plOverall ? plOverall(x.status) : "none"; }
function slLabel(x) {
  /* lietotājs 2026-11-11 14:08: "Nosūtīts uz 11 no 13 aģentūrām", kamēr kāda nosūtītā nav zaļa; tad "Iesniegts …" */
  const v = Object.values(x.status || {}).filter((z) => z.st !== "bad"), n = v.length;
  const sent = v.filter((z) => ["up", "part", "done"].includes(z.st)).length, green = v.filter((z) => z.st === "done").length;
  const p = x.plan || {};
  if (n && green === n) return { k: "done", txt: t("sl_done_all") };
  if (sent && green === sent) return { k: "done", txt: t("sl_sub_n", { k: green, n }) };
  if (sent) return { k: green ? "part" : "up", txt: t("sl_sent_n", { k: sent, n }) };
  if (p.stage === "draft") return { k: "draft", txt: t("pl_stg_draft") };
  if (p.stage === "blocked") return { k: "blocked", txt: "⚠ " + t("pl_stg_blocked") };
  if (p.stage === "nas" && p.nas_wait && !p.move_err) return { k: "nas", txt: "⏳ " + t("pl_stg_naswait", { n: p.nas_wait.n, t: p.nas_wait.total }) };
  if (p.stage === "nas") return { k: "nas", txt: "⚠ " + (p.move_at ? t("pl_stg_nas", { d: fmtDay(p.move_at.slice(0, 10)), t: p.move_at.slice(11, 16) }) : t("pl_stg_nas_now")) };
  if (x.ready) return { k: "ready", txt: t("pl_stg_ready") };
  return { k: "free", txt: t("sl_noplan") };
}
function slWhere(x) {
  const left = x.count - x.missing - x.moved;
  if (x.moved && !left) return `<span class="sl-where" title="${esc(t("where_stock", { p: x.dir }))}">${SVG_CLOUD}</span>`;
  const it = S.items.find((i) => (x.stems || []).includes(i.stem) && i.path);
  const p = it ? it.folder : "";
  return `<span class="sl-where muted" title="${esc(x.moved ? t("set_moved_part", { m: x.moved, n: x.count }) + "\n" : "") + esc(t("where_nas", { p: p || (x.remote ? t("nas_tip") : "—") }))}">${SVG_DISK}</span>`;
}
async function loadSets() {
  let d;
  try { d = await api("sets"); } catch (e) { return toast(e.message, "err"); }
  SL.d = d;
  slPaint();
}
function slPaint() {
  const d = SL.d; if (!d) return;
  const ags = d.agencies || [], box = $("#setsList");
  if (!d.sets.length) { box.innerHTML = `<div class="muted">${esc(t("sets_none"))}</div>`; return; }
  const dd = (iso) => iso ? new Date(iso).toLocaleDateString(window.langLocale(), { day: "2-digit", month: "2-digit" }) : "";
  const agCell = (a, z, x) => {
    if (!z) return "<td></td>";
    const head = z.st === "done" ? t("ag_done", { d: dd(z.date) }) : z.st === "part" ? t("ag_part", { s: z.sub, n: z.n })
      : z.st === "up" ? t("ag_up", { u: z.up, n: z.n }) : z.st === "bad" ? t(z.skip ? "ag_skip" : "ag_bad_l") : z.st === "plan" ? t("ag_plan_l") : t("ag_none_l");
    const tip = a.name + " — " + head + "\n" + t("ag_tip", { a: a.name, s: z.sub, n: z.n, acc: z.acc, rej: z.rej, w: z.wait, up: z.up, b: z.bad }) + "\n" + t("sl_dot_tip");
    return `<td class="dotc" data-ag="${a.id}" title="${esc(tip)}"><span class="sdot ${z.st}${z.rej ? " rej" : ""}${z.skip ? " skip" : ""}"></span></td>`;
  };
  const cnt = { todo: 0, done: 0, all: d.sets.length, noday: 0 };
  d.sets.forEach((x) => { const ov = slOverall(x); if (ov === "done") cnt.done++; else cnt.todo++; if (!x.day) cnt.noday++; });
  const keep = (x) => SL.f === "all" ? true : SL.f === "done" ? slOverall(x) === "done" : SL.f === "noday" ? !x.day : slOverall(x) !== "done";
  const list = d.sets.filter(keep);
  const groups = new Map();
  list.sort((p, q) => (p.day || "9999") < (q.day || "9999") ? -1 : (p.day || "9999") > (q.day || "9999") ? 1 : (p.name < q.name ? -1 : 1));
  if (SL.f === "done") list.reverse();
  list.forEach((x) => { const k = x.day || ""; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(x); });
  const chips = ["todo", "done", "all", "noday"].map((k) => `<button class="chip small sl-f${SL.f === k ? " on" : ""}" data-f="${k}">${esc(t("sl_f_" + k))} <span class="muted">${cnt[k]}</span></button>`).join("");
  const cols = 6 + ags.length;
  let body = "";
  for (const [day, xs] of groups) {
    const isT = day === d.today;
    const dl = day ? new Date(day + "T12:00").toLocaleDateString(window.langLocale(), { weekday: "long", day: "numeric", month: "long" }) : "";
    const head = day ? (isT ? t("pl_today") + " · " : "") + dl.charAt(0).toUpperCase() + dl.slice(1) : t("sl_noday");
    body += `<tr class="sl-grp${isT ? " today" : ""}${day && day < d.today ? " past" : ""}"><td colspan="${cols}"><div class="sl-gh"><b>${esc(head)}</b></div></td></tr>`;
    body += xs.map((x) => {
      const ov = slOverall(x), lb = slLabel(x);
      const sub = x.rel ? "STOCK › " + x.rel : x.remote ? t("nas_tip") : "";
      return `<tr data-id="${esc(x.id)}" class="sl-row ov-${ov}${ov === "done" ? " dim" : ""}"><td class="sl-name"><span class="sl-stripe ${ov}"></span><div><b>${esc(x.name)}</b>
        ${x.missing ? ` <span class="small warn">${esc(t("set_missing", { k: x.missing }))}</span>` : ""}<div class="muted small sl-sub" title="${esc(x.dir || "")}">${esc(sub)}</div></div></td>
        <td>${slWhere(x)}</td><td><span class="cat cat-${esc(x.cat)}">${esc(x.cat)}</span></td><td>${x.count}</td>` +
        ags.map((a) => agCell(a, (x.status || {})[a.id], x)).join("") +
        `<td class="sl-st"><span class="sl-lab stg-${lb.k}">${esc(lb.txt)}</span></td><td class="sl-m"><button class="small ghost sl-more" title="${esc(t("sl_more"))}">⋯</button></td></tr>`;
    }).join("");
  }
  box.innerHTML = `<div class="sl-chips">${chips}</div>` + (list.length ? `<table class="t sets sl"><thead><tr><th>${esc(t("set_name"))}</th><th>${esc(t("set_where"))}</th><th>${esc(t("f_cat"))}</th><th>${esc(t("set_n"))}</th>` +
    ags.map((a) => `<th class="agh" data-ag="${a.id}" title="${esc(a.name)}">${esc(a.name.replace(/ \/.*/, ""))}</th>`).join("") + `<th></th><th></th></tr></thead><tbody>${body}</tbody></table>` : `<div class="muted">${esc(t("sl_empty"))}</div>`) +
    `<div class="sdot-legend muted small">${(window.PL_KEYS || ["done", "part", "up", "none", "bad"]).map((k) => `<span><span class="sdot ${k}"></span> ${esc(t("ag_leg_" + k))}</span>`).join("")}<span><span class="sdot done rej"></span> ${esc(t("ag_leg_rej"))}</span></div>`;
}
const slFind = (id) => ((SL.d || {}).sets || []).find((s) => s.id === id);
$("#setsList").addEventListener("click", async (e) => {
  const f = e.target.closest(".sl-f"); if (f) { SL.f = f.dataset.f; slPaint(); return; }
  const tr = e.target.closest("tr[data-id]"); if (!tr) return;
  const x = slFind(tr.dataset.id); if (!x) return;
  if (e.target.closest(".sl-where") && x.rel) return setAct("open", x);
  if (e.target.closest(".sl-more")) { e.stopPropagation(); const r = e.target.getBoundingClientRect(); return slMenu(x, r.left, r.bottom + 2); }
  if (e.target.closest(".sl-name b")) return setAct("show", x);
});
$("#setsList").addEventListener("contextmenu", (e) => {
  const tr = e.target.closest("tr[data-id]"); if (!tr) return;
  const x = slFind(tr.dataset.id); if (!x) return;
  e.preventDefault();
  const dot = e.target.closest("td.dotc[data-ag]");
  if (dot) return slDotMenu(x, dot.dataset.ag, e.clientX, e.clientY);
  slMenu(x, e.clientX, e.clientY);
});
/* komplekta darbības izvēlnē (agrākās pogas rindā zem komplekta) */
function slMenu(x, px, py) {
  const ags = S.agencies, canMove = x.count - x.missing - x.moved > 0, done = slOverall(x) === "done";
  plCtx(px, py, `<div class="ctx-h small">${esc(x.name)}</div>
    <button data-a="show">👁 ${esc(t("set_show"))}</button>
    ${window.pickOpenSet ? `<button data-a="edit">✎ ${esc(t("ctx_open_set"))}</button>` : ""}
    ${x.rel ? `<button data-a="open">📁 ${esc(t("ctx_open_dir"))}</button>` : ""}
    ${canMove && !done ? `<button data-a="move">☁ ${esc(t("pl_move_now"))}</button>` : ""}
    ${!done ? `<button data-a="ftp">⇡ ${esc(t("ag_all_ftp"))}</button>` : ""}
    <div class="ctx-sub small muted">${esc(t("sl_one_ag"))}</div>
    <div class="row sl-agrow"><select class="sl-ag">${ags.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select>
      <button data-a="ftp1" class="small">${esc(t("set_ftp"))}</button></div>
    ${!x.plan || !x.plan.date ? `<button data-a="day">📅 ${esc(t("sl_to_plan"))}</button>` : ""}
    <button data-a="del" class="danger-t">× ${esc(t("set_del"))}</button>`);
  $("#plCtx").dataset.set = x.id;
}
function slDotMenu(x, ag, px, py) {
  const z = (x.status || {})[ag] || {};
  const opt = [["uploaded", "up", "sl_m_up"], ["part", "part", "sl_m_part"], ["submitted", "done", "sl_m_sub"], ["skip", "bad skip", "sl_m_skip"]];
  plCtx(px, py, `<div class="ctx-h small">${esc(x.name)} · ${esc(agName(ag))}</div>` +
    opt.map(([v, k, l]) => `<button data-a="mark" data-st="${v}" class="${(v === "skip" ? z.skip : z.st === k && !z.skip) ? "on" : ""}"><span class="sdot ${k}"></span> ${esc(t(l))}</button>`).join("") +
    `<button data-a="mark" data-st="">↺ ${esc(t("sl_m_clear"))}</button>`);
  $("#plCtx").dataset.set = x.id; $("#plCtx").dataset.ag = ag;
}
$("#plCtx").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-a]"); if (!b || !$("#plCtx").dataset.set || S.page !== "sets") return;
  if (b.closest(".sl-agrow") && !b.dataset.a) return;
  const x = slFind($("#plCtx").dataset.set); if (!x) return;
  const a = b.dataset.a, ag1 = ($(".sl-ag", $("#plCtx")) || {}).value;
  e.stopImmediatePropagation();
  $("#plCtx").classList.add("hidden");
  if (a === "mark") {
    try { const r = await api("set_mark", { id: x.id, agency: $("#plCtx").dataset.ag, state: b.dataset.st }); toast(b.dataset.st === "part" ? t("sl_marked_part", { a: agName($("#plCtx").dataset.ag) }) : b.dataset.st === "skip" ? t("sl_marked_skip", { n: r.n, a: agName($("#plCtx").dataset.ag) }) : t("sl_marked", { n: r.n, a: agName($("#plCtx").dataset.ag) }), "ok", 2500); await load(); loadSets(); }
    catch (err) { toast(err.message, "err"); }
    return;
  }
  if (a === "edit") return pickOpenSet(x.id);
  if (a === "ftp") return setAct("ftp", x, "*");
  if (a === "ftp1") return setAct("ftp", x, ag1);
  if (a === "sub1") return setAct("sub", x, ag1);
  if (a === "day") { const day = await askDate(t("set_day_q", { s: x.name })); if (day) { try { await api("plan", { do: "assign", id: x.id, date: day }); loadSets(); } catch (err) { dayErr(err); } } return; }
  return setAct(a, x, "");
}, true);

/* komplekta darbības — Komplekti un Plāns (plan.js) */
async function setAct(act, x, ag) {
  const done = async () => { await load(); if (S.page === "sets") loadSets(); if (S.page === "plan" && window.planLoad) planLoad(); };
  if (act === "show") { showPage("stock"); $("#fSet").value = x.id; S.shown = 300; render(); return; }
  if (act === "ftp" && ag === "*") return ftpAll(x);
  if (ag === "*" && (act === "sub" || act === "portal")) { toast(t("ag_pick_one"), "err", 5000); return; }
  if (act === "ftp") {
    const a = S.agencies.find((z) => z.id === ag) || {};
    if (a.mode !== "ftp") { toast(t("ftp_e_not_ftp", { a: agName(ag) }), "err", 7000); return; }
    const todo = x.stems.filter((st) => { const it = S.items.find((i) => i.stem === st); return it && cellState(it, ag) === ""; });
    if (!todo.length) { toast(t("set_sub_none", { a: agName(ag) }) + skipNote(x, ag, [""]), "err sticky", 12000); return; }
    if (!(await uiConfirm(t("set_ftp_q", { n: todo.length, s: x.name, a: agName(ag) }) + limitNote(ag, todo.length) + skipNote(x, ag, [""]), t("set_ftp")))) return;
    try { await api("ftp_upload", { id: x.id, agency: ag }); S.ftpShown = false; ftpPoll(); }
    catch (err) { const k = "ftp_e_" + err.message; toast(t(k) !== k ? t(k, { a: agName(ag) }) : err.message, "err", 8000); }
    return;
  }
  if (act === "open") { api("open", { path: x.dir }).catch((err) => toast(err.message, "err")); return; }
  if (act === "move") {
    const n = x.count - x.missing - x.moved;
    if (!x.planned) {                    /* uz OneDrive tikai plānotos — vispirms diena (lēmums 2026-11-05 22:04) */
      const day = await askDate(t("set_day_q", { s: x.name }));
      if (!day) return;
      try { await api("plan", { do: "assign", id: x.id, date: day }); x.planned = day; }
      catch (err) { const k = "pl_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err", 8000); return; }
    }
    if (!(await uiConfirm(t("set_move_q", { n, s: x.name }), t("set_move")))) return;
    if (x.remote) {                      /* pults (bildes NAS) — uzdevums dežūras datoram (2026-11-11) */
      try { await api("plan", { do: "want", id: x.id, what: "move" }); toast(t("pl_want_move"), "ok", 6000); await done(); } catch (err) { toast(err.message, "err"); }
      return;
    }
    try { const r = await api("set_move", { id: x.id }); S.moveShown = false; toast(t("move_start", { n: r.total, d: r.dir }), "ok", 6000); movePoll(); }
    catch (err) { const k = "move_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err sticky", 12000); }
    return;
  }
  if (act === "sub") {
    /* tikai bildes, kas šai aģentūrai der un vēl nav atzīmētas (neder / noraidītās / pieņemtās nepārraksta) */
    const todo = x.stems.filter((st) => { const it = S.items.find((i) => i.stem === st); return it && ["", "uploaded"].includes(cellState(it, ag)); });
    const skip = x.count - todo.length;
    if (!todo.length) { toast(t("set_sub_none", { a: agName(ag) }) + skipNote(x, ag, ["", "uploaded"]), "err sticky", 12000); return; }
    if (!(await uiConfirm(t("set_sub_q", { n: todo.length, s: x.name, a: agName(ag) }) + limitNote(ag, todo.length) + (skip ? skipNote(x, ag, ["", "uploaded"]) : ""), t("set_sub")))) return;
    await mark(todo, ag, "submitted", x.id); done(); return;
  }
  if (act === "del") {
    if ((x.rel || (x.plan && x.plan.date)) && window.plRemove) return plRemove({ id: x.id, name: x.name });
    if (!(await uiConfirm(t("set_del_q", { s: x.name }), t("set_del")))) return;
    try { await api("set_delete", { id: x.id }); await done(); } catch (err) { toast(err.message, "err"); }
  }
}

/* ---------- iestatījumi ---------- */
const settingsPage = Core.settingsFrame({
  root: "#page-settings",
  shared: ["agencies"],
  connections: { jobs: [["assistant", t("job_assistant")]] },          // "Pieslēgumi": OneDrive un Google konts (google.js — sinhronizācija starp datoriem)
  moduleHtml: `<section data-collapse="agconn"><h2 data-i18n="s_conn_ag"></h2><p class="muted small" data-i18n="s_conn_ag_d"></p><div id="sConn"></div></section>
    <section data-collapse="sub"><h2 data-i18n="s_app"></h2>
    <label><span data-i18n="ready_dir"></span>
      <div class="row"><input id="sDir" spellcheck="false" style="flex:1"><button id="sDirPick" data-i18n="pick_dir"></button></div></label>
    <p class="muted small" data-i18n="s_dir_d"></p>
    <h3 data-i18n="s_ags"></h3><p class="muted small" data-i18n="s_ags_d"></p><div id="sAgs" class="ag-checks"></div>
    <label><span data-i18n="s_setdir"></span>
      <div class="row"><input id="sSetDir" spellcheck="false" style="flex:1"><button id="sSetDirPick" data-i18n="pick_dir"></button></div></label>
    <p class="muted small" data-i18n="s_setdir_d"></p>
    <h3 data-i18n="s_ai"></h3>
    <label class="chk"><input type="checkbox" class="sw" id="sAiPick"> <span data-i18n="s_ai_pick"></span></label>
    <label class="chk"><input type="checkbox" class="sw" id="sAiThumbs"> <span data-i18n="s_ai_thumbs"></span></label>
    <p class="muted small" data-i18n="s_ai_d"></p>
    <h3 data-i18n="s_ed"></h3><p class="muted small" data-i18n="s_ed_d"></p><div id="sEd"></div></section>
    <section data-collapse="auto"><h2 data-i18n="s_auto"></h2><p class="muted small" data-i18n="s_auto_d"></p>
    <label class="chk"><input type="checkbox" class="sw" id="sDuty"> <span data-i18n="s_duty"></span></label>
    <p class="muted small" id="sDutyInfo"></p>
    <label class="chk"><input type="checkbox" class="sw" id="sAutoStart"> <span data-i18n="s_autostart"></span></label>
    <p class="muted small" data-i18n="s_autostart_d"></p>
    <h3 data-i18n="s_move_h"></h3>
    <div class="row"><select id="sMoveMode"><option value="evening" data-i18n="s_move_evening"></option><option value="approve" data-i18n="s_move_approve"></option></select>
      ${timeSel("sMoveAt")}</div>
    <h3 data-i18n="s_ftp_h"></h3>
    <label class="chk"><input type="checkbox" class="sw" id="sAutoFtp"> <span data-i18n="s_auto_ftp"></span></label>
    <div class="row"><label class="flt"><span data-i18n="s_ftp_from"></span> ${timeSel("sFtpFrom")}</label>
      <label class="flt"><span data-i18n="s_ftp_to"></span> ${timeSel("sFtpTo")}</label></div>
    <p class="muted small" data-i18n="s_ftp_d"></p></section>
    ${window.BACKUP_HTML || ""}`,
  load(s) {
    $("#sDir").value = s.sub_ready_dir || "";
    $("#sAiPick").checked = s.sub_ai_pick !== false; $("#sAiThumbs").checked = !!s.sub_ai_thumbs;
    $("#sDuty").checked = !!s.sub_duty; $("#sAutoFtp").checked = s.sub_auto_ftp !== false;
    timeSet("sFtpFrom", s.sub_ftp_from || "20:00"); timeSet("sFtpTo", s.sub_ftp_to || "09:00");
    $("#sMoveMode").value = s.sub_move_mode || "evening"; timeSet("sMoveAt", s.sub_move_at || "19:00");
    $$("#sMoveAt select").forEach((el) => { el.disabled = $("#sMoveMode").value === "approve"; });
    api("auto").then((a) => { $("#sDutyInfo").textContent = a.duty_set ? t("s_duty_me") : a.duty_pc ? t("s_duty_other", { c: a.duty_pc }) : t(a.sync ? "s_duty_none" : "s_duty_single"); }).catch(() => {});
    api("autostart").then((a) => { $("#sAutoStart").checked = !!a.on; }).catch(() => { $("#sAutoStart").disabled = true; });
    $("#sSetDir").value = s.sub_set_dir || ""; $("#sSetDir").placeholder = t("s_setdir_ph");
    const all = (Core.state || {}).agencies_all || [];
    const box = (id, vals) => all.map((a) => `<label class="chk"><input type="checkbox" class="${id}" value="${a.id}" ${vals.includes(a.id) ? "checked" : ""}> ${esc(a.name)}</label>`).join("");
    $("#sAgs").innerHTML = box("sAg1", s.sub_agencies || []);
    const ed = s.sub_ed_agencies || [], edi = s.sub_edi_agencies || [];
    $("#sEd").innerHTML = `<table class="t ed-tbl"><thead><tr><th>${esc(t("f_agency"))}</th><th>ED</th><th>EDI</th></tr></thead><tbody>` +
      all.map((a) => { const e = ed.includes(a.id); return `<tr><td>${esc(a.name)}</td><td><input type="checkbox" class="sEd1" value="${a.id}" ${e ? "checked" : ""}></td>
        <td><input type="checkbox" class="sEdi1" value="${a.id}" ${e || edi.includes(a.id) ? "checked" : ""} ${e ? "disabled" : ""}></td></tr>`; }).join("") + `</tbody></table>`;
    $$(".sEd1").forEach((c) => c.addEventListener("change", () => {     /* ED ietver EDI */
      const i = $(`.sEdi1[value="${c.value}"]`); if (c.checked) { i.checked = true; i.disabled = true; } else i.disabled = false;
    }));
    connLoad(s, all);
    if (window.bkLoad) window.bkLoad(s);
  },
  collect() {
    return { sub_ready_dir: $("#sDir").value.trim(), sub_set_dir: $("#sSetDir").value.trim(), sub_agencies: $$(".sAg1").filter((c) => c.checked).map((c) => c.value),
      sub_ed_agencies: $$(".sEd1").filter((c) => c.checked).map((c) => c.value),
      sub_edi_agencies: $$(".sEdi1").filter((c) => c.checked && !c.disabled).map((c) => c.value),
      sub_conn: connCollect(), sub_ai_pick: $("#sAiPick").checked, sub_ai_thumbs: $("#sAiThumbs").checked,
      ...autoVals(),
      ...(window.bkCollect ? window.bkCollect() : {}) };
  },
  onSaved() { load(); if (typeof loadBackups === "function") loadBackups(); },
});
/* laiks 24 h (lietotājs 2026-11-11 11:55: <input type="time"> rādīja "07:00 PM") — divas izvēles HH : MM */
function timeSel(id) {
  const o = (n, st) => Array.from({ length: n / st }, (_, i) => String(i * st).padStart(2, "0")).map((v) => `<option>${v}</option>`).join("");
  return `<span class="tsel" id="${id}"><select data-p="h">${o(24, 1)}</select>:<select data-p="m">${o(60, 5)}</select></span>`;
}
function timeSet(id, v) {
  const [h, m] = String(v || "00:00").split(":"); const el = $("#" + id); if (!el) return;
  $("select[data-p=h]", el).value = String(+h || 0).padStart(2, "0");
  const mm = String(Math.round((+m || 0) / 5) * 5 % 60).padStart(2, "0"); $("select[data-p=m]", el).value = mm;
}
const timeGet = (id) => $("#" + id) ? `${$("#" + id + " select[data-p=h]").value}:${$("#" + id + " select[data-p=m]").value}` : "";
function autoVals() {
  return { sub_duty: $("#sDuty").checked, sub_auto_ftp: $("#sAutoFtp").checked, sub_ftp_from: timeGet("sFtpFrom") || "20:00",
    sub_ftp_to: timeGet("sFtpTo") || "09:00", sub_move_mode: $("#sMoveMode").value, sub_move_at: timeGet("sMoveAt") || "19:00" };
}
/* automātikas iestatījumi saglabājas uzreiz (lietotājs 2026-11-11 13:48 — ieslēdza dežūru, nesaglabāja) */
document.addEventListener("change", async (e) => {
  if (!e.target.closest("#sDuty, #sAutoFtp, #sMoveMode, #sMoveAt, #sFtpFrom, #sFtpTo")) return;
  if (e.target.id === "sMoveMode") $$("#sMoveAt select").forEach((el) => { el.disabled = e.target.value === "approve"; });
  try {
    const r = await api("settings", { settings: autoVals() });
    Core.settings = Object.assign({}, Core.settings, r.settings || {});
    toast(t("s_auto_saved"), "ok", 2000);
    if (e.target.id === "sDuty") api("auto").then((a) => { $("#sDutyInfo").textContent = a.duty_set ? t("s_duty_me") : a.duty_pc ? t("s_duty_other", { c: a.duty_pc }) : t(a.sync ? "s_duty_none" : "s_duty_single"); }).catch(() => {});
  } catch (err) { toast(err.message, "err"); }
});
document.addEventListener("change", async (e) => {
  if (e.target.id !== "sAutoStart") return;
  try { const r = await api("autostart", { on: e.target.checked }); e.target.checked = !!r.on; toast(t(r.on ? "s_autostart_on" : "s_autostart_off"), "ok", 3000); }
  catch (err) { e.target.checked = !e.target.checked; toast(err.message === "unsupported" ? t("s_autostart_na") : err.message, "err"); }
});
document.addEventListener("click", async (e) => {
  const b = e.target.closest("#sDirPick, #sSetDirPick"); if (!b) return;
  const inp = b.id === "sDirPick" ? $("#sDir") : $("#sSetDir");
  try { const r = await api("pick_folder", { start: inp.value }); if (r.path) inp.value = r.path; } catch (_) {}
});

/* ---------- aģentūru pieslēgumi: FTP vai portāls (parole — tikai drošajā glabātuvē, core/credentials "ftp:<aģentūra>") ---------- */
async function connLoad(s, all) {
  const box = $("#sConn"); if (!box) return;
  const def = (Core.state || {}).ftp_def || {}, cfg = s.sub_conn || {};
  let creds = {};
  try { creds = (await api("creds", { names: Object.keys(def).map((a) => "ftp:" + a) })).creds || {}; } catch (_) {}
  box.innerHTML = all.map((a) => {
    const c = cfg[a.id] || {}, d = def[a.id], mode = d && c.mode === "ftp" ? "ftp" : "portal", cr = creds["ftp:" + a.id] || {};
    return `<div class="cn-ag" data-ag="${a.id}"><div class="cn-ag-h"><b>${esc(a.name)}</b>
      <select class="ca-mode"><option value="portal">${esc(t("mode_portal"))}</option>${d ? `<option value="ftp">${esc(t("mode_ftp"))}</option>` : ""}</select>
      ${d ? "" : `<span class="muted small">${esc(t("ftp_none"))}</span>`}</div>
      <div class="ca-portal ${mode === "portal" ? "" : "hidden"}"><input class="ca-url" spellcheck="false" placeholder="${esc(a.url)}" value="${esc(c.url && c.url !== a.url ? c.url : "")}"></div>
      ${d ? `<div class="ca-ftp ${mode === "ftp" ? "" : "hidden"}">
        <div class="ca-row"><select class="ca-proto">${["ftp", "ftps", "sftp"].map((p) => `<option value="${p}" ${(c.proto || d.proto) === p ? "selected" : ""}>${p.toUpperCase()}</option>`).join("")}</select>
          <input class="ca-host" spellcheck="false" data-ph="host" placeholder="${esc(d.host || t("ftp_host"))}" value="${esc(c.host && c.host !== d.host ? c.host : "")}">
          <input class="ca-port" type="number" min="1" max="65535" placeholder="${d.port}" value="${esc(c.port && c.port !== d.port ? c.port : "")}">
          <input class="ca-dir" spellcheck="false" placeholder="${esc(d.dir || t("ftp_dir_ph"))}" title="${esc(t("ftp_dir_d"))}" value="${esc(c.dir && c.dir !== d.dir ? c.dir : "")}"></div>
        <div class="ca-row"><input class="ca-user" spellcheck="false" autocomplete="off" placeholder="${esc(t("cr_user"))}" value="${esc(cr.user || "")}">
          <input class="ca-pass" type="password" autocomplete="new-password" placeholder="${esc(cr.saved ? t("ftp_pass_saved") : t("cr_pass"))}">
          <button class="small ca-save">${esc(t("ftp_save"))}</button><button class="small ca-test">${esc(t("ftp_test"))}</button>
          ${cr.saved ? `<button class="small ghost ca-forget">${esc(t("cr_forget"))}</button>` : ""}<span class="ca-st small muted"></span></div>
        <div class="muted small">${esc(t(d.note))}</div></div>` : ""}</div>`;
  }).join("");
  box.onchange = (e) => {
    const m = e.target.closest(".ca-mode"); if (!m) return;
    const row = m.closest(".cn-ag");
    $(".ca-portal", row).classList.toggle("hidden", m.value !== "portal");
    if ($(".ca-ftp", row)) $(".ca-ftp", row).classList.toggle("hidden", m.value !== "ftp");
  };
  $$(".cn-ag", box).forEach((row) => { const c = cfg[row.dataset.ag] || {}; if (c.mode === "ftp" && $(".ca-ftp", row)) $(".ca-mode", row).value = "ftp"; });
  box.onclick = async (e) => {
    const row = e.target.closest(".cn-ag"); if (!row) return;
    const ag = row.dataset.ag, st = $(".ca-st", row);
    try {
      if (e.target.closest(".ca-save")) {
        /* 2026-11-04: rindas "Saglabāt" saglabāja tikai lietotāju/paroli, un pārzīmējot serveris/ports/veids pazuda —
           tagad saglabā arī šīs aģentūras pieslēgumu (sub_conn) */
        const u = $(".ca-user", row).value.trim(), pw = $(".ca-pass", row).value;
        if (u || pw) await api("cred_save", { name: "ftp:" + ag, user: u, password: pw });
        const sc = Object.assign({}, (Core.settings || {}).sub_conn || {}, { [ag]: connOf(row) });
        Core.settings = Object.assign({}, Core.settings, { sub_conn: (await api("settings", { settings: { sub_conn: sc } })).settings.sub_conn });
        $(".ca-pass", row).value = ""; st.textContent = t("saved"); return connLoad(Core.settings, all);
      }
      if (e.target.closest(".ca-forget")) { await api("cred_forget", { name: "ftp:" + ag }); return connLoad(Core.settings, all); }
      if (e.target.closest(".ca-test")) {
        if ($(".ca-pass", row).value) await api("cred_save", { name: "ftp:" + ag, user: $(".ca-user", row).value.trim(), password: $(".ca-pass", row).value });
        st.textContent = t("ftp_testing");
        const r = (await api("ftp_test", { agency: ag, conn: connOf(row) })).result || {};
        const k = "ftp_e_" + r.error, why = t(k) !== k ? t(k) : (r.error || "");
        const hint = !r.ok && ag === "adobe" && $(".ca-user", row).value.includes("@") ? " " + t("ftp_adobe_id") : "";
        st.textContent = r.ok ? t("ftp_ok") : why + (r.detail ? " — " + r.detail : "") + hint;
        st.className = "ca-st small " + (r.ok ? "ok-t" : "err-t");
      }
    } catch (err) {
      const k = "ftp_e_" + err.message;
      st.textContent = err.message === "keyring" ? t("s_creds_na") : t(k) !== k ? t(k) : err.message; st.className = "ca-st small err-t";
    }
  };
}
function connOf(row) {
  const o = { mode: $(".ca-mode", row).value };
  const url = $(".ca-url", row).value.trim(); if (url) o.url = url;
  if ($(".ca-ftp", row)) {
    o.proto = $(".ca-proto", row).value;
    const h = $(".ca-host", row).value.trim(); if (h) o.host = h;
    const p = +$(".ca-port", row).value; if (p) o.port = p;
    const dr = $(".ca-dir", row).value.trim(); if (dr) o.dir = dr;
  }
  return o;
}
function connCollect() {
  if (!$("#sConn .cn-ag")) return (Core.settings || {}).sub_conn || {};
  const out = {};
  $$("#sConn .cn-ag").forEach((row) => { out[row.dataset.ag] = connOf(row); });
  return out;
}

function onLang() { applyI18n(); fillFilters(); renderCards(); render(); if (S.page === "settings") loadSettings(); if (S.page === "sets") { loadSets(); paintNs(); } }

Core.init({ onLang, icon: "/static/icon.svg" });

async function init() {
  let st;
  try { st = await api("state"); } catch (e) { toast(e.message, "err"); return; }
  Core.boot(st);
  applyI18n();
  await load();
  ftpPoll();                               // ja augšupielāde jau notiek (lapa pārlādēta)
  S.moveShown = true; movePoll();
}
init();

/* Darba indikators statusa joslā (lietotājs 2026-11-12 16:36, test40): ko Tirgotājs dara tagad, ko dara dežūras
   dators (pultī), un — ja nekas nenotiek — nākamais plānotais darbs. Ik 5 s. */
let actTimer = null;
const actHm = (iso) => { const d = new Date(iso); return isNaN(d) ? "" : d.toLocaleDateString(window.langLocale(), { day: "2-digit", month: "2-digit" }) + " " + d.toLocaleTimeString(window.langLocale(), { hour: "2-digit", minute: "2-digit" }); };
async function actPoll() {
  clearTimeout(actTimer);
  let d;
  try { d = await api("activity"); } catch (_) { actTimer = setTimeout(actPoll, 15000); return; }
  const m = d.move || {}, n = d.nas || {}, a = d.auto || {}, nx = d.next || {};
  if (m.running && !moveTimer) movePoll();                       /* pārvietošana sākās automātiski (19:00) — rādīt gaitu */
  Core.setStatus("nas", n.running ? { text: t("act_nas", { d: n.done || 0, n: n.total || 0, f: n.current || "" }), cls: "run spin" } : null);
  const rm = (d.remote || [])[0];
  Core.setStatus("remote", rm && !m.running ? { text: t("act_remote_move", { c: rm.pc || "", s: rm.name || "", d: rm.done || 0, n: rm.total || 0,
    sec: Math.max(0, Math.round((Date.now() - new Date(rm.at)) / 1000)) }), cls: "run spin" } : null);
  const busy = m.running || n.running || rm || ftpTimer && document.querySelector('#statusLeft [data-id="ftp"]');
  let idle = null;
  if (!busy) {
    const parts = [];
    if (nx.move_at) parts.push(t("act_next_move", { t: actHm(nx.move_at), s: nx.move_name }));
    if (nx.ftp_at) parts.push(t("act_next_ftp", { t: actHm(nx.ftp_at), s: nx.ftp_name }));
    if (parts.length) idle = { text: t("act_wait") + " " + parts.join(" · "), cls: "ok" };
  }
  if (!a.duty && a.sync && a.duty_seen) {                        /* pults: vai dežūras dators dzīvs */
    const min = Math.round((Date.now() - new Date(a.duty_seen)) / 60000);
    if (min > 5) idle = { text: t("act_duty_lost", { c: a.duty_pc || "?", m: min }), cls: "err" };
  }
  if (a.err) idle = { text: t("act_err", { e: a.err }), cls: "err" };
  Core.setStatus("work", idle);
  actTimer = setTimeout(actPoll, 5000);
}
setTimeout(actPoll, 3000);
