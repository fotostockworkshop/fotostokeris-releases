"use strict";
/* Tirgotājs — cilne "Plāns" (plan.py; kopsavilkums §11, lēmumi 2026-11-05 16:27–16:59).
   Nedēļas × dienas, kartīte = komplekts; pārvilkt uz citu dienu; "Apstiprināt nedēļu"; "Sagatavot nākamo nedēļu"
   (pārvieto uz OneDrive mapēm pēc plānotās dienas); augšā "Šodien" un nokavētie. Darbības ar komplektu — setAct (app.js). */
const PL = { d: null };

async function planLoad(body) {
  let d;
  try { d = await api("plan", body || {}); } catch (e) { toast(e.message, "err"); return null; }
  PL.d = d;
  planPaint();
  return d;
}
window.planLoad = planLoad;

const plDay = (iso, o) => new Date(iso + "T12:00").toLocaleDateString(window.langLocale(), o || { weekday: "short", day: "numeric", month: "numeric" });
function plDots(c) {
  return (PL.d.agencies || []).map((a) => {
    const z = (c.agst || {})[a.id]; if (!z) return "";
    const head = z.st === "done" ? t("ag_done", { d: "" }) : z.st === "part" ? t("ag_part", { s: z.sub, n: z.n }) : z.st === "up" ? t("ag_up", { u: z.up, n: z.n }) : z.st === "bad" ? t("ag_bad_l") : t("ag_none_l");
    return `<span class="sdot ${z.st}${z.rej ? " rej" : ""}" title="${esc(a.name + " — " + head)}"></span>`;
  }).join("");
}
function plState(c) {
  return c.done ? t("pl_st_done") : c.moved ? t("pl_st_moved") : c.status === "approved" ? t("pl_st_approved") : t("pl_st_draft");
}
function plCard(c, big) {
  const tok = encodeURIComponent(window.TOKEN);
  const th = (c.thumbs || []).map((x) => `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(x.series)}&n=${encodeURIComponent(x.stem)}" alt="">`).join("");
  const cls = c.done ? "done" : c.moved ? "moved" : c.status;
  return `<div class="pl-card ${cls}${big ? " big" : ""}" draggable="${c.moved || c.done ? "false" : "true"}" data-date="${c.date}">
    <div class="pl-c-h"><b title="${esc(c.name)}">${esc(c.name)}</b><span class="cat cat-${esc(c.cat)}">${esc(c.cat)}</span></div>
    <div class="pl-th">${th || `<div class="ns-noimg"></div>`}</div>
    <div class="pl-c-f small"><span>${c.count} · ${esc(plState(c))}</span><span class="pl-dots">${plDots(c)}</span></div>
    <div class="pl-c-a">${c.moved ? `<button class="small ghost pl-open" title="${esc(c.dir)}">📁</button>` : ""}
      <button class="small ghost pl-show" title="${esc(t("set_show"))}">👁</button>
      ${c.moved || c.done ? "" : `<button class="small ghost pl-x" title="${esc(t("pl_remove"))}">×</button>`}</div></div>`;
}
function plTodayBox(c) {
  if (!c) return `<div class="pl-today muted">${esc(t("pl_today_none"))}</div>`;
  const ags = PL.d.agencies || [];
  return `<div class="pl-today"><div class="pl-today-h"><b>${esc(t("pl_today"))}</b> <span class="muted">${esc(plDay(c.date, { weekday: "long", day: "numeric", month: "long" }))}</span></div>
    <div class="row">${plCard(c, true)}
    <div class="pl-today-a">${c.moved ? "" : `<div class="small warn">${esc(t("pl_not_moved"))}</div><button class="small primary pl-move">${esc(t("set_move"))}</button>`}
      <div class="row"><select class="pl-ag">${ags.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select>
      <button class="small pl-ftp">${esc(t("set_ftp"))}</button><button class="small pl-portal">${esc(t("open_ag"))} ↗</button><button class="small pl-sub">${esc(t("set_sub"))}</button></div></div></div></div>`;
}
function planPaint() {
  const d = PL.d; if (!d) return;
  $("#plInfo").textContent = t("pl_info", { n: d.planned });
  $("#plPrep").disabled = !d.ready_next;
  $("#plPrep").title = d.ready_next ? t("plan_prep_d") : t("pl_prep_none");
  const note = $("#plNote");
  const msgs = [];
  if (!d.has_set_dir) msgs.push(esc(t("pl_no_setdir")));
  if (d.fresh >= 5 && d.planned) msgs.push(`${esc(t("pl_fresh", { n: d.fresh }))} <button class="small" id="plFill">${esc(t("pl_fill"))}</button>`);
  if (!d.planned) msgs.push(esc(d.fresh ? t("pl_empty", { n: d.fresh }) : t("pl_nothing")));
  note.innerHTML = msgs.join("<br>"); note.classList.toggle("hidden", !msgs.length);
  $("#plToday").innerHTML = d.planned ? plTodayBox(d.today_card) : "";
  $("#plLate").innerHTML = (d.late || []).length ? `<div class="pl-late"><b>${esc(t("pl_late", { n: d.late.length }))}</b><div class="pl-row">${d.late.map((c) => `<div class="pl-day"><div class="pl-d-h small">${esc(plDay(c.date))}</div>${plCard(c)}</div>`).join("")}</div></div>` : "";
  $("#plWeeks").innerHTML = d.weeks.map((w) => `<div class="pl-week"><div class="pl-w-h"><b>${esc(t("pl_week", { w: w.week }))}</b>
      <span class="muted small">${esc(plDay(w.days[0].date, { day: "numeric", month: "short" }))} – ${esc(plDay(w.days[w.days.length - 1].date, { day: "numeric", month: "short" }))}</span>
      ${w.drafts ? `<button class="small pl-approve" data-m="${w.monday}">${esc(t("pl_approve", { n: w.drafts }))}</button>` : ""}</div>
    <div class="pl-row">${w.days.map((x) => `<div class="pl-day${x.past ? " past" : ""}${x.date === d.today ? " today" : ""}" data-date="${x.date}">
      <div class="pl-d-h small">${esc(plDay(x.date))}</div>${x.card ? plCard(x.card) : `<div class="pl-empty muted small">—</div>`}</div>`).join("")}</div></div>`).join("");
}

function plFind(date) {
  const d = PL.d; if (!d) return null;
  if (d.today_card && d.today_card.date === date) return d.today_card;
  for (const w of d.weeks) for (const x of w.days) if (x.date === date && x.card) return x.card;
  return (d.late || []).find((c) => c.date === date) || null;
}
const plSet = (c) => Object.assign({ stems: [] }, c.set_info || {});

$("#page-plan").addEventListener("click", async (e) => {
  if (e.target.closest("#plFill")) { const d = await planLoad({ do: "auto" }); if (d) toast(t("pl_made", { n: d.result.made || 0 }), "ok", 4000); load(); return; }
  const ap = e.target.closest(".pl-approve");
  if (ap) { await planLoad({ do: "approve", monday: ap.dataset.m }); return; }
  const card = e.target.closest(".pl-card, .pl-today"); if (!card) return;
  const date = (card.dataset.date || ($(".pl-card", card) || {}).dataset?.date); const c = plFind(date); if (!c) return;
  if (e.target.closest(".pl-x")) {
    if (!(await uiConfirm(t("pl_remove_q", { s: c.name }), t("pl_remove")))) return;
    await planLoad({ do: "remove", date }); load(); return;
  }
  if (e.target.closest(".pl-show")) return setAct("show", plSet(c));
  if (e.target.closest(".pl-open")) return setAct("open", plSet(c));
  if (e.target.closest(".pl-move")) return setAct("move", plSet(c));
  const ag = ($(".pl-ag", card) || {}).value;
  if (e.target.closest(".pl-ftp")) return setAct("ftp", plSet(c), ag);
  if (e.target.closest(".pl-sub")) return setAct("sub", plSet(c), ag);
  if (e.target.closest(".pl-portal")) { const a = S.agencies.find((z) => z.id === ag); if (a) api("open_url", { url: a.url }).catch((err) => toast(err.message, "err")); }
});
$("#plAuto").addEventListener("click", async () => {
  $("#plAuto").disabled = true;
  try { const d = await planLoad({ do: "auto" }); if (d) toast(d.result.made ? t("pl_made", { n: d.result.made }) : t(d.result.free ? "pl_nothing" : "pl_full"), d.result.made ? "ok" : "err", 5000); load(); }
  finally { $("#plAuto").disabled = false; }
});
$("#plPrep").addEventListener("click", async () => {
  if (!(await uiConfirm(t("pl_prep_q", { n: PL.d.ready_next }), t("plan_prep")))) return;
  try { const r = await api("plan", { do: "prepare" }); S.moveShown = false; toast(t("move_start", { n: r.total, d: r.dir }), "ok", 6000); movePoll(); }
  catch (err) { const k = "move_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err sticky", 12000); }
});

/* pārvilkšana uz citu dienu (HTML5 drag & drop) */
$("#page-plan").addEventListener("dragstart", (e) => {
  const c = e.target.closest(".pl-card[draggable=true]"); if (!c) return;
  e.dataTransfer.setData("text/plain", c.dataset.date); e.dataTransfer.effectAllowed = "move"; c.classList.add("drag");
});
$("#page-plan").addEventListener("dragend", (e) => { const c = e.target.closest(".pl-card"); if (c) c.classList.remove("drag"); $$(".pl-day.over").forEach((x) => x.classList.remove("over")); });
$("#page-plan").addEventListener("dragover", (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day || day.classList.contains("past")) return;
  e.preventDefault(); $$(".pl-day.over").forEach((x) => x !== day && x.classList.remove("over")); day.classList.add("over");
});
$("#page-plan").addEventListener("drop", async (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day) return;
  e.preventDefault(); day.classList.remove("over");
  const from = e.dataTransfer.getData("text/plain"); if (!from || from === day.dataset.date) return;
  const d = await planLoad({ do: "move", from, to: day.dataset.date });
  if (d && !d.result.ok) toast(t("pl_e_" + d.result.error), "err", 5000);
  load();
});
