"""AI asistents Tirgotājā (lietotājs 2026-11-03: "sagatavo iesniegšanai Bali RF bilžu kolekciju").

AI saņem tikai kopsavilkumu (sērijas, kategorijas, atslēgvārdu paraugs, kas kur iesniegts) — ne bildes — un atbild ar
darbību JSON. Bildes atlasa pats Tirgotājs (stock.suggest — tie paši noteikumi), lietotājs pārskata un saglabā.
AI pats neko neatzīmē un neiesniedz. Pieslēgumi — kopīgie (core/ai.py, darbs "assistant"; noteikumi §5 p.2).
Bez AI (vai ja neizdodas) — vienkārša vārdu nolasīšana no teikuma (local_parse).
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import tempfile
import urllib.error
import urllib.request
from collections import Counter

from core import ai as cai

from . import config, stock

SCHEMA = {
    "type": "object",
    "properties": {
        "action": {"type": "string", "enum": ["make_set", "show", "answer"]},
        "match": {"type": "string", "description": "search words (place/topic) to find photos; empty = all"},
        "cat": {"type": "string", "enum": ["RF", "ED", "EDI", ""]},
        "size": {"type": "integer", "description": "number of photos for a set; 0 = automatic"},
        "agency": {"type": "string", "description": "agency id or empty"},
        "show": {"type": "string", "enum": ["todo", "rejected", "bad", ""]},
        "reply": {"type": "string", "description": "short answer to the user in the user's language"},
    },
    "required": ["action", "match", "cat", "size", "agency", "show", "reply"],
    "additionalProperties": False,
}

STOP = set("""sagatavo sagatavot iesniegšanai iesniegt bilžu bildes bildi kolekciju kolekcija komplektu komplekts komplektā
parādi parādīt rādīt kas kur vēl nav cik un ar no par uz man lūdzu please prepare make set collection photos photo images
show submit submission for the of to with and from rf ed edi iesniegts iesniegtas iesniegtās pieņemts pieņemtas noraidīts
noraidītas neder bilde komplektam aģentūrā aģentūrai agency""".split())


def summary() -> dict:
    r = stock.listing()
    ags = [a["id"] for a in r["agencies"]]
    ser = {s["key"]: {"name": s["name"], "code": s["code"], "n": 0, "cat": Counter(), "kw": Counter(),
                      "todo": Counter(), "sub": Counter(), "acc": Counter(), "rej": Counter()} for s in r["series"]}
    for it in r["items"]:
        x = ser.get(it["series"])
        if not x:
            continue
        x["n"] += 1
        x["cat"][it["cat"]] += 1
        for w in (it.get("kwtext") or "").split("|")[:25]:
            if w:
                x["kw"][w] += 1
        for a in ags:
            c = it["cells"].get(a) or {}
            stt = c.get("state") or ("bad" if c.get("bad") else "")
            key = {"": "todo", "submitted": "sub", "accepted": "acc", "rejected": "rej"}.get(stt)
            if key:
                x[key][a] += 1
    out = []
    for x in list(ser.values())[:300]:
        out.append({"series": x["name"], "code": x["code"], "photos": x["n"], "categories": dict(x["cat"]),
                    "keywords": [w for w, _ in x["kw"].most_common(12)],
                    "not_submitted": dict(x["todo"]), "submitted": dict(x["sub"]), "accepted": dict(x["acc"]),
                    "rejected": dict(x["rej"])})
    return {"agencies": {a["id"]: a["name"] for a in r["agencies"]}, "series": out, "sets": r.get("sets") or []}


def local_parse(text: str) -> dict:
    low = text.lower()
    words = re.findall(r"[\wāčēģīķļņšūž]+", low)
    cat = "EDI" if "edi" in words or "illustrative" in words else ("ED" if "ed" in words or "editorial" in words else ("RF" if "rf" in words else ""))
    nums = [int(w) for w in words if w.isdigit()]
    ag = next((a for a in stock.AG_IDS if a in words or a in low), "")
    match = " ".join(w for w in words if w not in STOP and not w.isdigit() and len(w) > 2 and w != ag)
    make = bool(re.search(r"sagatav|komplekt|kolekcij|prepare|\bset\b|collection", low))
    show = "rejected" if re.search(r"noraid|reject", low) else ("todo" if re.search(r"nav iesniegt|neiesniegt|not submitted", low) else "")
    return {"action": "make_set" if make else "show", "match": match, "cat": cat, "size": nums[0] if nums else 0,
            "agency": ag, "show": show, "reply": "", "by": "local"}


def _prompt(text: str) -> str:
    return ("You are the assistant inside 'Tirgotājs', a desktop tool that helps a stock photographer submit finished "
            "photos to stock agencies. The user writes a request (usually in Latvian). Decide ONE action:\n"
            "- make_set: prepare a submission set (komplekts/kolekcija) — fill match (place/topic words that occur in series "
            "names or keywords, e.g. 'Bali'), cat (RF, ED = editorial, EDI = illustrative editorial: brands without people; or empty), size (0 = automatic) and agency if named;\n"
            "- show: show photos in the table — fill match/agency/show (todo = not submitted yet, rejected, bad = unsuitable);\n"
            "- answer: answer a question (counts etc.) from the data below in 'reply'.\n"
            "Always write a short 'reply' in the user's language explaining what you did. Use agency ids from the data. "
            "Never claim photos were submitted — the user submits and marks them.\n\n"
            "DATA (JSON):\n" + json.dumps(summary(), ensure_ascii=False) + "\n\nUSER REQUEST:\n" + text +
            "\n\nAnswer with JSON only, matching this schema:\n" + json.dumps(SCHEMA))


def _json(text: str) -> dict:
    text = (text or "").strip()
    try:
        d = json.loads(text)
        if isinstance(d, dict):
            return d
    except json.JSONDecodeError:
        pass
    m = re.search(r"\{.*\}", text, re.S)
    if m:
        return json.loads(m.group(0))
    raise RuntimeError("AI: " + text[:200])


def _claude(prompt: str) -> dict:
    cmd = cai.find_claude()
    if not cmd:
        raise RuntimeError("Claude Code nav uzstādīts")
    args = cmd + ["-p", "--output-format", "json", "--model", (config.get("model") or "sonnet").strip()]
    with tempfile.TemporaryDirectory() as wd:
        r = subprocess.run(args, input=prompt.encode("utf-8"), capture_output=True, cwd=wd, timeout=180,
                           env=cai._env(cai.CLAUDE_ENV), creationflags=cai.NO_WINDOW)
    out = r.stdout.decode("utf-8", "replace").strip()
    data = None
    for chunk in [out] + out.splitlines()[::-1]:
        if chunk.strip().startswith("{"):
            try:
                data = json.loads(chunk.strip())
                break
            except json.JSONDecodeError:
                continue
    if not data or data.get("is_error"):
        raise RuntimeError(str((data or {}).get("result") or out or r.stderr.decode("utf-8", "replace"))[:300])
    u = data.get("usage") or {}
    cai.record("claude_sub", "", int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0))
    so = data.get("structured_output")
    return so if isinstance(so, dict) else _json(str(data.get("result", "")))


def _codex(prompt: str) -> dict:
    cmd = cai.find_codex()
    if not cmd:
        raise RuntimeError("Codex nav uzstādīts")
    with tempfile.TemporaryDirectory() as wd:
        sf, of = os.path.join(wd, "schema.json"), os.path.join(wd, "answer.json")
        json.dump(SCHEMA, open(sf, "w", encoding="utf-8"))
        args = cmd + ["exec", "--skip-git-repo-check", "--sandbox", "read-only", "--cd", wd,
                      "--output-schema", sf, "--output-last-message", of]
        m = (config.get("codex_model") or "").strip()
        if m:
            args += ["--model", m]
        r = subprocess.run(args + ["-"], input=("Do not run commands. " + prompt).encode("utf-8"), capture_output=True,
                           cwd=wd, timeout=240, env=cai._env(cai.CODEX_ENV), creationflags=cai.NO_WINDOW)
        text = open(of, encoding="utf-8", errors="replace").read() if os.path.isfile(of) else ""
    if not text:
        raise RuntimeError(((r.stdout + r.stderr).decode("utf-8", "replace") or f"exit {r.returncode}")[-300:])
    cai.record("chatgpt_sub", m)
    return _json(text)


def _post(url: str, body: dict, headers: dict) -> dict:
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"content-type": "application/json", **headers})
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            return json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"API {e.code}: {e.read().decode('utf-8', 'replace')[:200]}")


def _claude_api(prompt: str) -> dict:
    k = cai.key("claude_api")
    if not k:
        raise RuntimeError("nav Claude API atslēgas")
    m = (config.get("model") or "sonnet").strip()
    model = {"sonnet": "claude-sonnet-5-5", "opus": "claude-opus-5-5", "haiku": "claude-haiku-5-5"}.get(m, m)
    d = _post("https://api.anthropic.com/v1/messages", {"model": model, "max_tokens": 1500,
              "messages": [{"role": "user", "content": prompt}]}, {"x-api-key": k, "anthropic-version": "2023-06-01"})
    u = d.get("usage") or {}
    cai.record("claude_api", model, int(u.get("input_tokens") or 0), int(u.get("output_tokens") or 0))
    return _json("".join(b.get("text", "") for b in d.get("content", []) if b.get("type") == "text"))


def _openai_api(prompt: str) -> dict:
    k = cai.key("openai_api")
    if not k:
        raise RuntimeError("nav OpenAI API atslēgas")
    model = (config.get("openai_model") or "gpt-5-mini").strip()
    d = _post("https://api.openai.com/v1/chat/completions", {"model": model, "messages": [{"role": "user", "content": prompt}],
              "response_format": {"type": "json_object"}}, {"Authorization": "Bearer " + k})
    u = d.get("usage") or {}
    cai.record("openai_api", model, int(u.get("prompt_tokens") or 0), int(u.get("completion_tokens") or 0))
    return _json(((d.get("choices") or [{}])[0].get("message") or {}).get("content") or "")


RUN = {"claude_sub": _claude, "chatgpt_sub": _codex, "claude_api": _claude_api, "openai_api": _openai_api}


def providers() -> list[str]:
    lst = [p for p in cai.order("assistant") if p in RUN]
    if not lst:                                   # noklusējums: kas šajā datorā ir pieejams
        if cai.find_claude():
            lst.append("claude_sub")
        if cai.find_codex():
            lst.append("chatgpt_sub")
        lst += [p for p in ("claude_api", "openai_api") if cai.key(p)]
    return lst


def ask(text: str) -> dict:
    text = (text or "").strip()[:1000]
    if not text:
        raise ValueError("empty")
    errs = []
    prompt = None
    for p in providers():
        try:
            prompt = prompt or _prompt(text)
            d = RUN[p](prompt)
            d["by"] = p
            break
        except Exception as e:                    # nākamais pieslēgums; beigās — bez AI
            errs.append(f"{p}: {e}")
    else:
        d = local_parse(text)
        d["errors"] = errs
    d.setdefault("match", "")
    d["cat"] = d.get("cat") if d.get("cat") in ("RF", "ED", "EDI") else ""
    if d.get("agency") not in stock.AG_IDS:
        d["agency"] = ""
    if d.get("action") == "make_set":
        res = stock.suggest(d["cat"] or "RF", int(d.get("size") or 0), match=d["match"])
        d["set"] = res
    return {"ok": True, **d}
