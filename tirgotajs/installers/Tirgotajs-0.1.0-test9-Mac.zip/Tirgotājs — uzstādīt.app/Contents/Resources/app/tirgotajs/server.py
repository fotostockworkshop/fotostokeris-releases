"""Tirgotāja API (prefikss sub_, noteikumi §3, §5) virs kopīgā servera core/server.py."""
from __future__ import annotations

import os

from core import server as core

from . import config, stock


def _ok(**kw):
    kw.setdefault("ok", True)
    return kw


def api_sub_state(_):
    return _ok(**core.base_state(), agencies_all=stock.AGENCIES, ftp_def=stock.FTP_DEF)


def api_sub_ftp_upload(b):
    from . import ftp
    return ftp.upload_set(str(b.get("id") or ""), str(b.get("agency") or ""))


def api_sub_ftp_status(_):
    from . import ftp
    return _ok(job=ftp.status())


def api_sub_ftp_test(b):
    from . import ftp
    return ftp.test(str(b.get("agency") or ""), b.get("conn") or None)


def api_sub_list(_):
    r = stock.listing()
    for it in r["items"]:
        it.pop("kwtext", None)
    return r


def api_sub_ask(b):
    from . import assistant
    return assistant.ask(str(b.get("text") or ""))


def api_sub_mark(b):
    n = stock.mark(b.get("stems") or [], b.get("agency") or "", b.get("state") or "", b.get("reason") or "")
    return _ok(n=n)


def api_sub_set_suggest(b):
    return stock.suggest(b.get("cat") or "RF", int(b.get("size") or 0), b.get("exclude") or [], str(b.get("match") or ""))


def api_sub_set_save(b):
    return _ok(set=stock.set_save(str(b.get("name") or "").strip(), b.get("cat") or "RF", b.get("stems") or []))


def api_sub_set_delete(b):
    stock.set_delete(str(b.get("id") or ""))
    return _ok()


def api_sub_set_export(b):
    return stock.set_export(str(b.get("id") or ""), str(b.get("agency") or ""))


def api_sub_sets(_):
    return _ok(sets=stock.sets_list(), agencies=stock.agencies())


def api_sub_set_dir(b):
    p = str(b.get("path") or "").strip()
    if p and not os.path.isdir(p):
        return {"ok": False, "error": "dir_missing"}
    config.update({"sub_ready_dir": p})
    return _ok()


def api_sub_open(b):
    p = str(b.get("path") or "")
    if not os.path.exists(p):
        return {"ok": False, "error": "dir_missing"}
    core._open_folder(p if os.path.isdir(p) else os.path.dirname(p))
    return _ok()


def api_sub_open_url(b):
    u = str(b.get("url") or "")
    if u not in stock.portal_urls():                          # tikai aģentūru lapas (noklusējums vai iestatījumos)
        return {"ok": False, "error": "url"}
    from core import browser
    browser.open_url(u)
    return _ok()


def _get_thumb(q):
    if q.get("t") != core.TOKEN:
        return 403, b"", "text/plain", None
    data = stock.thumb(q.get("s") or "", q.get("n") or "")
    if not data:
        return 404, b"", "text/plain", None
    return 200, data, "image/jpeg", {"Cache-Control": "max-age=3600"}


API = {k[len("api_sub_"):]: v for k, v in dict(globals()).items() if k.startswith("api_sub_")}


def start(port: int = 0):
    core.register_get({"/thumb": _get_thumb})
    try:
        from core import backup
        from . import appdef
        backup.set_hooks(after_restore=appdef.after_restore,
                         info=lambda _p=None: {"marks": len(stock.ledger().data), "sets": len(stock.sets_store().data)})
        backup.start_scheduler(lambda: False)
        from core import sync
        sync.start()                     # sinhronizācija starp datoriem (ja ieslēgta; dati §7a)
    except Exception as e:
        print("rezerves kopijas:", e)
    res = core.start(port)
    core.register(API)
    return res


shutdown = core.shutdown
idle_watch = core.idle_watch
