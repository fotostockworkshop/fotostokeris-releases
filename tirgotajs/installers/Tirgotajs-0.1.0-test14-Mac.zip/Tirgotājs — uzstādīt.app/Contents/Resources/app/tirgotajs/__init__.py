"""Tirgotājs — Fotostokera modulis: gatavo bilžu iesniegšana aģentūrās un uzskaite (noteikumi §2, §11)."""

APP_NAME = "Tirgotājs"
VERSION = "0.1.0-test14"
