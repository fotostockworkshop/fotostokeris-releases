"""Tirgotājs ↔ Google Drive caur programmas Google kontu (test21; noteikumi dati §7a (c), §8c; lēmumi 2026-11-09).

- Manifesti: `core.manifests_drive.pull` → datu mapē `Manifesti-drive/` (ik 15 min fonā, poga "Atjaunot no Google" — uzreiz).
  stock.scan() tos lasa kā kopīgo manifestu mapi; bildes, kuru šajā datorā nav (Mac — NAS bildes neredz), rāda "uz NAS".
- Vecās sērijas: ja šajā datorā ir sērijas manifests ar bildēm, bet Drive tā nav — augšupielādē (vienreiz; darba dators).
- `agenturas_bildes.json` (Analītiķis → Drive `Fotostokeris/Kopigi/`): bildes, kas jau ir aģentūrās — Tirgotājs tikai lasa.
Bez Google konta — nekas no šī nenotiek (strādā kā līdz šim).
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from . import config

EVERY = 900                     # s — Drive pārbaude fonā
EXT_FILE = "agenturas_bildes.json"
_last = 0.0
_lock = threading.Lock()
_state = {"at": "", "error": "", "manifests": 0, "uploaded": 0, "ext": 0}
_sent: set[str] = set()         # sērijas, kas šajā reizē jau ieliktas rindā (vecās)
_ext_cache: tuple[float, dict] | None = None


def drive_dir() -> Path:
    return Path(config.app_dir()) / "Manifesti-drive"


def connected() -> bool:
    try:
        from core import google
        return google.connected()
    except Exception:
        return False


def _vsafe(name: str) -> str:
    """Tāpat kā Vārdotāja manifest._safe — lai Drive faila nosaukums sakrīt."""
    return re.sub(r'[\\/:*?"<>|]+', "_", str(name or "")).strip(" .") or "serija"


def queue(jpath: str, zpath: str | None = None) -> None:
    """Manifestu (sērijas ar "pārvietota" atzīmēm vai komplekta) — Drive rindā (core apvieno ar Drive versiju)."""
    if not connected():
        return
    try:
        data = json.loads(Path(jpath).read_text(encoding="utf-8"))
        sid = str(data.get("series_id") or "")
        if not sid:
            return
        from core import manifests_drive
        manifests_drive.queue(f"{_vsafe(data.get('name'))}__{sid[:8]}", jpath, zpath, "tirgotajs")
    except Exception as e:
        print("Drive manifests (rinda):", str(e)[:200])


def _backfill() -> int:
    """Sērijas manifesti šajā datorā (ar bildēm), kuru Drive vēl nav → augšupielāde (dati §7a (c): vecās NAS sērijas)."""
    from . import stock
    try:
        have = json.loads((drive_dir() / "_drive.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        have = {}
    ids = {k[:8]: v.get("name") for k, v in have.items() if k.endswith(".json")}
    n = 0
    for root in stock._roots():
        for folder, jp in stock._manifests(root):
            try:
                data = json.loads(Path(jp).read_text(encoding="utf-8"))
            except Exception:
                continue
            sid = str(data.get("series_id") or "")
            if not sid or data.get("kind") == "set" or data.get("set_id") or sid in _sent:
                continue
            if sid[:8] in ids:
                # Drive ir — vai tur zināmas visas šeit "pārvietotās" (pārvietotas pirms test21 vai no cita datora)?
                mv = {i.get("stem") for i in data.get("images") or [] if i.get("status") == "moved"}
                if not mv:
                    continue
                try:
                    rem = json.loads((drive_dir() / ids[sid[:8]]).read_text(encoding="utf-8"))
                except (OSError, ValueError, TypeError):
                    continue
                if mv <= {i.get("stem") for i in rem.get("images") or [] if i.get("status") == "moved"}:
                    continue
                _sent.add(sid)
                queue(jp)                                  # tikai "pārvietota" atzīmes (core apvieno)
                n += 1
                continue
            imgs = [i for i in data.get("images") or [] if i.get("status") != "moved" and i.get("file")]
            if not any(os.path.isfile(os.path.join(folder, i["file"])) for i in imgs):
                continue
            z = os.path.join(os.path.dirname(jp), data["thumbs"]) if data.get("thumbs") else None
            _sent.add(sid)
            queue(jp, z if z and os.path.isfile(z) else None)
            n += 1
    if n:
        print(f"Drive manifesti: {n} sērijas no šī datora ieliktas augšupielādei (Drive to vēl nebija)")
    return n + _backfill_sets(ids)


def _backfill_sets(ids: dict) -> int:
    """Komplektu manifesti (kind: set), kuru Drive vēl nav — arī vecie, pārvietoti pirms test21 (lietotājs 2026-11-11 14:45;
    Analītiķis tos lasa). Tikai datorā, kur komplekta mape redzama."""
    from . import stock
    n = 0
    for sid, x in list(stock.sets_store().data.items()):
        key = "set:" + sid
        if not x.get("rel") or key in _sent or sid[:8] in ids:
            continue
        folder = stock.set_path(x)
        if not folder or not os.path.isdir(folder):
            continue
        jp = None
        for sub in stock.SUBS:
            d = os.path.join(folder, sub)
            cand = [os.path.join(d, os.path.basename(folder) + ".json")] + sorted(
                str(q) for q in Path(d).glob("*.json")) if os.path.isdir(d) else []
            for c in cand:
                try:
                    data = json.loads(Path(c).read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    continue
                if str(data.get("set_id") or data.get("series_id") or "") == sid:
                    jp = c
                    break
            if jp:
                break
        if not jp:
            continue
        z = os.path.join(os.path.dirname(jp), data.get("thumbs") or (os.path.basename(jp)[:-5] + "-sikteli.zip"))
        _sent.add(key)
        queue(jp, z if os.path.isfile(z) else None)
        n += 1
    if n:
        print(f"Drive manifesti: {n} komplekti ielikti augšupielādei (Drive to vēl nebija)")
    return n


def _pull_ext() -> int:
    from core import google
    fid = google.folder("Kopigi")
    f = next((x for x in google.list_files(fid) if x.get("name") == EXT_FILE), None)
    if not f:
        return 0
    p = Path(config.app_dir()) / EXT_FILE
    tmp = p.with_suffix(".tmp")
    tmp.write_bytes(google.download(f["id"]))
    os.replace(tmp, p)
    return len(ext_data().get("images") or [])


def refresh(force: bool = False) -> dict:
    """Lejupielādē jaunākos manifestus un agenturas_bildes.json; vecās sērijas — augšupielādei."""
    global _last
    if not connected():
        return {"ok": False, "error": "no_google"}
    if not force and time.time() - _last < EVERY:
        return {"ok": True, "skipped": True, **_state}
    with _lock:
        _last = time.time()
        err = []
        try:
            from core import manifests_drive
            r = manifests_drive.pull(drive_dir())
            _state["manifests"] = r.get("total", 0)
            print(f"manifesti no Google Drive: jauni {r.get('new')}, kopā {r.get('total')}")
        except Exception as e:
            err.append(f"manifesti: {e}"[:200])
        try:
            _state["ext"] = _pull_ext()
        except Exception as e:
            err.append(f"{EXT_FILE}: {e}"[:200])
        try:
            from . import stock
            stock.restore_sets()                       # pazuduši komplekti no OneDrive mapes (tad arī uz Drive)
        except Exception as e:
            err.append(f"komplekti: {e}"[:200])
        try:
            _state["uploaded"] += _backfill()
        except Exception as e:
            err.append(f"augšupielāde: {e}"[:200])
        for m in err:
            print("Google Drive:", m)
        _state.update(at=time.strftime("%Y-%m-%d %H:%M"), error="; ".join(err))
    return {"ok": not err, **_state}


def status() -> dict:
    return dict(_state, google=connected())


def start() -> None:
    def loop():
        time.sleep(45)
        while True:
            try:
                refresh()
            except Exception as e:
                print("Google Drive fonā:", str(e)[:200])
            time.sleep(EVERY)
    threading.Thread(target=loop, daemon=True, name="drive").start()


# --------------------------------------------------------------------------- agenturas_bildes.json (dati §8c)

AG_MAP = {"envato_market": "envato"}


def ext_data() -> dict:
    global _ext_cache
    p = Path(config.app_dir()) / EXT_FILE
    try:
        m = p.stat().st_mtime
    except OSError:
        return {}
    if _ext_cache and _ext_cache[0] == m:
        return _ext_cache[1]
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    _ext_cache = (m, d)
    return d


def ext_index() -> tuple[dict, dict]:
    """({stem: {aģentūra: {status, seen}}}, {orig_file(lower): tas pats})."""
    by_stem, by_orig = {}, {}
    rank = {"accepted": 5, "review": 4, "changes": 3, "other": 2, "rejected": 1}
    for im in ext_data().get("images") or []:
        ags = {}
        for a, v in (im.get("agencies") or {}).items():
            a = AG_MAP.get(a, a)
            v = {"status": str((v or {}).get("status") or "other"), "seen": str((v or {}).get("seen") or "")}
            if a not in ags or rank.get(v["status"], 2) > rank.get(ags[a]["status"], 2):
                ags[a] = v
        if not ags:
            continue
        if im.get("stem"):
            by_stem[str(im["stem"])] = ags
        if im.get("orig_file"):
            by_orig[str(im["orig_file"]).lower()] = ags
    return by_stem, by_orig
