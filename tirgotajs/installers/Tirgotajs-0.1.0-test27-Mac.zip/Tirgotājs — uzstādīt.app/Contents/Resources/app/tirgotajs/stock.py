"""Krājums: gatavās bildes (no Vārdotāja manifestiem) × aģentūras, prasību pārbaude un iesniegumu uzskaite.

Avots — iesniegšanai gatavo bilžu mape (Vārdotājs 0.9.0-test9+: <gads>/<YYYY-MM>_<Sērija>_<kods>/RF|ED/), katrā bilžu
mapē .fotostokeris/<sērija>.json (+ -sikteli.zip). Moduļi viens otru neimportē — tikai dati (noteikumi §10, dati §7a).
Komplekti pēc pārvietošanas (move.py) dzīvo komplektu mapē (OneDrive `STOCK/<gads>/<MM-mēn>/<nedēļa>/<KAT-tēma-N>`) ar savu
.fotostokeris/<komplekts>.json — scan() lasa abas mapes.
Uzskaite — ledger.json Tirgotāja datu mapē: {stem: {aģentūra: {"state", "at", "reason", "set", "hist": [...]}}}; stem = faila nosaukums bez
paplašinājuma (pēc Vārdotāja pārdēvēšanas tas ir unikāls: <kods>_<oriģinālais>).
"""
from __future__ import annotations

import glob
import json
import os
import re
import threading
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from . import config

SUB = "_fotostokeris"                 # lēmums 2026-11-05: bez punkta (Synology Drive u.c. mapes ar punktu nesinhronizē)
SUBS = ("_fotostokeris", ".fotostokeris")   # lasa abas (vecās — ar punktu)
STATES = ("uploaded", "submitted", "accepted", "rejected", "skip")   # uploaded = augšupielādēts ar FTP, portālā vēl jāspiež "Submit"     # "" = vēl nav iesniegts; "skip" = lietotājs: neder šai aģentūrai

# Aģentūras, kurās Tirgotājs palīdz iesniegt (Bigstock jaunu saturu vairs nepieņem — docs/tirgotajs-iesniegsana.md)
AGENCIES = [
    {"id": "adobe", "name": "Adobe Stock", "url": "https://contributor.stock.adobe.com/", "ftp": "SFTP*"},
    {"id": "shutterstock", "name": "Shutterstock", "url": "https://submit.shutterstock.com/", "ftp": "FTPS", "limit": [500, 7]},
    {"id": "istock", "name": "iStock / Getty", "url": "https://esp.gettyimages.com/", "ftp": ""},
    {"id": "alamy", "name": "Alamy", "url": "https://www.alamy.com/myupload/Index.aspx", "ftp": "FTP"},
    {"id": "dreamstime", "name": "Dreamstime", "url": "https://www.dreamstime.com/upload", "ftp": "FTP"},
    {"id": "depositphotos", "name": "Depositphotos", "url": "https://depositphotos.com/", "ftp": "FTP"},
    {"id": "123rf", "name": "123RF", "url": "https://www.123rf.com/contributor/", "ftp": "FTP"},
    {"id": "pond5", "name": "Pond5", "url": "https://www.pond5.com/", "ftp": "FTP"},
    {"id": "envato", "name": "Envato", "url": "https://portfolio.author.envato.com/", "ftp": ""},
    {"id": "magnific", "name": "Magnific", "url": "https://contributor.magnific.com/dashboard", "ftp": "FTP*", "limit": [200, 30]},
    {"id": "pixta", "name": "PIXTA", "url": "https://pixtastock.com/", "ftp": ""},
    # 2026-11-04 (lietotājs): arī Zoonar un Ingram (Analītiķa aģentūras); FTP adrese — no konta, kad lietotājs to atsūtīs
    {"id": "zoonar", "name": "Zoonar", "url": "https://www.zoonar.com/", "ftp": "FTPS"},
    {"id": "ingram", "name": "Ingram", "url": "https://www.ingramportal.com/", "ftp": "FTP*"},
]
AG_IDS = [a["id"] for a in AGENCIES]

# FTP noklusējumi no izpētes (docs/tirgotajs-iesniegsana.md); host "" — adrese jāņem no aģentūras konta
FTP_DEF = {
    "adobe": {"proto": "sftp", "host": "sftp.contributor.adobestock.com", "port": 22, "note": "ftp_n_adobe"},
    "shutterstock": {"proto": "ftps", "host": "ftps.shutterstock.com", "port": 21, "note": "ftp_n_login"},
    "alamy": {"proto": "ftp", "host": "upload.alamy.com", "port": 21, "note": "ftp_n_login", "dir": "Stock"},
    "dreamstime": {"proto": "ftp", "host": "upload.dreamstime.com", "port": 21, "note": "ftp_n_dreamstime"},
    "depositphotos": {"proto": "ftp", "host": "ftp.depositphotos.com", "port": 21, "note": "ftp_n_account"},
    "123rf": {"proto": "ftp", "host": "ftp.123rf.com", "port": 21, "note": "ftp_n_login"},
    "pond5": {"proto": "ftp", "host": "ftp.pond5.com", "port": 21, "note": "ftp_n_pond5"},
    "zoonar": {"proto": "ftps", "host": "ftp.zoonar.com", "port": 21, "note": "ftp_n_zoonar"},   # lietotājs 2026-11-04: explicit TLS, passive
    "ingram": {"proto": "ftp", "host": "", "port": 21, "note": "ftp_n_ingram"},   # pieejas dati — jāprasa Ingram; mape Contributor_Folder_XXXXXX
    "magnific": {"proto": "sftp", "host": "contributor-ftp.magnific.com", "port": 60022, "note": "ftp_n_magnific"},   # lietotājs 2026-11-04
}


def conn(ag: str) -> dict:
    """Aģentūras pieslēgums (iestatījums sub_conn): {mode: portal|ftp, url, proto, host, port}."""
    c = dict(((config.get("sub_conn") or {}).get(ag)) or {})
    base = next((a for a in AGENCIES if a["id"] == ag), {})
    d = FTP_DEF.get(ag) or {}
    c["mode"] = c.get("mode") if c.get("mode") in ("portal", "ftp") and (c.get("mode") != "ftp" or d) else "portal"
    url = str(c.get("url") or "").strip()
    c["url"] = url if re.match(r"^https?://", url) else base.get("url", "")
    for k in ("proto", "host", "port", "dir"):
        if not c.get(k) and d.get(k):
            c[k] = d[k]
    c["host"] = clean_host(c.get("host"))
    return c


def clean_host(h) -> str:
    """Aģentūru lapās adrese mēdz būt ar priedēkli (sftp://contributor-ftp.magnific.com) — atstāj tikai servera vārdu."""
    h = re.sub(r"^[a-z]+://", "", str(h or "").strip(), flags=re.I)
    return h.split("/")[0].strip()


def portal_urls() -> set:
    return {a["url"] for a in AGENCIES} | {conn(a)["url"] for a in AG_IDS}

_lock = threading.RLock()
_ledger: config.JsonStore | None = None
_specs: dict | None = None
_zips: dict[str, str] = {}            # sērijas atslēga → sīktēlu zip ceļš (sīktēlu GET adresei)
_alt: dict[str, str] = {}             # stem → cits zip (Manifesti kopija), ja sērijas zip šīs bildes nav
_paths: dict[str, str] = {}           # stem → bildes ceļš (lielajam skatam GET /full)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def ledger() -> config.JsonStore:
    global _ledger
    if _ledger is None:
        _ledger = config.JsonStore(config.app_dir() / "ledger.json", {})
    return _ledger


def specs() -> dict:
    global _specs
    if _specs is None:
        p = Path(__file__).resolve().parent.parent / "core" / "agency_specs.json"
        if not p.is_file():
            p = Path(__file__).resolve().parent.parent.parent / "core" / "agency_specs.json"   # izstrādē
        try:
            _specs = json.loads(p.read_text(encoding="utf-8")).get("agencies") or {}
        except Exception:
            _specs = {}
    return _specs


def agencies() -> list[dict]:
    """Aģentūras, ko rādīt: Tirgotāja izvēle → kopīgās mērķa aģentūras → visas."""
    sel = config.get("sub_agencies") or []
    if not sel:
        tgt = config.get("target_agencies") or []
        sel = [a for a in tgt if a in AG_IDS]
    ids = [a for a in AG_IDS if a in sel] if sel else AG_IDS
    out = []
    for a in AGENCIES:
        if a["id"] in ids:
            c = conn(a["id"])
            out.append({**a, "url": c["url"], "mode": c["mode"]})
    return out


# --------------------------------------------------------------------------- bilžu saraksts no manifestiem

IMG_EXT = (".jpg", ".jpeg", ".tif", ".tiff", ".png")


def _manifests(root: str, files: dict | None = None):
    """Sērijas manifesti `.fotostokeris/*.json`; files — {faila nosaukums: ceļš} visām bildēm (rezerves meklēšanai)."""
    for d, dirs, fl in os.walk(root):
        base = os.path.basename(d)
        if base in SUBS:
            dirs[:] = []
            for f in sorted(fl):
                if f.endswith(".json") and not f.endswith(".tmp"):
                    yield os.path.dirname(d), os.path.join(d, f)
            continue
        if files is not None:
            for f in fl:
                if f.lower().endswith(IMG_EXT):
                    files.setdefault(f, os.path.join(d, f))
        dirs[:] = [x for x in dirs if x in SUBS or (not x.startswith(".") and x.lower() != "manifesti")]


_said: set[str] = set()


def _say(m: str) -> None:
    """Žurnālā katru skenēšanas piezīmi vienreiz (ne pie katra "Atjaunot")."""
    if m not in _said:
        _said.add(m)
        print("skenēšana:", m)


def _shared_manifests(root: str):
    """Kopīgā `<gatavo mape>/Manifesti/*.json` (Vārdotāja kopijas) — rezerve sērijām, kuru mapē `.fotostokeris` nav
    (2026-11-05: Vārdotājs sērijai bez RF/ED apakšmapes manifestu mapē neuzrakstīja, bija tikai kopija)."""
    d = os.path.join(root, "Manifesti")
    if not os.path.isdir(d):
        return
    for f in sorted(os.listdir(d)):
        if f.endswith(".json") and not f.endswith(".tmp"):
            yield os.path.join(d, f)


def _roots() -> list[str]:
    """Gatavo bilžu mape + komplektu mape (ja nav viena otrā)."""
    out = []
    for r in (str(config.get("sub_ready_dir") or "").strip(), set_dir()):
        if not r or not os.path.isdir(r):
            continue
        rr = os.path.realpath(r)
        if any(rr == x or rr.startswith(x + os.sep) for x in map(os.path.realpath, out)):
            continue
        out = [x for x in out if not os.path.realpath(x).startswith(rr + os.sep)] + [r]
    return out


def _drive_manifests() -> list[str]:
    """Manifesti no Google Drive (drive.py lejupielādē datu mapē `Manifesti-drive/`) — tikai sērijas (ne komplekti)."""
    d = Path(config.app_dir()) / "Manifesti-drive"
    try:
        return [str(d / f) for f in sorted(os.listdir(d)) if f.endswith(".json") and not f.startswith("_")]
    except OSError:
        return []


_ED_RE = re.compile(r"^[^:\n]{3,90}\b(19|20)\d{2}\s*:")


def ed_text(desc, prefix=None) -> bool:
    """Apraksts sākas kā ED paraksts ("RIGA, LATVIA – MAY 4, 2024: …", "OCTOBER 4, 2025: …") — RF bildei tas nozīmē, ka
    Vārdotājs kategoriju noteica pēc mapes, lai gan bilde aprakstīta kā ED (lietotājs 2026-11-10; NODOSANA 6g)."""
    d = str(desc or "").strip()
    if not d:
        return False
    if prefix and d.startswith(str(prefix).strip()):
        return True
    return bool(_ED_RE.match(d))


def scan() -> dict:
    root = str(config.get("sub_ready_dir") or "").strip()
    drv = _drive_manifests()
    if not root and not drv:
        return {"ok": True, "items": [], "series": [], "no_dir": True}
    if root and not os.path.isdir(root):
        if not drv:
            return {"ok": False, "error": "dir_missing", "dir": root, "items": [], "series": []}
        _say(f"gatavo mape {root} nav pieejama — rāda tikai Google Drive manifestus")
        root = ""
    items, series = [], []
    seen: set[str] = set()
    seen_at: dict[str, str] = {}
    seen_orig: set[str] = set()
    seen_ph: set[tuple] = set()
    sids: set[str] = set()
    files: dict[str, str] = {}
    _zips.clear()
    _alt.clear()
    # komplektu mape (OneDrive) PIRMĀ: ja tā pati bilde vēl ir arī gatavo mapē (piem. Mac Synology kopija vēl nav
    # izdzēsta, 2026-11-05), noteicošā ir komplekta mape — citādi komplekts rādās "vēl gatavo mapē"
    sd = set_dir()
    roots = sorted(_roots(), key=lambda r: 0 if sd and os.path.realpath(r) == os.path.realpath(sd) else 1)
    found = [m for r in roots for m in _manifests(r, files)]
    shared = []
    for jp in (_shared_manifests(root) if root else []):                    # kopijas — tikai sērijām, kuru mapē manifesta nav
        shared.append((None, jp))
        z = jp[:-5] + "-sikteli.zip"                      # sīktēli no kopijas — arī komplektiem, kuru zip tos nesaņēma (test15)
        if os.path.isfile(z):
            try:
                for i in json.loads(Path(jp).read_text(encoding="utf-8")).get("images") or []:
                    st = i.get("stem") or os.path.splitext(i.get("file") or "")[0]
                    if st:
                        _alt.setdefault(st, z)
            except Exception:
                pass
    skipped = []

    def take(folder, jpath, data, zpath, remote_ok=False):
        key = f"s{len(series)}"
        if zpath and os.path.isfile(zpath):
            _zips[key] = zpath
        n = 0
        for it in data.get("images") or []:
            if it.get("status") == "moved" or not it.get("file"):
                continue
            p = os.path.join(folder, it["file"]) if folder else ""
            if not (p and os.path.isfile(p)):
                p = it.get("path") if it.get("path") and os.path.isfile(it.get("path")) else files.get(it["file"], "")
            remote = False
            if not p or not os.path.isfile(p):
                if not remote_ok:
                    continue
                p, remote = "", True                      # Drive manifests: bilde ir NAS, šajā datorā nav (test21)
            stem = it.get("stem") or os.path.splitext(it["file"])[0]
            okey = str(it.get("orig_file") or it["file"]).lower()
            if remote and (okey in seen_orig or (it.get("phash") and (it["phash"], it.get("taken_at")) in seen_ph)):
                continue                    # tā pati bilde ar citu nosaukumu (Vārdotāja darba mapes manifests; test22)
            if stem in seen:
                if p and os.path.normcase(p) != os.path.normcase(seen_at.get(stem, p) or p):
                    _say(f"bilde {it['file']} ir divās vietās — ņemta {os.path.dirname(seen_at[stem])}, otra {os.path.dirname(p)}")
                continue
            seen_at[stem] = p
            seen.add(stem)
            seen_orig.add(okey)
            if it.get("phash"):
                seen_ph.add((it["phash"], it.get("taken_at")))
            try:
                size = os.path.getsize(p) if p else int(it.get("bytes") or 0)
            except (OSError, ValueError, TypeError):
                size = 0
            n += 1
            if remote and zpath and os.path.isfile(zpath):
                _alt.setdefault(stem, zpath)
            cat = it.get("category") or "RF"
            edw = cat == "RF" and ed_text(it.get("description"), it.get("ed_prefix"))
            items.append({
                **({"remote": True} if remote else {}),
                **({"edwarn": True} if edw else {}),
                "stem": stem, "file": it["file"], "orig": it.get("orig_file") or it["file"], "path": p,
                "folder": os.path.dirname(p) if p else "", "series": key, "cat": cat, "ready": it.get("status") == "ready",
                "title": it.get("title") or "", "kw": len(it.get("keywords") or []), "hint": str(it.get("hint") or "")[:80],
                "w": int(it.get("width") or 0), "h": int(it.get("height") or 0), "size": size,
                "ext": os.path.splitext(it["file"])[1].lower().lstrip("."), "taken": it.get("taken_at") or "",
                "thumb": True, "phash": it.get("phash") or "", "jpath": jpath, "zpath": _zips.get(key) or _alt.get(stem, ""),
                "src_name": it.get("series_name") or data.get("name") or "",
                "kwtext": "|".join(str(k).lower() for k in it.get("keywords") or [])})
        if n:
            f0 = folder or os.path.dirname(next((i["path"] for i in items if i["series"] == key and i["path"]), "") or "")
            series.append({"key": key, "name": data.get("name") or os.path.basename(f0),
                           "code": data.get("series_code") or "", "folder": f0, "count": n,
                           **({"set": data["set_id"]} if data.get("set_id") else {}),
                           **({"remote": True} if not f0 else {})})
        return n

    for folder, jpath in found + shared:
        try:
            data = json.loads(Path(jpath).read_text(encoding="utf-8"))
        except Exception as e:
            skipped.append(f"{jpath}: nevar nolasīt ({type(e).__name__})")
            continue
        sid = str(data.get("series_id") or "")
        if folder is None:                                # kopija no Manifesti/
            z = jpath[:-5] + "-sikteli.zip"
            if sid and sid in sids:
                continue
            if take(None, jpath, data, z):
                _say(f"sērija '{data.get('name')}' — manifests tikai mapē Manifesti (sērijas mapē nav _fotostokeris)")
            if sid:
                sids.add(sid)
            continue
        if sid:
            sids.add(sid)
        z = os.path.join(os.path.dirname(jpath), data.get("thumbs") or "") if data.get("thumbs") else ""
        if not take(folder, jpath, data, z):
            skipped.append(f"{jpath}: nav atrastu bilžu")
    # Google Drive manifesti (test21): bildes, kas vēl nav redzētas — arī tās, kuru šajā datorā nav ("uz NAS")
    nrem = 0

    def _renamed(jp):                       # vispirms manifesti ar pārdēvētām bildēm (NAS), tad darba mapes kopijas
        try:
            d = json.loads(Path(jp).read_text(encoding="utf-8"))
        except Exception:
            return 1
        return 0 if d.get("series_code") or any(i.get("orig_file") and i.get("orig_file") != i.get("file")
                                                for i in d.get("images") or []) else 1
    for jp in sorted(drv, key=_renamed):
        try:
            data = json.loads(Path(jp).read_text(encoding="utf-8"))
        except Exception:
            continue
        if data.get("kind") == "set" or data.get("set_id"):
            continue                                      # komplekti — tās pašas bildes (dati §7a (c) 2. punkts)
        if _renamed(jp):                                  # 1 = nav pārdēvētu bilžu / sērijas koda
            _say(f"Google manifests {os.path.basename(jp)} — sērija vēl pie Vārdotāja (nav nodota \"Uz iesniegšanu\"), neņem")
            continue                                      # test23: darba mapes manifests ≠ NAS (bildes vēl nav iesniegšanai)
        before = len(items)
        take(None, jp, data, jp[:-5] + "-sikteli.zip", remote_ok=True)
        nrem += sum(1 for it in items[before:] if it.get("remote"))
    if nrem:
        _say(f"{nrem} bildes no Google Drive manifestiem šajā datorā nav (uz NAS)")
    for m in skipped[:20]:
        _say(m)
    _paths.clear()
    _paths.update({it["stem"]: it["path"] for it in items if it["path"]})
    return {"ok": True, "items": items, "series": series}


# --------------------------------------------------------------------------- prasību pārbaude (core/agency_specs.json)

def check(it: dict, ag: str) -> list[list]:
    """Iemesli, kāpēc bilde neder aģentūrai: [[atslēga, {vērtības}], …] (teksti — saskarnē)."""
    out = []
    cat = it.get("cat") or "RF"
    if cat in ("ED", "EDI"):
        ed = config.get("sub_ed_agencies")
        ed = ed if isinstance(ed, list) else []
        edi = config.get("sub_edi_agencies")
        edi = edi if isinstance(edi, list) else []
        if cat == "ED" and ag not in ed:                       # parasts ED — tikai, kur atzīmēts ED
            out.append(["r_ed", {}])
        elif cat == "EDI" and ag not in ed and ag not in edi:  # EDI — kur atzīmēts ED vai EDI
            out.append(["r_edi", {}])
    s = specs().get(ag) or {}
    if cat in ("ED", "EDI") and s.get(cat.lower()) is False and not out:    # aģentūra pati nepieņem (piem. Ingram)
        out.append(["r_ed_ag", {}])
    ext = {"jpeg": "jpg", "tiff": "tif"}.get(it["ext"], it["ext"])
    fm = s.get("formats")
    if fm and ext not in fm:
        out.append(["r_fmt", {"f": ext.upper(), "ok": ", ".join(x.upper() for x in fm)}])
    mb = it["size"] / 1048576                                  # 0 = nezināms (Drive manifests bez `bytes`)
    if s.get("max_mb") and mb > s["max_mb"]:
        out.append(["r_big", {"mb": round(mb, 1), "max": s["max_mb"]}])
    if s.get("min_mb") and it["size"] and mb < s["min_mb"]:
        out.append(["r_small_mb", {"mb": round(mb, 1), "min": s["min_mb"]}])
    w, h = it["w"], it["h"]
    if w and h:
        mp = w * h / 1e6
        if s.get("min_mp") and mp < s["min_mp"]:
            out.append(["r_min_mp", {"mp": round(mp, 1), "min": s["min_mp"]}])
        if s.get("max_mp") and mp > s["max_mp"]:
            out.append(["r_max_mp", {"mp": round(mp, 1), "max": s["max_mp"]}])
        if s.get("min_side_px") and min(w, h) < s["min_side_px"]:
            out.append(["r_side", {"px": min(w, h), "min": s["min_side_px"]}])
        if s.get("min_long_px") and max(w, h) < s["min_long_px"]:
            out.append(["r_long_min", {"px": max(w, h), "min": s["min_long_px"]}])
        if s.get("max_long_px") and max(w, h) > s["max_long_px"]:
            out.append(["r_long_max", {"px": max(w, h), "max": s["max_long_px"]}])
    return out


def listing() -> dict:
    r = scan()
    led = ledger().data
    ags = agencies()
    mem: dict[str, list] = {}
    for x in sets_store().data.values():
        for st in x.get("stems") or []:
            mem.setdefault(st, []).append(x.get("id"))
    r["sets"] = [{"id": x.get("id"), "name": x.get("name")} for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True)]
    plan = {st: x["planned"] for x in sets_store().data.values() if x.get("planned") for st in x.get("stems") or []}
    from . import drive
    ext_s, ext_o = drive.ext_index()
    for it in r["items"]:
        it["in_sets"] = mem.get(it["stem"], [])
        if it["stem"] in plan:
            it["planned"] = plan[it["stem"]]
        rec = led.get(it["stem"]) or {}
        ext = ext_s.get(it["stem"]) or ext_o.get(str(it.get("orig") or "").lower()) or {}
        cells = {}
        for a in ags:
            c = dict(rec.get(a["id"]) or {})
            bad = check(it, a["id"])
            if bad:
                c["bad"] = bad
            if ext.get(a["id"]) and not c.get("state"):
                c["ext"] = ext[a["id"]]                   # jau aģentūrā (Analītiķis, dati §8c) — nepiedāvā
            cells[a["id"]] = c
        it["cells"] = cells
    # ierakstiem uzskaitē, kuru bilžu mapē vairs nav (pārvietotas / dzēstas) — tikai skaits
    have = {it["stem"] for it in r["items"]}
    r["gone"] = sum(1 for s in led if s not in have)
    r["agencies"] = ags
    return r


HIST = 30


def _set_of(stem: str) -> str:
    """Jaunākais komplekts, kurā ir bilde."""
    best = ("", "")
    for x in sets_store().data.values():
        if stem in (x.get("stems") or []) and x.get("created", "") >= best[0]:
            best = (x.get("created", ""), x.get("id", ""))
    return best[1]


def mark(stems: list, ag: str, state: str, reason: str = "", set_id: str = "") -> int:
    """Atzīme ar vēsturi: iepriekšējais stāvoklis pāriet uz "hist" (kas, kad, kurā komplektā)."""
    if ag not in AG_IDS or (state and state not in STATES):
        raise ValueError("bad state")
    st = ledger()
    n = 0
    with st.lock:
        for s in stems:
            rec = st.data.setdefault(str(s), {})
            old = rec.get(ag) or {}
            hist = list(old.get("hist") or [])
            if old.get("state"):
                hist.append({k: v for k, v in old.items() if k != "hist"})
            if state:
                sid = set_id or _set_of(str(s))
                rec[ag] = {"state": state, "at": _now(), **({"reason": reason} if reason else {}),
                           **({"set": sid} if sid else {}), **({"hist": hist[-HIST:]} if hist else {})}
            elif hist:
                rec[ag] = {"state": "", "at": _now(), "hist": hist[-HIST:]}     # atzīme noņemta — vēsture paliek
            else:
                rec.pop(ag, None)
            if not rec:
                st.data.pop(str(s), None)
            n += 1
        st.save()
    return n


def ledger_merge(base, local, remote):
    """Sinhronizācija (lēmums 2026-11-05): katrai bildei × aģentūrai uzvar jaunākā atzīme (`at`); otras puses atzīme
    pāriet vēsturē — nekas svaigāks netiek pārrakstīts. Ja atzīme vienā pusē izdzēsta (pārējā nemainīta) — dzēsta."""
    base, local, remote = base or {}, local or {}, remote or {}
    out = {}
    for stem in set(local) | set(remote):
        l, r, b = local.get(stem) or {}, remote.get(stem) or {}, base.get(stem) or {}
        rec = {}
        for ag in set(l) | set(r):
            x, y, z = l.get(ag), r.get(ag), b.get(ag)
            if x is None or y is None:
                one = x if y is None else y
                if z is not None and one == z:
                    continue                              # otrā datorā noņemta
                rec[ag] = one
                continue
            win, lose = (x, y) if str(x.get("at") or "") >= str(y.get("at") or "") else (y, x)
            hist, seen = [], set()
            for h in (win.get("hist") or []) + (lose.get("hist") or []) + ([{k: v for k, v in lose.items() if k != "hist"}] if lose.get("state") else []):
                key = (h.get("state"), h.get("at"))
                if key in seen or key == (win.get("state"), win.get("at")):
                    continue
                seen.add(key)
                hist.append(h)
            hist.sort(key=lambda h: str(h.get("at") or ""))
            w = {k: v for k, v in win.items() if k != "hist"}
            if hist:
                w["hist"] = hist[-HIST:]
            rec[ag] = w
        if rec:
            out[stem] = rec
    return out


# --------------------------------------------------------------------------- komplekti (kopsavilkums §3 "Komplekts")
# Komplekts = vienas kategorijas bilžu kopa iesniegšanai visās piemērotajās aģentūrās vienā reizē. Gandrīz vienādas bildes
# (phash attālums ≤ 6, kā Vārdotājā) vienā komplektā nekad; vienas sērijas dažādi kadri — drīkst.
SIMILAR = 6
_sets: config.JsonStore | None = None


def sets_store() -> config.JsonStore:
    global _sets
    if _sets is None:
        _sets = config.JsonStore(config.app_dir() / "sets.json", {})   # {id: komplekts} — vārdnīca, lai sinhronizācija apvieno pa ierakstiem
        ch = False                                                       # vecie nosaukumi → ar licenci priekšā (mapes neaiztiek)
        for x in _sets.data.values():
            cat = x.get("cat") or "RF"
            if not str(x.get("name") or "").upper().startswith(cat + "-"):
                x["name"] = set_name(x.get("name") or "", cat) or f"{cat}-{str(x.get('created', ''))[:10]}"
                ch = True
        if ch:
            _sets.save()
    return _sets


def _ham(a: str, b: str) -> int:
    try:
        return bin(int(a, 16) ^ int(b, 16)).count("1")
    except (TypeError, ValueError):
        return 99


def _todo(it: dict, ags: list) -> bool:
    """Vai bilde vēl jāiesniedz vismaz vienā aģentūrā (nav atzīmes un der pēc prasībām)."""
    return any(not (c := it["cells"].get(a) or {}).get("state") and not c.get("bad") and not c.get("ext") for a in ags)


def _cat_ok(it: dict, cat: str) -> bool:
    return (it.get("cat") or "RF") == (cat if cat in ("RF", "ED", "EDI") else "RF")     # komplektā viena kategorija


def _matcher(match: str, r: dict):
    """Meklēšana (AI asistents): vārdi sērijas nosaukumā, mapē, virsrakstā, atslēgvārdos, faila nosaukumā."""
    words = [w for w in re.findall(r"[\wāčēģīķļņšūž]+", (match or "").lower()) if len(w) > 1]
    if not words:
        return None
    names = {s["key"]: (s["name"] + " " + s.get("code", "")).lower() for s in r["series"]}

    def text(it):
        return " ".join([names.get(it["series"], ""), it["folder"].lower(), it["title"].lower(), it.get("kwtext", ""),
                         it["file"].lower(), it["orig"].lower()])
    return words, text


GAP_S = 1800      # jauns laika klasteris, ja starp kadriem > 30 min


def _ts(it: dict) -> float:
    try:
        return datetime.fromisoformat(str(it.get("taken") or "")[:19]).timestamp()
    except ValueError:
        return 0.0


def clusters(items: list) -> dict:
    """Bilžu grupas "viena vieta un laiks" (dažādai atlasei, lēmums 2026-11-05 16:27): sērija + vieta (`hint`) +
    laika klasteris (> 30 min starpība = jauns). {stem: klastera id}."""
    out, last = {}, {}
    for it in sorted(items, key=lambda i: (i["series"], i.get("hint") or "", _ts(i), i["file"])):
        k = (it["series"], (it.get("hint") or "").lower())
        t = _ts(it)
        prev = last.get(k)
        if prev is None or (t and prev[1] and t - prev[1] > GAP_S):
            prev = (f"{k[0]}|{k[1]}|{len(out)}", t)
        last[k] = (prev[0], t or prev[1])
        out[it["stem"]] = prev[0]
    return out


def _candidates(r: dict, cat: str, excl: set, only: set | None = None) -> list:
    ags = [a["id"] for a in r["agencies"]]
    in_sets = {st for x in sets_store().data.values() for st in x.get("stems") or []}
    return [it for it in r["items"] if _cat_ok(it, cat) and it["stem"] not in in_sets and it["stem"] not in excl
            and (only is None or it["stem"] in only) and _todo(it, ags)
            and not it.get("edwarn")]                      # "RF ar ED aprakstu" — automātiski RF komplektos neliek (6g)


def _filter(cand: list, match: str, r: dict) -> list:
    m = _matcher(match, r)
    if not m:
        return cand
    words, text = m
    allw = [it for it in cand if all(w in text(it) for w in words)]
    return allw or [it for it in cand if any(w in text(it) for w in words)]


def _round_robin(cand: list) -> list:
    """Pa vienai bildei no katras grupas (vieta + laiks) pēc kārtas — komplektā dažādas vietas, ne viss no vienas."""
    cl = clusters(cand)
    groups: dict[str, list] = {}
    for it in sorted(cand, key=lambda i: (_ts(i), i["file"])):
        groups.setdefault(cl[it["stem"]], []).append(it)
    order = sorted(groups.values(), key=lambda g: (-len(g), _ts(g[0])))
    out, i = [], 0
    while any(order):
        for g in order:
            if i < len(g):
                out.append(g[i])
        i += 1
        if all(i >= len(g) for g in order):
            break
    return out


def pretty(name: str) -> str:
    """Sērijas nosaukums cilvēkam: "2026-09_Bali_a1b2" → "Bali"."""
    s = re.sub(r"^\d{4}[-._]\d{2}([-._]\d{2})?[_\s-]*", "", str(name or ""))
    s = re.sub(r"[_-][0-9a-f]{4,6}$", "", s)
    s = re.sub(r"[_-](RF|ED|EDI)$", "", s, flags=re.I)
    return s.replace("_", " ").strip() or str(name or "")


def pool(cat: str, match: str = "", topics: list | None = None, limit: int = 120, exclude: list | None = None,
         r: dict | None = None) -> list:
    """Kandidāti AI redaktoram: dažāda secība (pa vienai no katras vietas/laika grupas), no katras līdzīgo grupas tikai
    viena, ne vairāk par `limit`."""
    from . import similar
    r = r or listing()
    base = _candidates(r, cat, set(exclude or []))
    topics = [t for t in (topics or []) if str(t).strip()][:8]
    lists = [_round_robin(_filter(base, t, r)) for t in topics] if topics else [_round_robin(_filter(base, match, r))]
    out, got = [], set()
    i = 0
    while len(out) < limit and any(i < len(l) for l in lists):
        for l in lists:
            if i < len(l) and l[i]["stem"] not in got:
                it = l[i]
                got.add(it["stem"])
                if not any(similar.similar(it, c, _zips) for c in out if c["series"] == it["series"]):
                    out.append(it)
        i += 1
    return out[:limit]


def themes(cat: str = "", r: dict | None = None) -> list:
    """Neiesniegto, komplektos vēl neiekļauto bilžu tēmas (sērija + vieta) — Plānam un asistentam."""
    r = r or listing()
    names = {s["key"]: s["name"] for s in r["series"]}
    cand = [it for c in ([cat] if cat else ["RF", "ED", "EDI"]) for it in _candidates(r, c, set())]
    out: dict[tuple, dict] = {}
    for it in cand:
        k = (it["series"], (it.get("hint") or "").strip().lower(), it.get("cat") or "RF")
        x = out.setdefault(k, {"key": "|".join(k), "series": it["series"], "name": names.get(it["series"], ""),
                               "hint": (it.get("hint") or "").strip(), "cat": k[2], "stems": [], "newest": ""})
        x["stems"].append(it["stem"])
        x["newest"] = max(x["newest"], it.get("taken") or "")
    lst = list(out.values())
    for x in lst:
        x["n"] = len(x["stems"])
        x["thumb"] = x["stems"][0]
        x["title"] = x["hint"] or pretty(x["name"])
    lst.sort(key=lambda x: -x["n"])
    return lst


def suggest(cat: str = "RF", size: int = 0, exclude: list | None = None, match: str = "", have: list | None = None,
            topics: list | None = None, only: list | None = None, r: dict | None = None) -> dict:
    """Ieteikums: neiesniegtās bildes, viena kategorija; dažāda atlase — pa vienai no katras vietas/laika grupas pēc
    kārtas; `topics` — vairākas tēmas ar vienādu kvotu (trūkumu piepilda citas). Līdzīgās (similar.py) vienā komplektā
    nekad — no grupas paliek pirmā, pārējās atliktas (groups). have — jau komplektā esošās (pievienojot "vēl")."""
    from . import similar
    r = r or listing()
    excl = set(exclude or []) | set(have or [])
    by = {it["stem"]: it for it in r["items"]}
    base = _candidates(r, cat, excl, set(only) if only is not None else None)
    topics = [t for t in (topics or []) if str(t).strip()][:8]
    if topics:
        lists = [_round_robin(_filter(base, t, r)) for t in topics]
        cand_all = {it["stem"] for l in lists for it in l}
    else:
        lists = [_round_robin(_filter(base, match, r))]
        cand_all = {it["stem"] for it in lists[0]}
    todo = len(cand_all)
    auto = max(10, min(50, -(-todo // 20))) if todo else 0      # vienmērīga plūsma: ~20 darba dienās (1 mēnesis)
    size = int(size or 0) or auto
    seed = [by[s] for s in (have or []) if s in by]
    chosen, groups, nsim, got = [], {}, 0, set()
    counts = [0] * len(lists)
    quota = [size // len(lists) + (1 if i < size % len(lists) else 0) for i in range(len(lists))]

    def take(it, ti):
        nonlocal nsim
        if it["stem"] in got:
            return False
        like = next((c for c in seed + chosen if similar.similar(it, c, _zips)), None)
        got.add(it["stem"])
        if like:
            nsim += 1
            groups.setdefault(like["stem"], []).append({k: it[k] for k in ("stem", "file", "series", "thumb", "title")})
            return False
        chosen.append(it)
        counts[ti] += 1
        return True
    for ti, l in enumerate(lists):                       # katrai tēmai sava kvota
        for it in l:
            if counts[ti] >= quota[ti] or len(chosen) >= size:
                break
            take(it, ti)
    if len(chosen) < size:                               # trūkumu piepilda citas tēmas
        for ti, l in enumerate(lists):
            for it in l:
                if len(chosen) >= size:
                    break
                take(it, ti)
    out = [dict(it) for it in chosen]
    for it in out:
        it.pop("kwtext", None)
    return {"ok": True, "items": out, "similar": nsim, "groups": groups, "todo": todo, "auto": auto, "size": size,
            "agencies": r["agencies"], "match": match, "topics": topics,
            "topic_counts": dict(zip(topics, counts)) if topics else {}}


def set_name(name: str, cat: str) -> str:
    """Komplekta nosaukums ar licenci priekšā (lēmums 2026-11-04 20:23): "Bali" / "Bali RF" → "RF-Bali"."""
    cat = cat if cat in ("RF", "ED", "EDI") else "RF"
    n = re.sub(r"^\s*(RF|ED|EDI|RFR)\b[\s_-]*", "", str(name or ""), flags=re.I)
    n = re.sub(r"[\s_-]*\b(RF|ED|EDI|RFR)\s*$", "", n, flags=re.I).strip(" -_")
    return f"{cat}-{n}" if n else ""


def set_save(name: str, cat: str, stems: list) -> dict:
    st = sets_store()
    with st.lock:
        sid = f"k{int(datetime.now().timestamp() * 1000)}"
        n = sum(1 for x in st.data.values() if x.get("created", "")[:10] == _now()[:10] and x.get("cat") == cat) + 1
        rec = {"id": sid, "name": set_name(name, cat) or f"{cat}-{_now()[:10]}-{n}", "cat": cat, "created": _now(), "stems": list(stems)}
        st.data[sid] = rec
        st.save()
    return rec


def set_add(sid: str, stems: list) -> dict:
    """Atlasītās bildes pievieno esošam komplektam (tikai tās pašas kategorijas, ne jau citā komplektā)."""
    st = sets_store()
    r = listing()
    by = {it["stem"]: it for it in r["items"]}
    with st.lock:
        x = st.data.get(sid)
        if not x:
            raise ValueError("no_set")
        have = set(x.get("stems") or [])
        in_other = {s for k, y in st.data.items() if k != sid for s in y.get("stems") or []}
        add, skipped = [], 0
        for s in stems:
            it = by.get(s)
            if not it or s in have or s in in_other or (it.get("cat") or "RF") != (x.get("cat") or "RF"):
                skipped += 1
                continue
            add.append(s)
        x["stems"] = list(x.get("stems") or []) + add
        st.save()
    return {"ok": True, "added": len(add), "skipped": skipped, "name": x.get("name"), "moved": bool(x.get("rel"))}


def set_remove(sid: str, stems: list) -> dict:
    """Izņem bildes no komplekta (Atlasīt pašam). Jau OneDrive pārvietotam komplektam — nē (faili ir tā mapē)."""
    st = sets_store()
    with st.lock:
        x = st.data.get(sid)
        if not x:
            raise ValueError("no_set")
        if x.get("rel"):
            raise ValueError("moved")
        rm = set(stems)
        before = len(x.get("stems") or [])
        x["stems"] = [s for s in x.get("stems") or [] if s not in rm]
        st.save()
    return {"ok": True, "removed": before - len(x["stems"]), "name": x.get("name"), "left": len(x["stems"])}


def sim_check(stems: list) -> dict:
    """Atlasīto bilžu savstarpēja līdzība (Atlasīt pašam): {stem: [līdzīgie]}."""
    from . import similar
    by = {it["stem"]: it for it in scan()["items"]}
    its = [by[s] for s in stems if s in by][:200]
    out: dict[str, list] = {}
    for i, a in enumerate(its):
        for b in its[i + 1:]:
            if similar.similar(a, b, _zips):
                out.setdefault(a["stem"], []).append(b["stem"])
                out.setdefault(b["stem"], []).append(a["stem"])
    return out


def full_image(stem: str, size: int = 1800) -> bytes | None:
    """Lielais skats: oriģināls samazināts līdz `size` px (garākā mala), JPEG. Kešs ~40 bildes."""
    if stem in _full:
        return _full[stem]
    p = _paths.get(stem)
    if not p or not os.path.isfile(p):
        scan()
        p = _paths.get(stem)
    if not p or not os.path.isfile(p):
        return None
    try:
        import io
        from PIL import Image, ImageOps
        with Image.open(p) as im:
            im.draft("RGB", (size, size))
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((size, size))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=85)
        data = buf.getvalue()
    except Exception:
        return None
    _full[stem] = data
    while len(_full) > 40:
        _full.pop(next(iter(_full)))
    return data


_full: dict[str, bytes] = {}


def set_delete(sid: str) -> None:
    st = sets_store()
    with st.lock:
        x = st.data.pop(sid, None)
        st.save()
    if x and x.get("rel"):                     # mape OneDrive paliek — atceras, lai restore_sets to neliek atpakaļ
        from . import plan
        ps = plan.store()
        with ps.lock:
            ps.data.setdefault("gone", {})[sid] = _now()
            ps.save()


def restore_sets() -> int:
    """Komplekti, kuru mape ar manifestu ir komplektu mapē (OneDrive), bet ieraksta sarakstā nav (dzēsts, sinhronizācijas
    konflikts, cits dators) → atjauno no manifesta (lietotājs 2026-11-11 15:01). Apzināti izņemtos (plan.json `gone`) neliek."""
    base = set_dir()
    if not base or not os.path.isdir(base):
        return 0
    from . import plan
    gone = plan.store().data.get("gone") or {}
    st = sets_store()
    have = set(st.data)
    n = 0
    for sub in SUBS:
        for jp in glob.glob(os.path.join(glob.escape(base), "*", "*", "*", "*", sub, "*.json")):
            try:
                with open(jp, encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                continue
            sid = str(data.get("set_id") or (data.get("series_id") if data.get("kind") == "set" else "") or "")
            if not sid or sid in have or sid in gone:
                continue
            folder = os.path.dirname(os.path.dirname(jp))
            stems = [i.get("stem") for i in data.get("images") or [] if i.get("stem") and i.get("file")
                     and os.path.isfile(os.path.join(folder, i["file"]))]
            if not stems:
                continue
            cat = data.get("category") or "RF"
            rec = {"id": sid, "name": data.get("name") or os.path.basename(folder), "cat": cat,
                   "created": data.get("created") or _now(), "stems": stems,
                   "rel": os.path.relpath(folder, base).replace(os.sep, "/"), "moved_at": data.get("created") or _now(),
                   "restored": _now()}
            with st.lock:
                st.data[sid] = rec
                st.save()
            have.add(sid)
            n += 1
            print(f"atjaunots komplekts '{rec['name']}' no OneDrive mapes ({len(stems)} bildes; sarakstā tā nebija)")
    return n


DONE = ("submitted", "accepted", "rejected")


def set_status(x: dict, by: dict, ag: str) -> dict:
    """Komplekta stāvoklis aģentūrā: st = done (viss, kas der, iesniegts) | part | up (tikai augšupielādēts) | none |
    bad (nekas neder / lietotājs atzīmējis "neder"); skaitļi un pirmās iesniegšanas datums."""
    n = sub = acc = rej = up = bad = ext = 0
    date = ""
    for s in x.get("stems") or []:
        it = by.get(s)
        c = (it or {}).get("cells", {}).get(ag) or {}
        stt = c.get("state") or ""
        if stt == "skip" or (not stt and c.get("bad")):
            bad += 1
            continue
        if not stt and c.get("ext"):                     # jau aģentūrā (iesniegta garām Tirgotājam) — nav jāsūta
            ext += 1
            continue
        n += 1
        if stt in DONE:
            sub += 1
            acc += stt == "accepted"
            rej += stt == "rejected"
            d = next((h.get("at") for h in (c.get("hist") or []) + [c] if h.get("state") == "submitted"), c.get("at") or "")
            date = min(date, d) if date and d else (d or date)
        elif stt == "uploaded":
            up += 1
    st = ("done" if ext else "bad") if not n else "done" if sub >= n else "part" if sub else "up" if up else "none"
    if (x.get("part") or {}).get(ag) and st not in ("done", "bad"):
        st = "part"                                        # lietotājs: "daļēji" visam komplektam (labais klikšķis, 6j)
    return {"st": st, "n": n, "sub": sub, "acc": acc, "rej": rej, "wait": sub - acc - rej, "up": up, "bad": bad,
            "ext": ext, "date": date}


SET_MARKS = ("uploaded", "submitted", "part", "")


def set_mark(sid: str, ag: str, state: str) -> dict:
    """Labais klikšķis uz komplekta punktiņa (lietotājs 2026-11-11 11:20–11:26): augšupielādēts / daļēji / iesniegts /
    noņemt. Bildes, kas aģentūrai neder, jau ir tur vai ir pieņemtas/noraidītas (automātiski), neaiztiek."""
    if ag not in AG_IDS or state not in SET_MARKS:
        return {"ok": False, "error": "bad_state"}
    ss = sets_store()
    x = ss.data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    with ss.lock:
        part = dict(x.get("part") or {})
        if state == "part":
            part[ag] = _now()
        else:
            part.pop(ag, None)
        if part:
            x["part"] = part
        else:
            x.pop("part", None)
        ss.save()
    if state == "part":
        return {"ok": True, "n": 0}
    by = {it["stem"]: it for it in listing()["items"]}
    stems = []
    for s in x.get("stems") or []:
        c = ((by.get(s) or {}).get("cells") or {}).get(ag) or {}
        cur = c.get("state") or ""
        if cur in ("accepted", "rejected", "skip") or (not cur and (c.get("bad") or c.get("ext"))):
            continue
        if state == "" and cur not in ("uploaded", "submitted"):
            continue
        if cur != state:
            stems.append(s)
    n = mark(stems, ag, state, set_id=sid) if stems else 0
    return {"ok": True, "n": n}


def set_path(x: dict, series: list | None = None) -> str:
    """Komplekta mape šajā datorā (sets.json sinhronizējas — glabā ceļu attiecībā pret komplektu mapi).
    2026-11-05: ja otrā datorā "Komplektu mape" iestatīta citādi (piem. OneDrive, nevis OneDrive/stock), mapi atrod
    pēc komplekta manifesta (`set_id`) skenētajās mapēs — citādi rādītu "vēl gatavo mapē" un pārvietotu vēlreiz."""
    rel = x.get("rel") or ""
    p = os.path.join(set_dir(), *rel.split("/")) if rel and set_dir() else ""
    if p and os.path.isdir(p):
        return p
    if rel:
        for sr in (series if series is not None else scan()["series"]):
            if sr.get("set") == x.get("id") and os.path.isdir(sr.get("folder") or ""):
                if p:
                    _say(f"komplekts '{x.get('name')}' atrasts {sr['folder']} (iestatījumos komplektu mape: {set_dir()})")
                return sr["folder"]
    return p


def sets_list() -> list:
    r = listing()
    by = {it["stem"]: it for it in r["items"]}
    ags = [a["id"] for a in r["agencies"]]
    out = []
    for x in sorted(sets_store().data.values(), key=lambda x: x.get("created", ""), reverse=True):
        stems = x.get("stems") or []
        p = set_path(x, r["series"])
        moved = sum(1 for s in stems if s in by and p and by[s]["path"] and os.path.dirname(by[s]["path"]) == p)
        missing = sum(1 for s in stems if s not in by)
        here = bool(p and os.path.isdir(p))
        ready = bool(x.get("rel")) and here and stems and moved >= len(stems) - missing   # "Gatavs iesniegšanai" (test21)
        stt = {a: set_status(x, by, a) for a in ags}
        if not ready:                                       # vēl nav pārvietots: neiesniegts = ⚪ "plānots" (ne 🔴)
            for z in stt.values():
                if z["st"] == "none":
                    z["st"] = "plan"
        out.append({**x, "count": len(stems), "status": stt, "dir": p, "moved": moved, "here": here, "ready": ready,
                    "missing": missing, "remote": sum(1 for s in stems if s in by and by[s].get("remote"))})
    return out


def set_dir() -> str:
    """Komplektu mape (OneDrive STOCK; datora iestatījums). Tukšs — pārvietot nevar."""
    return str(config.get("sub_set_dir") or "").strip()


def _safe(n: str) -> str:
    return "".join(c if c.isalnum() or c in "-_ ." else "_" for c in n).strip() or "komplekts"


def thumb(series: str, stem: str) -> bytes | None:
    for z in (_zips.get(series), _alt.get(stem)):     # komplekta zip, tad Manifesti kopija (ja komplektā sīktēla nav)
        if not z:
            continue
        try:
            with zipfile.ZipFile(z) as f:
                return f.read(stem + ".jpg")
        except (KeyError, OSError, zipfile.BadZipFile):
            continue
    return make_thumb(stem)


def make_thumb(stem: str, path: str = "") -> bytes | None:
    """Ja sīktēla nav nevienā zip (2026-11-05: sērijas no Mac — zip nebija ne sērijas mapē, ne Manifesti), to izveido no
    pašas bildes (256 px) un glabā datu mapē thumbs/ — nākamreiz ātri."""
    d = config.app_dir() / "thumbs"
    f = d / (re.sub(r"[^\w.-]", "_", stem) + ".jpg")
    try:
        if f.is_file():
            return f.read_bytes()
    except OSError:
        pass
    p = path or _paths.get(stem)
    if not p or not os.path.isfile(p):
        return None
    try:
        import io
        from PIL import Image, ImageOps
        with Image.open(p) as im:
            im.draft("RGB", (512, 512))
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((256, 256))
            buf = io.BytesIO()
            im.save(buf, "JPEG", quality=82)
        data = buf.getvalue()
        d.mkdir(exist_ok=True)
        f.write_bytes(data)
        return data
    except Exception:
        return None
