"use strict";
/* Tirgotājs 0.1.0 — krājums "bilde × aģentūra" (docs/tirgotajs-kopsavilkums.md §3, §11; docs/tirgotajs-iesniegsana.md).
   Kopīgais (tēma, valoda, iestatījumu rāmis, atjauninājumi) — /core/core.js. */

const S = { items: [], series: [], agencies: [], sel: new Set(), shown: 300, page: "stock", data: null };
const STATES = ["submitted", "accepted", "rejected", "skip"];

function showPage(name) {
  S.page = name;
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "settings") settingsPage.load();
}
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));

/* ---------- šūnas stāvoklis ---------- */
function cellState(it, ag) {
  const c = (it.cells || {})[ag] || {};
  if (c.state) return c.state;                     // lietotāja atzīme ir svarīgāka par pārbaudi
  return c.bad ? "bad" : "";
}
function reasonText(r) { return t(r[0], r[1] || {}); }
function cellTitle(it, ag) {
  const c = (it.cells || {})[ag] || {}, st = cellState(it, ag);
  const parts = [agName(ag) + ": " + t("st_" + st)];
  if (c.at) parts.push(new Date(c.at).toLocaleDateString(window.langLocale()));
  if (c.reason) parts.push(c.reason);
  if (c.bad) parts.push(...c.bad.map(reasonText));
  return parts.join("\n");
}
function agName(id) { const a = S.agencies.find((x) => x.id === id); return a ? a.name : id; }

/* ---------- ielāde ---------- */
async function load() {
  let d;
  try { d = await api("list"); } catch (e) { toast(e.message, "err"); return; }
  S.data = d;
  S.items = d.items || []; S.series = d.series || []; S.agencies = d.agencies || [];
  const have = new Set(S.items.map((i) => i.stem));
  S.sel.forEach((s) => { if (!have.has(s)) S.sel.delete(s); });
  $("#noDir").classList.toggle("hidden", !d.no_dir && d.error !== "dir_missing");
  if (d.error === "dir_missing") $("#noDir p").textContent = t("dir_missing", { p: d.dir || "" });
  else $("#noDir p").textContent = t("no_dir");
  const dir = (Core.settings || {}).sub_ready_dir || "";
  $("#dirLine").classList.toggle("hidden", !dir || d.error === "dir_missing");
  $("#dirPath").textContent = dir;
  fillFilters();
  renderCards();
  render();
  Core.setStatus("count", { text: t("sb_count", { n: S.items.length, s: S.series.length }) });
}

function fillFilters() {
  const fs = $("#fSeries"), cur = fs.value;
  fs.innerHTML = `<option value="">${esc(t("all"))}</option>` + S.series.map((s) => `<option value="${esc(s.key)}">${esc(s.name)} (${s.count})</option>`).join("");
  fs.value = S.series.some((s) => s.key === cur) ? cur : "";
  for (const sel of [$("#fAgency"), $("#selAgency")]) {
    const v = sel.value;
    sel.innerHTML = (sel.id === "fAgency" ? `<option value="">${esc(t("any_agency"))}</option>` : "") + S.agencies.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("");
    if (S.agencies.some((a) => a.id === v)) sel.value = v;
  }
}

/* ---------- kopsavilkums pa aģentūrām ---------- */
function renderCards() {
  const box = $("#agCards");
  if (!S.items.length) { box.innerHTML = ""; return; }
  box.innerHTML = S.agencies.map((a) => {
    const n = { "": 0, submitted: 0, accepted: 0, rejected: 0, skip: 0, bad: 0 };
    S.items.forEach((it) => { n[cellState(it, a.id)]++; });
    const how = a.ftp ? t(a.ftp.endsWith("*") ? "how_ftp_q" : "how_ftp", { f: a.ftp.replace("*", "") }) : t("how_web");
    return `<div class="ag-card" data-ag="${a.id}">
      <div class="ag-h"><b>${esc(a.name)}</b><button class="ghost small ag-open" data-url="${esc(a.url)}" title="${esc(t("open_ag_d"))}">${esc(t("open_ag"))} ↗</button></div>
      <div class="ag-todo"><span class="big">${n[""]}</span> <span class="muted">${esc(t("c_todo"))}</span></div>
      <div class="ag-n small"><span class="st-submitted-t">${n.submitted} ${esc(t("c_sub"))}</span> · <span class="st-accepted-t">${n.accepted} ${esc(t("c_acc"))}</span> ·
        <span class="st-rejected-t">${n.rejected} ${esc(t("c_rej"))}</span> · <span class="muted">${n.bad + n.skip} ${esc(t("c_bad"))}</span></div>
      <div class="ag-how small muted">${esc(how)}</div>
      <button class="ag-todo-btn small" data-ag="${a.id}">${esc(t("show_todo"))}</button></div>`;
  }).join("");
}
$("#agCards").addEventListener("click", async (e) => {
  const o = e.target.closest(".ag-open");
  if (o) { try { await api("open_url", { url: o.dataset.url }); } catch (err) { toast(err.message, "err"); } return; }
  const b = e.target.closest(".ag-todo-btn");
  if (b) { $("#fAgency").value = b.dataset.ag; $("#fShow").value = "todo"; S.shown = 300; render(); $("#grid").scrollIntoView({ behavior: "smooth" }); }
});

/* ---------- tabula ---------- */
function filtered() {
  const ser = $("#fSeries").value, cat = $("#fCat").value, show = $("#fShow").value, ag = $("#fAgency").value;
  const q = $("#fText").value.trim().toLowerCase();
  const ags = ag ? [ag] : S.agencies.map((a) => a.id);
  return S.items.filter((it) => {
    if (ser && it.series !== ser) return false;
    if (cat && (cat === "ED" ? !/^ED/.test(it.cat) : it.cat !== cat)) return false;
    if (q && !(it.file + " " + it.orig + " " + it.title).toLowerCase().includes(q)) return false;
    if (show === "todo") return ags.some((a) => cellState(it, a) === "");
    if (show === "rejected") return ags.some((a) => cellState(it, a) === "rejected");
    if (show === "bad") return ags.some((a) => cellState(it, a) === "bad");
    return true;
  });
}

function render() {
  const list = filtered();
  const ags = S.agencies;
  $("#grid thead").innerHTML = `<tr><th class="ck"><input type="checkbox" id="ckAll"></th><th></th><th data-i18n="col_file">${esc(t("col_file"))}</th>
    <th>${esc(t("col_cat"))}</th><th>${esc(t("col_size"))}</th>` +
    ags.map((a) => `<th class="agh" title="${esc(a.name)}">${esc(a.name.replace(/ \/.*/, ""))}</th>`).join("") + `</tr>`;
  const rows = list.slice(0, S.shown);
  const tok = encodeURIComponent(window.TOKEN);
  $("#grid tbody").innerHTML = rows.map((it) => {
    const mb = (it.size / 1048576).toFixed(1), mp = it.w && it.h ? (it.w * it.h / 1e6).toFixed(1) + " MP" : "";
    const ser = S.series.find((s) => s.key === it.series);
    return `<tr data-stem="${esc(it.stem)}" class="${S.sel.has(it.stem) ? "sel" : ""}">
      <td class="ck"><input type="checkbox" class="ck1" ${S.sel.has(it.stem) ? "checked" : ""}></td>
      <td class="th">${it.thumb ? `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(it.series)}&n=${encodeURIComponent(it.stem)}" alt="">` : ""}</td>
      <td class="fn"><div class="f1" title="${esc(it.path)}">${esc(it.file)}</div><div class="f2 muted small">${esc(ser ? ser.name : "")}${it.title ? " · " + esc(it.title) : ""}</div></td>
      <td><span class="cat cat-${esc(it.cat)}">${esc(it.cat)}</span></td>
      <td class="muted small">${mb} MB<br>${mp}</td>` +
      ags.map((a) => { const st = cellState(it, a.id); return `<td class="cell st-${st}" data-ag="${a.id}" title="${esc(cellTitle(it, a.id))}">${st === "bad" ? "!" : st === "accepted" ? "✓" : st === "rejected" ? "✕" : st === "submitted" ? "↑" : st === "skip" ? "–" : ""}</td>`; }).join("") + `</tr>`;
  }).join("");
  $("#empty").classList.toggle("hidden", !!list.length || !!(S.data && S.data.no_dir));
  $("#empty").textContent = S.items.length ? t("empty_filter") : t("empty_none");
  $("#more").classList.toggle("hidden", list.length <= S.shown);
  $("#countLine").textContent = t("count_line", { n: list.length, all: S.items.length });
  $("#ckAll").checked = rows.length > 0 && rows.every((r) => S.sel.has(r.stem));
  $("#ckAll").addEventListener("change", (e) => { rows.forEach((r) => (e.target.checked ? S.sel.add(r.stem) : S.sel.delete(r.stem))); render(); });
  selBar();
}
["#fSeries", "#fCat", "#fShow", "#fAgency"].forEach((s) => $(s).addEventListener("change", () => { S.shown = 300; render(); }));
$("#fText").addEventListener("input", () => { S.shown = 300; render(); });
$("#more").addEventListener("click", () => { S.shown += 300; render(); });

$("#grid tbody").addEventListener("click", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr) return;
  const stem = tr.dataset.stem;
  const cell = e.target.closest("td.cell");
  if (cell) return cellMenu(cell, stem, cell.dataset.ag);
  if (e.target.closest("td.ck") || e.target.closest("td.th") || e.target.closest("td.fn")) {
    if (S.sel.has(stem)) S.sel.delete(stem); else S.sel.add(stem);
    tr.classList.toggle("sel", S.sel.has(stem));
    const ck = $(".ck1", tr); if (ck) ck.checked = S.sel.has(stem);
    selBar();
  }
});
$("#grid tbody").addEventListener("dblclick", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr || e.target.closest("td.cell")) return;
  const it = S.items.find((i) => i.stem === tr.dataset.stem);
  if (it) api("open", { path: it.path }).catch((err) => toast(err.message, "err"));
});

/* ---------- vienas šūnas izvēlne ---------- */
function cellMenu(td, stem, ag) {
  const m = $("#cellMenu");
  const it = S.items.find((i) => i.stem === stem);
  const c = (it.cells || {})[ag] || {};
  const stems = S.sel.has(stem) && S.sel.size > 1 ? [...S.sel] : [stem];
  m.innerHTML = `<div class="ctx-h">${esc(agName(ag))}${stems.length > 1 ? " · " + esc(t("n_photos", { n: stems.length })) : ""}</div>` +
    (c.bad ? `<div class="ctx-bad small">${c.bad.map((r) => "⚠ " + esc(reasonText(r))).join("<br>")}</div>` : "") +
    STATES.map((s) => `<button data-st="${s}" class="${c.state === s ? "on" : ""}">${esc(t("mark_" + s))}</button>`).join("") +
    `<button data-st="">${esc(t("mark_clear"))}</button>`;
  const r = td.getBoundingClientRect();
  m.style.left = Math.min(r.left, innerWidth - 230) + "px";
  m.style.top = Math.min(r.bottom + 2, innerHeight - 260) + "px";
  m.classList.remove("hidden");
  m.onclick = async (e) => {
    const b = e.target.closest("button[data-st]"); if (!b) return;
    m.classList.add("hidden");
    await mark(stems, ag, b.dataset.st);
  };
}
document.addEventListener("click", (e) => { if (!e.target.closest("#cellMenu") && !e.target.closest("td.cell")) $("#cellMenu").classList.add("hidden"); });

async function mark(stems, ag, st) {
  let reason = "";
  if (st === "rejected") {
    reason = await askText(t("reason_q"));
    if (reason === null) return;
  }
  try {
    await api("mark", { stems, agency: ag, state: st, reason });
    toast(t("marked", { n: stems.length, a: agName(ag), s: t(st ? "st_" + st : "st_") }), "ok", 2500);
    await load();
  } catch (e) { toast(e.message, "err"); }
}
function askText(msg) {
  return new Promise((res) => {
    const m = $("#reasonModal"), inp = $("#reasonIn");
    $("#reasonQ").textContent = msg; inp.value = ""; m.classList.remove("hidden");
    setTimeout(() => inp.focus(), 30);
    const done = (v) => { m.classList.add("hidden"); $("#reasonOk").onclick = $("#reasonNo").onclick = inp.onkeydown = null; res(v); };
    $("#reasonOk").onclick = () => done(inp.value.trim());
    $("#reasonNo").onclick = () => done(null);
    inp.onkeydown = (e) => { if (e.key === "Enter") done(inp.value.trim()); if (e.key === "Escape") done(null); };
  });
}

/* ---------- atlasīto josla ---------- */
function selBar() {
  const n = S.sel.size;
  $("#selBar").classList.toggle("hidden", !n);
  $("#selN").textContent = t("n_selected", { n });
}
$("#selBar").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-st]"); if (!b) return;
  mark([...S.sel], $("#selAgency").value, b.dataset.st);
});
$("#selClear").addEventListener("click", () => { S.sel.clear(); render(); });

/* ---------- mape ---------- */
async function pickDir() {
  try {
    const r = await api("pick_folder", { start: (Core.settings || {}).sub_ready_dir || "" });
    if (!r.path) return;
    await api("set_dir", { path: r.path });
    Core.settings.sub_ready_dir = r.path;
    await load();
  } catch (e) { if (!/pick_busy/.test(e.message)) toast(e.message, "err"); }
}
$("#pickDir").addEventListener("click", pickDir);
$("#changeDir").addEventListener("click", pickDir);
$("#openDir").addEventListener("click", () => api("open", { path: (Core.settings || {}).sub_ready_dir || "" }).catch((e) => toast(e.message, "err")));
$("#reloadBtn").addEventListener("click", load);

/* ---------- iestatījumi ---------- */
const settingsPage = Core.settingsFrame({
  root: "#page-settings",
  shared: ["agencies"],
  moduleHtml: `<section data-collapse="sub"><h2 data-i18n="s_app"></h2>
    <label><span data-i18n="ready_dir"></span>
      <div class="row"><input id="sDir" spellcheck="false" style="flex:1"><button id="sDirPick" data-i18n="pick_dir"></button></div></label>
    <p class="muted small" data-i18n="s_dir_d"></p>
    <h3 data-i18n="s_ags"></h3><p class="muted small" data-i18n="s_ags_d"></p><div id="sAgs" class="ag-checks"></div>
    <h3 data-i18n="s_ed"></h3><p class="muted small" data-i18n="s_ed_d"></p><div id="sEd" class="ag-checks"></div></section>`,
  load(s) {
    $("#sDir").value = s.sub_ready_dir || "";
    const all = (Core.state || {}).agencies_all || [];
    const box = (id, vals) => all.map((a) => `<label class="chk"><input type="checkbox" class="${id}" value="${a.id}" ${vals.includes(a.id) ? "checked" : ""}> ${esc(a.name)}</label>`).join("");
    $("#sAgs").innerHTML = box("sAg1", s.sub_agencies || []);
    $("#sEd").innerHTML = box("sEd1", s.sub_ed_agencies || []);
  },
  collect() {
    return { sub_ready_dir: $("#sDir").value.trim(), sub_agencies: $$(".sAg1").filter((c) => c.checked).map((c) => c.value),
      sub_ed_agencies: $$(".sEd1").filter((c) => c.checked).map((c) => c.value) };
  },
  onSaved() { load(); },
});
document.addEventListener("click", async (e) => {
  if (!e.target.closest("#sDirPick")) return;
  try { const r = await api("pick_folder", { start: $("#sDir").value }); if (r.path) $("#sDir").value = r.path; } catch (_) {}
});

function onLang() { applyI18n(); fillFilters(); renderCards(); render(); if (S.page === "settings") settingsPage.load(); }

Core.init({ onLang, icon: "/static/icon.svg" });

async function init() {
  let st;
  try { st = await api("state"); } catch (e) { toast(e.message, "err"); return; }
  Core.boot(st);
  applyI18n();
  await load();
}
init();
