"use strict";
/* Atlasīt pašam (2026-11-05): bilžu režģis ar izmēra slīdni, filtri, klikšķis — atlasīt, dubultklikšķis / atstarpe —
   lielais skats (oriģināls no NAS/OneDrive, samazināts serverī — GET /full), līdzīgo ≈ uzreiz (sub_sim_check),
   komplekts no atlasītajām vai pievienošana esošam. Lielais skats arī ieteikumā (Komplekti). Lieto app.js S, thumbUrl. */
const P = { pick: new Set(), shown: 240, sim: {}, list: [], focus: -1, set: "" };

/* rediģē komplektu (2026-11-05): komplekta bildes (✦) + pēc izvēles brīvās tās pašas kategorijas pievienošanai */
function pSetObj() { return (S.sets || []).find((x) => x.id === P.set) || null; }
function pFiltered() {
  if (P.set) {
    const ord = ((S.sets || []).find((x) => x.id === P.set) || {}).stems || [];   /* komplekta secībā (jaukta), ne pēc nosaukumiem */
    const inSet = S.items.filter((it) => (it.in_sets || []).includes(P.set)).sort((a, b) => ord.indexOf(a.stem) - ord.indexOf(b.stem));
    if (!$("#pSetFree").checked) return inSet;
    const cat = (inSet[0] || {}).cat || $("#pCat").value || "";
    const ags = (S.agencies || []).map((a) => a.id);
    const q = $("#pText").value.trim().toLowerCase(), ser = $("#pSeries").value;
    return inSet.concat(S.items.filter((it) => !(it.in_sets || []).length && (!cat || (it.cat || "RF") === cat) && (!ser || it.series === ser)
      && ags.some((a) => { const c = (it.cells || {})[a] || {}; return !c.state && !c.bad && !c.ext; })
      && (!q || (it.file + " " + (it.title || "")).toLowerCase().includes(q))));
  }
  const ser = $("#pSeries").value, cat = $("#pCat").value, show = $("#pShow").value;
  const q = $("#pText").value.trim().toLowerCase();
  const ags = (S.agencies || []).map((a) => a.id);
  return S.items.filter((it) => {
    if (ser && it.series !== ser) return false;
    if (cat && (it.cat || "RF") !== cat) return false;
    if (show === "free" && (it.in_sets || []).length) return false;
    if (show === "todo") {
      if ((it.in_sets || []).length) return false;
      if (!ags.some((a) => { const c = (it.cells || {})[a] || {}; return !c.state && !c.bad && !c.ext; })) return false;
    }
    if (q) { const s = (it.file + " " + (it.title || "") + " " + ((S.series.find((x) => x.key === it.series) || {}).name || "")).toLowerCase(); if (!s.includes(q)) return false; }
    return true;
  });
}
function pFill() {
  const sel = $("#pSeries"), cur = sel.value;
  sel.innerHTML = `<option value="">${esc(t("all"))}</option>` + S.series.map((s) => `<option value="${esc(s.key)}">${esc(s.name)} (${s.count})</option>`).join("");
  if ([...sel.options].some((o) => o.value === cur)) sel.value = cur;
  const ps = $("#pSet"), pcur = P.set;
  ps.innerHTML = `<option value="">${esc(t("p_set_none"))}</option>` + (S.sets || []).map((x) => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("");
  ps.value = (S.sets || []).some((x) => x.id === pcur) ? pcur : "";
  P.set = ps.value;
  const add = $("#pAddTo");
  add.innerHTML = `<option value="">${esc(t("p_add_ph"))}</option>` + (S.sets || []).map((x) => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("");
}
function pRender() {
  if (S.page !== "pick") return;
  pFill();
  const have = new Set(S.items.map((i) => i.stem));
  P.pick.forEach((s) => { if (!have.has(s)) P.pick.delete(s); });
  P.list = pFiltered();
  const show = P.list.slice(0, P.shown);
  document.documentElement.style.setProperty("--ptile", $("#pSize").value + "px");
  $("#pGrid").innerHTML = show.map((it, i) => {
    const on = P.pick.has(it.stem), sim = P.sim[it.stem];
    const bad = (S.agencies || []).filter((a) => ((it.cells || {})[a.id] || {}).bad).length;
    const mine = P.set && (it.in_sets || []).includes(P.set);
    return `<div class="p-it ${on ? "on" : ""} ${(it.in_sets || []).length && !mine ? "inset" : ""} ${mine ? "mine" : ""}" data-i="${i}" data-stem="${esc(it.stem)}" title="${esc(it.file + (it.title ? "\n" + it.title : ""))}">
      ${it.thumb ? `<img loading="lazy" src="${thumbUrl(it)}" alt="">` : `<div class="ns-noimg"></div>`}
      <span class="p-cat cat cat-${esc(it.cat || "RF")}">${esc(it.cat || "RF")}</span>
      ${sim ? `<span class="p-sim" title="${esc(t("p_sim_tip", { f: sim.map((s) => (S.items.find((x) => x.stem === s) || {}).file || s).join(", ") }))}">≈</span>` : ""}
      ${bad ? `<span class="p-bad" title="${esc(t("p_bad_tip", { n: bad }))}">!${bad}</span>` : ""}
      <span class="p-ck">${on ? "✓" : ""}</span>${mine ? `<span class="p-mine" title="${esc(t("p_in_set"))}">✦</span>` : ""}
      ${it.remote ? `<span class="p-nas nas-badge" title="${esc(t("nas_tip"))}">${esc(t("nas_badge"))}</span>` : ""}
      ${it.edwarn ? `<span class="p-edw edw-badge" title="${esc(t("edw_tip"))}">⚠ ${esc(t("edw_badge"))}</span>` : ""}
      <div class="small p-fn">${esc(it.file)}</div></div>`;
  }).join("") || pEmptyNote();
  $("#pCount").textContent = t("count_line", { n: show.length, all: P.list.length });
  $("#pMore").classList.toggle("hidden", P.list.length <= P.shown);
  $("#pSetNote").classList.toggle("hidden", !P.set);
  const x = pSetObj();
  if (x) $("#pSetTxt").textContent = t("p_set_note", { s: x.name, n: S.items.filter((it) => (it.in_sets || []).includes(P.set)).length });
  pBar();
}
/* tukšs režģis — cik bilžu paslēpj filtri + "Rādīt visas" (lietotājs 2026-11-05 20:34) */
function pEmptyNote() {
  if (!S.items.length) return `<div class="muted">${esc(t("empty_none"))}</div>`;
  const f = [];
  if ($("#pSeries").value) f.push(t("f_series") + ": " + $("#pSeries").selectedOptions[0].textContent);
  if ($("#pCat").value) f.push(t("f_cat") + ": " + $("#pCat").value);
  if ($("#pShow").value) f.push(t("f_show") + ": " + $("#pShow").selectedOptions[0].textContent);
  if ($("#pText").value.trim()) f.push("“" + $("#pText").value.trim() + "”");
  if (P.set) f.push(t("p_set") + ": " + ((pSetObj() || {}).name || ""));
  return `<div class="flt-note p-empty">${esc(t("p_empty_flt", { n: S.items.length, f: f.join(", ") || "—" }))} <button class="small" id="pShowAll">${esc(t("flt_all"))}</button></div>`;
}
document.addEventListener("click", (e) => {
  if (!e.target.closest("#pShowAll")) return;
  $("#pSeries").value = ""; $("#pCat").value = ""; $("#pShow").value = ""; $("#pText").value = "";
  if (P.set) { P.set = ""; $("#pSet").value = ""; }
  P.shown = 240; pRender();
});
function pBar() {
  const n = P.pick.size;
  $("#pBar").classList.toggle("hidden", !n);
  if (!n) return;
  const items = [...P.pick].map((s) => S.items.find((i) => i.stem === s)).filter(Boolean);
  const cats = [...new Set(items.map((i) => i.cat || "RF"))];
  const bad = (S.agencies || []).map((a) => [a.name.replace(/ \/.*/, ""), items.filter((i) => ((i.cells || {})[a.id] || {}).bad).length]).filter((x) => x[1]);
  const nsim = Object.keys(P.sim).length;
  $("#pSelN").textContent = t("p_sel_n", { n });
  $("#pSelInfo").textContent = [cats.length > 1 ? "⚠ " + t("p_mixed", { c: cats.join("/") }) : cats[0],
    nsim ? "≈ " + t("p_sim_n", { n: nsim }) : "", bad.length ? t("p_bad_line", { l: bad.map((b) => b[0] + " " + b[1]).join(", ") }) : ""].filter(Boolean).join(" · ");
  $("#pCreate").disabled = cats.length > 1;
  const inSet = P.set ? items.filter((i) => (i.in_sets || []).includes(P.set)).length : 0;
  $("#pRemove").classList.toggle("hidden", !inSet);
  $("#pRemove").textContent = t("p_remove", { n: inSet });
  if (P.set) $("#pAddTo").value = P.set;
  $("#pCreate").classList.toggle("hidden", !!P.set);
}
let pSimTimer = null;
function pSimCheck() {
  clearTimeout(pSimTimer);
  pSimTimer = setTimeout(async () => {
    if (P.pick.size < 2) { P.sim = {}; pPaint(); return; }
    try { P.sim = (await api("sim_check", { stems: [...P.pick] })).sim || {}; } catch (_) { P.sim = {}; }
    pPaint();
  }, 300);
}
/* atlases maiņa — tikai flīžu klases un zīmes (režģi nepārzīmē, lai dubultklikšķis strādā) */
function pPaint() {
  $$("#pGrid .p-it").forEach((d) => {
    const st = d.dataset.stem, on = P.pick.has(st), sim = P.sim[st];
    d.classList.toggle("on", on);
    $(".p-ck", d).textContent = on ? "✓" : "";
    let b = $(".p-sim", d);
    if (sim && !b) { d.insertAdjacentHTML("beforeend", `<span class="p-sim">≈</span>`); b = $(".p-sim", d); }
    if (b && !sim) b.remove();
    if (b && sim) b.title = t("p_sim_tip", { f: sim.map((x) => (S.items.find((i) => i.stem === x) || {}).file || x).join(", ") });
  });
  pBar();
}
function pToggle(stem) { if (P.pick.has(stem)) P.pick.delete(stem); else P.pick.add(stem); pPaint(); pSimCheck(); }

$("#pGrid").addEventListener("click", (e) => { const d = e.target.closest(".p-it"); if (d) pToggle(d.dataset.stem); });
$("#pGrid").addEventListener("dblclick", (e) => { const d = e.target.closest(".p-it"); if (!d) return; if (window.getSelection) window.getSelection().removeAllRanges(); lbOpen(P.list, +d.dataset.i, "pick"); });   // divi klikšķi jau atlasīja un noņēma
/* labais klikšķis: "Izdzēst no NAS" (lietotājs 2026-11-24 — dublikātu tīrīšanai, te labi redzams) */
$("#pGrid").addEventListener("contextmenu", (e) => {
  const d = e.target.closest(".p-it");
  if (!d) return;
  e.preventDefault();
  const stem = d.dataset.stem, many = P.pick.has(stem) && P.pick.size > 1;
  const m = $("#cellMenu");
  m.innerHTML = `<div class="ctx-h">${esc(((S.items.find((i) => i.stem === stem) || {}).file) || stem)}</div>` +
    `<button data-a="big">${esc(t("p_big"))}</button>` +
    `<button data-a="del" class="danger">${esc(t("nasdel"))}</button>` +
    (many ? `<button data-a="delsel" class="danger">${esc(t("nasdel_sel", { n: P.pick.size }))}</button>` : "");
  m.style.left = Math.min(e.clientX, innerWidth - 230) + "px";
  m.style.top = Math.min(e.clientY, innerHeight - 140) + "px";
  m.classList.remove("hidden");
  m.onclick = async (ev) => {
    const b = ev.target.closest("button[data-a]");
    if (!b) return;
    m.classList.add("hidden");
    if (b.dataset.a === "big") { lbOpen(P.list, +d.dataset.i, "pick"); return; }
    const stems = b.dataset.a === "delsel" ? [...P.pick] : [stem];
    if (await nasDelete(stems)) { stems.forEach((x) => P.pick.delete(x)); await load(); pRender(); }
  };
});
$("#pGrid").addEventListener("mouseover", (e) => { const d = e.target.closest(".p-it"); if (d) P.focus = +d.dataset.i; });
$("#pSet").addEventListener("change", () => { P.set = $("#pSet").value; P.from = ""; P.pick.clear(); P.sim = {}; P.shown = 240; pRender(); });
$("#pSetFree").addEventListener("change", () => { P.shown = 240; pRender(); });
$("#pRemove").addEventListener("click", async () => {
  const x = pSetObj(); if (!x) return;
  const stems = [...P.pick].filter((s) => { const it = S.items.find((i) => i.stem === s); return it && (it.in_sets || []).includes(P.set); });
  if (!stems.length) return;
  try {
    const r = await api("set_remove", { id: P.set, stems });
    toast(t("p_removed", { n: r.removed, s: r.name }), "ok", 4000);
    stems.forEach((s) => P.pick.delete(s)); P.sim = {}; await load(); pRender();
  } catch (err) { toast(t("p_e_" + err.message) !== "p_e_" + err.message ? t("p_e_" + err.message) : err.message, "err", 7000); }
});
/* no Plāna kartītes (✎) — atver šo komplektu */
window.pickNewForDay = function (d) {   /* Plāns → labais klikšķis uz dienas → "Izveidot pašam" */
  P.set = ""; P.pick.clear(); P.sim = {}; if ($("#pSet")) $("#pSet").value = ""; showPage("pick");
  setTimeout(() => { $("#pDate").value = d; toast(t("p_for_day", { d: fmtDay(d) }), "ok", 6000); }, 50);
};
window.pickOpenSet = function (id) { P.from = S.page && S.page !== "pick" ? S.page : ""; P.set = id; P.pick.clear(); P.sim = {}; $("#pSetFree").checked = false; showPage("pick"); };
["#pSeries", "#pCat", "#pShow"].forEach((id) => $(id).addEventListener("change", () => { P.shown = 240; pRender(); }));
$("#pText").addEventListener("input", () => { P.shown = 240; pRender(); });
$("#pSize").addEventListener("input", () => document.documentElement.style.setProperty("--ptile", $("#pSize").value + "px"));
$("#pMoreBtn").addEventListener("click", () => { P.shown += 240; pRender(); });
$("#pClear").addEventListener("click", () => { P.pick.clear(); P.sim = {}; pPaint(); });
$("#pCreate").addEventListener("click", async () => {
  const items = [...P.pick].map((s) => S.items.find((i) => i.stem === s)).filter(Boolean);
  if (!items.length) return;
  if (Object.keys(P.sim).length && !(await uiConfirm(t("p_sim_q", { n: Object.keys(P.sim).length }), t("p_create")))) return;
  try {
    const edw = items.filter((i) => i.edwarn && (i.cat || "RF") === "RF").length;
    if (edw && !(await uiConfirm(t("edw_q", { n: edw }), t("p_create")))) return;
    const r = await api("set_save", { name: $("#pName").value.trim(), cat: items[0].cat || "RF", stems: items.map((i) => i.stem), date: $("#pDate").value, now: $("#pNow").checked });
    toast(t("ns_saved", { n: r.set.name, c: items.length }) + (r.set.planned ? " " + t("ns_saved_day", { d: fmtDay(r.set.planned) }) : "") + (r.set.want_move ? " " + t("ns_saved_now") : ""), "ok", 6000);
    P.pick.clear(); P.sim = {}; $("#pName").value = ""; $("#pDate").value = ""; fillDay("#pDate");
    await load(); pRender();
  } catch (err) { dayErr(err); }
});
$("#pAdd").addEventListener("click", async () => {
  const id = $("#pAddTo").value; if (!id || !P.pick.size) return;
  try {
    const r = await api("set_add", { id, stems: [...P.pick] });
    toast(t("p_added", { n: r.added, s: r.name }) + (r.skipped ? " " + t("p_add_skip", { k: r.skipped }) : ""), r.skipped ? "err" : "ok", 6000);
    P.pick.clear(); P.sim = {}; await load(); pRender();
  } catch (err) { toast(t("p_e_" + err.message) !== "p_e_" + err.message ? t("p_e_" + err.message) : err.message, "err", 7000); }
});

/* ---------- lielais skats ---------- */
const LB = { list: [], i: 0, mode: "" };
const fullUrl = (it) => `/full?t=${encodeURIComponent(window.TOKEN)}&n=${encodeURIComponent(it.stem)}`;
function lbOpen(list, i, mode) { LB.list = list; LB.i = i; LB.mode = mode; $("#lb").classList.remove("hidden"); lbShow(); }
function lbShow() {
  const it = LB.list[LB.i]; if (!it) return;
  const img = $("#lbImg");
  img.src = it.thumb ? thumbUrl(it) : "";                 // uzreiz sīktēls, tad lielā bilde
  const big = new Image(); big.onload = () => { if (LB.list[LB.i] === it) img.src = big.src; }; big.src = fullUrl(it);
  $("#lbTitle").textContent = it.file;
  $("#lbPos").textContent = `${LB.i + 1} / ${LB.list.length}`;
  const ser = (S.series.find((x) => x.key === it.series) || {}).name || "";
  const bad = (S.agencies || []).filter((a) => ((it.cells || {})[a.id] || {}).bad).map((a) => a.name + ": " + ((it.cells[a.id].bad || []).map(reasonText).join("; ")));
  $("#lbInfo").innerHTML = `<div><b>${esc(it.title || "")}</b></div><div class="muted">${esc([ser, it.cat || "RF", it.taken ? it.taken.slice(0, 16).replace("T", " ") : "", it.w && it.h ? `${it.w}×${it.h}` : "", it.size ? (it.size / 1048576).toFixed(1) + " MB" : ""].filter(Boolean).join(" · "))}</div>` +
    (bad.length ? `<div class="warn">⚠ ${bad.map(esc).join("<br>")}</div>` : "");
  const sel = $("#lbSel");
  sel.classList.toggle("hidden", LB.mode !== "pick");
  sel.textContent = P.pick.has(it.stem) ? t("p_unpick") : t("p_pick");
}
function lbClose() { $("#lb").classList.add("hidden"); $("#lbImg").src = ""; }
$("#lbClose").addEventListener("click", lbClose);
$("#lbPrev").addEventListener("click", () => { if (LB.i > 0) { LB.i--; lbShow(); } });
$("#lbNext").addEventListener("click", () => { if (LB.i < LB.list.length - 1) { LB.i++; lbShow(); } });
$("#lbSel").addEventListener("click", () => { const it = LB.list[LB.i]; if (it) { pToggle(it.stem); lbShow(); } });
$("#lb").addEventListener("click", (e) => { if (e.target.id === "lb") lbClose(); });
document.addEventListener("keydown", (e) => {
  const open = !$("#lb").classList.contains("hidden");
  if (open) {
    if (e.key === "Escape") lbClose();
    else if (e.key === "ArrowRight") $("#lbNext").click();
    else if (e.key === "ArrowLeft") $("#lbPrev").click();
    else if (e.key === " " && LB.mode === "pick") { e.preventDefault(); $("#lbSel").click(); }
    else return;
    e.preventDefault(); return;
  }
  if (S.page === "pick" && e.key === " " && !/INPUT|SELECT|TEXTAREA/.test((document.activeElement || {}).tagName || "") && P.focus >= 0) {
    e.preventDefault(); lbOpen(P.list, P.focus, "pick");
  }
});
/* ieteikumā (Komplekti): dubultklikšķis uz sīktēla — lielais skats */
$("#nsGrid").addEventListener("dblclick", (e) => {
  const d = e.target.closest(".ns-it"); if (!d || !S.ns) return;
  const i = S.ns.items.findIndex((x) => x.stem === d.dataset.stem); if (i >= 0) lbOpen(S.ns.items, i, "ns");
});

/* lapas pārslēgšana — app.js showPage izsauc pRender caur šo āķi */
const _showPage = showPage;
showPage = function (name) { _showPage(name); if (name === "pick") pRender(); };   // eslint-disable-line no-global-assign
const _load = load;
load = async function () { await _load(); if (S.page === "pick") pRender(); };   // eslint-disable-line no-global-assign

/* "← Atpakaļ" komplekta skatā (lietotājs 2026-11-12 15:39): uz cilni, no kuras atvēra (Plāns / Komplekti), citādi — tikai aizver komplektu */
$("#pBack").addEventListener("click", () => {
  const to = P.from; P.from = ""; P.set = ""; P.pick.clear(); P.sim = {}; $("#pSet").value = "";
  if (to) showPage(to); else pRender();
});
