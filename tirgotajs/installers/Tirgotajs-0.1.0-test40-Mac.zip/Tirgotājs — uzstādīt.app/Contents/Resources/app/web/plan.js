"use strict";
/* Tirgotājs — cilne "Plāns" (plan.py; kopsavilkums §11, lēmumi 2026-11-05 16:27–16:59).
   Nedēļas × dienas, kartīte = komplekts; pārvilkt uz citu dienu; "Apstiprināt nedēļu"; "Sagatavot nākamo nedēļu"
   (pārvieto uz OneDrive mapēm pēc plānotās dienas); augšā "Šodien" un nokavētie. Darbības ar komplektu — setAct (app.js). */
const PL = { d: null };

async function planLoad(body) {
  let d;
  try { d = await api("plan", body || {}); } catch (e) { const k = "pl_e_" + e.message; toast(t(k) !== k ? t(k) : e.message, "err", 6000); return null; }
  PL.d = d;
  planPaint();
  return d;
}
window.planLoad = planLoad;

const plDay = (iso, o) => new Date(iso + "T12:00").toLocaleDateString(window.langLocale(), o || { weekday: "short", day: "numeric", month: "numeric" });
function plHead(z) {
  return z.st === "done" ? t("ag_done", { d: z.date ? plDay(z.date.slice(0, 10), { day: "2-digit", month: "2-digit" }) : "" }) : z.st === "part" ? t("ag_part", { s: z.sub, n: z.n })
    : z.st === "up" ? t("ag_up", { u: z.up, n: z.n }) : z.st === "bad" ? t("ag_bad_l") : z.st === "plan" ? t("ag_plan_l") : t("ag_none_l");
}
/* stāvokļi (lēmums 2026-11-05 22:04): ⚪ plānots (nav pārvietots) · 🔴 gatavs iesniegšanai · 🟠 augšupielādēts · 🔵 daļēji · 🟢 iesniegts */
const PL_KEYS = ["plan", "none", "up", "part", "done", "bad"];
const PL_LEG = () => "\n— " + PL_KEYS.map((k) => ({ done: "🟢", part: "🔵", up: "🟠", none: "🔴", plan: "⚪", bad: "◌" })[k] + " " + t("ag_leg_" + k)).join("\n— ");
window.PL_KEYS = PL_KEYS;
/* kopējais komplekta stāvoklis vienam punktam */
function plOverall(agst) {
  const v = Object.values(agst || {}); if (!v.length) return "none";
  if (v.every((z) => z.st === "done" || z.st === "bad") && v.some((z) => z.st === "done")) return "done";
  if (v.some((z) => z.st === "done" || z.st === "part")) return "part";
  if (v.some((z) => z.st === "up")) return "up";
  if (v.every((z) => z.st === "bad")) return "bad";
  return v.some((z) => z.st === "plan") ? "plan" : "none";
}
function plDots(c) {
  return (PL.d.agencies || []).map((a) => {
    const z = (c.agst || {})[a.id]; if (!z) return "";
    return `<span class="sdot ${z.st}${z.rej ? " rej" : ""}" title="${esc(a.name + " — " + plHead(z) + PL_LEG())}"></span>`;
  }).join("");
}
function plState(c) {
  return c.done ? t("pl_st_done") : c.sub ? t("pl_st_sub") : c.moved ? t("pl_st_moved") : c.status === "approved" ? t("pl_st_approved") : c.date ? t("pl_st_draft") : t("pl_st_moved");
}
/* ceļš (lietotājs 2026-11-11): melnraksts → apstiprināts (vēl NAS) → gatavs (OneDrive) → iesniegts. Josla kartītē. */
const plHm = (iso) => iso ? new Date(iso).toLocaleTimeString(window.langLocale(), { hour: "2-digit", minute: "2-digit", hourCycle: "h23" }) : "";
const plDm = (iso) => iso ? new Date(iso).toLocaleDateString(window.langLocale(), { day: "2-digit", month: "2-digit" }) : "";
function plStage(c) {
  if (c.done) return { k: "done", txt: t("pl_st_done") };
  if (c.back) return { k: "nas", txt: "↩ " + t("pl_back_wait") };
  if (c.back_err) return { k: "blocked", txt: "⚠ " + t("pl_back_err", { e: c.back_err }) };
  if (c.ftp_run && !c.ftp_done) return { k: "up", txt: "⇡ " + t("pl_sending", { a: agName(c.ftp_run.agency || ""), k: c.ftp_run.step || 1, n: c.ftp_run.steps || 1 }) };
  if (c.ftp_done && (c.ftp_res || []).length && !c.sub) {
    const bad = (c.ftp_res || []).some((r) => r.error || r.done < r.total);
    return { k: bad ? "blocked" : "up", txt: (bad ? "⚠ " : "") + t("pl_ftp_done", { t: plHm(c.ftp_done) }) };
  }
  if (c.sub) return { k: "sub", txt: t("pl_st_sub") };
  const st = c.stage;
  if (st === "draft") return { k: "draft", txt: t("pl_stg_draft") };
  if (st === "blocked") return { k: "blocked", txt: "⚠ " + t(c.move_err ? "pl_stg_moveerr" : "pl_stg_blocked", { e: c.move_err || "" }) };
  if (st === "nas") return { k: "nas", txt: "⚠ " + (c.move_err ? t("pl_stg_moveerr", { e: c.move_err }) : c.want_move ? t("pl_stg_nas_now") : c.move_at ? t("pl_stg_nas", { d: plDm(c.move_at), t: plHm(c.move_at) }) : t("pl_stg_nas_now")) };
  if (st === "ready") {
    const A = PL.d.auto || {};
    if (c.ftp_done) return { k: "ready", txt: t("pl_stg_ready") };
    if (c.ftp_late) return { k: "blocked", txt: "⚠ " + t("pl_ftp_late") };
    if (c.want_ftp) return { k: "ready", txt: t("pl_ftp_now") };
    if (c.status === "approved" && A.auto_ftp && !c.ftp_skip) return { k: "ready", txt: c.ftp_at ? "⏱ " + t("pl_ftp_at", { t: plHm(c.ftp_at) }) : t("pl_ftp_night") };
    return { k: "ready", txt: t("pl_stg_ready") };
  }
  return null;
}
function plCard(c, big) {
  const tok = encodeURIComponent(window.TOKEN);
  const th = (c.thumbs || []).map((x) => `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(x.series)}&n=${encodeURIComponent(x.stem)}" alt="">`).join("");
  const sg = plStage(c);
  const cls = (c.done ? "done" : c.sub ? "sub" : c.moved ? "moved" : c.status || "moved") + (sg ? " stg-" + sg.k : "");
  const drag = c.date && !c.moved && !c.done && !c.sub;
  return `<div class="pl-card ${cls}${big ? " big" : ""}" draggable="${drag ? "true" : "false"}" data-id="${esc(c.id)}" data-date="${c.date || ""}">
    <div class="pl-c-h"><span class="sdot ${plOverall(c.agst)}"></span><b title="${esc(c.name)}">${esc(c.name)}</b><span class="cat cat-${esc(c.cat)}">${esc(c.cat)}</span></div>
    ${sg ? `<div class="pl-stg stg-${sg.k} small" title="${esc(sg.txt)}">${esc(sg.txt)}</div>` : ""}
    <div class="pl-th">${th || `<div class="ns-noimg"></div>`}</div>
    <div class="pl-c-f small"><span>${c.count}${sg ? "" : " · " + esc(plState(c))}${c.remote ? ` · <span class="nas-badge" title="${esc(t("nas_tip"))}">${esc(t("nas_badge"))}</span>` : ""}</span><span class="pl-dots">${plDots(c)}</span></div>
    <div class="pl-c-a">${c.moved ? `<button class="small ghost pl-open" title="${esc(c.dir)}">📁</button>` : ""}
      <button class="small ghost pl-show" title="${esc(t("set_show"))}">👁</button>
      ${drag ? `<button class="small ghost pl-edit" title="${esc(t("pl_edit"))}">✎</button><button class="small ghost pl-x" title="${esc(t("pl_remove"))}">×</button>` : ""}</div></div>`;
}
function plTodayBox(cs) {
  if (!cs || !cs.length) return `<div class="pl-today muted">${esc(t("pl_today_none"))}</div>`;
  const ags = PL.d.agencies || [];
  const d0 = cs[0].date;
  return `<div class="pl-today-h"><b>${esc(t("pl_today"))}</b> <span class="muted">${esc(plDay(d0, { weekday: "long", day: "numeric", month: "long" }))}</span></div>` +
    cs.map((c) => `<div class="pl-today" data-id="${esc(c.id)}"><div class="row">${plCard(c, true)}
    <div class="pl-today-a">${c.moved ? "" : `<div class="small warn">${esc(t("pl_not_moved"))}</div><div class="row"><button class="small primary pl-movesend">${esc(t("pl_move_send"))}</button><button class="small pl-movenow">${esc(t("pl_move_now"))}</button></div>`}
      <div class="row"><select class="pl-ag"><option value="*">${esc(t("ag_all_ftp"))}</option>${ags.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select>
      <button class="small pl-ftp">${esc(t("set_ftp"))}</button><button class="small pl-portal">${esc(t("open_ag"))} ↗</button></div></div></div></div>`).join("");
}
/* dienas rāmis — variants B (lēmums 2026-11-05 21:39): virsraksts kā josla rāmja augšā; šodiena — zaļa */
function plDayBox(x, today) {
  const isT = x.date === today;
  const head = (isT ? t("pl_today") + " · " : "") + plDay(x.date, { weekday: "short", day: "2-digit", month: "2-digit" });
  return `<div class="pl-day${x.past ? " past" : ""}${isT ? " today" : ""}" data-date="${x.date}"><div class="pl-d-h small">${esc(head)}</div>
    <div class="pl-d-b">${(x.cards || []).length ? x.cards.map((c) => plCard(c)).join("") : `<div class="pl-empty muted small">—</div>`}</div></div>`;
}
function planPaint() {
  const d = PL.d; if (!d) return;
  $("#plInfo").textContent = t("pl_info", { n: d.planned });
  $("#plPrep").disabled = !d.ready_next;
  $("#plPrep").title = d.ready_next ? t("plan_prep_d") : t("pl_prep_none");
  const note = $("#plNote");
  const msgs = [];
  if (!d.has_set_dir) msgs.push(esc(t("pl_no_setdir")));
  if (d.fresh >= 5 && d.planned) msgs.push(`${esc(t("pl_fresh", { n: d.fresh }))} <button class="small" id="plFill">${esc(t("pl_fill"))}</button>`);
  if (!d.planned) msgs.push(esc(d.fresh ? t("pl_empty", { n: d.fresh }) : t("pl_nothing")));
  const A = d.auto || {};
  if (A.sync && !A.duty && !A.duty_pc) msgs.push("⚠ " + esc(t("pl_no_duty")));
  note.innerHTML = msgs.join("<br>"); note.classList.toggle("hidden", !msgs.length);
  $("#plAutoLine").innerHTML = plAutoLine(A);
  $("#plLog").innerHTML = plLogBox(d.log || []);
  $("#plToday").innerHTML = d.planned ? plTodayBox(d.today_cards) : "";
  $("#plLate").innerHTML = (d.late || []).length ? `<div class="pl-late"><b>${esc(t("pl_late", { n: d.late.length }))}</b><div class="pl-row">${d.late.map((c) => `<div class="pl-day"><div class="pl-d-h small">${esc(plDay(c.date))}</div><div class="pl-d-b">${plCard(c)}</div></div>`).join("")}</div></div>` : "";
  $("#plWeeks").innerHTML = d.weeks.map((w) => `<div class="pl-week"><div class="pl-w-h"><b>${esc(t("pl_week", { w: w.week }))}</b>
      <span class="muted small">${esc(plDay(w.days[0].date, { day: "numeric", month: "short" }))} – ${esc(plDay(w.days[6].date, { day: "numeric", month: "short" }))}</span>
      ${w.drafts ? `<button class="small pl-approve" data-m="${w.monday}">${esc(t("pl_approve", { n: w.drafts }))}</button>` : ""}
      ${w.days.some((x) => x.cards.some((c) => c.date && !c.moved && !c.sub && !c.done && !x.past)) ? `<button class="small ghost pl-wcancel" data-m="${w.monday}">${esc(t("pl_wcancel"))}</button>` : ""}</div>
    <div class="pl-row pl-cal">${w.days.map((x) => plDayBox(x, d.today)).join("")}</div></div>`).join("") +
    `<div class="sdot-legend muted small">${PL_KEYS.map((k) => `<span><span class="sdot ${k}"></span> ${esc(t("ag_leg_" + k))}</span>`).join("")}</div>`;
}

function plAutoLine(A) {
  const who = A.duty ? t("pl_duty_me") : A.duty_pc ? t("pl_duty_pc", { c: A.duty_pc, m: A.duty_seen ? Math.max(0, Math.round((Date.now() - Date.parse(A.duty_seen)) / 60000)) : "?" }) : t("pl_duty_none");
  const ftp = A.auto_ftp ? t("pl_auto_on", { a: A.ftp_from, b: A.ftp_to }) : t("pl_auto_off");
  const mv = A.move_mode === "approve" ? t("pl_move_m_approve") : t("pl_move_m_evening", { t: A.move_at });
  return `<span class="muted small">🖥 ${esc(who)} · ${esc(mv)} · ${esc(ftp)}${A.err ? " · ⚠ " + esc(A.err) : ""}</span>`;
}
/* rīta kopsavilkums (automātiskā FTP iesniegšana naktī) — jaunie ieraksti kopš pēdējās apskates */
function plLogSeen() { try { return localStorage.getItem("tirg_log_seen") || ""; } catch (_) { return ""; } }
function plLogBox(log) {
  /* test38 (lietotājs 2026-11-12 16:08): variants B ar spilgtu fonu — aģentūras kā čipi; klikšķis — portāls, labais
     klikšķis — "Iesniegts" (✓). Ieraksts pazūd, kad visur ✓; josla — arī ar "Skaidrs". */
  const seen = plLogSeen();
  const chips = (x) => (x.res || []).filter((r) => r.done || r.error).map((r) => {
    const z = (x.agst || {})[r.agency] || {}, ok = z.st === "done", bad = r.error || r.done < r.total;
    return { ag: r.agency, ok, txt: (ok ? "✓ " : bad ? "⚠ " : "○ ") + agName(r.agency) + " " + (bad ? r.done + "/" + r.total : r.done) };
  });
  const fresh = log.filter((x) => (x.at || "") > seen).map((x) => ({ x, c: chips(x) })).filter((e) => !e.c.length || e.c.some((c) => !c.ok));
  if (!fresh.length) return "";
  const todo = fresh.reduce((n, e) => n + e.c.filter((c) => !c.ok).length, 0);
  const line = ({ x, c }) => `<div class="pl-log-set"><b>${esc(x.name)}</b> <span class="pl-log-m">${esc(plDm(x.at))} ${esc(plHm(x.at))}</span>` +
    ((x.skip || []).length ? ` <span class="pl-log-m">· ${esc(t("pl_log_skip"))}: ${x.skip.map((z) => esc(agName(z.agency))).join(", ")}</span>` : "") + `</div>` +
    `<div class="pl-log-chips">${c.map((z) => `<button class="pl-chip${z.ok ? " ok" : ""}" data-set="${esc(x.set)}" data-ag="${esc(z.ag)}" title="${esc(t("pl_log_chip_d"))}">${esc(z.txt)}</button>`).join("")}</div>`;
  return `<div class="pl-log"><div class="pl-log-h"><span class="pl-log-new">${esc(t("pl_log_new"))}</span><b>${esc(t("pl_log_h"))}</b>` +
    (todo ? `<span class="pl-log-m">— ${esc(t("pl_log_todo", { n: todo }))}</span>` : "") +
    `<span class="spacer"></span><button class="pl-log-ok" id="plLogOk">${esc(t("pl_log_ok"))}</button></div>${fresh.map(line).join("")}<div class="pl-log-m small">${esc(t("pl_log_help"))}</div></div>`;
}
document.addEventListener("click", (e) => {
  const ch = e.target.closest(".pl-chip");
  if (ch) { const a = S.agencies.find((z) => z.id === ch.dataset.ag); if (a && a.url) api("open_url", { url: a.url }).catch((err) => toast(err.message, "err")); return; }
  if (!e.target.closest("#plLogOk")) return;
  const last = ((PL.d || {}).log || []).reduce((m, x) => (x.at > m ? x.at : m), "");
  try { localStorage.setItem("tirg_log_seen", last); } catch (_) {}
  $("#plLog").innerHTML = "";
});
document.addEventListener("contextmenu", async (e) => {
  const ch = e.target.closest(".pl-chip"); if (!ch) return;
  e.preventDefault();
  if (ch.classList.contains("ok")) return;
  try {
    const r = await api("set_mark", { id: ch.dataset.set, agency: ch.dataset.ag, state: "submitted" });
    toast(t("sl_marked", { n: r.n, a: agName(ch.dataset.ag) }), "ok", 2500);
    planLoad();
  } catch (err) { toast(err.message, "err"); }
});
/* atcelt komplektu (lietotājs 2026-11-11): OneDrive — jautā, vai atpakaļ uz NAS */
async function plRemove(c) {
  if (!(await uiConfirm(t("pl_remove_q", { s: c.name }), t("pl_remove")))) return;
  try { await api("plan", { do: "remove", id: c.id }); }
  catch (err) {
    if (err.message === "ask_back") {
      const v = await uiDialog(t("pl_back_q", { s: c.name }), [{ v: "back", label: t("pl_back_yes"), cls: "primary" }, { v: "keep", label: t("pl_back_no") }, { v: null, label: t("cancel") }]);
      if (!v) return;
      const back = v === "back";
      try { const r = await api("plan", { do: "remove", id: c.id, back }); if (r.result && r.result.queued) toast(t("pl_back_queued"), "ok", 6000); else if (back) { S.moveShown = false; movePoll(); } }
      catch (e2) { plErr(e2); }
    } else plErr(err);
  }
  planLoad(); load();
}
function plErr(err) { const k = "pl_e_" + err.message, k2 = "move_e_" + err.message; toast(t(k) !== k ? t(k) : t(k2) !== k2 ? t(k2) : err.message, "err sticky", 10000); }
async function plWant(c, what, msg) {
  try { await api("plan", { do: "want", id: c.id, what }); if (msg) toast(t(msg), "ok", 6000); planLoad(); }
  catch (err) { plErr(err); }
}

function plFind(id) {
  const d = PL.d; if (!d) return null;
  const tc = (d.today_cards || []).find((c) => c.id === id); if (tc) return tc;
  for (const w of d.weeks) for (const x of w.days) for (const c of x.cards || []) if (c.id === id) return c;
  return (d.late || []).find((c) => c.id === id) || null;
}
const plSet = (c) => Object.assign({ stems: [] }, c.set_info || {});

$("#page-plan").addEventListener("click", async (e) => {
  if (e.target.closest("#plFill")) { plDlgOpen(); return; }
  const wc = e.target.closest(".pl-wcancel");
  if (wc) {
    if (!(await uiConfirm(t("pl_wcancel_q"), t("pl_wcancel")))) return;
    const d = await planLoad({ do: "cancel", monday: wc.dataset.m });
    if (d) toast(t("pl_cancelled", { n: d.result.removed || 0 }), "ok", 5000);
    load(); return;
  }
  const ap = e.target.closest(".pl-approve");
  if (ap) { await planLoad({ do: "approve", monday: ap.dataset.m }); return; }
  const card = e.target.closest(".pl-card, .pl-today"); if (!card) return;
  const c = plFind(card.dataset.id); if (!c) return;
  if (e.target.closest(".pl-x")) return plRemove(c);
  if (e.target.closest(".pl-movesend")) return plWant(c, "ftp", "pl_want_ftp");
  if (e.target.closest(".pl-movenow")) return plWant(c, "move", "pl_want_move");
  if (e.target.closest(".pl-show")) return setAct("show", plSet(c));
  if (e.target.closest(".pl-th, .pl-c-h b") && window.pickOpenSet) return pickOpenSet(c.id);   /* klikšķis uz bildēm — atver komplektu */
  if (e.target.closest(".pl-edit") && window.pickOpenSet) return pickOpenSet(c.id);
  if (e.target.closest(".pl-open")) return setAct("open", plSet(c));
  if (e.target.closest(".pl-move")) return setAct("move", plSet(c));
  const ag = ($(".pl-ag", card) || {}).value;
  if (e.target.closest(".pl-ftp")) return setAct("ftp", plSet(c), ag);
  if (e.target.closest(".pl-sub")) return setAct("sub", plSet(c), ag);
  if (e.target.closest(".pl-portal") && ag === "*") { toast(t("ag_pick_one"), "err", 5000); return; }
  if (e.target.closest(".pl-portal")) { const a = S.agencies.find((z) => z.id === ag); if (a) api("open_url", { url: a.url }).catch((err) => toast(err.message, "err")); }
});
/* "Ieplānot" — vispirms logs ar parametriem (test22, lietotājs 2026-11-10) */
let PLD = null;
const WD = [0, 1, 2, 3, 4, 5, 6];
async function plDlgOpen() {
  try { PLD = await api("plan", { do: "stats" }); } catch (e) { toast(e.message, "err"); return; }
  $("#pldStock").textContent = t("pld_stock", { rf: PLD.rf, ed: PLD.ed });
  $("#pldStart").value = PLD.start; $("#pldStart").min = PLD.start;
  $("#pldUnit").value = PLD.unit; $("#pldN").value = PLD.n; $("#pldSize").value = PLD.size; $("#pldPer").value = PLD.per_day;
  $("#pldWd").innerHTML = WD.map((k) => `<label class="pld-wd"><input type="checkbox" value="${k}" ${PLD.wdays.includes(k) ? "checked" : ""}> ${esc(new Date(2024, 0, 1 + k).toLocaleDateString(window.langLocale(), { weekday: "short" }))}</label>`).join("");
  plSlots(PLD.slots); plDlgSum(); $("#plDlg").classList.remove("hidden");
}
function plSlots(prev) {
  const n = Math.max(1, Math.min(6, +$("#pldPer").value || 1));
  const cur = prev || [...$$("#pldSlots select")].map((x) => x.value);
  $("#pldSlots").innerHTML = Array.from({ length: n }, (_, i) => `<label class="small">${i + 1}. <select>${["RF", "ED", "rnd"].map((v) => `<option value="${v}" ${(cur[i] || "rnd") === v ? "selected" : ""}>${esc(t("pld_slot_" + v))}</option>`).join("")}</select></label>`).join("");
}
function plDlgVals() {
  return { start: $("#pldStart").value, unit: $("#pldUnit").value, n: +$("#pldN").value, wdays: [...$$("#pldWd input:checked")].map((x) => +x.value),
    per_day: +$("#pldPer").value, slots: [...$$("#pldSlots select")].map((x) => x.value), size: +$("#pldSize").value };
}
function plDlgSum() {
  const o = plDlgVals();
  let days = 0;
  const st = new Date(o.start + "T12:00:00"), mon = new Date(st); mon.setDate(st.getDate() - ((st.getDay() + 6) % 7));
  const end = new Date(o.unit === "days" ? st : mon); end.setDate(end.getDate() + (o.unit === "days" ? o.n : 7 * o.n));
  for (let d = new Date(st); d < end; d.setDate(d.getDate() + 1)) if (o.wdays.includes((d.getDay() + 6) % 7)) days++;
  const sets = days * o.per_day, need = sets * o.size, have = PLD.rf + PLD.ed;
  const rf = o.slots.filter((x) => x === "RF").length * days, ed = o.slots.filter((x) => x === "ED").length * days;
  $("#pldSum").textContent = t("pld_sum2", { d: days, s: sets, rf, ed, r: sets - rf - ed, n: need, h: have }) + (need > have ? " " + t("pld_short", { k: Math.floor(have / Math.max(o.size, 1)) }) : "");
}
$("#plDlg").addEventListener("input", (e) => { if (e.target.id === "pldPer") plSlots(); plDlgSum(); });
$("#plDlg").addEventListener("change", plDlgSum);
$("#plDlgX").addEventListener("click", () => $("#plDlg").classList.add("hidden"));
$("#pldNo").addEventListener("click", () => $("#plDlg").classList.add("hidden"));
$("#pldOk").addEventListener("click", async () => {
  const opt = plDlgVals();
  if (!opt.wdays.length) { toast(t("pld_no_wd"), "err"); return; }
  $("#pldOk").disabled = true;
  try {
    const d = await planLoad({ do: "auto", opt });
    $("#plDlg").classList.add("hidden");
    if (d) toast(d.result.made ? t("pl_made", { n: d.result.made }) : t(d.result.free ? "pl_nothing" : "pl_full"), d.result.made ? "ok" : "err", 5000);
    load();
  } finally { $("#pldOk").disabled = false; }
});

/* labais klikšķis: uz dienas — pievienot / atcelt; uz kartītes — pārvietot šo, atvērt, pārcelt, izņemt (lietotājs 2026-11-10 12:54–12:56) */
function plCtx(x, y, html) {
  const m = $("#plCtx"); m.innerHTML = html; m.classList.remove("hidden");
  const r = m.getBoundingClientRect();
  m.style.left = Math.min(x, innerWidth - r.width - 8) + "px"; m.style.top = Math.min(y, innerHeight - r.height - 8) + "px";
}
document.addEventListener("click", (e) => { if (!e.target.closest("#plCtx")) $("#plCtx").classList.add("hidden"); });
document.addEventListener("keydown", (e) => { if (e.key === "Escape") $("#plCtx").classList.add("hidden"); });
$("#page-plan").addEventListener("contextmenu", (e) => {
  const card = e.target.closest(".pl-card, .pl-today");
  const day = e.target.closest(".pl-day[data-date]");
  if (!card && !day) return;
  e.preventDefault();
  if (card) {
    const c = plFind(card.dataset.id); if (!c) return;
    const plan = c.date && !c.moved && !c.sub && !c.done;
    const A = PL.d.auto || {}, open = !c.done && !c.sub && !c.ftp_done;
    plCtx(e.clientX, e.clientY, `<div class="ctx-h small">${esc(c.name)}</div>` +
      (c.date && c.status !== "approved" && open ? `<button data-a="approve" data-id="${esc(c.id)}">✔ ${esc(t("ctx_approve"))}</button>` : "") +
      (!c.moved && open && c.date ? `<button data-a="movenow" data-id="${esc(c.id)}">☁ ${esc(t("pl_move_now"))}</button>` : "") +
      (open && c.date ? `<button data-a="ftpnow" data-id="${esc(c.id)}">⇡ ${esc(t(c.moved ? "ctx_ftp_now" : "pl_move_send"))}</button>` : "") +
      (open && c.date && A.auto_ftp ? (c.ftp_skip ? `<button data-a="unskip" data-id="${esc(c.id)}">⏱ ${esc(t("ctx_unskip"))}</button>` : `<button data-a="skip" data-id="${esc(c.id)}">⏸ ${esc(t("ctx_skip"))}</button>`) : "") +
      `<button data-a="open" data-id="${esc(c.id)}">✎ ${esc(t("ctx_open_set"))}</button>` +
      `<button data-a="show" data-id="${esc(c.id)}">👁 ${esc(t("set_show"))}</button>` +
      (c.moved ? `<button data-a="dir" data-id="${esc(c.id)}">📁 ${esc(t("ctx_open_dir"))}</button>` : "") +
      (plan ? `<button data-a="day" data-id="${esc(c.id)}">📅 ${esc(t("ctx_other_day"))}</button>` : "") +
      (open && (c.date || c.moved) ? `<button data-a="rm" data-id="${esc(c.id)}">× ${esc(t("ctx_cancel_set"))}</button>` : ""));
    return;
  }
  if (day.classList.contains("past")) return;
  const dd = day.dataset.date, has = $$(".pl-card", day).some((x) => { const c = plFind(x.dataset.id); return c && c.date && !c.moved && !c.sub; });
  plCtx(e.clientX, e.clientY, `<div class="ctx-h small">${esc(plDay(dd, { weekday: "long", day: "numeric", month: "long" }))}</div>` +
    `<button data-a="add" data-d="${dd}">✨ ${esc(t("ctx_add_auto"))}</button><button data-a="new" data-d="${dd}">✋ ${esc(t("ctx_add_own"))}</button>` +
    (has ? `<button data-a="dcancel" data-d="${dd}">× ${esc(t("ctx_day_cancel"))}</button>` : ""));
});
$("#plCtx").addEventListener("click", async (e) => {
  const b = e.target.closest("button[data-a]"); if (!b) return;
  $("#plCtx").classList.add("hidden");
  const a = b.dataset.a, c = b.dataset.id ? plFind(b.dataset.id) : null, dd = b.dataset.d;
  if (a === "move" && c) return setAct("move", plSet(c));
  if (a === "open" && c && window.pickOpenSet) return pickOpenSet(c.id);
  if (a === "show" && c) return setAct("show", plSet(c));
  if (a === "dir" && c) return setAct("open", plSet(c));
  if (a === "rm" && c) return plRemove(c);
  if (a === "approve" && c) return plWant(c, "approve");
  if (a === "movenow" && c) return plWant(c, "move", "pl_want_move");
  if (a === "ftpnow" && c) return plWant(c, "ftp", "pl_want_ftp");
  if (a === "skip" && c) return plWant(c, "skip");
  if (a === "unskip" && c) return plWant(c, "unskip");
  if (a === "day" && c) { const to = await askDate(t("ctx_other_day_q", { s: c.name })); if (to) { await planLoad({ do: "move", id: c.id, to }); load(); } return; }
  if (a === "new" && window.pickNewForDay) return pickNewForDay(dd);
  if (a === "dcancel") { if (await uiConfirm(t("ctx_day_cancel_q"), t("ctx_day_cancel"))) { const d = await planLoad({ do: "cancel", day: dd }); if (d) toast(t("pl_cancelled", { n: d.result.removed || 0 }), "ok", 4000); load(); } return; }
  if (a === "add") {
    $("#plAddQ").textContent = t("pla_q", { d: plDay(dd, { weekday: "long", day: "numeric", month: "long" }) });
    $("#plaSize").value = (PLD && PLD.size) || 25; $("#plAddDlg").dataset.d = dd; $("#plAddDlg").classList.remove("hidden");
  }
});
$("#plaNo").addEventListener("click", () => $("#plAddDlg").classList.add("hidden"));
$("#plaOk").addEventListener("click", async () => {
  const dd = $("#plAddDlg").dataset.d; $("#plaOk").disabled = true;
  try {
    const d = await planLoad({ do: "add", date: dd, cat: $("#plaCat").value, size: +$("#plaSize").value });
    $("#plAddDlg").classList.add("hidden");
    if (d) toast(t("pla_made", { s: d.result.set.name, n: d.result.set.count }), "ok", 5000);
    load();
  } finally { $("#plaOk").disabled = false; }
});
$("#plCancel").addEventListener("click", async () => {
  if (!(await uiConfirm(t("pl_cancel_q"), t("pl_cancel")))) return;
  const d = await planLoad({ do: "cancel" });
  if (d) toast(t("pl_cancelled", { n: d.result.removed || 0 }), "ok", 5000);
  load();
});
$("#plAuto").addEventListener("click", () => {
  plDlgOpen();
});
$("#plPrep").addEventListener("click", async () => {
  if (!(await uiConfirm(t("pl_prep_q", { n: PL.d.ready_next }), t("plan_prep")))) return;
  try { const r = await api("plan", { do: "prepare" }); S.moveShown = false; toast(t("move_start", { n: r.total, d: r.dir }), "ok", 6000); movePoll(); }
  catch (err) { const k = "move_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err sticky", 12000); }
});

/* pārvilkšana uz citu dienu (HTML5 drag & drop) */
$("#page-plan").addEventListener("dragstart", (e) => {
  const c = e.target.closest(".pl-card[draggable=true]"); if (!c) return;
  e.dataTransfer.setData("text/plain", c.dataset.id + "|" + c.dataset.date); e.dataTransfer.effectAllowed = "move"; c.classList.add("drag");
});
$("#page-plan").addEventListener("dragend", (e) => { const c = e.target.closest(".pl-card"); if (c) c.classList.remove("drag"); $$(".pl-day.over").forEach((x) => x.classList.remove("over")); });
$("#page-plan").addEventListener("dragover", (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day || day.classList.contains("past")) return;
  e.preventDefault(); $$(".pl-day.over").forEach((x) => x !== day && x.classList.remove("over")); day.classList.add("over");
});
$("#page-plan").addEventListener("drop", async (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day) return;
  e.preventDefault(); day.classList.remove("over");
  const [id, from] = (e.dataTransfer.getData("text/plain") || "").split("|"); if (!id || from === day.dataset.date) return;
  await planLoad({ do: "move", id, to: day.dataset.date });
  load();
});
