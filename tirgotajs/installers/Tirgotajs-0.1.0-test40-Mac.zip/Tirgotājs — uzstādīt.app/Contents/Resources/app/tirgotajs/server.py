"""Tirgotāja API (prefikss sub_, noteikumi §3, §5) virs kopīgā servera core/server.py."""
from __future__ import annotations

import os

from core import server as core

from . import config, stock


def _ok(**kw):
    kw.setdefault("ok", True)
    return kw


def api_sub_state(_):
    return _ok(**core.base_state(), agencies_all=stock.AGENCIES, ftp_def=stock.FTP_DEF)


def api_sub_ftp_upload(b):
    from . import ftp
    return ftp.upload_set(str(b.get("id") or ""), str(b.get("agency") or ""))


def api_sub_ftp_all(b):
    from . import ftp
    sid = str(b.get("id") or "")
    if b.get("check"):                                    # tikai saraksts apstiprinājumam
        p = ftp.plan_all(sid)
        return {"ok": p.get("ok", False), "go": [{"agency": g["agency"], "n": g["n"]} for g in p.get("go", [])],
                "skip": p.get("skip", []), "error": p.get("error", "")}
    return ftp.upload_all(sid)


def api_sub_ftp_status(_):
    """Vietējais FTP darbs + dežūras datora automātiskā sūtīšana (pultī — no plan.json `ftp_run`, test25)."""
    from datetime import datetime, timedelta
    from . import ftp, plan
    runs = []
    old = (datetime.now() - timedelta(minutes=10)).isoformat(timespec="seconds")
    sets = stock.sets_store().data
    for sid, e in plan.items().items():
        r = e.get("ftp_run")
        if r and (r.get("at") or "") > old and not e.get("ftp_done"):
            runs.append(dict(r, set=sid, name=(sets.get(sid) or {}).get("name") or ""))
    return _ok(job=ftp.status(), runs=runs)


def api_sub_ftp_test(b):
    from . import ftp
    return _ok(result=ftp.test(str(b.get("agency") or ""), b.get("conn") or None))   # rezultāts (arī kļūda ar iemeslu) — saskarnei


def api_sub_list(_):
    from . import drive
    r = stock.listing()
    for it in r["items"]:
        it.pop("kwtext", None)
    r["drive"] = drive.status()
    return r


def api_sub_drive(b):
    """Google Drive: manifesti + agenturas_bildes.json (test21). do=refresh — uzreiz."""
    from . import drive
    if b.get("do") == "refresh":
        return drive.refresh(force=True)
    return _ok(**drive.status())


def api_sub_ask(b):
    from . import assistant
    return assistant.ask(str(b.get("text") or ""), [str(x) for x in (b.get("exclude") or [])][:500])


def api_sub_mark(b):
    n = stock.mark(b.get("stems") or [], b.get("agency") or "", b.get("state") or "", b.get("reason") or "",
                   str(b.get("set") or ""))
    return _ok(n=n)


def api_sub_as_ed(b):
    try:
        n = stock.as_ed(b.get("stems") or [], b.get("agency") or "", bool(b.get("on", True)))
    except ValueError as e:
        return {"ok": False, "error": str(e)}
    return _ok(n=n)


def api_sub_set_suggest(b):
    return stock.suggest(b.get("cat") or "RF", int(b.get("size") or 0), b.get("exclude") or [], str(b.get("match") or ""),
                         b.get("have") or [], topics=[str(x) for x in (b.get("topics") or [])][:8])


def api_sub_themes(b):
    return _ok(themes=[{k: v for k, v in x.items() if k != "stems"} for x in stock.themes(str(b.get("cat") or ""))])


def api_sub_set_add(b):
    return stock.set_add(str(b.get("id") or ""), [str(x) for x in (b.get("stems") or [])])


def api_sub_set_remove(b):
    return stock.set_remove(str(b.get("id") or ""), [str(x) for x in (b.get("stems") or [])])


def api_sub_ask_replace(b):
    from . import assistant
    return assistant.replace(str(b.get("text") or ""), str(b.get("cat") or "RF"), str(b.get("match") or ""),
                             [str(x) for x in (b.get("topics") or [])][:8], [str(x) for x in (b.get("have") or [])],
                             [str(x) for x in (b.get("exclude") or [])])


def api_sub_sim_check(b):
    return _ok(sim=stock.sim_check([str(x) for x in (b.get("stems") or [])][:200]))


def api_sub_not_similar(b):
    from . import similar
    return _ok(n=similar.mark_not_similar([str(x) for x in (b.get("stems") or [])][:50]))


def api_sub_set_save(b):
    """Saglabāt komplektu; `date` — iesniegšanas diena (komplekts uzreiz plānā; test21)."""
    from . import plan
    d = str(b.get("date") or "")
    if d and not plan.day_free(d):
        return {"ok": False, "error": "day_busy", "free": plan.free_days(None, 1)[0]}
    x = stock.set_save(str(b.get("name") or "").strip(), b.get("cat") or "RF", b.get("stems") or [])
    if d:
        r = plan.assign(x["id"], d)
        if not r.get("ok"):
            return _ok(set=x, plan_error=r.get("error"))
        x = dict(stock.sets_store().data.get(x["id"]) or x)  # nosaukums ar plāna dienu
        if b.get("now"):                                   # "Uzreiz uz OneDrive" (2026-11-11)
            plan.want(x["id"], "move")
            x["want_move"] = True
    return _ok(set=x)


def api_sub_set_mark(b):
    """Labais klikšķis uz komplekta punktiņa (6j): uploaded | submitted | part | "" visām komplekta bildēm aģentūrā."""
    r = stock.set_mark(str(b.get("id") or ""), str(b.get("agency") or ""), str(b.get("state") or ""))
    if not r.get("ok"):
        return {"ok": False, "error": r.get("error")}
    return _ok(n=r["n"])


def api_sub_autostart(b):
    """Palaist kopā ar datoru (core/autostart; datora iestatījums — no OS)."""
    from core import autostart
    if "on" in b:
        return autostart.set_enabled(bool(b.get("on")))
    return _ok(on=autostart.enabled())


def api_sub_auto(_):
    from . import auto
    return _ok(**auto.info())


def api_sub_set_delete(b):
    stock.set_delete(str(b.get("id") or ""))
    return _ok()


def api_sub_nas_delete(b):
    from . import move
    return move.nas_delete(list(b.get("stems") or []))


def api_sub_set_move(b):
    from . import move
    return move.move_set(str(b.get("id") or ""))


def api_sub_activity(_):
    """Statusa joslas indikators (lietotājs 2026-11-12 16:36): kas notiek šajā datorā, ko dara dežūras dators (pultī —
    no plan.json `move_run`/`ftp_run`), kas gaidāms nākamais."""
    from datetime import datetime, timedelta
    from . import auto, move, nasrecv, plan
    old = (datetime.now() - timedelta(minutes=3)).isoformat(timespec="seconds")
    runs = []
    for sid, e in plan.items().items():
        r = e.get("move_run")
        if r and (r.get("at") or "") > old:
            runs.append(dict(r, kind="move"))
    uniq = {(r.get("set"), r.get("kind")): r for r in runs}
    return _ok(move=move.status(), nas=nasrecv.status(), remote=list(uniq.values()), next=auto.next_info(), auto=auto.info())


def api_sub_move_status(_):
    from . import move
    return _ok(job=move.status())


def api_sub_sets(_):
    """Komplekti + plāna ceļš (diena, solis) — saraksts "variants A" (NODOSANA 6c)."""
    from datetime import date
    from . import auto, plan
    sl = stock.sets_list()
    it_ = plan.items()
    today = date.today()
    for x in sl:
        e = it_.get(x["id"]) or {}
        x["plan"] = {k: e.get(k) for k in ("date", "status") if e.get(k)}
        x["plan"].update(plan._stage(x, e, today))
        sd = plan.sub_day(x)
        x["day"] = sd or e.get("date") or (plan._local_day(x["moved_at"]) if x.get("rel") and x.get("moved_at") else "")
        x["sub"] = sd
    return _ok(sets=sl, agencies=stock.agencies(), today=today.isoformat(), auto=auto.info(), set_dir=stock.set_dir())


def api_sub_set_dir(b):
    p = str(b.get("path") or "").strip()
    if p and not os.path.isdir(p):
        return {"ok": False, "error": "dir_missing"}
    config.update({"sub_ready_dir": p})
    return _ok()


def api_sub_open(b):
    p = str(b.get("path") or "")
    if not os.path.exists(p):
        return {"ok": False, "error": "dir_missing"}
    core._open_folder(p if os.path.isdir(p) else os.path.dirname(p))
    return _ok()


def api_sub_open_url(b):
    u = str(b.get("url") or "")
    if u not in stock.portal_urls():                          # tikai aģentūru lapas (noklusējums vai iestatījumos)
        return {"ok": False, "error": "url"}
    from core import browser
    browser.open_url(u)
    return _ok()


def _get_thumb(q):
    if q.get("t") != core.TOKEN:
        return 403, b"", "text/plain", None
    data = stock.thumb(q.get("s") or "", q.get("n") or "")
    if not data:
        return 404, b"", "text/plain", None
    return 200, data, "image/jpeg", {"Cache-Control": "max-age=3600"}


def _get_full(q):
    if q.get("t") != core.TOKEN:
        return 403, b"", "text/plain", None
    data = stock.full_image(q.get("n") or "") or stock.thumb("", q.get("n") or "")   # "uz NAS" — tikai sīktēls
    if not data:
        return 404, b"", "text/plain", None
    return 200, data, "image/jpeg", {"Cache-Control": "max-age=600"}


def api_sub_plan(b):
    from . import plan
    do = str(b.get("do") or "view")
    if do == "auto":
        r = plan.auto(opt=b.get("opt") or {})
    elif do == "stats":
        return plan.stats()
    elif do == "cancel":
        r = plan.cancel(str(b.get("monday") or ""), str(b.get("day") or ""))
    elif do == "add":
        r = plan.add_auto(str(b.get("date") or ""), str(b.get("cat") or "rnd"), b.get("size"))
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error")}
    elif do == "move":
        r = plan.move_day(str(b.get("id") or ""), str(b.get("to") or ""))
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error")}
    elif do == "approve":
        r = plan.approve_week(str(b.get("monday") or ""), b.get("on") is not False)
    elif do == "remove":
        bk = b.get("back")
        r = plan.remove(str(b.get("id") or ""), None if bk is None else bool(bk))
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error")}
    elif do == "want":
        r = plan.want(str(b.get("id") or ""), str(b.get("what") or ""))
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error")}
    elif do == "prepare":
        return plan.prepare_next()
    elif do == "assign":
        r = plan.assign(str(b.get("id") or ""), str(b.get("date") or ""))
        if not r.get("ok"):
            return {"ok": False, "error": r.get("error"), "free": r.get("free", "")}
        return _ok(**r)
    elif do == "free":
        return _ok(free=plan.free_days(None, 30))
    else:
        r = {}
    v = plan.view()
    return {**v, "result": r}


API = {k[len("api_sub_"):]: v for k, v in dict(globals()).items() if k.startswith("api_sub_")}


def start(port: int = 0):
    core.register_get({"/thumb": _get_thumb, "/full": _get_full})
    try:
        from core import backup
        from . import appdef
        backup.set_hooks(after_restore=appdef.after_restore,
                         info=lambda _p=None: {"marks": len(stock.ledger().data), "sets": len(stock.sets_store().data)})
        backup.start_scheduler(lambda: False)
        from core import sync
        sync.start()                     # sinhronizācija starp datoriem (ja ieslēgta; dati §7a)
        from core import manifests_drive
        manifests_drive.start()          # neaugšupielādētie manifesti no iepriekšējās reizes (test21)
        import platform
        print(f"dators: {platform.node()} · gatavo bilžu mape: {config.get('sub_ready_dir') or '—'}"
              f" · komplektu mape: {config.get('sub_set_dir') or '—'}")
        from . import drive
        drive.start()                    # manifesti un agenturas_bildes.json no Google Drive (test21)
        import threading as _th
        _th.Thread(target=lambda: (stock.restore_sets(), stock.nas_init()), daemon=True, name="restore-sets").start()
        from . import move as _mv
        _th.Thread(target=_mv.purge_trash, daemon=True, name="purge-trash").start()
        from . import auto
        auto.start()                     # dežūras dators: uz OneDrive vakarā + nakts FTP (2026-11-10/11)
        print(f"dežūras dators: {'jā' if auto.duty() else 'nē (pults)'} · automātiskā FTP iesniegšana: "
              f"{'ieslēgta' if config.get('sub_auto_ftp') else 'izslēgta'} {config.get('sub_ftp_from')}–{config.get('sub_ftp_to')}")
        core.ON_SHUTDOWN.append(lambda: sync.on_close(10))   # aizverot — nosūta neaizsūtītās izmaiņas (≤ 10 s)
    except Exception as e:
        print("rezerves kopijas:", e)
    res = core.start(port)
    core.register(API)
    return res


shutdown = core.shutdown
idle_watch = core.idle_watch
