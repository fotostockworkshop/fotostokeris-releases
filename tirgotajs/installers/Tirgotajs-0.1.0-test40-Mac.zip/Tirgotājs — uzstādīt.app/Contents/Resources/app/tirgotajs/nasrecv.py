"""NAS saņemšanas atskaite (lēmums 2026-11-13 14:17, dati §7a 17–19) — tikai dežūras datorā (redz NAS).

Ik ~30 min (un pēc vakara pārvietošanas) pārbauda Vārdotāja sūtījumus gatavo mapē (`sub_ready_dir`): katram failam
sūtījuma mapē (arī RAW/.xmp un `Original/`, bez `_fotostokeris/`) — izmērs + MD5. Raksta Google Drive
`Fotostokeris/Kopigi/nas_sanemts.json` (raksta tikai Tirgotājs; pārraksta to pašu failu):
  {format: 1, updated, computer, shipments: {<series_id>: {folder, sender, checked_at, complete, files: {rel: {bytes, md5}}}}}
`sender` — manifesta lauks `computer` (§7a 17a). Sūtījumu, kurā atrasti visi manifesta faili (`complete`), vairs
nepārbauda (pēc 6 h bez izmaiņām). Ieraksti vecāki par 60 dienām tiek izmesti. Vārdotājs to lasa un piedāvā dzēst vietējās kopijas.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import time
from datetime import datetime, timedelta, timezone

from . import config, stock

FILE = "nas_sanemts.json"
EVERY = 1800                       # ~30 min
KEEP_DAYS = 60
QUIET_H = 6                        # pilnu sūtījumu vēl pārbauda 6 h (RAW/.xmp var atnākt vēlāk)
SETTLE_S = 120                     # fails nav mainīts ≥ 2 min (Synology vēl neraksta)
SKIP = {"thumbs.db", ".ds_store", "desktop.ini"}

_lock = threading.Lock()
_st: dict = {"last": 0.0, "thread": None, "running": False, "file_id": None, "err": "", "current": "", "done": 0,
             "total": 0}


def _path():
    return config.app_dir() / FILE


def _load() -> dict:
    try:
        with open(_path(), encoding="utf-8") as f:
            d = json.load(f)
            if isinstance(d, dict) and isinstance(d.get("shipments"), dict):
                return d
    except (OSError, ValueError):
        pass
    return {"format": 1, "shipments": {}}


def _save(d: dict) -> bytes:
    raw = json.dumps(d, ensure_ascii=False, indent=1).encode("utf-8")
    tmp = _path().with_suffix(".tmp")
    tmp.write_bytes(raw)
    os.replace(tmp, _path())
    return raw


def _md5(p: str) -> str:
    h = hashlib.md5()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _files(folder: str) -> list[str]:
    """Sūtījuma faili (relatīvi, ar "/"): saknē un `Original/`; bez `_fotostokeris/`, pagaidu un sistēmas failiem."""
    out = []
    for sub in ("", "Original"):
        d = os.path.join(folder, sub) if sub else folder
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            p = os.path.join(d, f)
            if not os.path.isfile(p) or f.startswith(".") or f.lower() in SKIP or f.lower().endswith((".part", ".tmp")):
                continue
            out.append(f"{sub}/{f}" if sub else f)
    return out


def _expected(data: dict) -> set[str]:
    want = set()
    for r in data.get("images") or []:
        if r.get("status") in ("deleted",):
            continue
        if r.get("file"):
            want.add(str(r["file"]))
        o = r.get("original")
        if isinstance(o, dict) and o.get("file"):
            want.add(str(o["file"]).replace("\\", "/"))
    return want


def _pull_existing(d: dict) -> dict:
    """Ja lokālās kopijas nav (dežūra pārcelta uz citu datoru) — sāk no Google versijas."""
    if d.get("shipments"):
        return d
    try:
        from core import google
        fid = google.folder("Kopigi")
        f = next((x for x in google.list_files(fid) if x.get("name") == FILE), None)
        if f:
            _st["file_id"] = f["id"]
            g = json.loads(google.download(f["id"]).decode("utf-8") or "{}")
            if isinstance(g.get("shipments"), dict):
                return g
    except Exception as e:
        print(f"NAS atskaite: Google versiju nevar nolasīt — {e}"[:200])
    return d


def _upload(raw: bytes) -> None:
    from core import google
    if not google.connected():
        return
    fid = google.folder("Kopigi")
    if not _st["file_id"]:
        f = next((x for x in google.list_files(fid) if x.get("name") == FILE), None)
        _st["file_id"] = f["id"] if f else None
    r = google.put_bytes(fid, FILE, raw, _st["file_id"])
    _st["file_id"] = r.get("id") or _st["file_id"]


def run() -> dict:
    """Viena pārbaude (sinhroni). Atgriež {checked, new_files, shipments}."""
    root = str(config.get("sub_ready_dir") or "").strip()
    if not root or not os.path.isdir(root):
        return {"ok": False, "error": "no_nas"}
    with _lock:
        _st.update(running=True, err="", done=0, total=0, current="")
        try:
            d = _pull_existing(_load())
            sh = d.setdefault("shipments", {})
            todo = []
            quiet = (datetime.now(timezone.utc) - timedelta(hours=QUIET_H)).isoformat(timespec="seconds")
            for folder, jp in stock._manifests(root):
                if stock.TRASH.lower() in os.path.normcase(folder).lower():
                    continue
                try:
                    with open(jp, encoding="utf-8") as f:
                        data = json.load(f)
                except (OSError, ValueError):
                    continue
                sid = str(data.get("series_id") or "")
                e0 = sh.get(sid) or {}
                if not sid or (data.get("kind") or "series") != "series":
                    continue
                if e0.get("complete") and str(e0.get("changed_at") or "") < quiet:   # pilns un 6 h nekas nav nācis klāt
                    continue
                todo.append((sid, folder, data))
            _st["total"] = len(todo)
            changed, nfiles = False, 0
            now = time.time()
            for sid, folder, data in todo:
                _st["current"] = os.path.basename(folder)
                e = sh.get(sid) or {}
                files = dict(e.get("files") or {})
                for rel in _files(folder):
                    p = os.path.join(folder, *rel.split("/"))
                    try:
                        stt = os.stat(p)
                        if now - stt.st_mtime < SETTLE_S:
                            continue
                        old = files.get(rel)
                        if old and old.get("bytes") == stt.st_size:
                            continue
                        files[rel] = {"bytes": stt.st_size, "md5": _md5(p)}
                        nfiles += 1
                    except OSError:
                        continue
                want = _expected(data)
                complete = bool(want) and want <= set(files)
                if files != e.get("files") or complete != bool(e.get("complete")) or not e:
                    sh[sid] = {"folder": os.path.relpath(folder, root).replace(os.sep, "/"),
                               "sender": data.get("computer") or "", "checked_at": stock._now(),
                               "changed_at": stock._now() if files != e.get("files") else e.get("changed_at") or stock._now(),
                               "complete": complete, "files": files}
                    changed = True
                _st["done"] += 1
            cut = (datetime.now(timezone.utc) - timedelta(days=KEEP_DAYS)).isoformat(timespec="seconds")
            for k in [k for k, v in sh.items() if str(v.get("checked_at") or "") < cut]:
                del sh[k]
                changed = True
            if changed:
                try:
                    from core import sync
                    pc = sync.computer()
                except Exception:
                    pc = ""
                d.update(format=1, updated=stock._now(), computer=pc)
                raw = _save(d)
                try:
                    _upload(raw)
                except Exception as ex:
                    _st["err"] = f"Google: {ex}"[:200]
                    print("NAS atskaite: augšupielāde neizdevās —", _st["err"])
            if nfiles:
                print(f"NAS atskaite: pārbaudīti {nfiles} faili {len(todo)} sūtījumos")
            return {"ok": True, "checked": len(todo), "new_files": nfiles, "shipments": len(sh)}
        except Exception as ex:
            _st["err"] = f"{type(ex).__name__}: {ex}"[:200]
            print("NAS atskaite: kļūda —", _st["err"])
            return {"ok": False, "error": _st["err"]}
        finally:
            _st.update(running=False, current="", last=time.time())


def maybe(force: bool = False) -> None:
    """No dežūras cilpas: fonā, ne biežāk kā ik ~30 min (force — pēc pārvietošanas)."""
    if _st["running"] or (not force and time.time() - _st["last"] < EVERY):
        return
    _st["last"] = time.time()
    t = threading.Thread(target=run, daemon=True, name="nasrecv")
    _st["thread"] = t
    t.start()


def status() -> dict:
    return {k: _st[k] for k in ("running", "current", "done", "total", "err", "last")}
