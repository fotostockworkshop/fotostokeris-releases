"use strict";
/* Tirgotājs — cilne "Plāns" (plan.py; kopsavilkums §11, lēmumi 2026-11-05 16:27–16:59).
   Nedēļas × dienas, kartīte = komplekts; pārvilkt uz citu dienu; "Apstiprināt nedēļu"; "Sagatavot nākamo nedēļu"
   (pārvieto uz OneDrive mapēm pēc plānotās dienas); augšā "Šodien" un nokavētie. Darbības ar komplektu — setAct (app.js). */
const PL = { d: null };

async function planLoad(body) {
  let d;
  try { d = await api("plan", body || {}); } catch (e) { toast(e.message, "err"); return null; }
  PL.d = d;
  planPaint();
  return d;
}
window.planLoad = planLoad;

const plDay = (iso, o) => new Date(iso + "T12:00").toLocaleDateString(window.langLocale(), o || { weekday: "short", day: "numeric", month: "numeric" });
function plHead(z) {
  return z.st === "done" ? t("ag_done", { d: z.date ? plDay(z.date.slice(0, 10), { day: "2-digit", month: "2-digit" }) : "" }) : z.st === "part" ? t("ag_part", { s: z.sub, n: z.n })
    : z.st === "up" ? t("ag_up", { u: z.up, n: z.n }) : z.st === "bad" ? t("ag_bad_l") : z.st === "plan" ? t("ag_plan_l") : t("ag_none_l");
}
/* stāvokļi (lēmums 2026-11-05 22:04): ⚪ plānots (nav pārvietots) · 🔴 gatavs iesniegšanai · 🟠 augšupielādēts · 🔵 daļēji · 🟢 iesniegts */
const PL_KEYS = ["plan", "none", "up", "part", "done", "bad"];
const PL_LEG = () => "\n— " + PL_KEYS.map((k) => ({ done: "🟢", part: "🔵", up: "🟠", none: "🔴", plan: "⚪", bad: "◌" })[k] + " " + t("ag_leg_" + k)).join("\n— ");
window.PL_KEYS = PL_KEYS;
/* kopējais komplekta stāvoklis vienam punktam */
function plOverall(agst) {
  const v = Object.values(agst || {}); if (!v.length) return "none";
  if (v.every((z) => z.st === "done" || z.st === "bad") && v.some((z) => z.st === "done")) return "done";
  if (v.some((z) => z.st === "done" || z.st === "part")) return "part";
  if (v.some((z) => z.st === "up")) return "up";
  if (v.every((z) => z.st === "bad")) return "bad";
  return v.some((z) => z.st === "plan") ? "plan" : "none";
}
function plDots(c) {
  return (PL.d.agencies || []).map((a) => {
    const z = (c.agst || {})[a.id]; if (!z) return "";
    return `<span class="sdot ${z.st}${z.rej ? " rej" : ""}" title="${esc(a.name + " — " + plHead(z) + PL_LEG())}"></span>`;
  }).join("");
}
function plState(c) {
  return c.done ? t("pl_st_done") : c.sub ? t("pl_st_sub") : c.moved ? t("pl_st_moved") : c.status === "approved" ? t("pl_st_approved") : c.date ? t("pl_st_draft") : t("pl_st_moved");
}
function plCard(c, big) {
  const tok = encodeURIComponent(window.TOKEN);
  const th = (c.thumbs || []).map((x) => `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(x.series)}&n=${encodeURIComponent(x.stem)}" alt="">`).join("");
  const cls = c.done ? "done" : c.sub ? "sub" : c.moved ? "moved" : c.status || "moved";
  const drag = c.date && !c.moved && !c.done && !c.sub;
  return `<div class="pl-card ${cls}${big ? " big" : ""}" draggable="${drag ? "true" : "false"}" data-id="${esc(c.id)}" data-date="${c.date || ""}">
    <div class="pl-c-h"><span class="sdot ${plOverall(c.agst)}"></span><b title="${esc(c.name)}">${esc(c.name)}</b><span class="cat cat-${esc(c.cat)}">${esc(c.cat)}</span></div>
    <div class="pl-th">${th || `<div class="ns-noimg"></div>`}</div>
    <div class="pl-c-f small"><span>${c.count} · ${esc(plState(c))}${c.remote ? ` · <span class="nas-badge" title="${esc(t("nas_tip"))}">${esc(t("nas_badge"))}</span>` : ""}</span><span class="pl-dots">${plDots(c)}</span></div>
    <div class="pl-c-a">${c.moved ? `<button class="small ghost pl-open" title="${esc(c.dir)}">📁</button>` : ""}
      <button class="small ghost pl-show" title="${esc(t("set_show"))}">👁</button>
      ${drag ? `<button class="small ghost pl-edit" title="${esc(t("pl_edit"))}">✎</button><button class="small ghost pl-x" title="${esc(t("pl_remove"))}">×</button>` : ""}</div></div>`;
}
function plTodayBox(c) {
  if (!c) return `<div class="pl-today muted">${esc(t("pl_today_none"))}</div>`;
  const ags = PL.d.agencies || [];
  return `<div class="pl-today" data-id="${esc(c.id)}"><div class="pl-today-h"><b>${esc(t("pl_today"))}</b> <span class="muted">${esc(plDay(c.date, { weekday: "long", day: "numeric", month: "long" }))}</span></div>
    <div class="row">${plCard(c, true)}
    <div class="pl-today-a">${c.moved ? "" : `<div class="small warn">${esc(t("pl_not_moved"))}</div><button class="small primary pl-move">${esc(t("set_move"))}</button>`}
      <div class="row"><select class="pl-ag"><option value="*">${esc(t("ag_all_ftp"))}</option>${ags.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select>
      <button class="small pl-ftp">${esc(t("set_ftp"))}</button><button class="small pl-portal">${esc(t("open_ag"))} ↗</button><button class="small pl-sub">${esc(t("set_sub"))}</button></div></div></div></div>`;
}
/* dienas rāmis — variants B (lēmums 2026-11-05 21:39): virsraksts kā josla rāmja augšā; šodiena — zaļa */
function plDayBox(x, today) {
  const isT = x.date === today;
  const head = (isT ? t("pl_today") + " · " : "") + plDay(x.date, { weekday: "short", day: "2-digit", month: "2-digit" });
  return `<div class="pl-day${x.past ? " past" : ""}${isT ? " today" : ""}" data-date="${x.date}"><div class="pl-d-h small">${esc(head)}</div>
    <div class="pl-d-b">${(x.cards || []).length ? x.cards.map((c) => plCard(c)).join("") : `<div class="pl-empty muted small">—</div>`}</div></div>`;
}
function planPaint() {
  const d = PL.d; if (!d) return;
  $("#plInfo").textContent = t("pl_info", { n: d.planned });
  $("#plPrep").disabled = !d.ready_next;
  $("#plPrep").title = d.ready_next ? t("plan_prep_d") : t("pl_prep_none");
  const note = $("#plNote");
  const msgs = [];
  if (!d.has_set_dir) msgs.push(esc(t("pl_no_setdir")));
  if (d.fresh >= 5 && d.planned) msgs.push(`${esc(t("pl_fresh", { n: d.fresh }))} <button class="small" id="plFill">${esc(t("pl_fill"))}</button>`);
  if (!d.planned) msgs.push(esc(d.fresh ? t("pl_empty", { n: d.fresh }) : t("pl_nothing")));
  note.innerHTML = msgs.join("<br>"); note.classList.toggle("hidden", !msgs.length);
  $("#plToday").innerHTML = d.planned ? plTodayBox(d.today_card) : "";
  $("#plLate").innerHTML = (d.late || []).length ? `<div class="pl-late"><b>${esc(t("pl_late", { n: d.late.length }))}</b><div class="pl-row">${d.late.map((c) => `<div class="pl-day"><div class="pl-d-h small">${esc(plDay(c.date))}</div><div class="pl-d-b">${plCard(c)}</div></div>`).join("")}</div></div>` : "";
  $("#plWeeks").innerHTML = d.weeks.map((w) => `<div class="pl-week"><div class="pl-w-h"><b>${esc(t("pl_week", { w: w.week }))}</b>
      <span class="muted small">${esc(plDay(w.days[0].date, { day: "numeric", month: "short" }))} – ${esc(plDay(w.days[6].date, { day: "numeric", month: "short" }))}</span>
      ${w.drafts ? `<button class="small pl-approve" data-m="${w.monday}">${esc(t("pl_approve", { n: w.drafts }))}</button>` : ""}
      ${w.days.some((x) => x.cards.some((c) => c.date && !c.moved && !c.sub && !c.done && !x.past)) ? `<button class="small ghost pl-wcancel" data-m="${w.monday}">${esc(t("pl_wcancel"))}</button>` : ""}</div>
    <div class="pl-row pl-cal">${w.days.map((x) => plDayBox(x, d.today)).join("")}</div></div>`).join("") +
    `<div class="sdot-legend muted small">${PL_KEYS.map((k) => `<span><span class="sdot ${k}"></span> ${esc(t("ag_leg_" + k))}</span>`).join("")}</div>`;
}

function plFind(id) {
  const d = PL.d; if (!d) return null;
  if (d.today_card && d.today_card.id === id) return d.today_card;
  for (const w of d.weeks) for (const x of w.days) for (const c of x.cards || []) if (c.id === id) return c;
  return (d.late || []).find((c) => c.id === id) || null;
}
const plSet = (c) => Object.assign({ stems: [] }, c.set_info || {});

$("#page-plan").addEventListener("click", async (e) => {
  if (e.target.closest("#plFill")) { plDlgOpen(); return; }
  const wc = e.target.closest(".pl-wcancel");
  if (wc) {
    if (!(await uiConfirm(t("pl_wcancel_q"), t("pl_wcancel")))) return;
    const d = await planLoad({ do: "cancel", monday: wc.dataset.m });
    if (d) toast(t("pl_cancelled", { n: d.result.removed || 0 }), "ok", 5000);
    load(); return;
  }
  const ap = e.target.closest(".pl-approve");
  if (ap) { await planLoad({ do: "approve", monday: ap.dataset.m }); return; }
  const card = e.target.closest(".pl-card, .pl-today"); if (!card) return;
  const c = plFind(card.dataset.id); if (!c) return;
  const date = c.date;
  if (e.target.closest(".pl-x")) {
    if (!(await uiConfirm(t("pl_remove_q", { s: c.name }), t("pl_remove")))) return;
    await planLoad({ do: "remove", date }); load(); return;
  }
  if (e.target.closest(".pl-show")) return setAct("show", plSet(c));
  if (e.target.closest(".pl-th, .pl-c-h b") && window.pickOpenSet) return pickOpenSet(c.id);   /* klikšķis uz bildēm — atver komplektu */
  if (e.target.closest(".pl-edit") && window.pickOpenSet) return pickOpenSet(c.id);
  if (e.target.closest(".pl-open")) return setAct("open", plSet(c));
  if (e.target.closest(".pl-move")) return setAct("move", plSet(c));
  const ag = ($(".pl-ag", card) || {}).value;
  if (e.target.closest(".pl-ftp")) return setAct("ftp", plSet(c), ag);
  if (e.target.closest(".pl-sub")) return setAct("sub", plSet(c), ag);
  if (e.target.closest(".pl-portal") && ag === "*") { toast(t("ag_pick_one"), "err", 5000); return; }
  if (e.target.closest(".pl-portal")) { const a = S.agencies.find((z) => z.id === ag); if (a) api("open_url", { url: a.url }).catch((err) => toast(err.message, "err")); }
});
/* "Ieplānot" — vispirms logs ar parametriem (test22, lietotājs 2026-11-10) */
let PLD = null;
async function plDlgOpen() {
  try { PLD = await api("plan", { do: "stats" }); } catch (e) { toast(e.message, "err"); return; }
  $("#pldStock").textContent = t("pld_stock", { rf: PLD.rf, ed: PLD.ed });
  $("#pldStart").value = PLD.start; $("#pldStart").min = PLD.start;
  $("#pldWeeks").value = PLD.weeks; $("#pldPer").value = PLD.per_week; $("#pldSize").value = PLD.size; $("#pldEd").value = PLD.ed_week;
  plDlgSum(); $("#plDlg").classList.remove("hidden");
}
function plDlgSum() {
  const w = +$("#pldWeeks").value || 0, p = +$("#pldPer").value || 0, z = +$("#pldSize").value || 0, e = Math.min(+$("#pldEd").value || 0, p);
  const sets = w * p, need = sets * z, have = PLD.rf + PLD.ed;
  $("#pldSum").textContent = t("pld_sum", { s: sets, rf: w * (p - e), ed: w * e, n: need, h: have }) + (need > have ? " " + t("pld_short", { k: Math.floor(have / Math.max(z, 1)) }) : "");
}
["#pldWeeks", "#pldPer", "#pldSize", "#pldEd"].forEach((id) => $(id).addEventListener("input", plDlgSum));
$("#plDlgX").addEventListener("click", () => $("#plDlg").classList.add("hidden"));
$("#pldNo").addEventListener("click", () => $("#plDlg").classList.add("hidden"));
$("#pldOk").addEventListener("click", async () => {
  const opt = { start: $("#pldStart").value, weeks: +$("#pldWeeks").value, per_week: +$("#pldPer").value, size: +$("#pldSize").value, ed_week: +$("#pldEd").value };
  $("#pldOk").disabled = true;
  try {
    const d = await planLoad({ do: "auto", opt });
    $("#plDlg").classList.add("hidden");
    if (d) toast(d.result.made ? t("pl_made", { n: d.result.made }) : t(d.result.free ? "pl_nothing" : "pl_full"), d.result.made ? "ok" : "err", 5000);
    load();
  } finally { $("#pldOk").disabled = false; }
});
$("#plCancel").addEventListener("click", async () => {
  if (!(await uiConfirm(t("pl_cancel_q"), t("pl_cancel")))) return;
  const d = await planLoad({ do: "cancel" });
  if (d) toast(t("pl_cancelled", { n: d.result.removed || 0 }), "ok", 5000);
  load();
});
$("#plAuto").addEventListener("click", () => {
  plDlgOpen();
});
$("#plPrep").addEventListener("click", async () => {
  if (!(await uiConfirm(t("pl_prep_q", { n: PL.d.ready_next }), t("plan_prep")))) return;
  try { const r = await api("plan", { do: "prepare" }); S.moveShown = false; toast(t("move_start", { n: r.total, d: r.dir }), "ok", 6000); movePoll(); }
  catch (err) { const k = "move_e_" + err.message; toast(t(k) !== k ? t(k) : err.message, "err sticky", 12000); }
});

/* pārvilkšana uz citu dienu (HTML5 drag & drop) */
$("#page-plan").addEventListener("dragstart", (e) => {
  const c = e.target.closest(".pl-card[draggable=true]"); if (!c) return;
  e.dataTransfer.setData("text/plain", c.dataset.date); e.dataTransfer.effectAllowed = "move"; c.classList.add("drag");
});
$("#page-plan").addEventListener("dragend", (e) => { const c = e.target.closest(".pl-card"); if (c) c.classList.remove("drag"); $$(".pl-day.over").forEach((x) => x.classList.remove("over")); });
$("#page-plan").addEventListener("dragover", (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day || day.classList.contains("past")) return;
  e.preventDefault(); $$(".pl-day.over").forEach((x) => x !== day && x.classList.remove("over")); day.classList.add("over");
});
$("#page-plan").addEventListener("drop", async (e) => {
  const day = e.target.closest(".pl-day[data-date]"); if (!day) return;
  e.preventDefault(); day.classList.remove("over");
  const from = e.dataTransfer.getData("text/plain"); if (!from || from === day.dataset.date) return;
  const d = await planLoad({ do: "move", from, to: day.dataset.date });
  if (d && !d.result.ok) toast(t("pl_e_" + d.result.error), "err", 5000);
  load();
});
