"""Plāns — iesniegšana pa dienām (kopsavilkums §11, lēmumi 2026-11-05 16:27–16:59; NODOSANA §6a C).

plan.json (sinhronizējas): {"days": {"YYYY-MM-DD": {"set": id, "theme": "Bali", "cat": "RF", "status": draft|approved}}}.
Komplekts ir parasts komplekts (sets.json) ar `planned` = diena. "Pārvietots" (OneDrive) un "iesniegts" — no komplekta,
nevis glabā plānā. Mapes OneDrive pēc plānotās dienas (move.target); pārvieto tikai nākamās nedēļas apstiprinātos.
"""
from __future__ import annotations

import os
from datetime import date, datetime, timedelta

from . import config, stock

_store: config.JsonStore | None = None
MIN_SIZE, MAX_SIZE = 10, 50
NEW_DAYS = 30            # "jaunie ED" — uzņemti pēdējās 30 dienās — plānā pirmie


def store() -> config.JsonStore:
    global _store
    if _store is None:
        _store = config.JsonStore(config.app_dir() / "plan.json", {"days": {}})
        _store.data.setdefault("days", {})
    return _store


def _cfg() -> tuple[int, int]:
    try:
        w = max(1, min(12, int(config.get("sub_plan_weeks") or 6)))
        n = max(1, min(7, int(config.get("sub_plan_per_week") or 5)))
    except (TypeError, ValueError):
        w, n = 6, 5
    return w, n


def monday(d: date) -> date:
    return d - timedelta(days=d.weekday())


def days(today: date | None = None) -> list[date]:
    """Plāna dienas: no šīs nedēļas pirmdienas, `weeks` nedēļas, katrā pirmās `per` dienas (P, O, T …)."""
    w, n = _cfg()
    m = monday(today or date.today())
    return [m + timedelta(days=7 * i + k) for i in range(w) for k in range(n)]


def _clean() -> None:
    """Dzēsts komplekts → plāna diena atbrīvojas."""
    st, sets = store(), stock.sets_store().data
    with st.lock:
        gone = [k for k, e in st.data["days"].items() if e.get("set") and e["set"] not in sets]
        for k in gone:
            st.data["days"].pop(k, None)
        if gone:
            st.save()


def _done(info: dict) -> bool:
    z = (info or {}).get("status") or {}
    return bool(z) and all(v.get("st") in ("done", "bad") for v in z.values()) and any(v.get("st") == "done" for v in z.values())


def view() -> dict:
    _clean()
    today = date.today()
    sets = {x["id"]: x for x in stock.sets_list()}
    r = stock.listing()
    by = {it["stem"]: it for it in r["items"]}
    dd = store().data["days"]
    ds = days(today)

    def card(k: str) -> dict | None:
        e = dd.get(k)
        if not e:
            return None
        x = sets.get(e.get("set")) or {}
        th = [{"stem": s, "series": by[s]["series"]} for s in (x.get("stems") or []) if s in by and by[s].get("thumb")][:4]
        moved = bool(x.get("moved")) and x.get("moved", 0) >= x.get("count", 0) - x.get("missing", 0)
        return {**e, "date": k, "name": x.get("name") or e.get("theme"), "count": x.get("count", 0), "thumbs": th,
                "agst": x.get("status") or {}, "moved": moved, "done": _done(x), "dir": x.get("dir") or "",
                "missing": x.get("missing", 0), "set_info": x}
    # OneDrive komplekti, kas nav plānā (izveidoti un pārvietoti ar roku) — pēc mapes <gads>/<MM-mēn>/<nedēļa>/
    in_plan = {e.get("set") for e in dd.values()}
    extra: dict[tuple, list] = {}
    for x in sets.values():
        parts = str(x.get("rel") or "").split("/")
        if x["id"] in in_plan or len(parts) < 4 or not (parts[0].isdigit() and parts[2].isdigit()):
            continue
        extra.setdefault((int(parts[0]), int(parts[2])), []).append(
            {"id": x["id"], "name": x.get("name"), "cat": x.get("cat"), "count": x.get("count", 0), "agst": x.get("status") or {},
             "dir": x.get("dir") or "", "done": _done(x), "set_info": x})
    weeks = []
    for i in range(0, len(ds), _cfg()[1]):
        wk = ds[i:i + _cfg()[1]]
        cards = [card(d.isoformat()) for d in wk]
        weeks.append({"monday": monday(wk[0]).isoformat(), "week": wk[0].isocalendar()[1],
                      "days": [{"date": d.isoformat(), "card": c, "past": d < today} for d, c in zip(wk, cards)],
                      "drafts": sum(1 for c in cards if c and c.get("status") == "draft" and not c["moved"]),
                      "onedrive": extra.get((wk[0].isocalendar()[0], wk[0].isocalendar()[1]), [])})
    late = [card(k) for k in sorted(dd) if k < today.isoformat()]
    late = [c for c in late if c and not c["done"]]
    in_sets = {s for x in stock.sets_store().data.values() for s in x.get("stems") or []}
    ags = [a["id"] for a in r["agencies"]]
    fresh = sum(1 for it in r["items"] if it["stem"] not in in_sets and stock._todo(it, ags))
    nxt = monday(today) + timedelta(days=7)
    ready_next = sum(1 for k, e in dd.items() if nxt.isoformat() <= k < (nxt + timedelta(days=7)).isoformat()
                     and e.get("status") == "approved" and not (card(k) or {}).get("moved"))
    return {"ok": True, "today": today.isoformat(), "today_card": card(today.isoformat()), "weeks": weeks, "late": late,
            "fresh": fresh, "planned": len(dd), "ready_next": ready_next, "agencies": r["agencies"],
            "has_set_dir": bool(stock.set_dir())}


def _theme_groups(r: dict) -> list[dict]:
    """Plāna tēmas: sērija (cilvēka nosaukums) × kategorija; jaunie ED pirmie, tad lielākās."""
    names = {s["key"]: stock.pretty(s["name"]) for s in r["series"]}
    out: dict[tuple, dict] = {}
    for cat in ("RF", "ED", "EDI"):
        for it in stock._candidates(r, cat, set()):
            k = (names.get(it["series"], ""), cat)
            x = out.setdefault(k, {"theme": k[0] or "komplekts", "cat": cat, "stems": [], "newest": ""})
            x["stems"].append(it["stem"])
            x["newest"] = max(x["newest"], it.get("taken") or "")
    cut = (datetime.now() - timedelta(days=NEW_DAYS)).isoformat()
    lst = list(out.values())
    lst.sort(key=lambda x: (0 if x["cat"] in ("ED", "EDI") and x["newest"] >= cut else 1, -len(x["stems"])))
    return lst


def auto(today: date | None = None) -> dict:
    """"Ieplānot": brīvās dienas (no šodienas) aizpilda ar melnraksta komplektiem. Tēmas mijas (ne viena tēma 2 dienas
    pēc kārtas, ja ir cita); lielums = neiesniegtās / brīvās dienas (10–50)."""
    today = today or date.today()
    st = store()
    _clean()
    free = [d for d in days(today) if d >= today and d.isoformat() not in st.data["days"]]
    if not free:
        return {"ok": True, "made": 0, "free": 0}
    r = stock.listing()
    groups = _theme_groups(r)
    total = sum(len(g["stems"]) for g in groups)
    if not total:
        return {"ok": True, "made": 0, "free": len(free), "none": True}
    size = max(MIN_SIZE, min(MAX_SIZE, -(-total // len(free))))
    made, last = 0, ""
    for d in free:
        groups = [g for g in groups if g["stems"]]
        if not groups:
            break
        g = next((g for g in groups if g["theme"] + g["cat"] != last), groups[0])
        n = len(g["stems"]) if len(g["stems"]) - size < MIN_SIZE // 2 else size   # mazu atlikumu nepaliek atsevišķi
        res = stock.suggest(g["cat"], min(n, MAX_SIZE), only=g["stems"], r=r)
        stems = [it["stem"] for it in res["items"]]
        if not stems:                                   # tikai līdzīgās — tēmu izlaiž
            g["stems"] = []
            continue
        x = stock.set_save(g["theme"], g["cat"], stems)
        ss = stock.sets_store()
        with ss.lock:
            ss.data[x["id"]]["planned"] = d.isoformat()
            ss.save()
        with st.lock:
            st.data["days"][d.isoformat()] = {"set": x["id"], "theme": g["theme"], "cat": g["cat"], "status": "draft"}
            st.save()
        got = set(stems)                                # līdzīgās (atliktās) paliek nākamajām dienām
        took_all = n >= len(g["stems"])
        g["stems"] = [s for s in g["stems"] if s not in got]
        if took_all:                                    # palikušas tikai līdzīgās — atsevišķu mazu komplektu netaisa
            g["stems"] = []
        last = g["theme"] + g["cat"]
        made += 1
    return {"ok": True, "made": made, "free": len(free), "size": size}


def _set_planned(sid: str, d: str) -> None:
    ss = stock.sets_store()
    with ss.lock:
        if sid in ss.data:
            ss.data[sid]["planned"] = d
            ss.save()


def move_day(frm: str, to: str) -> dict:
    """Pārvilkt uz citu dienu; ja tur jau ir komplekts — samaina vietām. Pārvietotos (OneDrive) nepārvieto."""
    st = store()
    with st.lock:
        dd = st.data["days"]
        a, b = dd.get(frm), dd.get(to)
        if not a or frm == to:
            return {"ok": False, "error": "nothing"}
        for e in (a, b):
            if e and stock.sets_store().data.get(e.get("set"), {}).get("rel"):
                return {"ok": False, "error": "moved"}
        dd[to] = a
        if b:
            dd[frm] = b
        else:
            dd.pop(frm, None)
        st.save()
    _set_planned(a["set"], to)
    if b:
        _set_planned(b["set"], frm)
    return {"ok": True}


def approve_week(mon: str, on: bool = True) -> dict:
    st = store()
    m = date.fromisoformat(mon)
    keys = [(m + timedelta(days=i)).isoformat() for i in range(7)]
    n = 0
    with st.lock:
        for k in keys:
            e = st.data["days"].get(k)
            if e and e.get("status") != ("approved" if on else "draft"):
                e["status"] = "approved" if on else "draft"
                n += 1
        st.save()
    return {"ok": True, "n": n}


def remove(d: str) -> dict:
    """Noņem no plāna; nepārvietotu un neiesniegtu melnraksta komplektu izdzēš (bildes atgriežas brīvajās)."""
    st = store()
    with st.lock:
        e = st.data["days"].pop(d, None)
        st.save()
    if not e:
        return {"ok": False, "error": "nothing"}
    x = stock.sets_store().data.get(e.get("set")) or {}
    led = stock.ledger().data
    marked = any((led.get(s) or {}).get(a, {}).get("state") for s in x.get("stems") or [] for a in stock.AG_IDS)
    if x and not x.get("rel") and not marked:
        stock.set_delete(x["id"])
        return {"ok": True, "deleted": True}
    if x:
        _set_planned(x["id"], "")
    return {"ok": True, "deleted": False}


def prepare_next(today: date | None = None) -> dict:
    """"Sagatavot nākamo nedēļu": apstiprinātos nākamās nedēļas komplektus pārvieto uz OneDrive (mapes pēc plānotās
    dienas). Tikai nākamā nedēļa (lēmums 2026-11-05 16:59)."""
    from . import move
    today = today or date.today()
    nxt = monday(today) + timedelta(days=7)
    lo, hi = nxt.isoformat(), (nxt + timedelta(days=7)).isoformat()
    ids = [e["set"] for k, e in sorted(store().data["days"].items()) if lo <= k < hi and e.get("status") == "approved"]
    if not ids:
        return {"ok": False, "error": "no_approved"}
    return move.move_many(ids)


def planned_map() -> dict:
    """{stem: plānotā diena} — Krājumā stāvoklis "plānots"."""
    out = {}
    for x in stock.sets_store().data.values():
        if x.get("planned"):
            for s in x.get("stems") or []:
                out[s] = x["planned"]
    return out
