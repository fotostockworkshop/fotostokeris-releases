"""Tirgotāja apraksts kopīgajam kodam core/ (noteikumi §10, §12). Moduļa atslēgām prefikss sub_ (§5)."""
from __future__ import annotations

from pathlib import Path

from core import app as core_app

from . import APP_NAME, VERSION

ROOT = Path(__file__).resolve().parent.parent

# Aģentūras, kurās sūtu editorial (ED) bildes — lietotājs maina iestatījumos (Vārdotāja Stoku_noteikumi: Adobe parasto ED
# no individuāliem autoriem nepieņem; Envato un Magnific — tikai komerciālas bildes)
ED_DEFAULT = ["shutterstock", "istock", "alamy", "dreamstime", "depositphotos", "123rf", "pond5", "pixta"]

DEFAULT_SETTINGS = {
    "sub_ready_dir": "",          # iesniegšanai gatavo bilžu mape (tukšs = Vārdotāja "ready_dir" nav zināms — jāizvēlas)
    "sub_agencies": [],           # tukšs = kopīgās "target_agencies" vai visas
    "sub_ed_agencies": ED_DEFAULT,
}


def _validate(vals: dict) -> dict:
    for k in ("sub_agencies", "sub_ed_agencies"):
        if k in vals and not isinstance(vals[k], list):
            vals.pop(k)
    return vals


APP = core_app.init(core_app.App(
    name=APP_NAME, slug="Tirgotajs", version=VERSION, ports=(47635, 47636, 47637), api_prefix="sub_",
    web_dir=ROOT / "web", defaults=DEFAULT_SETTINGS, msgs={}, validate_settings=_validate,
    icon=ROOT / "assets" / "icon.png",
    backup_files=("ledger.json", "sets.json"),
    sync_files=("ledger.json", "sets.json"),
    local_keys=("sub_ready_dir",)))


def after_restore() -> None:
    from . import stock
    stock._ledger = None
    stock._sets = None
