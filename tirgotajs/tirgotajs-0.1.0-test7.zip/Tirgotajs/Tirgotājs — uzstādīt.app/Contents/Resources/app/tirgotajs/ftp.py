"""Aģentūru FTP pieslēgumi (iestatījumi → "Aģentūru pieslēgumi"). Parole — tikai drošajā glabātuvē
(core/credentials, nosaukums ftp:<aģentūra>). FTP un FTPS — Python ftplib; SFTP — bibliotēka paramiko (ja uzstādīta).
Augšupielāde no komplekta — nākamajā versijā; šeit pieslēgšanās pārbaude."""
from __future__ import annotations

import ftplib
import socket

from core import credentials

from . import stock

TIMEOUT = 20


def cred_name(ag: str) -> str:
    return "ftp:" + ag


def _login(ag: str, c: dict):
    cr = credentials.get(cred_name(ag))
    if not cr or not cr[0] or not cr[1]:
        raise RuntimeError("no_creds")
    user, pw = cr
    host, port, proto = str(c.get("host") or "").strip(), int(c.get("port") or 0), c.get("proto") or "ftp"
    if not host:
        raise RuntimeError("no_host")
    if proto == "sftp":
        try:
            import paramiko
        except ImportError:
            raise RuntimeError("no_paramiko")
        t = paramiko.Transport((host, port or 22))
        t.banner_timeout = TIMEOUT
        t.connect(username=user, password=pw)
        return ("sftp", t, paramiko.SFTPClient.from_transport(t))
    f = ftplib.FTP_TLS(timeout=TIMEOUT) if proto == "ftps" else ftplib.FTP(timeout=TIMEOUT)
    f.connect(host, port or 21)
    f.login(user, pw)
    if proto == "ftps":
        f.prot_p()
    return ("ftp", f, None)


def _close(h):
    try:
        if h[0] == "sftp":
            h[2].close()
            h[1].close()
        else:
            h[1].quit()
    except Exception:
        pass


def test(ag: str, override: dict | None = None) -> dict:
    if ag not in stock.FTP_DEF:
        return {"ok": False, "error": "no_ftp"}
    c = stock.conn(ag)
    if override:
        c.update({k: override[k] for k in ("proto", "host", "port") if override.get(k)})
    try:
        h = _login(ag, c)
    except RuntimeError as e:
        return {"ok": False, "error": str(e)}
    except ftplib.error_perm as e:
        return {"ok": False, "error": "auth", "detail": str(e)[:200]}
    except (socket.timeout, TimeoutError):
        return {"ok": False, "error": "timeout"}
    except Exception as e:
        return {"ok": False, "error": "connect", "detail": f"{type(e).__name__}: {e}"[:200]}
    try:
        listing = h[2].listdir(".")[:20] if h[0] == "sftp" else h[1].nlst()[:20]
    except Exception:
        listing = []
    _close(h)
    return {"ok": True, "listing": listing}
