"use strict";
/* Tirgotājs 0.1.0 — krājums "bilde × aģentūra" (docs/tirgotajs-kopsavilkums.md §3, §11; docs/tirgotajs-iesniegsana.md).
   Kopīgais (tēma, valoda, iestatījumu rāmis, atjauninājumi) — /core/core.js. */

const S = { items: [], series: [], agencies: [], sets: [], sel: new Set(), shown: 300, page: "stock", data: null, ns: null };
Object.defineProperty(S, "settings", { get: () => Core.settings, set: (v) => { Core.settings = v; } });   // google.js / gsync.js lieto S.settings
const STATES = ["submitted", "accepted", "rejected", "skip"];

function showPage(name) {
  S.page = name;
  $$(".tabs button").forEach((b) => b.classList.toggle("active", b.dataset.page === name));
  $$(".page").forEach((p) => p.classList.toggle("hidden", p.id !== "page-" + name));
  if (name === "settings") loadSettings();
  if (name === "sets") loadSets();
}
function loadSettings() { settingsPage.load(); }      // google.js papildina (Google konta rinda)
function reloadView() { load(); if (S.page === "sets") loadSets(); }   // gsync.js — pēc datu saņemšanas no cita datora
$$(".tabs button").forEach((b) => b.addEventListener("click", () => showPage(b.dataset.page)));

/* ---------- šūnas stāvoklis ---------- */
function cellState(it, ag) {
  const c = (it.cells || {})[ag] || {};
  if (c.state) return c.state;                     // lietotāja atzīme ir svarīgāka par pārbaudi
  return c.bad ? "bad" : "";
}
function reasonText(r) { return t(r[0], r[1] || {}); }
function cellTitle(it, ag) {
  const c = (it.cells || {})[ag] || {}, st = cellState(it, ag);
  const parts = [agName(ag) + ": " + t("st_" + st)];
  if (c.at) parts.push(new Date(c.at).toLocaleDateString(window.langLocale()));
  if (c.reason) parts.push(c.reason);
  if (c.bad) parts.push(...c.bad.map(reasonText));
  return parts.join("\n");
}
function agName(id) { const a = S.agencies.find((x) => x.id === id); return a ? a.name : id; }

/* ---------- ielāde ---------- */
async function load() {
  let d;
  try { d = await api("list"); } catch (e) { toast(e.message, "err"); return; }
  S.data = d;
  S.items = d.items || []; S.series = d.series || []; S.agencies = d.agencies || []; S.sets = d.sets || [];
  const have = new Set(S.items.map((i) => i.stem));
  S.sel.forEach((s) => { if (!have.has(s)) S.sel.delete(s); });
  $("#noDir").classList.toggle("hidden", !d.no_dir && d.error !== "dir_missing");
  if (d.error === "dir_missing") $("#noDir p").textContent = t("dir_missing", { p: d.dir || "" });
  else $("#noDir p").textContent = t("no_dir");
  const dir = (Core.settings || {}).sub_ready_dir || "";
  $("#dirLine").classList.toggle("hidden", !dir || d.error === "dir_missing");
  $("#dirPath").textContent = dir;
  fillFilters();
  renderCards();
  render();
  Core.setStatus("count", { text: t("sb_count", { n: S.items.length, s: S.series.length }) });
}

function fillFilters() {
  const fs = $("#fSeries"), cur = fs.value;
  fs.innerHTML = `<option value="">${esc(t("all"))}</option>` + S.series.map((s) => `<option value="${esc(s.key)}">${esc(s.name)} (${s.count})</option>`).join("");
  fs.value = S.series.some((s) => s.key === cur) ? cur : "";
  const fk = $("#fSet"), ck = fk.value;
  fk.innerHTML = `<option value="">${esc(t("all"))}</option><option value="-">${esc(t("f_noset"))}</option>` + S.sets.map((x) => `<option value="${esc(x.id)}">${esc(x.name)}</option>`).join("");
  fk.value = ck === "-" || S.sets.some((x) => x.id === ck) ? ck : "";
  for (const sel of [$("#fAgency"), $("#selAgency")]) {
    const v = sel.value;
    sel.innerHTML = (sel.id === "fAgency" ? `<option value="">${esc(t("any_agency"))}</option>` : "") + S.agencies.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("");
    if (S.agencies.some((a) => a.id === v)) sel.value = v;
  }
}

/* ---------- kopsavilkums pa aģentūrām ---------- */
function renderCards() {
  const box = $("#agCards");
  if (!S.items.length) { box.innerHTML = ""; return; }
  box.innerHTML = S.agencies.map((a) => {
    const n = { "": 0, submitted: 0, accepted: 0, rejected: 0, skip: 0, bad: 0 };
    S.items.forEach((it) => { n[cellState(it, a.id)]++; });
    const lim = a.limit ? `<div class="ag-lim small ${recentCount(a.id, a.limit[1]) >= a.limit[0] ? "over" : "muted"}">${esc(t("limit_line", { have: recentCount(a.id, a.limit[1]), n: a.limit[0], d: a.limit[1] }))}</div>` : "";
    const how = a.ftp ? t(a.ftp.endsWith("*") ? "how_ftp_q" : "how_ftp", { f: a.ftp.replace("*", "") }) : t("how_web");
    return `<div class="ag-card" data-ag="${a.id}">
      <div class="ag-h"><b>${esc(a.name)}</b><button class="ghost small ag-open" data-url="${esc(a.url)}" title="${esc(t("open_ag_d"))}">${esc(t("open_ag"))} ↗</button></div>
      <div class="ag-todo"><span class="big">${n[""]}</span> <span class="muted">${esc(t("c_todo"))}</span></div>
      <div class="ag-n small"><span class="st-submitted-t">${n.submitted} ${esc(t("c_sub"))}</span> · <span class="st-accepted-t">${n.accepted} ${esc(t("c_acc"))}</span> ·
        <span class="st-rejected-t">${n.rejected} ${esc(t("c_rej"))}</span> · <span class="muted">${n.bad + n.skip} ${esc(t("c_bad"))}</span></div>
      <div class="ag-how small muted">${esc(how)}</div>${lim}
      <button class="ag-todo-btn small" data-ag="${a.id}">${esc(t("show_todo"))}</button></div>`;
  }).join("");
}
$("#agCards").addEventListener("click", async (e) => {
  const o = e.target.closest(".ag-open");
  if (o) { try { await api("open_url", { url: o.dataset.url }); } catch (err) { toast(err.message, "err"); } return; }
  const b = e.target.closest(".ag-todo-btn");
  if (b) { $("#fAgency").value = b.dataset.ag; $("#fShow").value = "todo"; S.shown = 300; render(); $("#grid").scrollIntoView({ behavior: "smooth" }); }
});

/* ---------- tabula ---------- */
function filtered() {
  const set = $("#fSet").value, ser = $("#fSeries").value, cat = $("#fCat").value, show = $("#fShow").value, ag = $("#fAgency").value;
  const q = $("#fText").value.trim().toLowerCase();
  const ags = ag ? [ag] : S.agencies.map((a) => a.id);
  return S.items.filter((it) => {
    if (ser && it.series !== ser) return false;
    if (set === "-" ? (it.in_sets || []).length : set && !(it.in_sets || []).includes(set)) return false;
    if (cat && it.cat !== cat) return false;
    if (q && !(it.file + " " + it.orig + " " + it.title).toLowerCase().includes(q)) return false;
    if (show === "todo") return ags.some((a) => cellState(it, a) === "");
    if (show === "rejected") return ags.some((a) => cellState(it, a) === "rejected");
    if (show === "bad") return ags.some((a) => cellState(it, a) === "bad");
    return true;
  });
}

function render() {
  const list = filtered();
  const ags = S.agencies;
  $("#grid thead").innerHTML = `<tr><th class="ck"><input type="checkbox" id="ckAll"></th><th></th><th data-i18n="col_file">${esc(t("col_file"))}</th>
    <th>${esc(t("col_cat"))}</th><th>${esc(t("col_size"))}</th>` +
    ags.map((a) => `<th class="agh" title="${esc(a.name)}">${esc(a.name.replace(/ \/.*/, ""))}</th>`).join("") + `</tr>`;
  const rows = list.slice(0, S.shown);
  const tok = encodeURIComponent(window.TOKEN);
  $("#grid tbody").innerHTML = rows.map((it) => {
    const mb = (it.size / 1048576).toFixed(1), mp = it.w && it.h ? (it.w * it.h / 1e6).toFixed(1) + " MP" : "";
    const ser = S.series.find((s) => s.key === it.series);
    return `<tr data-stem="${esc(it.stem)}" class="${S.sel.has(it.stem) ? "sel" : ""}">
      <td class="ck"><input type="checkbox" class="ck1" ${S.sel.has(it.stem) ? "checked" : ""}></td>
      <td class="th">${it.thumb ? `<img loading="lazy" src="/thumb?t=${tok}&s=${encodeURIComponent(it.series)}&n=${encodeURIComponent(it.stem)}" alt="">` : ""}</td>
      <td class="fn"><div class="f1" title="${esc(it.path)}">${esc(it.file)}</div><div class="f2 muted small">${esc(ser ? ser.name : "")}${it.title ? " · " + esc(it.title) : ""}</div></td>
      <td><span class="cat cat-${esc(it.cat)}">${esc(it.cat)}</span></td>
      <td class="muted small">${mb} MB<br>${mp}</td>` +
      ags.map((a) => { const st = cellState(it, a.id); return `<td class="cell st-${st}" data-ag="${a.id}" title="${esc(cellTitle(it, a.id))}">${st === "bad" ? "!" : st === "accepted" ? "✓" : st === "rejected" ? "✕" : st === "submitted" ? "↑" : st === "skip" ? "–" : ""}</td>`; }).join("") + `</tr>`;
  }).join("");
  $("#empty").classList.toggle("hidden", !!list.length || !!(S.data && S.data.no_dir));
  $("#empty").textContent = S.items.length ? t("empty_filter") : t("empty_none");
  $("#more").classList.toggle("hidden", list.length <= S.shown);
  $("#countLine").textContent = t("count_line", { n: list.length, all: S.items.length });
  $("#ckAll").checked = rows.length > 0 && rows.every((r) => S.sel.has(r.stem));
  $("#ckAll").addEventListener("change", (e) => { rows.forEach((r) => (e.target.checked ? S.sel.add(r.stem) : S.sel.delete(r.stem))); render(); });
  selBar();
}
["#fSet", "#fSeries", "#fCat", "#fShow", "#fAgency"].forEach((s) => $(s).addEventListener("change", () => { S.shown = 300; render(); }));
$("#fText").addEventListener("input", () => { S.shown = 300; render(); });
$("#more").addEventListener("click", () => { S.shown += 300; render(); });

$("#grid tbody").addEventListener("click", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr) return;
  const stem = tr.dataset.stem;
  const cell = e.target.closest("td.cell");
  if (cell) return cellMenu(cell, stem, cell.dataset.ag);
  if (e.target.closest("td.ck") || e.target.closest("td.th") || e.target.closest("td.fn")) {
    if (S.sel.has(stem)) S.sel.delete(stem); else S.sel.add(stem);
    tr.classList.toggle("sel", S.sel.has(stem));
    const ck = $(".ck1", tr); if (ck) ck.checked = S.sel.has(stem);
    selBar();
  }
});
$("#grid tbody").addEventListener("dblclick", (e) => {
  const tr = e.target.closest("tr[data-stem]"); if (!tr || e.target.closest("td.cell")) return;
  const it = S.items.find((i) => i.stem === tr.dataset.stem);
  if (it) api("open", { path: it.path }).catch((err) => toast(err.message, "err"));
});

/* ---------- vienas šūnas izvēlne ---------- */
function cellMenu(td, stem, ag) {
  const m = $("#cellMenu");
  const it = S.items.find((i) => i.stem === stem);
  const c = (it.cells || {})[ag] || {};
  const stems = S.sel.has(stem) && S.sel.size > 1 ? [...S.sel] : [stem];
  m.innerHTML = `<div class="ctx-h">${esc(agName(ag))}${stems.length > 1 ? " · " + esc(t("n_photos", { n: stems.length })) : ""}</div>` +
    (c.bad ? `<div class="ctx-bad small">${c.bad.map((r) => "⚠ " + esc(reasonText(r))).join("<br>")}</div>` : "") +
    STATES.map((s) => `<button data-st="${s}" class="${c.state === s ? "on" : ""}">${esc(t("mark_" + s))}</button>`).join("") +
    `<button data-st="">${esc(t("mark_clear"))}</button>`;
  const r = td.getBoundingClientRect();
  m.style.left = Math.min(r.left, innerWidth - 230) + "px";
  m.style.top = Math.min(r.bottom + 2, innerHeight - 260) + "px";
  m.classList.remove("hidden");
  m.onclick = async (e) => {
    const b = e.target.closest("button[data-st]"); if (!b) return;
    m.classList.add("hidden");
    await mark(stems, ag, b.dataset.st);
  };
}
document.addEventListener("click", (e) => { if (!e.target.closest("#cellMenu") && !e.target.closest("td.cell")) $("#cellMenu").classList.add("hidden"); });

async function mark(stems, ag, st) {
  let reason = "";
  if (st === "rejected") {
    reason = await askText(t("reason_q"));
    if (reason === null) return;
  }
  try {
    await api("mark", { stems, agency: ag, state: st, reason });
    toast(t("marked", { n: stems.length, a: agName(ag), s: t(st ? "st_" + st : "st_") }), "ok", 2500);
    await load();
  } catch (e) { toast(e.message, "err"); }
}
function askText(msg) {
  return new Promise((res) => {
    const m = $("#reasonModal"), inp = $("#reasonIn");
    $("#reasonQ").textContent = msg; inp.value = ""; m.classList.remove("hidden");
    setTimeout(() => inp.focus(), 30);
    const done = (v) => { m.classList.add("hidden"); $("#reasonOk").onclick = $("#reasonNo").onclick = inp.onkeydown = null; res(v); };
    $("#reasonOk").onclick = () => done(inp.value.trim());
    $("#reasonNo").onclick = () => done(null);
    inp.onkeydown = (e) => { if (e.key === "Enter") done(inp.value.trim()); if (e.key === "Escape") done(null); };
  });
}

/* ---------- atlasīto josla ---------- */
function selBar() {
  const n = S.sel.size;
  $("#selBar").classList.toggle("hidden", !n);
  $("#selN").textContent = t("n_selected", { n });
}
$("#selBar").addEventListener("click", (e) => {
  const b = e.target.closest("button[data-st]"); if (!b) return;
  mark([...S.sel], $("#selAgency").value, b.dataset.st);
});
$("#selClear").addEventListener("click", () => { S.sel.clear(); render(); });

/* ---------- mape ---------- */
async function pickDir() {
  try {
    const r = await api("pick_folder", { start: (Core.settings || {}).sub_ready_dir || "" });
    if (!r.path) return;
    await api("set_dir", { path: r.path });
    Core.settings.sub_ready_dir = r.path;
    await load();
  } catch (e) { if (!/pick_busy/.test(e.message)) toast(e.message, "err"); }
}
$("#pickDir").addEventListener("click", pickDir);
$("#changeDir").addEventListener("click", pickDir);
$("#openDir").addEventListener("click", () => api("open", { path: (Core.settings || {}).sub_ready_dir || "" }).catch((e) => toast(e.message, "err")));
$("#reloadBtn").addEventListener("click", () => reloadView());

/* ---------- komplekti ---------- */
const thumbUrl = (it) => `/thumb?t=${encodeURIComponent(window.TOKEN)}&s=${encodeURIComponent(it.series)}&n=${encodeURIComponent(it.stem)}`;
async function suggest(more = false) {
  const cat = $("#nsCat").value, size = +$("#nsSize").value || 0, match = (S.ns && S.ns.match) || "";
  const have = more && S.ns ? S.ns.items : [];
  let d;
  try { d = await api("set_suggest", { cat, size: more ? Math.max(1, (size || S.ns.size) - have.length) || 10 : size, exclude: have.map((i) => i.stem).concat(S.ns && S.ns.removed || []), match }); }
  catch (e) { return toast(e.message, "err"); }
  const items = more ? have.concat(d.items.filter((i) => !have.some((h) => h.stem === i.stem))) : d.items;
  S.ns = { cat, items, size: d.size, removed: more && S.ns ? S.ns.removed : [], match };
  $("#nsSize").placeholder = t("ns_auto", { n: d.auto });
  $("#nsInfo").textContent = d.todo ? t("ns_info", { todo: d.todo, n: items.length, sim: d.similar }) : t("ns_none");
  paintNs();
}
function paintNs() {
  const ns = S.ns;
  $("#nsBox").classList.toggle("hidden", !ns || !ns.items.length);
  if (!ns) return;
  $("#nsGrid").innerHTML = ns.items.map((it) => `<div class="ns-it" data-stem="${esc(it.stem)}" title="${esc(it.file + (it.title ? "\n" + it.title : ""))}">
    ${it.thumb ? `<img loading="lazy" src="${thumbUrl(it)}" alt="">` : `<div class="ns-noimg"></div>`}
    <div class="small ns-fn">${esc(it.file)}</div><button class="ns-x" data-i18n-title="ns_remove" title="${esc(t("ns_remove"))}">×</button></div>`).join("");
}
$("#nsGo").addEventListener("click", () => { S.ns = null; suggest(false); });
$("#nsMore").addEventListener("click", () => suggest(true));
$("#nsCancel").addEventListener("click", () => { S.ns = null; paintNs(); $("#nsInfo").textContent = ""; });
$("#nsGrid").addEventListener("click", (e) => {
  const x = e.target.closest(".ns-x"); if (!x) return;
  const stem = x.closest(".ns-it").dataset.stem;
  S.ns.items = S.ns.items.filter((i) => i.stem !== stem); S.ns.removed.push(stem); paintNs();
});
$("#nsSave").addEventListener("click", async () => {
  if (!S.ns || !S.ns.items.length) return;
  try {
    const r = await api("set_save", { name: $("#nsName").value.trim(), cat: S.ns.cat, stems: S.ns.items.map((i) => i.stem) });
    toast(t("ns_saved", { n: r.set.name, c: S.ns.items.length }), "ok", 4000);
    S.ns = null; $("#nsName").value = ""; $("#nsInfo").textContent = ""; paintNs();
    await load(); loadSets();
  } catch (e) { toast(e.message, "err"); }
});
/* aģentūras iesniegšanas limits (docs/tirgotajs-iesniegsana.md): Shutterstock 500 / 7 dienās, Magnific 200 / mēnesī */
function recentCount(ag, days) {
  const from = Date.now() - days * 864e5;
  return S.items.filter((it) => { const c = (it.cells || {})[ag] || {}; return c.state && c.state !== "skip" && c.at && Date.parse(c.at) >= from; }).length;
}
function limitNote(ag, add) {
  const a = S.agencies.find((x) => x.id === ag); if (!a || !a.limit) return "";
  const [n, days] = a.limit, have = recentCount(ag, days);
  return have + add > n ? " ⚠ " + t("limit_over", { a: a.name, n, d: days, have, add }) : "";
}
/* ---------- AI asistents (assistant.py): AI izvēlas darbību, bildes atlasa Tirgotājs, lietotājs saglabā ---------- */
const PROV = { claude_sub: "Claude", chatgpt_sub: "ChatGPT", claude_api: "Claude API", openai_api: "OpenAI API", local: "" };
async function ask() {
  const text = $("#asIn").value.trim(); if (!text) return;
  const out = $("#asOut"), btn = $("#asGo");
  btn.disabled = true; out.classList.remove("hidden"); out.textContent = t("asst_busy");
  let d;
  try { d = await api("ask", { text }); } catch (e) { out.textContent = e.message; btn.disabled = false; return; }
  btn.disabled = false;
  const who = PROV[d.by] ? t("asst_by", { p: PROV[d.by] }) : t("asst_local");
  let msg = d.reply || "";
  if (d.action === "make_set") {
    const r = d.set || {};
    $("#nsCat").value = d.cat || "RF";
    S.ns = { cat: d.cat || "RF", items: r.items || [], size: r.size, removed: [], match: d.match || "" };
    $("#nsSize").placeholder = t("ns_auto", { n: r.auto || 0 });
    $("#nsInfo").textContent = r.todo ? t("ns_info", { todo: r.todo, n: (r.items || []).length, sim: r.similar || 0 }) : t("ns_none");
    if (!$("#nsName").value && d.match) $("#nsName").value = (d.match.replace(/\b\w/g, (c) => c.toUpperCase()) + " " + (d.cat || "RF")).trim();
    paintNs();
    msg = msg || ((r.items || []).length ? t("asst_set", { n: r.items.length, m: d.match || "—", c: d.cat || "RF" }) : t("ns_none"));
    if ((r.items || []).length) msg += " " + t("asst_review");
  } else if (d.action === "show") {
    showPage("stock");
    $("#fText").value = d.match || ""; $("#fAgency").value = d.agency || ""; $("#fShow").value = d.show || ""; S.shown = 300; render();
    msg = msg || t("asst_shown", { n: filtered().length });
  }
  out.innerHTML = `<div>${esc(msg)}</div><div class="muted small">${esc(who)}${d.errors && d.errors.length ? " · " + esc(t("asst_noai")) : ""}</div>`;
}
$("#asGo").addEventListener("click", ask);
$("#asIn").addEventListener("keydown", (e) => { if (e.key === "Enter") ask(); });

async function loadSets() {
  let d;
  try { d = await api("sets"); } catch (e) { return toast(e.message, "err"); }
  const ags = d.agencies || [];
  const box = $("#setsList");
  if (!d.sets.length) { box.innerHTML = `<div class="muted">${esc(t("sets_none"))}</div>`; return; }
  box.innerHTML = `<table class="t sets"><thead><tr><th>${esc(t("set_name"))}</th><th>${esc(t("f_cat"))}</th><th>${esc(t("set_n"))}</th><th>${esc(t("set_created"))}</th>` +
    ags.map((a) => `<th class="agh" title="${esc(a.name)}">${esc(a.name.replace(/ \/.*/, ""))}</th>`).join("") + `<th></th></tr></thead><tbody>` +
    d.sets.map((x) => `<tr data-id="${esc(x.id)}"><td><b>${esc(x.name)}</b></td><td><span class="cat cat-${esc(x.cat)}">${esc(x.cat)}</span></td><td>${x.count}</td>
      <td class="muted small">${esc(new Date(x.created).toLocaleDateString(window.langLocale()))}</td>` +
      ags.map((a) => { const p = x.progress[a.id] || 0; return `<td class="prog ${p >= x.count ? "done" : p ? "part" : ""}" title="${esc(a.name)}: ${p}/${x.count}">${p}/${x.count}</td>`; }).join("") +
      `<td class="acts"><button class="small set-show">${esc(t("set_show"))}</button>
        <select class="set-ag">${ags.map((a) => `<option value="${a.id}">${esc(a.name)}</option>`).join("")}</select><button class="small set-exp" title="${esc(t("set_exp_d"))}">${esc(t("set_exp"))}</button><button class="small primary set-sub">${esc(t("set_sub"))}</button>
        <button class="small ghost set-del">${esc(t("set_del"))}</button></td></tr>`).join("") + `</tbody></table>`;
  box.onclick = async (e) => {
    const tr = e.target.closest("tr[data-id]"); if (!tr) return;
    const x = d.sets.find((s) => s.id === tr.dataset.id);
    if (e.target.closest(".set-show")) { showPage("stock"); $("#fSet").value = x.id; S.shown = 300; render(); return; }
    if (e.target.closest(".set-exp")) {
      const ag = $(".set-ag", tr).value, btn = e.target.closest(".set-exp");
      btn.disabled = true; const old = btn.textContent; btn.textContent = t("set_exp_busy");
      try {
        const r = await api("set_export", { id: x.id, agency: ag });
        if (!r.copied) toast(t("set_sub_none", { a: agName(ag) }), "err", 5000);
        else {
          toast(t("set_exp_done", { n: r.copied, a: agName(ag), d: r.dir }) + (r.skipped ? " " + t("set_sub_skip", { k: r.skipped }) : ""), "ok", 9000);
          api("open", { path: r.dir }).catch(() => {});
        }
      } catch (err) { toast(err.message, "err"); }
      btn.disabled = false; btn.textContent = old; return;
    }
    if (e.target.closest(".set-sub")) {
      const ag = $(".set-ag", tr).value;
      /* tikai bildes, kas šai aģentūrai der un vēl nav atzīmētas (neder / noraidītās / pieņemtās nepārraksta) */
      const todo = x.stems.filter((st) => { const it = S.items.find((i) => i.stem === st); return it && cellState(it, ag) === ""; });
      const skip = x.count - todo.length;
      if (!todo.length) { toast(t("set_sub_none", { a: agName(ag) }), "err", 5000); return; }
      if (!(await uiConfirm(t("set_sub_q", { n: todo.length, s: x.name, a: agName(ag) }) + (skip ? " " + t("set_sub_skip", { k: skip }) : "") + limitNote(ag, todo.length), t("set_sub")))) return;
      await mark(todo, ag, "submitted"); loadSets(); return;
    }
    if (e.target.closest(".set-del")) {
      if (!(await uiConfirm(t("set_del_q", { s: x.name }), t("set_del")))) return;
      try { await api("set_delete", { id: x.id }); await load(); loadSets(); } catch (err) { toast(err.message, "err"); }
    }
  };
}

/* ---------- iestatījumi ---------- */
const settingsPage = Core.settingsFrame({
  root: "#page-settings",
  shared: ["agencies"],
  connections: { jobs: [["assistant", t("job_assistant")]] },          // "Pieslēgumi": OneDrive un Google konts (google.js — sinhronizācija starp datoriem)
  moduleHtml: `<section data-collapse="sub"><h2 data-i18n="s_app"></h2>
    <label><span data-i18n="ready_dir"></span>
      <div class="row"><input id="sDir" spellcheck="false" style="flex:1"><button id="sDirPick" data-i18n="pick_dir"></button></div></label>
    <p class="muted small" data-i18n="s_dir_d"></p>
    <h3 data-i18n="s_ags"></h3><p class="muted small" data-i18n="s_ags_d"></p><div id="sAgs" class="ag-checks"></div>
    <label><span data-i18n="s_setdir"></span>
      <div class="row"><input id="sSetDir" spellcheck="false" style="flex:1"><button id="sSetDirPick" data-i18n="pick_dir"></button></div></label>
    <p class="muted small" data-i18n="s_setdir_d"></p>
    <h3 data-i18n="s_conn_ag"></h3><p class="muted small" data-i18n="s_conn_ag_d"></p><div id="sConn"></div>
    <h3 data-i18n="s_ed"></h3><p class="muted small" data-i18n="s_ed_d"></p><div id="sEd"></div></section>
    ${window.BACKUP_HTML || ""}`,
  load(s) {
    $("#sDir").value = s.sub_ready_dir || "";
    $("#sSetDir").value = s.sub_set_dir || ""; $("#sSetDir").placeholder = t("s_setdir_ph");
    const all = (Core.state || {}).agencies_all || [];
    const box = (id, vals) => all.map((a) => `<label class="chk"><input type="checkbox" class="${id}" value="${a.id}" ${vals.includes(a.id) ? "checked" : ""}> ${esc(a.name)}</label>`).join("");
    $("#sAgs").innerHTML = box("sAg1", s.sub_agencies || []);
    const ed = s.sub_ed_agencies || [], edi = s.sub_edi_agencies || [];
    $("#sEd").innerHTML = `<table class="t ed-tbl"><thead><tr><th>${esc(t("f_agency"))}</th><th>ED</th><th>EDI</th></tr></thead><tbody>` +
      all.map((a) => { const e = ed.includes(a.id); return `<tr><td>${esc(a.name)}</td><td><input type="checkbox" class="sEd1" value="${a.id}" ${e ? "checked" : ""}></td>
        <td><input type="checkbox" class="sEdi1" value="${a.id}" ${e || edi.includes(a.id) ? "checked" : ""} ${e ? "disabled" : ""}></td></tr>`; }).join("") + `</tbody></table>`;
    $$(".sEd1").forEach((c) => c.addEventListener("change", () => {     /* ED ietver EDI */
      const i = $(`.sEdi1[value="${c.value}"]`); if (c.checked) { i.checked = true; i.disabled = true; } else i.disabled = false;
    }));
    connLoad(s, all);
    if (window.bkLoad) window.bkLoad(s);
  },
  collect() {
    return { sub_ready_dir: $("#sDir").value.trim(), sub_set_dir: $("#sSetDir").value.trim(), sub_agencies: $$(".sAg1").filter((c) => c.checked).map((c) => c.value),
      sub_ed_agencies: $$(".sEd1").filter((c) => c.checked).map((c) => c.value),
      sub_edi_agencies: $$(".sEdi1").filter((c) => c.checked && !c.disabled).map((c) => c.value),
      sub_conn: connCollect(), ...(window.bkCollect ? window.bkCollect() : {}) };
  },
  onSaved() { load(); if (typeof loadBackups === "function") loadBackups(); },
});
document.addEventListener("click", async (e) => {
  const b = e.target.closest("#sDirPick, #sSetDirPick"); if (!b) return;
  const inp = b.id === "sDirPick" ? $("#sDir") : $("#sSetDir");
  try { const r = await api("pick_folder", { start: inp.value }); if (r.path) inp.value = r.path; } catch (_) {}
});

/* ---------- aģentūru pieslēgumi: FTP vai portāls (parole — tikai drošajā glabātuvē, core/credentials "ftp:<aģentūra>") ---------- */
async function connLoad(s, all) {
  const box = $("#sConn"); if (!box) return;
  const def = (Core.state || {}).ftp_def || {}, cfg = s.sub_conn || {};
  let creds = {};
  try { creds = (await api("creds", { names: Object.keys(def).map((a) => "ftp:" + a) })).creds || {}; } catch (_) {}
  box.innerHTML = all.map((a) => {
    const c = cfg[a.id] || {}, d = def[a.id], mode = d && c.mode === "ftp" ? "ftp" : "portal", cr = creds["ftp:" + a.id] || {};
    return `<div class="cn-ag" data-ag="${a.id}"><div class="cn-ag-h"><b>${esc(a.name)}</b>
      <select class="ca-mode"><option value="portal">${esc(t("mode_portal"))}</option>${d ? `<option value="ftp">${esc(t("mode_ftp"))}</option>` : ""}</select>
      ${d ? "" : `<span class="muted small">${esc(t("ftp_none"))}</span>`}</div>
      <div class="ca-portal ${mode === "portal" ? "" : "hidden"}"><input class="ca-url" spellcheck="false" placeholder="${esc(a.url)}" value="${esc(c.url && c.url !== a.url ? c.url : "")}"></div>
      ${d ? `<div class="ca-ftp ${mode === "ftp" ? "" : "hidden"}">
        <div class="ca-row"><select class="ca-proto">${["ftp", "ftps", "sftp"].map((p) => `<option value="${p}" ${(c.proto || d.proto) === p ? "selected" : ""}>${p.toUpperCase()}</option>`).join("")}</select>
          <input class="ca-host" spellcheck="false" data-ph="host" placeholder="${esc(d.host || t("ftp_host"))}" value="${esc(c.host && c.host !== d.host ? c.host : "")}">
          <input class="ca-port" type="number" min="1" max="65535" placeholder="${d.port}" value="${esc(c.port && c.port !== d.port ? c.port : "")}"></div>
        <div class="ca-row"><input class="ca-user" spellcheck="false" autocomplete="off" placeholder="${esc(t("cr_user"))}" value="${esc(cr.user || "")}">
          <input class="ca-pass" type="password" autocomplete="new-password" placeholder="${esc(cr.saved ? t("ftp_pass_saved") : t("cr_pass"))}">
          <button class="small ca-save">${esc(t("ftp_save"))}</button><button class="small ca-test">${esc(t("ftp_test"))}</button>
          ${cr.saved ? `<button class="small ghost ca-forget">${esc(t("cr_forget"))}</button>` : ""}<span class="ca-st small muted"></span></div>
        <div class="muted small">${esc(t(d.note))}</div></div>` : ""}</div>`;
  }).join("");
  box.onchange = (e) => {
    const m = e.target.closest(".ca-mode"); if (!m) return;
    const row = m.closest(".cn-ag");
    $(".ca-portal", row).classList.toggle("hidden", m.value !== "portal");
    if ($(".ca-ftp", row)) $(".ca-ftp", row).classList.toggle("hidden", m.value !== "ftp");
  };
  $$(".cn-ag", box).forEach((row) => { const c = cfg[row.dataset.ag] || {}; if (c.mode === "ftp" && $(".ca-ftp", row)) $(".ca-mode", row).value = "ftp"; });
  box.onclick = async (e) => {
    const row = e.target.closest(".cn-ag"); if (!row) return;
    const ag = row.dataset.ag, st = $(".ca-st", row);
    try {
      if (e.target.closest(".ca-save")) {
        await api("cred_save", { name: "ftp:" + ag, user: $(".ca-user", row).value.trim(), password: $(".ca-pass", row).value });
        $(".ca-pass", row).value = ""; st.textContent = t("saved"); return connLoad(Core.settings, all);
      }
      if (e.target.closest(".ca-forget")) { await api("cred_forget", { name: "ftp:" + ag }); return connLoad(Core.settings, all); }
      if (e.target.closest(".ca-test")) {
        if ($(".ca-pass", row).value) await api("cred_save", { name: "ftp:" + ag, user: $(".ca-user", row).value.trim(), password: $(".ca-pass", row).value });
        st.textContent = t("ftp_testing");
        const r = await api("ftp_test", { agency: ag, conn: connOf(row) });
        st.textContent = r.ok ? t("ftp_ok") : t("ftp_e_" + r.error) + (r.detail ? " (" + r.detail + ")" : "");
        st.className = "ca-st small " + (r.ok ? "ok-t" : "err-t");
      }
    } catch (err) {
      const k = "ftp_e_" + err.message;
      st.textContent = err.message === "keyring" ? t("s_creds_na") : t(k) !== k ? t(k) : err.message; st.className = "ca-st small err-t";
    }
  };
}
function connOf(row) {
  const o = { mode: $(".ca-mode", row).value };
  const url = $(".ca-url", row).value.trim(); if (url) o.url = url;
  if ($(".ca-ftp", row)) {
    o.proto = $(".ca-proto", row).value;
    const h = $(".ca-host", row).value.trim(); if (h) o.host = h;
    const p = +$(".ca-port", row).value; if (p) o.port = p;
  }
  return o;
}
function connCollect() {
  if (!$("#sConn .cn-ag")) return (Core.settings || {}).sub_conn || {};
  const out = {};
  $$("#sConn .cn-ag").forEach((row) => { out[row.dataset.ag] = connOf(row); });
  return out;
}

function onLang() { applyI18n(); fillFilters(); renderCards(); render(); if (S.page === "settings") loadSettings(); if (S.page === "sets") { loadSets(); paintNs(); } }

Core.init({ onLang, icon: "/static/icon.svg" });

async function init() {
  let st;
  try { st = await api("state"); } catch (e) { toast(e.message, "err"); return; }
  Core.boot(st);
  applyI18n();
  await load();
}
init();
