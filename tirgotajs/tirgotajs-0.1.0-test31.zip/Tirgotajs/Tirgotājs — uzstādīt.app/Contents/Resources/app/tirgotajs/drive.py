"""Tirgotājs ↔ Google Drive caur programmas Google kontu (test21; noteikumi dati §7a (c), §8c; lēmumi 2026-11-09).

- Vienkāršotā kārtība (dati §7a, lēmums 2026-11-11 22:33; test31): Vārdotāja sūtījumi — Google `Fotostokeris/Sutijumi`
  (`core.manifests_drive.pull` → datu mapē `Sutijumi-drive/`, ik 15 min, poga "Atjaunot no Google" — uzreiz); tikai lasa,
  nemaina. Bildes, kuru šajā datorā nav (Mac — NAS neredz), rāda "uz NAS".
- Komplektu manifesti — Google `Fotostokeris/Komplekti` (raksta tikai Tirgotājs, bez apvienošanas); komplekti, kuru tur
  vēl nav (arī vecie no `Manifesti`), augšupielādē no OneDrive komplektu mapes.
- `agenturas_bildes.json` (Analītiķis → Drive `Fotostokeris/Kopigi/`): bildes, kas jau ir aģentūrās — Tirgotājs tikai lasa.
Bez Google konta — nekas no šī nenotiek (strādā kā līdz šim).
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from pathlib import Path

from . import config

EVERY = 900                     # s — Drive pārbaude fonā
EXT_FILE = "agenturas_bildes.json"
_last = 0.0
_lock = threading.Lock()
_state = {"at": "", "error": "", "manifests": 0, "uploaded": 0, "ext": 0}
_sent: set[str] = set()         # sērijas, kas šajā reizē jau ieliktas rindā (vecās)
_ext_cache: tuple[float, dict] | None = None


IN_DIR = "Sutijumi"              # lasa (raksta Vārdotājs)
OUT_DIR = "Komplekti"            # raksta (lasa Analītiķis)


def drive_dir() -> Path:
    return Path(config.app_dir()) / "Sutijumi-drive"


def connected() -> bool:
    try:
        from core import google
        return google.connected()
    except Exception:
        return False


def _vsafe(name: str) -> str:
    """Tāpat kā Vārdotāja manifest._safe — lai Drive faila nosaukums sakrīt."""
    return re.sub(r'[\\/:*?"<>|]+', "_", str(name or "")).strip(" .") or "serija"


def queue(jpath: str, zpath: str | None = None) -> None:
    """Komplekta manifests → Google `Komplekti` (viens rakstītājs — pārraksta). Sūtījumus (Vārdotāja) nemaina."""
    if not connected():
        return
    try:
        data = json.loads(Path(jpath).read_text(encoding="utf-8"))
        sid = str(data.get("set_id") or (data.get("series_id") if data.get("kind") == "set" else "") or "")
        if not sid:
            return
        from core import manifests_drive
        manifests_drive.queue(f"{_vsafe(data.get('name'))}__{sid[:8]}", jpath, zpath, "plain", folder=OUT_DIR)
    except Exception as e:
        print("Drive manifests (rinda):", str(e)[:200])


def _out_ids() -> set:
    """ID8 komplektiem, kas jau ir Google `Komplekti`."""
    from core import google, manifests_drive
    out = set()
    for f in manifests_drive._remote_files(google.root_folders(OUT_DIR)):
        n = f.get("name") or ""
        if n.endswith(".json") and "__" in n:
            out.add(n.rsplit("__", 1)[1][:-5])
    return out


def _backfill_sets(ids) -> int:
    """Komplektu manifesti (kind: set), kuru Google `Komplekti` vēl nav (test31 pāreja no `Manifesti`) — arī vecie, pārvietoti pirms test21 (lietotājs 2026-11-11 14:45;
    Analītiķis tos lasa). 2026-11-11 16:35: meklē pašā komplektu mapē (OneDrive), ne tikai sarakstā — komplekts, kura
    ierakstam nav mapes vai kura sarakstā nav (arī apzināti izņemts — bildes mapē tik un tā ir), nonāk Drive."""
    from . import stock
    n = 0
    sm = list(stock.set_manifests())
    print(f"Drive manifesti: komplektu mapē {stock.set_dir()} atrasti {len(sm)} komplektu manifesti, Drive jau {sum(1 for _j, _d, s in sm if s[:8] in ids)}")
    for jp, data, sid in sm:
        key = "set:" + sid
        if key in _sent or sid[:8] in ids:
            continue
        z = os.path.join(os.path.dirname(jp), data.get("thumbs") or (os.path.basename(jp)[:-5] + "-sikteli.zip"))
        _sent.add(key)
        queue(jp, z if os.path.isfile(z) else None)
        print(f"Drive manifesti: komplekts '{data.get('name')}' ielikts augšupielādei")
        n += 1
    if n:
        print(f"Drive manifesti: {n} komplekti ielikti augšupielādei (Drive to vēl nebija)")
    return n


def _pull_ext() -> int:
    from core import google
    fid = google.folder("Kopigi")
    f = next((x for x in google.list_files(fid) if x.get("name") == EXT_FILE), None)
    if not f:
        return 0
    p = Path(config.app_dir()) / EXT_FILE
    tmp = p.with_suffix(".tmp")
    tmp.write_bytes(google.download(f["id"]))
    os.replace(tmp, p)
    return len(ext_data().get("images") or [])


def refresh(force: bool = False) -> dict:
    """Lejupielādē jaunākos manifestus un agenturas_bildes.json; vecās sērijas — augšupielādei."""
    global _last
    if not connected():
        return {"ok": False, "error": "no_google"}
    if not force and time.time() - _last < EVERY:
        return {"ok": True, "skipped": True, **_state}
    with _lock:
        _last = time.time()
        err = []
        try:
            from core import manifests_drive
            r = manifests_drive.pull(drive_dir(), folder=IN_DIR)
            _state["manifests"] = r.get("total", 0)
            print(f"sūtījumi no Google ({IN_DIR}): jauni {r.get('new')}, kopā {r.get('total')}")
        except Exception as e:
            err.append(f"manifesti: {e}"[:200])
        try:
            _state["ext"] = _pull_ext()
        except Exception as e:
            err.append(f"{EXT_FILE}: {e}"[:200])
        try:
            from . import stock
            stock.restore_sets()                       # pazuduši komplekti no OneDrive mapes (tad arī uz Drive)
        except Exception as e:
            err.append(f"komplekti: {e}"[:200])
        try:
            _state["uploaded"] += _backfill_sets(_out_ids())
        except Exception as e:
            err.append(f"augšupielāde: {e}"[:200])
        for m in err:
            print("Google Drive:", m)
        _state.update(at=time.strftime("%Y-%m-%d %H:%M"), error="; ".join(err))
    return {"ok": not err, **_state}


def status() -> dict:
    return dict(_state, google=connected())


def start() -> None:
    def loop():
        time.sleep(45)
        while True:
            try:
                refresh()
            except Exception as e:
                print("Google Drive fonā:", str(e)[:200])
            time.sleep(EVERY)
    threading.Thread(target=loop, daemon=True, name="drive").start()


# --------------------------------------------------------------------------- agenturas_bildes.json (dati §8c)

AG_MAP = {"envato_market": "envato"}


def ext_data() -> dict:
    global _ext_cache
    p = Path(config.app_dir()) / EXT_FILE
    try:
        m = p.stat().st_mtime
    except OSError:
        return {}
    if _ext_cache and _ext_cache[0] == m:
        return _ext_cache[1]
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    _ext_cache = (m, d)
    return d


def ext_index() -> tuple[dict, dict]:
    """({stem: {aģentūra: {status, seen}}}, {orig_file(lower): tas pats})."""
    by_stem, by_orig = {}, {}
    rank = {"accepted": 5, "review": 4, "changes": 3, "other": 2, "rejected": 1}
    for im in ext_data().get("images") or []:
        ags = {}
        for a, v in (im.get("agencies") or {}).items():
            a = AG_MAP.get(a, a)
            v = {"status": str((v or {}).get("status") or "other"), "seen": str((v or {}).get("seen") or "")}
            if a not in ags or rank.get(v["status"], 2) > rank.get(ags[a]["status"], 2):
                ags[a] = v
        if not ags:
            continue
        if im.get("stem"):
            by_stem[str(im["stem"])] = ags
        if im.get("orig_file"):
            by_orig[str(im["orig_file"]).lower()] = ags
    return by_stem, by_orig
