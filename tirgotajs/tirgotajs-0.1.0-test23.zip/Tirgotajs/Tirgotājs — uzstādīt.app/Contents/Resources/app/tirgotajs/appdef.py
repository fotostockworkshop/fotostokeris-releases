"""Tirgotāja apraksts kopīgajam kodam core/ (noteikumi §10, §12). Moduļa atslēgām prefikss sub_ (§5)."""
from __future__ import annotations

from pathlib import Path

from core import app as core_app

from . import APP_NAME, VERSION

ROOT = Path(__file__).resolve().parent.parent

# Aģentūras, kurās sūtu editorial (ED) bildes — lietotājs maina iestatījumos (Vārdotāja Stoku_noteikumi: Adobe parasto ED
# no individuāliem autoriem nepieņem; Envato un Magnific — tikai komerciālas bildes)
ED_DEFAULT = ["shutterstock", "istock", "alamy", "dreamstime", "depositphotos", "123rf", "pond5", "pixta"]

DEFAULT_SETTINGS = {
    "sub_ready_dir": "",          # iesniegšanai gatavo bilžu mape (tukšs = Vārdotāja "ready_dir" nav zināms — jāizvēlas)
    "sub_agencies": [],           # tukšs = kopīgās "target_agencies" vai visas
    "sub_ed_agencies": ED_DEFAULT,
    "sub_edi_agencies": ["adobe"],   # tikai EDI (illustrative editorial — zīmoli bez cilvēkiem; lietotāja termins); ED ķeksis ietver arī EDI
    "sub_conn": {},               # {aģentūra: {mode: portal|ftp, url, proto, host, port}} — parole tikai drošajā glabātuvē
    "sub_plan_weeks": 6,          # Plāns: cik nedēļas uz priekšu
    "sub_plan_per_week": 5,       # Plāns: komplekti nedēļā (darba dienas P–Pk)
    "sub_plan_size": 25,          # Plāns: bildes komplektā ("Ieplānot" logs, test22)
    "sub_plan_ed_week": 1,        # Plāns: ED komplekti nedēļā, ne vairāk (RF aģentūrām katru nedēļu jaunas bildes)
    "sub_plan_unit": "weeks",     # Plāns ("Ieplānot" logs, test23): periods dienās vai nedēļās
    "sub_plan_n": 6,              # … cik dienas / nedēļas
    "sub_plan_wdays": [0, 1, 2, 3, 4],   # … kurās nedēļas dienās (0 = pirmdiena)
    "sub_plan_per_day": 1,        # … komplekti dienā
    "sub_plan_slots": ["rnd"],    # … katram komplektam RF | ED | rnd (nejauši)
    "sub_ai_pick": True,          # AI redaktors pats izvēlas bildes (ar "kāpēc"); izslēgts — atlasa Tirgotājs pēc noteikumiem
    "sub_ai_thumbs": False,       # AI redaktoram rāda arī sīktēlus (kontaktlapa) — tērē vairāk
    "sub_set_dir": "",            # komplektu mape (OneDrive STOCK) — komplektus pārvieto uz <gads>/<MM-mēn>/<nedēļa>/<KAT-tēma-N>
}


def _validate(vals: dict) -> dict:
    for k in ("sub_plan_weeks", "sub_plan_per_week"):
        if k in vals:
            try:
                vals[k] = max(1, min(12 if k == "sub_plan_weeks" else 7, int(vals[k])))
            except (TypeError, ValueError):
                vals.pop(k)
    for k in ("sub_agencies", "sub_ed_agencies", "sub_edi_agencies"):
        if k in vals and not isinstance(vals[k], list):
            vals.pop(k)
    if "sub_conn" in vals and not isinstance(vals["sub_conn"], dict):
        vals.pop("sub_conn")
    return vals


def _busy() -> bool:
    from . import ftp, move
    return bool(ftp.status().get("running") or move.status().get("running"))


APP = core_app.init(core_app.App(
    name=APP_NAME, slug="Tirgotajs", version=VERSION, ports=(47635, 47636, 47637), api_prefix="sub_",
    web_dir=ROOT / "web", defaults=DEFAULT_SETTINGS, msgs={}, busy=_busy, validate_settings=_validate,
    icon=ROOT / "assets" / "icon.png",
    backup_files=("ledger.json", "sets.json", "notsimilar.json", "plan.json"),
    sync_files=("ledger.json", "sets.json", "notsimilar.json", "plan.json"),
    sync_merge={"ledger.json": lambda b, l, r: __import__("tirgotajs.stock", fromlist=["x"]).ledger_merge(b, l, r)},
    local_keys=("sub_ready_dir", "sub_set_dir")))


def after_restore() -> None:
    from . import stock
    stock._ledger = None
    stock._sets = None
    from . import similar
    similar._pairs = None
    from . import plan
    plan._store = None
