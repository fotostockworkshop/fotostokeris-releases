"""Plāns — iesniegšana pa dienām (kopsavilkums §11; lēmumi 2026-11-05 16:27–16:59, 2026-11-10 12:52–12:56).

plan.json (sinhronizējas): {"items": {set_id: {"date": "YYYY-MM-DD", "theme": "Bali", "cat": "RF", "status": draft|approved}}}
— **vienā dienā var būt vairāki komplekti** (test23; līdz test22 — {"days": {date: {...}}}, ielasot pārveido).
Komplekts ir parasts komplekts (sets.json) ar `planned` = diena. "Pārvietots" (STOCK) un "iesniegts" — no komplekta,
nevis glabā plānā. Mapes STOCK pēc plānotās dienas (move.target).
"""
from __future__ import annotations

import re
from datetime import date, datetime, timedelta

from . import config, stock

_store: config.JsonStore | None = None
MAX_SIZE = 100
NEW_DAYS = 30            # "jaunie ED" — uzņemti pēdējās 30 dienās — tēmu secībā pirmie
ED_CATS = ("ED", "EDI")


def store() -> config.JsonStore:
    global _store
    if _store is None:
        _store = config.JsonStore(config.app_dir() / "plan.json", {"items": {}})
    _migrate(_store)
    return _store


def _migrate(st: config.JsonStore) -> None:
    """Vecais formāts {"days": {date: {set,…}}} (arī pēc sinhronizācijas no datora ar test22) → {"items": {set: {date,…}}}."""
    d = st.data
    d.setdefault("items", {})
    old = d.get("days")
    if old is None:
        return
    with st.lock:
        for k, e in (old or {}).items():
            if isinstance(e, dict) and e.get("set") and e["set"] not in d["items"]:
                d["items"][e["set"]] = {"date": k, "theme": e.get("theme") or "", "cat": e.get("cat") or "RF",
                                        "status": e.get("status") or "draft"}
        d.pop("days", None)
        st.save()


def items() -> dict:
    return store().data["items"]


def on_day(d: str) -> list[str]:
    return [sid for sid, e in items().items() if e.get("date") == d]


# --------------------------------------------------------------------------- iestatījumi

def opts() -> dict:
    """"Ieplānot" loga vērtības (atceras pēdējās)."""
    g = config.get

    def num(k, dflt, lo, hi):
        try:
            return max(lo, min(hi, int(g(k) if g(k) is not None else dflt)))
        except (TypeError, ValueError):
            return dflt
    wd = g("sub_plan_wdays")
    if not isinstance(wd, list) or not wd:
        wd = list(range(max(1, min(7, num("sub_plan_per_week", 5, 1, 7)))))
    slots = g("sub_plan_slots")
    per = num("sub_plan_per_day", 1, 1, 6)
    if not isinstance(slots, list):
        slots = []
    slots = [s if s in ("RF", "ED", "rnd") else "rnd" for s in slots][:per] + ["rnd"] * max(0, per - len(slots))
    unit = g("sub_plan_unit") if g("sub_plan_unit") in ("days", "weeks") else "weeks"
    return {"unit": unit, "n": num("sub_plan_n", num("sub_plan_weeks", 6, 1, 12), 1, 60),
            "wdays": sorted({int(x) for x in wd if str(x).isdigit() and 0 <= int(x) <= 6}) or [0, 1, 2, 3, 4],
            "per_day": per, "slots": slots, "size": num("sub_plan_size", 25, 5, MAX_SIZE)}


def monday(d: date) -> date:
    return d - timedelta(days=d.weekday())


def _span(o: dict, start: date) -> list[date]:
    """Plāna dienas: no `start`, N dienas vai N nedēļas (līdz svētdienai), tikai izvēlētajās nedēļas dienās."""
    end = start + timedelta(days=o["n"]) if o["unit"] == "days" else monday(start) + timedelta(days=7 * o["n"])
    out, d = [], start
    while d < end:
        if d.weekday() in o["wdays"]:
            out.append(d)
        d += timedelta(days=1)
    return out


def _clean() -> None:
    """Dzēsts komplekts → no plāna ārā."""
    st, sets = store(), stock.sets_store().data
    with st.lock:
        gone = [k for k in st.data["items"] if k not in sets]
        for k in gone:
            st.data["items"].pop(k, None)
        if gone:
            st.save()


def _done(info: dict) -> bool:
    z = (info or {}).get("status") or {}
    return bool(z) and all(v.get("st") in ("done", "bad") for v in z.values()) and any(v.get("st") == "done" for v in z.values())


def _local_day(at: str) -> str:
    """ISO laiks (UTC) → vietējā diena YYYY-MM-DD."""
    try:
        return datetime.fromisoformat(str(at)).astimezone().date().isoformat()
    except ValueError:
        return str(at or "")[:10]


def sub_day(x: dict) -> str:
    """Komplekta pirmās iesniegšanas diena (agrākā "submitted" atzīme kādā aģentūrā) vai ""."""
    ds = [_local_day(z["date"]) for z in (x.get("status") or {}).values() if z.get("date")]
    return min(ds) if ds else ""


# --------------------------------------------------------------------------- skats

def view() -> dict:
    """Kalendārs: visas 7 dienas; dienā — komplekti, kas tajā iesniegti (pirmā "submitted"), plānotie (plāna diena)
    un pārvietotie bez plāna un iesniegšanas (pārvietošanas diena). Dienā var būt vairāki."""
    _clean()
    today = date.today()
    sl = stock.sets_list()
    r = stock.listing()
    by = {it["stem"]: it for it in r["items"]}
    it_ = items()

    def card(x: dict) -> dict:
        e = it_.get(x["id"]) or {}
        pk = e.get("date") or ""
        th = [{"stem": s, "series": by[s]["series"]} for s in (x.get("stems") or []) if s in by and by[s].get("thumb")][:4]
        return {"id": x["id"], "date": pk, "status": e.get("status") or "", "theme": e.get("theme") or "",
                "cat": x.get("cat") or e.get("cat") or "RF", "name": x.get("name") or e.get("theme"),
                "count": x.get("count", 0), "thumbs": th, "agst": x.get("status") or {}, "moved": bool(x.get("ready")),
                "done": _done(x), "dir": x.get("dir") or "", "missing": x.get("missing", 0), "sub": sub_day(x),
                "remote": x.get("remote", 0), "set_info": x}
    cards = [card(x) for x in sl]
    byday: dict[str, list] = {}
    for c in cards:
        x = c["set_info"]
        day = c["sub"] or c["date"] or (_local_day(x["moved_at"]) if x.get("rel") and x.get("moved_at") else "")
        if day:
            c["day"] = day
            byday.setdefault(day, []).append(c)
    for v in byday.values():
        v.sort(key=lambda c: (0 if c["sub"] else 1, 0 if c["cat"] == "RF" else 1, c["name"] or ""))
    o = opts()
    nw = o["n"] if o["unit"] == "weeks" else max(1, -(-(o["n"] + today.weekday()) // 7))
    m0 = monday(today)
    weeks = []
    for i in range(max(nw, 1) + 1):                        # +1 — nākamā nedēļa vienmēr redzama (pievienot)
        wk = [m0 + timedelta(days=7 * i + k) for k in range(7)]
        dl = [{"date": d.isoformat(), "cards": byday.get(d.isoformat(), []), "past": d < today} for d in wk]
        weeks.append({"monday": wk[0].isoformat(), "week": wk[0].isocalendar()[1], "days": dl,
                      "drafts": sum(1 for x in dl for c in x["cards"] if c["date"] and c["status"] == "draft" and not c["moved"])})
    # tukšas nedēļas beigās nerāda (izņemot šo un nākamo)
    while len(weeks) > 2 and not any(x["cards"] for x in weeks[-1]["days"]):
        weeks.pop()
    late = sorted((c for c in cards if c["date"] and c["date"] < today.isoformat() and not c["done"] and not c["sub"]),
                  key=lambda c: c["date"])
    tc = [c for c in cards if c["date"] == today.isoformat()]
    in_sets = {s for x in stock.sets_store().data.values() for s in x.get("stems") or []}
    ags = [a["id"] for a in r["agencies"]]
    fresh = sum(1 for it in r["items"] if it["stem"] not in in_sets and stock._todo(it, ags))
    nxt = monday(today) + timedelta(days=7)
    ready_next = sum(1 for c in cards if c["date"] and nxt.isoformat() <= c["date"] < (nxt + timedelta(days=7)).isoformat()
                     and c["status"] == "approved" and not c["moved"])
    return {"ok": True, "today": today.isoformat(), "today_cards": tc, "weeks": weeks, "late": late,
            "fresh": fresh, "planned": len(it_), "ready_next": ready_next, "agencies": r["agencies"],
            "has_set_dir": bool(stock.set_dir())}


def free_days(today: date | None = None, n: int = 30) -> list[str]:
    """Tuvākās dienas (no šodienas, izvēlētajās nedēļas dienās), kurās vēl ir mazāk komplektu nekā "komplekti dienā"."""
    today = today or date.today()
    o = opts()
    cnt: dict[str, int] = {}
    for e in items().values():
        cnt[e.get("date") or ""] = cnt.get(e.get("date") or "", 0) + 1
    out, d = [], today
    for _ in range(400):
        if d.weekday() in o["wdays"] and cnt.get(d.isoformat(), 0) < o["per_day"]:
            out.append(d.isoformat())
            if len(out) >= n:
                break
        d += timedelta(days=1)
    return out or [today.isoformat()]


def day_free(d: str) -> bool:                              # saderībai (test21–22): dienā vienmēr var pievienot
    return True


def _set_planned(sid: str, d: str) -> None:
    ss = stock.sets_store()
    with ss.lock:
        if sid in ss.data:
            ss.data[sid]["planned"] = d
            ss.save()


def assign(sid: str, d: str, status: str = "approved") -> dict:
    """Komplektam iesniegšanas diena (veidojot, pārceļot, pirms pārvietošanas). Dienā var būt vairāki komplekti."""
    try:
        day = date.fromisoformat(d)
    except ValueError:
        return {"ok": False, "error": "bad_day"}
    if day < date.today():
        return {"ok": False, "error": "past_day"}
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    st = store()
    with st.lock:
        e = st.data["items"].get(sid)
        if e and e.get("date") != d and x.get("rel"):
            return {"ok": False, "error": "moved"}           # jau STOCK mapē pēc savas dienas
        st.data["items"][sid] = {"date": d, "theme": (e or {}).get("theme") or stock.pretty(re.sub(r"^(RF|ED|EDI)-", "", x.get("name") or "")),
                                 "cat": x.get("cat") or "RF", "status": (e or {}).get("status") or status}
        st.save()
    _set_planned(sid, d)
    return {"ok": True, "date": d}


def move_day(sid: str, to: str) -> dict:
    """Pārvilkt / pārcelt komplektu uz citu dienu (pievieno tai dienai, neko nemaina vietām)."""
    return assign(sid, to)


# --------------------------------------------------------------------------- automātiskā veidošana

def _theme_groups(r: dict) -> list[dict]:
    """Plāna tēmas: sērija (cilvēka nosaukums) × kategorija; jaunie ED pirmie, tad lielākās."""
    names = {s["key"]: stock.pretty(s["name"]) for s in r["series"]}
    out: dict[tuple, dict] = {}
    for cat in ("RF", "ED", "EDI"):
        for it in stock._candidates(r, cat, set()):
            k = (names.get(it["series"], ""), cat)
            x = out.setdefault(k, {"theme": k[0] or "komplekts", "cat": cat, "stems": [], "newest": ""})
            x["stems"].append(it["stem"])
            x["newest"] = max(x["newest"], it.get("taken") or "")
    cut = (datetime.now() - timedelta(days=NEW_DAYS)).isoformat()
    lst = list(out.values())
    lst.sort(key=lambda x: (0 if x["cat"] in ED_CATS and x["newest"] >= cut else 1, -len(x["stems"])))
    return lst


def stats() -> dict:
    """"Ieplānot" logam: brīvās bildes (vēl nav komplektā) pa kategorijām + pēdējās loga vērtības."""
    g = _theme_groups(stock.listing())
    rf = sum(len(x["stems"]) for x in g if x["cat"] == "RF")
    ed = sum(len(x["stems"]) for x in g if x["cat"] in ED_CATS)
    return {"ok": True, "rf": rf, "ed": ed, "start": date.today().isoformat(), **opts()}


class _Maker:
    """Komplektu veidotājs vienai "Ieplānot" / "Pievienot automātiski" reizei."""

    def __init__(self, size: int):
        self.r = stock.listing()
        self.groups = _theme_groups(self.r)
        self.size = size
        self.last = ""

    def left(self, ed: bool) -> int:
        return sum(len(g["stems"]) for g in self.groups if (g["cat"] in ED_CATS) == ed)

    def make(self, d: str, want: str) -> dict | None:
        """want: RF | ED | rnd. Nejauši — kategorija ar vairāk brīvu bilžu. Izvēlētās kategorijas nav → None."""
        while True:
            self.groups = [g for g in self.groups if g["stems"]]
            if want == "rnd":
                if not self.groups:
                    return None
                ed = self.left(True) > self.left(False)
            else:
                ed = want == "ED"
            pool = [g for g in self.groups if (g["cat"] in ED_CATS) == ed]
            if not pool:
                return None
            g = next((g for g in pool if g["theme"] + g["cat"] != self.last), pool[0])
            size = self.size
            n = len(g["stems"]) if len(g["stems"]) - size < max(3, size // 3) else size   # mazu atlikumu nepaliek
            res = stock.suggest(g["cat"], min(n, MAX_SIZE), only=g["stems"], r=self.r)
            stems = [it["stem"] for it in res["items"]][:n]
            if not stems or len(stems) < min(len(g["stems"]), max(3, size // 3)):
                g["stems"] = []                            # tikai līdzīgās / pārāk maz — tēmu izlaiž
                continue
            x = stock.set_save(g["theme"], g["cat"], stems)
            ss = stock.sets_store()
            with ss.lock:
                ss.data[x["id"]]["planned"] = d
                ss.data[x["id"]]["auto"] = True
                ss.save()
            st = store()
            with st.lock:
                st.data["items"][x["id"]] = {"date": d, "theme": g["theme"], "cat": g["cat"], "status": "draft"}
                st.save()
            got = set(stems)
            took_all = n >= len(g["stems"])
            g["stems"] = [] if took_all else [s for s in g["stems"] if s not in got]
            self.last = g["theme"] + g["cat"]
            return x


def auto(today: date | None = None, opt: dict | None = None) -> dict:
    """"Ieplānot" (test23, lietotājs 2026-11-10 12:52): periods dienās vai nedēļās, nedēļas dienas, komplekti dienā —
    katram RF / ED / nejauši, bildes komplektā. Dienā jau esošos komplektus ieskaita (aizpilda tikai trūkstošās vietas)."""
    opt = opt or {}
    today = today or date.today()
    o = opts()
    try:
        unit = opt.get("unit") if opt.get("unit") in ("days", "weeks") else o["unit"]
        n = max(1, min(60, int(opt.get("n") or o["n"])))
        wd = sorted({int(x) for x in (opt.get("wdays") if isinstance(opt.get("wdays"), list) else o["wdays"]) if 0 <= int(x) <= 6})
        per = max(1, min(6, int(opt.get("per_day") or o["per_day"])))
        slots = opt.get("slots") if isinstance(opt.get("slots"), list) else o["slots"]
        slots = ([s if s in ("RF", "ED", "rnd") else "rnd" for s in slots] + ["rnd"] * per)[:per]
        size = max(5, min(MAX_SIZE, int(opt.get("size") or o["size"])))
        start = max(today, date.fromisoformat(str(opt.get("start") or today.isoformat())))
    except (TypeError, ValueError):
        return {"ok": False, "error": "bad_opt"}
    if not wd:
        return {"ok": False, "error": "no_wdays"}
    config.update({"sub_plan_unit": unit, "sub_plan_n": n, "sub_plan_wdays": wd, "sub_plan_per_day": per,
                   "sub_plan_slots": slots, "sub_plan_size": size})
    _clean()
    mk = _Maker(size)
    if not sum(len(g["stems"]) for g in mk.groups):
        return {"ok": True, "made": 0, "free": 0, "none": True}
    made = slots_n = 0
    for d in _span({"unit": unit, "n": n, "wdays": wd}, start):
        have = [items()[s].get("cat") for s in on_day(d.isoformat())]
        need = list(slots)
        for c in have:                                      # esošie komplekti aizņem atbilstošās vietas
            k = "ED" if c in ED_CATS else "RF"
            if k in need:
                need.remove(k)
            elif "rnd" in need:
                need.remove("rnd")
            elif need:
                need.pop()
        for want in sorted(need, key=lambda w: {"RF": 0, "ED": 1}.get(w, 2)):
            slots_n += 1
            if mk.make(d.isoformat(), want):
                made += 1
    return {"ok": True, "made": made, "free": slots_n, "size": size}


def add_auto(d: str, want: str = "rnd", size: int | None = None) -> dict:
    """Labais klikšķis uz dienas → "Pievienot automātiski": viens komplekts šai dienai."""
    try:
        if date.fromisoformat(d) < date.today():
            return {"ok": False, "error": "past_day"}
    except ValueError:
        return {"ok": False, "error": "bad_day"}
    o = opts()
    sz = max(5, min(MAX_SIZE, int(size or o["size"])))
    _clean()
    x = _Maker(sz).make(d, want if want in ("RF", "ED", "rnd") else "rnd")
    if not x:
        return {"ok": False, "error": "no_photos"}
    return {"ok": True, "set": {"id": x["id"], "name": x["name"], "count": len(x.get("stems") or [])}}


# --------------------------------------------------------------------------- noņemšana, apstiprināšana, pārvietošana

def remove(sid: str) -> dict:
    """Noņem no plāna; nepārvietotu un neiesniegtu "Ieplānot" komplektu izdzēš (bildes atgriežas brīvajās),
    pašu veidotu tikai noņem no plāna."""
    st = store()
    with st.lock:
        e = st.data["items"].pop(sid, None)
        st.save()
    if not e:
        return {"ok": False, "error": "nothing"}
    x = stock.sets_store().data.get(sid) or {}
    led = stock.ledger().data
    marked = any((led.get(s) or {}).get(a, {}).get("state") for s in x.get("stems") or [] for a in stock.AG_IDS)
    made_auto = x.get("auto") or e.get("status") == "draft"
    if x and not x.get("rel") and not marked and made_auto:
        stock.set_delete(sid)
        return {"ok": True, "deleted": True}
    if x:
        _set_planned(sid, "")
    return {"ok": True, "deleted": False}


def cancel(monday_iso: str = "", day: str = "") -> dict:
    """"Atcelt plānu" / "Atcelt nedēļu" / "Atcelt dienu": noņem vēl nepārvietotos komplektus (no šodienas)."""
    today = date.today().isoformat()
    sel = [(sid, e.get("date") or "") for sid, e in items().items() if (e.get("date") or "") >= today]
    if monday_iso:
        m = date.fromisoformat(monday_iso)
        wk = {(m + timedelta(days=i)).isoformat() for i in range(7)}
        sel = [z for z in sel if z[1] in wk]
    if day:
        sel = [z for z in sel if z[1] == day]
    n = deleted = 0
    for sid, _d in sel:
        if (stock.sets_store().data.get(sid) or {}).get("rel"):
            continue                                       # jau STOCK mapē — paliek
        r = remove(sid)
        if r.get("ok"):
            n += 1
            deleted += 1 if r.get("deleted") else 0
    return {"ok": True, "removed": n, "deleted": deleted}


def approve_week(mon: str, on: bool = True) -> dict:
    st = store()
    m = date.fromisoformat(mon)
    keys = {(m + timedelta(days=i)).isoformat() for i in range(7)}
    n = 0
    with st.lock:
        for e in st.data["items"].values():
            if e.get("date") in keys and e.get("status") != ("approved" if on else "draft"):
                e["status"] = "approved" if on else "draft"
                n += 1
        st.save()
    return {"ok": True, "n": n}


def prepare_next(today: date | None = None) -> dict:
    """"Sagatavot nākamo nedēļu": apstiprinātos nākamās nedēļas komplektus pārvieto uz STOCK (mapes pēc plānotās
    dienas). Tikai nākamā nedēļa (lēmums 2026-11-05 16:59)."""
    from . import move
    today = today or date.today()
    nxt = monday(today) + timedelta(days=7)
    lo, hi = nxt.isoformat(), (nxt + timedelta(days=7)).isoformat()
    ids = [sid for sid, e in sorted(items().items(), key=lambda z: z[1].get("date") or "")
           if lo <= (e.get("date") or "") < hi and e.get("status") == "approved"]
    if not ids:
        return {"ok": False, "error": "no_approved"}
    return move.move_many(ids)


def planned_map() -> dict:
    """{stem: plānotā diena} — Krājumā stāvoklis "plānots"."""
    out = {}
    for x in stock.sets_store().data.values():
        if x.get("planned"):
            for s in x.get("stems") or []:
                out[s] = x["planned"]
    return out
