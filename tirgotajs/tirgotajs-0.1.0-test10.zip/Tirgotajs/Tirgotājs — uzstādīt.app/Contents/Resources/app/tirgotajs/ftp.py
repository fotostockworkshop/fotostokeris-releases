"""Aģentūru FTP pieslēgumi (iestatījumi → "Aģentūru pieslēgumi"). Parole — tikai drošajā glabātuvē
(core/credentials, nosaukums ftp:<aģentūra>). FTP un FTPS — Python ftplib; SFTP — bibliotēka paramiko (ja uzstādīta).
upload_set(): komplekta bildes, kas aģentūrai der un vēl nav atzīmētas, augšupielādē fonā (progress — status());
pēc katra faila atzīme "uploaded" — portālā vēl jāspiež "Submit" (to dara lietotājs)."""
from __future__ import annotations

import ftplib
import os
import socket
import threading

from core import credentials

from . import stock

TIMEOUT = 20


def cred_name(ag: str) -> str:
    return "ftp:" + ag


def _login(ag: str, c: dict):
    cr = credentials.get(cred_name(ag))
    if not cr or not cr[0] or not cr[1]:
        raise RuntimeError("no_creds")
    user, pw = cr
    host, port, proto = str(c.get("host") or "").strip(), int(c.get("port") or 0), c.get("proto") or "ftp"
    if not host:
        raise RuntimeError("no_host")
    if proto == "sftp":
        try:
            import paramiko
        except ImportError:
            raise RuntimeError("no_paramiko")
        t = paramiko.Transport((host, port or 22))
        t.banner_timeout = TIMEOUT
        t.connect(username=user, password=pw)
        return ("sftp", t, paramiko.SFTPClient.from_transport(t))
    f = ftplib.FTP_TLS(timeout=TIMEOUT) if proto == "ftps" else ftplib.FTP(timeout=TIMEOUT)
    f.connect(host, port or 21)
    f.login(user, pw)
    if proto == "ftps":
        f.prot_p()
    return ("ftp", f, None)


def _close(h):
    try:
        if h[0] == "sftp":
            h[2].close()
            h[1].close()
        else:
            h[1].quit()
    except Exception:
        pass


def test(ag: str, override: dict | None = None) -> dict:
    if ag not in stock.FTP_DEF:
        return {"ok": False, "error": "no_ftp"}
    c = stock.conn(ag)
    if override:
        c.update({k: override[k] for k in ("proto", "host", "port") if override.get(k)})
    try:
        h = _login(ag, c)
    except RuntimeError as e:
        return {"ok": False, "error": str(e)}
    except ftplib.error_perm as e:
        return {"ok": False, "error": "auth", "detail": str(e)[:200]}
    except (socket.timeout, TimeoutError):
        return {"ok": False, "error": "timeout"}
    except Exception as e:
        return {"ok": False, "error": "connect", "detail": f"{type(e).__name__}: {e}"[:200]}
    try:
        listing = h[2].listdir(".")[:20] if h[0] == "sftp" else h[1].nlst()[:20]
    except Exception:
        listing = []
    _close(h)
    return {"ok": True, "listing": listing}


_job: dict = {"running": False}
_jlock = threading.Lock()


def status() -> dict:
    return dict(_job)


def _put(h, local: str, name: str, remote_dir: str):
    if h[0] == "sftp":
        h[2].put(local, (remote_dir.rstrip("/") + "/" if remote_dir else "") + name)
    else:
        with open(local, "rb") as f:
            h[1].storbinary("STOR " + name, f, blocksize=256 * 1024)


def _enter(h, remote_dir: str):
    if remote_dir and h[0] == "ftp":
        h[1].cwd(remote_dir)


def _run(ag: str, items: list, c: dict, sid: str = ""):
    errors, done = [], 0
    h = None
    try:
        h = _login(ag, c)
        _enter(h, c.get("dir") or "")
        for it in items:
            _job.update(current=it["file"])
            for attempt in (1, 2):                 # savienojums pārtrūka — pieslēdzas no jauna un mēģina vēlreiz
                try:
                    _put(h, it["path"], it["file"], c.get("dir") or "")
                    stock.mark([it["stem"]], ag, "uploaded", set_id=sid)
                    done += 1
                    break
                except Exception as e:
                    if attempt == 2:
                        errors.append(f"{it['file']}: {type(e).__name__}: {e}"[:200])
                    else:
                        _close(h)
                        h = _login(ag, c)
                        _enter(h, c.get("dir") or "")
            _job.update(done=done, errors=errors[-5:], nerr=len(errors))
    except Exception as e:
        errors.append(f"{type(e).__name__}: {e}"[:200] if not isinstance(e, RuntimeError) else str(e))
    finally:
        if h:
            _close(h)
        _job.update(running=False, finished=True, done=done, errors=errors[-5:], nerr=len(errors), current="")


def upload_set(sid: str, ag: str) -> dict:
    if ag not in stock.FTP_DEF:
        return {"ok": False, "error": "no_ftp"}
    c = stock.conn(ag)
    if c.get("mode") != "ftp":
        return {"ok": False, "error": "not_ftp"}
    cr = credentials.get(cred_name(ag))
    if not cr or not cr[1]:
        return {"ok": False, "error": "no_creds"}
    x = stock.sets_store().data.get(sid)
    if not x:
        return {"ok": False, "error": "no_set"}
    by = {it["stem"]: it for it in stock.listing()["items"]}
    items = []
    for st in x.get("stems") or []:
        it = by.get(st)
        if it:
            rec = (stock.ledger().data.get(st) or {}).get(ag) or {}
            if not rec.get("state") and not stock.check(it, ag) and os.path.isfile(it["path"]):
                items.append(it)
    if not items:
        return {"ok": False, "error": "nothing"}
    with _jlock:
        if _job.get("running"):
            return {"ok": False, "error": "busy"}
        _job.clear()
        _job.update(running=True, finished=False, agency=ag, set=sid, total=len(items), done=0, errors=[], nerr=0,
                    current="", url=c.get("url"))
    threading.Thread(target=_run, args=(ag, items, c, sid), daemon=True).start()
    return {"ok": True, "total": len(items)}
